#version 150

// 0.66 RELATIVA - lensa gravitasi (lubang hitam, lengkung ruang-waktu) + aberasi relativistik & Doppler (Lesat Cahaya).
// Lensa titik Schwarzschild, pendekatan lensa tipis: cahaya dari sudut beta tampak di sudut theta dengan
// beta = theta - thetaE^2 / theta. Di dalam cincin Einstein (theta < thetaE) terlihat citra kedua yang terbalik, di tepi
// bayangan ada cincin foton tipis, dan di dalam bayangan gelap total (cahaya nggak bisa lolos).

uniform sampler2D DiffuseSampler;

uniform vec2 InSize;
uniform float Clock;       // detik, buat kilau cincin foton
uniform float CenterX;     // pusat lensa di layar (0..1, boleh di luar layar)
uniform float CenterY;
uniform float Lens;        // jari-jari cincin Einstein (satuan tinggi layar), 0 = tanpa lensa
uniform float Shadow;      // jari-jari bayangan lubang hitam (satuan tinggi layar), 0 = tanpa bayangan
uniform float Ring;        // terang cincin foton (0-1)
uniform float Aberration;  // 0-1 aberasi relativistik: pandangan memampat ke arah gerak
uniform float Doppler;     // 0-1 pergeseran Doppler: biru di depan, merah di tepi

in vec2 texCoord;

out vec4 fragColor;

vec3 fetch(vec2 uv) {
    return texture(DiffuseSampler, clamp(uv, vec2(0.0005), vec2(0.9995))).rgb;
}

void main() {
    float aspect = InSize.x / max(InSize.y, 1.0);
    vec2 scale = vec2(aspect, 1.0);
    vec2 uv = texCoord;

    // 1) aberasi relativistik: makin cepat, makin banyak dunia yang terlihat termampat di depan
    if (Aberration > 0.0005) {
        vec2 d = (uv - 0.5) * scale;
        float r = length(d);
        float k = 1.0 + Aberration * (0.55 + 0.9 * r);
        uv = 0.5 + d * k / scale;
    }

    // 2) lensa gravitasi
    float shadow = 0.0;
    float ring = 0.0;
    if (Lens > 0.0005) {
        vec2 c = vec2(CenterX, CenterY);
        vec2 d = (uv - c) * scale;
        float th = max(length(d), 0.00001);
        vec2 dir = d / th;
        float fall = 1.0 / (1.0 + pow(th / (Lens * 7.0), 2.0));   // meluruh jauh dari pusat: layar nggak melengkung semua
        float beta = th - (Lens * Lens / th) * fall;
        uv = c + dir * beta / scale;
        if (Shadow > 0.0005) {
            shadow = 1.0 - smoothstep(Shadow * 0.94, Shadow * 1.02, th);
            float e = (th - Shadow * 1.06) / max(Shadow * 0.07, 0.0001);
            ring = exp(-e * e) * Ring * (0.9 + 0.1 * sin(Clock * 6.0 + atan(d.y, d.x) * 3.0));
        }
    }

    vec3 col = fetch(uv);

    // 3) Doppler: arah gerak (tengah layar) bergeser biru, tepi bergeser merah
    if (Doppler > 0.0005) {
        vec2 d = (texCoord - 0.5) * scale;
        float r = clamp(length(d) * 1.6, 0.0, 1.0);
        vec3 blue = col * vec3(0.72, 0.92, 1.38) + vec3(0.0, 0.02, 0.06);
        vec3 red = col * vec3(1.35, 0.82, 0.62);
        col = mix(col, mix(blue, red, r), Doppler);
    }

    col = mix(col, vec3(0.0), shadow);
    col += vec3(1.0, 0.82, 0.55) * ring;
    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
