package com.shazammod;

import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * SFX sinematik buatan sendiri (bukan suara bawaan Minecraft). File .ogg-nya ada di assets/shazammod/sounds/,
 * daftar variannya di assets/shazammod/sounds.json. Semua suara mono supaya terdengar dari arah sumbernya.
 * Dibuat dengan tools/sfx/synth.py.
 */
public final class ShazamSounds {
    private ShazamSounds() {}

    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, ShazamMod.MODID);

    // ------------------------------------------------ pustaka umum (0.24.1)
    public static final DeferredHolder<SoundEvent, SoundEvent> THUNDER = reg("thunder");
    public static final DeferredHolder<SoundEvent, SoundEvent> LIGHTNING_STRIKE = reg("lightning_strike");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPACT = reg("impact");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPACT_RING = reg("impact_ring");
    public static final DeferredHolder<SoundEvent, SoundEvent> BODY_HIT = reg("body_hit");
    public static final DeferredHolder<SoundEvent, SoundEvent> WHOOSH = reg("whoosh");
    public static final DeferredHolder<SoundEvent, SoundEvent> WHOOSH_HEAVY = reg("whoosh_heavy");
    public static final DeferredHolder<SoundEvent, SoundEvent> POWER_UP = reg("power_up");
    public static final DeferredHolder<SoundEvent, SoundEvent> AURA_SWELL = reg("aura_swell");
    public static final DeferredHolder<SoundEvent, SoundEvent> POWER_DOWN = reg("power_down");
    public static final DeferredHolder<SoundEvent, SoundEvent> ENERGY_PULSE = reg("energy_pulse");
    public static final DeferredHolder<SoundEvent, SoundEvent> CHARGE = reg("charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> RISER = reg("riser");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHIMMER = reg("shimmer");
    public static final DeferredHolder<SoundEvent, SoundEvent> RESONANCE = reg("resonance");
    public static final DeferredHolder<SoundEvent, SoundEvent> SPELL = reg("spell");
    public static final DeferredHolder<SoundEvent, SoundEvent> SONIC_BOOM = reg("sonic_boom");
    public static final DeferredHolder<SoundEvent, SoundEvent> DIVINE = reg("divine");
    public static final DeferredHolder<SoundEvent, SoundEvent> PUNCH = reg("punch");
    public static final DeferredHolder<SoundEvent, SoundEvent> PUNCH_CRIT = reg("punch_crit");
    public static final DeferredHolder<SoundEvent, SoundEvent> DEFLECT = reg("deflect");
    public static final DeferredHolder<SoundEvent, SoundEvent> DARK_HISS = reg("dark_hiss");
    public static final DeferredHolder<SoundEvent, SoundEvent> DREAD = reg("dread");
    public static final DeferredHolder<SoundEvent, SoundEvent> HEARTBEAT = reg("heartbeat");
    public static final DeferredHolder<SoundEvent, SoundEvent> SAND_BURST = reg("sand_burst");
    public static final DeferredHolder<SoundEvent, SoundEvent> EARTH_CRACK = reg("earth_crack");
    public static final DeferredHolder<SoundEvent, SoundEvent> FIRE_BLAST = reg("fire_blast");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHOCKWAVE = reg("shockwave");
    public static final DeferredHolder<SoundEvent, SoundEvent> WIND_LOOP = reg("wind_loop");
    public static final DeferredHolder<SoundEvent, SoundEvent> CAPE_SNAP = reg("cape_snap");
    public static final DeferredHolder<SoundEvent, SoundEvent> BRAAM = reg("braam");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRANSFORM = reg("transform");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRANSFORM_ADAM = reg("transform_adam");

    // ------------------------------------------------ suara khas tiap skill (0.24.2)
    // *_WINDUP / *_CAST / MEHEN_RISE = ancang-ancang: panjangnya PERSIS sama dengan tick ancang-ancang di ShazamAnim,
    // jadi puncaknya jatuh tepat di tick hantaman. Putar di pitch 1 (jangan lewat tune()) supaya panjangnya nggak berubah.
    public static final DeferredHolder<SoundEvent, SoundEvent> SOLOMON_CAST = reg("solomon_cast");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOLOMON_SIGHT = reg("solomon_sight");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERCULES_WINDUP = reg("hercules_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERCULES_CLAP = reg("hercules_clap");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERCULES_THROW = reg("hercules_throw");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATLAS_WINDUP = reg("atlas_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATLAS_SLAM = reg("atlas_slam");
    public static final DeferredHolder<SoundEvent, SoundEvent> ZEUS_WINDUP = reg("zeus_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> ZEUS_SPEAR = reg("zeus_spear");
    public static final DeferredHolder<SoundEvent, SoundEvent> ACHILLES_WINDUP = reg("achilles_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> ACHILLES_WARCRY = reg("achilles_warcry");
    public static final DeferredHolder<SoundEvent, SoundEvent> COURAGE_NOVA = reg("courage_nova");
    public static final DeferredHolder<SoundEvent, SoundEvent> STORM_WINDUP = reg("storm_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> STORM_GODS = reg("storm_gods");
    public static final DeferredHolder<SoundEvent, SoundEvent> THUNDER_PUNCH = reg("thunder_punch");
    public static final DeferredHolder<SoundEvent, SoundEvent> MERCURY_BLINK = reg("mercury_blink");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHU_VORTEX = reg("shu_vortex");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHU_BURST = reg("shu_burst");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERU_DIVE = reg("heru_dive");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERU_LAND = reg("heru_land");
    public static final DeferredHolder<SoundEvent, SoundEvent> AMON_WINDUP = reg("amon_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> AMON_QUAKE = reg("amon_quake");
    public static final DeferredHolder<SoundEvent, SoundEvent> ZEHUTI_CAST = reg("zehuti_cast");
    public static final DeferredHolder<SoundEvent, SoundEvent> ZEHUTI_SEAL = reg("zehuti_seal");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATON_WINDUP = reg("aton_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATON_RAY = reg("aton_ray");
    public static final DeferredHolder<SoundEvent, SoundEvent> MEHEN_RISE = reg("mehen_rise");
    public static final DeferredHolder<SoundEvent, SoundEvent> MEHEN_COIL = reg("mehen_coil");
    public static final DeferredHolder<SoundEvent, SoundEvent> MEHEN_BITE = reg("mehen_bite");
    public static final DeferredHolder<SoundEvent, SoundEvent> KAHNDAQ_WINDUP = reg("kahndaq_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> KAHNDAQ_WRATH = reg("kahndaq_wrath");
    public static final DeferredHolder<SoundEvent, SoundEvent> CALL_WINDUP = reg("call_windup");

    // ------------------------------------------------ Penangkal Petir Hidup (0.25)
    // ROD_STRIKE = petir menyambar Shazam tiap 2 detik: desis turun 0,15 dtk (= ShazamAnim.ROD_DESCENT) lalu retakan tepat di
    // tick hantaman. Sama seperti ancang-ancang, putar di pitch +-1 supaya retakannya nggak bergeser.
    public static final DeferredHolder<SoundEvent, SoundEvent> ROD_STRIKE = reg("rod_strike");

    // ------------------------------------------------ Kekuatan Keluarga (0.26)
    // FAMILY_WINDUP panjangnya PERSIS ShazamAnim.FAMILY_WINDUP (10 tick) dan memuncak di tick sambaran; putar di pitch 1.
    public static final DeferredHolder<SoundEvent, SoundEvent> FAMILY_WINDUP = reg("family_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> FAMILY_STRIKE = reg("family_strike");

    // ------------------------------------------------ Tangan Kahndaq (0.27, Black Adam)
    // ADAM_CATCH = proyektil berhenti di udara (desing macet + dengung menahan), ADAM_RELEASE = semua dilempar balik.
    public static final DeferredHolder<SoundEvent, SoundEvent> ADAM_CATCH = reg("adam_catch");
    public static final DeferredHolder<SoundEvent, SoundEvent> ADAM_RELEASE = reg("adam_release");

    // ------------------------------------------------ Black Adam setara Shazam (0.28), kekuatan matahari Aton (0.28.1)
    // ADAM_BLOCK = Tangkisan Kahndaq (ditahan kulit, panas menyembur balik), ATON_PULSE = Cakram Aton tiap 2 detik
    // (semburan tepat di 0,15 dtk = ShazamAnim.ROD_DESCENT), ATON_PUNCH = Tinju Aton.
    public static final DeferredHolder<SoundEvent, SoundEvent> ADAM_BLOCK = reg("adam_block");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATON_PULSE = reg("aton_pulse");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATON_PUNCH = reg("aton_punch");

    // ------------------------------------------------ Pasif tiap 2 detik padam / menyala (0.29)
    // ROD_FADE = petir Shazam padam (gurun / es / Nether), ATON_SET = Cakram Aton terbenam, ATON_RISE = terbit (mekar di 1 dtk).
    public static final DeferredHolder<SoundEvent, SoundEvent> ROD_FADE = reg("rod_fade");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATON_SET = reg("aton_set");
    public static final DeferredHolder<SoundEvent, SoundEvent> ATON_RISE = reg("aton_rise");

    // ------------------------------------------------ Sabbac, juara enam iblis (0.30)
    // HELLFIRE_PULSE = Api Neraka tiap 2 detik (semburan tepat di 0,15 dtk = ShazamAnim.ROD_DESCENT). *_WINDUP panjangnya
    // PERSIS tick ancang-ancang di ShazamAnim (HORN_WINDUP 6, HELLGATE_WINDUP 12, SABBAC_CALL_WINDUP 12); putar di pitch 1.
    // BEELZEBUB_BREATH = tarikan napas BREATH_WINDUP lalu semburan BREATH_TICKS. SABBAC_PACT memuncak di PACT_STRIKE.
    public static final DeferredHolder<SoundEvent, SoundEvent> TRANSFORM_SABBAC = reg("transform_sabbac");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELLFIRE_PULSE = reg("hellfire_pulse");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELLFIRE_PUNCH = reg("hellfire_punch");
    public static final DeferredHolder<SoundEvent, SoundEvent> SABBAC_ENGULF = reg("sabbac_engulf");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELLFIRE_OUT = reg("hellfire_out");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELLFIRE_IN = reg("hellfire_in");
    public static final DeferredHolder<SoundEvent, SoundEvent> HORNS_WINDUP = reg("horns_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> HORNS_CHARGE = reg("horns_charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> AYM_SHELL = reg("aym_shell");
    public static final DeferredHolder<SoundEvent, SoundEvent> AYM_BURST = reg("aym_burst");
    public static final DeferredHolder<SoundEvent, SoundEvent> BELIAL_CHAINS = reg("belial_chains");
    public static final DeferredHolder<SoundEvent, SoundEvent> BEELZEBUB_BREATH = reg("beelzebub_breath");
    public static final DeferredHolder<SoundEvent, SoundEvent> ASMODEUS_ROAR = reg("asmodeus_roar");
    public static final DeferredHolder<SoundEvent, SoundEvent> CRATEIS_WINGS = reg("crateis_wings");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELLGATE_WINDUP = reg("hellgate_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELLGATE_OPEN = reg("hellgate_open");
    public static final DeferredHolder<SoundEvent, SoundEvent> LEGION_RISE = reg("legion_rise");
    public static final DeferredHolder<SoundEvent, SoundEvent> DEMON_CALL_WINDUP = reg("demon_call_windup");
    public static final DeferredHolder<SoundEvent, SoundEvent> DEMON_CALL = reg("demon_call");
    public static final DeferredHolder<SoundEvent, SoundEvent> SABBAC_PACT = reg("sabbac_pact");

    // ------------------------------------------------ Rival Juara (0.30)
    public static final DeferredHolder<SoundEvent, SoundEvent> RIVAL_ARRIVE = reg("rival_arrive");

    // ------------------------------------------------ Lintang, juara surya ala Superman (0.32, fisik tanpa sihir sejak 0.35)
    // SOLAR_PULSE = tenaga surya mengalir (sekutu diselamatkan / tenaga kembali), hembusannya tepat di 0,15 dtk.
    // SOLAR_FLARE memuncak di 0,8 dtk (= FLARE_WINDUP), SUN_CALL di 0,5 dtk (= SUNCALL_WINDUP). TRANSFORM_LINTANG diputar
    // di tick LINTANG_SUITUP (kostum terpasang). Putar di pitch 1 supaya puncaknya nggak bergeser.
    public static final DeferredHolder<SoundEvent, SoundEvent> SOLAR_PULSE = reg("solar_pulse");
    public static final DeferredHolder<SoundEvent, SoundEvent> HEAT_VISION = reg("heat_vision");
    public static final DeferredHolder<SoundEvent, SoundEvent> FROST_BREATH = reg("frost_breath");
    public static final DeferredHolder<SoundEvent, SoundEvent> SONIC_CLAP = reg("sonic_clap");
    public static final DeferredHolder<SoundEvent, SoundEvent> SPEED_DASH = reg("speed_dash");
    public static final DeferredHolder<SoundEvent, SoundEvent> DAWN_PUNCH = reg("dawn_punch");
    public static final DeferredHolder<SoundEvent, SoundEvent> BARRAGE = reg("barrage");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOLAR_FLARE = reg("solar_flare");
    public static final DeferredHolder<SoundEvent, SoundEvent> SUN_STRIKE = reg("sun_strike");
    public static final DeferredHolder<SoundEvent, SoundEvent> SUN_CALL = reg("sun_call");
    public static final DeferredHolder<SoundEvent, SoundEvent> TRANSFORM_LINTANG = reg("transform_lintang");
    public static final DeferredHolder<SoundEvent, SoundEvent> LINTANG_RITE = reg("lintang_rite");
    public static final DeferredHolder<SoundEvent, SoundEvent> KELAM_HUM = reg("kelam_hum");
    public static final DeferredHolder<SoundEvent, SoundEvent> FROST_PARRY = reg("frost_parry");
    public static final DeferredHolder<SoundEvent, SoundEvent> SUPER_BREATH = reg("super_breath");
    public static final DeferredHolder<SoundEvent, SoundEvent> SOLAR_NOVA = reg("solar_nova");
    public static final DeferredHolder<SoundEvent, SoundEvent> HERO_LAND = reg("hero_land");
    public static final DeferredHolder<SoundEvent, SoundEvent> LASER_CHARGE = reg("laser_charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> LASER_FIRE = reg("laser_fire");
    public static final DeferredHolder<SoundEvent, SoundEvent> LASER_LOOP = reg("laser_loop");
    public static final DeferredHolder<SoundEvent, SoundEvent> BLITZ_STOP = reg("blitz_stop");
    public static final DeferredHolder<SoundEvent, SoundEvent> BLITZ_RESUME = reg("blitz_resume");
    public static final DeferredHolder<SoundEvent, SoundEvent> SUN_FORM = reg("sun_form");
    public static final DeferredHolder<SoundEvent, SoundEvent> SUN_LOOP = reg("sun_loop");

    // ------------------------------------------------ 0.43 Projek Helion-6 (radiasi Cryon, lemah di bawah matahari)
    // HELION_TRANSFORM panjangnya PERSIS HELION_SUITUP (0,8 dtk) dan memuncak di tick kostum terbentuk; HELION_BEAM_CHARGE
    // PERSIS HELION_EYES_WINDUP (0,5 dtk); HELION_QUAKE meledak di 0,6 dtk (= HELION_QUAKE_WINDUP), HELION_NOVA di 3 dtk
    // (= HELION_NOVA_WINDUP), HELION_INHALE melonjak di 0,9 dtk, HELION_RITE meledak di 5,6 dtk. Putar di pitch 1.
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_TRANSFORM = reg("helion_transform");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_BURST = reg("helion_burst");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_PULSE = reg("helion_pulse");
    public static final DeferredHolder<SoundEvent, SoundEvent> GEIGER = reg("geiger");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_DASH = reg("helion_dash");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_BEAM_CHARGE = reg("helion_beam_charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_BEAM_FIRE = reg("helion_beam_fire");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_BEAM_LOOP = reg("helion_beam_loop");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_QUAKE = reg("helion_quake");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_NOVA = reg("helion_nova");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_INHALE = reg("helion_inhale");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_SUN_BURN = reg("helion_sun_burn");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_PUNCH = reg("helion_punch");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_CRYON_PUNCH = reg("helion_cryon_punch");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_RITE = reg("helion_rite");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_POWER_DOWN = reg("helion_power_down");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_LAHAP = reg("helion_lahap");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_ORBIT = reg("helion_orbit");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_SHARD = reg("helion_shard");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_NISAN = reg("helion_nisan");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_TOMB_SHATTER = reg("helion_tomb_shatter");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION_ECLIPSE = reg("helion_eclipse");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_ROAR = reg("helion3_roar");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_STEP = reg("helion3_step");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_SMASH = reg("helion3_smash");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_SLAM = reg("helion3_slam");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_CHARGE = reg("helion3_charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_ADAPT = reg("helion3_adapt");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_ABSORB = reg("helion3_absorb");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_FALL = reg("helion3_fall");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_REVIVE = reg("helion3_revive");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_DEATH = reg("helion3_death");
    public static final DeferredHolder<SoundEvent, SoundEvent> HELION3_EMERGE = reg("helion3_emerge");

    // ------------------------------------------------ 0.51 PRALAYA, Sang Mesin Kiamat (mekanis & digital)
    // Puncaknya dikunci ke tick ShazamAnim.AKSARA_* (lihat tools/sfx/aksara_sfx.py): TRANSFORM 2,2 dtk, NOVA 1,1, PURNA 1,7,
    // ERASE 3,2, RITE 7,5, SOUL 2,4, TIMESTOP 0,6. Putar di pitch 1 supaya puncaknya nggak bergeser. Kecuali AKSARA_CORE
    // (0.52, inti daya menyala): diputar dengan pitch per inti, jadi keenam inti berurutan jadi akor.
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_TRANSFORM = reg("aksara_transform");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_REVERT = reg("aksara_revert");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_PULSE = reg("aksara_pulse");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_PUNCH = reg("aksara_punch");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_SIXFOLD = reg("aksara_sixfold");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_BEAM = reg("aksara_beam");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_NOVA = reg("aksara_nova");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_FOLD = reg("aksara_fold");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_GATE = reg("aksara_gate");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_LANCE = reg("aksara_lance");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_DOMINION = reg("aksara_dominion");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_REWRITE = reg("aksara_rewrite");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_VEIL = reg("aksara_veil");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_TIMESTOP = reg("aksara_timestop");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_TIMERESUME = reg("aksara_timeresume");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_REWIND = reg("aksara_rewind");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_SOUL = reg("aksara_soul");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_WARD = reg("aksara_ward");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_PURNA = reg("aksara_purna");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_ERASE = reg("aksara_erase");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_DISC = reg("aksara_disc");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_SHIELD = reg("aksara_shield");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_STEP = reg("aksara_step");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_RITE = reg("aksara_rite");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_PARRY = reg("aksara_parry");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_CORE = reg("aksara_core");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_WORLDSTOP = reg("aksara_worldstop");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_WORLDRESUME = reg("aksara_worldresume");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_CLOCKTICK = reg("aksara_clocktick");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_RUIN = reg("aksara_ruin");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_PSYBURST = reg("aksara_psyburst");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_SOULBURST = reg("aksara_soulburst");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_DRILL = reg("aksara_drill");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_SLAM = reg("aksara_slam");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_SKYSPEAR = reg("aksara_skyspear");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_GRAVITY = reg("aksara_gravity");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_IMPLODE = reg("aksara_implode");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_NEURAL = reg("aksara_neural");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_SPIKES = reg("aksara_spikes");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_ECHO = reg("aksara_echo");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_TETHER = reg("aksara_tether");
    public static final DeferredHolder<SoundEvent, SoundEvent> AKSARA_SEMADI = reg("aksara_semadi");

    // ------------------------------------------------ 0.63 THANOS (fan-made, tools/sfx/thanos_sfx.py)
    // Puncaknya dikunci ke ShazamAnim.TITAN_* (lihat docstring thanos_sfx.py): putar di pitch 1, kecuali METEOR & DUST.
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_BIND = reg("thanos_bind");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_TRANSFORM = reg("thanos_transform");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_REVERT = reg("thanos_revert");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_STONE_FOUND = reg("thanos_stone_found");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_POWER_PUNCH = reg("thanos_power_punch");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_POWER_NOVA = reg("thanos_power_nova");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_SPACE_STEP = reg("thanos_space_step");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_MOON_RIFT = reg("thanos_moon_rift");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_METEOR = reg("thanos_meteor");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_MIND = reg("thanos_mind");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_MINDSTORM = reg("thanos_mindstorm");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_REALITY_WRAP = reg("thanos_reality_wrap");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_REALITY_BURST = reg("thanos_reality_burst");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_REALITY_STORM = reg("thanos_reality_storm");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_REWIND = reg("thanos_rewind");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_TIMESTOP = reg("thanos_timestop");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_SOUL_HARVEST = reg("thanos_soul_harvest");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_SOUL_SHIELD = reg("thanos_soul_shield");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_SNAP_CHARGE = reg("thanos_snap_charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_SNAP = reg("thanos_snap");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_DUST = reg("thanos_dust");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_RAGE = reg("thanos_rage");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_SPIN = reg("thanos_spin");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_THROW = reg("thanos_throw");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_SLAM = reg("thanos_slam");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_LEAP = reg("thanos_leap");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_PARRY = reg("thanos_parry");
    public static final DeferredHolder<SoundEvent, SoundEvent> THANOS_SIGNAL = reg("thanos_signal");

    // ------------------------------------------------ 0.64 Kuasa Infinity (Thanos & PRALAYA, tools/sfx/infinity_sfx.py)
    public static final DeferredHolder<SoundEvent, SoundEvent> INFINITY_SURGE = reg("infinity_surge");
    public static final DeferredHolder<SoundEvent, SoundEvent> INFINITY_CRATER_CHARGE = reg("infinity_crater_charge");
    public static final DeferredHolder<SoundEvent, SoundEvent> INFINITY_CRATER = reg("infinity_crater");
    public static final DeferredHolder<SoundEvent, SoundEvent> INFINITY_PORTAL_OPEN = reg("infinity_portal_open");
    public static final DeferredHolder<SoundEvent, SoundEvent> INFINITY_PORTAL_CLOSE = reg("infinity_portal_close");
    public static final DeferredHolder<SoundEvent, SoundEvent> INFINITY_REWRITE = reg("infinity_rewrite");
    public static final DeferredHolder<SoundEvent, SoundEvent> INFINITY_REWRITE_END = reg("infinity_rewrite_end");
    public static final DeferredHolder<SoundEvent, SoundEvent> INFINITY_RAISE = reg("infinity_raise");
    public static final DeferredHolder<SoundEvent, SoundEvent> INFINITY_CRUMBLE = reg("infinity_crumble");

    // ------------------------------------------------ 0.66 RELATIVA (orisinal, fisika Einstein, tools/sfx/relativa_sfx.py)
    // Puncaknya dikunci ke tick ShazamAnim.REL_* (20 tick = 1 dtk): TRANSFORM 1,3 dtk, RITE 7,0, DILATION 0,5, WARP hempasan
    // di 2,0, BLACKHOLE 0,9, EMC 1,3, ANNIHILATE 0,8, UNIFIED 3,2, BEC 0,7, LASER menyala di 0,5, GWAVE 0,4. Putar di pitch 1.
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_RITE = reg("relativa_rite");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_TRANSFORM = reg("relativa_transform");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_REVERT = reg("relativa_revert");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_PAPER = reg("relativa_paper");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_DASH = reg("relativa_dash");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_DILATION = reg("relativa_dilation");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_WARP = reg("relativa_warp");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_BLACKHOLE = reg("relativa_blackhole");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_BLACKHOLE_HUM = reg("relativa_blackhole_hum");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_HAWKING = reg("relativa_hawking");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_TUNNEL = reg("relativa_tunnel");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_ENTANGLE = reg("relativa_entangle");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_ENTANGLE_PULSE = reg("relativa_entangle_pulse");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_NEUTRON = reg("relativa_neutron");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_FISSION = reg("relativa_fission");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_CRITICAL = reg("relativa_critical");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_NUKE = reg("relativa_nuke");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_GEIGER = reg("relativa_geiger");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_FUSION = reg("relativa_fusion");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_FUSION_BOOM = reg("relativa_fusion_boom");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_TOKAMAK = reg("relativa_tokamak");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_DISRUPT = reg("relativa_disrupt");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_EMC = reg("relativa_emc");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_EMC_BOOM = reg("relativa_emc_boom");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_ANNIHILATE = reg("relativa_annihilate");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_UNIFIED = reg("relativa_unified");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_BEC = reg("relativa_bec");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_PHOTON = reg("relativa_photon");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_ARC = reg("relativa_arc");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_LASER = reg("relativa_laser");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_GWAVE = reg("relativa_gwave");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_BROWN = reg("relativa_brown");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_DODGE = reg("relativa_dodge");
    public static final DeferredHolder<SoundEvent, SoundEvent> RELATIVA_PUNCH = reg("relativa_punch");

    private static DeferredHolder<SoundEvent, SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(ShazamMod.id(name)));
    }

    // ======= Angka yang gampang diutak-atik =======
    /** Seberapa jauh nada SFX ikut angka pitch di kode (1 = penuh, 0 = selalu nada asli). Nada ke bawah dibiarkan
     *  lebih bebas supaya slow motion tetap terdengar berat. */
    private static final float PITCH_UP_FOLLOW = 0.4f;
    private static final float PITCH_DOWN_FOLLOW = 0.6f;

    /**
     * Angka pitch lama disetel untuk suara bawaan Minecraft (misalnya 0.4 supaya guntur vanila terdengar berat,
     * atau 1.9 supaya terdengar kecil). SFX baru sudah dibuat dengan nada yang pas, jadi angkanya dijinakkan
     * supaya suaranya nggak jadi melar atau cempreng.
     */
    public static float tune(float pitch) {
        float p = pitch < 1f ? 1f - (1f - pitch) * PITCH_DOWN_FOLLOW : 1f + (pitch - 1f) * PITCH_UP_FOLLOW;
        return Mth.clamp(p, 0.55f, 1.6f);
    }
}
