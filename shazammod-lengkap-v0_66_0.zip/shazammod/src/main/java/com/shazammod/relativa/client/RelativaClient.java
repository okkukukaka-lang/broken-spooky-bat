package com.shazammod.relativa.client;

import org.lwjgl.glfw.GLFW;

import com.shazammod.ShazamMod;
import com.shazammod.client.fx.RelativaFx;
import com.shazammod.client.fx.RelativaLensShader;
import com.shazammod.relativa.RelativaClientState;
import com.shazammod.relativa.RelativaNetwork;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 0.66 Khusus client: tombol Y (Wujud RELATIVA), HUD, tick efek RelativaFx, dan shader lensa gravitasi. Tombol lain
 * (G Z X C V B N R M J) memakai tombol juara yang sudah ada di ShazamClient.
 */
public final class RelativaClient {
    private RelativaClient() {}

    public static final KeyMapping TRANSFORM = new KeyMapping("key.shazammod.relativa", GLFW.GLFW_KEY_Y,
            "key.categories.shazammod");

    @EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModEvents {
        private ModEvents() {}

        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(TRANSFORM);
        }

        @SubscribeEvent
        public static void registerHud(RegisterGuiLayersEvent event) {
            event.registerAbove(VanillaGuiLayers.HOTBAR, ShazamMod.id("relativa_hud"), RelativaHud::render);
        }
    }

    @EventBusSubscriber(modid = ShazamMod.MODID, value = Dist.CLIENT)
    public static final class GameEvents {
        private GameEvents() {}

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) {
                return;
            }
            while (TRANSFORM.consumeClick()) {
                PacketDistributor.sendToServer(new RelativaNetwork.ActionPayload(RelativaNetwork.ACTION_TRANSFORM));
            }
            if (!mc.isPaused()) {
                RelativaFx.tick(mc.level);   // atom di dada, kisi ruang-waktu, medan-medan yang menempel di badan
            }
        }

        /** Lensa gravitasi lubang hitam & aberasi Lesat Cahaya: paling akhir, sesudah semua yang digambar di dunia. */
        @SubscribeEvent(priority = EventPriority.LOWEST)
        public static void onRenderLevelLast(RenderLevelStageEvent event) {
            RelativaLensShader.render(event);
        }

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
            RelativaClientState.reset();
            RelativaFx.clear();
            RelativaLensShader.close();
        }
    }
}
