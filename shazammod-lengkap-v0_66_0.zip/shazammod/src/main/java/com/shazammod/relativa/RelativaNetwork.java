package com.shazammod.relativa;

import java.util.ArrayList;
import java.util.List;

import com.shazammod.ShazamMod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * 0.66 Paket RELATIVA. Tombol Z X C V B N R M J G memakai paket juara yang sudah ada (ShazamNetwork.handleAction ->
 * RelativaAbilities.handleSharedKey); di sini: tombol Y, data HUD pemain sendiri, dan status RELATIVA yang dilihat pemain
 * lain (atom di dada, medan dilatasi, tokamak).
 */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class RelativaNetwork {
    private RelativaNetwork() {}

    public static final int ACTION_TRANSFORM = 0;

    public static final int FLAG_DILATION = 1, FLAG_TOKAMAK = 2, FLAG_HOLE = 4;

    /** Client -> server: tombol Y. */
    public record ActionPayload(int action) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<ActionPayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("relativa_action"));

        public static final StreamCodec<ByteBuf, ActionPayload> STREAM_CODEC =
                ByteBufCodecs.VAR_INT.map(ActionPayload::new, ActionPayload::action);

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> client: data HUD pemain itu sendiri. */
    public record SyncPayload(boolean unlocked, boolean transformed, float energy, int papers, int dilationTicks,
                              int tokamakTicks, int entangleTicks, int holeTicks, List<Integer> cooldowns)
            implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<SyncPayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("relativa_sync"));

        public static final StreamCodec<ByteBuf, SyncPayload> STREAM_CODEC = StreamCodec.of(
                (buf, p) -> {
                    ByteBufCodecs.BOOL.encode(buf, p.unlocked());
                    ByteBufCodecs.BOOL.encode(buf, p.transformed());
                    ByteBufCodecs.FLOAT.encode(buf, p.energy());
                    ByteBufCodecs.VAR_INT.encode(buf, p.papers());
                    ByteBufCodecs.VAR_INT.encode(buf, p.dilationTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.tokamakTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.entangleTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.holeTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.cooldowns().size());
                    for (int c : p.cooldowns()) {
                        ByteBufCodecs.VAR_INT.encode(buf, c);
                    }
                },
                buf -> {
                    boolean unlocked = ByteBufCodecs.BOOL.decode(buf);
                    boolean transformed = ByteBufCodecs.BOOL.decode(buf);
                    float energy = ByteBufCodecs.FLOAT.decode(buf);
                    int papers = ByteBufCodecs.VAR_INT.decode(buf);
                    int dilation = ByteBufCodecs.VAR_INT.decode(buf);
                    int tokamak = ByteBufCodecs.VAR_INT.decode(buf);
                    int entangle = ByteBufCodecs.VAR_INT.decode(buf);
                    int hole = ByteBufCodecs.VAR_INT.decode(buf);
                    int n = Math.min(ByteBufCodecs.VAR_INT.decode(buf), 64);
                    List<Integer> cooldowns = new ArrayList<>(n);
                    for (int i = 0; i < n; i++) {
                        cooldowns.add(ByteBufCodecs.VAR_INT.decode(buf));
                    }
                    return new SyncPayload(unlocked, transformed, energy, papers, dilation, tokamak, entangle, hole, cooldowns);
                });

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> pemain di sekitar: siapa yang sedang jadi RELATIVA (atom di dada) dan medan apa yang menyala. */
    public record StatePayload(int entityId, boolean transformed, int flags) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<StatePayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("relativa_state"));

        public static final StreamCodec<ByteBuf, StatePayload> STREAM_CODEC = StreamCodec.of(
                (buf, p) -> {
                    ByteBufCodecs.VAR_INT.encode(buf, p.entityId());
                    ByteBufCodecs.BOOL.encode(buf, p.transformed());
                    ByteBufCodecs.VAR_INT.encode(buf, p.flags());
                },
                buf -> new StatePayload(ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.BOOL.decode(buf),
                        ByteBufCodecs.VAR_INT.decode(buf)));

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(ActionPayload.TYPE, ActionPayload.STREAM_CODEC, RelativaNetwork::handleAction);
        registrar.playToClient(SyncPayload.TYPE, SyncPayload.STREAM_CODEC, RelativaNetwork::handleSync);
        registrar.playToClient(StatePayload.TYPE, StatePayload.STREAM_CODEC, RelativaNetwork::handleState);
    }

    private static void handleAction(ActionPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player && payload.action() == ACTION_TRANSFORM) {
                RelativaAbilities.toggleTransform(player);
            }
        });
    }

    private static void handleSync(SyncPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> RelativaClientState.update(payload));
    }

    private static void handleState(StatePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> RelativaClientState.onState(payload));
    }

    public static void sync(ServerPlayer player) {
        RelativaData d = RelativaAbilities.data(player);
        List<Integer> cooldowns = new ArrayList<>(RelativaData.SLOTS);
        for (int c : d.cooldowns) {
            cooldowns.add(c);
        }
        PacketDistributor.sendToPlayer(player, new SyncPayload(d.unlocked, d.transformed, d.energy, d.papers,
                d.dilationTicks, d.tokamakTicks, d.entangleTicks, d.holeTicks, cooldowns));
    }

    private static StatePayload state(ServerPlayer player) {
        RelativaData d = RelativaAbilities.data(player);
        int flags = (d.dilationTicks > 0 ? FLAG_DILATION : 0) | (d.tokamakTicks > 0 ? FLAG_TOKAMAK : 0)
                | (d.holeTicks > 0 ? FLAG_HOLE : 0);
        return new StatePayload(player.getId(), d.transformed, flags);
    }

    /** Status RELATIVA pemain ini ke dirinya sendiri & semua yang melihatnya. */
    public static void broadcastState(ServerPlayer player) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, state(player));
    }

    /** Pemain baru melihat pemain ini (masuk jangkauan): kirim statusnya. */
    public static void sendStateTo(ServerPlayer relativa, ServerPlayer viewer) {
        PacketDistributor.sendToPlayer(viewer, state(relativa));
    }
}
