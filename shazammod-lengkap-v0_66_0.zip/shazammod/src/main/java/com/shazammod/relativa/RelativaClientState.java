package com.shazammod.relativa;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 0.66 Status RELATIVA di sisi client: data HUD pemain ini sendiri, dan siapa saja di sekitar yang sedang jadi RELATIVA
 * (buat atom di dada & medan-medannya). Cuma field biasa tanpa kelas client, jadi aman ikut termuat di server dedicated.
 */
public final class RelativaClientState {
    private RelativaClientState() {}

    public static boolean unlocked;
    public static boolean transformed;
    public static float energy = RelativaData.MAX_ENERGY;
    public static int papers;
    public static int dilationTicks;
    public static int tokamakTicks;
    public static int entangleTicks;
    public static int holeTicks;
    private static List<Integer> cooldowns = List.of();

    /** Pemain yang sedang jadi RELATIVA (termasuk diri sendiri): id entity -> bendera medan (RelativaNetwork.FLAG_*). */
    private static final Map<Integer, Integer> OTHERS = new HashMap<>();

    public static void update(RelativaNetwork.SyncPayload p) {
        unlocked = p.unlocked();
        transformed = p.transformed();
        energy = p.energy();
        papers = p.papers();
        dilationTicks = p.dilationTicks();
        tokamakTicks = p.tokamakTicks();
        entangleTicks = p.entangleTicks();
        holeTicks = p.holeTicks();
        cooldowns = p.cooldowns();
    }

    public static void onState(RelativaNetwork.StatePayload p) {
        if (p.transformed()) {
            OTHERS.put(p.entityId(), p.flags());
        } else {
            OTHERS.remove(p.entityId());
        }
    }

    public static boolean isRelativa(int entityId) {
        return OTHERS.containsKey(entityId);
    }

    public static int flags(int entityId) {
        Integer f = OTHERS.get(entityId);
        return f == null ? 0 : f;
    }

    public static Map<Integer, Integer> all() {
        return OTHERS;
    }

    public static int cooldown(int slot) {
        return slot >= 0 && slot < cooldowns.size() ? cooldowns.get(slot) : 0;
    }

    public static void reset() {
        unlocked = false;
        transformed = false;
        energy = RelativaData.MAX_ENERGY;
        papers = 0;
        dilationTicks = 0;
        tokamakTicks = 0;
        entangleTicks = 0;
        holeTicks = 0;
        cooldowns = List.of();
        OTHERS.clear();
    }
}
