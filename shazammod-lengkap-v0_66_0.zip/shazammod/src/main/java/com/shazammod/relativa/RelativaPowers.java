package com.shazammod.relativa;

import com.shazammod.ShazamMod;

import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

/**
 * 0.66 Stat wujud RELATIVA (modifier atribut sementara, dipasang ulang saat login). Lebih gesit dari Thanos, lebih tipis
 * armornya: kekuatannya dari fisika, bukan dari otot.
 */
public final class RelativaPowers {
    private RelativaPowers() {}

    // ======= Angka yang gampang diutak-atik =======
    public static final double HEALTH = 30.0;         // darah tambahan (2 = 1 hati)
    public static final double ARMOR = 10.0;
    public static final double TOUGHNESS = 6.0;
    public static final double DAMAGE = 6.0;
    public static final double KNOCKBACK = 0.6;
    public static final double SPEED = 0.25;          // +25% kecepatan jalan
    public static final double JUMP = 0.12;
    public static final double SAFE_FALL = 10.0;

    private static final AttributeModifier.Operation ADD = AttributeModifier.Operation.ADD_VALUE;

    public static void apply(Player p) {
        set(p, Attributes.MAX_HEALTH, "health", HEALTH, ADD);
        set(p, Attributes.ARMOR, "armor", ARMOR, ADD);
        set(p, Attributes.ARMOR_TOUGHNESS, "toughness", TOUGHNESS, ADD);
        set(p, Attributes.ATTACK_DAMAGE, "damage", DAMAGE, ADD);
        set(p, Attributes.KNOCKBACK_RESISTANCE, "knockback", KNOCKBACK, ADD);
        set(p, Attributes.MOVEMENT_SPEED, "speed", SPEED, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        set(p, Attributes.JUMP_STRENGTH, "jump", JUMP, ADD);
        set(p, Attributes.STEP_HEIGHT, "step", 0.5, ADD);
        set(p, Attributes.SAFE_FALL_DISTANCE, "fall", SAFE_FALL, ADD);
    }

    public static void remove(Player p) {
        clear(p, Attributes.MAX_HEALTH, "health");
        clear(p, Attributes.ARMOR, "armor");
        clear(p, Attributes.ARMOR_TOUGHNESS, "toughness");
        clear(p, Attributes.ATTACK_DAMAGE, "damage");
        clear(p, Attributes.KNOCKBACK_RESISTANCE, "knockback");
        clear(p, Attributes.MOVEMENT_SPEED, "speed");
        clear(p, Attributes.JUMP_STRENGTH, "jump");
        clear(p, Attributes.STEP_HEIGHT, "step");
        clear(p, Attributes.SAFE_FALL_DISTANCE, "fall");
        if (p.getHealth() > p.getMaxHealth()) {
            p.setHealth(p.getMaxHealth());
        }
    }

    private static ResourceLocation id(String name) {
        return ShazamMod.id("relativa_" + name);
    }

    private static void set(Player p, Holder<Attribute> attribute, String name, double amount, AttributeModifier.Operation op) {
        AttributeInstance instance = p.getAttribute(attribute);
        if (instance != null) {
            instance.removeModifier(id(name));
            if (amount != 0.0) {
                instance.addTransientModifier(new AttributeModifier(id(name), amount, op));
            }
        }
    }

    private static void clear(Player p, Holder<Attribute> attribute, String name) {
        AttributeInstance instance = p.getAttribute(attribute);
        if (instance != null) {
            instance.removeModifier(id(name));
        }
    }
}
