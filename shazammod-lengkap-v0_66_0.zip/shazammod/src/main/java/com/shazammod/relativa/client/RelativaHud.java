package com.shazammod.relativa.client;

import com.shazammod.relativa.RelativaClientState;
import com.shazammod.relativa.RelativaData;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * 0.66 HUD RELATIVA, di KIRI hotbar (HUD Thanos di kanan, HUD juara di kiri atas, jadi nggak bertabrakan):
 *
 *   medan yang menyala (Dilatasi Waktu, Lubang Hitam, Keterikatan, Tokamak: sisa detik)
 *   sembilan kotak Z X C V B N R M J berwarna ranah fisikanya: redup = kuasa normal cooldown, garis di bawahnya = kuasa
 *   Shift cooldown
 *   bar Energi "E = mc²" (emas saat penuh)
 *
 * Wujud manusia: kemajuan empat makalah Jurnal Annus Mirabilis, atau pengingat tombol Y.
 */
public final class RelativaHud {
    private RelativaHud() {}

    private static final int BOX = 11, GAP = 2, KEYS = 9;
    private static final String[] LABEL = {"Z", "X", "C", "V", "B", "N", "R", "M", "J"};
    /** Warna ranah: relativitas khusus, gravitasi, kuantum, fisi, fusi, E=mc², medan terpadu, foton, gelombang gravitasi. */
    public static final int[] COLOR = {0x8FD8FF, 0x9A6BFF, 0x5CFFE1, 0x7CFF5A, 0xFF7AD9, 0xFFD34D, 0xFFFFFF, 0xFFF07A, 0xB28CFF};
    private static final int[] NORMAL = {0, 1, 2, 3, 4, 5, RelativaData.SLOT_R, RelativaData.SLOT_M, RelativaData.SLOT_J};
    private static final int[] SHIFT = {6, 7, 8, 9, 10, 11, RelativaData.SLOT_R_SHIFT, RelativaData.SLOT_M_SHIFT,
            RelativaData.SLOT_J_SHIFT};
    private static final int SHADE = 0xA0000000, EDGE = 0xFF4A5468;
    private static final int ENERGY = 0xFF5CE1FF, ENERGY_FULL = 0xFFFFD34D;

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null) {
            return;
        }
        Font font = mc.font;
        int width = KEYS * BOX + (KEYS - 1) * GAP;
        int x = g.guiWidth() / 2 - 91 - 32 - width;   // kiri hotbar, lewat slot tangan kiri
        int bottom = g.guiHeight();
        if (x < 4) {   // layar sempit: naik sedikit supaya nggak menutupi slot tangan kiri
            x = 4;
            bottom -= 24;
        }
        if (!RelativaClientState.unlocked) {
            if (RelativaClientState.papers != 0) {
                int n = Integer.bitCount(RelativaClientState.papers);
                Component line = Component.translatable(n >= RelativaData.PAPERS ? "hud.shazammod.relativa.papers_done"
                        : "hud.shazammod.relativa.papers", n, RelativaData.PAPERS);
                g.drawString(font, line, x, bottom - 18, n >= RelativaData.PAPERS ? 0xFFFFD34D : 0xFF8FD8FF);
            }
            return;
        }
        if (!RelativaClientState.transformed) {
            g.drawString(font, Component.translatable("hud.shazammod.relativa.human"), x, bottom - 18, 0xFF8FA8C8);
            return;
        }

        // sembilan kotak
        int boxY = bottom - 30;
        for (int k = 0; k < KEYS; k++) {
            int bx = x + k * (BOX + GAP);
            int rgb = 0xFF000000 | COLOR[k];
            int cd = RelativaClientState.cooldown(NORMAL[k]);
            int cdShift = RelativaClientState.cooldown(SHIFT[k]);
            g.fill(bx - 1, boxY - 1, bx + BOX + 1, boxY + BOX + 1, EDGE);
            g.fill(bx, boxY, bx + BOX, boxY + BOX, rgb);
            if (cd > 0) {
                g.fill(bx, boxY, bx + BOX, boxY + BOX, 0xB0000000);
            }
            g.fill(bx, boxY + BOX + 2, bx + BOX, boxY + BOX + 4, cdShift > 0 ? 0xFF2E3440 : rgb);
            g.drawString(font, LABEL[k], bx + 3, boxY + 2, cd > 0 ? 0xFF888888 : 0xFF101018, false);
        }

        // medan yang menyala
        StringBuilder status = new StringBuilder();
        if (RelativaClientState.holeTicks > 0) {
            status.append("● ").append(seconds(RelativaClientState.holeTicks)).append("  ");
        }
        if (RelativaClientState.dilationTicks > 0) {
            status.append("⌛ ").append(seconds(RelativaClientState.dilationTicks)).append("  ");
        }
        if (RelativaClientState.entangleTicks > 0) {
            status.append("ψψ ").append(seconds(RelativaClientState.entangleTicks)).append("  ");
        }
        if (RelativaClientState.tokamakTicks > 0) {
            status.append("◎ ").append(seconds(RelativaClientState.tokamakTicks));
        }
        if (!status.isEmpty()) {
            g.drawString(font, status.toString().trim(), x, boxY - 11, 0xFFB8E8FF);
        }

        // energi
        int barY = bottom - 8;
        float energy = RelativaClientState.energy;
        g.fill(x - 1, barY - 1, x + width + 1, barY + 4, SHADE);
        g.fill(x, barY, x + Math.round(width * energy / RelativaData.MAX_ENERGY), barY + 3,
                energy >= RelativaData.MAX_ENERGY ? ENERGY_FULL : ENERGY);
        String label = "E " + Math.round(energy);
        int lx = x - font.width(label) - 4;
        g.drawString(font, label, lx >= 2 ? lx : x + width + 4, barY - 3, 0xFFB8E8FF);
    }

    private static String seconds(int ticks) {
        int s = (ticks + 19) / 20;
        return s >= 60 ? (s / 60) + ":" + String.format("%02d", s % 60) : s + "s";
    }
}
