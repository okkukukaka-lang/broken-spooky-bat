package com.shazammod.relativa;

import java.util.Locale;

import com.shazammod.ShazamMod;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.ServerChatEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** 0.66 Event RELATIVA di server. */
@EventBusSubscriber(modid = ShazamMod.MODID)
public final class RelativaEvents {
    private RelativaEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            RelativaAbilities.tick(player);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            RelativaAbilities.onLogin(player);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            RelativaAbilities.onRespawn(player);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            RelativaAbilities.onLogout(player);
        }
    }

    /** Pemain lain masuk jangkauan pandang: kirim status RELATIVA-nya (atom di dada & medan). */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer relativa && event.getEntity() instanceof ServerPlayer viewer
                && RelativaAbilities.active(relativa)) {
            RelativaNetwork.sendStateTo(relativa, viewer);
        }
    }

    /** Tinju Foton, Superposisi, Makalah IV (ledakan). */
    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        RelativaAbilities.guard(event);
    }

    /** Keterikatan Kuantum: damage yang benar-benar masuk ke satu makhluk mengalir ke pasangannya. */
    @SubscribeEvent
    public static void onDamagePost(LivingDamageEvent.Post event) {
        RelativaSkills.onDamagePost(event);
    }

    /** Ketik "relativa" atau "E=mc²" di chat = sama dengan tombol Y. */
    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        String word = event.getRawText().toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
        if (word.equals("relativa") || word.equals("emc")) {
            ServerPlayer player = event.getPlayer();
            player.server.execute(() -> RelativaAbilities.toggleTransform(player));
        }
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        RelativaCommands.register(event.getDispatcher());
    }
}
