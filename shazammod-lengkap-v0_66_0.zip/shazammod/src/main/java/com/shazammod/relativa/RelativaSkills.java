package com.shazammod.relativa;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;
import com.shazammod.infinity.InfinityWorld;
import com.shazammod.thanos.entity.ThrownDoubleBlade;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;

/**
 * 0.66 Kuasa RELATIVA: 18 skill, semuanya fisika Einstein (dan yang lahir dari teorinya). Tick puncak tiap skill =
 * konstanta ShazamAnim.REL_* (klip RelativaClips, efek RelativaFx, dan SFX relativa_* dikunci ke angka yang sama).
 *
 *   Z  Relativitas Khusus  Lesat Cahaya (melesat 22 blok, menghantam yang dilewati)  | Shift: Dilatasi Waktu (medan 9 blok:
 *                          waktu musuh & proyektil melambat, waktumu normal)
 *   X  Relativitas Umum    Lengkung Ruang-Waktu (sumur gravitasi, lalu dihempas)     | Shift: LUBANG HITAM (menyedot makhluk,
 *                          proyektil & blok; menguap jadi ledakan radiasi Hawking)
 *   C  Kuantum             Terowongan Kuantum (menembus dinding)                     | Shift: Keterikatan Kuantum (8 musuh
 *                          terikat: damage ke satu mengalir ke semuanya)
 *   V  Fisi Nuklir         Fisi Berantai (neutron membelah inti, reaksi berantai)    | Shift: Massa Kritis (ledakan fisi +
 *                          awan jamur, kawah, radiasi sisa)
 *   B  Fusi Nuklir         Fusi Bintang (dua proton jadi bintang mini, dilempar)     | Shift: Tokamak (cincin plasma 10 dtk)
 *   N  E = mc²             Konversi massa sasaran jadi energi (damage ikut massanya) | Shift: Anihilasi (dua sinar gamma
 *                          berlawanan arah, menembus semua)
 *   R  Teori Medan Terpadu (keempat gaya menyatu, radius 22)                         | Shift: Kondensat Bose-Einstein
 *                          (nol mutlak: semua membeku 6 dtk, air jadi es)
 *   M  Efek Fotolistrik (rentetan foton, elektron terlepas melompat)                 | Shift: Laser (emisi terstimulasi)
 *   J  Gelombang Gravitasi (riak ruang-waktu meregang & memampat)                    | Shift: Gerak Brown (melompat acak)
 *
 * Perubahan blok (Lubang Hitam, kawah Massa Kritis, air beku) ikut /gamerule mobGriefing.
 */
public final class RelativaSkills {
    private RelativaSkills() {}

    // ======= Angka yang gampang diutak-atik =======
    /** Pengali semua damage skill RELATIVA (1 = biasa). */
    public static final float SKILL_DAMAGE = 1.0f;
    // energi & cooldown (detik): {normal, shift} untuk Z..N
    private static final float[][] COST = {{12, 30}, {20, 45}, {14, 25}, {18, 50}, {16, 35}, {28, 26}};
    private static final int[][] COOLDOWN = {{3, 22}, {9, 35}, {5, 18}, {7, 40}, {5, 26}, {12, 14}};
    private static final float UNIFIED_COST = 80f, BEC_COST = 45f, PHOTO_COST = 10f, LASER_COST = 30f, GWAVE_COST = 18f,
            BROWN_COST = 15f;
    private static final int UNIFIED_CD = 75, BEC_CD = 40, PHOTO_CD = 4, LASER_CD = 16, GWAVE_CD = 8, BROWN_CD = 10;
    private static final double DASH_RANGE = 22.0;
    private static final double DILATION_RADIUS = 9.0;
    private static final double HOLE_PULL = 16.0;
    private static final int HOLE_EAT_PER_TICK = 5;
    private static final double TUNNEL_RANGE = 24.0;
    private static final int ENTANGLE_MAX = 8;
    private static final float ENTANGLE_SHARE = 0.6f;
    private static final double CRIT_RADIUS = 12.0;
    private static final int CRIT_CRATER = 6;
    private static final double TOKAMAK_RADIUS = 4.5;
    private static final float EMC_CAP = 60f;

    // ---------------------------------------------------------------- keadaan tiap pemain (nggak disimpan)

    private static final class Task {
        int delay;
        final Consumer<ServerPlayer> action;

        Task(int delay, Consumer<ServerPlayer> action) {
            this.delay = delay;
            this.action = action;
        }
    }

    private static final class Held {
        final LivingEntity entity;
        int ticks;

        Held(LivingEntity entity, int ticks) {
            this.entity = entity;
            this.ticks = ticks;
        }
    }

    private static final class State {
        int busy;
        final List<Task> tasks = new ArrayList<>();
        Vec3 lastPos;
        double speed;
        int dilation;
        final Set<Projectile> slowed = new HashSet<>();
        Vec3 warpAt;
        int warp;
        Vec3 holeAt;
        int hole, holeAge;
        final List<LivingEntity> entangled = new ArrayList<>();
        int entangle;
        int tokamak;
        int laser;
        final List<Held> frozen = new ArrayList<>();
        Vec3 radAt;
        int rad;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();
    private static boolean sharing;

    private static State state(ServerPlayer p) {
        return STATES.computeIfAbsent(p.getUUID(), id -> new State());
    }

    public static void clear(ServerPlayer p) {
        State s = STATES.remove(p.getUUID());
        if (s != null) {
            releaseSlowed(s);
        }
    }

    public static boolean free(ServerPlayer p) {
        State s = STATES.get(p.getUUID());
        return s == null || s.busy <= 0;
    }

    public static void busy(ServerPlayer p, int ticks) {
        State s = state(p);
        s.busy = Math.max(s.busy, ticks);
    }

    /** Jalankan action delay tick lagi (dibatalkan kalau pemainnya mati / keluar / kembali jadi manusia). */
    public static void later(ServerPlayer p, int delay, Consumer<ServerPlayer> action) {
        state(p).tasks.add(new Task(Math.max(1, delay), action));
    }

    /** Kecepatan gerak pemain (blok/tick, dihaluskan), dari perpindahan posisinya di server. */
    public static double trackMotion(ServerPlayer p) {
        State s = state(p);
        Vec3 now = p.position();
        if (s.lastPos != null) {
            double v = now.distanceTo(s.lastPos);
            s.speed = s.speed * 0.6 + (v > 12.0 ? 0.0 : v) * 0.4;   // teleport / ganti dimensi = bukan kecepatan
        }
        s.lastPos = now;
        return s.speed;
    }

    public static double speed(ServerPlayer p) {
        State s = STATES.get(p.getUUID());
        return s == null ? 0.0 : s.speed;
    }

    /** Kembali jadi manusia / mati: semua medan & kuasa yang sedang berjalan padam. Es & radiasi yang sudah ada tetap. */
    public static void endAll(ServerPlayer p, RelativaData d) {
        d.dilationTicks = 0;
        d.tokamakTicks = 0;
        d.entangleTicks = 0;
        d.holeTicks = 0;
        State s = STATES.get(p.getUUID());
        if (s == null) {
            return;
        }
        s.tasks.clear();
        s.busy = 0;
        s.dilation = 0;
        releaseSlowed(s);
        s.warp = 0;
        s.warpAt = null;
        s.hole = 0;
        s.holeAt = null;
        s.entangle = 0;
        s.entangled.clear();
        s.tokamak = 0;
        s.laser = 0;
    }

    // ---------------------------------------------------------------- tiap tick

    public static void tick(ServerPlayer p, RelativaData d) {
        State s = STATES.get(p.getUUID());
        if (s == null) {
            return;
        }
        if (s.busy > 0) {
            s.busy--;
        }
        if (!s.tasks.isEmpty()) {
            List<Task> due = new ArrayList<>();
            Iterator<Task> it = s.tasks.iterator();
            while (it.hasNext()) {
                Task t = it.next();
                if (--t.delay <= 0) {
                    due.add(t);
                    it.remove();
                }
            }
            for (Task t : due) {
                if (p.isAlive() && !p.isRemoved()) {
                    t.action.accept(p);
                }
            }
        }
        tickDilation(p, s, d);
        tickWarp(p, s);
        tickHole(p, s, d);
        tickEntangle(s, d);
        tickTokamak(p, s, d);
        tickLaser(p, s);
        tickFrozen(p, s);
        tickRadiation(p, s);
    }

    // ---------------------------------------------------------------- syarat

    private static boolean ready(ServerPlayer p, RelativaData d, int slot, float cost) {
        if (!free(p) || d.morphing > 0) {
            return false;
        }
        if (d.cooldowns[slot] > 0) {
            RelativaAbilities.msg(p, "cooldown", ChatFormatting.RED, (d.cooldowns[slot] + 19) / 20);
            return false;
        }
        if (!p.getAbilities().instabuild && d.energy < cost) {
            RelativaAbilities.msg(p, "no_energy", ChatFormatting.RED, Math.round(d.energy), Math.round(cost));
            return false;
        }
        return true;
    }

    private static void spend(ServerPlayer p, RelativaData d, int slot, float cost, int cooldownSec) {
        if (!p.getAbilities().instabuild) {
            d.energy = Math.max(0f, d.energy - cost);
        }
        d.cooldowns[slot] = cooldownSec * 20;
    }

    // ---------------------------------------------------------------- tombol

    /** Z..N (index 0-5), shift = kuasa kedua. */
    public static void key(ServerPlayer p, RelativaData d, int index, boolean shift) {
        if (index < 0 || index > 5) {
            return;
        }
        int slot = index + (shift ? RelativaData.SLOT_SHIFT : 0);
        float cost = COST[index][shift ? 1 : 0];
        if (!ready(p, d, slot, cost)) {
            return;
        }
        boolean ok = switch (index) {
            case 0 -> shift ? dilation(p) : dash(p);
            case 1 -> shift ? blackHole(p) : warp(p);
            case 2 -> shift ? entangle(p) : tunnel(p);
            case 3 -> shift ? critical(p) : fission(p);
            case 4 -> shift ? tokamak(p) : fusion(p);
            default -> shift ? annihilate(p) : emc(p);
        };
        if (ok) {
            spend(p, d, slot, cost, COOLDOWN[index][shift ? 1 : 0]);
        } else {
            RelativaAbilities.msg(p, "no_target", ChatFormatting.GRAY);
        }
    }

    /** R Teori Medan Terpadu / Shift+R Kondensat Bose-Einstein. */
    public static void ultimate(ServerPlayer p, RelativaData d, boolean shift) {
        if (shift) {
            if (ready(p, d, RelativaData.SLOT_R_SHIFT, BEC_COST)) {
                spend(p, d, RelativaData.SLOT_R_SHIFT, BEC_COST, BEC_CD);
                condensate(p);
            }
        } else if (ready(p, d, RelativaData.SLOT_R, UNIFIED_COST)) {
            spend(p, d, RelativaData.SLOT_R, UNIFIED_COST, UNIFIED_CD);
            unified(p);
        }
    }

    /** M Efek Fotolistrik / Shift+M Laser. */
    public static void light(ServerPlayer p, RelativaData d, boolean shift) {
        if (shift) {
            if (ready(p, d, RelativaData.SLOT_M_SHIFT, LASER_COST)) {
                spend(p, d, RelativaData.SLOT_M_SHIFT, LASER_COST, LASER_CD);
                laser(p);
            }
        } else if (ready(p, d, RelativaData.SLOT_M, PHOTO_COST)) {
            spend(p, d, RelativaData.SLOT_M, PHOTO_COST, PHOTO_CD);
            photo(p);
        }
    }

    /** J Gelombang Gravitasi / Shift+J Gerak Brown. */
    public static void wave(ServerPlayer p, RelativaData d, boolean shift) {
        if (shift) {
            if (ready(p, d, RelativaData.SLOT_J_SHIFT, BROWN_COST)) {
                spend(p, d, RelativaData.SLOT_J_SHIFT, BROWN_COST, BROWN_CD);
                brownian(p);
            }
        } else if (ready(p, d, RelativaData.SLOT_J, GWAVE_COST)) {
            spend(p, d, RelativaData.SLOT_J, GWAVE_COST, GWAVE_CD);
            gravityWave(p);
        }
    }

    // ================================================================ Z  Relativitas Khusus

    // Z  Lesat Cahaya: secepat cahaya, perjalanannya nyaris nol waktu; semua yang dilewati tersambar foton
    private static boolean dash(ServerPlayer p) {
        Vec3 dest = safeAim(p, DASH_RANGE);
        if (dest == null || dest.distanceTo(p.position()) < 2.0) {
            return false;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_DASH, dest);
        sound(p, p.position(), ShazamSounds.RELATIVA_DASH.get(), 1.6f);
        busy(p, ShazamAnim.REL_DASH_AT + 2);
        later(p, ShazamAnim.REL_DASH_AT, sp -> {
            if (!sp.level().noCollision(sp, sp.getBoundingBox().move(dest.subtract(sp.position())))) {
                return;
            }
            Vec3 from = sp.position();
            Vec3 dir = flat(dest.subtract(from));
            for (LivingEntity e : along(sp, from.add(0, 1.0, 0), dest.add(0, 1.0, 0), 1.8)) {
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 10f));
                e.push(dir.x * 1.1, 0.45, dir.z * 1.1);
                e.hurtMarked = true;
            }
            sp.teleportTo(dest.x, dest.y, dest.z);
            sp.resetFallDistance();
        });
        return true;
    }

    // Shift+Z  Dilatasi Waktu: t' = γt. Di dalam medan, waktu musuh & proyektil berjalan sangat lambat dilihat dari luar
    private static boolean dilation(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_DILATION);
        sound(p, p.position(), ShazamSounds.RELATIVA_DILATION.get(), 2.0f);
        busy(p, ShazamAnim.REL_DILATION_HIT + 4);
        later(p, ShazamAnim.REL_DILATION_HIT, sp -> {
            State s = state(sp);
            releaseSlowed(s);
            s.dilation = ShazamAnim.REL_DILATION_TICKS;
            RelativaAbilities.data(sp).dilationTicks = s.dilation;
            RelativaNetwork.broadcastState(sp);
        });
        return true;
    }

    private static void tickDilation(ServerPlayer p, State s, RelativaData d) {
        if (s.dilation <= 0) {
            return;
        }
        s.dilation--;
        d.dilationTicks = s.dilation;
        ServerLevel level = p.serverLevel();
        Vec3 c = p.position();
        AABB box = new AABB(c, c).inflate(DILATION_RADIUS);
        if (s.dilation % 5 == 0) {
            for (LivingEntity e : around(p, c, DILATION_RADIUS)) {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 12, 4, false, true), p);
                e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 12, 3, false, true), p);
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 12, 1, false, true), p);
            }
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 14, 1, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 14, 1, false, false));
        }
        for (Projectile pr : level.getEntitiesOfClass(Projectile.class, box, x -> x.getOwner() != p)) {
            if (pr.position().distanceTo(c) > DILATION_RADIUS) {
                continue;
            }
            if (s.slowed.add(pr)) {
                pr.setNoGravity(true);
            }
            Vec3 v = pr.getDeltaMovement();
            if (v.lengthSqr() > 0.0004) {
                pr.setDeltaMovement(v.scale(0.6));   // waktunya melambat: gerakannya merayap
                pr.hurtMarked = true;
            }
        }
        s.slowed.removeIf(pr -> {
            if (!pr.isAlive()) {
                return true;
            }
            if (pr.position().distanceTo(c) > DILATION_RADIUS + 1.0) {
                pr.setNoGravity(false);
                return true;
            }
            return false;
        });
        if (s.dilation == 0) {
            releaseSlowed(s);
            RelativaNetwork.broadcastState(p);
        }
    }

    private static void releaseSlowed(State s) {
        for (Projectile pr : s.slowed) {
            if (pr.isAlive()) {
                pr.setNoGravity(false);
            }
        }
        s.slowed.clear();
    }

    // ================================================================ X  Relativitas Umum

    // X  Lengkung Ruang-Waktu: massa melengkungkan ruang-waktu; semua di sekitarnya "jatuh" ke dasar lengkungan
    private static boolean warp(ServerPlayer p) {
        Vec3 c = aimPoint(p, 28.0, 16.0);
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_WARP, c);
        sound(p, c, ShazamSounds.RELATIVA_WARP.get(), 2.4f);
        busy(p, ShazamAnim.REL_WARP_HIT + 4);
        later(p, ShazamAnim.REL_WARP_HIT, sp -> {
            State s = state(sp);
            s.warpAt = c;
            s.warp = ShazamAnim.REL_WARP_SLAM - ShazamAnim.REL_WARP_HIT;
        });
        return true;
    }

    private static void tickWarp(ServerPlayer p, State s) {
        if (s.warp <= 0 || s.warpAt == null) {
            return;
        }
        Vec3 c = s.warpAt;
        for (LivingEntity e : around(p, c, 9.0)) {
            Vec3 to = c.subtract(e.position());
            double dist = Math.sqrt(to.x * to.x + to.z * to.z);
            if (dist < 0.6) {
                Vec3 v = e.getDeltaMovement();
                e.setDeltaMovement(v.x * 0.5, v.y, v.z * 0.5);
                continue;
            }
            double f = (0.06 + 0.22 / Math.max(1.0, dist)) * Math.min(1.0, 9.0 / Math.max(1.0, dist));
            e.push(to.x / dist * f, -0.03, to.z / dist * f);
            e.hurtMarked = true;
        }
        if (--s.warp == 0) {
            for (LivingEntity e : around(p, c, 5.0)) {
                double dist = e.position().distanceTo(c);
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, 14f * (float) Math.max(0.35, 1.0 - dist / 8.0)));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2), p);
                Vec3 v = e.getDeltaMovement();
                e.setDeltaMovement(v.x * 0.2, -0.9, v.z * 0.2);
                e.hurtMarked = true;
            }
            s.warpAt = null;
        }
    }

    // Shift+X  LUBANG HITAM: massa dipadatkan sampai cahaya pun nggak bisa lolos
    private static boolean blackHole(ServerPlayer p) {
        HitResult hit = p.pick(24.0, 1.0f, false);
        Vec3 c = hit.getType() == HitResult.Type.BLOCK ? hit.getLocation().add(0, 2.6, 0)
                : p.getEyePosition().add(p.getLookAngle().scale(14.0));
        final Vec3 center = c;
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_BLACKHOLE, center);
        sound(p, center, ShazamSounds.RELATIVA_BLACKHOLE.get(), 2.8f);
        busy(p, ShazamAnim.REL_BH_FORM + 4);
        later(p, ShazamAnim.REL_BH_FORM, sp -> {
            State s = state(sp);
            s.holeAt = center;
            s.hole = ShazamAnim.REL_BH_TICKS;
            s.holeAge = 0;
            RelativaAbilities.data(sp).holeTicks = s.hole;
            sound(sp, center, ShazamSounds.RELATIVA_BLACKHOLE_HUM.get(), 3.2f);
            RelativaNetwork.broadcastState(sp);
        });
        return true;
    }

    private static void tickHole(ServerPlayer p, State s, RelativaData d) {
        if (s.hole <= 0 || s.holeAt == null) {
            return;
        }
        ServerLevel level = p.serverLevel();
        Vec3 c = s.holeAt;
        s.hole--;
        s.holeAge++;
        d.holeTicks = s.hole;
        double grow = Math.min(1.0, s.holeAge / 30.0);
        double horizon = 0.8 + 1.1 * grow;
        AABB box = new AABB(c, c).inflate(HOLE_PULL);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> valid(p, e))) {
            Vec3 to = c.subtract(e.getBoundingBox().getCenter());
            double dist = to.length();
            if (dist > HOLE_PULL || dist < 1.0E-3) {
                continue;
            }
            double f = Math.min(0.42, 3.0 / (dist * dist) + 0.03) * grow;
            e.push(to.x / dist * f, to.y / dist * f + 0.05 * grow, to.z / dist * f);
            e.hurtMarked = true;
            e.resetFallDistance();
            if (dist < horizon + e.getBbWidth() * 0.5 && s.holeAge % 4 == 0) {   // spagetifikasi di dekat cakrawala peristiwa
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, 7f));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 3), p);
            }
        }
        for (Projectile pr : level.getEntitiesOfClass(Projectile.class, box, x -> x.getOwner() != p)) {
            Vec3 to = c.subtract(pr.position());
            double dist = to.length();
            if (dist > 12.0) {
                continue;
            }
            if (dist < 1.6) {
                if (pr instanceof ThrownTrident || pr instanceof ThrownDoubleBlade) {
                    pr.setDeltaMovement(Vec3.ZERO);   // barang milik orang: cuma tertahan
                } else {
                    pr.discard();
                }
                continue;
            }
            pr.setDeltaMovement(pr.getDeltaMovement().scale(0.85).add(to.scale(0.08 / dist)));
            pr.hurtMarked = true;
        }
        if (s.holeAge % 2 == 0) {
            for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, box.deflate(4.0))) {
                Vec3 to = c.subtract(item.position());
                double dist = Math.max(1.0, to.length());
                item.setDeltaMovement(item.getDeltaMovement().add(to.scale(0.05 / dist)));
            }
        }
        if (griefing(level) && s.holeAge > 6) {   // ruang-waktu menelan materi: blok di dekatnya tercabut & lenyap
            RandomSource rnd = level.random;
            double r = 1.5 + 4.0 * grow;
            int eaten = 0;
            for (int i = 0; i < 16 && eaten < HOLE_EAT_PER_TICK; i++) {
                double ox = (rnd.nextDouble() * 2.0 - 1.0) * r, oy = (rnd.nextDouble() * 2.0 - 1.0) * r,
                        oz = (rnd.nextDouble() * 2.0 - 1.0) * r;
                if (ox * ox + oy * oy + oz * oz > r * r) {
                    continue;
                }
                BlockPos pos = BlockPos.containing(c.x + ox, c.y + oy, c.z + oz);
                BlockState state = level.getBlockState(pos);
                if (eatable(level, pos, state)) {
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                    eaten++;
                }
            }
        }
        if (s.hole == 0) {   // radiasi Hawking: lubang hitam menguap habis, lalu meledak
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_BH_END, c);
            sound(p, c, ShazamSounds.RELATIVA_HAWKING.get(), 3.4f);
            for (LivingEntity e : around(p, c, 7.5)) {
                double dist = e.position().distanceTo(c);
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, 20f * (float) Math.max(0.3, 1.0 - dist / 10.0)));
                Vec3 away = e.position().subtract(c);
                away = away.lengthSqr() < 1.0E-4 ? new Vec3(0, 1, 0) : away.normalize();
                e.push(away.x * 1.6, 0.7 + Math.max(0.0, away.y), away.z * 1.6);
                e.hurtMarked = true;
            }
            s.holeAt = null;
            d.holeTicks = 0;
            RelativaNetwork.broadcastState(p);
        }
    }

    private static boolean eatable(ServerLevel level, BlockPos pos, BlockState state) {
        return !state.isAir() && level.isLoaded(pos) && state.getDestroySpeed(level, pos) >= 0f
                && level.getBlockEntity(pos) == null;
    }

    // ================================================================ C  Kuantum

    // C  Terowongan Kuantum: peluang partikel ada di balik penghalang nggak pernah nol. Kamu muncul di sana.
    private static boolean tunnel(ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double eyeHeight = p.getEyeHeight();
        Vec3 dest = null;
        for (double dist = TUNNEL_RANGE; dist >= 2.5; dist -= 0.5) {   // titik aman terjauh, walau ada dinding di depannya
            Vec3 feet = eye.add(look.scale(dist)).subtract(0, eyeHeight, 0);
            if (feet.y < p.level().getMinBuildHeight() + 1 || !p.level().isLoaded(BlockPos.containing(feet))) {
                continue;
            }
            if (p.level().noCollision(p, p.getBoundingBox().move(feet.subtract(p.position())))) {
                dest = feet;
                break;
            }
        }
        if (dest == null) {
            return false;
        }
        final Vec3 to = dest;
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_TUNNEL, to);
        sound(p, p.position(), ShazamSounds.RELATIVA_TUNNEL.get(), 1.6f);
        busy(p, ShazamAnim.REL_TUNNEL_AT + 2);
        later(p, ShazamAnim.REL_TUNNEL_AT, sp -> {
            if (!sp.level().noCollision(sp, sp.getBoundingBox().move(to.subtract(sp.position())))) {
                return;
            }
            sp.teleportTo(to.x, to.y, to.z);
            sp.resetFallDistance();
            sound(sp, to, ShazamSounds.RELATIVA_TUNNEL.get(), 1.2f);
            for (LivingEntity e : around(sp, to, 3.2)) {   // gelombang peluang runtuh: yang di dekatnya terhentak
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 6f));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1), sp);
                Vec3 away = flat(e.position().subtract(to));
                e.push(away.x * 0.8, 0.3, away.z * 0.8);
                e.hurtMarked = true;
            }
        });
        return true;
    }

    // Shift+C  Keterikatan Kuantum ("aksi seram dari jauh"): yang terjadi pada satu langsung terjadi pada pasangannya
    private static boolean entangle(ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        List<LivingEntity> list = new ArrayList<>();
        for (LivingEntity e : enemies(p, 16.0)) {
            Vec3 to = chest(e).subtract(eye);
            double dist = to.length();
            if (dist > 16.0 || (dist > 3.0 && to.normalize().dot(look) < 0.35)) {
                continue;
            }
            list.add(e);
        }
        if (list.isEmpty()) {
            return false;
        }
        list.sort(Comparator.comparingDouble(e -> e.distanceToSqr(p)));
        List<LivingEntity> targets = new ArrayList<>(list.subList(0, Math.min(ENTANGLE_MAX, list.size())));
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_ENTANGLE);
        sound(p, p.position(), ShazamSounds.RELATIVA_ENTANGLE.get(), 1.8f);
        busy(p, ShazamAnim.REL_ENTANGLE_HIT + 4);
        later(p, ShazamAnim.REL_ENTANGLE_HIT, sp -> {
            State s = state(sp);
            s.entangled.clear();
            for (LivingEntity e : targets) {
                if (!e.isAlive() || e.level() != sp.level()) {
                    continue;
                }
                s.entangled.add(e);
                ShazamNetwork.playAnim(sp, ShazamAnim.PHYS_ENTANGLE, chest(e));
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 4f));
                e.addEffect(new MobEffectInstance(MobEffects.GLOWING, ShazamAnim.REL_ENTANGLE_TICKS, 0), sp);
            }
            s.entangle = s.entangled.isEmpty() ? 0 : ShazamAnim.REL_ENTANGLE_TICKS;
            RelativaAbilities.data(sp).entangleTicks = s.entangle;
        });
        return true;
    }

    private static void tickEntangle(State s, RelativaData d) {
        if (s.entangle <= 0) {
            return;
        }
        s.entangled.removeIf(e -> !e.isAlive());
        if (--s.entangle <= 0 || s.entangled.isEmpty()) {
            s.entangle = 0;
            s.entangled.clear();
        }
        d.entangleTicks = s.entangle;
    }

    /** Damage yang benar-benar masuk ke satu makhluk terikat mengalir ke semua pasangannya. */
    public static void onDamagePost(LivingDamageEvent.Post event) {
        LivingEntity victim = event.getEntity();
        float dealt = event.getNewDamage();
        if (sharing || STATES.isEmpty() || dealt <= 0f || victim.level().isClientSide() || victim.getServer() == null) {
            return;
        }
        for (Map.Entry<UUID, State> en : new ArrayList<>(STATES.entrySet())) {
            State s = en.getValue();
            if (s.entangle <= 0 || !s.entangled.contains(victim)) {
                continue;
            }
            ServerPlayer owner = victim.getServer().getPlayerList().getPlayer(en.getKey());
            if (owner == null) {
                continue;
            }
            sharing = true;
            try {
                for (LivingEntity e : new ArrayList<>(s.entangled)) {
                    if (e == victim || !e.isAlive() || e.level() != victim.level()) {
                        continue;
                    }
                    e.invulnerableTime = 0;
                    e.hurt(magic(owner), dealt * ENTANGLE_SHARE);
                    ShazamNetwork.playAnim(owner, ShazamAnim.PHYS_ENTANGLE_PULSE, chest(e));
                }
            } finally {
                sharing = false;
            }
        }
    }

    // ================================================================ V  Fisi Nuklir

    // V  Fisi Berantai: satu neutron membelah inti, tiap belahan melepas dua neutron lagi, dan seterusnya
    private static boolean fission(ServerPlayer p) {
        LivingEntity first = aimed(p, 24.0);
        if (first == null) {
            first = nearestInFront(p, 14.0);
        }
        if (first == null) {
            return false;
        }
        final LivingEntity target = first;
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_FISSION, chest(target));
        sound(p, p.position(), ShazamSounds.RELATIVA_NEUTRON.get(), 1.4f);
        busy(p, ShazamAnim.REL_FISSION_HIT + 2);
        Set<LivingEntity> reserved = new HashSet<>();
        reserved.add(target);
        int[] budget = {14};
        later(p, ShazamAnim.REL_FISSION_HIT, sp -> split(sp, target, 0, reserved, budget));
        return true;
    }

    private static void split(ServerPlayer p, LivingEntity t, int gen, Set<LivingEntity> reserved, int[] budget) {
        if (!t.isAlive() || budget[0] <= 0 || t.level() != p.level()) {
            return;
        }
        budget[0]--;
        Vec3 at = chest(t);
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_FISSION, at);
        sound(p, at, ShazamSounds.RELATIVA_FISSION.get(), 1.5f);
        t.invulnerableTime = 0;
        t.hurt(magic(p), dmg(p, 12f * (float) Math.pow(0.85, gen)));
        RandomSource r = p.getRandom();
        t.push((r.nextDouble() - 0.5) * 0.6, 0.25, (r.nextDouble() - 0.5) * 0.6);
        t.hurtMarked = true;
        if (gen >= 3) {
            return;
        }
        List<LivingEntity> next = new ArrayList<>();
        for (LivingEntity e : around(p, at, 9.0)) {
            if (!reserved.contains(e)) {
                next.add(e);
            }
        }
        next.sort(Comparator.comparingDouble(e -> e.position().distanceToSqr(at)));
        for (int k = 0; k < Math.min(2, next.size()); k++) {
            LivingEntity n = next.get(k);
            reserved.add(n);
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_FROM, at);
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_NEUTRON, chest(n));
            later(p, ShazamAnim.REL_FISSION_GAP, sp -> split(sp, n, gen + 1, reserved, budget));
        }
    }

    // Shift+V  Massa Kritis: inti uranium dimampatkan sampai superkritis
    private static boolean critical(ServerPlayer p) {
        Vec3 c = aimPoint(p, 32.0, 20.0).add(0, 0.6, 0);
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_CRITICAL, c);
        sound(p, c, ShazamSounds.RELATIVA_CRITICAL.get(), 3.0f);
        busy(p, ShazamAnim.REL_CRIT_CORE + 4);
        later(p, ShazamAnim.REL_CRIT_BOOM, sp -> nuke(sp, c));
        return true;
    }

    private static void nuke(ServerPlayer p, Vec3 c) {
        ServerLevel level = p.serverLevel();
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_CRIT_BOOM, c);
        level.playSound(null, c.x, c.y, c.z, ShazamSounds.RELATIVA_NUKE.get(), SoundSource.PLAYERS, 7.0f, 1f);
        for (LivingEntity e : around(p, c, CRIT_RADIUS)) {
            double dist = e.position().distanceTo(c);
            e.invulnerableTime = 0;
            e.hurt(p.damageSources().explosion(p, p), dmg(p, 38f * (float) Math.max(0.25, 1.0 - dist / 16.0)));
            e.igniteForSeconds(6);
            Vec3 away = e.position().subtract(c);
            away = away.lengthSqr() < 1.0E-4 ? new Vec3(0, 1, 0) : away.normalize();
            double k = 2.2 * Math.max(0.2, 1.0 - dist / (CRIT_RADIUS + 4.0));
            e.push(away.x * k, 0.6 + 0.5 * k, away.z * k);
            e.hurtMarked = true;
        }
        if (griefing(level)) {
            InfinityWorld.crater(level, c, CRIT_CRATER);
        }
        State s = state(p);
        s.radAt = c;
        s.rad = 120;
    }

    private static void tickRadiation(ServerPlayer p, State s) {
        if (s.rad <= 0 || s.radAt == null) {
            return;
        }
        if (--s.rad % 20 == 0) {   // radiasi sisa: sakit radiasi untuk yang masuk zona
            for (LivingEntity e : around(p, s.radAt, 8.0)) {
                e.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 0), p);
                e.addEffect(new MobEffectInstance(MobEffects.HUNGER, 60, 1), p);
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, 1.5f));
            }
            sound(p, s.radAt, ShazamSounds.RELATIVA_GEIGER.get(), 1.0f);
        }
        if (s.rad <= 0) {
            s.radAt = null;
        }
    }

    // ================================================================ B  Fusi Nuklir

    // B  Fusi Bintang: dua inti hidrogen dipaksa bersatu jadi helium, selisih massanya jadi bintang mini
    private static boolean fusion(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_FUSION);
        sound(p, p.position(), ShazamSounds.RELATIVA_FUSION.get(), 1.8f);
        busy(p, ShazamAnim.REL_FUSION_THROW + 2);
        later(p, ShazamAnim.REL_FUSION_THROW, sp -> {
            Vec3 from = sp.getEyePosition().add(0, -0.3, 0);
            Vec3 impact = rayImpact(sp, from, sp.getLookAngle(), 36.0);
            ShazamNetwork.playAnim(sp, ShazamAnim.PHYS_FUSION_SHOT, impact);
            int travel = Math.max(1, (int) Math.ceil(from.distanceTo(impact) / RelativaData.FUSION_SPEED));
            later(sp, travel, sp2 -> fusionBoom(sp2, impact));
        });
        return true;
    }

    private static void fusionBoom(ServerPlayer p, Vec3 at) {
        sound(p, at, ShazamSounds.RELATIVA_FUSION_BOOM.get(), 2.6f);
        for (LivingEntity e : around(p, at, 4.5)) {
            double dist = e.position().distanceTo(at);
            e.invulnerableTime = 0;
            e.hurt(magic(p), dmg(p, 18f * (float) Math.max(0.35, 1.0 - dist / 7.0)));
            e.igniteForSeconds(5);
            Vec3 away = flat(e.position().subtract(at));
            e.push(away.x * 1.1, 0.5, away.z * 1.1);
            e.hurtMarked = true;
        }
    }

    // Shift+B  Tokamak: plasma bersuhu jutaan derajat dikurung medan magnet berbentuk donat di sekelilingmu
    private static boolean tokamak(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_TOKAMAK);
        sound(p, p.position(), ShazamSounds.RELATIVA_TOKAMAK.get(), 2.0f);
        busy(p, ShazamAnim.REL_TOKAMAK_HIT + 4);
        later(p, ShazamAnim.REL_TOKAMAK_HIT, sp -> {
            State s = state(sp);
            s.tokamak = ShazamAnim.REL_TOKAMAK_TICKS;
            RelativaAbilities.data(sp).tokamakTicks = s.tokamak;
            RelativaNetwork.broadcastState(sp);
        });
        return true;
    }

    private static void tickTokamak(ServerPlayer p, State s, RelativaData d) {
        if (s.tokamak <= 0) {
            return;
        }
        s.tokamak--;
        d.tokamakTicks = s.tokamak;
        Vec3 c = p.position().add(0, 1.0, 0);
        if (s.tokamak % 10 == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 14, 0, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 14, 0, false, false));
            for (LivingEntity e : around(p, c, TOKAMAK_RADIUS + 2.2)) {
                double dx = e.getX() - c.x, dz = e.getZ() - c.z;
                double rho = Math.sqrt(dx * dx + dz * dz);
                double dy = e.getY() + e.getBbHeight() * 0.5 - c.y;
                if (Math.abs(rho - TOKAMAK_RADIUS) > 1.7 || Math.abs(dy) > 1.9) {
                    continue;
                }
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, 4f));
                e.igniteForSeconds(3);
                Vec3 out = rho < 0.01 ? new Vec3(1, 0, 0) : new Vec3(dx / rho, 0, dz / rho);
                e.push(out.x * 0.7, 0.25, out.z * 0.7);
                e.hurtMarked = true;
            }
        }
        for (Projectile pr : p.serverLevel().getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(TOKAMAK_RADIUS + 1.5),
                x -> x.getOwner() != p)) {
            double dx = pr.getX() - c.x, dz = pr.getZ() - c.z;
            double rho = Math.sqrt(dx * dx + dz * dz);
            if (Math.abs(rho - TOKAMAK_RADIUS) > 1.3 || Math.abs(pr.getY() - c.y) > 1.3) {
                continue;
            }
            if (pr instanceof ThrownTrident || pr instanceof ThrownDoubleBlade) {
                pr.setDeltaMovement(Vec3.ZERO);
            } else {
                pr.discard();   // menguap di plasma
            }
        }
        if (s.tokamak == 0) {   // plasma lepas kendali: cincinnya pecah ke luar
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_DISRUPT, c);
            sound(p, c, ShazamSounds.RELATIVA_DISRUPT.get(), 2.4f);
            for (LivingEntity e : around(p, c, 7.5)) {
                double dist = e.position().distanceTo(c);
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, 14f * (float) Math.max(0.3, 1.0 - dist / 10.0)));
                e.igniteForSeconds(4);
                Vec3 away = flat(e.position().subtract(c));
                e.push(away.x * 1.4, 0.5, away.z * 1.4);
                e.hurtMarked = true;
            }
            RelativaNetwork.broadcastState(p);
        }
    }

    // ================================================================ N  E = mc²

    // N  E = mc²: sebagian massa sasaran dikonversi jadi energi. Makin besar massanya (darah maksimal), makin dahsyat.
    private static boolean emc(ServerPlayer p) {
        LivingEntity target = aimed(p, 28.0);
        if (target == null) {
            return false;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_EMC, chest(target));
        sound(p, p.position(), ShazamSounds.RELATIVA_EMC.get(), 1.8f);
        busy(p, ShazamAnim.REL_EMC_HIT + 4);
        later(p, ShazamAnim.REL_EMC_HIT, sp -> {
            if (!target.isAlive() || target.level() != sp.level() || target.distanceTo(sp) > 36.0) {
                return;
            }
            float base = Math.min(EMC_CAP, 6f + target.getMaxHealth() * 0.22f);
            float dealt = dmg(sp, base);
            target.invulnerableTime = 0;
            target.hurt(magic(sp), dealt);
            sound(sp, chest(target), ShazamSounds.RELATIVA_EMC_BOOM.get(), 2.4f);
            RelativaData data = RelativaAbilities.data(sp);
            data.energy = Math.min(RelativaData.MAX_ENERGY, data.energy + 10f);   // energinya dipanen
            sp.setAbsorptionAmount(Math.max(sp.getAbsorptionAmount(), Math.min(20f, dealt * 0.25f)));
            target.push(0.0, 0.35, 0.0);
            target.hurtMarked = true;
        });
        return true;
    }

    // Shift+N  Anihilasi: elektron bertemu positron, massanya lenyap 100% jadi dua foton gamma yang berlawanan arah
    private static boolean annihilate(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_ANNIHILATE);
        sound(p, p.position(), ShazamSounds.RELATIVA_ANNIHILATE.get(), 2.2f);
        busy(p, ShazamAnim.REL_ANNIHILATE_AT + ShazamAnim.REL_ANNIHILATE_TICKS);
        later(p, ShazamAnim.REL_ANNIHILATE_AT, sp -> {
            Vec3 from = sp.getEyePosition().add(0, -0.35, 0);
            Vec3 look = sp.getLookAngle();
            Set<LivingEntity> hit = new HashSet<>();
            for (int k = 0; k < 2; k++) {
                Vec3 dir = k == 0 ? look : look.scale(-1.0);
                Vec3 end = blockEnd(sp, from, dir, 30.0);
                for (LivingEntity e : along(sp, from, end, 1.3)) {
                    if (!hit.add(e)) {
                        continue;
                    }
                    e.invulnerableTime = 0;
                    e.hurt(magic(sp), dmg(sp, 20f));
                    e.push(dir.x * 0.8, 0.3, dir.z * 0.8);
                    e.hurtMarked = true;
                }
            }
        });
        return true;
    }

    // ================================================================ R

    // R  Teori Medan Terpadu: gravitasi, elektromagnet, gaya kuat, gaya lemah jadi satu (mimpi terakhir Einstein)
    private static void unified(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_UNIFIED);
        sound(p, p.position(), ShazamSounds.RELATIVA_UNIFIED.get(), 3.2f);
        busy(p, ShazamAnim.REL_UNIFIED_TICKS);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, ShazamAnim.REL_UNIFIED_HIT + 6, 2, false, false));
        later(p, ShazamAnim.REL_UNIFIED_HIT, sp -> {
            Vec3 c = sp.position().add(0, 1.0, 0);
            int n = 0;
            for (LivingEntity e : around(sp, c, 22.0)) {
                double dist = e.position().distanceTo(c);
                if (n++ < 24) {
                    ShazamNetwork.playAnim(sp, ShazamAnim.PHYS_UNIFIED_HIT, chest(e));
                }
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 30f * (float) Math.max(0.6, 1.0 - dist / 44.0)));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 70, 4), sp);   // gaya kuat: terkunci
                e.addEffect(new MobEffectInstance(MobEffects.WITHER, 120, 1), sp);             // gaya lemah: meluruh
                e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0), sp);
                Vec3 away = flat(e.position().subtract(c));
                e.push(away.x * 1.4, 0.9, away.z * 1.4);                                     // elektromagnet: tolakan
                e.hurtMarked = true;
            }
        });
    }

    // Shift+R  Kondensat Bose-Einstein: didinginkan sampai nyaris nol mutlak, semua atomnya berhenti & menyatu
    private static void condensate(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_BEC);
        sound(p, p.position(), ShazamSounds.RELATIVA_BEC.get(), 2.4f);
        busy(p, ShazamAnim.REL_BEC_HIT + 6);
        later(p, ShazamAnim.REL_BEC_HIT, sp -> {
            State s = state(sp);
            Vec3 c = sp.position();
            for (LivingEntity e : around(sp, c, 12.0)) {
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 8f));
                s.frozen.removeIf(h -> h.entity == e);
                s.frozen.add(new Held(e, ShazamAnim.REL_BEC_TICKS));
                ShazamNetwork.playAnim(sp, ShazamAnim.PHYS_FROZEN, chest(e));
            }
            if (griefing(sp.serverLevel())) {
                freezeWater(sp.serverLevel(), c, 10);
            }
        });
    }

    private static void tickFrozen(ServerPlayer p, State s) {
        if (s.frozen.isEmpty()) {
            return;
        }
        Iterator<Held> it = s.frozen.iterator();
        while (it.hasNext()) {
            Held h = it.next();
            LivingEntity e = h.entity;
            if (!e.isAlive() || e.level() != p.level() || --h.ticks <= 0) {
                if (e.isAlive()) {
                    e.setTicksFrozen(Math.min(e.getTicksFrozen(), e.getTicksRequiredToFreeze()));   // mencair pelan
                }
                it.remove();
                continue;
            }
            e.setTicksFrozen(Math.max(e.getTicksFrozen(), e.getTicksRequiredToFreeze() + 20));
            if (h.ticks % 5 == 0) {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 6, false, false), p);
                e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 10, 4, false, false), p);
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 10, 2, false, false), p);
            }
            Vec3 v = e.getDeltaMovement();
            e.setDeltaMovement(0.0, Math.min(0.0, v.y), 0.0);
            if (e instanceof Mob mob) {
                mob.getNavigation().stop();
            }
        }
    }

    private static void freezeWater(ServerLevel level, Vec3 c, int radius) {
        BlockPos center = BlockPos.containing(c);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz > radius * radius) {
                    continue;
                }
                for (int dy = -3; dy <= 2; dy++) {
                    pos.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    if (!level.isLoaded(pos)) {
                        continue;
                    }
                    BlockState state = level.getBlockState(pos);
                    if (state.is(Blocks.WATER) && level.getFluidState(pos).isSource() && level.getBlockState(pos.above()).isAir()) {
                        level.setBlockAndUpdate(pos.immutable(), Blocks.FROSTED_ICE.defaultBlockState());
                    }
                }
            }
        }
    }

    // ================================================================ M  Cahaya

    // M  Efek Fotolistrik: tiap foton membawa E = hν; begitu kena, elektronnya terlepas dan melompat ke yang terdekat
    private static void photo(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_PHOTO);
        sound(p, p.position(), ShazamSounds.RELATIVA_PHOTON.get(), 1.6f);
        busy(p, ShazamAnim.REL_PHOTO_FIRST + ShazamAnim.REL_PHOTO_COUNT * ShazamAnim.REL_PHOTO_GAP);
        for (int k = 0; k < ShazamAnim.REL_PHOTO_COUNT; k++) {
            final int shot = k;
            later(p, ShazamAnim.REL_PHOTO_FIRST + k * ShazamAnim.REL_PHOTO_GAP, sp -> photon(sp, shot));
        }
    }

    private static void photon(ServerPlayer p, int shot) {
        Vec3 from = p.getEyePosition().add(0, -0.2, 0);
        RandomSource r = p.getRandom();
        double spread = shot == 0 ? 0.0 : 0.035;
        Vec3 dir = p.getLookAngle().add((r.nextDouble() - 0.5) * spread, (r.nextDouble() - 0.5) * spread,
                (r.nextDouble() - 0.5) * spread).normalize();
        Vec3 end = blockEnd(p, from, dir, 30.0);
        EntityHitResult hit = rayEntity(p, from, end);
        Vec3 at = hit != null ? hit.getLocation() : end;
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_PHOTON, at);
        if (hit == null || !(hit.getEntity() instanceof LivingEntity target)) {
            return;
        }
        target.invulnerableTime = 0;
        target.hurt(magic(p), dmg(p, 4f));
        List<LivingEntity> near = new ArrayList<>();
        for (LivingEntity e : around(p, chest(target), 6.0)) {
            if (e != target) {
                near.add(e);
            }
        }
        near.sort(Comparator.comparingDouble(e -> e.distanceToSqr(target)));
        for (int k = 0; k < Math.min(2, near.size()); k++) {   // fotoelektron melompat
            LivingEntity o = near.get(k);
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_FROM, chest(target));
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_ARC, chest(o));
            o.invulnerableTime = 0;
            o.hurt(magic(p), dmg(p, 3f));
        }
        if (!near.isEmpty()) {
            sound(p, chest(target), ShazamSounds.RELATIVA_ARC.get(), 1.0f);
        }
    }

    // Shift+M  Laser: emisi terstimulasi (Einstein 1917): satu foton memancing foton kembar, semuanya sefase
    private static void laser(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_LASER);
        sound(p, p.position(), ShazamSounds.RELATIVA_LASER.get(), 1.8f);
        busy(p, ShazamAnim.REL_LASER_CHARGE + ShazamAnim.REL_LASER_TICKS);
        later(p, ShazamAnim.REL_LASER_CHARGE, sp -> state(sp).laser = ShazamAnim.REL_LASER_TICKS);
    }

    private static void tickLaser(ServerPlayer p, State s) {
        if (s.laser <= 0) {
            return;
        }
        if (--s.laser % 2 != 0) {
            return;
        }
        Vec3 from = p.getEyePosition().add(0, -0.2, 0);
        Vec3 end = blockEnd(p, from, p.getLookAngle(), 40.0);
        for (LivingEntity e : along(p, from, end, 0.8)) {
            e.invulnerableTime = 0;
            e.hurt(magic(p), dmg(p, 3f));
            e.igniteForSeconds(2);
        }
    }

    // ================================================================ J

    // J  Gelombang Gravitasi: ruang-waktu sendiri yang beriak, meregang ke satu arah sambil memampat ke arah lainnya
    private static void gravityWave(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_GWAVE);
        sound(p, p.position(), ShazamSounds.RELATIVA_GWAVE.get(), 2.2f);
        busy(p, ShazamAnim.REL_GWAVE_HIT + 6);
        later(p, ShazamAnim.REL_GWAVE_HIT, sp -> {
            Vec3 c = sp.position();
            for (LivingEntity e : around(sp, c, 9.0)) {
                double dx = e.getX() - c.x, dz = e.getZ() - c.z;
                double dist = Math.sqrt(dx * dx + dz * dz);
                double ang = Math.atan2(dz, dx);
                double stretch = 0.6 + 0.5 * Math.cos(2.0 * ang);   // polarisasi "+": meregang di satu sumbu
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 10f * (float) Math.max(0.35, 1.0 - dist / 14.0)));
                Vec3 out = dist < 0.01 ? new Vec3(1, 0, 0) : new Vec3(dx / dist, 0, dz / dist);
                e.push(out.x * stretch, 0.75, out.z * stretch);
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1), sp);
                e.hurtMarked = true;
            }
            sp.resetFallDistance();
        });
    }

    // Shift+J  Gerak Brown: ditabrak miliaran molekul dari segala arah, badanmu melompat-lompat acak
    private static void brownian(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_BROWN);
        sound(p, p.position(), ShazamSounds.RELATIVA_BROWN.get(), 1.4f);
        busy(p, 2 + ShazamAnim.REL_BROWN_COUNT * ShazamAnim.REL_BROWN_GAP);
        for (int k = 0; k < ShazamAnim.REL_BROWN_COUNT; k++) {
            later(p, 2 + k * ShazamAnim.REL_BROWN_GAP, RelativaSkills::hop);
        }
    }

    private static void hop(ServerPlayer p) {
        RandomSource r = p.getRandom();
        Vec3 from = p.position();
        Vec3 to = null;
        for (int tries = 0; tries < 8 && to == null; tries++) {
            double a = r.nextDouble() * Math.PI * 2.0, dist = 2.0 + r.nextDouble() * 2.5;
            for (int dy = 0; dy <= 2 && to == null; dy++) {
                Vec3 c = from.add(Math.cos(a) * dist, dy == 2 ? -1 : dy, Math.sin(a) * dist);
                AABB box = p.getBoundingBox().move(c.subtract(from));
                if (!p.level().noCollision(p, box) || p.level().noCollision(p, box.move(0, -0.6, 0))) {
                    continue;   // sesak, atau nggak ada pijakan
                }
                BlockPos at = BlockPos.containing(c);
                if (p.level().getFluidState(at).is(FluidTags.LAVA) || p.level().getFluidState(at.below()).is(FluidTags.LAVA)) {
                    continue;
                }
                to = c;
            }
        }
        if (to == null) {
            return;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_FROM, from);
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_BROWN, to);
        p.teleportTo(to.x, to.y, to.z);
        p.resetFallDistance();
        p.invulnerableTime = Math.max(p.invulnerableTime, 6);
        for (LivingEntity e : around(p, to.add(0, 1.0, 0), 2.6)) {   // tabrakan molekul
            e.invulnerableTime = 0;
            e.hurt(magic(p), dmg(p, 4f));
            e.push((r.nextDouble() - 0.5) * 1.2, 0.3, (r.nextDouble() - 0.5) * 1.2);
            e.hurtMarked = true;
        }
    }

    // ---------------------------------------------------------------- bantuan

    static float dmg(ServerPlayer p, float base) {
        return Math.max(0f, base) * SKILL_DAMAGE;
    }

    static DamageSource magic(ServerPlayer p) {
        return p.damageSources().indirectMagic(p, p);
    }

    static void sound(ServerPlayer p, Vec3 at, SoundEvent sound, float volume) {
        p.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, 1f);
    }

    static Vec3 chest(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.62, 0);
    }

    static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : f.normalize();
    }

    static boolean griefing(ServerLevel level) {
        return level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
    }

    /** Sasaran kuasa: bukan diri sendiri, kawan, peliharaan sendiri; pemain cuma kalau PvP nyala. */
    static boolean valid(ServerPlayer p, LivingEntity e) {
        if (e == p || !e.isAlive() || e instanceof ArmorStand || p.isAlliedTo(e)) {
            return false;
        }
        if (e instanceof TamableAnimal pet && pet.isOwnedBy(p)) {
            return false;
        }
        return !(e instanceof Player) || p.server.isPvpAllowed();
    }

    static List<LivingEntity> enemies(ServerPlayer p, double radius) {
        return p.serverLevel().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(radius), e -> valid(p, e));
    }

    /** Sasaran yang pusat badannya dalam radius r dari titik c. */
    static List<LivingEntity> around(ServerPlayer p, Vec3 c, double r) {
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : p.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r + 2.0),
                e -> valid(p, e))) {
            if (e.getBoundingBox().getCenter().distanceTo(c) <= r + e.getBbWidth() * 0.5) {
                out.add(e);
            }
        }
        return out;
    }

    /** Sasaran yang badannya dekat ruas garis a-b (dalam radius r). */
    static List<LivingEntity> along(ServerPlayer p, Vec3 a, Vec3 b, double r) {
        List<LivingEntity> out = new ArrayList<>();
        Vec3 ab = b.subtract(a);
        double len2 = Math.max(1.0E-6, ab.lengthSqr());
        for (LivingEntity e : p.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(a, b).inflate(r + 1.0),
                e -> valid(p, e))) {
            Vec3 c = e.getBoundingBox().getCenter();
            double t = Math.max(0.0, Math.min(1.0, c.subtract(a).dot(ab) / len2));
            Vec3 closest = a.add(ab.scale(t));
            if (c.distanceTo(closest) <= r + e.getBbWidth() * 0.5 + e.getBbHeight() * 0.25) {
                out.add(e);
            }
        }
        return out;
    }

    /** Musuh yang dibidik (paling dekat ke garis pandang, terlihat langsung), atau null. */
    static LivingEntity aimed(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestScore = -1.0;
        for (LivingEntity e : enemies(p, range)) {
            Vec3 to = chest(e).subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.01) {
                continue;
            }
            double dot = to.normalize().dot(look);
            double need = Math.max(0.9, 0.995 - 0.6 / dist);   // makin dekat makin longgar
            if (dot < need || !p.hasLineOfSight(e)) {
                continue;
            }
            double score = dot - dist * 0.002;
            if (score > bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    /** Musuh terdekat di kerucut depan (buat sasaran pertama Fisi Berantai kalau nggak ada yang dibidik). */
    static LivingEntity nearestInFront(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity e : enemies(p, range)) {
            Vec3 to = chest(e).subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.01 || to.normalize().dot(look) < 0.6 || !p.hasLineOfSight(e)) {
                continue;
            }
            if (dist < bd) {
                bd = dist;
                best = e;
            }
        }
        return best;
    }

    /** Titik tujuan aman sejauh range di arah bidikan (mundur sampai 4 blok kalau tujuannya sesak), atau null. */
    static Vec3 safeAim(ServerPlayer p, double range) {
        HitResult hit = p.pick(range, 1.0f, false);
        Vec3 to = hit.getLocation();
        if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult block) {
            BlockPos above = block.getBlockPos().relative(block.getDirection());
            to = Vec3.atBottomCenterOf(above);
        }
        Vec3 back = flat(p.getLookAngle()).scale(-1.0);
        for (int i = 0; i <= 4; i++) {
            Vec3 c = to.add(back.scale(i));
            if (p.level().noCollision(p, p.getBoundingBox().move(c.subtract(p.position())))) {
                return c;
            }
        }
        return null;
    }

    /** Titik di tanah yang dibidik (sejauh range), atau tanah fallback blok di depan kalau bidikannya ke langit. */
    static Vec3 aimPoint(ServerPlayer p, double range, double fallback) {
        HitResult hit = p.pick(range, 1.0f, false);
        if (hit.getType() == HitResult.Type.BLOCK) {
            return hit.getLocation();
        }
        Vec3 ahead = p.position().add(flat(p.getLookAngle()).scale(fallback));
        return new Vec3(ahead.x, p.serverLevel().getHeight(Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(ahead.x),
                (int) Math.floor(ahead.z)), ahead.z);
    }

    /** Titik pertama yang kena blok di arah dir (sejauh range), atau ujungnya. */
    static Vec3 blockEnd(ServerPlayer p, Vec3 from, Vec3 dir, double range) {
        Vec3 end = from.add(dir.scale(range));
        BlockHitResult hit = p.level().clip(new ClipContext(from, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return hit.getType() == HitResult.Type.MISS ? end : hit.getLocation();
    }

    /** Sasaran pertama yang dilewati garis from-to, atau null. */
    static EntityHitResult rayEntity(ServerPlayer p, Vec3 from, Vec3 to) {
        AABB box = new AABB(from, to).inflate(1.0);
        return ProjectileUtil.getEntityHitResult(p, from, to, box, e -> e instanceof LivingEntity le && valid(p, le),
                from.distanceToSqr(to));
    }

    /** Titik hantam bola yang dilempar lurus: blok atau sasaran pertama. */
    static Vec3 rayImpact(ServerPlayer p, Vec3 from, Vec3 dir, double range) {
        Vec3 end = blockEnd(p, from, dir, range);
        EntityHitResult hit = rayEntity(p, from, end);
        return hit != null ? hit.getLocation() : end;
    }
}
