package com.shazammod.relativa;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.shazammod.PralayaGod;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamPowers;
import com.shazammod.ShazamSounds;
import com.shazammod.thanos.ThanosAbilities;
import com.shazammod.thanos.ThanosSnap;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 0.66 RELATIVA, Sang Penekuk Ruang-Waktu (orisinal, terinspirasi teori-teori Einstein). Sama seperti Thanos: wujud
 * terpisah dari juara ShazamForm, tapi nggak bisa aktif bareng juara mana pun (termasuk Thanos).
 *
 *   Jurnal Annus Mirabilis      empat makalah 1905 ditulis dengan MENGALAMINYA sendiri (bawa jurnalnya di inventori):
 *                               I  Efek Fotolistrik   berdiri di bawah sinar matahari langsung (5 detik)
 *                               II Gerak Brown        menyelam di air (3 detik)
 *                               III Relativitas Khusus bergerak sangat cepat (elytra, perahu di es, jatuh dari tinggi)
 *                               IV E = mc²            kena ledakan (creeper / TNT)
 *                               lalu klik kanan jurnalnya: Eksperimen Pikiran (RelativaRite), RELATIVA terbuka
 *   Y / ketik RELATIVA / E=mc²  berubah (RELATIVA_TRANSFORM, kekuatan terpasang di REL_MORPH_BURST) / kembali
 *   Z X C V B N R M J (+Shift)  18 skill fisika (RelativaSkills); G = kembali jadi manusia
 *
 * Pasif: Superposisi (sesekali serangan cuma "lewat"), Tinju Foton (pukulan biasa + foton, makin cepat bergerak makin
 * berat karena massa relativistik), Energi terisi lebih cepat di bawah matahari (foton). Semua logika di server.
 */
public final class RelativaAbilities {
    private RelativaAbilities() {}

    // ======= Angka yang gampang diutak-atik =======
    private static final int TOGGLE_GAP = 20;
    private static final int SYNC_EVERY = 10;
    private static final float ENERGY_REGEN = 6f;       // per detik
    private static final float ENERGY_SUN = 3f;         // tambahan per detik di bawah matahari (foton)
    private static final float DODGE_CHANCE = 0.18f;    // Superposisi
    private static final int DODGE_GAP = 30;
    private static final float PUNCH_BONUS = 4f;        // Tinju Foton
    private static final int PAPER_SUN_TICKS = 100;     // Makalah I: 5 detik di bawah matahari
    private static final int PAPER_WATER_TICKS = 60;    // Makalah II: 3 detik menyelam
    private static final int PAPER_FAST_TICKS = 20;     // Makalah III: 1 detik di atas PAPER_FAST_SPEED
    private static final double PAPER_FAST_SPEED = 0.9; // blok/tick (18 m/dtk)

    /** Kemajuan menulis makalah (nggak disimpan): {matahari, air, cepat, jurnal dibawa (1/0)}. */
    private static final Map<UUID, int[]> PROGRESS = new HashMap<>();

    // ---------------------------------------------------------------- data & syarat

    public static RelativaData data(Player p) {
        return p.getData(RelativaRegistry.DATA);
    }

    public static boolean active(Player p) {
        return data(p).transformed;
    }

    public static boolean hasJournal(Player p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).getItem() instanceof AnnusMirabilisItem) {
                return true;
            }
        }
        return false;
    }

    /** Sedang (atau mulai) jadi juara lain / Thanos, atau di tengah ritual juara. */
    public static boolean championBusy(ServerPlayer p) {
        return ThanosAbilities.championBusy(p) || ThanosAbilities.active(p);
    }

    public static void msg(ServerPlayer p, String key, ChatFormatting color, Object... args) {
        p.displayClientMessage(Component.translatable("message.shazammod.relativa." + key, args).withStyle(color), true);
    }

    public static Component paperName(int paper) {
        return Component.translatable("paper.shazammod.relativa." + paper);
    }

    static Vec3 chest(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.62, 0);
    }

    // ---------------------------------------------------------------- tombol

    /**
     * Dipanggil dari ShazamNetwork.handleAction. Dalam wujud RELATIVA tombol juara dipakai RELATIVA. true = sudah diurus di
     * sini; K (ganti juara) & H tetap seperti biasa.
     */
    public static boolean handleSharedKey(ServerPlayer p, int action) {
        RelativaData d = data(p);
        if (!d.transformed) {
            return false;
        }
        if (action == ShazamNetwork.ACTION_FORM || action == ShazamNetwork.ACTION_HOOD) {
            return false;
        }
        boolean shift = p.isShiftKeyDown();
        if (action == ShazamNetwork.ACTION_TRANSFORM) {
            toggleTransform(p);
        } else if (action >= 1 && action <= 6) {
            RelativaSkills.key(p, d, action - 1, shift);
        } else if (action == 7) {
            RelativaSkills.ultimate(p, d, shift);
        } else if (action == ShazamNetwork.ACTION_ADAM_CALL) {
            RelativaSkills.light(p, d, shift);
        } else if (action == ShazamNetwork.ACTION_FAMILY) {
            RelativaSkills.wave(p, d, shift);
        }
        // tombol lain (Alt + Z..N, sinar Lintang): nggak dipakai RELATIVA, tapi tetap ditelan supaya juara lain nggak jalan
        RelativaNetwork.sync(p);
        return true;
    }

    // ---------------------------------------------------------------- berubah

    public static void toggleTransform(ServerPlayer p) {
        RelativaData d = data(p);
        if (p.isSpectator() || !p.isAlive() || PralayaGod.frozen(p) || d.morphing > 0 || RelativaRite.isRunning(p)) {
            return;
        }
        long now = p.level().getGameTime();
        if (d.lastToggle != 0L && now >= d.lastToggle && now - d.lastToggle < TOGGLE_GAP) {
            return;
        }
        if (d.transformed) {
            d.lastToggle = now;
            revert(p, d);
            return;
        }
        if (!d.unlocked) {
            msg(p, "need_unlock", ChatFormatting.GRAY);
            return;
        }
        if (ThanosAbilities.active(p)) {
            msg(p, "thanos_active", ChatFormatting.GRAY);
            return;
        }
        if (championBusy(p)) {
            msg(p, "champion_active", ChatFormatting.GRAY);
            return;
        }
        if (!RelativaSkills.free(p)) {
            return;
        }
        d.lastToggle = now;
        d.morphing = ShazamAnim.REL_MORPH_BURST;
        RelativaSkills.busy(p, ShazamAnim.REL_MORPH_TICKS);
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_TRANSFORM);
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.RELATIVA_TRANSFORM.get(),
                SoundSource.PLAYERS, 2.2f, 1f);
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ShazamAnim.REL_MORPH_BURST, 3, false, false));
    }

    /** E=mc² dipadatkan jadi atom di dada (REL_MORPH_BURST): kekuatan RELATIVA terpasang. */
    private static void completeMorph(ServerPlayer p, RelativaData d) {
        if (d.transformed || !d.unlocked || championBusy(p)) {
            return;
        }
        d.transformed = true;
        float ratio = p.getHealth() / Math.max(1f, p.getMaxHealth());
        RelativaPowers.apply(p);
        p.setHealth(Math.max(1f, ratio * p.getMaxHealth()));
        for (LivingEntity e : RelativaSkills.enemies(p, 4.5)) {   // gelombang cahaya mendorong yang terlalu dekat
            Vec3 away = RelativaSkills.flat(e.position().subtract(p.position()));
            e.push(away.x * 0.9, 0.35, away.z * 0.9);
            e.hurtMarked = true;
        }
        msg(p, "transformed", ChatFormatting.AQUA);
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    private static void revert(ServerPlayer p, RelativaData d) {
        RelativaSkills.endAll(p, d);
        d.transformed = false;
        RelativaPowers.remove(p);
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_REVERT);
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.RELATIVA_REVERT.get(), SoundSource.PLAYERS,
                1.3f, 1f);
        msg(p, "reverted", ChatFormatting.GRAY);
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    /** Dipaksa lepas (jadi juara lain lewat jalan lain, /relativa lock): tanpa animasi. */
    static void dropForm(ServerPlayer p, RelativaData d) {
        RelativaSkills.endAll(p, d);
        d.transformed = false;
        d.morphing = 0;
        RelativaPowers.remove(p);
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    // ---------------------------------------------------------------- tick, login, respawn

    public static void tick(ServerPlayer p) {
        RelativaData d = data(p);
        double speed = RelativaSkills.trackMotion(p);
        RelativaRite.tick(p, d);
        if (!d.unlocked) {
            tickPapers(p, d, speed);
            return;
        }
        if (d.transformed && (ShazamPowers.isTransformed(p) || ThanosAbilities.active(p))) {
            dropForm(p, d);   // jadi juara lain lewat jalan lain: wujud RELATIVA lepas
        }
        if (PralayaGod.frozen(p)) {   // waktu dunia dihentikan PRALAYA: RELATIVA ikut membeku
            return;
        }
        if (d.morphing > 0 && --d.morphing == 0) {
            completeMorph(p, d);
        }
        RelativaSkills.tick(p, d);
        for (int i = 0; i < d.cooldowns.length; i++) {
            if (d.cooldowns[i] > 0) {
                d.cooldowns[i]--;
            }
        }
        if (d.dodgeCooldown > 0) {
            d.dodgeCooldown--;
        }
        if (d.transformed && p.isAlive()) {
            float regen = ENERGY_REGEN + (p.tickCount % 20 == 0 && ShazamPowers.isInSun(p) ? ENERGY_SUN * 20f : 0f);
            d.energy = Math.min(RelativaData.MAX_ENERGY, d.energy + regen / 20f);
            if (p.tickCount % 40 == 0 && p.getHealth() < p.getMaxHealth()) {
                p.heal(1f);
            }
        }
        if (p.tickCount % SYNC_EVERY == 0 && (d.transformed || d.coolingDown() || d.morphing > 0)) {
            RelativaNetwork.sync(p);
        }
    }

    public static void onLogin(ServerPlayer p) {
        RelativaData d = data(p);
        d.morphing = 0;
        d.dilationTicks = 0;
        d.tokamakTicks = 0;
        d.entangleTicks = 0;
        d.holeTicks = 0;
        if (d.transformed && (!d.unlocked || ShazamPowers.isTransformed(p) || ThanosAbilities.active(p))) {
            d.transformed = false;
        }
        if (d.transformed) {
            RelativaPowers.apply(p);   // modifier atribut nggak ikut tersimpan, jadi dipasang ulang
        } else {
            RelativaPowers.remove(p);
        }
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    /** Hidup lagi sebagai manusia biasa (sama seperti juara lain); RELATIVA & makalahnya tetap tercatat. */
    public static void onRespawn(ServerPlayer p) {
        RelativaData d = data(p);
        RelativaSkills.endAll(p, d);
        RelativaSkills.clear(p);
        d.transformed = false;
        d.morphing = 0;
        RelativaPowers.remove(p);
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    public static void onLogout(ServerPlayer p) {
        RelativaSkills.clear(p);
        RelativaRite.clear(p);
        PROGRESS.remove(p.getUUID());
    }

    // ---------------------------------------------------------------- empat makalah 1905

    private static void tickPapers(ServerPlayer p, RelativaData d, double speed) {
        if (d.papers == RelativaData.PAPERS_ALL) {
            return;
        }
        int[] pr = PROGRESS.computeIfAbsent(p.getUUID(), id -> new int[4]);
        if (p.tickCount % 10 == 0) {
            pr[3] = hasJournal(p) ? 1 : 0;
            if (pr[3] == 1 && p.isAlive()) {
                if (!d.hasPaper(RelativaData.PAPER_PHOTO) && ShazamPowers.isInSun(p) && (pr[0] += 10) >= PAPER_SUN_TICKS) {
                    writePaper(p, d, RelativaData.PAPER_PHOTO);
                }
                if (!d.hasPaper(RelativaData.PAPER_BROWN) && p.isUnderWater() && (pr[1] += 10) >= PAPER_WATER_TICKS) {
                    writePaper(p, d, RelativaData.PAPER_BROWN);
                }
            }
        }
        if (pr[3] == 1 && !d.hasPaper(RelativaData.PAPER_RELATIVITY) && speed > PAPER_FAST_SPEED
                && ++pr[2] >= PAPER_FAST_TICKS) {
            writePaper(p, d, RelativaData.PAPER_RELATIVITY);
        }
    }

    public static void writePaper(ServerPlayer p, RelativaData d, int paper) {
        if (d.hasPaper(paper) || d.unlocked) {
            return;
        }
        d.papers |= 1 << paper;
        int count = Integer.bitCount(d.papers);
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_PAPER, new Vec3(paper, count, 0));
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.RELATIVA_PAPER.get(), SoundSource.PLAYERS,
                1.2f, 1f);
        p.displayClientMessage(Component.translatable("message.shazammod.relativa.paper_written", paperName(paper), count)
                .withStyle(ChatFormatting.AQUA), false);
        if (d.papers == RelativaData.PAPERS_ALL) {
            p.displayClientMessage(Component.translatable("message.shazammod.relativa.papers_done")
                    .withStyle(ChatFormatting.GOLD), false);
        }
        RelativaNetwork.sync(p);
    }

    // ---------------------------------------------------------------- damage: Tinju Foton, Superposisi, makalah IV

    public static void guard(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        DamageSource source = event.getSource();
        if (source.getEntity() instanceof ServerPlayer attacker && attacker != victim && source.getDirectEntity() == attacker
                && source.is(DamageTypes.PLAYER_ATTACK) && active(attacker)) {
            // Tinju Foton: tiap pukulan melepas paket foton; makin cepat bergerak makin berat (massa relativistik)
            float boost = 1f + (float) Math.min(0.8, RelativaSkills.speed(attacker));
            event.setAmount(event.getAmount() * boost + PUNCH_BONUS);
            ShazamNetwork.playAnim(attacker, ShazamAnim.PHYS_PUNCH, chest(victim));
        }
        if (!(victim instanceof ServerPlayer p)) {
            return;
        }
        RelativaData d = data(p);
        if (!d.unlocked && source.is(DamageTypeTags.IS_EXPLOSION) && hasJournal(p)) {
            writePaper(p, d, RelativaData.PAPER_EMC);   // Makalah IV: massa jadi energi, kamu merasakannya sendiri
        }
        if (RelativaRite.isRunning(p) && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            event.setCanceled(true);   // selama Eksperimen Pikiran pikiranmu jauh dari badanmu
            return;
        }
        if (!d.transformed || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || ThanosSnap.isSnap(source)) {
            return;
        }
        if (d.dodgeCooldown <= 0 && (source.getEntity() != null || source.getDirectEntity() != null)
                && p.getRandom().nextFloat() < DODGE_CHANCE) {
            // Superposisi: badanmu berada di dua tempat sekaligus, serangannya "lewat" di salah satunya
            event.setCanceled(true);
            d.dodgeCooldown = DODGE_GAP;
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_DODGE, p.position());
            p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.RELATIVA_DODGE.get(),
                    SoundSource.PLAYERS, 1.0f, 1f);
        }
    }
}
