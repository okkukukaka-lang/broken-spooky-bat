package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Lightning;

import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * 0.66 Huruf garis-cahaya RELATIVA: persamaan (E=mc², E=hν, t'=γt, Δx·Δp≥ħ/2, ...) ditulis dengan goresan cahaya di udara,
 * bukan teks Minecraft, jadi ikut menyala & bisa "ditulis" pelan-pelan (ujung pena berpendar). Tiap huruf = beberapa
 * goresan (titik x, y di kotak satuan: tinggi huruf besar 1, garis dasar 0).
 */
final class RelativaGlyphs {
    private RelativaGlyphs() {}

    private static final Map<Character, float[][]> FONT = new HashMap<>();
    private static final Map<Character, Float> ADVANCE = new HashMap<>();
    private static final Map<String, Text> CACHE = new HashMap<>();
    private static final Vec3 UP = new Vec3(0, 1, 0);

    static {
        g('E', 0.62f, new float[] {0.5f, 1, 0, 1, 0, 0, 0.5f, 0}, new float[] {0, 0.52f, 0.4f, 0.52f});
        g('=', 0.62f, new float[] {0.02f, 0.34f, 0.5f, 0.34f}, new float[] {0.02f, 0.62f, 0.5f, 0.62f});
        g('m', 0.7f, new float[] {0, 0, 0, 0.62f},
                new float[] {0, 0.46f, 0.08f, 0.58f, 0.18f, 0.62f, 0.26f, 0.56f, 0.28f, 0.44f, 0.28f, 0},
                new float[] {0.28f, 0.46f, 0.36f, 0.58f, 0.46f, 0.62f, 0.54f, 0.56f, 0.56f, 0.44f, 0.56f, 0});
        g('c', 0.6f, arc(0.27f, 0.31f, 0.27f, 0.31f, 40, 320, 14));
        g('²', 0.36f, new float[] {0, 0.86f, 0.04f, 0.96f, 0.14f, 1.0f, 0.24f, 0.96f, 0.27f, 0.88f, 0.24f, 0.8f, 0, 0.6f,
                0.28f, 0.6f});
        g('h', 0.5f, new float[] {0, 0, 0, 1}, new float[] {0, 0.42f, 0.08f, 0.56f, 0.2f, 0.62f, 0.32f, 0.56f, 0.36f, 0.44f,
                0.36f, 0});
        g('ħ', 0.5f, new float[] {0, 0, 0, 1}, new float[] {0, 0.42f, 0.08f, 0.56f, 0.2f, 0.62f, 0.32f, 0.56f, 0.36f, 0.44f,
                0.36f, 0}, new float[] {-0.06f, 0.74f, 0.24f, 0.86f});
        g('ν', 0.52f, new float[] {0, 0.62f, 0.06f, 0.62f, 0.2f, 0}, new float[] {0.2f, 0, 0.3f, 0.2f, 0.37f, 0.42f,
                0.4f, 0.62f});
        g('t', 0.42f, new float[] {0.14f, 0.88f, 0.14f, 0.1f, 0.2f, 0, 0.32f, 0.02f}, new float[] {0, 0.62f, 0.32f, 0.62f});
        g('\'', 0.2f, new float[] {0.09f, 1.0f, 0.03f, 0.74f});
        g('γ', 0.5f, new float[] {0, 0.62f, 0.2f, 0.1f, 0.38f, 0.62f},
                new float[] {0.2f, 0.1f, 0.15f, -0.12f, 0.2f, -0.3f, 0.25f, -0.12f, 0.2f, 0.1f});
        g('ψ', 0.72f, new float[] {0.3f, 0.95f, 0.3f, -0.3f},
                new float[] {0, 0.62f, 0.01f, 0.4f, 0.08f, 0.22f, 0.18f, 0.13f, 0.3f, 0.1f, 0.42f, 0.13f, 0.52f, 0.22f, 0.59f,
                        0.4f, 0.6f, 0.62f});
        g('G', 0.84f, join(arc(0.36f, 0.5f, 0.36f, 0.5f, 40, 352, 18), new float[] {0.72f, 0.42f}),
                new float[] {0.72f, 0.42f, 0.42f, 0.42f});
        g('∞', 0.98f, lemniscate());
        g('Δ', 0.76f, new float[] {0, 0, 0.32f, 1, 0.64f, 0, 0, 0});
        g('x', 0.54f, new float[] {0, 0, 0.42f, 0.62f}, new float[] {0, 0.62f, 0.42f, 0});
        g('·', 0.22f, new float[] {0.06f, 0.33f, 0.12f, 0.39f});
        g('p', 0.52f, new float[] {0, -0.3f, 0, 0.62f}, arc(0.2f, 0.31f, 0.22f, 0.31f, 150, -150, 12));
        g('≥', 0.56f, new float[] {0.02f, 0.82f, 0.44f, 0.6f, 0.02f, 0.38f}, new float[] {0.02f, 0.16f, 0.44f, 0.38f});
        g('/', 0.44f, new float[] {0, 0, 0.36f, 1});
        g('2', 0.52f, new float[] {0.02f, 0.8f, 0.08f, 0.94f, 0.22f, 1.0f, 0.36f, 0.94f, 0.4f, 0.8f, 0.34f, 0.64f, 0, 0,
                0.42f, 0});
        g('0', 0.56f, arc(0.24f, 0.5f, 0.24f, 0.5f, 90, 450, 20));
        g('K', 0.54f, new float[] {0, 0, 0, 1}, new float[] {0.42f, 1, 0, 0.42f}, new float[] {0.12f, 0.54f, 0.44f, 0});
        g('U', 0.6f, new float[] {0, 1, 0, 0.28f, 0.06f, 0.08f, 0.24f, 0, 0.42f, 0.08f, 0.48f, 0.28f, 0.48f, 1});
        g('n', 0.5f, new float[] {0, 0, 0, 0.62f}, new float[] {0, 0.42f, 0.08f, 0.56f, 0.2f, 0.62f, 0.32f, 0.56f, 0.36f,
                0.44f, 0.36f, 0});
        g('+', 0.56f, new float[] {0.02f, 0.45f, 0.46f, 0.45f}, new float[] {0.24f, 0.23f, 0.24f, 0.67f});
        g(' ', 0.34f);
    }

    private static void g(char c, float advance, float[]... strokes) {
        FONT.put(c, strokes);
        ADVANCE.put(c, advance + 0.14f);
    }

    /** Busur elips (derajat, a0 -> a1, boleh menurun), n segmen. */
    private static float[] arc(float cx, float cy, float rx, float ry, float a0, float a1, int n) {
        float[] out = new float[(n + 1) * 2];
        for (int i = 0; i <= n; i++) {
            double a = Math.toRadians(a0 + (a1 - a0) * i / (double) n);
            out[i * 2] = (float) (cx + Math.cos(a) * rx);
            out[i * 2 + 1] = (float) (cy + Math.sin(a) * ry);
        }
        return out;
    }

    private static float[] join(float[] a, float[] b) {
        float[] out = new float[a.length + b.length];
        System.arraycopy(a, 0, out, 0, a.length);
        System.arraycopy(b, 0, out, a.length, b.length);
        return out;
    }

    private static float[] lemniscate() {
        int n = 32;
        float[] out = new float[(n + 1) * 2];
        for (int i = 0; i <= n; i++) {
            double t = Math.PI * 2.0 * i / n;
            double s = Math.sin(t), c = Math.cos(t), k = 1.0 + s * s;
            out[i * 2] = (float) (0.42 + 0.42 * c / k);
            out[i * 2 + 1] = (float) (0.4 + 0.5 * s * c / k);
        }
        return out;
    }

    // ------------------------------------------------------------------ tata letak

    /** Teks yang sudah ditata: goresan di koordinat lokal (x mulai 0), panjang tiap goresan, lebar total. */
    static final class Text {
        final List<float[]> strokes = new ArrayList<>();
        final List<float[]> cumulative = new ArrayList<>();
        float total;
        float width;
    }

    static Text text(String s) {
        Text cached = CACHE.get(s);
        if (cached != null) {
            return cached;
        }
        Text t = new Text();
        float cursor = 0f;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            float[][] strokes = FONT.get(c);
            float adv = ADVANCE.getOrDefault(c, 0.5f);
            if (strokes != null) {
                for (float[] st : strokes) {
                    float[] pts = new float[st.length];
                    float[] cum = new float[st.length / 2];
                    float len = 0f;
                    for (int k = 0; k < st.length; k += 2) {
                        pts[k] = st[k] + cursor;
                        pts[k + 1] = st[k + 1];
                        if (k > 0) {
                            len += (float) Math.hypot(pts[k] - pts[k - 2], pts[k + 1] - pts[k - 1]);
                        }
                        cum[k / 2] = len;
                    }
                    t.strokes.add(pts);
                    t.cumulative.add(cum);
                    t.total += len;
                }
            }
            cursor += adv;
        }
        t.width = Math.max(0.01f, cursor - 0.14f);
        CACHE.put(s, t);
        return t;
    }

    /**
     * Gambar teks di bidang (right, up) yang berpusat di o, tinggi huruf size blok. reveal = panjang goresan yang sudah
     * ditulis (Float.MAX_VALUE = semua). Mengembalikan ujung pena (titik terakhir yang ditulis) atau null kalau selesai.
     */
    static Vec3 draw(Draw d, Text t, Vec3 o, Vec3 right, Vec3 up, double size, float width, int rgb, int core, float a,
                     float reveal) {
        if (a <= 0.003f) {
            return null;
        }
        double ox = -t.width * 0.5, oy = -0.5;
        float used = 0f;
        Vec3 pen = null;
        for (int s = 0; s < t.strokes.size(); s++) {
            float[] pts = t.strokes.get(s);
            float[] cum = t.cumulative.get(s);
            int n = pts.length / 2;
            float len = cum[n - 1];
            if (used >= reveal) {
                break;
            }
            float allow = reveal - used;
            int count = 0;
            float[] xyz = new float[(n + 1) * 3];
            for (int k = 0; k < n; k++) {
                double lx, ly;
                if (cum[k] <= allow) {
                    lx = pts[k * 2];
                    ly = pts[k * 2 + 1];
                } else {   // potong di tengah ruas: ujung pena
                    float seg = cum[k] - cum[k - 1];
                    float f = seg < 1.0E-5f ? 1f : (allow - cum[k - 1]) / seg;
                    lx = Mth.lerp(f, pts[k * 2 - 2], pts[k * 2]);
                    ly = Mth.lerp(f, pts[k * 2 - 1], pts[k * 2 + 1]);
                }
                double wx = (lx + ox) * size, wy = (ly + oy) * size;
                xyz[count * 3] = (float) (o.x + right.x * wx + up.x * wy);
                xyz[count * 3 + 1] = (float) (o.y + right.y * wx + up.y * wy);
                xyz[count * 3 + 2] = (float) (o.z + right.z * wx + up.z * wy);
                count++;
                if (cum[k] > allow) {
                    break;
                }
            }
            if (count >= 2) {
                d.polyline(xyz, count, width, width, rgb, core, a, a);
            } else if (count == 1 && n == 1) {
                d.glow(xyz[0], xyz[1], xyz[2], width, rgb, a);
            }
            if (count > 0 && allow < len) {
                pen = new Vec3(xyz[(count - 1) * 3], xyz[(count - 1) * 3 + 1], xyz[(count - 1) * 3 + 2]);
            }
            used += len;
        }
        return reveal < t.total ? pen : null;
    }

    /** Sumbu bidang yang menghadap kamera (billboard): {kanan, atas}. */
    static Vec3[] facing(Draw d, Vec3 o) {
        Vec3 toCam = new Vec3(d.camX - o.x, d.camY - o.y, d.camZ - o.z);
        if (toCam.lengthSqr() < 1.0E-6) {
            return new Vec3[] {new Vec3(1, 0, 0), UP};
        }
        toCam = toCam.normalize();
        Vec3 right = UP.cross(toCam);
        right = right.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : right.normalize();
        return new Vec3[] {right, toCam.cross(right).normalize()};
    }

    /** Bidang tegak yang dibaca dari arah look (menghadap orang yang melihat ke arah look): {kanan, atas}. */
    static Vec3[] readableFrom(Vec3 look) {
        Vec3 f = new Vec3(look.x, 0, look.z);
        f = f.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : f.normalize();
        return new Vec3[] {f.cross(UP).normalize(), UP};
    }

    // ------------------------------------------------------------------ efek

    /**
     * Persamaan yang ditulis goresan cahaya. right/up = null: menghadap kamera. write = lama menulis (tick, 0 = langsung
     * utuh). fly > 0: mulai tick flyAt teksnya terbang mengecil ke flyTo selama fly tick.
     */
    static final class Glyphs extends Effect {
        private final Text text;
        private final Lightning.Anchor at;
        private final Vec3 right, up;
        private final double size, rise;
        private final int rgb, write;
        private int flyAt = -1, fly;
        private Lightning.Anchor flyTo;

        Glyphs(String text, Lightning.Anchor at, Vec3 right, Vec3 up, double size, int rgb, int write, int life, double rise) {
            super(life);
            this.text = text(text);
            this.at = at;
            this.right = right;
            this.up = up;
            this.size = size;
            this.rgb = rgb;
            this.write = write;
            this.rise = rise;
        }

        Glyphs fly(int at, int ticks, Lightning.Anchor to) {
            this.flyAt = at;
            this.fly = Math.max(1, ticks);
            this.flyTo = to;
            return this;
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = RelativaFx.fade(time, life, 3f, Math.min(10f, life * 0.3f));
            Vec3 o = at.at(d.partialTick);
            if (o == null) {
                return;
            }
            o = o.add(0, rise * time, 0);
            double s = size;
            if (flyAt >= 0 && time > flyAt && flyTo != null) {
                Vec3 to = flyTo.at(d.partialTick);
                float f = Mth.clamp((time - flyAt) / fly, 0f, 1f);
                float e = f * f;
                if (to != null) {
                    o = o.lerp(to, e);
                }
                s *= 1.0 - 0.85 * e;
                a *= 1f - 0.3f * e;
            }
            Vec3[] basis = right == null ? facing(d, o) : new Vec3[] {right, up};
            float reveal = write <= 0 ? Float.MAX_VALUE : text.total * Mth.clamp(time / write, 0f, 1f);
            float w = (float) Math.max(0.02, s * 0.11);
            Vec3 pen = draw(d, text, o, basis[0], basis[1], s, w, rgb, RelativaFx.hot(rgb), a, reveal);
            if (pen != null) {
                d.flare(pen.x, pen.y, pen.z, (float) (s * 0.35), rgb, a);
            }
        }
    }
}
