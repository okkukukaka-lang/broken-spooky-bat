package com.shazammod.client.anim;

import java.util.Map;

import com.shazammod.ShazamAnim;

/**
 * 0.66 Gerakan badan RELATIVA (orisinal, fisika Einstein), didaftarkan ke Clips.CLIPS. Gaya geraknya seorang fisikawan
 * yang bertarung: tangan kanan menulis persamaan di udara, telapak yang "menekan" ruang-waktu, jentikan neutron, dan
 * hentakan OUT_BACK tepat di tick puncak (sama dengan server, efek RelativaFx, dan SFX relativa_*). Lengan kanan = tangan
 * kuasa (efek keluar dari sini, lihat RelativaFx.hand).
 */
final class RelativaClips {
    private RelativaClips() {}

    static void register(Map<ShazamAnim, Clip> clips) {
        // Eksperimen Pikiran: pose berpikir (telunjuk di dagu), lalu menatap sekeliling, lengan terbuka menerima, persamaan
        // ditarik ke dada (gemetar), dan di REL_RITE_BURST meledak terbuka.
        int rb = ShazamAnim.REL_RITE_BURST;
        clips.put(ShazamAnim.RELATIVA_RITE, Clip.builder(ShazamAnim.REL_RITE_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-112, -34, 0).leftArm(-40, 32, 0).head(18, 0, 0).tilt(4)
                .key(34, Ease.IN_OUT_SINE).rightArm(-116, -36, 0).head(22, 8, 0).shake(0.2f)
                .key(64, Ease.IN_OUT_SINE).rightArm(-44, 0, 38).leftArm(-44, 0, -38).head(-22, -10, 0).tilt(0).drop(-0.08f)
                .key(100, Ease.IN_OUT_SINE).rightArm(-150, 0, 30).leftArm(-150, 0, -30).head(-36, 0, 0).drop(-0.26f).shake(0.8f)
                .key(rb - 4, Ease.IN_QUAD).rightArm(-72, -50, 0).leftArm(-72, 50, 0).head(12, 0, 0).drop(-0.3f).shake(2.4f)
                .key(rb, Ease.OUT_BACK).rightArm(-100, 0, 82).leftArm(-100, 0, -82).head(-32, 0, 0).tilt(-8).drop(-0.42f)
                        .shake(1.4f)
                .key(rb + 12, Ease.IN_OUT_SINE).rightArm(-30, 0, 30).leftArm(-30, 0, -30).head(-6, 0, 0).tilt(0).drop(-0.1f)
                        .shake(0.2f)
                .key(ShazamAnim.REL_RITE_TICKS, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).drop(0f)
                        .shake(0f)
                .fade(4, 10).build());

        // Berubah: telunjuk kanan menulis E=mc² di udara (bolak-balik kecil), lalu tangan ditarik ke dada (gemetar), dan di
        // REL_MORPH_BURST dada dibusungkan, kedua lengan terbuka.
        int mb = ShazamAnim.REL_MORPH_BURST;
        clips.put(ShazamAnim.RELATIVA_TRANSFORM, writing(Clip.builder(ShazamAnim.REL_MORPH_TICKS), 2, 18)
                .key(mb - 4, Ease.IN_QUAD).rightArm(-62, -46, 0).leftArm(-30, 20, 0).head(14, 0, 0).tilt(6).shake(2.2f)
                .key(mb, Ease.OUT_BACK).rightArm(-60, 0, 62).leftArm(-60, 0, -62).head(-26, 0, 0).tilt(-8).drop(-0.08f)
                        .shake(1.0f)
                .key(ShazamAnim.REL_MORPH_TICKS, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0)
                        .drop(0f).shake(0f)
                .fade(2, 8).build());

        clips.put(ShazamAnim.RELATIVA_REVERT, Clip.builder(ShazamAnim.REL_REVERT_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-58, -40, 0).leftArm(-58, 40, 0).head(14, 0, 0)
                .key(6, Ease.IN_OUT_SINE).shake(0.8f)
                .key(ShazamAnim.REL_REVERT_TICKS, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).shake(0f)
                .fade(1, 6).build());

        // Z Lesat Cahaya: merunduk, lalu badan lurus seperti berkas cahaya (lengan terseret ke belakang).
        int da = ShazamAnim.REL_DASH_AT;
        clips.put(ShazamAnim.RELATIVA_DASH, Clip.builder(da + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(30, 0, 20).leftArm(30, 0, -20).head(-6, 0, 0).tilt(16).drop(0.14f)
                        .rightLeg(-20, 0, 2).leftLeg(16, 0, -2)
                .key(da - 1, Ease.IN_QUAD).tilt(20).drop(0.18f).shake(0.6f)
                .key(da, Ease.OUT_BACK).rightArm(62, 0, 14).leftArm(62, 0, -14).head(-14, 0, 0).tilt(32).drop(0.05f)
                        .rightLeg(-34, 0, 2).leftLeg(30, 0, -2).shake(0f)
                .key(da + 10, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f)
                        .rightLeg(0, 0, 2).leftLeg(0, 0, -2)
                .fade(1, 5).build());

        // Shift+Z Dilatasi Waktu: telunjuk kanan menggambar lingkaran jam, lalu kedua telapak terbuka menahan waktu.
        int dh = ShazamAnim.REL_DILATION_HIT;
        clips.put(ShazamAnim.RELATIVA_DILATION, Clip.builder(dh + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-90, 0, 0).leftArm(-20, 0, -14).head(4, 0, 0)
                .key(3, Ease.IN_OUT_SINE).rightArm(-122, -18, 0)
                .key(6, Ease.IN_OUT_SINE).rightArm(-96, -40, 0)
                .key(8, Ease.IN_OUT_SINE).rightArm(-70, -16, 0).shake(0.8f)
                .key(dh, Ease.OUT_BACK).rightArm(-84, 0, 58).leftArm(-84, 0, -58).head(-12, 0, 0).tilt(-4).shake(0.4f)
                .key(dh + 16, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).shake(0f)
                .fade(1, 6).build());

        // X Lengkung Ruang-Waktu: telapak diangkat, lalu menekan ke bawah-depan menahan lengkungan (makin gemetar), dan di
        // REL_WARP_SLAM dihentak ke bawah.
        int wh = ShazamAnim.REL_WARP_HIT, ws = ShazamAnim.REL_WARP_SLAM;
        clips.put(ShazamAnim.RELATIVA_WARP, Clip.builder(ws + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, 0, 12).leftArm(-24, 0, -20).head(-14, 0, 0)
                .key(wh, Ease.OUT_BACK).rightArm(-64, 0, 4).head(10, 0, 0).tilt(10).drop(0.08f).shake(0.8f).aim(0.5f)
                .key(ws - 4, Ease.IN_QUAD).rightArm(-56, 0, 4).tilt(14).drop(0.12f).shake(2.6f)
                .key(ws, Ease.OUT_BACK).rightArm(-18, 0, 8).leftArm(-30, 0, -40).head(18, 0, 0).tilt(26).drop(0.26f).shake(1.6f)
                        .aim(0f)
                .key(ws + 10, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f).shake(0f)
                .fade(1, 6).build());

        // Shift+X LUBANG HITAM: kedua telapak saling menekan di depan dada (massa dipadatkan, gemetar makin hebat), lalu di
        // REL_BH_FORM didorong lepas ke depan.
        int bf = ShazamAnim.REL_BH_FORM;
        clips.put(ShazamAnim.RELATIVA_BLACKHOLE, Clip.builder(bf + 20)
                .key(0, Ease.OUT_CUBIC).rightArm(-86, 34, 0).leftArm(-86, -34, 0).head(6, 0, 0).tilt(4).aim(0.4f)
                .key(10, Ease.IN_OUT_SINE).rightArm(-90, 40, 0).leftArm(-90, -40, 0).head(14, 0, 0).tilt(8).shake(1.8f)
                .key(bf - 1, Ease.IN_QUAD).rightArm(-94, 46, 0).leftArm(-94, -46, 0).head(18, 0, 0).tilt(10).drop(0.1f)
                        .shake(3.6f)
                .key(bf, Ease.OUT_BACK).rightArm(-104, -8, 22).leftArm(-104, 8, -22).head(-12, 0, 0).tilt(-6).drop(0f)
                        .shake(1.2f).aim(0.9f)
                .key(bf + 20, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).shake(0f).aim(0f)
                .fade(1, 7).build());

        // C Terowongan Kuantum: badan condong menembus, lengan terulur.
        int ta = ShazamAnim.REL_TUNNEL_AT;
        clips.put(ShazamAnim.RELATIVA_TUNNEL, Clip.builder(ta + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(-100, 0, 10).leftArm(-100, 0, -10).head(6, 0, 0).tilt(10).shake(0.6f)
                .key(ta - 1, Ease.IN_QUAD).tilt(24).drop(0.1f).shake(1.4f)
                .key(ta, Ease.OUT_BACK).rightArm(-30, 0, 34).leftArm(-30, 0, -34).head(-4, 0, 0).tilt(-4).drop(0f).shake(0f)
                .key(ta + 10, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0)
                .fade(1, 5).build());

        // Shift+C Keterikatan Kuantum: kedua telunjuk bersentuhan di depan dada, lalu ditarik berpisah.
        int eh = ShazamAnim.REL_ENTANGLE_HIT;
        clips.put(ShazamAnim.RELATIVA_ENTANGLE, Clip.builder(eh + 14)
                .key(0, Ease.OUT_CUBIC).rightArm(-92, 30, 0).leftArm(-92, -30, 0).head(8, 0, 0)
                .key(eh - 1, Ease.IN_QUAD).rightArm(-94, 34, 0).leftArm(-94, -34, 0).shake(1.6f)
                .key(eh, Ease.OUT_BACK).rightArm(-92, 0, 72).leftArm(-92, 0, -72).head(-6, 0, 0).shake(0.4f)
                .key(eh + 14, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).shake(0f)
                .fade(1, 6).build());

        // V Fisi Berantai: pergelangan dikokang, lalu neutron dijentikkan ke sasaran (ikut bidikan).
        int fh = ShazamAnim.REL_FISSION_HIT;
        clips.put(ShazamAnim.RELATIVA_FISSION, Clip.builder(fh + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-78, 0, 6).head(2, 0, 0).twist(-8).aim(0.7f)
                .key(fh - 1, Ease.IN_QUAD).rightArm(-74, 0, 8).twist(-12).shake(0.6f).aim(0.9f)
                .key(fh, Ease.OUT_BACK).rightArm(-98, 0, 0).twist(10).tilt(4).shake(0f).aim(1f)
                .key(fh + 12, Ease.IN_OUT_SINE).rightArm(0, 0, 5).head(0, 0, 0).twist(0).tilt(0).aim(0f)
                .fade(1, 5).build());

        // Shift+V Massa Kritis: lemparan dari atas bahu.
        int cc = ShazamAnim.REL_CRIT_CORE;
        clips.put(ShazamAnim.RELATIVA_CRITICAL, Clip.builder(cc + 14)
                .key(0, Ease.OUT_CUBIC).rightArm(-176, 0, 14).leftArm(-60, 0, -24).head(-10, 0, 0).twist(-22).tilt(-4)
                .key(cc - 2, Ease.IN_QUAD).rightArm(-200, 0, 10).twist(-30).tilt(-8).shake(0.8f)
                .key(cc, Ease.OUT_BACK).rightArm(-70, 0, 6).leftArm(10, 0, -18).head(6, 0, 0).twist(22).tilt(14).shake(0f)
                .key(cc + 14, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).twist(0).tilt(0)
                .fade(1, 6).build());

        // B Fusi Bintang: kedua telapak menangkup dua proton (gemetar), lalu bintang mini didorong ke depan.
        int ft = ShazamAnim.REL_FUSION_THROW;
        clips.put(ShazamAnim.RELATIVA_FUSION, Clip.builder(ft + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-72, 36, 0).leftArm(-72, -36, 0).head(12, 0, 0).tilt(4)
                .key(ft - 2, Ease.IN_QUAD).rightArm(-76, 42, 0).leftArm(-76, -42, 0).head(16, 0, 0).shake(2.2f)
                .key(ft, Ease.OUT_BACK).rightArm(-96, 0, 0).leftArm(-26, 0, -30).head(-2, 0, 0).twist(14).tilt(8).shake(0f)
                        .aim(1f)
                .key(ft + 12, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).twist(0).tilt(0).aim(0f)
                .fade(1, 6).build());

        // Shift+B Tokamak: lengan menyilang, lalu dibentangkan menyamping (sikap T) saat cincin plasma menyala.
        int kh = ShazamAnim.REL_TOKAMAK_HIT;
        clips.put(ShazamAnim.RELATIVA_TOKAMAK, Clip.builder(kh + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-82, 42, 0).leftArm(-82, -42, 0).head(10, 0, 0).tilt(4)
                .key(kh - 1, Ease.IN_QUAD).shake(1.6f).drop(0.06f)
                .key(kh, Ease.OUT_BACK).rightArm(-4, 0, 88).leftArm(-4, 0, -88).head(-14, 0, 0).tilt(-4).drop(-0.06f).shake(0.6f)
                .key(kh + 16, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f).shake(0f)
                .fade(1, 7).build());

        // N E=mc²: menulis persamaan di udara, lalu dilempar ke sasaran (REL_EMC_WRITE + 2), dan kepalan digenggam saat massa
        // sasaran dikonversi (REL_EMC_HIT).
        int ew = ShazamAnim.REL_EMC_WRITE, ec = ShazamAnim.REL_EMC_HIT;
        clips.put(ShazamAnim.RELATIVA_EMC, writing(Clip.builder(ec + 12), 1, ew)
                .key(ew + 2, Ease.OUT_BACK).rightArm(-100, 0, 0).leftArm(-20, 0, -20).head(0, 0, 0).twist(12).tilt(6)
                        .shake(0f).aim(1f)
                .key(ec - 1, Ease.IN_QUAD).rightArm(-96, 0, 0).shake(1.2f)
                .key(ec, Ease.OUT_BACK).rightArm(-84, -12, 0).twist(-6).tilt(-2).shake(1.6f)
                .key(ec + 12, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).twist(0).tilt(0).shake(0f).aim(0f)
                .fade(1, 6).build());

        // Shift+N Anihilasi: kedua tangan dari samping dipertemukan di depan, lalu terpental berlawanan (sinar gamma ke
        // depan & ke belakang).
        int aa = ShazamAnim.REL_ANNIHILATE_AT, at = ShazamAnim.REL_ANNIHILATE_TICKS;
        clips.put(ShazamAnim.RELATIVA_ANNIHILATE, Clip.builder(aa + at + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(-64, 0, 54).leftArm(-64, 0, -54).head(6, 0, 0)
                .key(aa - 2, Ease.IN_QUAD).rightArm(-92, 24, 0).leftArm(-92, -24, 0).head(12, 0, 0).shake(2.6f)
                .key(aa, Ease.OUT_BACK).rightArm(-96, 0, 0).leftArm(44, 0, -16).head(-4, 0, 0).twist(10).tilt(-4).shake(1.4f)
                        .aim(1f)
                .key(aa + at, Ease.LINEAR).shake(0.6f)
                .key(aa + at + 8, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).twist(0).tilt(0).shake(0f)
                        .aim(0f)
                .fade(1, 6).build());

        // R Teori Medan Terpadu: semadi, badan terangkat, lengan naik, keempat gaya dipertemukan di atas kepala (gemetar),
        // lalu di REL_UNIFIED_HIT meledak terbuka; turun pelan.
        int uh = ShazamAnim.REL_UNIFIED_HIT;
        clips.put(ShazamAnim.RELATIVA_UNIFIED, Clip.builder(ShazamAnim.REL_UNIFIED_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-20, 0, 18).leftArm(-20, 0, -18).head(20, 0, 0).drop(0f)
                .key(20, Ease.IN_OUT_SINE).rightArm(-90, 0, 64).leftArm(-90, 0, -64).head(0, 0, 0).drop(-0.4f).shake(0.3f)
                .key(42, Ease.IN_OUT_SINE).rightArm(-160, 0, 26).leftArm(-160, 0, -26).head(-26, 0, 0).drop(-0.62f).shake(0.9f)
                .key(uh - 4, Ease.IN_QUAD).rightArm(-176, 0, 4).leftArm(-176, 0, -4).head(-34, 0, 0).drop(-0.7f).shake(3.6f)
                .key(uh, Ease.OUT_BACK).rightArm(-100, 0, 86).leftArm(-100, 0, -86).head(-38, 0, 0).tilt(-10).drop(-0.78f)
                        .shake(1.6f)
                .key(uh + 14, Ease.IN_OUT_SINE).rightArm(-40, 0, 40).leftArm(-40, 0, -40).head(-8, 0, 0).tilt(-2).drop(-0.3f)
                        .shake(0.3f)
                .key(ShazamAnim.REL_UNIFIED_TICKS, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0)
                        .drop(0f).shake(0f)
                .fade(3, 10).build());

        // Shift+R Kondensat Bose-Einstein: merendah, telapak kanan menempel ke tanah saat suhu jatuh ke nol mutlak.
        int bh = ShazamAnim.REL_BEC_HIT;
        clips.put(ShazamAnim.RELATIVA_BEC, Clip.builder(bh + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-40, 0, 12).leftArm(-24, 0, -28).head(18, 0, 0).tilt(10).drop(0.12f)
                .key(bh - 2, Ease.IN_QUAD).rightArm(-26, 0, 6).head(26, 0, 0).tilt(26).drop(0.42f).shake(1.6f)
                        .rightLeg(-50, 0, 6).leftLeg(20, 0, -6)
                .key(bh, Ease.OUT_BACK).rightArm(-14, 0, 4).leftArm(-40, 0, -50).head(18, 0, 0).tilt(30).drop(0.5f).shake(0.8f)
                .key(bh + 8, Ease.LINEAR).shake(0.2f)
                .key(bh + 16, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f).shake(0f)
                        .rightLeg(0, 0, 2).leftLeg(0, 0, -2)
                .fade(1, 7).build());

        // M Efek Fotolistrik: telapak kanan ke depan, terhentak kecil tiap foton.
        int pf = ShazamAnim.REL_PHOTO_FIRST, pg = ShazamAnim.REL_PHOTO_GAP, pn = ShazamAnim.REL_PHOTO_COUNT;
        Clip.Builder photo = Clip.builder(pf + pn * pg + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(-90, 0, 0).leftArm(-14, 0, -18).head(2, 0, 0).aim(0.9f);
        for (int k = 0; k < pn; k++) {
            photo.key(pf + k * pg, Ease.OUT_BACK).rightArm(k % 2 == 0 ? -96 : -88, 0, 0).twist(k % 2 == 0 ? 6 : 2).shake(0.6f)
                    .aim(1f);
        }
        clips.put(ShazamAnim.RELATIVA_PHOTO, photo
                .key(pf + pn * pg + 8, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).twist(0).shake(0f)
                        .aim(0f)
                .fade(1, 5).build());

        // Shift+M Laser: telapak kanan ke depan, tangan kiri menahan pergelangan, lalu sinar koheren ditahan.
        int lc = ShazamAnim.REL_LASER_CHARGE, lt = ShazamAnim.REL_LASER_TICKS;
        clips.put(ShazamAnim.RELATIVA_LASER, Clip.builder(lc + lt + 6)
                .key(0, Ease.OUT_CUBIC).rightArm(-90, 0, 0).leftArm(-82, 40, 0).head(4, 0, 0).aim(1f)
                .key(lc - 1, Ease.IN_QUAD).shake(1.6f)
                .key(lc, Ease.OUT_BACK).rightArm(-94, 0, 0).leftArm(-86, 38, 0).tilt(-3).shake(0.9f).aim(1f)
                .key(lc + lt, Ease.LINEAR).shake(0.7f)
                .key(lc + lt + 6, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).shake(0f).aim(0f)
                .fade(1, 5).build());

        // J Gelombang Gravitasi: merunduk, lompat kecil, lalu menghentak tanah.
        int gh = ShazamAnim.REL_GWAVE_HIT;
        clips.put(ShazamAnim.RELATIVA_GWAVE, Clip.builder(gh + 14)
                .key(0, Ease.OUT_CUBIC).rightArm(20, 0, 18).leftArm(20, 0, -18).head(12, 0, 0).tilt(10).drop(0.16f)
                .key(gh - 3, Ease.OUT_QUAD).rightArm(-130, 0, 30).leftArm(-130, 0, -30).head(-16, 0, 0).tilt(-4).drop(-0.32f)
                        .legs(6)
                .key(gh, Ease.OUT_BACK).rightArm(-30, 0, 52).leftArm(-30, 0, -52).head(20, 0, 0).tilt(18).drop(0.34f).legs(12)
                        .shake(2.2f)
                .key(gh + 14, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f).legs(2)
                        .shake(0f)
                .fade(1, 6).build());

        // Shift+J Gerak Brown: badan bergetar, lengan tersentak ke arah acak tiap lompatan.
        int bg = ShazamAnim.REL_BROWN_GAP, bn = ShazamAnim.REL_BROWN_COUNT;
        Clip.Builder brown = Clip.builder(2 + bn * bg + 6)
                .key(0, Ease.OUT_CUBIC).rightArm(-40, 0, 30).leftArm(-40, 0, -30).shake(2.4f);
        float[][] jolt = {{-60, 40, -20, -50}, {-20, 60, -70, -30}, {-80, 20, -30, -70}, {-30, 70, -60, -20}};
        for (int k = 0; k < bn; k++) {
            float[] j = jolt[k % jolt.length];
            brown.key(2 + k * bg, Ease.OUT_BACK).rightArm(j[0], 0, j[1]).leftArm(j[2], 0, j[3]).lean(k % 2 == 0 ? 8 : -8)
                    .tilt(k % 3 == 0 ? 6 : -2).shake(2.8f);
        }
        clips.put(ShazamAnim.RELATIVA_BROWN, brown
                .key(2 + bn * bg + 6, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).lean(0).tilt(0).shake(0f)
                .fade(1, 5).build());
    }

    /** Telunjuk kanan menulis di udara dari tick from sampai to: bolak-balik kecil seperti menulis E = m c ². */
    private static Clip.Builder writing(Clip.Builder b, int from, int to) {
        b.key(0, Ease.OUT_CUBIC).rightArm(-96, 0, 0).leftArm(-22, 0, -16).head(6, 0, 0).aim(0.6f);
        float step = (to - from) / 6f;
        float[][] strokes = {{-104, -18}, {-88, -8}, {-100, 6}, {-90, 14}, {-108, 22}, {-94, 10}};
        for (int i = 0; i < strokes.length; i++) {
            b.key(from + step * (i + 1), Ease.IN_OUT_SINE).rightArm(strokes[i][0], strokes[i][1], 0).aim(0.6f);
        }
        return b;
    }
}
