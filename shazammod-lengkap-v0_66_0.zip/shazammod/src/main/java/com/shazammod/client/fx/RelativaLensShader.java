package com.shazammod.client.fx;

import java.util.List;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;
import org.slf4j.Logger;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import com.shazammod.ShazamMod;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * 0.66 Lensa gravitasi RELATIVA: shader layar (post-processing) di atas gambar dunia. Cahaya di sekitar lubang hitam
 * dibelokkan seperti lensa titik Schwarzschild (pendekatan lensa tipis, beta = theta - thetaE^2 / theta): latar di belakangnya
 * membentuk cincin Einstein, bagian belakang piringan akresi "terangkat" melingkari bayangan hitam, dan ada cincin foton
 * tipis di tepi bayangan. Dipakai juga (lebih lemah) oleh Lengkung Ruang-Waktu & singularitas Teori Medan Terpadu, dan untuk
 * aberasi relativistik + pergeseran Doppler di layar sendiri saat Lesat Cahaya. Kalau shader-nya gagal dimuat (driver / mod
 * shader lain), RelativaEffects menggambar bayangan & cincinnya sendiri di dunia.
 */
public final class RelativaLensShader {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final ResourceLocation CHAIN = ResourceLocation.fromNamespaceAndPath(ShazamMod.MODID,
            "shaders/post/relativa_lens.json");

    private static PostChain chain;
    private static boolean failed;
    private static boolean checked, pack;
    private static int width = -1, height = -1;

    private RelativaLensShader() {}

    /** Shader bisa dipakai (belum pernah gagal & nggak ada shader pack): bayangan lubang hitam diurus shader. */
    public static boolean usable() {
        if (!checked) {
            checked = true;
            pack = shaderPackInUse();
        }
        return !failed && !pack;
    }

    private static boolean shaderPackInUse() {
        try {
            Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Object instance = api.getMethod("getInstance").invoke(null);
            return Boolean.TRUE.equals(api.getMethod("isShaderPackInUse").invoke(instance));
        } catch (Throwable notInstalled) {
            return false;
        }
    }

    /** Dipanggil paling akhir di RenderLevelStageEvent (prioritas LOWEST), cuma di tahap AFTER_LEVEL. */
    public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL) {
            return;
        }
        float pt = event.getPartialTick().getGameTimeDeltaPartialTick(true);
        float aberration = RelativaFx.aberration(pt);
        List<float[]> lenses = RelativaFx.lenses(pt);
        if (lenses.isEmpty() && aberration <= 0.001f) {
            close();
            return;
        }
        if (!usable()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        // lensa terkuat di layar: {pusat x, pusat y, jari-jari Einstein, bayangan, cincin} dalam satuan tinggi layar
        float[] best = null;
        float bestSize = 0f;
        for (float[] l : lenses) {
            float[] s = project(event, l);
            if (s != null && s[2] > bestSize) {
                bestSize = s[2];
                best = s;
            }
        }
        if (best == null && aberration <= 0.001f) {
            return;
        }
        RenderTarget main = mc.getMainRenderTarget();
        try {
            if (chain == null) {
                chain = new PostChain(mc.getTextureManager(), mc.getResourceManager(), main, CHAIN);
                width = -1;
                height = -1;
            }
            if (main.width != width || main.height != height) {
                width = main.width;
                height = main.height;
                chain.resize(width, height);
            }
            float clock = mc.level != null ? ((mc.level.getGameTime() % 2000L) + pt) / 20f : 0f;
            chain.setUniform("Clock", clock);
            chain.setUniform("CenterX", best != null ? best[0] : 0.5f);
            chain.setUniform("CenterY", best != null ? best[1] : 0.5f);
            chain.setUniform("Lens", best != null ? best[2] : 0f);
            chain.setUniform("Shadow", best != null ? best[3] : 0f);
            chain.setUniform("Ring", best != null ? best[4] : 0f);
            chain.setUniform("Aberration", aberration);
            chain.setUniform("Doppler", aberration * 0.8f);
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.resetTextureMatrix();
            chain.process(pt);
        } catch (Exception e) {
            failed = true;
            LOGGER.warn("RELATIVA: shader lensa gravitasi gagal dipakai, bayangan lubang hitam digambar biasa", e);
            close();
        } finally {
            main.bindWrite(true);
            RenderSystem.enableDepthTest();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
        }
    }

    /**
     * Lensa {x, y, z, Einstein, bayangan, cincin, kuat} (dunia) ke layar: {x, y, Einstein, bayangan, cincin} (0..1, satuan
     * tinggi layar), atau null kalau di belakang kamera / terlalu jauh di luar layar. Lensa yang terlalu dekat dengan kamera
     * dilemahkan supaya layar nggak melengkung seluruhnya.
     */
    private static float[] project(RenderLevelStageEvent event, float[] l) {
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        Vector4f v = new Vector4f((float) (l[0] - cam.x), (float) (l[1] - cam.y), (float) (l[2] - cam.z), 1.0f);
        float dist = (float) Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
        v.mul(new Matrix4f().rotation(camera.rotation().conjugate(new Quaternionf())));
        Matrix4f proj = event.getProjectionMatrix();
        v.mul(proj);
        if (v.w < 0.05f) {
            return null;
        }
        float x = v.x / v.w * 0.5f + 0.5f, y = v.y / v.w * 0.5f + 0.5f;
        if (x < -0.6f || x > 1.6f || y < -0.6f || y > 1.6f) {
            return null;
        }
        float near = Mth.clamp((dist - l[3] * 1.5f) / (l[3] * 2.5f), 0f, 1f);   // terlalu dekat kamera: memudar
        float k = l[6] * near;
        if (k <= 0.01f) {
            return null;
        }
        float scale = Math.abs(proj.m11()) / v.w * 0.5f;
        return new float[] {x, y, Math.min(0.6f, l[3] * scale) * k, Math.min(0.3f, l[4] * scale) * k, l[5] * k};
    }

    /** Efeknya selesai / keluar world: shader dilepas (dibuat lagi waktu dipakai lagi). */
    public static void close() {
        if (chain != null) {
            try {
                chain.close();
            } catch (RuntimeException ignored) {
                // melepas shader nggak boleh bikin game crash
            }
            chain = null;
        }
        width = -1;
        height = -1;
    }
}
