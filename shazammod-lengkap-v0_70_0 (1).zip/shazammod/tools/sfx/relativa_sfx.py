"""SFX RELATIVA (0.66, karakter orisinal bertema fisika Einstein). Dibuat dari nol dengan synth.py (+ aksara_sfx.py).

    python3 tools/sfx/relativa_sfx.py src/main/resources/assets/shazammod/sounds [nama ...]

Ciri suaranya: SAINS. Nada kaca yang jernih (foton, atom, elektron yang mengorbit), dengung listrik & kumparan magnet,
klik pencacah Geiger, kicau gelombang gravitasi ala LIGO (frekuensinya naik makin cepat sampai dua massa menyatu), detak
jam yang melambat (dilatasi waktu), dan biola di Eksperimen Pikiran (Einstein memang pemain biola). Elektron & positron
bertemu di 511 Hz (energi diamnya 511 keV), lalu dua sinar gamma. Kondensat Bose-Einstein: semua nada jatuh ke SATU nada
yang sama (semua boson di keadaan dasar yang sama). Puncaknya dikunci ke tick ShazamAnim.REL_* (20 tick = 1 dtk), jadi
putar di pitch 1:

    relativa_rite 7,0 dtk | relativa_transform 1,3 | relativa_dash 0,2 | relativa_dilation 0,5 | relativa_warp mulai 0,5,
    hempasan 2,0 | relativa_blackhole 0,9 | relativa_tunnel muncul lagi 0,4 | relativa_entangle 0,5 | relativa_neutron 0,35
    relativa_critical: inti tiba 0,5, dipotong tepat 2,3 (= REL_CRIT_BOOM, ledakannya relativa_nuke) | relativa_fusion 0,7
    relativa_tokamak 0,6 | relativa_emc: tulisan selesai 0,9, dilempar sampai 1,3 | relativa_annihilate 0,8 (+0,6 gamma)
    relativa_unified 3,2 | relativa_bec 0,7 | relativa_photon 6 foton mulai 0,2 tiap 0,1 | relativa_laser menyala 0,5-3,0
    relativa_gwave 0,4 | relativa_brown 8 lompatan mulai 0,1 tiap 0,15 | sisanya langsung (dipicu saat kejadiannya)
    0.67: relativa_light_on waktu berhenti 0,8 | relativa_light_end waktu berjalan 0,6 | relativa_phase_on 1,2 |
    relativa_phase_off 0,7
    0.70: relativa_wormhole robek 0,8 | relativa_wormhole_close implosi 0,6 | relativa_photon_on melesat 0,5 |
    relativa_photon_off 0,4 | relativa_clone terbelah 0,7 | relativa_cloak_on hilang 0,6 | relativa_cloak_off 0,4
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_argv = sys.argv
sys.argv = [sys.argv[0]]
import synth as s                 # noqa: E402
import aksara_sfx as a            # noqa: E402  (alat bantu: clank, place)
sys.argv = _argv

SR = s.SR
place = a.place


def env(dur, tau):
    return s.env_exp(int(dur * SR), tau)


def n_of(dur):
    return int(dur * SR)


def axis(dur):
    return np.arange(n_of(dur)) / SR


# ------------------------------------------------------------------ bahan

def glass(f, dur, rng, tau=0.9):
    """Nada kaca jernih (harmonik murni, seperti harpa kaca): foton, atom, persamaan."""
    return s.bell(f, dur, rng, ((1, 1), (2.0, 0.3), (3.0, 0.12), (4.17, 0.05)), tau, 0.0008)


def blip(dur, f, rng):
    """Bip pendek bernada (anak tangga energi kuantum, tumbukan molekul)."""
    t = axis(dur)
    return (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(4 * np.pi * f * t)) * np.minimum(1, t / 0.003) * np.exp(-t / (dur * 0.35))


def hum(dur, f=60.0):
    """Dengung listrik / kumparan magnet (harmonik jala-jala)."""
    t = axis(dur)
    return (np.sin(2 * np.pi * f * t) + 0.6 * np.sin(4 * np.pi * f * t) + 0.35 * np.sin(6 * np.pi * f * t + 0.5)
            + 0.2 * np.sin(10 * np.pi * f * t + 1.1))


def tick(rng, f=1800.0, amp=1.0):
    """Detak jam saku: klik tajam + resonansi kecil."""
    n = n_of(0.06)
    t = np.arange(n) / SR
    click = s.bp(s.white(n, rng), 2500, 8000) * np.exp(-t / 0.0015)
    wood = np.sin(2 * np.pi * f * t) * np.exp(-t / 0.01) * 0.5 + np.sin(2 * np.pi * f * 2.7 * t) * np.exp(-t / 0.004) * 0.25
    return (click + wood) * amp


def orbit(dur, rng, f=660.0, rates=(5.0, 8.0, 13.0)):
    """Elektron mengitari inti: tiap elektron satu nada yang bergoyang (Doppler) dan mengeras saat mendekat."""
    n = n_of(dur)
    t = np.arange(n) / SR
    y = np.zeros(n)
    for k, r in enumerate(rates):
        w = np.sin(2 * np.pi * r * t + rng.uniform(0, 2 * np.pi))
        y += s.osc(f * (1 + 0.5 * k) * (1 + 0.025 * w), dur) * (0.55 + 0.45 * w)
    return y / len(rates)


def violin(f, dur, rng, att=0.25, rel=0.4):
    """Biola: gergaji dengan vibrato yang tumbuh pelan, desis busur, resonansi badan biola."""
    n = n_of(dur)
    t = np.arange(n) / SR
    vib = 1 + 0.0055 * np.sin(2 * np.pi * 5.6 * t + rng.uniform(0, 6)) * np.clip((t - 0.15) / 0.5, 0, 1)
    saw = s.osc(f * vib, dur, "saw")
    body = (s.bp(saw, 270, 330) * 0.9 + s.bp(saw, 430, 560) * 0.8 + s.bp(saw, 950, 1250) * 0.5
            + s.bp(saw, 2500, 3300) * 0.45 + s.lp(saw, 4000) * 0.15)
    bow = s.bp(s.white(n, rng), 2500, 7500) * 0.03 * (1 + 0.5 * np.sin(2 * np.pi * 3 * t))
    return (body + bow) * s.env_adsr(dur, att, 0.25, 0.85, rel, 1.4)


def flutter(dur, rng):
    """Kertas berdesir / dibalik."""
    n = n_of(dur)
    t = np.arange(n) / SR
    x = s.bp(s.white(n, rng), 900, 7000)
    am = np.clip(0.4 + 0.6 * np.abs(np.sin(2 * np.pi * rng.uniform(16, 24) * t)) ** 3
                 + 0.3 * s.lp(rng.standard_normal(n), 80) * 8, 0, 1.6)
    return x * am * np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 0.8


def scratch(dur, rng):
    """Goresan pena di kertas."""
    k = np.linspace(0, 1, n_of(dur))
    grain = s.crackle(dur, 2600, rng, 1800, 7000, 0.0004) * 0.6
    hiss = s.bp(s.white(n_of(dur), rng), 2500, 6500) * 0.35
    return (grain + hiss) * np.sin(np.pi * k) ** 0.7


def stroke(dur, rng, f0=2600.0, f1=3400.0, wig=0.0):
    """Satu goresan pena CAHAYA di udara: siulan tipis yang meluncur + desis + kilau partikel."""
    n = n_of(dur)
    t = np.arange(n) / SR
    k = np.linspace(0, 1, n)
    f = np.geomspace(f0, f1, n) * (1 + 0.06 * np.sin(2 * np.pi * wig * t))
    whistle = s.osc(f, dur) * 0.25
    hiss = s.bp(s.white(n, rng), 1800, 9000) * 0.45
    sparkle = s.crackle(dur, 260, rng, 5000, 12000, 0.0006) * 0.6
    return (whistle + hiss + sparkle) * np.sin(np.pi * k) ** 0.5


# goresan "E = m c ²": (mulai, lama) relatif terhadap lama menulis, nada awal/akhir siulan, goyangan (huruf m)
EMC_STROKES = ((0.00, 0.10, 2300, 3000, 0), (0.11, 0.05, 2900, 3000, 0), (0.17, 0.05, 2900, 3000, 0),   # E
               (0.27, 0.05, 3100, 3200, 0), (0.34, 0.05, 3100, 3200, 0),                              # =
               (0.44, 0.18, 2300, 3300, 14), (0.66, 0.12, 3500, 2500, 0), (0.82, 0.10, 3800, 4400, 0))  # m c ²


def write(rng, start, length, amp=1.0):
    """E = mc² ditulis dengan cahaya mulai detik start, selama length detik."""
    return [(start + st * length, stroke(d * length, rng, f0, f1, wig) * amp * 0.5) for st, d, f0, f1, wig in EMC_STROKES]


def geiger(dur, rng, rate_curve, amp=1.0):
    """Pencacah Geiger: klik tajam acak (proses Poisson), kerapatannya mengikuti kurva (klik per detik)."""
    n = n_of(dur)
    y = np.zeros(n)
    curve = np.interp(np.arange(n), np.linspace(0, n - 1, len(rate_curve)), np.asarray(rate_curve, float))
    k = n_of(0.01)
    tk = np.arange(k) / SR
    kernels = [s.hp(rng.standard_normal(k), 1800) * np.exp(-tk / 0.0005) * 0.9
               + np.sin(2 * np.pi * rng.uniform(2500, 3300) * tk) * np.exp(-tk / 0.0014) * 0.45 for _ in range(6)]
    t = rng.exponential(1.0 / max(curve[0], 0.5))
    while t < dur:
        i = min(int(t * SR), n - 1)
        ker = kernels[rng.integers(len(kernels))] * rng.uniform(0.6, 1.0)
        e = min(n, i + k)
        y[i:e] += ker[: e - i]
        t += rng.exponential(1.0 / max(curve[i], 0.5))
    return y * amp


def chirp(dur, f0=70.0, f1=640.0):
    """Kicau gelombang gravitasi (LIGO): f ~ (t_c - t)^(-3/8), amplitudo ~ f^(2/3), makin cepat sampai menyatu."""
    n = n_of(dur)
    t = np.linspace(0, 1, n, endpoint=False)
    tau = 1.0 - t + 0.0025
    f = np.minimum(f0 * (tau / tau[0]) ** (-3.0 / 8.0), f1)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return (np.sin(ph) + 0.4 * np.sin(2 * ph) + 0.15 * np.sin(3 * ph)) * (f / f1) ** (2.0 / 3.0)


def stop_at(y, sec, tail=0.025):
    """Berhenti tepat di detik sec (ekor pendek supaya nggak 'klik')."""
    n = n_of(sec)
    y = s.pad(y, sec + tail).copy()
    y[n:] *= np.exp(-np.arange(len(y) - n) / (tail / 5 * SR))
    return y


def ramp(dur, p=1.0, lo=0.0):
    return lo + (1 - lo) * np.linspace(0, 1, n_of(dur)) ** p


# ------------------------------------------------------------------ resep

def relativa_rite(rng, v):         # Eksperimen Pikiran: biola, detak jam yang melambat saat mengejar cahaya, 4 makalah, puncak 7,0
    T, total = 7.0, 10.0
    items = []
    notes = ((0.3, 293.66, 1.5), (1.7, 369.99, 1.5), (3.1, 440.0, 1.5), (4.5, 587.33, T - 4.5 + 0.15))   # D mayor naik
    for k, (st, f, d) in enumerate(notes):
        x = violin(f, d, rng, 0.25 if k < 3 else 0.5, 0.45 if k < 3 else 0.06) * (0.32 + 0.08 * k)
        if k == 3:
            x = x * np.linspace(0.7, 1.25, len(x))   # nada terakhir ditahan & makin keras sampai puncak
        items.append((st, x))
    t, gap = 0.1, 0.22
    while t < T - 0.15:   # makin mendekati kecepatan cahaya, detak jam (waktu) makin lambat
        items.append((t, tick(rng, 1700, 0.55)))
        t += gap
        gap *= 1.13
    for k, f in enumerate((587.33, 659.25, 880.0, 987.77)):   # empat makalah 1905 mengorbit
        st = 0.9 + k * 1.35
        items += [(st, flutter(0.35, rng) * 0.35), (st + 0.05, glass(f * 2, 2.2, rng, 0.9) * 0.22)]
    d = T - 2.5
    drone = s.supersaw(np.geomspace(73.42, 146.83, n_of(d)), d, 7, 0.008, rng)
    items += [(2.5, s.lp(drone, 1400) * ramp(d, 2.2) * 0.22), (T - 1.6, s.reverse_swell(1.6, rng, 500, 14000) * 0.8),
              (T - 1.4, orbit(1.4, rng, 700, (4.0, 7.0, 11.0)) * ramp(1.4, 2) * 0.25)]
    chord = s.mix(*[glass(f, 3.2, rng, 1.4) * g for f, g in ((587.33, 0.5), (739.99, 0.4), (880.0, 0.4), (1174.66, 0.3), (1760.0, 0.15))])
    burst = s.mix(chord, s.thump(rng, 70, 30, 2.0, 0.5, 0.8, 0.4) * 0.9, s.sub_drop(140, 30, 2.2, 0.6, 7) * 1.2,
                  s.hp(s.white(n_of(0.02), rng), 2500) * env(0.02, 0.004) * 2.5,
                  s.crackle(1.6, 500, rng, 3000, 12000, 0.0015, np.linspace(1, 0, 30) ** 2) * 0.5,
                  orbit(2.6, rng, 880, (6.0, 9.0, 14.0)) * env(2.6, 0.9) * 0.3)
    items.append((T, burst))
    return s.limiter(s.reverb(place(total, *items), 3.0, 0.3, rng=rng, size=2.0), 0.95)


def relativa_transform(rng, v):    # Y: E=mc² ditulis dengan cahaya (0-0,9), dipadatkan (0,9-1,3), jadi atom tepat 1,3 dtk
    T, total = 1.3, 4.2
    items = write(rng, 0.02, 0.84)
    d = T - 0.9
    items += [(0.9, s.reverse_swell(d, rng, 900, 15000) * 0.9),
              (0.9, s.osc(np.geomspace(420, 2400, n_of(d)), d) * ramp(d, 2) * 0.25),
              (0.9, orbit(d, rng, 900, (9.0, 15.0, 23.0)) * ramp(d, 1.5) * 0.3)]
    chord = s.mix(*[glass(f, 2.8, rng, 1.1) * g for f, g in ((659.25, 0.5), (830.61, 0.4), (987.77, 0.35), (1318.51, 0.25))])
    burst = s.mix(chord, s.thump(rng, 75, 32, 1.6, 0.4, 0.8, 0.45), s.sub_drop(150, 32, 1.8, 0.5, 8) * 1.1,
                  s.hp(s.white(n_of(0.015), rng), 3000) * env(0.015, 0.003) * 2.6,
                  orbit(2.6, rng, 660, (5.0, 8.0, 13.0)) * env(2.6, 0.8) * 0.35,
                  s.crackle(1.2, 420, rng, 3000, 12000, 0.0012, np.linspace(1, 0, 30) ** 2) * 0.45)
    items.append((T, burst))
    return s.limiter(s.reverb(place(total, *items), 2.4, 0.28, rng=rng, size=1.6), 0.95)


def relativa_revert(rng, v):       # G: atomnya terurai jadi cahaya: arpeggio kaca turun + desis yang memudar
    total = 2.2
    items = [(k * 0.08, glass(f, 1.4, rng, 0.6) * (0.35 - 0.04 * k)) for k, f in enumerate((1318.51, 987.77, 830.61, 659.25, 493.88))]
    n = n_of(1.2)
    wash = s.sweep_filter(s.white(n, rng), np.geomspace(9000, 600, 64), "low", 0.8) * env(1.2, 0.35) * 0.35
    items += [(0, wash), (0, s.osc(np.geomspace(900, 180, n), 1.2) * env(1.2, 0.3) * 0.2),
              (0, orbit(1.0, rng, 660, (12.0, 8.0, 5.0)) * env(1.0, 0.25) * 0.25)]
    return s.reverb(place(total, *items), 1.8, 0.3, rng=rng)


def relativa_paper(rng, v):        # makalah tertulis di jurnal: goresan pena, kertas dibalik, denting dua nada
    total = 2.0
    items = []
    t = 0.0
    while t < 0.45:
        d = rng.uniform(0.04, 0.09)
        items.append((t, scratch(d, rng) * rng.uniform(0.4, 0.7)))
        t += d + rng.uniform(0.01, 0.03)
    items += [(0.5, flutter(0.3, rng) * 0.5), (0.6, glass(880.0, 1.4, rng, 0.7) * 0.35), (0.72, glass(1318.51, 1.3, rng, 0.7) * 0.3)]
    return s.reverb(place(total, *items), 1.4, 0.25, rng=rng)


def relativa_dash(rng, v):         # Z: merunduk 0,2 dtk (= REL_DASH_AT), lalu MELESAT: desing Doppler, retakan udara, dentum
    T, total = 0.2, 1.6
    items = [(0, s.osc(np.geomspace(700, 2600 + v * 300, n_of(T)), T) * ramp(T, 2) * 0.22),
             (0, s.reverse_swell(T, rng, 1200, 15000) * 0.6)]
    m = n_of(0.5)
    zing = s.osc(np.geomspace(6200 - v * 400, 700, m), 0.5) * env(0.5, 0.08) * 0.35   # nadanya anjlok saat lewat (Doppler)
    zing2 = s.osc(np.geomspace(3100, 350, m), 0.5) * env(0.5, 0.1) * 0.25
    crack = s.mix(s.transient(0.02, 2000, 0.003, 2.4, rng),
                  s.crackle(0.25, 1200, rng, 3000, 12000, 0.001, np.linspace(1, 0, 20) ** 2) * 0.6)
    items += [(T, zing), (T, zing2), (T, crack), (T, s.air_whoosh(0.9, rng, 500, 3800, 400, 1.2, 0.15) * 0.8),
              (T, s.thump(rng, 80, 40, 0.6, 0.12, 0.5, 0.3) * 0.5)]
    return s.limiter(s.reverb(place(total, *items), 1.2, 0.2, rng=rng), 0.95)


def relativa_dilation(rng, v):     # Shift+Z: detak cepat, "vwomp" tepat 0,5 dtk (= REL_DILATION_HIT), lalu detaknya melambat
    T, total = 0.5, 3.6
    items = []
    t = 0.0
    while t < T - 0.02:
        items.append((t, tick(rng, 1900, 0.5)))
        t += 0.085
    m = n_of(1.4)
    vw = s.osc(np.geomspace(340, 48, m), 1.4) * env(1.4, 0.35) * 0.7
    vw = vw + s.lp(s.osc(np.geomspace(170, 30, m), 1.4, "saw"), 600) * env(1.4, 0.3) * 0.3
    items += [(T - 0.35, s.reverse_swell(0.35, rng, 700, 11000) * 0.7), (T, vw), (T, s.thump(rng, 60, 30, 1.2, 0.35, 0.6, 0.2) * 0.6)]
    t, gap, f = T + 0.12, 0.16, 1500.0
    while t < total - 0.5:   # di dalam medan, detak jam makin lambat & makin rendah
        items.append((t, tick(rng, f, 0.45)))
        t += gap
        gap *= 1.45
        f *= 0.85
    d = total - T
    tt = axis(d)
    field = (np.sin(2 * np.pi * 110 * tt) + 0.4 * np.sin(2 * np.pi * 165.5 * tt)) * (0.6 + 0.4 * np.sin(2 * np.pi * 1.3 * tt))
    items.append((T, field * s.env_adsr(d, 0.2, 0.3, 0.6, 1.6) * 0.12))
    return s.limiter(s.reverb(place(total, *items), 2.2, 0.3, rng=rng, size=1.6), 0.95)


def relativa_warp(rng, v):         # X: telapak menekan (0,5 dtk = REL_WARP_HIT), ruang-waktu melengkung & menarik, HEMPASAN 2,0
    H, S, total = 0.5, 2.0, 5.0
    items = [(0, s.reverse_swell(H, rng, 600, 9000) * 0.5), (H, s.thump(rng, 70, 36, 0.8, 0.2, 0.6, 0.3) * 0.6)]
    d = S - H
    n = n_of(d)
    bend = s.lp(s.supersaw(np.geomspace(98, 41, n), d, 5, 0.01, rng), 700) * ramp(d, 1.5, 0.3) * 0.3   # nada membengkok turun
    sub = s.osc(np.geomspace(55, 30, n), d) * ramp(d, 1, 0.2) * 0.6
    creak = s.crackle(d, 60, rng, 150, 1500, 0.01, np.linspace(0.2, 1.0, 20)) * 0.7                 # kisi ruang-waktu berderit
    pull = s.sweep_filter(s.pink(n, rng), np.geomspace(3000, 250, 64), "band", 1.4) * ramp(d, 1, 0.2) * 0.4
    items += [(H, bend), (H, sub), (H, creak), (H, pull), (S - 0.6, s.reverse_swell(0.6, rng, 300, 8000) * 0.7)]
    items.append((S, s.mix(s.impact(rng, 1) * 0.9, s.earth_crack(rng, 0) * 0.5, s.sub_drop(100, 24, 2.2, 0.6, 6))))
    return s.limiter(s.reverb(place(total, *items), 2.6, 0.25, rng=rng, size=1.8), 0.95)


def relativa_blackhole(rng, v):    # Shift+X: massa dimampatkan (0-0,9), IMPLOSI tepat 0,9 dtk (= REL_BH_FORM), cahaya tertelan
    F, total = 0.9, 3.6
    n = n_of(F)
    crunch = s.crackle(F, 400, rng, 300, 6000, 0.002, np.linspace(0.1, 1.0, 30) ** 2) * 0.6        # materi diremas
    rise = s.sweep_filter(s.osc(np.geomspace(90, 900, n), F, "saw"), np.geomspace(300, 4000, 64), "low", 1.6) * ramp(F, 2) * 0.18
    suck = s.reverse_of(s.impact(rng, 0), F) * 0.7                                                 # dentuman dibalik: tersedot
    items = [(0, crunch), (0, rise), (0, suck), (0, s.reverse_swell(F, rng, 400, 13000) * 0.6)]
    voom = s.mix(s.sub_drop(80, 22, 2.6, 0.9, 4) * 1.6, s.thump(rng, 55, 24, 1.8, 0.6, 0.9, 0.2),
                 s.lp(s.brown(n_of(2.6), rng), 140) * s.env_adsr(2.6, 0.02, 0.4, 0.5, 2.0) * 0.6)
    items += [(F, voom), (F, s.osc(np.geomspace(1200, 60, n_of(0.7)), 0.7) * env(0.7, 0.18) * 0.18)]   # siulan tertelan
    return s.limiter(s.reverb(s.sat(place(total, *items), 1.3), 2.4, 0.22, rng=rng, size=2.0), 0.95)


def relativa_blackhole_hum(rng, v):   # lubang hitam hidup 7 dtk (= REL_BH_TICKS): piringan akresi berputar, materi tertelan
    dur = 7.2
    n = n_of(dur)
    t = np.arange(n) / SR
    rumble = s.lp(s.brown(n, rng), 130) * 1.4
    deep = (np.sin(2 * np.pi * 34 * t) + np.sin(2 * np.pi * 35.3 * t) + 0.5 * np.sin(2 * np.pi * 68.5 * t)) * 0.35
    swirl = s.sweep_filter(s.pink(n, rng), 500 + 380 * np.sin(2 * np.pi * 0.9 * np.linspace(0, dur, 300)), "band", 2.2) * 0.5
    infall = s.crackle(dur, 30, rng, 400, 5000, 0.004) * 0.6
    items = [(0, rumble), (0, deep), (0, swirl), (0, infall)]
    for k in range(4):   # sesekali siulan turun: benda "spageti" meluncur ke cakrawala peristiwa
        st = 0.6 + k * 1.55 + rng.uniform(-0.2, 0.2)
        items.append((st, s.osc(np.geomspace(rng.uniform(1600, 2400), 90, n_of(1.1)), 1.1) * env(1.1, 0.35) * 0.12))
    y = place(dur, *items) * s.env_adsr(dur, 0.35, 0.5, 0.85, 1.4, 1.2)
    return s.reverb(s.sat(y, 1.4), 2.0, 0.25, rng=rng)


def relativa_hawking(rng, v):      # lubang hitam menguap habis: desis naik singkat, lalu MELEDAK jadi hujan partikel
    P, total = 0.12, 3.6
    items = [(0, s.osc(np.geomspace(800, 5200, n_of(P)), P) * ramp(P, 2) * 0.25), (0, s.reverse_swell(P, rng, 2000, 15000) * 0.6)]
    burst = s.mix(s.transient(0.02, 1500, 0.004, 2.6, rng), s.thump(rng, 90, 30, 1.6, 0.45, 0.8, 0.4) * 0.9,
                  s.sub_drop(160, 30, 2.0, 0.5, 8),
                  s.crackle(2.2, 1600, rng, 2500, 14000, 0.0012, np.linspace(1, 0, 40) ** 1.5) * 0.7,
                  s.mix(*[glass(f, 2.0, rng, 0.6) * 0.12 for f in (1567.98, 2093.0, 2637.02, 3135.96)]))
    items += [(P, burst), (P + 0.1, s.bp(s.white(n_of(2.4), rng), 3000, 11000) * env(2.4, 0.6) * 0.18)]
    return s.limiter(s.reverb(place(total, *items), 2.4, 0.3, rng=rng, size=1.8), 0.95)


def relativa_tunnel(rng, v):       # C: badan jadi gelombang (nada bertangga = tingkat energi), muncul lagi 0,4 dtk (= REL_TUNNEL_AT)
    A, total = 0.4, 1.4
    steps = (392.0, 523.25, 659.25, 783.99, 1046.5) if v == 0 else (440.0, 587.33, 739.99, 880.0, 1174.66)
    items = [(k * 0.065, blip(0.09, f, rng) * 0.3) for k, f in enumerate(steps)]
    n = n_of(A)
    t = np.arange(n) / SR
    wave = s.osc(700 * (1 + 0.08 * np.sin(2 * np.pi * 22 * t)), A) * np.sin(np.pi * t / A) * 0.18
    phase = s.sweep_filter(s.white(n, rng), 1500 + 1200 * np.sin(2 * np.pi * 5 * np.linspace(0, A, 64)), "band", 4.0) * 0.35
    pop = s.osc(np.geomspace(2200, 300, n_of(0.3)), 0.3) * env(0.3, 0.05) * 0.4
    items += [(0, wave), (0, phase), (A, pop), (A, s.thump(rng, 90, 50, 0.4, 0.08, 0.4, 0.3) * 0.4),
              (A, s.transient(0.01, 3000, 0.002, 1.4, rng))]
    return s.reverb(place(total, *items), 1.2, 0.25, rng=rng)


def relativa_entangle(rng, v):     # Shift+C: dua nada (dua partikel) saling mencari, MENGUNCI tepat 0,5 dtk (= REL_ENTANGLE_HIT)
    H, total = 0.5, 2.8
    n = n_of(H)
    t = np.arange(n) / SR
    p = s.osc(np.geomspace(310, 440, n) * (1 + 0.02 * np.sin(2 * np.pi * 9 * t)), H) * 0.22
    q = s.osc(np.geomspace(990, 660, n) * (1 + 0.02 * np.sin(2 * np.pi * 7 * t + 1)), H) * 0.18
    r = ramp(H, 1.5, 0.3)
    items = [(0, p * r), (0, q * r), (H - 0.3, s.reverse_swell(0.3, rng, 1500, 14000) * 0.45)]
    lock = s.mix(glass(880, 2.0, rng, 0.8) * 0.4, glass(1320, 2.0, rng, 0.8) * 0.35, s.transient(0.01, 3000, 0.002, 1.2, rng))
    tt = axis(2.2)
    trem = 0.6 + 0.4 * np.sin(2 * np.pi * 6 * tt)   # tremolo yang SAMA di kedua nada: keadaan yang berkorelasi
    twin = (np.sin(2 * np.pi * 440 * tt) * 0.2 + np.sin(2 * np.pi * 660 * tt) * 0.16) * trem * env(2.2, 0.7)
    items += [(H, lock), (H, twin), (H, orbit(1.6, rng, 880, (6.0, 6.0)) * env(1.6, 0.5) * 0.15)]
    return s.reverb(place(total, *items), 2.0, 0.3, rng=rng)


def relativa_entangle_pulse(rng, v):   # aksi seram dari jauh: dua denting kembar serempak + percik listrik
    f = (880.0, 987.77)[v % 2]
    y = s.mix(glass(f, 0.9, rng, 0.35) * 0.4, glass(f * 1.5, 0.9, rng, 0.35) * 0.3, s.zap(0.08, rng, 1.0) * 0.35,
              s.transient(0.008, 3000, 0.0015, 1.0, rng))
    return s.reverb(y, 0.9, 0.25, rng=rng)


def relativa_neutron(rng, v):      # V: jentikan jari, neutron melesat, kena sasaran pertama 0,35 dtk (= REL_FISSION_HIT)
    H, total = 0.35, 0.9
    flick = s.mix(s.transient(0.012, 2000, 0.002, 1.6, rng), s.osc(1400, 0.03) * env(0.03, 0.006) * 0.4)
    items = [(0, flick), (0.02, s.zip_by(H - 0.02, rng, 5600, 1800, True) * 0.7), (H, s.transient(0.01, 2500, 0.002, 1.0, rng))]
    return s.reverb(place(total, *items), 0.8, 0.2, rng=rng)


def relativa_fission(rng, v):      # inti membelah: retakan, dua nada yang berpisah (dua inti anak terlempar), sinar gamma, dentum
    dur = 1.4
    f0 = (392.0, 349.23, 440.0)[v % 3]
    n = n_of(0.8)
    up = s.osc(np.geomspace(f0, f0 * 2.4, n), 0.8) * env(0.8, 0.18) * 0.3
    dn = s.osc(np.geomspace(f0, f0 * 0.42, n), 0.8) * env(0.8, 0.2) * 0.3
    crack = s.mix(s.transient(0.015, 1800, 0.003, 2.4, rng), s.bp(s.white(n_of(0.2), rng), 700, 4500) * env(0.2, 0.03) * 0.9)
    gamma = s.bp(s.white(n_of(0.5), rng), 4000, 12000) * env(0.5, 0.08) * 0.4
    y = place(dur, (0, crack), (0, up), (0, dn), (0, gamma), (0, s.thump(rng, 95, 42, 0.7, 0.12, 0.6, 0.4) * 0.7),
              (0.01, s.crackle(0.6, 900, rng, 2000, 10000, 0.001, np.linspace(1, 0, 20) ** 2) * 0.5))
    return s.limiter(s.reverb(y, 1.2, 0.22, rng=rng), 0.95)


def relativa_critical(rng, v):     # Shift+V: inti uranium dilempar (tiba 0,5 = REL_CRIT_CORE), Geiger makin rapat, dengung naik,
    C, B = 0.5, 2.3                #   DIPOTONG tepat 2,3 dtk (= REL_CRIT_BOOM); ledakannya relativa_nuke
    items = [(0, s.air_whoosh(C, rng, 300, 1800, 600, 1.0, 0.7) * 0.6),
             (C, s.mix(a.clank(rng, 330, 0.6, 0.8, 0.15) * 0.5, s.thump(rng, 80, 45, 0.5, 0.1, 0.5, 0.4) * 0.5))]
    d = B - C
    n = n_of(d)
    pulse = 0.55 + 0.45 * np.sin(2 * np.pi * np.cumsum(np.geomspace(3, 26, n)) / SR)
    whine = s.sweep_filter(s.osc(np.geomspace(180, 1300, n), d, "saw"), np.geomspace(400, 5000, 64), "low", 1.5)
    items += [(C, geiger(d, rng, np.geomspace(6, 420, 40)) * 0.9), (C, whine * pulse * ramp(d, 2, 0.1) * 0.2),
              (C, s.osc(np.geomspace(55, 110, n), d) * ramp(d, 1, 0.2) * 0.45), (B - 0.5, s.reverse_swell(0.5, rng, 600, 14000) * 0.8)]
    return stop_at(place(B + 0.05, *items), B)


def relativa_nuke(rng, v):         # ledakan fisi: kilat, DENTUM raksasa, gemuruh bergulung, angin balik saat awan jamur naik
    total = 7.5
    n = n_of(total)
    flash = s.mix(s.transient(0.03, 1200, 0.006, 3.2, rng),
                  s.crackle(0.5, 3000, rng, 2000, 14000, 0.0015, np.linspace(1, 0, 20) ** 2) * 1.2)
    boom = s.mix(s.thump(rng, 55, 20, 3.5, 1.0, 1.0, 0.5) * 1.3, s.sub_drop(110, 18, 4.0, 1.2, 5) * 1.6,
                 s.lp(s.white(n_of(0.8), rng), 500) * env(0.8, 0.12) * 2.2)
    roll = s.lp(s.brown(n, rng), 220) * s.env_adsr(total, 0.05, 1.0, 0.55, total - 1.3, 1.2) * 1.6
    roll = roll * np.clip(1 + 0.5 * s.unit(s.lp(rng.standard_normal(n), 5)), 0.3, 1.8)
    debris = s.crackle(3.0, 220, rng, 300, 4000, 0.006, np.linspace(1, 0, 40) ** 1.6) * 0.8
    m = n_of(2.6)
    afterwind = s.sweep_filter(s.pink(m, rng), np.geomspace(200, 1400, 64), "band", 1.1) * np.sin(np.pi * np.linspace(0, 1, m)) ** 1.5 * 0.5
    y = place(total, (0, flash), (0, boom), (0, roll), (0.08, debris), (0.35, s.impact(rng, 2) * 0.7), (2.6, afterwind))
    return s.limiter(s.reverb(s.sat(y, 1.8), 4.5, 0.3, rng=rng, size=2.6), 0.95)


def relativa_geiger(rng, v):       # sisa radiasi: pencacah Geiger berbunyi acak (tiap detik)
    y = geiger(1.0, rng, (22, 30, 18, 26) if v == 0 else (28, 16, 32, 20))
    return y * np.minimum(1, (1.0 - axis(1.0)) / 0.15)


def relativa_fusion(rng, v):       # B: dua proton didekatkan (dua dengung bertemu), MENYALA tepat 0,7 dtk (= REL_FUSION_THROW)
    H, total = 0.7, 2.0
    n = n_of(H)
    t = np.arange(n) / SR
    p1 = s.osc(np.geomspace(220, 587.33, n) * (1 + 0.01 * np.sin(2 * np.pi * 11 * t)), H, "tri") * 0.2
    p2 = s.osc(np.geomspace(1300, 587.33, n) * (1 + 0.01 * np.sin(2 * np.pi * 13 * t)), H, "tri") * 0.16
    r = ramp(H, 1.6, 0.2)
    sizzle = s.crackle(H, 900, rng, 2500, 11000, 0.001, np.linspace(0.1, 1, 30) ** 2) * 0.4
    ign = s.mix(s.fire_whoosh(1.0, rng, 0.12, 4200) * 0.8, glass(1174.66, 1.4, rng, 0.5) * 0.3,
                s.thump(rng, 85, 40, 0.7, 0.15, 0.6, 0.3) * 0.6, s.transient(0.012, 2500, 0.002, 1.8, rng))
    items = [(0, p1 * r), (0, p2 * r), (0, sizzle), (H - 0.35, s.reverse_swell(0.35, rng, 900, 14000) * 0.6), (H, ign),
             (H + 0.05, s.air_whoosh(0.7, rng, 400, 2600, 500, 1.2, 0.3) * 0.6)]
    return s.limiter(s.reverb(place(total, *items), 1.4, 0.22, rng=rng), 0.95)


def relativa_fusion_boom(rng, v):  # bintang mini meledak: plasma menyilaukan, deru matahari, desis panas
    dur = 3.4
    y = place(dur, (0, s.transient(0.02, 1500, 0.004, 2.8, rng)), (0, s.thump(rng, 70 - v * 6, 28, 1.8, 0.5, 0.9, 0.4)),
              (0, s.sub_drop(130, 28, 2.0, 0.5, 7)), (0, s.fire_whoosh(2.4, rng, 0.06, 5200) * 0.9),
              (0, s.crackle(1.8, 700, rng, 2000, 12000, 0.0015, np.linspace(1, 0, 30) ** 1.5) * 0.6),
              (0.05, s.bp(s.white(n_of(1.6), rng), 3500, 11000) * env(1.6, 0.4) * 0.25), (0, glass(1567.98, 1.8, rng, 0.6) * 0.15))
    return s.limiter(s.reverb(s.sat(y, 1.5), 2.4, 0.28, rng=rng, size=1.8), 0.95)


def relativa_tokamak(rng, v):      # Shift+B: kumparan magnet mengisi (dengung listrik naik), plasma MENYALA 0,6 dtk (= REL_TOKAMAK_HIT)
    H, total = 0.6, 4.0
    n = n_of(H)
    charge = s.sweep_filter(s.osc(np.geomspace(200, 2200, n), H, "saw"), np.geomspace(300, 5000, 64), "low", 1.4) * ramp(H, 2) * 0.16
    items = [(0, hum(H, 60) * ramp(H, 1.5) * 0.25), (0, charge),
             (0, s.electric_field(H, rng, np.geomspace(4, 60, 20), (0.004, 0.03), 0.5)), (H - 0.3, s.reverse_swell(0.3, rng, 800, 12000) * 0.5)]
    d = total - H
    whirr = s.sweep_filter(s.pink(n_of(d), rng), 700 + 450 * np.sin(2 * np.pi * 2.2 * np.linspace(0, d, 200)), "band", 2.5)
    shape = s.env_adsr(d, 0.05, 0.5, 0.6, 2.2)
    ign = s.mix(s.thump(rng, 75, 34, 1.2, 0.35, 0.8, 0.35) * 1.3, s.transient(0.02, 2000, 0.004, 2.4, rng),
                s.fire_whoosh(0.8, rng, 0.1, 3600) * 0.5, glass(1046.5, 1.6, rng, 0.6) * 0.2)
    items += [(H, ign), (H, whirr * shape * 0.38), (H, hum(d, 60) * shape * 0.14),
              (H, s.electric_field(d - 0.5, rng, [40, 25, 10, 4], (0.004, 0.03), 0.35))]
    return s.limiter(s.reverb(place(total, *items), 1.8, 0.25, rng=rng, size=1.6), 0.95)


def relativa_disrupt(rng, v):      # plasma lepas kendali: SNAP listrik, cincin pecah ke luar, gemeretak, dengung jatuh
    dur = 2.8
    down = s.lp(s.osc(np.geomspace(1500, 90, n_of(1.2)), 1.2, "saw"), 2500) * env(1.2, 0.35) * 0.18
    y = place(dur, (0, s.mix(s.transient(0.02, 1500, 0.004, 2.8, rng), s.zap(0.12, rng, 1.2) * 0.9)),
              (0, s.fire_whoosh(1.6, rng, 0.08, 4800) * 0.8), (0, down), (0, s.thump(rng, 80, 32, 1.2, 0.3, 0.8, 0.4) * 0.8),
              (0.02, s.electric_field(1.4, rng, [140, 60, 20, 5], (0.004, 0.04), 0.6)),
              (0, s.crackle(1.2, 800, rng, 2000, 11000, 0.0015, np.linspace(1, 0, 20) ** 2) * 0.5))
    return s.limiter(s.reverb(y, 2.0, 0.26, rng=rng, size=1.6), 0.95)


def relativa_emc(rng, v):          # N: E = mc² ditulis (selesai 0,9 dtk = REL_EMC_WRITE), denting, lalu DILEMPAR (sampai 1,3)
    W, H, total = 0.9, 1.3, 1.6
    items = write(rng, 0.0, W - 0.05)
    items += [(W, s.mix(glass(659.25, 1.2, rng, 0.5) * 0.35, glass(987.77, 1.2, rng, 0.5) * 0.3)),
              (W, s.zip_by(H - W + 0.2, rng, 6000, 2000, False) * 0.5),
              (W, s.air_whoosh(H - W + 0.2, rng, 500, 3200, 600, 1.2, 0.6) * 0.6)]
    return s.reverb(place(total, *items), 1.2, 0.25, rng=rng)


def relativa_emc_boom(rng, v):     # massa jadi energi: "tsiing" sangat terang, DENTUM, energi menyembur, ekor panjang berkilau
    dur = 4.0
    tsing = s.mix(glass(2637.02, 1.6, rng, 0.5) * 0.3, glass(3951.07, 1.4, rng, 0.4) * 0.2,
                  s.osc(np.geomspace(9000, 2500, n_of(0.4)), 0.4) * env(0.4, 0.08) * 0.2)
    boom = s.mix(s.thump(rng, 70, 24, 2.4, 0.7, 1.0, 0.5) * 1.2, s.sub_drop(150, 22, 3.0, 0.8, 6) * 1.4,
                 s.transient(0.025, 1200, 0.005, 3.0, rng))
    surge = s.sweep_filter(s.white(n_of(1.8), rng), np.geomspace(12000, 500, 64), "low", 0.9) * env(1.8, 0.5) * 0.7
    chord = s.mix(*[glass(f, 3.0, rng, 1.2) * g for f, g in ((329.63, 0.4), (415.30, 0.3), (493.88, 0.3), (659.25, 0.25))])
    y = place(dur, (0, tsing), (0, boom), (0, surge), (0.02, chord),
              (0, s.crackle(2.0, 900, rng, 2500, 13000, 0.0012, np.linspace(1, 0, 30) ** 1.5) * 0.5))
    return s.limiter(s.reverb(s.sat(y, 1.5), 3.0, 0.3, rng=rng, size=2.0), 0.95)


def relativa_annihilate(rng, v):   # Shift+N: elektron (naik) & positron (turun) bertemu di 511 Hz tepat 0,8 dtk (= REL_ANNIHILATE_AT),
    M, G, total = 0.8, 0.6, 2.6    #   lalu dua sinar gamma 0,6 dtk (= REL_ANNIHILATE_TICKS)
    n = n_of(M)
    t = np.arange(n) / SR
    e = s.osc(np.geomspace(260, 511, n) * (1 + 0.015 * np.sin(2 * np.pi * 14 * t)), M) * 0.22
    p = s.osc(np.geomspace(1020, 511, n) * (1 + 0.015 * np.sin(2 * np.pi * 17 * t + 1)), M) * 0.2
    r = ramp(M, 1.4, 0.25)
    pop = s.mix(s.transient(0.012, 2000, 0.0025, 2.4, rng), s.thump(rng, 100, 45, 0.6, 0.12, 0.5, 0.4) * 0.7,
                glass(1022.0, 1.6, rng, 0.6) * 0.3)
    m = n_of(G)
    gamma = (s.bp(s.white(m, rng), 3500, 12000) * 0.5 + np.sin(2 * np.pi * 5110 * axis(G)) * 0.08
             + s.crackle(G, 1500, rng, 4000, 13000, 0.0008) * 0.4) * s.env_adsr(G, 0.01, 0.1, 0.8, 0.15)
    items = [(0, e * r), (0, p * r), (M - 0.3, s.reverse_swell(0.3, rng, 1500, 15000) * 0.5), (M, pop), (M, gamma)]
    return s.limiter(s.reverb(place(total, *items), 1.8, 0.25, rng=rng), 0.95)


def relativa_unified(rng, v):      # R: empat gaya masuk satu per satu (gravitasi, elektromagnet, kuat, lemah), mengorbit & naik,
    H, total = 3.2, 7.0            #   lalu MENYATU tepat 3,2 dtk (= REL_UNIFIED_HIT)
    n = n_of(H)
    grav = (np.sin(2 * np.pi * np.cumsum(np.geomspace(41, 55, n)) / SR) * 0.6 + s.lp(s.brown(n, rng), 120) * 0.5) * ramp(H, 1, 0.3)
    d2 = H - 0.6
    em = hum(d2, 110) * 0.15 * ramp(d2, 1, 0.2) + s.electric_field(d2, rng, np.linspace(6, 40, 20), (0.004, 0.03), 0.3)
    d3 = H - 1.2
    strong = s.lp(s.sat(s.supersaw(np.geomspace(82.41, 110, n_of(d3)), d3, 5, 0.02, rng), 2.5), 1200) * ramp(d3, 1.3, 0.2) * 0.18
    d4 = H - 1.8
    t4 = axis(d4)
    weak = (np.sin(2 * np.pi * 659.25 * t4) + 0.5 * np.sin(2 * np.pi * 987.77 * t4)) * (0.5 + 0.5 * np.sin(2 * np.pi * 9 * t4))
    items = [(0, grav * 0.6), (0.6, em), (1.2, strong), (1.8, weak * ramp(d4, 1, 0.2) * 0.12),
             (1.8, geiger(d4, rng, np.geomspace(4, 40, 20)) * 0.4),                       # peluruhan beta (gaya lemah)
             (H - 1.2, s.reverse_swell(1.2, rng, 400, 15000) * 0.9),
             (H - 1.0, orbit(1.0, rng, 440, (3.0, 5.0, 8.0, 13.0)) * ramp(1.0, 2) * 0.3)]
    d = total - H
    chord = 0
    for f, g in ((55.0, 1.0), (110.0, 0.8), (164.81, 0.6), (220.0, 0.5), (277.18, 0.35), (329.63, 0.3)):   # A mayor
        chord = chord + g * s.supersaw(f, d, 5, 0.008, rng)
    chord = s.sweep_filter(chord, np.concatenate([np.geomspace(300, 3200, 6), np.geomspace(3200, 260, 58)]), "low", 1.6)
    chord = s.sat(chord * s.env_adsr(d, 0.012, 0.8, 0.5, 2.6) * 0.9, 2.0) * 0.6
    burst = s.mix(chord, s.sub_drop(140, 24, 3.0, 0.8, 7) * 1.5, s.thump(rng, 65, 26, 2.0, 0.55, 0.9, 0.5),
                  s.transient(0.025, 1500, 0.005, 3.0, rng),
                  s.mix(*[glass(f, 3.4, rng, 1.3) * 0.18 for f in (880.0, 1108.73, 1318.51, 1760.0)]),
                  s.crackle(2.4, 700, rng, 2500, 13000, 0.0015, np.linspace(1, 0, 30) ** 1.5) * 0.5)
    items.append((H, burst))
    return s.limiter(s.reverb(place(total, *items), 3.6, 0.3, rng=rng, size=2.4), 0.95)


def relativa_bec(rng, v):          # Shift+R: suhu anjlok (kaca turun), BEKU tepat 0,7 dtk (= REL_BEC_HIT): semua nada jatuh ke SATU
    H, total = 0.7, 3.2            #   nada yang sama (boson di keadaan dasar yang sama), es berderak
    items = [(k * 0.07, glass(3520.0 * 0.82 ** k, 0.9, rng, 0.3) * 0.16) for k in range(9)]
    n = n_of(H)
    cold = s.sweep_filter(s.white(n, rng), np.geomspace(9000, 1200, 64), "band", 1.4) * np.linspace(1, 0.3, n) * 0.3
    items += [(0, cold), (H - 0.25, s.reverse_swell(0.25, rng, 2000, 15000) * 0.5)]
    d = total - H
    tt = axis(d)
    conv = 0
    for k, f in enumerate((174.61, 196.0, 233.08, 261.63, 293.66)):
        glide = 220.0 + (f - 220.0) * np.exp(-tt / 0.12)
        conv = conv + np.sin(2 * np.pi * np.cumsum(glide) / SR + k)
    ice = s.mix(s.transient(0.015, 2500, 0.003, 2.2, rng), s.crackle(1.6, 500, rng, 2500, 12000, 0.0015, np.linspace(1, 0, 30) ** 1.6) * 0.7,
                s.thump(rng, 80, 40, 0.8, 0.15, 0.5, 0.4) * 0.6)
    items += [(H, ice), (H, conv * env(d, 0.9) * 0.1), (H, glass(880, 2.4, rng, 1.0) * 0.3), (H, glass(1760, 2.0, rng, 0.8) * 0.15)]
    return s.reverb(place(total, *items), 2.6, 0.32, rng=rng, size=1.8)


def relativa_photon(rng, v):       # M: 6 foton (mulai 0,2 dtk = REL_PHOTO_FIRST, tiap 0,1 = REL_PHOTO_GAP): tiap foton "piu" kaca
    total = 1.4
    items = [(0, s.osc(np.geomspace(500, 1800, n_of(0.2)), 0.2) * ramp(0.2, 2) * 0.15)]
    for k in range(6):
        st = 0.2 + k * 0.1
        f = 3600 + k * 220 + rng.uniform(-80, 80)   # tiap foton sedikit lebih tinggi (E = h nu)
        pew = s.osc(np.geomspace(f, f * 0.32, n_of(0.12)), 0.12) * env(0.12, 0.03) * 0.35
        items += [(st, pew), (st, s.transient(0.006, 3500, 0.0012, 0.9, rng)), (st, glass(f * 0.5, 0.4, rng, 0.12) * 0.12)]
    return s.reverb(place(total, *items), 1.0, 0.22, rng=rng)


def relativa_arc(rng, v):          # elektron terlepas (efek fotolistrik): busur listrik pendek di sasaran
    y = place(0.7, (0, s.zap(0.14 + v * 0.03, rng, 1.2) * 0.8), (0.05, s.zap(0.08, rng, 1.0) * 0.5),
              (0, s.transient(0.008, 3000, 0.0015, 1.4, rng)), (0, glass(2093.0 + v * 200, 0.6, rng, 0.15) * 0.15))
    return s.reverb(y, 0.8, 0.2, rng=rng)


def relativa_laser(rng, v):        # Shift+M: atom tereksitasi (inversi populasi) 0,5 dtk (= REL_LASER_CHARGE), sinar koheren 2,5 dtk
    C, L, total = 0.5, 2.5, 3.4
    n = n_of(C)
    pump = s.osc(np.geomspace(300, 1760, n), C) * (0.5 + 0.5 * np.sin(2 * np.pi * np.cumsum(np.geomspace(8, 40, n)) / SR))
    m = n_of(L)
    tt = axis(L)
    beam = (np.sin(2 * np.pi * 880 * tt) * 0.3 + np.sin(2 * np.pi * 1760.6 * tt) * 0.12 + np.sin(2 * np.pi * 440 * tt) * 0.18)
    beam = beam * (0.9 + 0.1 * np.sin(2 * np.pi * 31 * tt))
    sizzle = s.bp(s.white(m, rng), 3000, 9000) * (0.6 + 0.4 * np.abs(s.unit(s.lp(rng.standard_normal(m), 40)))) * 0.2
    shape = s.env_adsr(L, 0.01, 0.15, 0.8, 0.25)
    fire = s.mix(s.transient(0.015, 2500, 0.003, 2.0, rng), s.thump(rng, 90, 45, 0.5, 0.1, 0.4, 0.3) * 0.5)
    items = [(0, pump * ramp(C, 2) * 0.25), (C - 0.3, s.reverse_swell(0.3, rng, 1500, 15000) * 0.5),
             (C, (beam + sizzle + hum(L, 55) * 0.1) * shape), (C, fire), (C, s.crackle(L, 160, rng, 2000, 9000, 0.002) * 0.3 * shape)]
    return s.limiter(s.reverb(place(total, *items), 1.4, 0.2, rng=rng), 0.95)


def relativa_gwave(rng, v):        # J: kicau LIGO memuncak tepat 0,4 dtk (= REL_GWAVE_HIT), hentakan, "ringdown", lalu
    H, total = 0.4, 3.0            #   gelombang ruang-waktu merambat (denyut rendah yang meregang-memampat)
    tt = axis(0.35)
    items = [(0, chirp(H, 70, 640) * 0.35), (H, np.sin(2 * np.pi * 640 * tt) * np.exp(-tt / 0.05) * 0.3),
             (H, s.thump(rng, 70, 30, 1.6, 0.45, 0.9, 0.5)), (H, s.sub_drop(120, 26, 2.0, 0.55, 6) * 0.9),
             (H, s.transient(0.015, 1500, 0.003, 1.6, rng)), (H, s.air_whoosh(1.6, rng, 200, 900, 150, 0.9, 0.2) * 0.4)]
    for k in range(3):
        tw = axis(0.5)
        items.append((H + 0.25 + k * 0.45, np.sin(2 * np.pi * (48 - k * 5) * tw) * np.sin(np.pi * tw / 0.5) ** 2 * (0.26 - k * 0.07)))
    return s.limiter(s.reverb(s.sat(place(total, *items), 1.4), 2.2, 0.25, rng=rng, size=1.8), 0.95)


def relativa_brown(rng, v):        # Shift+J: ditabrak miliaran molekul: gemeretak acak + 8 lompatan (mulai 0,1 dtk tiap 0,15)
    total = 1.6
    items = [(0, s.crackle(1.3, 1400, rng, 1500, 9000, 0.0006, [0.4, 1, 1, 0.8, 0.2]) * 0.4)]
    for k in range(8):
        st = 0.1 + k * 0.15
        items += [(st, blip(0.07, rng.uniform(500, 1400), rng) * 0.3), (st, s.thump(rng, 120, 70, 0.15, 0.03, 0.4, 0.4) * 0.35),
                  (st, s.air_whoosh(0.12, rng, 600, 2400, 700, 1.0, 0.3) * 0.25)]
    return s.reverb(place(total, *items), 0.9, 0.2, rng=rng)


def relativa_dodge(rng, v):        # superposisi: badan ada di dua tempat sekaligus - desir kembar yang bergeser fase, kilau kaca
    w = s.air_whoosh(0.35, rng, 700, 4200 - v * 400, 800, 1.6, 0.4) * 0.6
    y = place(0.9, (0, w), (0.035, w * 0.8), (0, glass(1318.51 + v * 120, 0.6, rng, 0.2) * 0.2),
              (0.035, glass(1975.53 + v * 120, 0.6, rng, 0.2) * 0.15), (0, s.transient(0.006, 3000, 0.0012, 0.8, rng)))
    return s.reverb(y, 0.9, 0.25, rng=rng)


def relativa_punch(rng, v):        # Tinju Foton: hantaman + desing cahaya + kilau partikel
    zing = s.osc(np.geomspace(4200 + v * 300, 900, n_of(0.25)), 0.25) * env(0.25, 0.05) * 0.25
    y = place(1.0, (0, s.body_hit(rng, v) * 0.9), (0, zing), (0, s.transient(0.01, 2500, 0.002, 1.6, rng)),
              (0, s.crackle(0.4, 900, rng, 3000, 11000, 0.001, np.linspace(1, 0, 20) ** 2) * 0.4))
    return s.limiter(y, 0.95)


# ------------------------------------------------------------------ 0.67 Kecepatan Cahaya & Terowongan Kuantum

def relativa_light_on(rng, v):     # O: mendekati c (dengung naik makin cepat, detak jam makin LAMBAT = dilatasi waktu),
    F, total = 0.8, 4.0            #   waktu BERHENTI tepat 0,8 dtk (= REL_LIGHT_WINDUP): "VWOOM", lalu dengung kaca membeku
    n = n_of(F)
    t = np.arange(n) / SR
    rate = np.geomspace(4, 46, n)
    hum = s.osc(np.geomspace(110, 1760, n), F, "saw") * (0.55 + 0.45 * np.sin(2 * np.pi * np.cumsum(rate) / SR))
    hum = s.sweep_filter(hum, np.geomspace(500, 7000, 64), "low", 1.5) * ramp(F, 2.0, 0.1) * 0.22
    items = [(0, hum), (0, s.reverse_swell(F, rng, 500, 15000) * 0.8),
             (0, orbit(F, rng, 880, (6.0, 11.0, 19.0)) * ramp(F, 2) * 0.25)]
    tk, gap = 0.0, 0.07
    while tk < F - 0.05:   # jam di sekitar melambat
        items.append((tk, tick(rng, 1900, 0.5)))
        tk += gap
        gap *= 1.32
    # waktu berhenti: dentum dalam + "vwoom" yang anjlok + akor kaca beku
    m = n_of(1.6)
    vw = s.osc(np.geomspace(420, 36, m), 1.6) * env(1.6, 0.35) * 0.8
    chord = s.mix(*[glass(f, total - F, rng, 2.2) * g for f, g in ((1318.51, 0.3), (1567.98, 0.25), (1975.53, 0.22),
                                                                    (2637.02, 0.15))])
    freeze = s.mix(s.thump(rng, 70, 26, 2.2, 0.7, 1.0, 0.4) * 1.1, s.sub_drop(160, 24, 2.6, 0.7, 6) * 1.3, vw,
                   s.transient(0.02, 1800, 0.004, 2.6, rng), chord)
    items.append((F, freeze))
    tt = axis(total - F)
    shimmer = (np.sin(2 * np.pi * 2637.02 * tt) * 0.5 + np.sin(2 * np.pi * 2640.5 * tt) * 0.5) * env(total - F, 1.4) * 0.06
    items.append((F, shimmer))
    return s.limiter(s.reverb(place(total, *items), 3.4, 0.32, rng=rng, size=2.2), 0.95)


def relativa_light_hum(rng, v):    # dunia yang membeku: dengung rendah berdenyut pelan, harmonik kaca tinggi, detak jam jauh
    dur = 3.2
    t = axis(dur)
    drone = (np.sin(2 * np.pi * 55 * t) + np.sin(2 * np.pi * 55.6 * t) + 0.5 * np.sin(2 * np.pi * 110.4 * t)) * 0.25
    glassy = (np.sin(2 * np.pi * 1760 * t) + np.sin(2 * np.pi * 1763.1 * t) + 0.6 * np.sin(2 * np.pi * 2637 * t)) * 0.03
    air = s.sweep_filter(s.pink(n_of(dur), rng), 900 + 500 * np.sin(2 * np.pi * 0.4 * np.linspace(0, dur, 200)), "band", 3.0) * 0.12
    items = [(0, drone), (0, glassy * (0.6 + 0.4 * np.sin(2 * np.pi * 0.7 * t))), (0, air)]
    for k in range(2):   # detak jam yang terdengar sangat jauh dan sangat lambat
        items.append((0.6 + k * 1.5, tick(rng, 900, 0.18)))
    y = place(dur, *items) * s.env_adsr(dur, 0.35, 0.3, 0.9, 0.6, 1.2)
    return s.reverb(y, 2.2, 0.3, rng=rng)


def relativa_light_end(rng, v):    # tangan dijentikkan: jam mulai berdetak lagi makin cepat, waktu BERJALAN tepat 0,6 dtk
    R, total = 0.6, 3.6            #   (= REL_LIGHT_RESUME): semua pukulan yang ditabung meledak sekaligus, waktu beku pecah
    n = n_of(R)
    items = [(0, s.osc(np.geomspace(60, 600, n), R, "saw") * ramp(R, 2.2, 0.05) * 0.12),   # pita dipercepat lagi
             (0, s.reverse_swell(R, rng, 300, 15000) * 0.9), (0, s.transient(0.008, 3000, 0.0015, 1.2, rng))]
    tk, gap = 0.04, 0.16
    while tk < R - 0.02:
        items.append((tk, tick(rng, 1600, 0.5)))
        tk += gap
        gap *= 0.72
    burst = s.mix(s.impact(rng, 2) * 0.9, s.sub_drop(140, 26, 2.2, 0.6, 6) * 1.2, s.transient(0.025, 1500, 0.005, 3.0, rng),
                  s.crackle(1.4, 1600, rng, 3000, 14000, 0.0012, np.linspace(1, 0, 30) ** 1.6) * 0.6)   # waktu beku pecah
    items.append((R, burst))
    for k in range(7):   # pukulan-pukulan yang ditabung lepas beruntun
        st = R + 0.02 + k * 0.045 + rng.uniform(0, 0.02)
        items.append((st, s.body_hit(rng, k % 3) * (0.5 - k * 0.04)))
    tt = axis(1.2)
    items.append((R, (np.sin(2 * np.pi * 1318.5 * tt) + np.sin(2 * np.pi * 1975.5 * tt)) * env(1.2, 0.3) * 0.08))
    return s.limiter(s.reverb(place(total, *items), 2.6, 0.28, rng=rng, size=2.0), 0.95)


def relativa_time_hit(rng, v):     # pukulan ke makhluk yang membeku: dentum teredam + "ting" kaca yang menggantung di udara
    dur = 1.6
    thud = s.lp(s.body_hit(rng, v), 900) * 0.8
    ping = glass((1567.98, 1760.0)[v % 2], 1.5, rng, 0.9) * 0.3
    frozen = s.reverse_swell(0.18, rng, 2000, 12000) * 0.25
    y = place(dur, (0, frozen), (0.16, thud), (0.16, ping), (0.16, s.transient(0.006, 3000, 0.0012, 0.8, rng)))
    return s.reverb(y, 2.0, 0.35, rng=rng)


def relativa_phase_on(rng, v):     # I: bidang ukur menyapu badan, atom demi atom berubah jadi gelombang (butiran naik),
    D, total = 1.2, 2.8            #   selesai tepat 1,2 dtk (= REL_PHASE_SWEEP): denting ungu
    items = []
    for k in range(46):   # butiran kaca naik: tiap butir satu atom yang berubah
        st = D * k / 46 + rng.uniform(-0.01, 0.01)
        f = 600 * (2 ** (k / 46 * 2.2)) * rng.uniform(0.97, 1.03)
        items.append((max(0.0, st), glass(f, 0.35, rng, 0.08) * 0.14))
    n = n_of(D)
    t = np.arange(n) / SR
    warble = s.osc(np.geomspace(300, 900, n) * (1 + 0.04 * np.sin(2 * np.pi * np.geomspace(3, 14, n) * t)), D) * ramp(D, 1.4, 0.2) * 0.12
    items += [(0, warble), (0, s.sweep_filter(s.white(n, rng), np.geomspace(800, 9000, 64), "band", 3.0) * ramp(D, 1.2) * 0.2),
              (D - 0.3, s.reverse_swell(0.3, rng, 1500, 15000) * 0.5)]
    chord = s.mix(*[glass(f, total - D, rng, 1.2) * g for f, g in ((587.33, 0.4), (739.99, 0.32), (880.0, 0.3), (1174.66, 0.2))])
    items += [(D, chord), (D, s.air_whoosh(0.6, rng, 600, 3000, 500, 1.2, 0.2) * 0.4)]
    return s.reverb(place(total, *items), 2.4, 0.32, rng=rng, size=1.8)


def relativa_phase_off(rng, v):    # fungsi gelombang runtuh: butiran turun, lalu "klik" pengukuran tepat 0,7 dtk (= REL_PHASE_OFF)
    D, total = 0.7, 1.8
    items = []
    for k in range(26):
        st = D * k / 26
        f = 1800 * (2 ** (-k / 26 * 1.8)) * rng.uniform(0.97, 1.03)
        items.append((st, glass(f, 0.3, rng, 0.07) * 0.13))
    items.append((0, s.reverse_swell(D, rng, 600, 9000) * 0.5))
    snap = s.mix(s.transient(0.01, 2500, 0.002, 2.2, rng), s.thump(rng, 120, 60, 0.4, 0.08, 0.5, 0.5) * 0.6,
                 glass(880.0, 0.9, rng, 0.25) * 0.3)
    items.append((D, snap))
    return s.reverb(place(total, *items), 1.4, 0.25, rng=rng)


def relativa_phase_pass(rng, v):   # serangan / benda menembus badan: desir berfase + "blup" kaca yang bergoyang
    dur = 0.9
    n = n_of(0.45)
    w = s.sweep_filter(s.white(n, rng), 1200 + 2600 * np.sin(np.pi * np.linspace(0, 1, 64)), "band", 4.0) * np.sin(np.pi * np.linspace(0, 1, n)) * 0.45
    f0 = (1046.5, 932.33)[v % 2]
    tt = axis(0.35)
    blup = np.sin(2 * np.pi * np.cumsum(f0 * (1 + 0.25 * np.exp(-tt / 0.05) * np.sin(2 * np.pi * 18 * tt))) / SR) * env(0.35, 0.09) * 0.3
    y = place(dur, (0, w), (0.06, w * 0.6), (0.05, blup), (0.05, glass(f0 * 2, 0.5, rng, 0.15) * 0.12))
    return s.reverb(y, 1.0, 0.3, rng=rng)


# ------------------------------------------------------------------ 0.70 ruang-waktu

def relativa_wormhole(rng, v):     # L: kedua telapak menekan ruang-waktu (nada membentang & bergetar makin keras), RUANG-WAKTU
    O, total = 0.8, 3.4            #   ROBEK tepat 0,8 dtk (= REL_WORM_OPEN): "VWOOM" dalam, retakan, tenggorokan berputar
    n = n_of(O)
    t = np.arange(n) / SR
    stretch = s.osc(np.geomspace(140, 70, n) * (1 + 0.05 * np.sin(2 * np.pi * np.geomspace(4, 30, n) * t)), O, "saw")
    stretch = s.sweep_filter(stretch, np.geomspace(400, 2600, 64), "low", 1.4) * ramp(O, 1.6, 0.1) * 0.25
    items = [(0, stretch), (0, s.reverse_swell(O, rng, 300, 14000) * 0.9),
             (0, s.crackle(O, 120, rng, 600, 7000, 0.002, np.linspace(0.1, 1.0, 30) ** 2) * 0.35)]
    m = n_of(2.2)
    tt = np.arange(m) / SR
    throat = s.sweep_filter(s.pink(m, rng), 300 + 900 * np.exp(-tt / 0.6) + 200 * np.sin(2 * np.pi * 1.7 * tt), "band", 2.0)
    throat = throat * s.env_adsr(2.2, 0.01, 0.4, 0.6, 1.4) * 0.5
    vw = s.osc(np.geomspace(300, 40, n_of(1.4)), 1.4) * env(1.4, 0.4) * 0.7
    chord = s.mix(*[glass(f, 2.4, rng, 1.4) * g for f, g in ((392.0, 0.35), (587.33, 0.3), (783.99, 0.22), (1174.66, 0.14))])
    tear = s.mix(s.transient(0.02, 900, 0.006, 2.8, rng), s.crackle(0.5, 2400, rng, 1500, 12000, 0.001, np.linspace(1, 0, 20)) * 0.7)
    boom = s.mix(s.thump(rng, 62, 22, 2.2, 0.6, 1.0, 0.4) * 1.1, s.sub_drop(120, 20, 2.4, 0.8, 5) * 1.2, vw, tear, chord, throat)
    items.append((O, boom))
    return s.limiter(s.reverb(s.sat(place(total, *items), 1.2), 2.8, 0.3, rng=rng, size=2.0), 0.95)


def relativa_wormhole_hum(rng, v):   # mulut lubang cacing yang terbuka (diputar ulang tiap 2 dtk): tenggorokan yang berputar,
    dur = 2.4                        #   angin tersedot, gema dari seberang, denting kaca yang jauh
    n = n_of(dur)
    t = np.arange(n) / SR
    drone = (np.sin(2 * np.pi * 46 * t) + np.sin(2 * np.pi * 46.9 * t) + 0.5 * np.sin(2 * np.pi * 92.5 * t)) * 0.3
    swirl = s.sweep_filter(s.pink(n, rng), 420 + 300 * np.sin(2 * np.pi * 1.25 * np.linspace(0, dur, 240)), "band", 2.4) * 0.5
    suck = s.sweep_filter(s.white(n, rng), 2200 + 1400 * np.sin(2 * np.pi * 0.5 * np.linspace(0, dur, 120)), "band", 5.0) * 0.08
    items = [(0, drone), (0, swirl), (0, suck)]
    for k in range(3):
        st = 0.3 + k * 0.7 + rng.uniform(-0.1, 0.1)
        items.append((st, glass(rng.choice([1174.66, 1318.51, 1567.98, 1760.0]), 1.0, rng, 0.5) * 0.05))
    y = place(dur, *items) * s.env_adsr(dur, 0.3, 0.3, 0.9, 0.7, 1.2)
    return s.reverb(s.sat(y, 1.3), 2.0, 0.3, rng=rng)


def relativa_wormhole_pass(rng, v):  # sesuatu lewat: tersedot (desis naik), "whum" Doppler yang menukik, denting tiba
    dur = 1.5
    n = n_of(0.35)
    suck = s.reverse_swell(0.3, rng, 800, 14000) * 0.7
    swoop = s.osc(np.geomspace(1400, 90, n_of(0.6)), 0.6) * env(0.6, 0.14) * 0.35
    whoosh = s.air_whoosh(0.6, rng, 300, 2400, 300, 1.3, 0.35) * 0.8
    land = s.mix(s.thump(rng, 80, 40, 0.8, 0.2, 0.6, 0.3) * 0.6, glass((1046.5, 1174.66)[v % 2], 1.0, rng, 0.5) * 0.22)
    y = place(dur, (0, suck), (0.28, swoop), (0.2, whoosh), (0.3, land), (0.3, s.transient(0.01, 2500, 0.002, 1.2, rng)))
    return s.reverb(y, 1.6, 0.28, rng=rng)


def relativa_wormhole_close(rng, v):   # mulut menutup: tenggorokan menciut (nada naik makin tinggi & cepat), lalu IMPLOSI
    C, total = 0.6, 2.4                #   tepat 0,6 dtk (= Mouth.CLOSE 12 tick): dentum teredam, materi terakhir tersedot
    n = n_of(C)
    t = np.arange(n) / SR
    shrink = s.osc(np.geomspace(120, 1800, n) * (1 + 0.04 * np.sin(2 * np.pi * np.geomspace(6, 40, n) * t)), C) * ramp(C, 1.8, 0.2) * 0.2
    items = [(0, shrink), (0, s.reverse_swell(C, rng, 500, 13000) * 0.8),
             (0, s.sweep_filter(s.pink(n, rng), np.geomspace(300, 4000, 64), "band", 2.0) * ramp(C, 1.5) * 0.4)]
    pop = s.mix(s.thump(rng, 90, 30, 1.4, 0.35, 0.9, 0.5), s.sub_drop(140, 30, 1.6, 0.4, 7) * 0.9,
                s.transient(0.012, 2000, 0.003, 2.0, rng), glass(523.25, 1.6, rng, 0.8) * 0.2)
    items.append((C, pop))
    return s.limiter(s.reverb(place(total, *items), 2.2, 0.28, rng=rng, size=1.6), 0.95)


def relativa_photon_on(rng, v):    # F: badan dilepas jadi foton (arpeggio kaca naik makin rapat), MELESAT tepat 0,5 dtk
    L, total = 0.5, 2.2            #   (= REL_PHOTON_ON): "fwoom" terang, desing cahaya, kilau yang memudar
    items = []
    for k in range(14):
        st = L * (k / 14) ** 0.8
        f = 523.25 * 2 ** (k / 14 * 2.5) * rng.uniform(0.99, 1.01)
        items.append((st, glass(f, 0.3, rng, 0.08) * 0.14))
    items.append((0, s.reverse_swell(L, rng, 1200, 16000) * 0.7))
    whoosh = s.air_whoosh(0.9, rng, 400, 5000, 1200, 1.4, 0.2) * 0.9
    zing = s.osc(np.geomspace(900, 4200, n_of(0.5)), 0.5) * env(0.5, 0.14) * 0.22
    burst = s.mix(s.thump(rng, 90, 45, 0.9, 0.22, 0.6, 0.3) * 0.7, s.transient(0.015, 2500, 0.003, 2.0, rng), whoosh, zing,
                  s.mix(*[glass(f, 1.6, rng, 0.9) * 0.1 for f in (1567.98, 2093.0, 2637.02)]))
    items.append((L, burst))
    return s.limiter(s.reverb(place(total, *items), 2.0, 0.3, rng=rng, size=1.6), 0.95)


def relativa_photon_off(rng, v):   # foton memadat lagi jadi massa: kaca turun, "dum" lembut tepat 0,4 dtk (= REL_PHOTON_OFF)
    D, total = 0.4, 1.4
    items = []
    for k in range(10):
        f = 2093.0 * 2 ** (-k / 10 * 1.6) * rng.uniform(0.99, 1.01)
        items.append((D * k / 10, glass(f, 0.25, rng, 0.07) * 0.13))
    items.append((0, s.reverse_swell(D, rng, 600, 9000) * 0.4))
    items.append((D, s.mix(s.thump(rng, 100, 55, 0.6, 0.15, 0.5, 0.4) * 0.6, glass(523.25, 0.9, rng, 0.3) * 0.2)))
    return s.reverb(place(total, *items), 1.4, 0.25, rng=rng)


def relativa_clone(rng, v):        # K: kotak dibuka (engsel berderit), dua-tiga nada saling bertumpuk & bergoyang (superposisi),
    S, total = 0.7, 2.4            #   TERBELAH tepat 0,7 dtk (= REL_CLONE_SPLIT): empat "shing" kaca berpencar
    n = n_of(S)
    t = np.arange(n) / SR
    creak = s.sweep_filter(s.osc(np.geomspace(180, 260, n_of(0.35)) * (1 + 0.03 * s.lp(rng.standard_normal(n_of(0.35)), 40) * 20),
                                 0.35, "saw"), np.full(64, 1200.0), "band", 3.0) * env(0.35, 0.2) * 0.25
    sup = s.mix(*[s.osc(f * (1 + 0.012 * np.sin(2 * np.pi * r * t)), S) * 0.12
                  for f, r in ((440.0, 3.1), (466.16, 4.3), (493.88, 5.7))]) * ramp(S, 1.3, 0.2)
    items = [(0, creak), (0.1, sup[: n_of(S - 0.1)]), (0, s.reverse_swell(S, rng, 900, 14000) * 0.6)]
    split = [glass(f, 1.4, rng, 0.7) * 0.18 for f in (659.25, 830.61, 987.77, 1318.51)]
    for k, g in enumerate(split):
        items.append((S + k * 0.035, g))
    items += [(S, s.transient(0.015, 2200, 0.003, 1.8, rng)), (S, s.thump(rng, 85, 40, 0.9, 0.2, 0.6, 0.3) * 0.6),
              (S, s.air_whoosh(0.7, rng, 500, 3500, 700, 1.3, 0.25) * 0.6)]
    return s.limiter(s.reverb(place(total, *items), 2.2, 0.3, rng=rng, size=1.6), 0.95)


def relativa_clone_collapse(rng, v):   # salinan teramati: "klik" pengukuran, kaca pecah jadi butiran, desis partikel
    dur = 1.4
    click = s.mix(s.transient(0.008, 3000, 0.0015, 2.2, rng), blip(0.06, (1760.0, 1975.53)[v % 2], rng) * 0.35)
    shatter = s.crackle(0.8, 2200, rng, 2500, 14000, 0.0009, np.linspace(1, 0, 30) ** 1.4) * 0.6
    grains = [(0.03 + k * 0.03, glass(rng.uniform(1500, 3200), 0.25, rng, 0.06) * 0.08) for k in range(9)]
    fizz = s.bp(s.white(n_of(0.9), rng), 4000, 12000) * env(0.9, 0.25) * 0.15
    y = place(dur, (0, click), (0.01, shatter), (0.02, fizz), *grains)
    return s.reverb(y, 1.4, 0.3, rng=rng)


def relativa_clone_punch(rng, v):   # tinju foton salinan: hantaman + desing cahaya kecil + kilau
    dur = 0.9
    y = place(dur, (0, s.body_hit(rng, v) * 0.8), (0, s.transient(0.01, 2400, 0.002, 1.2, rng)),
              (0.005, s.osc(np.geomspace(2600, 900, n_of(0.18)), 0.18) * env(0.18, 0.05) * 0.18),
              (0.01, glass((1318.51, 1567.98, 1760.0)[v % 3], 0.6, rng, 0.25) * 0.12))
    return s.reverb(y, 1.0, 0.2, rng=rng)


def relativa_cloak_on(rng, v):     # H: cahaya dibelokkan mengitari badan (glissando kaca turun & menyatu), lalu HILANG tepat
    H, total = 0.6, 2.0            #   0,6 dtk (= REL_CLOAK_AT): "fmmm" yang tersedot ke sunyi, sisa kilau tipis
    n = n_of(H)
    t = np.arange(n) / SR
    bend = s.mix(*[s.osc(np.geomspace(f, 880.0, n), H) * 0.1 for f in (1760.0, 1318.51, 2349.32)]) * ramp(H, 0.8, 0.3)
    items = [(0, bend), (0, s.reverse_swell(H, rng, 800, 15000) * 0.6),
             (0, s.sweep_filter(s.white(n, rng), np.geomspace(9000, 1200, 64), "band", 3.0) * ramp(H, 1.2) * 0.25)]
    tt = axis(total - H)
    tail = (np.sin(2 * np.pi * 880.0 * tt) + np.sin(2 * np.pi * 883.2 * tt)) * env(total - H, 0.5) * 0.06
    gone = s.mix(s.osc(np.geomspace(880, 220, n_of(0.3)), 0.3) * env(0.3, 0.08) * 0.25,
                 s.lp(s.brown(n_of(0.4), rng), 300) * env(0.4, 0.1) * 0.5)
    items += [(H, gone), (H, tail)]
    return s.reverb(place(total, *items), 2.2, 0.35, rng=rng, size=1.6)


def relativa_cloak_off(rng, v):    # lensa dilepas: kilau, "pop" tepat 0,4 dtk (= REL_CLOAK_OFF), nada kaca naik
    O, total = 0.4, 1.5
    items = [(0, s.reverse_swell(O, rng, 1200, 15000) * 0.5),
             (0, s.osc(np.geomspace(220, 880, n_of(O)), O) * ramp(O, 1.5, 0.1) * 0.1)]
    pop = s.mix(s.transient(0.01, 2000, 0.002, 1.6, rng), s.thump(rng, 110, 60, 0.5, 0.1, 0.5, 0.4) * 0.5,
                s.mix(*[glass(f, 1.0, rng, 0.4) * 0.12 for f in (880.0, 1318.51, 1760.0)]))
    items.append((O, pop))
    return s.reverb(place(total, *items), 1.6, 0.3, rng=rng)


def relativa_cloak_strike(rng, v):   # serangan dari balik lensa: desir muncul tiba-tiba, HANTAMAN tajam, kaca berdering
    dur = 1.2
    y = place(dur, (0, s.reverse_swell(0.12, rng, 2000, 15000) * 0.6), (0.1, s.impact(rng, 0) * 0.8),
              (0.1, s.transient(0.015, 2200, 0.003, 2.0, rng)),
              (0.1, s.mix(*[glass(f, 0.9, rng, 0.3) * 0.12 for f in (1108.73, 1661.22)])),
              (0.1, s.osc(np.geomspace(3000, 600, n_of(0.25)), 0.25) * env(0.25, 0.06) * 0.2))
    return s.limiter(s.reverb(y, 1.6, 0.25, rng=rng), 0.95)


RECIPES = {
    "relativa_rite": (relativa_rite, 1, 1.0),
    "relativa_transform": (relativa_transform, 1, 1.0),
    "relativa_revert": (relativa_revert, 1, 0.8),
    "relativa_paper": (relativa_paper, 1, 0.85),
    "relativa_dash": (relativa_dash, 2, 0.9),
    "relativa_dilation": (relativa_dilation, 1, 0.9),
    "relativa_warp": (relativa_warp, 1, 1.0),
    "relativa_blackhole": (relativa_blackhole, 1, 1.0),
    "relativa_blackhole_hum": (relativa_blackhole_hum, 1, 0.85),
    "relativa_hawking": (relativa_hawking, 1, 1.0),
    "relativa_tunnel": (relativa_tunnel, 2, 0.85),
    "relativa_entangle": (relativa_entangle, 1, 0.85),
    "relativa_entangle_pulse": (relativa_entangle_pulse, 2, 0.75),
    "relativa_neutron": (relativa_neutron, 1, 0.8),
    "relativa_fission": (relativa_fission, 3, 0.9),
    "relativa_critical": (relativa_critical, 1, 0.9),
    "relativa_nuke": (relativa_nuke, 1, 1.0),
    "relativa_geiger": (relativa_geiger, 2, 0.7),
    "relativa_fusion": (relativa_fusion, 1, 1.0),
    "relativa_fusion_boom": (relativa_fusion_boom, 2, 1.0),
    "relativa_tokamak": (relativa_tokamak, 1, 0.9),
    "relativa_disrupt": (relativa_disrupt, 1, 0.95),
    "relativa_emc": (relativa_emc, 1, 0.95),
    "relativa_emc_boom": (relativa_emc_boom, 1, 1.0),
    "relativa_annihilate": (relativa_annihilate, 1, 0.95),
    "relativa_unified": (relativa_unified, 1, 1.0),
    "relativa_bec": (relativa_bec, 1, 1.0),
    "relativa_photon": (relativa_photon, 1, 0.95),
    "relativa_arc": (relativa_arc, 2, 0.8),
    "relativa_laser": (relativa_laser, 1, 0.9),
    "relativa_gwave": (relativa_gwave, 1, 1.0),
    "relativa_brown": (relativa_brown, 1, 0.8),
    "relativa_dodge": (relativa_dodge, 2, 0.8),
    "relativa_punch": (relativa_punch, 3, 0.95),
    "relativa_light_on": (relativa_light_on, 1, 1.0),
    "relativa_light_hum": (relativa_light_hum, 1, 0.45),
    "relativa_light_end": (relativa_light_end, 1, 1.0),
    "relativa_time_hit": (relativa_time_hit, 2, 0.85),
    "relativa_phase_on": (relativa_phase_on, 1, 0.9),
    "relativa_phase_off": (relativa_phase_off, 1, 1.0),
    "relativa_phase_pass": (relativa_phase_pass, 2, 0.75),
    "relativa_wormhole": (relativa_wormhole, 1, 1.0),
    "relativa_wormhole_hum": (relativa_wormhole_hum, 1, 0.6),
    "relativa_wormhole_pass": (relativa_wormhole_pass, 2, 0.85),
    "relativa_wormhole_close": (relativa_wormhole_close, 1, 0.95),
    "relativa_photon_on": (relativa_photon_on, 1, 0.95),
    "relativa_photon_off": (relativa_photon_off, 1, 0.8),
    "relativa_clone": (relativa_clone, 1, 0.95),
    "relativa_clone_collapse": (relativa_clone_collapse, 2, 0.85),
    "relativa_clone_punch": (relativa_clone_punch, 3, 0.85),
    "relativa_cloak_on": (relativa_cloak_on, 1, 0.85),
    "relativa_cloak_off": (relativa_cloak_off, 1, 0.85),
    "relativa_cloak_strike": (relativa_cloak_strike, 1, 0.95),
}
WINDUPS = {"relativa_critical"}
LOOPS = set()

s.RECIPES.update(RECIPES)
s.WINDUPS.update(WINDUPS)
s.LOOPS.update(LOOPS)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "out"
    only = sys.argv[2:] if len(sys.argv) > 2 else None
    os.makedirs(out, exist_ok=True)
    for name, (fn, count, gain) in RECIPES.items():
        if only and name not in only:
            continue
        for v in range(count):
            y = s.render(name, fn, v, gain)
            fname = f"{name}_{v + 1}.ogg"
            s.encode(y, os.path.join(out, fname))
            rms = 20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)
            print(fname, round(len(y) / SR, 2), "dtk", round(float(rms), 1), "dB", flush=True)
