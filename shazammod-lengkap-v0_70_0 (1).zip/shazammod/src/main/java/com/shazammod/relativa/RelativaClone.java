package com.shazammod.relativa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamAnimPayload;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.RelativeMovement;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 0.70 KUCING SCHRÖDINGER (tombol K): kotaknya dibuka sebelum diamati, jadi RELATIVA ada dalam superposisi: badannya
 * terbelah jadi COUNT salinan yang sama persis (kulit, baju zirah, barang di tangan, atom di dada, papan nama) dan yang
 * asli diacak di antara keempat tempatnya. Semua salinan ikut bertarung: mengejar musuh yang kamu pukul / yang memukulmu /
 * monster terdekat, melesat secepat cahaya ke sasaran yang jauh (Lesat Cahaya), dan meninju dengan tinju foton.
 *
 * Pengamatan meruntuhkan fungsi gelombang:
 *   salinan kena serangan apa pun     langsung runtuh jadi partikel (api, jatuh, sesak bukan "pengamatan": nggak mempan)
 *   yang ASLI kena serangan           salinan yang menanggungnya: satu salinan runtuh, damage ke yang asli batal
 *                                     (jeda DECOY_GAP tick sebelum salinan berikutnya)
 *   umurnya habis (REL_CLONE_TICKS)   salinan kembali menyatu jadi cahaya
 *
 * Tiap salinan = satu entity di server (kotak tabraknya seukuran pemain), digambar di client sebagai pemain boneka
 * (client.RelativaClonePuppets) supaya semua gerakan & efek RELATIVA berlaku. Nggak disimpan; runtuh saat RELATIVA-nya
 * kembali jadi manusia / keluar / beda dimensi. Ikut lewat Jembatan Einstein-Rosen bersama yang asli.
 */
public class RelativaClone extends PathfinderMob {
    // ======= Angka yang gampang diutak-atik =======
    public static final int COUNT = 3;
    public static final float COST = 40f;               // energi (x RelativaTier.COST)
    public static final int COOLDOWN = 30;              // detik (x RelativaTier.COOLDOWN)
    private static final double SPREAD = 3.2;           // jarak keempat tempat superposisi
    private static final float PUNCH = 30f;             // x RelativaSkills.SKILL_DAMAGE
    private static final int PUNCH_GAP = 8;
    private static final double REACH = 2.6;
    private static final double HUNT = 20.0;            // mencari monster sejauh ini
    private static final double LEASH = 26.0;           // tertinggal sejauh ini dari yang asli: melesat kembali
    private static final double DASH_MIN = 6.0, DASH_MAX = 28.0;
    private static final int DASH_GAP = 50;
    private static final int DECOY_GAP = 10;
    // ===============================================

    private static final EntityDataAccessor<Optional<UUID>> DATA_OWNER =
            SynchedEntityData.defineId(RelativaClone.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Boolean> DATA_COLLAPSE =
            SynchedEntityData.defineId(RelativaClone.class, EntityDataSerializers.BOOLEAN);

    /** Salinan milik tiap RELATIVA (server). Yang sudah hilang dibuang saat dibaca. */
    private static final Map<UUID, List<RelativaClone>> BY_OWNER = new HashMap<>();

    private int life = ShazamAnim.REL_CLONE_TICKS;
    private int punchCooldown;
    private int dashCooldown = 20;
    private int dashAt = -1;
    private Vec3 dashTo;
    private int pathTicks;
    private int collapseTicks = -1;

    public RelativaClone(EntityType<? extends RelativaClone> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.42)
                .add(Attributes.ATTACK_DAMAGE, PUNCH)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.STEP_HEIGHT, 1.1);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_OWNER, Optional.empty());
        builder.define(DATA_COLLAPSE, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    // ---------------------------------------------------------------- status (dibaca juga di client)

    public UUID owner() {
        return this.entityData.get(DATA_OWNER).orElse(null);
    }

    public boolean ownedBy(Entity e) {
        return e != null && e.getUUID().equals(owner());
    }

    public boolean collapsing() {
        return this.entityData.get(DATA_COLLAPSE);
    }

    private void setOwner(UUID id, boolean track) {
        this.entityData.set(DATA_OWNER, Optional.ofNullable(id));
        if (track) {
            track();
        }
    }

    /** Dicatat sebagai salinan milik RELATIVA-nya (server). */
    private void track() {
        UUID id = owner();
        if (id != null && !this.level().isClientSide()) {
            List<RelativaClone> list = BY_OWNER.computeIfAbsent(id, k -> new ArrayList<>());
            if (!list.contains(this)) {
                list.add(this);
            }
        }
    }

    /** Salinan milik pemain ini yang masih hidup (belum runtuh), di dimensi yang sama. */
    public static List<RelativaClone> of(ServerPlayer p) {
        List<RelativaClone> list = BY_OWNER.get(p.getUUID());
        if (list == null) {
            return List.of();
        }
        list.removeIf(c -> c.isRemoved() || !c.isAlive());
        if (list.isEmpty()) {
            BY_OWNER.remove(p.getUUID());
            return List.of();
        }
        List<RelativaClone> out = new ArrayList<>();
        for (RelativaClone c : list) {
            if (!c.collapsing() && c.level() == p.level()) {
                out.add(c);
            }
        }
        return out;
    }

    public static int count(ServerPlayer p) {
        return of(p).size();
    }

    public static void clearAll() {
        BY_OWNER.clear();
    }

    // ---------------------------------------------------------------- tombol K

    public static void cast(ServerPlayer p, RelativaData d) {
        if (!RelativaSkills.ready(p, d, RelativaData.SLOT_CLONE, COST)) {
            return;
        }
        RelativaSkills.spend(p, d, RelativaData.SLOT_CLONE, COST, COOLDOWN);
        collapseAll(p);   // superposisi lama runtuh, kotaknya dibuka lagi
        RelativaSkills.busy(p, ShazamAnim.REL_CLONE_SPLIT + 2);
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_CLONE);
        RelativaSkills.sound(p, p.position(), ShazamSounds.RELATIVA_CLONE.get(), 1.6f);
        RelativaSkills.later(p, ShazamAnim.REL_CLONE_SPLIT, RelativaClone::split);
        RelativaNetwork.sync(p);
    }

    /** Terbelah: empat tempat (di sini, kiri, kanan, belakang), yang asli diacak ke salah satunya. */
    private static void split(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        Vec3 origin = p.position();
        Vec3 fwd = RelativaSkills.flat(p.getLookAngle());
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
        Vec3[] want = {origin, origin.add(right.scale(SPREAD)), origin.subtract(right.scale(SPREAD)),
                origin.subtract(fwd.scale(SPREAD))};
        List<Vec3> spots = new ArrayList<>();
        for (Vec3 w : want) {
            spots.add(fit(p, level, origin, w));
        }
        int real = p.getRandom().nextInt(spots.size());
        Vec3 realSpot = spots.get(real);
        if (real != 0 && realSpot.distanceToSqr(origin) > 0.01) {
            p.teleportTo(realSpot.x, realSpot.y, realSpot.z);
        }
        float yaw = p.getYRot();
        int made = 0;
        for (int i = 0; i < spots.size() && made < COUNT; i++) {
            if (i == real) {
                continue;
            }
            RelativaClone c = RelativaRegistry.CLONE.get().create(level);
            if (c == null) {
                continue;
            }
            Vec3 s = spots.get(i);
            c.moveTo(s.x, s.y, s.z, yaw, p.getXRot());
            c.setYHeadRot(yaw);
            c.yBodyRot = yaw;
            c.dress(p);
            c.setOwner(p.getUUID(), false);
            if (level.addFreshEntity(c)) {
                c.track();
                made++;
            }
        }
        RelativaAbilities.msg(p, "clone", ChatFormatting.AQUA, made, ShazamAnim.REL_CLONE_TICKS / 20);
        RelativaNetwork.sync(p);
    }

    /** Tempat yang muat seukuran badan (naik satu blok kalau sesak), kalau nggak ada: tempat asal. */
    private static Vec3 fit(ServerPlayer p, ServerLevel level, Vec3 origin, Vec3 want) {
        for (double up = 0.0; up <= 1.01; up += 0.5) {
            Vec3 c = want.add(0, up, 0);
            if (level.noCollision(p, p.getBoundingBox().move(c.subtract(origin)))) {
                return c;
            }
        }
        return origin;
    }

    /** Sama persis dengan yang asli: ukuran badan, baju zirah, barang di tangan (nggak pernah dijatuhkan). */
    private void dress(ServerPlayer p) {
        AttributeInstance scale = this.getAttribute(Attributes.SCALE);
        if (scale != null) {
            scale.setBaseValue(p.getScale());
        }
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot == EquipmentSlot.BODY) {
                continue;
            }
            this.setItemSlot(slot, p.getItemBySlot(slot).copy());
            this.setDropChance(slot, 0f);
        }
        this.refreshDimensions();
    }

    /** Semua salinan milik pemain ini runtuh (skill dipakai lagi, kembali jadi manusia, tumbang). */
    public static void collapseAll(ServerPlayer p) {
        List<RelativaClone> list = BY_OWNER.get(p.getUUID());
        if (list == null) {
            return;
        }
        for (RelativaClone c : new ArrayList<>(list)) {
            c.collapse();
        }
    }

    /**
     * Yang asli kena serangan (bukan api / jatuh / sesak): satu salinan yang menanggungnya, damage-nya batal. true =
     * dibatalkan. Dipanggil RelativaAbilities.guard.
     */
    static boolean absorb(ServerPlayer p, RelativaData d, DamageSource source) {
        if (source.getEntity() == null && source.getDirectEntity() == null && !source.is(DamageTypeTags.IS_EXPLOSION)) {
            return false;
        }
        List<RelativaClone> list = of(p);
        if (list.isEmpty()) {
            return false;
        }
        if (d.decoyGap > 0) {
            return true;   // barusan ditanggung salinan: pukulan lain di jeda yang sama ikut lewat
        }
        RelativaClone c = list.get(p.getRandom().nextInt(list.size()));
        c.collapse();
        d.decoyGap = DECOY_GAP;
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_CLONE_DECOY, RelativaAbilities.chest(p));
        RelativaSkills.sound(p, p.position(), ShazamSounds.RELATIVA_DODGE.get(), 1.0f);
        RelativaAbilities.msg(p, "clone_decoy", ChatFormatting.AQUA, list.size() - 1);
        return true;
    }

    /** Yang asli lewat lubang cacing ke tempat lain: salinannya ikut (UUID yang dipindah). */
    static List<UUID> bring(ServerPlayer owner, ServerLevel from, ServerLevel to, Vec3 at) {
        List<UUID> moved = new ArrayList<>();
        List<RelativaClone> list = BY_OWNER.get(owner.getUUID());
        if (list == null || from == null) {
            return moved;
        }
        for (RelativaClone c : new ArrayList<>(list)) {
            if (c.isRemoved() || c.collapsing() || c.level() != from) {
                continue;
            }
            double ox = (c.random.nextDouble() - 0.5) * 2.0, oz = (c.random.nextDouble() - 0.5) * 2.0;
            Vec3 v = c.getDeltaMovement();
            UUID id = c.getUUID();
            if (c.teleportTo(to, at.x + ox, at.y, at.z + oz, Set.<RelativeMovement>of(), c.getYRot(), c.getXRot())) {
                Entity now = to.getEntity(id);
                if (now != null) {
                    now.setDeltaMovement(v);
                }
                moved.add(id);
            }
        }
        return moved;
    }

    // ---------------------------------------------------------------- tiap tick

    @Override
    public void aiStep() {
        this.updateSwingTime();   // PathfinderMob nggak menghitung ayunan tangannya sendiri (boneka di client meniru ini)
        super.aiStep();
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (collapseTicks >= 0) {
            this.setDeltaMovement(Vec3.ZERO);
            if (--collapseTicks <= 0) {
                this.discard();
            }
            return;
        }
        ServerPlayer owner = master();
        if (--life <= 0 || owner == null || !owner.isAlive() || !RelativaAbilities.active(owner) || owner.level() != this.level()) {
            collapse();
            return;
        }
        if (punchCooldown > 0) {
            punchCooldown--;
        }
        if (dashCooldown > 0) {
            dashCooldown--;
        }
        if (dashAt >= 0) {
            if (--dashAt <= 0) {
                dashAt = -1;
                if (dashTo != null) {
                    this.teleportTo(dashTo.x, dashTo.y, dashTo.z);
                    this.resetFallDistance();
                    punchCooldown = 0;
                }
            }
            return;
        }
        if (this.tickCount % 5 == 0) {
            retarget(owner);
        }
        LivingEntity t = this.getTarget();
        if (t != null && (!t.isAlive() || t.isRemoved() || t.level() != this.level() || this.distanceToSqr(t) > HUNT * HUNT * 4.0
                || !RelativaSkills.valid(owner, t))) {
            this.setTarget(null);
            t = null;
        }
        if (t != null) {
            this.getLookControl().setLookAt(t, 30f, 30f);
            double dist = this.distanceTo(t);
            if (dashCooldown <= 0 && dist > DASH_MIN && dist < DASH_MAX && this.hasLineOfSight(t)) {
                Vec3 dir = RelativaSkills.flat(t.position().subtract(this.position()));
                Vec3 dest = t.position().subtract(dir.scale(1.4 + t.getBbWidth() * 0.5));
                if (!this.level().noCollision(this, this.getBoundingBox().move(dest.subtract(this.position())))) {
                    dest = t.position();
                }
                dash(dest);
            } else if (dist <= REACH + t.getBbWidth() * 0.5) {
                this.getNavigation().stop();
                if (punchCooldown <= 0) {
                    punch(owner, t);
                }
            } else if (--pathTicks <= 0) {
                this.getNavigation().moveTo(t, 1.35);
                pathTicks = 8;
            }
            return;
        }
        double d = this.distanceTo(owner);
        if (d > LEASH && dashCooldown <= 0) {
            Vec3 dest = owner.position().add((this.random.nextDouble() - 0.5) * 4.0, 0, (this.random.nextDouble() - 0.5) * 4.0);
            if (!this.level().noCollision(this, this.getBoundingBox().move(dest.subtract(this.position())))) {
                dest = owner.position();
            }
            dash(dest);
        } else if (d > 5.0 && --pathTicks <= 0) {
            this.getNavigation().moveTo(owner, 1.25);
            pathTicks = 10;
        }
    }

    private ServerPlayer master() {
        UUID id = owner();
        if (id == null || !(this.level() instanceof ServerLevel level)) {
            return null;
        }
        return level.getServer().getPlayerList().getPlayer(id);
    }

    /** Sasaran: yang sedang dihajar yang asli, yang memukul yang asli, atau monster terdekat. */
    private void retarget(ServerPlayer owner) {
        LivingEntity pick = null;
        LivingEntity hit = owner.getLastHurtMob();
        if (hit != null && owner.tickCount - owner.getLastHurtMobTimestamp() < 200 && hit.distanceToSqr(this) < HUNT * HUNT * 2.25
                && RelativaSkills.valid(owner, hit)) {
            pick = hit;
        }
        LivingEntity by = owner.getLastHurtByMob();
        if (pick == null && by != null && by.distanceToSqr(this) < HUNT * HUNT * 2.25 && RelativaSkills.valid(owner, by)) {
            pick = by;
        }
        if (pick == null && (this.getTarget() == null || !this.getTarget().isAlive())) {
            double best = HUNT * HUNT;
            for (LivingEntity e : this.level().getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(HUNT),
                    e -> e instanceof Enemy && e.isAlive() && RelativaSkills.valid(owner, e))) {
                double dd = e.distanceToSqr(this);
                if (dd < best) {
                    best = dd;
                    pick = e;
                }
            }
        }
        if (pick != null && pick != this.getTarget()) {
            this.setTarget(pick);
        }
    }

    /** Tinju foton: damage dewa, kredit (XP & barang jatuhan) buat yang asli, sasarannya membalas ke salinan ini. */
    private void punch(ServerPlayer owner, LivingEntity t) {
        this.swing(InteractionHand.MAIN_HAND);
        t.invulnerableTime = 0;
        if (t.hurt(this.damageSources().mobAttack(this), RelativaSkills.dmg(owner, PUNCH))) {
            t.setLastHurtByPlayer(owner);
            Vec3 away = RelativaSkills.flat(t.position().subtract(this.position()));
            t.push(away.x * 1.2, 0.35, away.z * 1.2);
            t.hurtMarked = true;
            anim(ShazamAnim.PHYS_PUNCH, RelativaSkills.chest(t));
            play(ShazamSounds.RELATIVA_CLONE_PUNCH.get(), 1.0f);
        }
        punchCooldown = PUNCH_GAP;
    }

    /** Lesat Cahaya ke dest (klip & efeknya di boneka), pindah di REL_DASH_AT. */
    private void dash(Vec3 dest) {
        dashTo = dest;
        dashAt = ShazamAnim.REL_DASH_AT;
        dashCooldown = DASH_GAP;
        this.getNavigation().stop();
        anim(ShazamAnim.RELATIVA_DASH, dest);
        play(ShazamSounds.RELATIVA_DASH.get(), 0.9f);
    }

    /** Teramati / umurnya habis: fungsi gelombangnya runtuh jadi partikel, lalu hilang. */
    public void collapse() {
        if (collapseTicks >= 0 || this.level().isClientSide()) {
            return;
        }
        collapseTicks = ShazamAnim.REL_CLONE_COLLAPSE;
        this.entityData.set(DATA_COLLAPSE, true);
        this.getNavigation().stop();
        this.setTarget(null);
        this.setDeltaMovement(Vec3.ZERO);
        anim(ShazamAnim.PHYS_CLONE_COLLAPSE, RelativaSkills.chest(this));
        play(ShazamSounds.RELATIVA_CLONE_COLLAPSE.get(), 1.2f);
        ServerPlayer owner = master();
        if (owner != null && !owner.hasDisconnected()) {
            RelativaNetwork.sync(owner);
        }
    }

    private void anim(ShazamAnim a, Vec3 pos) {
        PacketDistributor.sendToPlayersTrackingEntity(this, new ShazamAnimPayload(this.getId(), a.ordinal(), (float) pos.x,
                (float) pos.y, (float) pos.z));
    }

    private void play(SoundEvent sound, float volume) {
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(), sound, SoundSource.PLAYERS,
                volume * RelativaTier.SOUND, 0.95f + this.random.nextFloat() * 0.1f);
    }

    // ---------------------------------------------------------------- serangan: pengamatan

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide() || collapseTicks >= 0) {
            return false;
        }
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            collapse();   // /kill, void
            return true;
        }
        Entity by = source.getEntity(), direct = source.getDirectEntity();
        if (by == null && direct == null && !source.is(DamageTypeTags.IS_EXPLOSION)) {
            return false;   // api, jatuh, sesak: bukan pengamatan
        }
        if (ownedBy(by) || ownedBy(direct) || sibling(by) || sibling(direct)) {
            return false;   // yang asli & salinan lain nggak mengamati dirinya sendiri
        }
        collapse();
        return true;
    }

    private boolean sibling(Entity e) {
        return e instanceof RelativaClone c && Objects.equals(c.owner(), owner());
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean canBreatheUnderwater() {
        return true;
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return null;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return null;
    }

    // ---------------------------------------------------------------- simpan (dipakai saat pindah dimensi)

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        UUID id = owner();
        if (id != null) {
            tag.putUUID("RelativaOwner", id);
        }
        tag.putInt("RelativaLife", life);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("RelativaOwner")) {
            setOwner(tag.getUUID("RelativaOwner"), true);   // salinan yang dibuat ulang saat pindah dimensi
        }
        if (tag.contains("RelativaLife")) {
            life = tag.getInt("RelativaLife");
        }
    }
}
