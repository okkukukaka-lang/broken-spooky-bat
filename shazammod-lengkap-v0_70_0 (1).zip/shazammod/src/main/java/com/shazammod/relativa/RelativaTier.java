package com.shazammod.relativa;

/**
 * 0.68 RELATIVA juara tingkat dewa (setara PRALAYA Fase Dewa). Satu tempat buat semua pengali "besar"-nya, dipakai server
 * (RelativaSkills, RelativaLight, RelativaAbilities) dan client (RelativaFx, RelativaEffects, RelativaQuantum) supaya
 * dampak di server dan ukuran efek di layar selalu sama besar. Ubah angka di sini untuk membesarkan / mengecilkan semuanya
 * sekaligus (1 = ukuran 0.66-0.67).
 */
public final class RelativaTier {
    private RelativaTier() {}

    /** Radius, jangkauan, & ukuran efek area semua skill (2 = dua kali lipat 0.67). */
    public static final double AREA = 2.0;
    public static final float AREA_F = (float) AREA;
    /** Pengali damage semua skill. */
    public static final float DAMAGE = 3.0f;
    /** Pengali hempasan (knockback) skill. */
    public static final double PUSH = 1.6;
    /** Cooldown skill: 0,35 = tinggal 35% dari 0.67. */
    public static final float COOLDOWN = 0.35f;
    /** Biaya energi skill: 0,5 = separuh. */
    public static final float COST = 0.5f;
    /** Ukuran efek yang menempel di badan / tangan / sasaran (kilatan, inti atom, sinar, bintang mini). */
    public static final float FX = 1.5f;
    /** Guncangan kamera, kilatan layar, & jangkauan guncangan untuk pemain lain. */
    public static final float SHAKE = 1.5f;
    /** Volume suara skill (lebih dari 1 = terdengar lebih jauh: 16 blok x volume). */
    public static final float SOUND = 1.6f;

    /** Cooldown (detik) sesudah dikali COOLDOWN, paling sedikit 1 detik. Lama medan yang menyala ada di ShazamAnim.REL_*. */
    public static int cooldown(int seconds) {
        return seconds <= 0 ? 0 : Math.max(1, Math.round(seconds * COOLDOWN));
    }
}
