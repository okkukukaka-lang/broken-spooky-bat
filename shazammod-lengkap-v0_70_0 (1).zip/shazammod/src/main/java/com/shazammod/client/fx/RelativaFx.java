package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamSounds;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;
import com.shazammod.relativa.RelativaClientState;
import com.shazammod.relativa.RelativaData;
import com.shazammod.relativa.RelativaNetwork;
import com.shazammod.relativa.RelativaTier;
import com.shazammod.relativa.client.RelativaPhotonFlight;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 0.66 Efek RELATIVA (orisinal, fisika Einstein). Semua dibangun dari mesin efek mod ini (Fx, Hd, CineFx, CineKit,
 * ScreenFx) + efek khusus di RelativaEffects & huruf garis-cahaya di RelativaGlyphs, tick puncaknya = ShazamAnim.REL_*.
 * Tiap skill punya bahasa visual dari gambar fisikanya sendiri, dan hampir semuanya memakai partikel & atom:
 *
 *   selalu          atom di dada (inti proton-neutron + tiga orbit elektron), dua orbit besar di sekeliling badan, kisi
 *                   ruang-waktu yang melengkung di bawah kaki, persamaan yang sesekali melayang dari bahu
 *   berubah         telunjuk menulis E=mc² di udara, persamaannya terbang & dipadatkan ke dada jadi atom
 *   Lesat Cahaya    bayangan badan berderet, berkas cahaya, aberasi relativistik + Doppler di layar sendiri
 *   Dilatasi Waktu  kulit bola, pita jam, jam tanah yang jarumnya nyaris diam, jam cahaya Einstein, jam lambat di musuh
 *   Lengkung        kisi lembaran karet yang melengkung, kelereng uji yang berputar jatuh, lensa gravitasi tipis
 *   LUBANG HITAM    piringan akresi (berkas Doppler), jet relativistik, bayangan & cincin Einstein (shader lensa),
 *                   blok yang tercabut & termakan, radiasi Hawking
 *   Terowongan      paket gelombang ψ (riil & imajiner berpilin), Δx·Δp≥ħ/2, keruntuhan fungsi gelombang
 *   Keterikatan     panah spin atas/bawah di tiap sasaran, jaring yang berpendar, kilat saat damage mengalir
 *   Fisi            neutron melesat, inti membelah (tetes cairan) + 3 neutron + kilat gamma + cahaya Cherenkov
 *   Massa Kritis    inti uranium, neutron berlipat, lensa implosi, ledakan + awan Wilson + awan jamur + radiasi sisa
 *   Fusi            dua proton menyatu di telapak, bintang mini berkorona dilempar
 *   Tokamak         donat plasma: irisan poloidal, kumparan D, garis medan berpilin, gumpalan plasma
 *   E=mc²           persamaan emas ditulis lalu dilempar, massa sasaran terurai jadi cahaya
 *   Anihilasi       elektron & positron dipertemukan, dua sinar gamma berlawanan
 *   Medan Terpadu   empat cincin gaya (gravitasi, elektromagnet, kuat, lemah) merapat jadi singularitas
 *   Kondensat       atom melambat lalu menyatu, puncak kondensat berwarna palsu, es, nol mutlak
 *   Fotolistrik     foton = paket gelombang berkepala partikel, elektron terlepas melompat
 *   Laser           atom tereksitasi, sinar koheren sefase
 *   Gel. Gravitasi  kisi berpolarisasi "+", cincin partikel uji yang meregang & memampat
 *   Gerak Brown     molekul menabrak, jejak acak bergerigi
 *
 * 0.68 tingkat dewa: semua efek area ikut membesar sama dengan dampaknya di server (RelativaTier.AREA), efek di badan /
 * sasaran x RelativaTier.FX, guncangan kamera & jangkauannya x RelativaTier.SHAKE, ditambah kawah, tiang cahaya, dan
 * gelombang kejut baru di skill yang dampaknya ditambah.
 *
 * 0.70 (RelativaSpace): Jembatan Einstein-Rosen (mulut bola + lensa, ER=EPR), Foton Tanpa Massa (badan cahaya, paket
 * gelombang, aberasi saat mendekati c), Kucing Schrödinger (kotak yang terbuka, |ψ⟩=|0⟩+|1⟩, salinan runtuh jadi
 * partikel), Cincin Einstein (cincin cahaya menyempit ke badan, sesudahnya tinggal lensa, θE).
 */
public final class RelativaFx {
    private RelativaFx() {}

    // ======= warna =======
    public static final int LIGHT = 0xFFF6D8, PHOTON = 0xFFF07A, QUANTUM = 0x5CFFE1, RELATIV = 0x8FD8FF, GRAVITY = 0x9A6BFF,
            DISK = 0xFF8A3A, DISK_HOT = 0xFFE6B0, JET = 0x7FB8FF, URANIUM = 0x7CFF5A, CHERENKOV = 0x3FA8FF,
            NEUTRON = 0xC8D0D8, PROTON = 0xFF5A4A, PLASMA = 0xFF7AD9, PLASMA_HOT = 0xFFE0F6, GOLD = 0xFFD34D,
            POSITRON = 0xFF4FD8, ELECTRON = 0x4FE0FF, GAMMA = 0xE8DCFF, COLD = 0xA8F0FF, LASER = 0xFF2A3A,
            GWAVE = 0xB28CFF;
    /** Empat gaya fundamental: gravitasi, elektromagnet, gaya kuat, gaya lemah. */
    static final int[] FORCES = {GRAVITY, ELECTRON, 0xFF4040, 0x6CFF7A};
    private static final Vec3 UP = new Vec3(0, 1, 0);
    // 0.68 tingkat dewa (RelativaTier): ukuran area, ukuran efek di badan, guncangan
    private static final double S = RelativaTier.AREA;
    private static final float SF = RelativaTier.AREA_F, F = RelativaTier.FX, SH = RelativaTier.SHAKE;

    private static final Map<Integer, RelativaEffects.Aura> AURAS = new HashMap<>();
    private static final Map<Integer, Vec3> FROM = new HashMap<>();
    private static final Map<Integer, RelativaEffects.Web> WEBS = new HashMap<>();
    private static final Map<Integer, RelativaEffects.SpinMark> MARKS = new HashMap<>();
    private static final List<RelativaEffects.Lensing> LENSES = new ArrayList<>();
    private static int aberrationAge = -1, aberrationLife = 1;
    // 0.67 Kecepatan Cahaya & Terowongan Kuantum
    private static final Map<Integer, RelativaQuantum.PhaseCloud> PHASES = new HashMap<>();
    private static final Map<Integer, RelativaQuantum.LightTrail> TRAILS = new HashMap<>();
    private static final Map<Integer, RelativaQuantum.FrozenMark> FROZEN = new HashMap<>();
    private static final int PULSE_LIFE = 18, FROZEN_MAX = 48;
    private static Vec3 dashDir = new Vec3(0, 0, 1);
    private static Vec3 lastPos, motion = new Vec3(0, 0, 1);
    private static double speed;
    private static float betaVis, betaVisO, frozenLevel, frozenLevelO;
    private static boolean worldWas;
    private static int pulseAge = -1, phaseAge = -1, windupAge = -1, scan;
    // 0.70 lubang cacing, foton, cincin Einstein, kucing Schrödinger
    private static final Map<Integer, RelativaSpace.Mouth> MOUTHS = new HashMap<>();
    private static final Map<Integer, RelativaSpace.PhotonTrail> PHOTONS = new HashMap<>();
    private static final Map<Integer, RelativaSpace.CloakLens> CLOAKS = new HashMap<>();
    private static final Set<Integer> CLOAKED = new HashSet<>();
    private static final Map<UUID, Long> SPLITS = new HashMap<>();

    // ------------------------------------------------------------------ pintu masuk

    public static void onAnim(AbstractClientPlayer p, ShazamAnim anim, Vec3 pos) {
        if (!(p.level() instanceof ClientLevel level)) {
            return;
        }
        boolean self = p == Minecraft.getInstance().player;
        switch (anim) {
            case RELATIVA_RITE -> rite(p, self);
            case RELATIVA_TRANSFORM -> transform(p, self);
            case RELATIVA_REVERT -> revert(level, p);
            case RELATIVA_DASH -> dash(p, pos, self);
            case RELATIVA_DILATION -> dilation(p, self);
            case RELATIVA_WARP -> warp(p, pos);
            case RELATIVA_BLACKHOLE -> blackHole(p, pos, self);
            case RELATIVA_TUNNEL -> tunnel(p, pos, self);
            case RELATIVA_ENTANGLE -> entangle(p);
            case RELATIVA_FISSION -> fissionThrow(p, pos);
            case RELATIVA_CRITICAL -> critical(p, pos);
            case RELATIVA_FUSION -> fusion(p);
            case RELATIVA_TOKAMAK -> tokamak(p, self);
            case RELATIVA_EMC -> emc(level, p, pos, self);
            case RELATIVA_ANNIHILATE -> annihilate(p, self);
            case RELATIVA_UNIFIED -> unified(p, self);
            case RELATIVA_BEC -> condensate(level, p, self);
            case RELATIVA_PHOTO -> photo(p);
            case RELATIVA_LASER -> laser(p, self);
            case RELATIVA_GWAVE -> gravityWave(p, self);
            case RELATIVA_BROWN -> brownian(p);
            case PHYS_PAPER -> paper(p, (int) Math.round(pos.x), self);
            case PHYS_FROM -> FROM.put(p.getId(), pos);
            case PHYS_NEUTRON -> {
                Vec3 from = FROM.remove(p.getId());
                if (from != null) {
                    Vfx.add(new RelativaEffects.Neutron(from, pos, ShazamAnim.REL_FISSION_GAP - 1));
                }
            }
            case PHYS_FISSION -> fission(pos);
            case PHYS_ARC -> {
                Vec3 from = FROM.remove(p.getId());
                if (from != null) {
                    arc(from, pos);
                }
            }
            case PHYS_PHOTON -> photon(p, pos);
            case PHYS_FUSION_SHOT -> fusionShot(p, pos);
            case PHYS_ENTANGLE -> entangled(level, p, pos);
            case PHYS_ENTANGLE_PULSE -> entanglePulse(level, pos);
            case PHYS_FROZEN -> frozen(level, pos);
            case PHYS_UNIFIED_HIT -> unifiedHit(p, pos);
            case PHYS_BH_END -> hawking(level, p, pos, self);
            case PHYS_CRIT_BOOM -> nuke(level, p, pos);
            case PHYS_DISRUPT -> disrupt(p, pos);
            case PHYS_BROWN -> brownHop(p, FROM.remove(p.getId()), pos);
            case PHYS_DODGE -> dodge(p, pos);
            case PHYS_PUNCH -> punch(level, p, pos);
            case RELATIVA_LIGHT -> lightWindup(level, p, self);
            case RELATIVA_LIGHT_END -> lightResume(p, self);
            case RELATIVA_PHASE_ON -> phase(p, true, self);
            case RELATIVA_PHASE_OFF -> phase(p, false, self);
            case PHYS_TIME_HIT -> Vfx.add(new RelativaQuantum.TimeHit(pos, pos.subtract(p.getEyePosition()),
                    p.getRandom().nextFloat() * 6.28f));
            case PHYS_PHASE_PASS -> Vfx.add(new RelativaQuantum.PhasePass(pos, RelativaEffects.chestOf(p, 1f).subtract(pos)));
            case RELATIVA_WORMHOLE -> wormholeCast(p, pos, self);
            case RELATIVA_PHOTON_ON -> photonOn(p, self);
            case RELATIVA_PHOTON_OFF -> photonOff(p);
            case RELATIVA_CLONE -> cloneCast(level, p, self);
            case RELATIVA_CLOAK_ON -> cloak(p, true, self);
            case RELATIVA_CLOAK_OFF -> cloak(p, false, self);
            case PHYS_CLONE_COLLAPSE -> cloneCollapse(p, pos);
            case PHYS_CLONE_DECOY -> cloneDecoy(p, pos);
            case PHYS_CLOAK_STRIKE -> cloakStrike(p, pos);
            default -> { }
        }
    }

    /** Tiap tick client: atom di dada setiap RELATIVA yang terlihat, dan masa hidup aberasi. */
    public static void tick(ClientLevel level) {
        for (Integer id : RelativaClientState.all().keySet()) {
            RelativaEffects.Aura aura = AURAS.get(id);
            if ((aura == null || aura.dead()) && level.getEntity(id) instanceof AbstractClientPlayer p && p.isAlive()) {
                aura = new RelativaEffects.Aura(p);
                AURAS.put(id, aura);
                Vfx.add(aura);
            }
        }
        AURAS.values().removeIf(RelativaEffects.Aura::dead);
        MARKS.values().removeIf(m -> !m.e.isAlive());
        if (MARKS.size() > 96) {
            MARKS.clear();
        }
        if (aberrationAge >= 0 && ++aberrationAge > aberrationLife) {
            aberrationAge = -1;
        }
        tickQuantum(level);
        if (level.getGameTime() % 200 == 0) {
            RelativaClientState.all().keySet().removeIf(id -> !(level.getEntity(id) instanceof AbstractClientPlayer));
        }
    }

    public static void clear() {
        AURAS.clear();
        FROM.clear();
        WEBS.clear();
        MARKS.clear();
        LENSES.clear();
        aberrationAge = -1;
        PHASES.clear();
        TRAILS.clear();
        FROZEN.clear();
        MOUTHS.clear();
        PHOTONS.clear();
        CLOAKS.clear();
        CLOAKED.clear();
        SPLITS.clear();
        lastPos = null;
        speed = 0;
        betaVis = betaVisO = frozenLevel = frozenLevelO = 0f;
        worldWas = false;
        pulseAge = phaseAge = windupAge = -1;
    }

    /** Lensa gravitasi yang sedang aktif (dibaca RelativaLensShader): {x, y, z, jari-jari Einstein, bayangan, cincin, kuat}. */
    public static List<float[]> lenses(float pt) {
        LENSES.removeIf(l -> !l.alive());
        List<float[]> out = new ArrayList<>();
        for (RelativaEffects.Lensing l : LENSES) {
            float[] v = l.lens(pt);
            if (v != null && v[6] > 0.01f) {
                out.add(v);
            }
        }
        return out;
    }

    /** 0-1: aberrasi relativistik di layar pemain sendiri (Lesat Cahaya). */
    public static float aberration(float pt) {
        if (aberrationAge < 0) {
            return 0f;
        }
        float f = Mth.clamp((aberrationAge + pt) / aberrationLife, 0f, 1f);
        return (float) Math.sin(Math.PI * f);
    }

    private static void startAberration(int life) {
        aberrationAge = 0;
        aberrationLife = Math.max(1, life);
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            dashDir = mc.player.getLookAngle();
        }
    }

    // ------------------------------------------------------------------ 0.67 Kecepatan Cahaya & Terowongan Kuantum

    /** Awan atom tiap pemain yang menembus, jejak cahaya tiap pemegang waktu, jam beku, gerak pemain sendiri (β). */
    private static void tickQuantum(ClientLevel level) {
        Minecraft mc = Minecraft.getInstance();
        for (Map.Entry<Integer, Integer> e : RelativaClientState.all().entrySet()) {
            int id = e.getKey(), flags = e.getValue();
            if ((flags & RelativaNetwork.FLAG_PHASE) != 0) {
                RelativaQuantum.PhaseCloud c = PHASES.get(id);
                if ((c == null || c.dead()) && level.getEntity(id) instanceof AbstractClientPlayer p && p.isAlive()) {
                    c = new RelativaQuantum.PhaseCloud(p);
                    PHASES.put(id, c);
                    Vfx.add(c);
                }
            }
            if ((flags & RelativaNetwork.FLAG_LIGHT) != 0) {
                RelativaQuantum.LightTrail t = TRAILS.get(id);
                if ((t == null || t.dead()) && level.getEntity(id) instanceof AbstractClientPlayer p && p.isAlive()) {
                    t = new RelativaQuantum.LightTrail(p);
                    TRAILS.put(id, t);
                    Vfx.add(t);
                }
            }
        }
        PHASES.values().removeIf(RelativaQuantum.PhaseCloud::dead);
        TRAILS.values().removeIf(RelativaQuantum.LightTrail::dead);
        tickSpace(level);

        // waktu dunia berhenti / berjalan lagi: gelombang di layar, judul, jam beku di atas makhluk
        boolean stopped = RelativaClientState.worldStopped;
        boolean owner = mc.player != null && mc.player.getId() == RelativaClientState.worldOwner;
        if (stopped != worldWas) {
            worldWas = stopped;
            pulseAge = 0;
            if (stopped) {
                ScreenFx.titleKey(owner ? "title.shazammod.relativa.light" : "title.shazammod.relativa.time_stop", RELATIV, 50,
                        0);
            } else {
                ScreenFx.titleKey("title.shazammod.relativa.time_resume", LIGHT, 30, 0);
                FROZEN.clear();
            }
        }
        if (pulseAge >= 0 && ++pulseAge > PULSE_LIFE) {
            pulseAge = -1;
        }
        frozenLevelO = frozenLevel;
        frozenLevel += ((stopped ? 1f : 0f) - frozenLevel) * 0.2f;
        if (stopped && mc.player != null && ++scan % 10 == 0 && FROZEN.size() < FROZEN_MAX) {
            for (Entity e : level.entitiesForRendering()) {
                if (!(e instanceof LivingEntity) || e == mc.player || e.getId() == RelativaClientState.worldOwner
                        || FROZEN.containsKey(e.getId()) || e.distanceToSqr(mc.player) > 48.0 * 48.0) {
                    continue;
                }
                if (level.tickRateManager().isEntityFrozen(e) || e instanceof Player) {
                    RelativaQuantum.FrozenMark m = new RelativaQuantum.FrozenMark(e);
                    FROZEN.put(e.getId(), m);
                    Vfx.add(m);
                    if (FROZEN.size() >= FROZEN_MAX) {
                        break;
                    }
                }
            }
        }
        FROZEN.values().removeIf(m -> !m.e.isAlive() || m.e.isRemoved());

        // gerak pemain sendiri: kecepatan & arahnya menentukan aberasi / Doppler di layar
        if (mc.player != null) {
            Vec3 pos = mc.player.position();
            if (lastPos != null) {
                Vec3 v = pos.subtract(lastPos);
                double sp = v.length();
                if (sp > 6.0) {   // teleport, bukan gerak
                    sp = 0.0;
                    v = Vec3.ZERO;
                }
                speed = speed * 0.7 + sp * 0.3;
                if (sp > 0.02) {
                    Vec3 m = motion.scale(0.55).add(v.scale(0.45 / sp));
                    motion = m.lengthSqr() > 1.0E-6 ? m.normalize() : motion;
                }
            }
            lastPos = pos;
        }
        betaVisO = betaVis;
        int light = RelativaClientState.lightState;
        float target = 0f;
        if (light == 2 || light == 3) {
            target = (float) (0.5 * (1.0 - Math.exp(-speed / 0.55)));
        } else if (RelativaPhotonFlight.flying()) {   // 0.70 Foton Tanpa Massa mendekati c: aberasi & Doppler
            target = (float) Mth.clamp((RelativaPhotonFlight.speed() - 1.4) / 2.4, 0.0, 1.0) * 0.3f;
        } else if (light == 1 && windupAge >= 0) {
            target = 0.25f * Mth.clamp(windupAge / (float) ShazamAnim.REL_LIGHT_WINDUP, 0f, 1f);
        }
        betaVis += (target - betaVis) * 0.25f;
        if (windupAge >= 0 && ++windupAge > ShazamAnim.REL_LIGHT_WINDUP + 4) {
            windupAge = -1;
        }
        if (phaseAge >= 0 && phaseAge < 30) {
            phaseAge++;
        }
    }

    /** v/c yang ditampilkan HUD selama waktu berhenti: makin cepat berlari, makin dekat ke 1. */
    public static float lightBeta() {
        return (float) (1.0 - 0.5 * Math.exp(-4.0 * speed));
    }

    /** Faktor Lorentz γ = 1/√(1 − v²/c²). */
    public static float lightGamma() {
        double b = lightBeta();
        return (float) (1.0 / Math.sqrt(Math.max(1.0E-9, 1.0 - b * b)));
    }

    /**
     * Buat shader optik relativistik: {β, arah gerak x, y, z (dunia), waktu beku 0-1, gelombang waktu 0-1 (0 = nggak ada),
     * kilau Terowongan Kuantum 0-1}.
     */
    public static float[] optics(float pt) {
        Minecraft mc = Minecraft.getInstance();
        float beta = Mth.lerp(pt, betaVisO, betaVis);
        Vec3 dir = speed > 0.03 ? motion : mc.player != null ? mc.player.getViewVector(pt) : new Vec3(0, 0, 1);
        float dash = aberration(pt) * 0.5f;
        if (dash > beta) {
            beta = dash;
            dir = dashDir;
        }
        float frozen = Mth.lerp(pt, frozenLevelO, frozenLevel);
        float pulse = pulseAge < 0 ? 0f : Mth.clamp((pulseAge + pt) / PULSE_LIFE, 0.0001f, 0.9999f);
        float phase = 0f;
        if (RelativaClientState.phase && RelativaClientState.transformed) {
            float k = phaseAge < 0 ? 1f : Mth.clamp((phaseAge + pt) / 30f, 0f, 1f);
            phase = 1f - 0.72f * k;   // kuat saat atomnya baru berubah, lalu tinggal kilau tipis di pinggir layar
        }
        return new float[] {beta < 0.002f ? 0f : beta, (float) dir.x, (float) dir.y, (float) dir.z,
                frozen < 0.002f ? 0f : frozen, pulse, phase};
    }

    private static void lightWindup(ClientLevel level, AbstractClientPlayer p, boolean self) {
        int w = ShazamAnim.REL_LIGHT_WINDUP;
        Vfx.add(new RelativaQuantum.LightCone(p, w));
        int clocks = 0;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(24.0 * S),
                x -> x != p && x.isAlive())) {
            Vfx.add(new RelativaEffects.SlowClock(e, w + 4));   // jam-jam di sekitar melambat
            if (++clocks >= 40) {
                break;
            }
        }
        Vfx.add(new RelativaGlyphs.Glyphs("t'=t/γ", Lightning.Anchor.on(p, 0, p.getBbHeight() + 0.7, 0), null, null, 0.42,
                RELATIV, 8, w + 14, 0.008));
        CineFx.gather(p, 0, w, CineKit.chestAnchor(p), LIGHT, 1.3, 1.6f, false);
        if (self) {
            windupAge = 0;
            ScreenFx.speedLines(1.0f);
        }
        schedule(w, 1, (lvl, t) -> {   // waktu berhenti
            Vec3 at = RelativaEffects.chestOf(p, 1f);
            CineKit.burst(at, 2.4f * F, LIGHT, 0xFFFFFF, 14, 1.6f);
            Vfx.add(new Fx.Flash(at, 3.0f * F, 0xE8FBFF, 10, 1.0f));
            Vfx.add(new Fx.Ripple(p.position().add(0, 0.1, 0), UP, 0.0, 0.5, 18.0 * S, 0.4 * F, RELATIV, 18, 0.9f, false));
            Vfx.add(new Hd.Pressure(at, UP, 10.0 * S, Math.PI, 0xE8FBFF, 18, 0.7f, true));   // 0.68 ruang membeku
            CineKit.camera(p, at, 0.8f * SH, 32 * S);
            if (self) {
                FovKick.punch(0.24f);
            }
        });
    }

    private static void lightResume(AbstractClientPlayer p, boolean self) {
        int r = ShazamAnim.REL_LIGHT_RESUME;
        Lightning.Anchor hand = hand(p);
        CineFx.gather(p, 0, r, CineKit.chestAnchor(p), RELATIV, 1.1, 1.4f, false);
        Vfx.add(new RelativaGlyphs.Glyphs("t", pt -> hand.at(pt).add(0, 0.5, 0), null, null, 0.5, LIGHT, 4, r + 10,
                0.01));
        schedule(r, 1, (lvl, t) -> {   // waktu berjalan lagi
            Vec3 at = RelativaEffects.chestOf(p, 1f);
            CineKit.burst(at, 1.8f * F, RELATIV, 0xFFFFFF, 12, 1.4f);
            Vfx.add(new Fx.Ripple(p.position().add(0, 0.1, 0), UP, 0.0, 0.5, 14.0 * S, 0.35 * F, LIGHT, 16, 0.8f, false));
            CineKit.camera(p, at, 0.6f * SH, 28 * S);
            if (self) {
                FovKick.punch(-0.12f);
            }
        });
    }

    /** Terowongan Kuantum nyala / mati: bidang ukur menyapu badan, atomnya berubah (atau runtuh kembali). */
    private static void phase(AbstractClientPlayer p, boolean on, boolean self) {
        int dur = on ? ShazamAnim.REL_PHASE_SWEEP : ShazamAnim.REL_PHASE_OFF;
        Vfx.add(new RelativaQuantum.PhaseSweep(p, on, dur));
        double h = p.getBbHeight();
        if (on) {
            schedule(dur, 1, (lvl, t) -> {
                Vec3 c = RelativaEffects.chestOf(p, 1f);
                Vfx.add(new RelativaGlyphs.Glyphs("ψ", Lightning.Anchor.on(p, 0, h + 0.6, 0), null, null, 0.8, GRAVITY, 0, 36,
                        0.012));
                CineKit.burst(c, 1.4f, GRAVITY, 0xFFFFFF, 12, 1.2f);
            });
        } else {
            schedule(dur, 1, (lvl, t) -> {
                Vec3 c = RelativaEffects.chestOf(p, 1f);
                Vfx.add(new RelativaGlyphs.Glyphs("Δx·Δp≥ħ/2", Lightning.Anchor.on(p, 0, h + 0.6, 0), null, null, 0.34,
                        RELATIV, 10, 40, 0.01));
                Vfx.add(new Fx.Flash(c, 1.4f, 0xFFFFFF, 6, 1.0f));
            });
        }
        if (self) {
            phaseAge = on ? 0 : -1;
        }
    }

    // ------------------------------------------------------------------ Eksperimen Pikiran, berubah, kembali

    private static void rite(AbstractClientPlayer p, boolean self) {
        int burst = ShazamAnim.REL_RITE_BURST, total = ShazamAnim.REL_RITE_TICKS;
        if (self) {
            ScreenFx.cinema(total + 8);
            ScreenFx.titleKey("title.shazammod.relativa.rite", RELATIV, 70, 8);
            ScreenFx.vignette(0.35f, 0x10203A, total);
        }
        for (int k = 0; k < 4; k++) {   // keempat makalah 1905 datang satu per satu lalu mengorbit
            final int kind = k, start = 10 + k * 20;
            schedule(start, 1, (lvl, t) -> {
                Vfx.add(new RelativaEffects.Paper(p, kind, kind * Math.PI / 2.0, burst + 2 - start, burst - 12 - start, true));
                Vfx.add(new Fx.Flash(CineKit.chest(p), 0.6f, paperColor(kind), 8, 0.7f));
            });
        }
        schedule(40, 1, (lvl, t) -> Vfx.add(new RelativaEffects.SpacetimeGrid(CineKit.feet(p), 8.0, 50, burst - 40,
                total - 40, false)));
        schedule(90, burst - 90, (lvl, t) -> {   // mengejar berkas cahaya: foton berputar makin cepat
            double ang = t * (0.2 + t * 0.006), r = 3.0 - t * 0.02;
            Vec3 c = CineKit.chest(p);
            Vec3 q = c.add(Math.cos(ang) * r, Math.sin(t * 0.15) * 0.4, Math.sin(ang) * r);
            Vfx.streak(q.x, q.y, q.z, -Math.sin(ang) * 0.4, 0, Math.cos(ang) * 0.4, LIGHT, 0.12f, 10);
            Vfx.mote(q.x, q.y, q.z, 0, 0, 0, PHOTON, 0.1f, 6);
        });
        CineFx.gather(p, burst - 30, 30, CineKit.chestAnchor(p), RELATIV, 2.4, 2.6f, true);
        schedule(burst, 1, (lvl, t) -> {
            Vec3 c = CineKit.chest(p);
            CineKit.burst(c, 2.2f, RELATIV, 0xFFFFFF, 18, 1f);
            CineKit.shock(lvl, CineKit.feet(p), UP, 8.0, RELATIV, LIGHT, 22, 0.9f, true);
            Vfx.add(new Fx.Pillar(CineKit.feet(p), 14.0, 1.4f, LIGHT, 24));
            CineFx.godRays(CineKit.chestAnchor(p), RELATIV, 16.0, 2.0, 10, 0.8f, 40);
            atomBurst(c, 3.0);
            Vfx.add(new RelativaGlyphs.Glyphs("E=mc²", Lightning.Anchor.fixed(c.add(0, 1.7, 0)), null, null, 0.7, GOLD, 0, 50,
                    0.01));
            CineKit.camera(p, c, 0.9f, 26);
            if (self) {
                ScreenFlash.flash(0.6f, 0xD8F0FF);
                FovKick.punch(-0.08f);
                ScreenFx.titleKey("title.shazammod.relativa.unlock", GOLD, 60, 2);
            }
        });
    }

    private static void transform(AbstractClientPlayer p, boolean self) {
        int burst = ShazamAnim.REL_MORPH_BURST;
        if (self) {
            ScreenFx.cinema(ShazamAnim.REL_MORPH_TICKS + 6);
            ScreenFx.titleKey("title.shazammod.relativa.transform", RELATIV, 46, burst);
        }
        Vec3 look = p.getViewVector(1f);
        Vec3[] basis = RelativaGlyphs.readableFrom(look);
        Vec3 at = p.getEyePosition(1f).add(CineKit.flat(look).scale(1.3)).add(0, -0.1, 0);
        Vfx.add(new RelativaGlyphs.Glyphs("E=mc²", Lightning.Anchor.fixed(at), basis[0], basis[1], 0.42, LIGHT, 18, burst + 2,
                0.0).fly(burst - 6, 6, CineKit.chestAnchor(p)));
        CineFx.gather(p, 4, burst - 4, CineKit.chestAnchor(p), ELECTRON, 1.6, 2.0f, true);
        schedule(burst, 1, (lvl, t) -> {
            Vec3 c = CineKit.chest(p);
            CineKit.burst(c, 1.8f * F, RELATIV, 0xFFFFFF, 14, 1f);
            CineKit.shock(lvl, CineKit.feet(p), UP, 9.0, RELATIV, LIGHT, 22, 0.9f, true);
            atomBurst(c, 2.6 * F);
            Vfx.add(new Hd.Pressure(c, UP, 9.0, Math.PI, RELATIV, 14, 0.8f, true));
            // 0.68 tingkat dewa: tiang cahaya, sinar dewa, nova, dan E=mc² menyala di atas kepala
            Vfx.add(new Fx.Pillar(CineKit.feet(p), 22.0, 1.8f, LIGHT, 28));
            CineFx.godRays(CineKit.chestAnchor(p), RELATIV, 16.0, 2.2, 12, 0.75f, 34);
            Vfx.add(new Hd.Nova(c, 4.5, 0xFFFFFF, RELATIV, GRAVITY, 0, 20, 0.8f, false));
            Vfx.add(new RelativaGlyphs.Glyphs("E=mc²", Lightning.Anchor.on(p, 0, p.getBbHeight() + 1.1, 0), null, null, 0.6, GOLD,
                    0, 44, 0.01));
            CineKit.camera(p, c, 0.6f * SH, 20 * S);
            if (self) {
                ScreenFlash.flash(0.5f, 0xD8F0FF);
                FovKick.punch(-0.09f);
            }
        });
    }

    private static void revert(ClientLevel level, AbstractClientPlayer p) {
        Vec3 c = CineKit.chest(p);
        CineKit.motesOut(c, 34, ELECTRON, 0.09, 0.06f, 20);
        CineKit.motesOut(c, 18, LIGHT, 0.06, 0.05f, 16);
        Vfx.add(new Fx.Flash(c, 0.9f, RELATIV, 8, 0.6f));
        ShazamFx.smokeCloud(level, CineKit.feet(p), 0x30405A, 3, 0.7);
    }

    /** Tiga orbit elektron besar yang mengembang dari satu titik (atom terbentuk / terlepas). */
    private static void atomBurst(Vec3 c, double size) {
        for (int k = 0; k < 3; k++) {
            double ang = k * Math.PI / 3.0;
            Vec3 n = new Vec3(Math.sin(ang) * 0.9, 0.45, Math.cos(ang) * 0.9).normalize();
            Vfx.add(new Fx.Ripple(c, n, 0.0, 0.2, size, 0.08, ELECTRON, 18, 0.9f, false));
        }
        CineKit.motesOut(c, 30, ELECTRON, 0.12, 0.06f, 16);
    }

    // ------------------------------------------------------------------ Z  Relativitas Khusus

    private static void dash(AbstractClientPlayer p, Vec3 dest, boolean self) {
        int at = ShazamAnim.REL_DASH_AT;
        CineFx.gather(p, 0, at, CineKit.chestAnchor(p), PHOTON, 0.8, 1.4f, false);
        schedule(at, 1, (lvl, t) -> {
            Vec3 start = p.position();
            Vec3 a = start.add(0, 1.0, 0), b = dest.add(0, 1.0, 0);
            Vec3 dir = b.subtract(a);
            if (dir.lengthSqr() < 1.0E-4) {
                return;
            }
            Vec3 unit = dir.normalize();
            float yaw = p.yBodyRot;
            for (int i = 0; i < 10; i++) {   // bayangan badan berderet sepanjang lintasan cahaya
                double f = i / 9.0;
                Vfx.add(new Hd.Ghost(start.lerp(dest, f), yaw, 1.0, 1, RELATIV, LIGHT, 8 + i, 0.6f * (float) (1.0 - f * 0.6)));
            }
            RandomSource r = lvl.random;
            for (int i = 0, n = Vfx.count(48); i < n; i++) {
                Vec3 q = a.lerp(b, r.nextDouble()).add((r.nextDouble() - 0.5) * 1.2, (r.nextDouble() - 0.5) * 1.6,
                        (r.nextDouble() - 0.5) * 1.2);
                Vfx.streak(q.x, q.y, q.z, unit.x * 1.2, unit.y * 1.2, unit.z * 1.2, i % 3 == 0 ? 0xFFFFFF : PHOTON, 0.1f, 7);
            }
            Vfx.add(new Hd.Lance(a, b, 0.5f * F, RELATIV, 0xFFFFFF, 2, 9));
            Vfx.add(new Fx.Flash(b, 1.2f * F * 1.4f, LIGHT, 8, 0.9f));
            Vfx.add(new Fx.Ripple(b, unit, 0.0, 0.2, 2.2 * S, 0.15 * F, RELATIV, 12, 0.8f, false));
            CineKit.shock(lvl, dest, UP, 4.5, RELATIV, LIGHT, 14, 0.8f, true);   // 0.68 ledakan sonik di tujuan
            CineKit.camera(p, b, 0.35f * SH, 24 * S);
            Vfx.add(new RelativaGlyphs.Glyphs("c", Lightning.Anchor.fixed(b.add(0, 1.0, 0)), null, null, 0.4, PHOTON, 0, 20, 0.02));
            if (self) {
                startAberration(14);
                FovKick.punch(0.12f);
                ScreenFx.speedLines(0.8f);
            }
        });
    }

    private static void dilation(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.REL_DILATION_HIT;
        CineFx.gather(p, 0, hit, hand(p), RELATIV, 0.9, 1.4f, false);
        schedule(hit, 1, (lvl, t) -> {
            Vfx.add(new RelativaEffects.DilationField(p, 9.0 * S, ShazamAnim.REL_DILATION_TICKS));
            Vfx.add(new Fx.Flash(CineKit.chest(p), 1.4f * F, RELATIV, 10, 0.8f));
            Vfx.add(new Hd.Pressure(CineKit.chest(p), UP, 9.0 * S, Math.PI, RELATIV, 16, 0.6f, true));
            Vfx.add(new RelativaGlyphs.Glyphs("t'=γt", Lightning.Anchor.on(p, 0, p.getBbHeight() + 2.6, 0), null, null, 0.4 * F,
                    RELATIV, 12, 60, 0.0));
            CineKit.camera(p, CineKit.chest(p), 0.3f * SH, 18 * S);
            if (self) {
                ScreenFx.vignette(0.3f, 0x203A5A, 40);
                FovKick.punch(-0.05f);
            }
        });
    }

    // ------------------------------------------------------------------ X  Relativitas Umum

    private static void warp(AbstractClientPlayer p, Vec3 c) {
        int hit = ShazamAnim.REL_WARP_HIT, slam = ShazamAnim.REL_WARP_SLAM;
        RelativaEffects.SpacetimeGrid grid = new RelativaEffects.SpacetimeGrid(c, 7.0 * S, hit, slam, slam + 16, true);
        Vfx.add(grid);
        LENSES.add(grid);
        CineFx.gather(p, 0, hit, hand(p), GRAVITY, 1.0, 1.6f, false);
        Vfx.add(new RelativaGlyphs.Glyphs("G", Lightning.Anchor.fixed(c.add(0, 3.6 * S, 0)), null, null, 0.8 * F, GRAVITY, 8,
                slam + 8, 0.0));
        schedule(slam, 1, (lvl, t) -> {
            Vfx.add(new Fx.Flash(c.add(0, 0.6, 0), 2.0f * F * 1.3f, GRAVITY, 10, 0.9f));
            CineKit.shock(lvl, c, UP, 6.5 * S, GRAVITY, LIGHT, 22, 0.9f, true);
            ShazamFx.impact(lvl, p, c, 1.6f * F, GRAVITY, LIGHT, true);
            CineKit.crater(lvl, c, 3.0, GRAVITY, 0x5A5048, 34);   // 0.68 kawah hentakan
            Vfx.add(new Hd.Pressure(c.add(0, 0.5, 0), UP, 7.0 * S, Math.PI, GRAVITY, 16, 0.7f, true));
            CineKit.camera(p, c, 0.7f * SH, 24 * S);
        });
    }

    private static void blackHole(AbstractClientPlayer p, Vec3 c, boolean self) {
        int form = ShazamAnim.REL_BH_FORM;
        RelativaEffects.BlackHole hole = new RelativaEffects.BlackHole(p, c, form, ShazamAnim.REL_BH_TICKS);
        Vfx.add(hole);
        LENSES.add(hole);
        CineFx.gather(p, 0, form, hand(p), GRAVITY, 1.2, 2.2f, true);
        schedule(form, 1, (lvl, t) -> {   // runtuh: kilatan, lalu gelap
            Vfx.add(new Fx.Flash(c, 2.6f * F * 1.3f, 0xFFFFFF, 6, 1f));
            Vfx.add(new Hd.Pressure(c, UP, 7.0 * S, Math.PI, GRAVITY, 14, 0.8f, true));
            CineKit.shock(lvl, c, UP, 8.0 * S, GRAVITY, DISK_HOT, 22, 0.8f, false);
            CineKit.camera(p, c, 0.8f * SH, 30 * S);
            if (self) {
                FovKick.punch(-0.1f);
                ScreenFx.titleKey("title.shazammod.relativa.blackhole", GRAVITY, 40, 0);
            }
        });
        schedule(form, ShazamAnim.REL_BH_TICKS, (lvl, t) -> {
            if (t % 10 == 0) {
                ShazamFx.shakeAround(c, 0.12f * SH, 22 * S);
            }
        });
    }

    private static void hawking(ClientLevel level, AbstractClientPlayer p, Vec3 c, boolean self) {
        Vfx.add(new Fx.Flash(c, 3.0f * F * 1.3f, 0xFFFFFF, 12, 1f));
        Vfx.add(new Hd.Nova(c, 6.0 * S, 0xFFFFFF, 0xC8B0FF, GRAVITY, 0, 26, 1f, false));
        CineKit.burst(c, 2.4f * F, GRAVITY, 0xFFFFFF, 18, 1f);
        CineKit.motesOut(c, 120, LIGHT, 0.5, 0.08f, 22);   // radiasi Hawking: partikel lepas dari cakrawala
        CineKit.sparks(c, 70, GAMMA, 0.9, 0.07f, 16, c.y - 12);
        CineKit.shock(level, c, UP, 9.0 * S, GRAVITY, 0xFFFFFF, 24, 1f, false);
        Vec3 ground = c.subtract(0, 2.6 * S, 0);
        CineKit.shock(level, ground, UP, 7.0 * S, GRAVITY, LIGHT, 22, 0.9f, true);   // 0.68 gelombang & kawah di tanah
        CineKit.crater(level, ground, 5.0, GRAVITY, 0x3A3048, 40);
        CineKit.camera(p, c, 1.0f * SH, 32 * S);
        if (self) {
            ScreenFlash.flash(0.45f, 0xE8E0FF);
        }
    }

    // ------------------------------------------------------------------ C  Kuantum

    private static void tunnel(AbstractClientPlayer p, Vec3 dest, boolean self) {
        int at = ShazamAnim.REL_TUNNEL_AT;
        Vec3 a = p.position().add(0, 1.0, 0), b = dest.add(0, 1.0, 0);
        Vfx.add(new RelativaEffects.WavePacket(a, b, at - 3, 5, at + 10));
        Vfx.add(new Hd.Ghost(p.position(), p.yBodyRot, 1.0, 0, QUANTUM, 0xFFFFFF, at + 6, 0.6f));
        Vfx.add(new RelativaGlyphs.Glyphs("Δx·Δp≥ħ/2", Lightning.Anchor.fixed(a.add(0, 1.3, 0)), null, null,
                0.22, QUANTUM, 6, at + 14, 0.01));
        schedule(0, at, (lvl, t) -> {   // awan peluang: badan mengabur
            RandomSource r = lvl.random;
            for (int i = 0; i < 4; i++) {
                Vec3 o = ShazamFx.randomDir(r).scale(0.4 + r.nextDouble() * 0.6);
                Vfx.mote(a.x + o.x, a.y + o.y * 1.2, a.z + o.z, 0, 0, 0, QUANTUM, 0.06f, 8);
            }
        });
        schedule(at, 1, (lvl, t) -> {   // fungsi gelombang runtuh di tujuan
            Vfx.add(new Fx.Flash(b, 1.3f * F, QUANTUM, 8, 0.9f));
            Vec3[] planes = {UP, new Vec3(1, 0, 0), new Vec3(0, 0, 1)};
            for (Vec3 n : planes) {
                Vfx.add(new Fx.Ripple(b, n, 0.0, 0.1, 1.8 * S, 0.07 * F, QUANTUM, 12, 0.8f, false));
            }
            CineKit.shock(lvl, dest, UP, 3.2 * S, QUANTUM, 0xFFFFFF, 14, 0.7f, true);   // 0.68 gelombang peluang runtuh
            Vfx.add(new RelativaGlyphs.Glyphs("ψ", Lightning.Anchor.fixed(b.add(0, 1.6, 0)), null, null, 0.5 * F, QUANTUM, 0, 18,
                    0.02));
            CineKit.motesOut(b, 40, QUANTUM, 0.22, 0.06f, 14);
            if (self) {
                FovKick.punch(0.06f);
            }
        });
    }

    private static void entangle(AbstractClientPlayer p) {
        int hit = ShazamAnim.REL_ENTANGLE_HIT;
        RelativaEffects.Web web = new RelativaEffects.Web(hit + ShazamAnim.REL_ENTANGLE_TICKS);
        RelativaEffects.Web old = WEBS.put(p.getId(), web);
        if (old != null) {   // 0.68 cooldown lebih pendek dari lamanya: keterikatan lama diganti yang baru
            for (Entity n : old.nodes) {
                RelativaEffects.SpinMark m = MARKS.remove(n.getId());
                if (m != null) {
                    m.cut();
                }
            }
            old.nodes.clear();
        }
        Vfx.add(web);
        CineFx.gather(p, 0, hit, hand(p), ELECTRON, 0.8, 1.4f, false);
        CineFx.gather(p, 0, hit, handL(p), POSITRON, 0.8, 1.4f, false);
    }

    private static void entangled(ClientLevel level, AbstractClientPlayer p, Vec3 pos) {
        LivingEntity e = near(level, pos, 2.5);
        Vfx.add(new Fx.Flash(pos, 0.8f * F, QUANTUM, 8, 0.8f));
        if (e == null) {
            return;
        }
        RelativaEffects.Web web = WEBS.get(p.getId());
        boolean upSpin = web == null || web.nodes.size() % 2 == 0;   // pasangan terikat: spinnya selalu berlawanan
        if (web != null) {
            web.nodes.add(e);
        }
        RelativaEffects.SpinMark mark = new RelativaEffects.SpinMark(e, upSpin, ShazamAnim.REL_ENTANGLE_TICKS);
        RelativaEffects.SpinMark oldMark = MARKS.put(e.getId(), mark);
        if (oldMark != null) {
            oldMark.cut();
        }
        Vfx.add(mark);
        Lightning.Anchor to = Lightning.Anchor.on(e, 0, e.getBbHeight() * 0.62, 0);
        Vfx.add(new Lightning.Arc(hand(p), to, ELECTRON, 0.08f, 8, 2, 0, 0.2));
        Vfx.add(new Lightning.Arc(handL(p), to, POSITRON, 0.08f, 8, 2, 0, 0.2));
    }

    private static void entanglePulse(ClientLevel level, Vec3 pos) {
        LivingEntity e = near(level, pos, 2.5);
        if (e != null) {
            RelativaEffects.SpinMark m = MARKS.get(e.getId());
            if (m != null) {
                m.pulse();
            }
        }
        Vfx.add(new Fx.Flash(pos, 0.7f * F, POSITRON, 6, 0.8f));
        CineKit.sparks(pos, 14, QUANTUM, 0.28, 0.05f, 9, pos.y - 2);
        CineKit.sound(level, pos, ShazamSounds.RELATIVA_ENTANGLE_PULSE, 0.8f, 1f);
    }

    // ------------------------------------------------------------------ V  Fisi

    private static void fissionThrow(AbstractClientPlayer p, Vec3 target) {
        int hit = ShazamAnim.REL_FISSION_HIT;
        CineFx.gather(p, 0, hit - 4, hand(p), URANIUM, 0.6, 1.2f, false);
        schedule(hit - 4, 1, (lvl, t) -> Vfx.add(new RelativaEffects.Neutron(handNow(p), target, 4)));
    }

    private static void fission(Vec3 c) {
        Vfx.add(new RelativaEffects.Fission(c, 30));
        Vfx.add(new Fx.Flash(c, 1.0f * F * 1.2f, CHERENKOV, 8, 0.9f));
        Vfx.add(new Fx.Ripple(c, UP, 0.0, 0.2, 1.6 * S, 0.08 * F, URANIUM, 12, 0.8f, false));
        CineKit.sparks(c, 24, URANIUM, 0.45, 0.06f, 11, c.y - 3);
    }

    private static void critical(AbstractClientPlayer p, Vec3 c) {
        int core = ShazamAnim.REL_CRIT_CORE, boom = ShazamAnim.REL_CRIT_BOOM;
        CineFx.gather(p, 0, core, hand(p), URANIUM, 0.8, 1.4f, false);
        schedule(core - 6, 1, (lvl, t) -> Vfx.add(new RelativaEffects.CriticalCore(handNow(p), c, 6, boom - (core - 6))));
        schedule(core, 1, (lvl, t) -> Vfx.add(new RelativaGlyphs.Glyphs("U", Lightning.Anchor.fixed(c.add(0, 4.5, 0)), null, null,
                0.7 * F, URANIUM, 6, boom - core, 0.0)));
    }

    private static void nuke(ClientLevel level, AbstractClientPlayer p, Vec3 c) {
        Vfx.add(new Fx.Flash(c, 7.0f * SF, 0xFFFFFF, 14, 1f));
        Vfx.add(new Hd.Nova(c, 9.0 * S, 0xFFFFFF, 0xFFB050, 0x9A2A10, 0x4A3A30, 48, 1f, true));
        Vfx.add(new Hd.Pressure(c, UP, 14.0 * S, Math.PI, 0xFFF0E0, 22, 0.9f, true));
        Vfx.add(new Fx.Wave(c, UP, 15.0 * S, 1.6 * S, 0xF0F0F0, 36, 0.6f, 0f, null, true));   // awan Wilson: cincin kondensasi
        CineKit.shock(level, c, UP, 16.0 * S, 0xFFE0B0, 0xFFFFFF, 30, 1f, true);
        CineKit.crater(level, c, 11.0, 0xFF8030, 0x6A5A4A, 50);
        CineFx.flare(c, 0xFFFFFF, 18f * SF, 0.8f, 1f, 24);
        CineKit.embers(c, 120, 6.0 * S, 0.35, 0.14f, 60);
        Vfx.add(new RelativaEffects.Mushroom(c, 140));
        Vfx.add(new Hd.Haze(Lightning.Anchor.fixed(c), 7.0 * S, 4.0 * S, 16, URANIUM, 200, 0.5f));   // radiasi sisa
        CineKit.camera(p, c, 1.4f * SH, 48 * S);
        LocalPlayer me = Minecraft.getInstance().player;
        if (me != null) {
            double dist = me.position().distanceTo(c);
            if (dist < 64.0 * S) {
                float k = (float) (1.0 - dist / (64.0 * S));
                ScreenFlash.flash(0.95f * k, 0xFFF6E8);
                FovKick.punch(-0.16f * k);
            }
        }
    }

    // ------------------------------------------------------------------ B  Fusi

    private static void fusion(AbstractClientPlayer p) {
        int th = ShazamAnim.REL_FUSION_THROW;
        schedule(0, th, (lvl, t) -> {   // dua proton berputar makin rapat di antara kedua telapak
            Vec3 m = ShazamPoses.handPos(p, true, 1f).lerp(ShazamPoses.handPos(p, false, 1f), 0.5);
            double ang = t * 0.9, rr = 0.32 * (1.0 - t / (double) th) + 0.03;
            Vfx.mote(m.x + Math.cos(ang) * rr, m.y + Math.sin(ang * 2.0) * 0.05, m.z + Math.sin(ang) * rr, 0, 0, 0, PROTON, 0.11f, 3);
            Vfx.mote(m.x - Math.cos(ang) * rr, m.y - Math.sin(ang * 2.0) * 0.05, m.z - Math.sin(ang) * rr, 0, 0, 0, PROTON, 0.11f, 3);
        });
        CineFx.gather(p, 0, th, hand(p), PLASMA, 0.7, 1.4f, false);
        schedule(th, 1, (lvl, t) -> {   // H + H -> He: kilatan fusi
            Vec3 h = handNow(p);
            Vfx.add(new Fx.Flash(h, 1.2f * F, PLASMA_HOT, 8, 1f));
            CineKit.sparks(h, 20, PLASMA, 0.32, 0.05f, 9, h.y - 2);
        });
    }

    private static void fusionShot(AbstractClientPlayer p, Vec3 impact) {
        Vec3 from = p.getEyePosition(1f).add(0, -0.3, 0);
        int travel = Math.max(1, (int) Math.ceil(from.distanceTo(impact) / RelativaData.FUSION_SPEED));
        Vfx.add(new RelativaEffects.FusionStar(p, handNow(p), impact, travel));
    }

    static void fusionBoom(ClientLevel level, AbstractClientPlayer owner, Vec3 b) {
        Vfx.add(new Hd.Nova(b, 4.5 * S, 0xFFFFFF, PLASMA, 0x8A2080, 0x3A2A30, 28, 1f, false));
        CineKit.burst(b, 1.6f * F, PLASMA, 0xFFFFFF, 14, 1f);
        CineKit.shock(level, b, UP, 5.0 * S, PLASMA, PLASMA_HOT, 20, 0.8f, true);
        CineKit.sparks(b, 60, PLASMA_HOT, 0.65, 0.07f, 14, b.y - 4);
        CineKit.embers(b, 36, 2.0 * S, 0.14, 0.09f, 36);
        CineKit.crater(level, b, 3.0, 0xFF6AD0, 0x5A4A50, 30);   // 0.68 bintang mini meninggalkan kawah
        CineFx.flare(b, PLASMA_HOT, 9f, 0.35f, 1f, 16);
        CineKit.camera(owner, b, 0.6f * SH, 22 * S);
    }

    private static void tokamak(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.REL_TOKAMAK_HIT;
        CineFx.gather(p, 0, hit, CineKit.chestAnchor(p), PLASMA, 1.6, 1.8f, true);
        schedule(hit, 1, (lvl, t) -> {
            Vfx.add(new RelativaEffects.Tokamak(p, 4.5 * S, 0.85 * 1.5, ShazamAnim.REL_TOKAMAK_TICKS + 4));
            Vfx.add(new Fx.Wave(p.position().add(0, 1.0, 0), UP, 4.5 * S, 0.6 * F, PLASMA, 14, 0.9f, 0f, null));
            Vfx.add(new Fx.Flash(CineKit.chest(p), 1.5f * F, PLASMA_HOT, 8, 0.8f));
            CineKit.camera(p, CineKit.chest(p), 0.3f * SH, 16 * S);
            if (self) {
                FovKick.punch(-0.04f);
            }
        });
    }

    private static void disrupt(AbstractClientPlayer p, Vec3 c) {
        Vfx.add(new Fx.Wave(c, UP, 8.5 * S, 0.8 * S, PLASMA, 18, 1f, 0.05f, null));
        Vfx.add(new Fx.Wave(c, UP, 6.0 * S, 0.3 * S, 0xFFFFFF, 12, 0.9f, 0f, null));
        Vfx.add(new Hd.Pressure(c, UP, 8.0 * S, Math.PI, PLASMA, 16, 0.8f, true));
        Vfx.add(new Fx.Flash(c, 2.4f * F * 1.3f, PLASMA_HOT, 12, 0.9f));
        CineKit.sparks(c, 80, PLASMA_HOT, 0.9, 0.07f, 16, c.y - 1.5);
        CineKit.camera(p, c, 0.7f * SH, 24 * S);
    }

    // ------------------------------------------------------------------ N  E = mc²

    private static void emc(ClientLevel level, AbstractClientPlayer p, Vec3 pos, boolean self) {
        int write = ShazamAnim.REL_EMC_WRITE, hit = ShazamAnim.REL_EMC_HIT;
        LivingEntity target = near(level, pos, 3.0);
        Vec3 look = p.getViewVector(1f);
        Vec3[] basis = RelativaGlyphs.readableFrom(look);
        Vec3 at = p.getEyePosition(1f).add(CineKit.flat(look).scale(1.6)).add(0, 0.25, 0);
        Lightning.Anchor dest = target != null ? Lightning.Anchor.on(target, 0, target.getBbHeight() * 0.62, 0)
                : Lightning.Anchor.fixed(pos);
        Vfx.add(new RelativaGlyphs.Glyphs("E=mc²", Lightning.Anchor.fixed(at), basis[0], basis[1], 0.55, GOLD, write - 1,
                hit + 2, 0.0).fly(write + 2, hit - write - 2, dest));
        CineFx.gather(p, 0, write, hand(p), GOLD, 0.6, 1.2f, false);
        if (self) {
            ScreenFx.titleKey("title.shazammod.relativa.emc", GOLD, 30, write);
        }
        schedule(hit, 1, (lvl, t) -> {
            Entity e = target != null && target.isAlive() ? target : null;
            Vec3 c = e != null ? RelativaEffects.chestOf(e, 1f) : pos;
            if (e != null) {
                Vfx.add(new RelativaEffects.EmcBurst(e, 30));
            }
            Vfx.add(new Fx.Flash(c, 2.2f * F * 1.3f, 0xFFF8E0, 12, 1f));
            Vfx.add(new Fx.Pillar(c.add(0, -1.0, 0), 20.0, 1.6f, GOLD, 24));
            CineKit.burst(c, 1.6f * F, GOLD, 0xFFFFFF, 14, 1f);
            CineFx.flare(c, GOLD, 14f, 0.35f, 1f, 16);
            CineKit.shock(lvl, c, UP, 4.0 * S, GOLD, 0xFFFFFF, 18, 0.8f, false);   // 0.68 energinya menyambar sekitar
            Vfx.add(new Hd.Nova(c, 3.0 * S, 0xFFFFFF, GOLD, 0x8A6A20, 0, 20, 0.8f, false));
            CineKit.camera(p, c, 0.6f * SH, 24 * S);
            if (self) {
                ScreenFlash.flash(0.3f, 0xFFF0C0);
            }
        });
    }

    private static void annihilate(AbstractClientPlayer p, boolean self) {
        int at = ShazamAnim.REL_ANNIHILATE_AT;
        schedule(0, at, (lvl, t) -> {   // elektron (kanan) & positron (kiri) saling tertarik
            float k = t / (float) at;
            Vec3 r = ShazamPoses.handPos(p, true, 1f), l = ShazamPoses.handPos(p, false, 1f);
            double ang = t * 0.8;
            Vfx.mote(r.x + Math.cos(ang) * 0.12, r.y + Math.sin(ang) * 0.12, r.z, 0, 0, 0, ELECTRON, 0.07f + 0.05f * k, 4);
            Vfx.mote(l.x - Math.cos(ang) * 0.12, l.y - Math.sin(ang) * 0.12, l.z, 0, 0, 0, POSITRON, 0.07f + 0.05f * k, 4);
        });
        Vfx.add(new Fx.Glow(p, hand(p), 0.3f, ELECTRON, at + 2, at));
        Vfx.add(new Fx.Glow(p, handL(p), 0.3f, POSITRON, at + 2, at));
        Vfx.add(new RelativaGlyphs.Glyphs("E=mc²", Lightning.Anchor.on(p, 0, p.getBbHeight() + 0.9, 0), null, null, 0.3,
                POSITRON, 8, at + 10, 0.0));
        schedule(at, 1, (lvl, t) -> {
            Vec3 o = p.getEyePosition(1f).add(0, -0.35, 0);
            Vfx.add(new Fx.Flash(o, 1.8f * F, 0xFFFFFF, 8, 1f));
            Vfx.add(new RelativaEffects.GammaBeams(p, ShazamAnim.REL_ANNIHILATE_TICKS));
            Vfx.add(new Hd.Pressure(o, UP, 4.0 * S, Math.PI, GAMMA, 12, 0.6f, true));
            CineKit.camera(p, o, 0.6f * SH, 22 * S);
            if (self) {
                ScreenFlash.flash(0.25f, 0xF0E0FF);
                FovKick.punch(-0.05f);
            }
        });
    }

    // ------------------------------------------------------------------ R

    private static void unified(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.REL_UNIFIED_HIT;
        if (self) {
            ScreenFx.cinema(ShazamAnim.REL_UNIFIED_TICKS + 10);
            ScreenFx.titleKey("title.shazammod.relativa.unified", 0xFFFFFF, 70, 10);
        }
        RelativaEffects.ForceRings rings = new RelativaEffects.ForceRings(p, hit);
        Vfx.add(rings);
        LENSES.add(rings);
        Lightning.Anchor center = pt -> p.getPosition(pt).add(0, p.getBbHeight() * 0.6 + 0.7, 0);
        CineFx.gather(p, 40, hit - 40, center, 0xFFFFFF, 3.0 * F, 3.0f * F, true);
        schedule(0, hit, (lvl, t) -> {
            if (t % 12 == 0) {
                CineKit.shock(lvl, CineKit.feet(p), UP, (2.0 + t / 12.0) * S, FORCES[(t / 12) % 4], 0xFFFFFF, 16, 0.45f, true);
                CineKit.camera(p, CineKit.feet(p), 0.12f * SH, 20 * S);
            }
        });
        schedule(hit, 1, (lvl, t) -> {
            Vec3 c = center.at(1f);
            Vfx.add(new Fx.Flash(c, 5.0f * SF, 0xFFFFFF, 14, 1f));
            Vfx.add(new Hd.Pressure(c, UP, 22.0 * S, Math.PI, 0xFFFFFF, 26, 0.9f, true));
            for (int k = 0; k < 4; k++) {   // keempat gaya menyapu keluar berurutan
                final int col = FORCES[k];
                schedule(k * 2, 1, (l2, t2) -> Vfx.add(new Fx.Wave(CineKit.feet(p), UP, 22.0 * S, 1.0 * S, col, 28, 0.9f, 0.04f,
                        null)));
            }
            CineKit.shock(lvl, CineKit.feet(p), UP, 22.0 * S, 0xFFFFFF, LIGHT, 32, 1f, true);
            CineFx.godRays(Lightning.Anchor.fixed(c), 0xFFFFFF, 20.0 * S, 3.0 * S, 18, 0.9f, 46);
            Vfx.add(new Hd.Nova(c, 7.0 * S, 0xFFFFFF, 0xD8E8FF, GRAVITY, 0, 30, 1f, false));   // 0.68 singularitas pecah
            Vfx.add(new Fx.Pillar(CineKit.feet(p), 40.0, 3.0f, 0xFFFFFF, 34));
            Vfx.add(new RelativaGlyphs.Glyphs("E=mc²", Lightning.Anchor.fixed(c.add(0, 3.4, 0)), null, null, 0.8 * F, GOLD, 0, 50,
                    0.01));
            Vfx.add(new RelativaGlyphs.Glyphs("∞", Lightning.Anchor.fixed(c.add(0, 5.0, 0)), null, null, 0.7 * F, 0xFFFFFF, 0, 50,
                    0.01));
            CineKit.camera(p, c, 1.3f * SH, 40 * S);
            if (self) {
                ScreenFlash.flash(0.8f, 0xFFFFFF);
                FovKick.punch(-0.16f);
            }
        });
    }

    private static void unifiedHit(AbstractClientPlayer p, Vec3 pos) {
        Vec3 c = p.position().add(0, p.getBbHeight() * 0.6 + 0.7, 0);
        Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(c), Lightning.Anchor.fixed(pos), ELECTRON, 0.11f, 8, 2, 2, 0.3));
        for (int k = 0; k < 4; k++) {
            double ang = k * Math.PI / 2.0;
            Vfx.add(new Fx.Flash(pos.add(Math.cos(ang) * 0.4, 0, Math.sin(ang) * 0.4), 0.6f * F, FORCES[k], 9, 0.9f));
        }
        Vfx.add(new Fx.Ripple(pos, UP, 0.0, 0.2, 1.8 * F, 0.1 * F, 0xFFFFFF, 12, 0.8f, false));
    }

    private static void condensate(ClientLevel level, AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.REL_BEC_HIT;
        Vec3 f = CineKit.feet(p);
        Ground.Map map = ShazamFx.ground(level, f, 12.5 * S);
        Vfx.add(new Hd.Frost(f, 12.0 * S, COLD, hit, ShazamAnim.REL_BEC_TICKS, 0.9f, map));
        Vfx.add(new RelativaEffects.Atoms(f, hit, hit + 14));
        schedule(hit, 1, (lvl, t) -> {
            Vfx.add(new Fx.Flash(CineKit.chest(p), 2.0f * F * 1.3f, COLD, 12, 0.9f));
            CineKit.shock(lvl, f, UP, 12.0 * S, COLD, 0xFFFFFF, 26, 0.9f, true);
            Vfx.add(new Fx.Wave(f.add(0, 0.2, 0), UP, 12.0 * S, 1.4 * S, 0xE8F8FF, 36, 0.5f, 0f, null, true));   // kabut dingin
            Vfx.add(new RelativaEffects.BecSpike(f, 70));
            Vfx.add(new RelativaGlyphs.Glyphs("0 K", Lightning.Anchor.fixed(f.add(0, 4.4 * F * 1.4, 0)), null, null, 0.6 * F, COLD,
                    6, 50, 0.0));
            RandomSource r = lvl.random;
            for (int i = 0, n = Vfx.count(80); i < n; i++) {   // salju halus
                double a = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * 10.0 * S;
                Vfx.mote(f.x + Math.cos(a) * rr, f.y + 2.0 + r.nextDouble() * 5.0, f.z + Math.sin(a) * rr, 0, -0.03, 0, 0xFFFFFF,
                        0.07f, 60);
            }
            ShazamFx.smokeCloud(lvl, f, 0xDDEEFF, 20, 6.0 * S);
            CineKit.camera(p, f, 0.4f * SH, 24 * S);
            if (self) {
                ScreenFx.vignette(0.4f, 0x9ADFFF, 30);
                FovKick.punch(-0.05f);
            }
        });
    }

    private static void frozen(ClientLevel level, Vec3 pos) {
        LivingEntity e = near(level, pos, 2.5);
        if (e != null) {
            Vfx.add(new RelativaEffects.IceShell(e, ShazamAnim.REL_BEC_TICKS));
        }
        HdKit.shards(pos, 16, 0.3, COLD, 0.09f, 22, pos.y - 2);
    }

    // ------------------------------------------------------------------ M  Cahaya

    private static void photo(AbstractClientPlayer p) {
        CineFx.gather(p, 0, ShazamAnim.REL_PHOTO_FIRST, hand(p), PHOTON, 0.5, 1.2f, false);
        Vfx.add(new RelativaGlyphs.Glyphs("E=hν", pt -> ShazamPoses.handPos(p, true, pt).add(0, 0.5, 0), null, null, 0.2,
                PHOTON, 4, 26, 0.0));
    }

    private static void photon(AbstractClientPlayer p, Vec3 pos) {
        Vfx.add(new RelativaEffects.PhotonPacket(handNow(p), pos, 2));
        schedule(2, 1, (lvl, t) -> {
            Vfx.add(new Fx.Flash(pos, 0.5f * F * 1.2f, PHOTON, 7, 0.9f));
            CineKit.sparks(pos, 14, ELECTRON, 0.32, 0.05f, 9, pos.y - 2);   // elektron terlepas
            Vfx.add(new Fx.Ripple(pos, UP, 0.0, 0.1, 1.2 * F, 0.06, PHOTON, 8, 0.7f, false));
        });
    }

    private static void arc(Vec3 a, Vec3 b) {
        Vfx.add(new Lightning.Arc(Lightning.Anchor.fixed(a), Lightning.Anchor.fixed(b), ELECTRON, 0.07f, 6, 2, 1, 0.35));
        Vfx.add(new Fx.Flash(b, 0.4f * F, ELECTRON, 6, 0.8f));
    }

    private static void laser(AbstractClientPlayer p, boolean self) {
        int charge = ShazamAnim.REL_LASER_CHARGE;
        schedule(0, charge, (lvl, t) -> {   // atom tereksitasi: elektron melompat ke orbit yang lebih tinggi
            Vec3 h = handNow(p);
            double ang = t * 0.9, rr = t % 4 < 2 ? 0.12 : 0.22;
            Vfx.mote(h.x + Math.cos(ang) * rr, h.y + Math.sin(ang) * rr, h.z + Math.sin(ang * 0.5) * rr, 0, 0, 0, LASER, 0.05f, 4);
        });
        Vfx.add(new Fx.Glow(p, hand(p), 0.25f, LASER, charge + 2, charge));
        schedule(charge, 1, (lvl, t) -> {
            Vfx.add(new RelativaEffects.LaserBeam(p, ShazamAnim.REL_LASER_TICKS));
            Vfx.add(new Fx.Flash(handNow(p), 1.2f * F, LASER, 8, 1f));
            CineKit.camera(p, handNow(p), 0.25f * SH, 16 * S);
            if (self) {
                FovKick.punch(-0.05f);
            }
        });
    }

    // ------------------------------------------------------------------ J

    private static void gravityWave(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.REL_GWAVE_HIT;
        schedule(hit, 1, (lvl, t) -> {
            Vec3 f = CineKit.feet(p);
            Vfx.add(new RelativaEffects.GravWave(f, 46));
            CineKit.shock(lvl, f, UP, 9.0 * S, GWAVE, LIGHT, 24, 0.9f, true);
            for (int k = 0; k < 4; k++) {
                schedule(k * 4, 1, (l2, t2) -> Vfx.add(new Fx.Wave(f, UP, 9.0 * S, 0.35 * S, GWAVE, 24, 0.7f, 0f, null)));
            }
            ShazamFx.impact(lvl, p, f, 1.0f * F * 1.2f, GWAVE, LIGHT, true);
            CineKit.camera(p, f, 0.7f * SH, 22 * S);
            if (self) {
                FovKick.punch(-0.05f);
            }
        });
    }

    private static void brownian(AbstractClientPlayer p) {
        int total = 2 + ShazamAnim.REL_BROWN_COUNT * ShazamAnim.REL_BROWN_GAP;
        schedule(0, total, (lvl, t) -> {   // molekul menabrak dari segala arah
            Vec3 c = CineKit.chest(p);
            RandomSource r = lvl.random;
            for (int i = 0; i < 3; i++) {
                Vec3 o = ShazamFx.randomDir(r).scale(1.6);
                Vfx.mote(c.x + o.x, c.y + o.y, c.z + o.z, -o.x * 0.35, -o.y * 0.35, -o.z * 0.35, i == 0 ? QUANTUM : LIGHT, 0.06f, 4);
            }
        });
    }

    private static void brownHop(AbstractClientPlayer p, Vec3 from, Vec3 to) {
        if (from != null) {
            Vfx.add(new RelativaEffects.BrownPath(from, to, 16));
            Vfx.add(new Hd.Ghost(from, p.yBodyRot, 1.0, 0, QUANTUM, LIGHT, 10, 0.5f));
        }
        Vec3 c = to.add(0, 1.0, 0);
        Vfx.add(new Fx.Flash(c, 0.7f * F, QUANTUM, 6, 0.8f));
        CineKit.sparks(c, 10, LIGHT, 0.28, 0.05f, 7, to.y);
        Vfx.add(new Fx.Ripple(to.add(0, 0.1, 0), UP, 0.0, 0.2, 4.0, 0.08, QUANTUM, 9, 0.7f, false));
    }

    // ------------------------------------------------------------------ pasif & makalah

    private static void dodge(AbstractClientPlayer p, Vec3 pos) {
        float yaw = p.yBodyRot;
        Vec3 side = new Vec3(Mth.cos(yaw * Mth.DEG_TO_RAD), 0, Mth.sin(yaw * Mth.DEG_TO_RAD)).scale(0.6);
        Vfx.add(new Hd.Ghost(pos.add(side), yaw, 1.0, 0, ELECTRON, 0xFFFFFF, 10, 0.55f));
        Vfx.add(new Hd.Ghost(pos.subtract(side), yaw, 1.0, 0, POSITRON, 0xFFFFFF, 10, 0.55f));
        Vfx.add(new Fx.Ripple(pos.add(0, 1.0, 0), UP, 0.0, 0.3, 1.4, 0.06, QUANTUM, 8, 0.7f, false));
        Vfx.add(new RelativaGlyphs.Glyphs("ψ", Lightning.Anchor.fixed(pos.add(0, p.getBbHeight() + 0.5, 0)), null, null, 0.3,
                QUANTUM, 0, 14, 0.03));
    }

    /** 0.68 tinju dewa: kilatan foton, cincin gelombang kejut, guncangan kecil buat yang memukul. */
    private static void punch(ClientLevel level, AbstractClientPlayer p, Vec3 pos) {
        Vfx.add(new Fx.Flash(pos, 0.9f, LIGHT, 6, 0.95f));
        CineKit.sparks(pos, 14, PHOTON, 0.35, 0.05f, 8, pos.y - 2);
        Vec3 n = pos.subtract(p.getEyePosition(1f));
        n = n.lengthSqr() < 1.0E-4 ? UP : n.normalize();
        Vfx.add(new Fx.Ripple(pos, n, 0.0, 0.2, 2.2, 0.08, PHOTON, 8, 0.8f, false));
        Vfx.add(new Fx.Ripple(pos, UP, 0.0, 0.2, 3.5, 0.06, LIGHT, 9, 0.5f, false));
        CineKit.camera(p, pos, 0.1f, 10);
        CineKit.sound(level, pos, ShazamSounds.RELATIVA_PUNCH, 1.1f, 0.85f + level.random.nextFloat() * 0.2f);
    }

    private static void paper(AbstractClientPlayer p, int kind, boolean self) {
        Vfx.add(new RelativaEffects.Paper(p, kind, 0.0, 44, 30, false));
        Vfx.add(new Fx.Flash(CineKit.chest(p), 0.8f, paperColor(kind), 8, 0.7f));
        if (self) {
            ScreenFx.titleKey("title.shazammod.relativa.paper." + Mth.clamp(kind, 0, 3), paperColor(kind), 50, 2);
        }
    }

    private static int paperColor(int kind) {
        return switch (kind) {
            case 0 -> PHOTON;
            case 1 -> QUANTUM;
            case 2 -> RELATIV;
            default -> GOLD;
        };
    }

    // ------------------------------------------------------------------ 0.70 ruang-waktu: lubang cacing, foton, kucing, lensa

    /** Tiap tick: jejak foton & lensa Cincin Einstein tiap pemain, kilau saat lensanya terpasang lagi, mulut lubang cacing. */
    private static void tickSpace(ClientLevel level) {
        Minecraft mc = Minecraft.getInstance();
        Set<Integer> cloakedNow = new HashSet<>();
        for (Map.Entry<Integer, Integer> e : RelativaClientState.all().entrySet()) {
            int id = e.getKey(), flags = e.getValue();
            if ((flags & RelativaNetwork.FLAG_PHOTON) != 0) {
                RelativaSpace.PhotonTrail t = PHOTONS.get(id);
                if ((t == null || t.dead()) && level.getEntity(id) instanceof AbstractClientPlayer p && p.isAlive()) {
                    t = new RelativaSpace.PhotonTrail(p);
                    PHOTONS.put(id, t);
                    Vfx.add(t);
                }
            }
            if ((flags & RelativaNetwork.FLAG_CLOAK) != 0) {
                cloakedNow.add(id);
                RelativaSpace.CloakLens l = CLOAKS.get(id);
                if ((l == null || l.dead()) && level.getEntity(id) instanceof AbstractClientPlayer p && p.isAlive()) {
                    l = new RelativaSpace.CloakLens(p);
                    CLOAKS.put(id, l);
                    Vfx.add(l);
                    LENSES.add(l);
                    if (!CLOAKED.contains(id)) {   // lensanya terpasang (lagi): cahaya di sekitar badan berkilau sekali
                        Vec3 c = RelativaEffects.chestOf(p, 1f);
                        Vfx.add(new Fx.Flash(c, 1.2f, 0xEAF2FF, 5, 0.45f));
                        Vfx.add(new Fx.Ripple(c, UP, 0.0, 0.3, 2.2, 0.05, 0xEAF2FF, 8, 0.5f, false));
                    }
                }
            }
        }
        CLOAKED.clear();
        CLOAKED.addAll(cloakedNow);
        PHOTONS.values().removeIf(RelativaSpace.PhotonTrail::dead);
        CLOAKS.values().removeIf(RelativaSpace.CloakLens::dead);
        MOUTHS.values().removeIf(RelativaSpace.Mouth::dead);
        if (RelativaClientState.transformed && RelativaClientState.cloak && mc.player != null
                && (RelativaClientState.flags(mc.player.getId()) & RelativaNetwork.FLAG_CLOAK) != 0) {
            ScreenFx.vignette(0.22f, 0xB8A8FF, 2);   // tanda di layar sendiri: sedang tak terlihat
        }
        if (SPLITS.size() > 32) {
            SPLITS.clear();
        }
    }

    /** Kabar satu mulut lubang cacing dari server (RelativaNetwork.WormholePayload). */
    public static void wormhole(ClientLevel level, RelativaNetwork.WormholePayload p) {
        if (level == null) {
            return;
        }
        int key = p.id() * 2 + p.side();
        RelativaSpace.Mouth m = MOUTHS.get(key);
        switch (p.state()) {
            case RelativaNetwork.WORM_OPEN -> {
                if (m != null && !m.dead() && !m.closing()) {
                    return;   // sudah terlihat
                }
                m = new RelativaSpace.Mouth(level, key, new Vec3(p.x(), p.y(), p.z()), p.radius(), p.partner(), p.age(),
                        p.life());
                MOUTHS.put(key, m);
                Vfx.add(m);
                LENSES.add(m);
                if (p.age() < 4) {
                    mouthOpened(level, m);
                }
            }
            case RelativaNetwork.WORM_PASS -> {
                if (m != null && !m.dead()) {
                    mouthPass(level, m);
                }
            }
            case RelativaNetwork.WORM_SHUT -> {
                if (m != null) {
                    m.shut();
                }
            }
            default -> { }
        }
    }

    /** Ruang-waktu robek & mulutnya mengembang: kilat, nova, gelombang tekanan, ER=EPR di atasnya. */
    private static void mouthOpened(ClientLevel level, RelativaSpace.Mouth m) {
        Vec3 c = m.c;
        double r = m.radius;
        int rim = m.pal[0];
        Vfx.add(new Fx.Flash(c, (float) (r * 2.2) * F, hot(rim), 10, 1.0f));
        Vfx.add(new Hd.Nova(c, r * 2.6, 0xFFFFFF, rim, m.pal[1], 0, 18, 0.7f, false));
        Vfx.add(new Hd.Pressure(c, UP, r * 5.0, Math.PI, rim, 14, 0.8f, true));
        Vfx.add(new Fx.Ripple(c.subtract(0, 1.1, 0), UP, 0.0, r, r * 6.0, 0.2, rim, 18, 0.8f, false));
        CineKit.motesOut(c, 40, rim, 0.18, 0.06f, 16);
        Vfx.add(new RelativaGlyphs.Glyphs("ER=EPR", Lightning.Anchor.fixed(c.add(0, r + 0.9, 0)), null, null, 0.42, RELATIV, 10,
                60, 0.004));
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.distanceToSqr(c) < 40.0 * 40.0) {
            CineKit.camera(mc.player, c, 0.45f * SH, 40);
        }
    }

    /** Sesuatu lewat: kilat dan riak dari mulutnya. */
    private static void mouthPass(ClientLevel level, RelativaSpace.Mouth m) {
        Vec3 c = m.c;
        double r = m.radius;
        Vfx.add(new Fx.Flash(c, (float) (r * 1.3), hot(m.pal[0]), 7, 0.8f));
        Vfx.add(new Hd.Pressure(c, UP, r * 2.6, Math.PI, m.pal[0], 10, 0.6f, true));
        CineKit.motesOut(c, 16, m.pal[4], 0.12, 0.05f, 12);
    }

    /** L: kedua tangan merobek ruang-waktu, mulut pertama terbuka di pos pada REL_WORM_OPEN. */
    private static void wormholeCast(AbstractClientPlayer p, Vec3 pos, boolean self) {
        int open = ShazamAnim.REL_WORM_OPEN;
        CineFx.gather(p, 0, open, hand(p), RELATIV, 1.0, 1.6f, false);
        CineFx.gather(p, 0, open, handL(p), GRAVITY, 1.0, 1.6f, false);
        Vfx.add(new RelativaGlyphs.Glyphs("ER=EPR", Lightning.Anchor.fixed(pos.add(0, 1.7, 0)), null, null, 0.36, RELATIV, 10,
                open + 10, 0.004));
        if (self) {
            ScreenFx.titleKey("title.shazammod.relativa.wormhole", RELATIV, 44, open);
        }
        schedule(open, 1, (lvl, t) -> {
            CineKit.burst(pos, 2.0f * F, RELATIV, 0xFFFFFF, 12, 1.2f);
            Vfx.add(new Fx.Ripple(pos.subtract(0, 1.1, 0), UP, 0.0, 0.5, 9.0 * S, 0.25, GRAVITY, 16, 0.8f, false));
            CineKit.camera(p, pos, 0.5f * SH, 28 * S);
            if (self) {
                FovKick.punch(0.14f);
                ScreenFlash.flash(0.25f, 0xD8F0FF);
            }
        });
    }

    /** F nyala: badan dilepas jadi foton (m = 0, E = pc), lalu melesat ke udara di REL_PHOTON_ON. */
    private static void photonOn(AbstractClientPlayer p, boolean self) {
        int at = ShazamAnim.REL_PHOTON_ON;
        CineKit.motesOut(CineKit.chest(p), 30, PHOTON, 0.08, 0.05f, at + 4);
        Vfx.add(new RelativaGlyphs.Glyphs("m=0", RelativaSpace.above(p, 0.55), null, null, 0.34, PHOTON, 6, at + 20, 0.01));
        Vfx.add(new RelativaGlyphs.Glyphs("E=pc", RelativaSpace.above(p, 1.0), null, null, 0.3, LIGHT, 8, at + 24, 0.01));
        if (self) {
            ScreenFx.titleKey("title.shazammod.relativa.photon", PHOTON, 40, at);
        }
        schedule(at, 1, (lvl, t) -> {
            Vec3 c = CineKit.chest(p);
            Vfx.add(new Fx.Flash(c, 2.0f * F, LIGHT, 8, 0.9f));
            Vfx.add(new Fx.Pillar(CineKit.feet(p), 14.0, 1.0f, PHOTON, 16));
            Vfx.add(new Fx.Ripple(CineKit.feet(p).add(0, 0.1, 0), UP, 0.0, 0.4, 7.0 * S, 0.2, PHOTON, 14, 0.8f, false));
            CineKit.camera(p, c, 0.3f * SH, 20 * S);
            if (self) {
                FovKick.punch(0.16f);
                ScreenFx.speedLines(0.8f);
            }
        });
    }

    /** F padam: foton-fotonnya berkumpul lagi jadi badan bermassa. */
    private static void photonOff(AbstractClientPlayer p) {
        int at = ShazamAnim.REL_PHOTON_OFF;
        CineFx.gather(p, 0, at, CineKit.chestAnchor(p), PHOTON, 1.2, 1.4f, false);
        schedule(at, 1, (lvl, t) -> {
            Vec3 c = CineKit.chest(p);
            Vfx.add(new Fx.Flash(c, 1.2f, PHOTON, 6, 0.7f));
            Vfx.add(new RelativaGlyphs.Glyphs("E=mc²", RelativaSpace.above(p, 0.6), null, null, 0.28, GOLD, 0, 26, 0.012));
        });
    }

    /** K: kotak Schrödinger terbuka, |ψ⟩=|0⟩+|1⟩, badannya terbelah di REL_CLONE_SPLIT. */
    private static void cloneCast(ClientLevel level, AbstractClientPlayer p, boolean self) {
        int split = ShazamAnim.REL_CLONE_SPLIT;
        SPLITS.put(p.getUUID(), level.getGameTime() + split);
        Vfx.add(new RelativaSpace.QuantumBox(p, split));
        Vfx.add(new RelativaGlyphs.Glyphs("|ψ⟩=|0⟩+|1⟩", RelativaSpace.above(p, 0.95), null, null, 0.28, QUANTUM, 10, split + 26,
                0.008));
        CineFx.gather(p, 0, split, CineKit.chestAnchor(p), QUANTUM, 1.0, 1.4f, false);
        if (self) {
            ScreenFx.titleKey("title.shazammod.relativa.clone", QUANTUM, 44, split);
        }
        schedule(split, 1, (lvl, t) -> {
            Vec3 c = CineKit.chest(p);
            CineKit.burst(c, 1.8f * F, QUANTUM, 0xFFFFFF, 12, 1.1f);
            Vfx.add(new Fx.Ripple(CineKit.feet(p).add(0, 0.1, 0), UP, 0.0, 0.4, 6.0 * S, 0.15, QUANTUM, 14, 0.8f, false));
            float yaw = p.yBodyRot;
            for (int k = 0; k < 4; k++) {   // empat keadaan yang saling bertumpuk berpencar
                double ang = Math.toRadians(yaw) + k * Math.PI / 2.0;
                Vec3 off = new Vec3(-Math.sin(ang), 0, Math.cos(ang)).scale(1.4);
                Vfx.add(new Hd.Ghost(p.position().add(off), yaw, 1.0, 0, k % 2 == 0 ? QUANTUM : ELECTRON, 0xFFFFFF, 10, 0.55f));
            }
            CineKit.camera(p, c, 0.3f * SH, 20 * S);
            if (self) {
                ScreenFlash.flash(0.25f, 0xC8FFF4);
                FovKick.punch(-0.06f);
            }
        });
    }

    /** Boneka salinan baru muncul (RelativaClonePuppets): kalau barusan terbelah, ia muncul dari cahaya. */
    public static void cloneBorn(AbstractClientPlayer puppet, UUID owner) {
        if (owner == null || !(puppet.level() instanceof ClientLevel level)) {
            return;
        }
        Long at = SPLITS.get(owner);
        if (at == null || Math.abs(level.getGameTime() - at) > 30) {
            return;   // cuma baru masuk jangkauan pandang, bukan baru terbelah
        }
        Vec3 feet = puppet.position();
        Vec3 c = feet.add(0, puppet.getBbHeight() * 0.62, 0);
        Vfx.add(new Hd.Ghost(feet, puppet.yBodyRot, puppet.getBbHeight() / 1.8, 0, QUANTUM, 0xFFFFFF, 14, 0.8f));
        Vfx.add(new Fx.Flash(c, 1.3f, QUANTUM, 8, 0.8f));
        CineKit.motesOut(c, 16, ELECTRON, 0.06, 0.05f, 12);
        Player o = level.getPlayerByUUID(owner);
        if (o != null) {
            Vfx.add(new Hd.Lance(RelativaEffects.chestOf(o, 1f), c, 0.16f, QUANTUM, 0xFFFFFF, 2, 8));
        }
        Vfx.add(new RelativaGlyphs.Glyphs("ψ", Lightning.Anchor.on(puppet, 0, puppet.getBbHeight() + 0.5, 0), null, null, 0.4,
                QUANTUM, 0, 24, 0.02));
    }

    /** Salinan teramati: fungsi gelombangnya runtuh jadi partikel (|0⟩). */
    private static void cloneCollapse(AbstractClientPlayer p, Vec3 pos) {
        Vfx.add(new Hd.Ghost(p.position(), p.yBodyRot, p.getBbHeight() / 1.8, 0, QUANTUM, 0xFFFFFF, 10, 0.9f));
        Vfx.add(new Fx.Flash(pos, 1.6f * F, 0xE8FFFA, 6, 0.9f));
        CineKit.motesOut(pos, 46, QUANTUM, 0.14, 0.06f, 18);
        CineKit.motesOut(pos, 20, ELECTRON, 0.09, 0.05f, 14);
        Vfx.add(new Fx.Ripple(pos, UP, 0.0, 0.3, 3.2, 0.08, QUANTUM, 10, 0.7f, false));
        Vfx.add(new RelativaGlyphs.Glyphs("|0⟩", Lightning.Anchor.fixed(pos.add(0, 1.0, 0)), null, null, 0.3, QUANTUM, 0, 20,
                0.03));
    }

    /** Yang asli dipukul, tapi salinannya yang menanggung: badannya bergeser kembar sesaat. */
    private static void cloneDecoy(AbstractClientPlayer p, Vec3 pos) {
        float yaw = p.yBodyRot;
        Vec3 side = new Vec3(Mth.cos(yaw * Mth.DEG_TO_RAD), 0, Mth.sin(yaw * Mth.DEG_TO_RAD)).scale(0.7);
        Vfx.add(new Hd.Ghost(p.position().add(side), yaw, 1.0, 0, QUANTUM, 0xFFFFFF, 10, 0.55f));
        Vfx.add(new Hd.Ghost(p.position().subtract(side), yaw, 1.0, 0, ELECTRON, 0xFFFFFF, 10, 0.55f));
        Vfx.add(new Fx.Ripple(pos, UP, 0.0, 0.3, 1.8, 0.06, QUANTUM, 8, 0.7f, false));
        Vfx.add(new RelativaGlyphs.Glyphs("ψ", Lightning.Anchor.fixed(pos.add(0, 1.0, 0)), null, null, 0.3, QUANTUM, 0, 14, 0.03));
    }

    /** H: cincin cahaya menyempit ke badan lalu badannya hilang (on), atau mengembang lepas & badannya terlihat (off). */
    private static void cloak(AbstractClientPlayer p, boolean on, boolean self) {
        int dur = on ? ShazamAnim.REL_CLOAK_AT : ShazamAnim.REL_CLOAK_OFF;
        Vfx.add(new RelativaSpace.LensRing(p, on, dur + 6));
        Vfx.add(new RelativaGlyphs.Glyphs("θE", RelativaSpace.above(p, 0.7), null, null, 0.34, LIGHT, 6, dur + 22, 0.01));
        if (self && on) {
            ScreenFx.titleKey("title.shazammod.relativa.cloak", 0xC8B8FF, 40, dur);
        }
        schedule(dur, 1, (lvl, t) -> {
            Vec3 c = CineKit.chest(p);
            Vfx.add(new Fx.Flash(c, 1.4f, 0xEAF2FF, 6, on ? 0.6f : 0.9f));
            Vfx.add(new Hd.Pressure(c, UP, 3.0, Math.PI, 0xEAF2FF, 10, 0.5f, true));
            if (!on) {
                CineKit.motesOut(c, 18, LIGHT, 0.06, 0.04f, 12);
            }
            if (self) {
                FovKick.punch(on ? 0.05f : -0.05f);
            }
        });
    }

    /** Serangan pertama dari balik Cincin Einstein (x2): kilat ungu & lensanya goyah. */
    private static void cloakStrike(AbstractClientPlayer p, Vec3 pos) {
        Vfx.add(new Fx.Flash(pos, 1.6f * F, 0xD8C0FF, 6, 1.0f));
        Vfx.add(new Fx.Ripple(pos, UP, 0.0, 0.2, 3.0, 0.08, 0xC8A8FF, 9, 0.8f, false));
        CineKit.sparks(pos, 18, 0xE0D0FF, 0.4, 0.05f, 9, pos.y - 2);
        Vfx.add(new RelativaGlyphs.Glyphs("x2", Lightning.Anchor.fixed(pos.add(0, 0.9, 0)), null, null, 0.3, 0xE0D0FF, 0, 18,
                0.03));
        CineKit.camera(p, pos, 0.2f, 12);
    }

    // ------------------------------------------------------------------ alat bantu

    static float fade(float time, float life, float in, float out) {
        return Mth.clamp(time / in, 0f, 1f) * Mth.clamp((life - time) / out, 0f, 1f);
    }

    static int hot(int rgb) {
        return Draw.mix(rgb, 0xFFFFFF, 0.65);
    }

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static Lightning.Anchor hand(AbstractClientPlayer p) {
        return pt -> ShazamPoses.handPos(p, true, pt);
    }

    private static Lightning.Anchor handL(AbstractClientPlayer p) {
        return pt -> ShazamPoses.handPos(p, false, pt);
    }

    private static Vec3 handNow(AbstractClientPlayer p) {
        return ShazamPoses.handPos(p, true, 1f);
    }

    private static LivingEntity near(ClientLevel level, Vec3 pos, double r) {
        LivingEntity best = null;
        double bd = r * r;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(r))) {
            double d = e.position().add(0, e.getBbHeight() * 0.62, 0).distanceToSqr(pos);
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        return best;
    }
}
