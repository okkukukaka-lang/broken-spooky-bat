package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.joml.Quaternionf;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Vfx;
import com.shazammod.relativa.RelativaClientState;
import com.shazammod.relativa.RelativaNetwork;
import com.shazammod.relativa.RelativaTier;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 0.66 Efek-efek khusus RELATIVA (semua digambar sendiri dengan mesin efek mod ini, tanpa partikel Minecraft). Bahasa
 * visualnya diambil dari gambar-gambar fisika yang terkenal: model atom Bohr, kisi "lembaran karet" ruang-waktu, piringan
 * akresi + cincin foton lubang hitam, tetes cairan inti yang membelah, donat plasma tokamak, paket gelombang ψ (bagian
 * riil & imajiner), jam cahaya, puncak kondensat Bose-Einstein berwarna palsu, dan cincin partikel uji gelombang gravitasi.
 */
final class RelativaEffects {
    private RelativaEffects() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);
    /** 0.68 tingkat dewa (RelativaTier): ukuran area (ikut dampak di server) & ukuran efek di badan / sasaran. */
    private static final double S = RelativaTier.AREA, F = RelativaTier.FX;

    /** Efek yang melengkungkan cahaya (dibaca RelativaLensShader): {x, y, z, jari-jari Einstein, bayangan, cincin, kuat}. */
    interface Lensing {
        float[] lens(float pt);

        boolean alive();
    }

    // ================================================================== alat gambar bersama

    /** Titik lambang atom di dada (sedikit di depan badan, ikut arah badan). */
    static Vec3 emblem(AbstractClientPlayer p, float pt) {
        float yaw = Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot) * Mth.DEG_TO_RAD;
        Vec3 f = new Vec3(-Mth.sin(yaw), 0, Mth.cos(yaw));
        return p.getPosition(pt).add(0, p.getBbHeight() * 0.7, 0).add(f.scale(0.21));
    }

    /** Inti atom: gumpalan proton & neutron (titik sebaran Fibonacci di bola) yang bergetar. */
    static void nucleus(Draw d, double x, double y, double z, double r, int count, float time, float a, int proton,
                        int neutron) {
        double golden = Math.PI * (3.0 - Math.sqrt(5.0));
        for (int i = 0; i < count; i++) {
            double f = (i + 0.5) / count;
            double yy = 1.0 - 2.0 * f, rr = Math.sqrt(Math.max(0.0, 1.0 - yy * yy)), th = golden * i;
            double jig = 1.0 + 0.12 * Math.sin(time * 1.3 + i * 2.1);
            double k = r * 0.62 * jig;
            double px = x + Math.cos(th) * rr * k, py = y + yy * k, pz = z + Math.sin(th) * rr * k;
            int c = i % 2 == 0 ? proton : neutron;
            d.glow(px, py, pz, (float) (r * 0.5), c, a * 0.85f);
            d.glow(px, py, pz, (float) (r * 0.2), RelativaFx.hot(c), a * 0.7f);
        }
        d.glow(x, y, z, (float) (r * 1.9), proton, a * 0.22f);
    }

    /** Orbit elektron: cincin tipis di bidang normal n + elektron yang berlari di atasnya. */
    static void orbit(Draw d, Vec3 c, double nx, double ny, double nz, double r, int rgb, float a, double phase, int electrons) {
        double l = Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (l < 1.0E-6) {
            return;
        }
        nx /= l;
        ny /= l;
        nz /= l;
        d.ring(c.x, c.y, c.z, nx, ny, nz, r, Math.max(0.006, r * 0.05), rgb, a * 0.45f, 0f, null);
        double[] e = new double[6];
        Draw.plane(nx, ny, nz, e);
        for (int k = 0; k < electrons; k++) {
            double ang = phase + k * Math.PI * 2.0 / electrons;
            double cs = Math.cos(ang), sn = Math.sin(ang);
            double px = c.x + (e[0] * cs + e[3] * sn) * r, py = c.y + (e[1] * cs + e[4] * sn) * r,
                    pz = c.z + (e[2] * cs + e[5] * sn) * r;
            d.flare(px, py, pz, (float) Math.max(0.025, r * 0.16), rgb, a);
        }
    }

    /** Kisi ruang-waktu kecil di kaki: melengkung ke bawah tepat di bawah badan (massa melengkungkan ruang-waktu). */
    static void footGrid(Draw d, Vec3 f, float a, int rgb) {
        final int n = 19, lines = 6;
        double reach = 3.0, step = 0.5;   // 0.68 kisi di kaki lebih lebar
        float[] xyz = new float[n * 3];
        float[] w = new float[n];
        float[] al = new float[n];
        for (int dir = 0; dir < 2; dir++) {
            for (int i = -lines; i <= lines; i++) {
                double off = i * step;
                for (int j = 0; j < n; j++) {
                    double t = -reach + 2.0 * reach * j / (n - 1);
                    double x = dir == 0 ? t : off, z = dir == 0 ? off : t;
                    double r2 = x * x + z * z;
                    double h = 0.03 + 0.26 * (1.0 - Math.exp(-r2 / 1.6));   // pinggirnya terangkat, tengahnya turun
                    xyz[j * 3] = (float) (f.x + x);
                    xyz[j * 3 + 1] = (float) (f.y + h);
                    xyz[j * 3 + 2] = (float) (f.z + z);
                    double fr = Math.max(0.0, 1.0 - Math.sqrt(r2) / reach);
                    al[j] = (float) (a * 0.3 * fr * fr);
                    w[j] = 0.02f;
                }
                d.strip(xyz, n, w, 1f, al, 1f, rgb);
            }
        }
    }

    static Vec3 chestOf(Entity e, float pt) {
        return e.getPosition(pt).add(0, e.getBbHeight() * 0.62, 0);
    }

    static Vec3 toCam(Draw d, Vec3 c) {
        Vec3 v = new Vec3(d.camX - c.x, d.camY - c.y, d.camZ - c.z);
        return v.lengthSqr() < 1.0E-6 ? UP : v.normalize();
    }

    static float fade(float time, float life, float in, float out) {
        return RelativaFx.fade(time, life, in, out);
    }

    static int hot(int rgb) {
        return RelativaFx.hot(rgb);
    }

    // ================================================================== Aura: atom di dada, orbit besar, kisi di kaki

    static final class Aura extends Effect {
        private final AbstractClientPlayer p;
        private final float seed = Vfx.random().nextFloat() * 100f;
        private boolean dead;

        Aura(AbstractClientPlayer p) {
            super(20 * 60 * 60);
            this.p = p;
        }

        boolean dead() {
            return dead;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (dead || p.isRemoved() || !RelativaClientState.isRelativa(p.getId()) || !super.tick(level)) {
                dead = true;
                return false;
            }
            RandomSource r = level.random;
            if (age % 4 == 0 && !p.isInvisible()) {   // foton kecil lepas dari atom
                Vec3 c = emblem(p, 1f);
                Vec3 dir = ShazamFx.randomDir(r);
                Vfx.mote(c.x, c.y, c.z, dir.x * 0.03, dir.y * 0.03 + 0.01, dir.z * 0.03,
                        r.nextBoolean() ? RelativaFx.ELECTRON : RelativaFx.LIGHT, 0.03f, 10);
            }
            if (age % 70 == 35 && !p.isInvisible() && !HdKit.firstPerson(p)) {   // persamaan melayang dari bahu
                String[] pool = {"E=mc²", "ħ", "ψ", "G", "∞", "c", "E=hν", "t'=γt"};
                double side = r.nextBoolean() ? 0.55 : -0.55;
                float yaw = p.yBodyRot * Mth.DEG_TO_RAD;
                Vec3 s = new Vec3(Mth.cos(yaw), 0, Mth.sin(yaw)).scale(side);
                Vec3 base = p.position().add(0, p.getBbHeight() * 0.95, 0).add(s);
                Vfx.add(new RelativaGlyphs.Glyphs(pool[r.nextInt(pool.length)], pt -> base, null, null, 0.15,
                        r.nextBoolean() ? RelativaFx.RELATIV : RelativaFx.QUANTUM, 18, 60, 0.012));
            }
            return true;
        }

        @Override
        public void renderGlow(Draw d) {
            if (p.isInvisible()) {
                return;
            }
            float pt = d.partialTick;
            float time = time(pt) + seed;
            float a = Math.min(1f, time(pt) / 10f);
            Vec3 c = emblem(p, pt);
            nucleus(d, c.x, c.y, c.z, 0.055, 7, time, a, RelativaFx.PROTON, RelativaFx.NEUTRON);
            for (int k = 0; k < 3; k++) {   // lambang atom: tiga orbit elektron yang miring
                double ang = k * Math.PI / 3.0 + time * 0.01;
                orbit(d, c, Math.sin(ang) * 0.9, 0.45, Math.cos(ang) * 0.9, 0.2, RelativaFx.ELECTRON, a * 0.9f,
                        time * 0.32 + k * 2.1, 1);
            }
            boolean fp = HdKit.firstPerson(p);
            if (!fp) {   // 0.68 tiga orbit besar mengelilingi badan + lingkaran cahaya di atas kepala (tingkat dewa)
                Vec3 body = p.getPosition(pt).add(0, p.getBbHeight() * 0.55, 0);
                double big = 0.58 * p.getBbHeight();
                for (int k = 0; k < 3; k++) {
                    double tilt = k == 0 ? 0.62 : k == 1 ? -0.62 : 1.25, spin = time * 0.012 * (k == 1 ? -1 : 1) + k * 2.1;
                    int col = k == 0 ? RelativaFx.ELECTRON : k == 1 ? RelativaFx.RELATIV : RelativaFx.GOLD;
                    orbit(d, body, Math.sin(spin) * Math.sin(tilt), Math.cos(tilt), Math.cos(spin) * Math.sin(tilt), big * (1.0 + 0.06 * k),
                            col, a * 0.38f, time * 0.11 * (k == 1 ? -1.2 : 1.0 + 0.2 * k), k == 2 ? 2 : 1);
                }
                Vec3 head = p.getPosition(pt).add(0, p.getBbHeight() + 0.28, 0);
                d.ring(head.x, head.y, head.z, 0, 1, 0, 0.3, 0.016, RelativaFx.GOLD, a * 0.55f, 0f, null);
                for (int k = 0; k < 6; k++) {   // foton yang mengorbit lingkaran cahaya
                    double ang = time * 0.09 + k * Math.PI / 3.0;
                    d.flare(head.x + Math.cos(ang) * 0.3, head.y, head.z + Math.sin(ang) * 0.3, 0.05f, RelativaFx.LIGHT, a * 0.8f);
                }
                d.glow(body.x, body.y, body.z, (float) (p.getBbHeight() * 0.7), RelativaFx.RELATIV, a * 0.06f);
            }
            if (p.onGround()) {
                footGrid(d, p.getPosition(pt), a * (fp ? 0.55f : 0.8f), RelativaFx.GRAVITY);
            }
        }
    }

    // ================================================================== Kertas makalah 1905

    /** Selembar makalah bercahaya: melayang di depan dada (atau mengorbit), lalu terbang masuk ke dada. */
    static final class Paper extends Effect {
        private final AbstractClientPlayer p;
        private final int kind, flyAt;
        private final double phase;
        private final boolean orbit;
        private final float[] scribble = new float[16];

        Paper(AbstractClientPlayer p, int kind, double phase, int life, int flyAt, boolean orbit) {
            super(life);
            this.p = p;
            this.kind = kind;
            this.phase = phase;
            this.flyAt = flyAt;
            this.orbit = orbit;
            Random r = new Random(31L * kind + 7L);
            float x = 0f, y = 0f;
            for (int i = 0; i < 8; i++) {   // jejak acak Gerak Brown
                scribble[i * 2] = x;
                scribble[i * 2 + 1] = y;
                x = Mth.clamp(x + (r.nextFloat() - 0.5f) * 0.5f, -0.5f, 0.5f);
                y = Mth.clamp(y + (r.nextFloat() - 0.5f) * 0.5f, -0.5f, 0.5f);
            }
        }

        private int color() {
            return switch (kind) {
                case 0 -> RelativaFx.PHOTON;
                case 1 -> RelativaFx.QUANTUM;
                case 2 -> RelativaFx.RELATIV;
                default -> RelativaFx.GOLD;
            };
        }

        private Vec3 pos(float pt) {
            float time = time(pt);
            Vec3 chest = chestOf(p, pt);
            Vec3 at;
            if (orbit) {
                double ang = phase + time * 0.05;
                at = chest.add(Math.cos(ang) * 1.7, 0.15 * Math.sin(time * 0.1 + phase), Math.sin(ang) * 1.7);
            } else {
                Vec3 look = p.getViewVector(pt);
                at = chest.add(look.x * 0.9, 0.25, look.z * 0.9);
            }
            if (time > flyAt) {
                float f = Mth.clamp((time - flyAt) / 10f, 0f, 1f);
                at = at.lerp(chest, f * f);
            }
            return at;
        }

        private double scale(float pt) {
            float time = time(pt);
            double s = Math.min(1.0, time / 6.0);
            if (time > flyAt) {
                s *= 1.0 - 0.85 * Mth.clamp((time - flyAt) / 10f, 0f, 1f);
            }
            return s;
        }

        @Override
        public void renderSoft(Draw d) {
            Vec3 o = pos(d.partialTick);
            double s = scale(d.partialTick);
            float a = fade(time(d.partialTick), life, 4f, 6f) * 0.55f;
            Vec3[] b = RelativaGlyphs.facing(d, o);
            double w = 0.24 * s, h = 0.32 * s;
            d.quad(o.x - b[0].x * w - b[1].x * h, o.y - b[0].y * w - b[1].y * h, o.z - b[0].z * w - b[1].z * h,
                    o.x + b[0].x * w - b[1].x * h, o.y + b[0].y * w - b[1].y * h, o.z + b[0].z * w - b[1].z * h,
                    o.x + b[0].x * w + b[1].x * h, o.y + b[0].y * w + b[1].y * h, o.z + b[0].z * w + b[1].z * h,
                    o.x - b[0].x * w + b[1].x * h, o.y - b[0].y * w + b[1].y * h, o.z - b[0].z * w + b[1].z * h,
                    0xF2E8C8, a, a, a, a);
        }

        @Override
        public void renderGlow(Draw d) {
            Vec3 o = pos(d.partialTick);
            double s = scale(d.partialTick);
            float time = time(d.partialTick);
            float a = fade(time, life, 4f, 6f);
            int c = color();
            Vec3[] b = RelativaGlyphs.facing(d, o);
            double w = 0.24 * s, h = 0.32 * s;
            Vec3 p00 = o.subtract(b[0].scale(w)).subtract(b[1].scale(h)), p10 = o.add(b[0].scale(w)).subtract(b[1].scale(h));
            Vec3 p11 = o.add(b[0].scale(w)).add(b[1].scale(h)), p01 = o.subtract(b[0].scale(w)).add(b[1].scale(h));
            float lw = (float) (0.025 * s);
            d.line(p00.x, p00.y, p00.z, p10.x, p10.y, p10.z, lw, lw, c, a, a);
            d.line(p10.x, p10.y, p10.z, p11.x, p11.y, p11.z, lw, lw, c, a, a);
            d.line(p11.x, p11.y, p11.z, p01.x, p01.y, p01.z, lw, lw, c, a, a);
            d.line(p01.x, p01.y, p01.z, p00.x, p00.y, p00.z, lw, lw, c, a, a);
            if (kind == 1) {   // Gerak Brown: jejak acak partikel
                float[] pts = new float[8 * 3];
                for (int i = 0; i < 8; i++) {
                    double lx = scribble[i * 2] * w * 1.4, ly = scribble[i * 2 + 1] * h * 1.2;
                    pts[i * 3] = (float) (o.x + b[0].x * lx + b[1].x * ly);
                    pts[i * 3 + 1] = (float) (o.y + b[0].y * lx + b[1].y * ly);
                    pts[i * 3 + 2] = (float) (o.z + b[0].z * lx + b[1].z * ly);
                }
                d.polyline(pts, 8, lw * 1.4f, lw * 1.4f, c, hot(c), a, a);
            } else {
                String eq = kind == 0 ? "E=hν" : kind == 2 ? "t'=γt" : "E=mc²";
                RelativaGlyphs.draw(d, RelativaGlyphs.text(eq), o, b[0], b[1], 0.1 * s, (float) (0.014 * s + 0.004), c, hot(c),
                        a, Float.MAX_VALUE);
            }
            d.glow(o.x, o.y, o.z, (float) (0.45 * s), c, a * 0.25f);
        }
    }

    // ================================================================== Dilatasi Waktu

    /** Medan dilatasi: kulit bola, pita jam di garis lintang, jam di tanah yang jarumnya nyaris diam, dan jam cahaya. */
    static final class DilationField extends Effect {
        private final AbstractClientPlayer p;
        private final double r;

        DilationField(AbstractClientPlayer p, double r, int life) {
            super(life);
            this.p = p;
            this.r = r;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (age > 6 && (RelativaClientState.flags(p.getId()) & RelativaNetwork.FLAG_DILATION) == 0) {
                return false;
            }
            Vec3 c = p.position().add(0, 1.0, 0);
            RandomSource rnd = level.random;
            for (int i = 0; i < 3; i++) {   // debu waktu yang melayang lambat sekali
                Vec3 o = ShazamFx.randomDir(rnd).scale(rnd.nextDouble() * r * 0.9);
                Vfx.mote(c.x + o.x, c.y + o.y, c.z + o.z, 0, 0.002, 0, rnd.nextBoolean() ? RelativaFx.RELATIV : RelativaFx.LIGHT,
                        0.07f, 40);
            }
            LocalPlayer me = Minecraft.getInstance().player;
            if (me != null && me.position().distanceTo(c) < r) {
                Vfx.worldTint(0x18304A, 0.12f);
            }
            if (age % 10 == 0) {   // jam kecil yang berdetak lambat di atas tiap makhluk di dalam medan
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r))) {
                    if (e != p && e.isAlive() && e.position().distanceTo(c) < r) {
                        Vfx.add(new SlowClock(e, 12));
                    }
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 8f, 12f);
            Vec3 c = p.getPosition(d.partialTick).add(0, 1.0, 0);
            d.shell(c.x, c.y, c.z, r, RelativaFx.RELATIV, 0.22f * a, 3.0, 1.0);
            for (int k = -2; k <= 2; k++) {
                double lat = k * 0.36, y = c.y + r * Math.sin(lat), rr = r * Math.cos(lat);
                d.ring(c.x, y, c.z, 0, 1, 0, rr, 0.12, RelativaFx.RELATIV, 0.4f * a, 0f, null);
            }
            for (int k = 0; k < 48; k++) {   // tanda jam di khatulistiwa, berputar sangat lambat
                double ang = k * Math.PI / 24.0 + time * 0.003;
                double cs = Math.cos(ang), sn = Math.sin(ang);
                float len = k % 4 == 0 ? 0.9f : 0.45f;
                d.line(c.x + cs * (r - len), c.y, c.z + sn * (r - len), c.x + cs * r, c.y, c.z + sn * r, 0.1f, 0.1f,
                        RelativaFx.LIGHT, a * 0.8f, a * 0.8f);
            }
            Vec3 g = p.getPosition(d.partialTick).add(0, 0.06, 0);   // jam di tanah: jarumnya nyaris berhenti
            d.ring(g.x, g.y, g.z, 0, 1, 0, r * 0.95, 0.3, RelativaFx.RELATIV, 0.55f * a, 0.04f, null);
            double hand = time * 0.004, minute = time * 0.05;
            d.line(g.x, g.y, g.z, g.x + Math.cos(hand) * r * 0.5, g.y, g.z + Math.sin(hand) * r * 0.5, 0.32f, 0.14f, 0xFFFFFF, a, a);
            d.line(g.x, g.y, g.z, g.x + Math.cos(minute) * r * 0.78, g.y, g.z + Math.sin(minute) * r * 0.78, 0.2f, 0.08f,
                    0xFFFFFF, a, a);
            // jam cahaya Einstein: foton memantul di antara dua cermin di atas kepala (lambat, waktunya mulur)
            Vec3 head = p.getPosition(d.partialTick).add(0, p.getBbHeight() + 0.45, 0);
            double y0 = head.y, y1 = head.y + 0.9, m = 0.22;
            for (double y : new double[] {y0, y1}) {
                d.quad(head.x - m, y, head.z - m, head.x + m, y, head.z - m, head.x + m, y, head.z + m, head.x - m, y, head.z + m,
                        RelativaFx.LIGHT, a * 0.35f, a * 0.35f, a * 0.35f, a * 0.35f);
            }
            double tri = Math.abs(((time * 0.035) % 2.0) - 1.0);
            double py = y0 + (y1 - y0) * tri;
            d.line(head.x, y0, head.z, head.x, y1, head.z, 0.02f, 0.02f, RelativaFx.PHOTON, a * 0.3f, a * 0.3f);
            d.flare(head.x, py, head.z, 0.12f, RelativaFx.PHOTON, a);
        }
    }

    /** Jam kecil di atas kepala makhluk yang waktunya diperlambat. */
    static final class SlowClock extends Effect {
        private final Entity e;

        SlowClock(Entity e, int life) {
            super(life);
            this.e = e;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return e.isAlive() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 2f, 3f) * 0.8f;
            Vec3 c = e.getPosition(d.partialTick).add(0, e.getBbHeight() + 0.4, 0);
            Vec3 n = toCam(d, c);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, 0.22, 0.03, RelativaFx.RELATIV, a, 0.1f, null);
            double ang = (e.tickCount + d.partialTick) * 0.02;
            Vec3[] b = RelativaGlyphs.facing(d, c);
            Vec3 tip = c.add(b[0].scale(Math.sin(ang) * 0.17)).add(b[1].scale(Math.cos(ang) * 0.17));
            d.line(c.x, c.y, c.z, tip.x, tip.y, tip.z, 0.03f, 0.02f, 0xFFFFFF, a, a);
        }
    }

    // ================================================================== Lengkung Ruang-Waktu

    /**
     * Kisi "lembaran karet": pinggirnya terangkat, tengahnya turun menyentuh tanah, garisnya mengerut ke pusat; kelereng uji
     * berputar menuruni lengkungan; di tick slam lengkungannya menghentak lalu beriak.
     */
    static final class SpacetimeGrid extends Effect implements Lensing {
        private final Vec3 c;
        private final double reach, k;
        private final int hit, slam;
        private final double[] mr, ma;
        private final boolean lensing;
        private boolean dead;

        SpacetimeGrid(Vec3 c, double reach, int hit, int slam, int life, boolean lensing) {
            super(life);
            this.c = c;
            this.reach = reach;
            this.k = Math.max(1.0, reach / 7.0);   // 0.68 lengkungannya ikut membesar bersama kisinya
            this.hit = hit;
            this.slam = slam;
            this.lensing = lensing;
            RandomSource r = Vfx.random();
            mr = new double[16];
            ma = new double[16];
            for (int i = 0; i < mr.length; i++) {
                mr[i] = reach * (0.45 + r.nextDouble() * 0.5);
                ma[i] = r.nextDouble() * Math.PI * 2.0;
            }
        }

        private double depth(float t) {
            if (t < hit) {
                return 0.4 * k * t / hit;
            }
            if (t < slam) {
                float f = (t - hit) / (slam - hit);
                return (0.4 + 1.8 * f * f * (3 - 2 * f)) * k;
            }
            float s = t - slam;
            return (2.2 + 1.1 * Math.exp(-s / 3.0) * Math.cos(s * 0.9)) * k * Math.max(0.0, 1.0 - s / (life - slam));
        }

        private double height(double r, double depth, float t) {
            double h = 0.06 + depth * (1.0 - Math.exp(-r * r / (8.0 * k * k)));
            if (t > slam) {
                float s = t - slam;
                h += 0.3 * k * Math.exp(-s / 8.0) * Math.sin(r * 2.2 / k - s * 0.9);
            }
            return h;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (age >= hit && age < slam) {
                double f = (age - hit) / (double) (slam - hit);
                for (int i = 0; i < mr.length; i++) {   // kelereng uji: makin dekat makin cepat berputar (Kepler)
                    mr[i] = Math.max(0.25 * k, mr[i] - (0.05 + 0.12 * f) * k);
                    ma[i] += 0.35 / Math.max(0.5, Math.sqrt(mr[i] / k));
                }
            }
            boolean ok = super.tick(level);
            dead |= !ok;
            return ok;
        }

        @Override
        public boolean alive() {
            return !dead;
        }

        @Override
        public float[] lens(float pt) {
            float t = time(pt);
            if (!lensing || t < hit || t > slam + 6) {
                return null;
            }
            float k = t < slam ? (t - hit) / (slam - hit) : 1f - (t - slam) / 6f;
            return new float[] {(float) c.x, (float) (c.y + 1.2 * this.k), (float) c.z, (float) (1.6 * this.k), 0f, 0f,
                    Mth.clamp(k, 0f, 1f) * 0.7f};
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float a = fade(t, life, 6f, 10f);
            double depth = depth(t);
            int n = (int) Math.round(25 * Math.min(1.6, k)), lines = (int) Math.round(10 * Math.min(1.6, k));
            double step = reach / lines;
            float[] xyz = new float[n * 3];
            float[] w = new float[n];
            float[] al = new float[n];
            double pinch = 0.35 * Math.min(1.0, depth / (2.2 * k));
            for (int dir = 0; dir < 2; dir++) {
                for (int i = -lines; i <= lines; i++) {
                    double off = i * step;
                    for (int j = 0; j < n; j++) {
                        double s = -reach + 2.0 * reach * j / (n - 1);
                        double x = dir == 0 ? s : off, z = dir == 0 ? off : s;
                        double r = Math.sqrt(x * x + z * z);
                        double q = 1.0 - pinch * Math.exp(-r * r / (6.5 * k * k));
                        xyz[j * 3] = (float) (c.x + x * q);
                        xyz[j * 3 + 1] = (float) (c.y + height(r * q, depth, t));
                        xyz[j * 3 + 2] = (float) (c.z + z * q);
                        double fr = Math.max(0.0, 1.0 - r / (reach * 1.02));
                        al[j] = (float) (a * 0.6 * Math.pow(fr, 0.6));
                        w[j] = (float) (0.045 * Math.sqrt(k));
                    }
                    d.polyline(xyz, n, w, al, RelativaFx.GRAVITY, hot(RelativaFx.GRAVITY));
                }
            }
            if (t >= hit && t < slam + 2) {
                for (int i = 0; i < mr.length; i++) {
                    double x = Math.cos(ma[i]) * mr[i], z = Math.sin(ma[i]) * mr[i];
                    d.flare(c.x + x, c.y + height(mr[i], depth, t) + 0.12, c.z + z, (float) (0.14 * Math.sqrt(k)), RelativaFx.LIGHT, a);
                }
            }
            d.glow(c.x, c.y + 0.3, c.z, (float) (0.6 + depth * 0.5), RelativaFx.GRAVITY, a * 0.5f);
        }
    }

    // ================================================================== Lubang Hitam

    /**
     * Lubang hitam: piringan akresi miring (panas di dalam, berkas Doppler: sisi yang mendekat lebih terang), jet relativistik
     * dua arah, materi yang berputar jatuh, blok yang tercabut & termakan (spagetifikasi). Bayangannya & cincin Einstein
     * dibuat shader lensa gravitasi (RelativaLensShader); kalau shader nggak bisa dipakai, bayangan & cincinnya digambar di sini.
     */
    static final class BlackHole extends Effect implements Lensing {
        private static final int P = 96;   // 0.68 materi yang berputar jatuh dua kali lebih banyak
        private final AbstractClientPlayer owner;
        private final Vec3 c, n;
        private final int form, alive;
        private final double[] e = new double[6];
        private final double[] pr = new double[P], pa = new double[P], py = new double[P], ox = new double[P],
                oy = new double[P], oz = new double[P];
        private final List<long[]> watched = new ArrayList<>();
        private final List<BlockState> watchedState = new ArrayList<>();
        private boolean dead;

        BlackHole(AbstractClientPlayer owner, Vec3 c, int form, int alive) {
            super(form + alive + 6);
            this.owner = owner;
            this.c = c;
            this.form = form;
            this.alive = alive;
            RandomSource r = Vfx.random();
            double tilt = 0.32 + r.nextDouble() * 0.2, yaw = r.nextDouble() * Math.PI * 2.0;
            this.n = new Vec3(Math.sin(tilt) * Math.cos(yaw), Math.cos(tilt), Math.sin(tilt) * Math.sin(yaw));
            Draw.plane(n.x, n.y, n.z, e);
            for (int i = 0; i < P; i++) {
                spawn(i, r, true);
            }
        }

        private void spawn(int i, RandomSource r, boolean anywhere) {
            pr[i] = (anywhere ? 2.0 + r.nextDouble() * 7.0 : 6.5 + r.nextDouble() * 3.5) * S;
            pa[i] = r.nextDouble() * Math.PI * 2.0;
            py[i] = (r.nextDouble() - 0.5) * 0.6 * S;
            Vec3 q = point(pr[i], pa[i], py[i]);
            ox[i] = q.x;
            oy[i] = q.y;
            oz[i] = q.z;
        }

        private Vec3 point(double rad, double ang, double up) {
            double cs = Math.cos(ang), sn = Math.sin(ang);
            return new Vec3(c.x + (e[0] * cs + e[3] * sn) * rad + n.x * up, c.y + (e[1] * cs + e[4] * sn) * rad + n.y * up,
                    c.z + (e[2] * cs + e[5] * sn) * rad + n.z * up);
        }

        private double grow(float t) {
            return Mth.clamp((t - form) / 30.0, 0.0, 1.0);
        }

        /** Jari-jari cakrawala peristiwa (dunia). */
        private double horizon(float t) {
            if (t < form) {
                return 0.0;
            }
            double h = (0.7 + 0.9 * grow(t)) * S;
            double end = form + alive;
            if (t > end - 12) {   // menguap: menciut cepat (radiasi Hawking makin deras)
                h *= Math.max(0.04, (end - t) / 12.0);
            }
            return h;
        }

        private float alpha(float t) {
            if (t < form) {
                return 0f;
            }
            return Mth.clamp((t - form) / 6f, 0f, 1f) * Mth.clamp((form + alive + 4 - t) / 6f, 0f, 1f);
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            int t = age;
            if (t < form) {   // massa dikumpulkan: aliran materi dari tangan & pusaran yang mengecil
                Vec3 hand = ShazamPoses.handPos(owner, true, 1f);
                for (int i = 0, k = Vfx.count(4); i < k; i++) {
                    Vec3 s = hand.lerp(c, r.nextDouble() * 0.3);
                    Vec3 v = c.subtract(s).normalize().scale(0.45);
                    Vfx.streak(s.x, s.y, s.z, v.x, v.y, v.z, RelativaFx.GRAVITY, 0.05f, 8);
                }
                Vec3 o = ShazamFx.randomDir(r).scale((3.0 + r.nextDouble()) * S);
                Vfx.mote(c.x + o.x, c.y + o.y, c.z + o.z, -o.x * 0.12, -o.y * 0.12, -o.z * 0.12, RelativaFx.DISK_HOT, 0.1f, 9);
            }
            if (t == form) {   // blok di sekitarnya dicatat: begitu server memakannya, pecahannya tersedot masuk
                BlockPos center = BlockPos.containing(c);
                int w = (int) Math.ceil(6 * S);
                double w2 = 38 * S * S;
                for (int dx = -w; dx <= w && watched.size() < 3200; dx++) {
                    for (int dy = -w; dy <= w; dy++) {
                        for (int dz = -w; dz <= w; dz++) {
                            if (dx * dx + dy * dy + dz * dz > w2) {
                                continue;
                            }
                            BlockPos bp = center.offset(dx, dy, dz);
                            BlockState st = level.getBlockState(bp);
                            if (!st.isAir() && st.getRenderShape() == RenderShape.MODEL) {
                                watched.add(new long[] {bp.asLong()});
                                watchedState.add(st);
                            }
                        }
                    }
                }
            }
            if (t >= form && t < form + alive) {
                double h = horizon(t);
                for (int i = 0; i < P; i++) {
                    Vec3 q = point(pr[i], pa[i], py[i]);
                    ox[i] = q.x;
                    oy[i] = q.y;
                    oz[i] = q.z;
                    pa[i] += 0.55 / Math.pow(Math.max(0.6, pr[i] / S), 1.5);
                    pr[i] -= (0.02 + 0.08 / Math.max(0.5, pr[i] / S)) * S;
                    py[i] *= 0.96;
                    if (pr[i] < h * 1.2) {
                        spawn(i, r, false);
                    }
                }
                int spawned = 0;
                for (int i = watched.size() - 1; i >= 0 && spawned < 14; i--) {
                    BlockPos bp = BlockPos.of(watched.get(i)[0]);
                    if (level.getBlockState(bp).isAir()) {
                        Vfx.add(new Infall(watchedState.get(i), Vec3.atCenterOf(bp), c, 18 + r.nextInt(14)));
                        watched.remove(i);
                        watchedState.remove(i);
                        spawned++;
                    }
                }
                for (int k = 0; k < 2; k++) {   // cahaya bintang di sekitarnya terseret masuk
                    Vec3 o = ShazamFx.randomDir(r).scale((9.0 + r.nextDouble() * 4.0) * S);
                    Vfx.streak(c.x + o.x, c.y + o.y, c.z + o.z, -o.x * 0.06, -o.y * 0.06, -o.z * 0.06, RelativaFx.LIGHT, 0.06f, 14);
                }
            }
            boolean ok = super.tick(level);
            dead |= !ok;
            return ok;
        }

        @Override
        public boolean alive() {
            return !dead;
        }

        @Override
        public float[] lens(float pt) {
            float t = time(pt);
            double h = horizon(t);
            float a = alpha(t);
            if (h <= 0.0 || a <= 0.01f) {
                return null;
            }
            return new float[] {(float) c.x, (float) c.y, (float) c.z, (float) (h * 2.8), (float) (h * 1.25), 0.9f, a};
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            if (t < form) {
                float f = t / form;
                d.flare(c.x, c.y, c.z, (float) ((0.3f + 0.9f * f) * F), RelativaFx.GRAVITY, 0.4f + 0.5f * f);
                Vec3 tc = toCam(d, c);
                d.ring(c.x, c.y, c.z, tc.x, tc.y, tc.z, (3.2 * (1.0 - f) + 0.2) * S, 0.12 * F, RelativaFx.DISK_HOT, 0.7f * f, 0f, null);
                return;
            }
            float a = alpha(t);
            double h = horizon(t);
            if (a <= 0.003f || h <= 0.0) {
                return;
            }
            boolean shader = RelativaLensShader.usable();
            Vec3 tc = toCam(d, c);
            // piringan akresi: pita-pita konsentris, rotasi diferensial (dalam lebih cepat), berkas Doppler
            int bands = 9, segs = 56;
            double inner = 1.7 * h, outer = 4.8 * h;
            for (int b = 0; b < bands; b++) {
                double r0 = inner + (outer - inner) * b / bands, r1 = inner + (outer - inner) * (b + 1) / bands;
                double fr = (double) b / bands;
                int col0 = Draw.mix(RelativaFx.DISK_HOT, RelativaFx.DISK, Math.min(1.0, fr * 1.6));
                int col1 = Draw.mix(RelativaFx.DISK_HOT, RelativaFx.DISK, Math.min(1.0, (fr + 1.0 / bands) * 1.6));
                if (fr > 0.6) {
                    col0 = Draw.mix(col0, 0x8A1A10, (fr - 0.6) * 2.0);
                    col1 = Draw.mix(col1, 0x8A1A10, (fr - 0.6) * 2.0);
                }
                float base0 = (float) Math.pow(1.0 - fr, 1.2) * a, base1 = (float) Math.pow(1.0 - fr - 1.0 / bands, 1.2) * a;
                double rot = t * 0.09 / Math.pow(r0 / inner, 1.5);
                for (int j = 0; j < segs; j++) {
                    double f0 = Math.PI * 2.0 * j / segs, f1 = Math.PI * 2.0 * (j + 1) / segs;
                    Vec3 q00 = point(r0, f0, 0), q01 = point(r0, f1, 0), q10 = point(r1, f0, 0), q11 = point(r1, f1, 0);
                    Vec3 mid = point((r0 + r1) * 0.5, (f0 + f1) * 0.5, 0);
                    if (!shader) {   // tanpa shader: bagian belakang piringan tertutup bayangan
                        Vec3 rel = mid.subtract(c);
                        double along = rel.dot(tc);
                        if (along < 0 && rel.subtract(tc.scale(along)).length() < h * 1.3) {
                            continue;
                        }
                    }
                    double fm = (f0 + f1) * 0.5;
                    Vec3 tan = new Vec3(-(e[0] * Math.sin(fm)) + e[3] * Math.cos(fm), -(e[1] * Math.sin(fm)) + e[4] * Math.cos(fm),
                            -(e[2] * Math.sin(fm)) + e[5] * Math.cos(fm));
                    Vec3 view = new Vec3(d.camX - mid.x, d.camY - mid.y, d.camZ - mid.z);
                    double vl = view.length();
                    double beam = vl < 1.0E-6 ? 0.6 : 0.55 + 0.45 * tan.dot(view) / vl;
                    double streak = 0.62 + 0.38 * Math.sin(3.0 * (fm - rot) + b * 0.7);
                    float k = (float) (beam * streak);
                    d.quad4(q00.x, q00.y, q00.z, q01.x, q01.y, q01.z, q11.x, q11.y, q11.z, q10.x, q10.y, q10.z,
                            col0, col0, col1, col1, base0 * k, base0 * k, base1 * k, base1 * k);
                }
            }
            if (!shader) {   // cincin foton & citra piringan yang terlensa (tanpa shader)
                d.ring(c.x, c.y, c.z, tc.x, tc.y, tc.z, h * 1.32, h * 0.1, RelativaFx.DISK_HOT, a, 0f, null);
                d.ring(c.x, c.y, c.z, tc.x, tc.y, tc.z, h * 1.75, h * 0.45, RelativaFx.DISK, 0.5f * a, 0f, null);
            }
            // jet relativistik dua arah dengan gumpalan yang melesat
            for (int s = -1; s <= 1; s += 2) {
                Vec3 base = c.add(n.scale(s * h * 1.1));
                Vec3 tip = c.add(n.scale(s * (9.0 + 2.0 * Math.sin(t * 0.2)) * S));
                d.beam(base.x, base.y, base.z, tip.x, tip.y, tip.z, (float) (0.22 + 0.2 * h), RelativaFx.JET, 0xFFFFFF, 0.85f * a,
                        0f);
                for (int k = 0; k < 3; k++) {
                    double f = (t * 0.06 + k / 3.0) % 1.0;
                    Vec3 q = base.lerp(tip, f);
                    d.flare(q.x, q.y, q.z, (float) (0.35 * F * (1.0 - f)), RelativaFx.JET, a * (float) (1.0 - f));
                }
            }
            // materi yang berputar jatuh
            float pt = d.partialTick;
            for (int i = 0; i < P; i++) {
                Vec3 q = point(pr[i], pa[i], py[i]);
                double x0 = ox[i], y0 = oy[i], z0 = oz[i];
                double x1 = x0 + (q.x - x0) * pt, y1 = y0 + (q.y - y0) * pt, z1 = z0 + (q.z - z0) * pt;
                int col = pr[i] < inner * 1.4 ? RelativaFx.DISK_HOT : RelativaFx.DISK;
                d.line(x0, y0, z0, x1 + (x1 - x0), y1 + (y1 - y0), z1 + (z1 - z0), 0.08f, 0.03f, col, a * 0.9f, a * 0.3f);
            }
        }

        @Override
        public void renderSoft(Draw d) {
            float t = time(d.partialTick);
            float a = alpha(t);
            double h = horizon(t);
            if (a <= 0.003f || h <= 0.0) {
                return;
            }
            Vec3 tc = toCam(d, c);
            if (!RelativaLensShader.usable()) {   // bayangan lubang hitam (tanpa shader): cakram hitam pekat
                d.disc(c.x, c.y, c.z, tc.x, tc.y, tc.z, h * 1.25, 0x000000, a, a, null);
            }
            d.puff(c.x, c.y, c.z, (float) (h * 2.6), 0x07040C, 0x000000, 0.3f * a);
        }
    }

    /** Pecahan blok yang termakan lubang hitam: berputar spiral masuk, memanjang (spagetifikasi), memijar, lenyap. */
    static final class Infall extends Effect {
        private final BlockState state;
        private final Vec3 c;
        private final double r0, phase, dy;
        private final float ax, ay, az, spin;

        Infall(BlockState state, Vec3 start, Vec3 c, int life) {
            super(life);
            this.state = state;
            this.c = c;
            double dx = start.x - c.x, dz = start.z - c.z;
            this.r0 = Math.max(0.3, Math.sqrt(dx * dx + dz * dz));
            this.phase = Math.atan2(dz, dx);
            this.dy = start.y - c.y;
            RandomSource r = Vfx.random();
            float x = r.nextFloat() - 0.5f, y = r.nextFloat() - 0.5f, z = r.nextFloat() - 0.5f;
            float l = (float) Math.sqrt(x * x + y * y + z * z) + 1.0E-4f;
            this.ax = x / l;
            this.ay = y / l;
            this.az = z / l;
            this.spin = (r.nextFloat() - 0.5f) * 0.8f;
        }

        private Vec3 at(float time) {
            float f = Mth.clamp(time / life, 0f, 1f);
            double e = Math.pow(f, 1.6);
            double rad = r0 * (1.0 - e), ang = phase + 2.6 * e * e + 0.6 * e;
            return new Vec3(c.x + Math.cos(ang) * rad, c.y + dy * (1.0 - e), c.z + Math.sin(ang) * rad);
        }

        @Override
        public void renderSolid(PoseStack poseStack, MultiBufferSource buffers, double camX, double camY, double camZ,
                                float partialTick) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.level == null) {
                return;
            }
            float time = age + partialTick;
            float f = Mth.clamp(time / life, 0f, 1f);
            if (f >= 0.98f) {
                return;
            }
            Vec3 q = at(time);
            float s = (float) (0.9 * Math.pow(1.0 - f, 0.6));
            float stretch = 1f + 2.6f * f * f;
            float yaw = (float) Math.atan2(c.z - q.z, c.x - q.x);
            poseStack.pushPose();
            poseStack.translate(q.x - camX, q.y - camY, q.z - camZ);
            poseStack.mulPose(new Quaternionf().rotationY(-yaw));
            poseStack.scale(s * stretch, s / (float) Math.sqrt(stretch), s / (float) Math.sqrt(stretch));
            poseStack.mulPose(new Quaternionf().rotationAxis(time * spin, ax, ay, az));
            poseStack.translate(-0.5f, -0.5f, -0.5f);
            int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(q.x, q.y, q.z));
            mc.getBlockRenderer().renderSingleBlock(state, poseStack, buffers, light, OverlayTexture.NO_OVERLAY);
            poseStack.popPose();
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float f = Mth.clamp(time / life, 0f, 1f);
            Vec3 q = at(time);
            d.glow(q.x, q.y, q.z, 0.15f + 0.35f * f, RelativaFx.DISK_HOT, f * 0.8f);
        }
    }

    // ================================================================== Kuantum

    /** Paket gelombang ψ dari a ke b: bagian riil (tegak) & imajiner (mendatar) berpilin, amplopnya Gauss. */
    static final class WavePacket extends Effect {
        private final Vec3 a, b;
        private final int depart, travel;

        WavePacket(Vec3 a, Vec3 b, int depart, int travel, int life) {
            super(life);
            this.a = a;
            this.b = b;
            this.depart = depart;
            this.travel = Math.max(1, travel);
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            Vec3 ab = b.subtract(a);
            double len = Math.max(0.1, ab.length());
            Vec3 dir = ab.scale(1.0 / len);
            Vec3 side = dir.cross(UP);
            side = side.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : side.normalize();
            Vec3 up = side.cross(dir).normalize();
            double s0 = t < depart ? 0.0 : Math.min(len, len * (t - depart) / travel);
            double sigma = 0.7 + 0.6 * Math.min(1.0, t / Math.max(1.0, depart));
            float amp = (float) (0.38 * Math.min(1.0, t / 4.0));
            float end = depart + travel;
            if (t > end) {
                amp *= Math.max(0f, 1f - (t - end) / 6f);
            }
            if (amp <= 0.003f) {
                return;
            }
            int n = 64;
            float[] re = new float[n * 3], im = new float[n * 3];
            double from = s0 - 3.0 * sigma, to = s0 + 3.0 * sigma;
            for (int i = 0; i < n; i++) {
                double s = from + (to - from) * i / (n - 1);
                double env = Math.exp(-(s - s0) * (s - s0) / (2.0 * sigma * sigma)) * amp;
                double ph = 7.0 * s - 0.9 * t;
                Vec3 base = a.add(dir.scale(s));
                Vec3 pr = base.add(up.scale(env * Math.cos(ph)));
                Vec3 pi = base.add(side.scale(env * Math.sin(ph)));
                re[i * 3] = (float) pr.x;
                re[i * 3 + 1] = (float) pr.y;
                re[i * 3 + 2] = (float) pr.z;
                im[i * 3] = (float) pi.x;
                im[i * 3 + 1] = (float) pi.y;
                im[i * 3 + 2] = (float) pi.z;
            }
            float al = Math.min(1f, amp * 3f);
            d.polyline(re, n, 0.07f, 0.07f, RelativaFx.QUANTUM, 0xFFFFFF, al, al);
            d.polyline(im, n, 0.05f, 0.05f, RelativaFx.POSITRON, 0xFFE0FF, al * 0.8f, al * 0.8f);
            Vec3 m = a.add(dir.scale(s0));
            d.flare(m.x, m.y, m.z, 0.3f, RelativaFx.QUANTUM, al * 0.8f);
        }
    }

    /** Jaring keterikatan: pita yang berpendar menyambung tiap pasangan yang terikat. */
    static final class Web extends Effect {
        final List<Entity> nodes = new ArrayList<>();

        Web(int life) {
            super(life);
        }

        @Override
        public boolean tick(ClientLevel level) {
            nodes.removeIf(e -> !e.isAlive());
            return (age < 14 || !nodes.isEmpty()) && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            int count = nodes.size();
            if (count < 2) {
                return;
            }
            float time = time(d.partialTick);
            float a = fade(time, life, 6f, 12f) * 0.55f;
            int links = count == 2 ? 1 : count;
            int n = 20;
            float[] pts = new float[n * 3];
            for (int k = 0; k < links; k++) {
                Vec3 s = chestOf(nodes.get(k), d.partialTick), e = chestOf(nodes.get((k + 1) % count), d.partialTick);
                Vec3 dir = e.subtract(s);
                Vec3 side = dir.cross(UP);
                side = side.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : side.normalize();
                for (int i = 0; i < n; i++) {
                    double f = i / (double) (n - 1);
                    double wv = Math.sin(Math.PI * f) * 0.25 * Math.sin(time * 0.5 + f * 14.0 + k);
                    pts[i * 3] = (float) (s.x + dir.x * f + side.x * wv);
                    pts[i * 3 + 1] = (float) (s.y + dir.y * f + Math.sin(Math.PI * f) * 0.3);
                    pts[i * 3 + 2] = (float) (s.z + dir.z * f + side.z * wv);
                }
                int col = k % 2 == 0 ? RelativaFx.ELECTRON : RelativaFx.POSITRON;
                d.polyline(pts, n, 0.06f, 0.06f, col, hot(col), a, a);
            }
        }
    }

    /** Panah spin (atas / bawah) di atas kepala makhluk yang terikat, berpresesi pelan; berkilat saat damage mengalir. */
    static final class SpinMark extends Effect {
        final Entity e;
        private final boolean upSpin;
        private int pulseAt = -100;

        private boolean cut;

        SpinMark(Entity e, boolean upSpin, int life) {
            super(life);
            this.e = e;
            this.upSpin = upSpin;
        }

        void pulse() {
            pulseAt = age;
        }

        /** 0.68 Keterikatan baru dimulai sebelum yang lama habis: tanda lamanya dilepas. */
        void cut() {
            cut = true;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return !cut && e.isAlive() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 4f, 10f);
            float kick = Mth.clamp(1f - (time - pulseAt) / 8f, 0f, 1f);
            int col = upSpin ? RelativaFx.ELECTRON : RelativaFx.POSITRON;
            Vec3 c = e.getPosition(d.partialTick).add(0, e.getBbHeight() + 0.6, 0);
            double tilt = 0.25, ang = time * 0.12;
            Vec3 axis = new Vec3(Math.sin(tilt) * Math.cos(ang), Math.cos(tilt), Math.sin(tilt) * Math.sin(ang));
            Vec3 dirv = upSpin ? axis : axis.scale(-1.0);
            Vec3 tail = c.subtract(dirv.scale(0.28)), tip = c.add(dirv.scale(0.28));
            d.line(tail.x, tail.y, tail.z, tip.x, tip.y, tip.z, 0.06f, 0.06f, col, a, a);
            Vec3 side = dirv.cross(UP);
            side = side.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : side.normalize();
            Vec3 l = tip.subtract(dirv.scale(0.12)).add(side.scale(0.09)), r = tip.subtract(dirv.scale(0.12)).subtract(side.scale(0.09));
            d.line(l.x, l.y, l.z, tip.x, tip.y, tip.z, 0.05f, 0.05f, col, a, a);
            d.line(r.x, r.y, r.z, tip.x, tip.y, tip.z, 0.05f, 0.05f, col, a, a);
            d.ring(c.x, c.y, c.z, axis.x, axis.y, axis.z, 0.22, 0.025, col, a * 0.6f, 0f, null);
            d.glow(c.x, c.y, c.z, 0.3f + 0.5f * kick, col, a * (0.25f + 0.75f * kick));
        }
    }

    // ================================================================== Fisi

    /** Neutron yang melesat dari a ke b (bola kecil keperakan + jejak tipis). */
    static final class Neutron extends Effect {
        private final Vec3 a, b;
        private final int travel;

        Neutron(Vec3 a, Vec3 b, int travel) {
            super(Math.max(1, travel) + 2);
            this.a = a;
            this.b = b;
            this.travel = Math.max(1, travel);
        }

        private Vec3 at(float time) {
            return a.lerp(b, Mth.clamp(time / travel, 0f, 1f));
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            if (time > travel + 0.5f) {
                return;
            }
            Vec3 q = at(time), tail = at(Math.max(0f, time - 1.5f));
            d.line(tail.x, tail.y, tail.z, q.x, q.y, q.z, 0.02f, 0.06f, RelativaFx.NEUTRON, 0.2f, 0.8f);
            d.glow(q.x, q.y, q.z, 0.11f, RelativaFx.NEUTRON, 1f);
            d.glow(q.x, q.y, q.z, 0.05f, 0xFFFFFF, 1f);
        }
    }

    /** Inti yang membelah (model tetes cairan): memanjang, lehernya putus, dua inti anak terpental, 3 neutron, kilat gamma. */
    static final class Fission extends Effect {
        private final Vec3 c, axis;
        private final Vec3[] neutrons = new Vec3[3];
        private final Vec3[] rays = new Vec3[10];

        Fission(Vec3 c, int life) {
            super(life);
            this.c = c;
            RandomSource r = Vfx.random();
            this.axis = ShazamFx.randomDir(r);
            for (int i = 0; i < neutrons.length; i++) {
                neutrons[i] = ShazamFx.randomDir(r);
            }
            for (int i = 0; i < rays.length; i++) {
                rays[i] = ShazamFx.randomDir(r);
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            if (t < 4f) {
                double sep = (0.04 + 0.11 * t / 4.0) * F;
                for (int s = -1; s <= 1; s += 2) {
                    Vec3 q = c.add(axis.scale(s * sep));
                    nucleus(d, q.x, q.y, q.z, 0.16 * F, 11, t * 3f, 1f, RelativaFx.PROTON, RelativaFx.URANIUM);
                }
                d.glow(c.x, c.y, c.z, (float) (0.5 * F), RelativaFx.URANIUM, 0.5f);
                return;
            }
            float f = t - 4f;
            float a = Math.max(0f, 1f - f / 22f);
            double dist = (0.18 + 2.2 * (1.0 - Math.exp(-f / 6.0))) * F;
            for (int s = -1; s <= 1; s += 2) {   // dua inti anak
                Vec3 q = c.add(axis.scale(s * dist));
                nucleus(d, q.x, q.y, q.z, 0.12 * F, 9, t * 2f, a, RelativaFx.PROTON, RelativaFx.NEUTRON);
            }
            float na = Math.max(0f, 1f - f / 10f);
            for (Vec3 nd : neutrons) {   // neutron bebas: siap membelah inti berikutnya
                Vec3 q = c.add(nd.scale(0.7 * f * F));
                Vec3 tail = c.add(nd.scale(Math.max(0.0, (0.7 * f - 0.6) * F)));
                d.line(tail.x, tail.y, tail.z, q.x, q.y, q.z, 0.015f, 0.07f, RelativaFx.NEUTRON, 0f, na);
                d.glow(q.x, q.y, q.z, (float) (0.08 * F), 0xFFFFFF, na);
            }
            if (f < 4f) {   // kilat sinar gamma
                float ga = 1f - f / 4f;
                for (Vec3 ray : rays) {
                    Vec3 end = c.add(ray.scale((0.6 + f * 0.9) * F));
                    d.line(c.x, c.y, c.z, end.x, end.y, end.z, 0.08f, 0.0f, RelativaFx.GAMMA, ga, 0f);
                }
            }
            d.glow(c.x, c.y, c.z, (float) ((0.9f + f * 0.15f) * F), RelativaFx.CHERENKOV, 0.5f * Math.max(0f, 1f - f / 12f));
        }
    }

    /** Inti uranium Massa Kritis: dilempar, lalu neutronnya berlipat ganda & lensa ledak merapat sampai meledak. */
    static final class CriticalCore extends Effect {
        private final Vec3 from, target;
        private final int arrive, boom;
        private final Vec3[] lenses = new Vec3[20];

        CriticalCore(Vec3 from, Vec3 target, int arrive, int boom) {
            super(boom + 1);
            this.from = from;
            this.target = target;
            this.arrive = Math.max(1, arrive);
            this.boom = boom;
            double golden = Math.PI * (3.0 - Math.sqrt(5.0));
            for (int i = 0; i < lenses.length; i++) {
                double f = (i + 0.5) / lenses.length, yy = 1.0 - 2.0 * f, rr = Math.sqrt(1.0 - yy * yy), th = golden * i;
                lenses[i] = new Vec3(Math.cos(th) * rr, yy, Math.sin(th) * rr);
            }
        }

        private Vec3 at(float t) {
            if (t >= arrive) {
                return target;
            }
            float f = t / arrive;
            return from.lerp(target, f).add(0, Math.sin(Math.PI * f) * 2.0 * F, 0);
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (age >= arrive && age < boom) {   // reaksi berantai: neutron berlipat dua tiap generasi
                int gen = (age - arrive) / 6;
                int count = Math.min(40, 1 << Math.min(6, gen));
                RandomSource r = level.random;
                for (int i = 0; i < count; i++) {
                    Vec3 o = ShazamFx.randomDir(r);
                    double s = (0.05 + r.nextDouble() * 0.15) * F;
                    Vfx.mote(target.x + o.x * 0.25 * F, target.y + o.y * 0.25 * F, target.z + o.z * 0.25 * F, o.x * s, o.y * s,
                            o.z * s, i % 3 == 0 ? RelativaFx.CHERENKOV : RelativaFx.URANIUM, 0.06f, 10);
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            Vec3 q = at(t);
            float k = t < arrive ? 0.4f : 0.4f + 0.6f * (t - arrive) / Math.max(1f, boom - arrive);
            float pulse = 0.85f + 0.15f * (float) Math.sin(t * (0.6f + k));
            d.flare(q.x, q.y, q.z, (float) ((0.3f + 0.5f * k) * pulse * F), RelativaFx.URANIUM, 0.9f);
            nucleus(d, q.x, q.y, q.z, 0.2 * F, 14, t * (1f + 2f * k), 1f, RelativaFx.URANIUM, RelativaFx.PROTON);
            d.glow(q.x, q.y, q.z, (float) (1.2f * k * F), RelativaFx.CHERENKOV, 0.35f * k);
            float start = boom - 12;
            if (t > start) {   // lensa ledak merapat dari segala arah (implosi)
                float f = Mth.clamp((t - start) / 10f, 0f, 1f);
                double rad = (2.6 * (1.0 - f * f) + 0.35) * F * 1.3;
                for (Vec3 l : lenses) {
                    Vec3 p = q.add(l.scale(rad));
                    d.glint(p.x, p.y, p.z, (float) (0.22 * F), t * 0.1f, 0xFFE8B0, 0.9f);
                    d.line(p.x, p.y, p.z, q.x, q.y, q.z, 0.03f, 0.1f, 0xFFE8B0, 0.15f + 0.5f * f, 0.6f * f);
                }
            }
        }
    }

    /** Awan jamur ledakan fisi: tiang yang naik & kepala yang menggulung (asap tebal + bara di dalamnya). */
    static final class Mushroom extends Effect {
        private final Vec3 c;

        Mushroom(Vec3 c, int life) {
            super(life);
            this.c = c;
        }

        private double capY(float t) {
            return c.y + (2.0 + 13.0 * (1.0 - Math.exp(-t / 28.0))) * S;
        }

        private double capR(float t) {
            return (1.5 + 5.0 * (1.0 - Math.exp(-t / 32.0))) * S;
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            float t = age;
            double cy = capY(t), cr = capR(t);
            if (age < life - 20) {
                for (int i = 0; i < 4; i++) {   // tiang
                    double y = c.y + r.nextDouble() * (cy - c.y);
                    double a = r.nextDouble() * Math.PI * 2.0,
                            rr = (0.6 + 0.6 * r.nextDouble()) * Math.min(1.6, 0.8 + t / 30.0) * S;
                    Vfx.smoke(c.x + Math.cos(a) * rr, y, c.z + Math.sin(a) * rr, 0, 0.12 * S, 0, 0x5A4A42,
                            (float) ((1.0f + r.nextFloat()) * S), 40);
                }
                for (int i = 0; i < 8; i++) {   // kepala yang menggulung
                    double a = r.nextDouble() * Math.PI * 2.0, rr = cr * (0.6 + 0.5 * r.nextDouble());
                    double up = r.nextDouble() * 1.6 * S;
                    double out = up > 0.8 * S ? 0.04 * S : -0.02 * S;
                    Vfx.smoke(c.x + Math.cos(a) * rr, cy + up, c.z + Math.sin(a) * rr, Math.cos(a) * out, 0.02, Math.sin(a) * out,
                            0x6A5A50, (float) ((1.4f + r.nextFloat() * 0.8f) * S), 50);
                }
            }
            if (age < 24) {
                for (int i = 0; i < 6; i++) {
                    double a = r.nextDouble() * Math.PI * 2.0;
                    Vfx.flame(c.x + Math.cos(a) * cr * 0.5, cy + r.nextDouble() * S, c.z + Math.sin(a) * cr * 0.5, 0, 0.05, 0,
                            0xFF7A30, (float) (1.2f * S), 14);
                    Vfx.flame(c.x + Math.cos(a) * 0.8 * S, c.y + r.nextDouble() * 2.0 * S, c.z + Math.sin(a) * 0.8 * S, 0, 0.1, 0,
                            0xFF9A40, (float) (1.0f * S), 12);
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderSoft(Draw d) {
            float t = time(d.partialTick);
            float a = fade(t, life, 4f, 30f) * 0.85f;
            double cy = capY(t), cr = capR(t);
            for (int k = 0; k < 18; k++) {
                double ang = k * Math.PI * 2.0 / 18 + t * 0.01;
                d.puff(c.x + Math.cos(ang) * cr, cy + 0.6 * S * Math.sin(ang * 3.0 + t * 0.05), c.z + Math.sin(ang) * cr,
                        (float) (cr * 0.55), 0x8A7A70, 0x2A2220, a);
            }
            d.puff(c.x, cy + cr * 0.45, c.z, (float) (cr * 0.85), 0x8A7A70, 0x2A2220, a);
            for (int k = 0; k < 8; k++) {
                double y = c.y + (cy - c.y) * (k + 0.5) / 8.0;
                d.puff(c.x, y, c.z, (float) ((0.9 + 0.3 * k / 8.0) * S), 0x7A6A60, 0x2A2220, a * 0.9f);
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float a = Math.max(0f, 1f - t / 34f);
            double cy = capY(t), cr = capR(t);
            d.glow(c.x, cy + cr * 0.3, c.z, (float) (cr * 1.1), 0xFF6A20, 0.7f * a);
            d.glow(c.x, c.y + 0.8 * S, c.z, (float) (2.4 * S), 0xFF9A40, 0.8f * a);
        }
    }

    // ================================================================== Fusi

    /** Bintang mini yang dilempar: inti plasma putih, korona merah muda, jejak api. Meledak sendiri di ujungnya. */
    static final class FusionStar extends Effect {
        private final AbstractClientPlayer owner;
        private final Vec3 a, b;
        private final int travel;
        private boolean boomed;

        FusionStar(AbstractClientPlayer owner, Vec3 a, Vec3 b, int travel) {
            super(Math.max(1, travel) + 2);
            this.owner = owner;
            this.a = a;
            this.b = b;
            this.travel = Math.max(1, travel);
        }

        private Vec3 at(float time) {
            return a.lerp(b, Mth.clamp(time / travel, 0f, 1f));
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (age < travel) {
                Vec3 q = at(age);
                RandomSource r = level.random;
                Vfx.flame(q.x, q.y, q.z, (r.nextDouble() - 0.5) * 0.04, 0.02, (r.nextDouble() - 0.5) * 0.04, RelativaFx.PLASMA,
                        (float) (0.45f * F), 10);
                Vfx.mote(q.x, q.y, q.z, (r.nextDouble() - 0.5) * 0.1, (r.nextDouble() - 0.5) * 0.1, (r.nextDouble() - 0.5) * 0.1,
                        RelativaFx.PLASMA_HOT, 0.06f, 8);
            } else if (!boomed) {
                boomed = true;
                RelativaFx.fusionBoom(level, owner, b);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            if (time > travel) {
                return;
            }
            Vec3 q = at(time);
            d.flare(q.x, q.y, q.z, (float) (0.6f * F), RelativaFx.PLASMA, 1f);
            d.glow(q.x, q.y, q.z, (float) (0.28f * F), 0xFFFFFF, 1f);
            d.glow(q.x, q.y, q.z, (float) (1.1f * F), RelativaFx.PLASMA, 0.3f);
            Vec3[] bs = RelativaGlyphs.facing(d, q);
            for (int k = 0; k < 12; k++) {   // korona
                double ang = k * Math.PI / 6.0 + time * 0.3;
                double len = (0.55 + 0.2 * Math.sin(time * 0.9 + k)) * F;
                Vec3 tip = q.add(bs[0].scale(Math.cos(ang) * len)).add(bs[1].scale(Math.sin(ang) * len));
                d.line(q.x, q.y, q.z, tip.x, tip.y, tip.z, 0.1f, 0f, RelativaFx.PLASMA_HOT, 0.8f, 0f);
            }
        }
    }

    /** Tokamak: donat plasma yang dikurung medan magnet (garis medan berpilin, kumparan, gumpalan plasma yang mengalir). */
    static final class Tokamak extends Effect {
        private final AbstractClientPlayer p;
        private final double major, minor;

        Tokamak(AbstractClientPlayer p, double major, double minor, int life) {
            super(life);
            this.p = p;
            this.major = major;
            this.minor = minor;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (age > 6 && (RelativaClientState.flags(p.getId()) & RelativaNetwork.FLAG_TOKAMAK) == 0) {
                return false;
            }
            RandomSource r = level.random;
            for (int i = 0; i < 2; i++) {
                double ang = r.nextDouble() * Math.PI * 2.0;
                Vec3 c = p.position().add(0, 1.0, 0);
                Vfx.spark(c.x + Math.cos(ang) * major, c.y, c.z + Math.sin(ang) * major, -Math.sin(ang) * 0.4, 0.05,
                        Math.cos(ang) * 0.4, RelativaFx.PLASMA_HOT, 0.06f, 9, Double.NaN);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 6f, 8f);
            Vec3 c = p.getPosition(d.partialTick).add(0, 1.0, 0);
            d.ring(c.x, c.y, c.z, 0, 1, 0, major, minor * 0.6, RelativaFx.PLASMA, 0.85f * a, 0f, null);
            d.ring(c.x, c.y, c.z, 0, 1, 0, major, minor * 0.18, 0xFFFFFF, a, 0f, null);
            for (int k = 0; k < 28; k++) {   // irisan tabung (poloidal)
                double ph = k * Math.PI * 2.0 / 28 + time * 0.01;
                double cs = Math.cos(ph), sn = Math.sin(ph);
                d.ring(c.x + cs * major, c.y, c.z + sn * major, -sn, 0, cs, minor, 0.035, RelativaFx.PLASMA, 0.35f * a, 0f, null);
            }
            for (int k = 0; k < 18; k++) {   // kumparan medan toroidal berbentuk D
                double ph = k * Math.PI * 2.0 / 18;
                double cs = Math.cos(ph), sn = Math.sin(ph);
                Vec3 in = c.add(cs * (major - minor * 1.4), 0, sn * (major - minor * 1.4));
                Vec3 out = c.add(cs * (major + minor * 1.4), 0, sn * (major + minor * 1.4));
                Vec3 top = c.add(cs * major, minor * 1.55, sn * major), bot = c.add(cs * major, -minor * 1.55, sn * major);
                d.line(in.x, in.y + minor * 1.2, in.z, in.x, in.y - minor * 1.2, in.z, 0.05f, 0.05f, 0x90A0C8, 0.35f * a, 0.35f * a);
                d.line(in.x, in.y + minor * 1.2, in.z, top.x, top.y, top.z, 0.05f, 0.05f, 0x90A0C8, 0.35f * a, 0.35f * a);
                d.line(top.x, top.y, top.z, out.x, out.y, out.z, 0.05f, 0.05f, 0x90A0C8, 0.35f * a, 0.35f * a);
                d.line(out.x, out.y, out.z, bot.x, bot.y, bot.z, 0.05f, 0.05f, 0x90A0C8, 0.35f * a, 0.35f * a);
                d.line(bot.x, bot.y, bot.z, in.x, in.y - minor * 1.2, in.z, 0.05f, 0.05f, 0x90A0C8, 0.35f * a, 0.35f * a);
            }
            int n = 200;
            float[] pts = new float[n * 3];
            for (int line = 0; line < 3; line++) {   // garis medan berpilin (faktor keamanan q = 4)
                for (int i = 0; i < n; i++) {
                    double ph = Math.PI * 2.0 * i / (n - 1);
                    double th = 4.0 * ph + time * 0.05 + line * Math.PI * 2.0 / 3.0;
                    double rr = major + minor * 0.8 * Math.cos(th);
                    pts[i * 3] = (float) (c.x + Math.cos(ph) * rr);
                    pts[i * 3 + 1] = (float) (c.y + minor * 0.8 * Math.sin(th));
                    pts[i * 3 + 2] = (float) (c.z + Math.sin(ph) * rr);
                }
                d.polyline(pts, n, 0.07f, 0.07f, RelativaFx.PLASMA_HOT, 0xFFFFFF, 0.6f * a, 0.6f * a);
            }
            for (int k = 0; k < 8; k++) {   // gumpalan plasma yang mengalir mengelilingi cincin
                double ph = time * 0.2 + k * Math.PI * 2.0 / 8;
                d.flare(c.x + Math.cos(ph) * major, c.y, c.z + Math.sin(ph) * major, (float) (0.45f * F), RelativaFx.PLASMA, a);
            }
        }
    }

    // ================================================================== E = mc²

    /** Massa sasaran dikonversi jadi energi: semburan emas, sinar foton memancar, butiran massa yang terurai ke atas. */
    static final class EmcBurst extends Effect {
        private final Entity e;

        EmcBurst(Entity e, int life) {
            super(life);
            this.e = e;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (e.isAlive() && age < life - 10) {
                RandomSource r = level.random;
                AABB box = e.getBoundingBox();
                for (int i = 0; i < 4; i++) {
                    double x = Mth.lerp(r.nextDouble(), box.minX, box.maxX), y = Mth.lerp(r.nextDouble(), box.minY, box.maxY),
                            z = Mth.lerp(r.nextDouble(), box.minZ, box.maxZ);
                    Vfx.mote(x, y, z, 0, 0.06 + r.nextDouble() * 0.05, 0, RelativaFx.GOLD, 0.06f, 16);
                }
                Vec3 c = e.position().add(0, e.getBbHeight() * 0.6, 0);
                Vec3 v = ShazamFx.randomDir(r).scale(0.6);
                Vfx.streak(c.x, c.y, c.z, v.x, v.y, v.z, 0xFFFFFF, 0.05f, 8);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float f = time / life;
            float a = fade(time, life, 1f, 12f);
            Vec3 c = chestOf(e, d.partialTick);
            d.flare(c.x, c.y, c.z, (float) ((0.4f + 1.4f * (1f - f)) * F), RelativaFx.GOLD, a);
            Vec3[] b = RelativaGlyphs.facing(d, c);
            for (int k = 0; k < 16; k++) {
                double ang = k * Math.PI / 8.0 + time * 0.05;
                double len = (0.6 + 2.6 * Math.min(1.0, f * 2.0)) * F;
                Vec3 tip = c.add(b[0].scale(Math.cos(ang) * len)).add(b[1].scale(Math.sin(ang) * len));
                d.line(c.x, c.y, c.z, tip.x, tip.y, tip.z, 0.14f, 0f, 0xFFF4C0, a, 0f);
            }
            Vec3 n = toCam(d, c);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, (0.4 + 3.0 * f) * F, 0.16, RelativaFx.GOLD, a * (1f - f), 0f, null);
        }
    }

    /** Dua sinar gamma anihilasi yang berlawanan arah (ke depan & ke belakang), ikut arah pandang. */
    static final class GammaBeams extends Effect {
        private final AbstractClientPlayer p;
        private Vec3 front, back;

        GammaBeams(AbstractClientPlayer p, int life) {
            super(life);
            this.p = p;
            update();
        }

        private Vec3 origin(float pt) {
            return p.getEyePosition(pt).add(0, -0.35, 0);
        }

        private void update() {
            Vec3 o = origin(1f);
            Vec3 look = p.getViewVector(1f);
            ClientLevel level = (ClientLevel) p.level();
            front = HdKit.rayEnd(level, p, o, look, 30.0 * S);
            back = HdKit.rayEnd(level, p, o, look.scale(-1.0), 30.0 * S);
        }

        @Override
        public boolean tick(ClientLevel level) {
            update();
            CineKit.sparks(front, 8, RelativaFx.GAMMA, 0.45, 0.06f, 9, front.y - 2);
            CineKit.sparks(back, 8, RelativaFx.GAMMA, 0.45, 0.06f, 9, back.y - 2);
            return p.isAlive() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 1f, 5f);
            Vec3 o = origin(d.partialTick);
            for (Vec3 end : new Vec3[] {front, back}) {
                d.beam(o.x, o.y, o.z, end.x, end.y, end.z, (float) (0.6f * a * F * 1.3), RelativaFx.GAMMA, 0xFFFFFF, a, 0.8f * a);
                Vec3 dir = end.subtract(o);
                double len = dir.length();
                if (len < 0.5) {
                    continue;
                }
                dir = dir.scale(1.0 / len);
                Vec3 side = dir.cross(UP);
                side = side.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : side.normalize();
                Vec3 up = side.cross(dir);
                int n = Math.min(200, (int) (len * 3) + 2);
                float[] pts = new float[n * 3];
                double helix = 0.22 * F * 1.3;
                for (int i = 0; i < n; i++) {   // foton gamma = gelombang: pilinan tipis di sekeliling sinar
                    double s = len * i / (n - 1), ph = s * 7.0 - time * 1.6;
                    Vec3 q = o.add(dir.scale(s)).add(side.scale(Math.cos(ph) * helix)).add(up.scale(Math.sin(ph) * helix));
                    pts[i * 3] = (float) q.x;
                    pts[i * 3 + 1] = (float) q.y;
                    pts[i * 3 + 2] = (float) q.z;
                }
                d.polyline(pts, n, 0.07f, 0.07f, RelativaFx.POSITRON, 0xFFFFFF, 0.7f * a, 0.4f * a);
                d.flare(end.x, end.y, end.z, (float) (0.9f * F), RelativaFx.GAMMA, a);
            }
            d.flare(o.x, o.y, o.z, (float) (0.8f * F), 0xFFFFFF, a);
        }
    }

    // ================================================================== Teori Medan Terpadu

    /** Empat gaya fundamental sebagai empat cincin yang mengorbit lalu merapat jadi satu singularitas putih. */
    static final class ForceRings extends Effect implements Lensing {
        private final AbstractClientPlayer p;
        private final int hit;
        private boolean dead;

        ForceRings(AbstractClientPlayer p, int hit) {
            super(hit + 8);
            this.p = p;
            this.hit = hit;
        }

        private Vec3 center(float pt) {
            return p.getPosition(pt).add(0, p.getBbHeight() * 0.6 + 0.7, 0);
        }

        private float converge(float t) {
            float f = Mth.clamp((t - 30f) / (hit - 30f), 0f, 1f);
            return f * f * (3f - 2f * f);
        }

        @Override
        public boolean tick(ClientLevel level) {
            boolean ok = p.isAlive() && super.tick(level);
            dead |= !ok;
            return ok;
        }

        @Override
        public boolean alive() {
            return !dead;
        }

        @Override
        public float[] lens(float pt) {
            float t = time(pt);
            if (t < hit - 8 || t > hit + 4) {
                return null;
            }
            Vec3 c = center(pt);
            float k = t < hit ? (t - (hit - 8)) / 8f : 1f - (t - hit) / 4f;
            return new float[] {(float) c.x, (float) c.y, (float) c.z, (float) (1.4 * S), 0.3f, 1f, Mth.clamp(k, 0f, 1f)};
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float a = fade(t, life, 8f, 4f);
            float conv = converge(t);
            Vec3 c = center(d.partialTick);
            double radius = (3.2 - 2.9 * conv) * Math.min(1.0, t / 10.0) * S;
            for (int k = 0; k < 4; k++) {
                double tilt = 0.5 + k * 0.35, spin = t * 0.03 * (k % 2 == 0 ? 1 : -1) + k * 1.3;
                double nx = Math.sin(tilt) * Math.cos(spin), ny = Math.cos(tilt), nz = Math.sin(tilt) * Math.sin(spin);
                double rr = radius * (1.0 + 0.08 * k);
                int col = RelativaFx.FORCES[k];
                d.ring(c.x, c.y, c.z, nx, ny, nz, rr, 0.06 * F * 1.3, col, 0.8f * a, 0f, null);
                double[] e = new double[6];
                Draw.plane(nx, ny, nz, e);
                switch (k) {
                    case 0 -> {   // gravitasi: lekukan-lekukan di sepanjang cincin
                        for (int i = 0; i < 8; i++) {
                            double ang = i * Math.PI / 4.0 + t * 0.05;
                            Vec3 q = on(c, e, rr, ang);
                            d.glow(q.x, q.y, q.z, (float) (0.14f * F * 1.3), col, a);
                        }
                    }
                    case 1 -> {   // elektromagnet: listrik yang berderak mengikuti cincin
                        RandomSource g = RandomSource.create((long) (t / 2f) * 977L + 3L);
                        int n = 60;
                        float[] pts = new float[n * 3];
                        for (int i = 0; i < n; i++) {
                            double ang = Math.PI * 2.0 * i / (n - 1);
                            Vec3 q = on(c, e, rr + (g.nextDouble() - 0.5) * 0.25 * S, ang);
                            pts[i * 3] = (float) q.x;
                            pts[i * 3 + 1] = (float) q.y;
                            pts[i * 3 + 2] = (float) q.z;
                        }
                        d.polyline(pts, n, 0.07f, 0.07f, col, 0xFFFFFF, a, a);
                    }
                    case 2 -> {   // gaya kuat: tiga kuark (merah, hijau, biru) diikat pegas gluon
                        int[] quark = {0xFF3030, 0x30FF50, 0x3060FF};
                        Vec3[] q = new Vec3[3];
                        for (int i = 0; i < 3; i++) {
                            q[i] = on(c, e, rr, t * 0.08 + i * Math.PI * 2.0 / 3.0);
                            d.flare(q[i].x, q[i].y, q[i].z, (float) (0.22f * F * 1.3), quark[i], a);
                        }
                        int n = 18;
                        float[] pts = new float[n * 3];
                        for (int i = 0; i < 3; i++) {
                            Vec3 s = q[i], en = q[(i + 1) % 3];
                            for (int j = 0; j < n; j++) {
                                double f = j / (double) (n - 1);
                                Vec3 m = s.lerp(en, f);
                                Vec3 off = m.subtract(c).normalize().scale(Math.sin(f * Math.PI * 8.0) * 0.12 * F);
                                pts[j * 3] = (float) (m.x + off.x);
                                pts[j * 3 + 1] = (float) (m.y + off.y);
                                pts[j * 3 + 2] = (float) (m.z + off.z);
                            }
                            d.polyline(pts, n, 0.06f, 0.06f, 0xFFD040, 0xFFFFFF, 0.8f * a, 0.8f * a);
                        }
                    }
                    default -> {   // gaya lemah: boson W & Z yang muncul-hilang
                        for (int i = 0; i < 4; i++) {
                            float pop = (float) Math.max(0.0, Math.sin(t * 0.4 + i * 1.7));
                            Vec3 q = on(c, e, rr, i * Math.PI / 2.0 + t * 0.02);
                            d.flare(q.x, q.y, q.z, (float) (0.2f * pop * F * 1.3), col, a * pop);
                        }
                    }
                }
            }
            if (conv > 0.6f) {
                float s = (conv - 0.6f) / 0.4f;
                d.flare(c.x, c.y, c.z, (float) ((0.3f + 0.9f * s) * F * 1.4), 0xFFFFFF, a * s);
            }
        }

        private static Vec3 on(Vec3 c, double[] e, double r, double ang) {
            double cs = Math.cos(ang), sn = Math.sin(ang);
            return new Vec3(c.x + (e[0] * cs + e[3] * sn) * r, c.y + (e[1] * cs + e[4] * sn) * r, c.z + (e[2] * cs + e[5] * sn) * r);
        }
    }

    // ================================================================== Kondensat Bose-Einstein

    /** Puncak kondensat berwarna palsu (gambar distribusi kecepatan terkenal): puncak sempit di atas awan termal lebar. */
    static final class BecSpike extends Effect {
        private static final int[] PALETTE = {0x2040FF, 0x20E0FF, 0x40FF60, 0xFFF040, 0xFF4020, 0xFFFFFF};
        private final Vec3 c;

        BecSpike(Vec3 c, int life) {
            super(life);
            this.c = c;
        }

        private static int color(double u) {
            u = Mth.clamp(u, 0.0, 1.0) * (PALETTE.length - 1);
            int i = Math.min(PALETTE.length - 2, (int) Math.floor(u));
            return Draw.mix(PALETTE[i], PALETTE[i + 1], u - i);
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float a = fade(t, life, 2f, 16f);
            double hMax = 2.4 * S * Math.min(1.0, t / 10.0);
            if (hMax <= 0.01) {
                return;
            }
            int rings = 14, segs = 36;
            double reach = 2.6 * S, s2 = S * S;
            for (int i = 0; i < rings; i++) {
                double r0 = reach * i / rings, r1 = reach * (i + 1) / rings;
                double h0 = hMax * (Math.exp(-r0 * r0 / (0.12 * s2)) + 0.22 * Math.exp(-r0 * r0 / (1.6 * s2)));
                double h1 = hMax * (Math.exp(-r1 * r1 / (0.12 * s2)) + 0.22 * Math.exp(-r1 * r1 / (1.6 * s2)));
                int c0 = color(h0 / (hMax * 1.22)), c1 = color(h1 / (hMax * 1.22));
                float a0 = a * 0.75f * (1f - (float) i / rings), a1 = a * 0.75f * (1f - (float) (i + 1) / rings);
                for (int j = 0; j < segs; j++) {
                    double f0 = Math.PI * 2.0 * j / segs, f1 = Math.PI * 2.0 * (j + 1) / segs;
                    d.quad4(c.x + Math.cos(f0) * r0, c.y + 0.05 + h0, c.z + Math.sin(f0) * r0,
                            c.x + Math.cos(f1) * r0, c.y + 0.05 + h0, c.z + Math.sin(f1) * r0,
                            c.x + Math.cos(f1) * r1, c.y + 0.05 + h1, c.z + Math.sin(f1) * r1,
                            c.x + Math.cos(f0) * r1, c.y + 0.05 + h1, c.z + Math.sin(f0) * r1,
                            c0, c0, c1, c1, a0, a0, a1, a1);
                }
            }
            d.flare(c.x, c.y + 0.05 + hMax * 1.22, c.z, (float) (0.35f * F * 1.4), 0xFFFFFF, a);
        }
    }

    /** Atom-atom yang melambat (didinginkan), lalu semuanya merapat jadi satu gumpalan (satu gelombang raksasa). */
    static final class Atoms extends Effect {
        private static final int N = 90;
        private final Vec3 c;
        private final int hit;
        private final double[] x = new double[N], y = new double[N], z = new double[N], vx = new double[N], vy = new double[N],
                vz = new double[N], px = new double[N], py = new double[N], pz = new double[N];

        Atoms(Vec3 c, int hit, int life) {
            super(life);
            this.c = c;
            this.hit = hit;
            RandomSource r = Vfx.random();
            for (int i = 0; i < N; i++) {
                Vec3 o = ShazamFx.randomDir(r).scale((1.0 + r.nextDouble() * 6.0) * S);
                x[i] = px[i] = c.x + o.x;
                y[i] = py[i] = c.y + 0.6 + Math.abs(o.y) * 0.5;
                z[i] = pz[i] = c.z + o.z;
                Vec3 v = ShazamFx.randomDir(r).scale(0.25 * S);
                vx[i] = v.x;
                vy[i] = v.y * 0.4;
                vz[i] = v.z;
            }
        }

        @Override
        public boolean tick(ClientLevel level) {
            for (int i = 0; i < N; i++) {
                px[i] = x[i];
                py[i] = y[i];
                pz[i] = z[i];
                if (age < hit) {   // didinginkan: gerak termalnya melambat
                    vx[i] *= 0.86;
                    vy[i] *= 0.86;
                    vz[i] *= 0.86;
                    x[i] += vx[i];
                    y[i] += vy[i];
                    z[i] += vz[i];
                } else {   // kondensasi: semuanya jadi satu
                    x[i] += (c.x - x[i]) * 0.22;
                    y[i] += (c.y + 1.0 - y[i]) * 0.22;
                    z[i] += (c.z - z[i]) * 0.22;
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float pt = d.partialTick;
            float a = fade(time, life, 2f, 6f);
            for (int i = 0; i < N; i++) {
                double qx = px[i] + (x[i] - px[i]) * pt, qy = py[i] + (y[i] - py[i]) * pt, qz = pz[i] + (z[i] - pz[i]) * pt;
                d.glow(qx, qy, qz, (float) (0.12f * F), RelativaFx.COLD, a);
                d.glow(qx, qy, qz, (float) (0.05f * F), 0xFFFFFF, a);
            }
            if (time > hit) {
                float k = Mth.clamp((time - hit) / 6f, 0f, 1f);
                d.flare(c.x, c.y + 1.0, c.z, (float) ((0.4f + 1.2f * k) * S), RelativaFx.COLD, a * k);
            }
        }
    }

    /** Kulit es tipis di sekeliling makhluk yang membeku di kondensat. */
    static final class IceShell extends Effect {
        private final Entity e;

        IceShell(Entity e, int life) {
            super(life);
            this.e = e;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return e.isAlive() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 3f, 14f);
            Vec3 c = e.getPosition(d.partialTick).add(0, e.getBbHeight() * 0.5, 0);
            double r = Math.max(e.getBbWidth(), e.getBbHeight()) * 0.62;
            d.shell(c.x, c.y, c.z, r, RelativaFx.COLD, 0.55f * a, 2.2, 1.0);
            for (int k = 0; k < 5; k++) {
                double ang = k * 1.256 + time * 0.02;
                d.glint(c.x + Math.cos(ang) * r * 0.8, c.y + Math.sin(ang * 2.0) * r * 0.5, c.z + Math.sin(ang) * r * 0.8, 0.12f,
                        time * 0.05f, 0xFFFFFF, a);
            }
        }

        @Override
        public void renderSoft(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 3f, 14f);
            Vec3 c = e.getPosition(d.partialTick).add(0, e.getBbHeight() * 0.5, 0);
            double r = Math.max(e.getBbWidth(), e.getBbHeight()) * 0.55;
            d.puff(c.x, c.y, c.z, (float) r, 0xE8F8FF, 0xA8D8F0, 0.2f * a);
        }
    }

    // ================================================================== Cahaya

    /** Satu foton: paket gelombang kecil (gelombang) dengan kepala bercahaya (partikel), dualisme gelombang-partikel. */
    static final class PhotonPacket extends Effect {
        private final Vec3 a, b;
        private final int travel;

        PhotonPacket(Vec3 a, Vec3 b, int travel) {
            super(Math.max(1, travel) + 6);
            this.a = a;
            this.b = b;
            this.travel = Math.max(1, travel);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            if (time > travel + 0.5f) {
                float f = (time - travel) / 6f;
                d.flare(b.x, b.y, b.z, (float) ((0.5f * (1f - f) + 0.1f) * F), RelativaFx.PHOTON, 1f - f);
                return;
            }
            Vec3 dir = b.subtract(a);
            double len = Math.max(0.1, dir.length());
            dir = dir.scale(1.0 / len);
            double head = len * Mth.clamp(time / travel, 0f, 1f);
            Vec3 tc = toCam(d, a.add(dir.scale(head)));
            Vec3 side = dir.cross(tc);
            side = side.lengthSqr() < 1.0E-6 ? new Vec3(0, 1, 0) : side.normalize();
            int n = 22;
            float[] pts = new float[n * 3];
            for (int i = 0; i < n; i++) {
                double s = head - 1.6 * i / (n - 1);
                double env = Math.exp(-Math.pow((head - s - 0.5) / 0.45, 2.0));
                Vec3 q = a.add(dir.scale(Math.max(0.0, s))).add(side.scale(Math.sin(s * 14.0) * 0.12 * F * env));
                pts[i * 3] = (float) q.x;
                pts[i * 3 + 1] = (float) q.y;
                pts[i * 3 + 2] = (float) q.z;
            }
            d.polyline(pts, n, 0.075f, 0.03f, RelativaFx.PHOTON, 0xFFFFFF, 1f, 0.2f);
            Vec3 h = a.add(dir.scale(head));
            d.flare(h.x, h.y, h.z, (float) (0.2f * F), RelativaFx.PHOTON, 1f);
        }
    }

    /** Laser: sinar koheren tipis yang menyilaukan dengan gelombang sefase di sekelilingnya, ikut arah pandang. */
    static final class LaserBeam extends Effect {
        private final AbstractClientPlayer p;
        private Vec3 end, endO;

        LaserBeam(AbstractClientPlayer p, int life) {
            super(life);
            this.p = p;
            end = endO = trace();
        }

        private Vec3 trace() {
            Vec3 eye = p.getEyePosition(1f).add(0, -0.2, 0);
            return HdKit.rayEnd((ClientLevel) p.level(), p, eye, p.getViewVector(1f), 40.0 * S);
        }

        @Override
        public boolean tick(ClientLevel level) {
            endO = end;
            end = trace();
            RandomSource r = level.random;
            for (int i = 0; i < 6; i++) {
                Vec3 v = ShazamFx.randomDir(r).scale(0.35);
                Vfx.spark(end.x, end.y, end.z, v.x, Math.abs(v.y) + 0.1, v.z, i == 0 ? 0xFFFFFF : RelativaFx.LASER, 0.06f, 9,
                        end.y - 1.5);
            }
            if (age % 2 == 0) {
                Vfx.smoke(end.x, end.y, end.z, 0, 0.04, 0, 0x403030, 0.7f, 22);
            }
            return p.isAlive() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 1f, 4f);
            Vec3 h = ShazamPoses.handPos(p, true, d.partialTick);
            Vec3 e = endO.lerp(end, d.partialTick);
            d.beam(h.x, h.y, h.z, e.x, e.y, e.z, 0.64f, RelativaFx.LASER, 0xFFFFFF, a, a);
            Vec3 dir = e.subtract(h);
            double len = dir.length();
            if (len > 0.5) {
                dir = dir.scale(1.0 / len);
                Vec3 side = dir.cross(UP);
                side = side.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : side.normalize();
                Vec3 up = side.cross(dir);
                int n = Math.min(240, (int) (len * 4) + 2);
                float[] pts = new float[n * 3];
                for (int i = 0; i < n; i++) {
                    double s = len * i / (n - 1), ph = s * 12.0 - time * 2.0;
                    Vec3 q = h.add(dir.scale(s)).add(up.scale(Math.sin(ph) * 0.16));
                    pts[i * 3] = (float) q.x;
                    pts[i * 3 + 1] = (float) q.y;
                    pts[i * 3 + 2] = (float) q.z;
                }
                d.polyline(pts, n, 0.045f, 0.045f, RelativaFx.LASER, 0xFFE0E0, 0.6f * a, 0.6f * a);
            }
            d.flare(h.x, h.y, h.z, 0.6f, RelativaFx.LASER, a);
            d.flare(e.x, e.y, e.z, 1.4f, RelativaFx.LASER, a);
        }
    }

    // ================================================================== Gelombang Gravitasi & Gerak Brown

    /** Riak ruang-waktu berpolarisasi "+": kisi meregang ke satu sumbu sambil memampat ke sumbu lain, cincin partikel uji. */
    static final class GravWave extends Effect {
        private final Vec3 c;

        GravWave(Vec3 c, int life) {
            super(life);
            this.c = c;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float a = fade(t, life, 1f, 12f);
            double front = 0.45 * t * S;
            int n = 33, lines = 16;
            double reach = 9.0 * S, step = reach / lines;
            float[] xyz = new float[n * 3];
            float[] w = new float[n];
            float[] al = new float[n];
            for (int dir = 0; dir < 2; dir++) {
                for (int i = -lines; i <= lines; i++) {
                    double off = i * step;
                    for (int j = 0; j < n; j++) {
                        double s = -reach + 2.0 * reach * j / (n - 1);
                        double x = dir == 0 ? s : off, z = dir == 0 ? off : s;
                        double r = Math.sqrt(x * x + z * z);
                        double env = Math.exp(-Math.pow(r - front, 2.0) / (2.0 * 1.2 * 1.2 * S * S));
                        double h = 0.35 * env * Math.cos(2.4 * (r - front) / S);
                        xyz[j * 3] = (float) (c.x + x * (1.0 + h * 0.35));
                        xyz[j * 3 + 1] = (float) (c.y + 0.08 + 0.12 * S * env);
                        xyz[j * 3 + 2] = (float) (c.z + z * (1.0 - h * 0.35));
                        double fr = Math.max(0.0, 1.0 - r / reach);
                        al[j] = (float) (a * (0.12 + 0.6 * env) * fr);
                        w[j] = 0.06f;
                    }
                    d.strip(xyz, n, w, 1f, al, 1f, RelativaFx.GWAVE);
                }
            }
            double hp = 0.35 * Math.exp(-t / 20.0) * Math.cos(t * 0.8);
            for (int k = 0; k < 24; k++) {   // cincin partikel uji (diagram detektor gelombang gravitasi)
                double ang = k * Math.PI / 12.0;
                d.flare(c.x + 3.0 * S * Math.cos(ang) * (1.0 + hp), c.y + 1.0, c.z + 3.0 * S * Math.sin(ang) * (1.0 - hp),
                        (float) (0.16f * F), RelativaFx.LIGHT, a);
            }
        }
    }

    /** Satu lompatan Gerak Brown: jejak acak bergerigi dari a ke b. */
    static final class BrownPath extends Effect {
        private final float[] pts = new float[8 * 3];

        BrownPath(Vec3 a, Vec3 b, int life) {
            super(life);
            RandomSource r = Vfx.random();
            for (int i = 0; i < 8; i++) {
                double f = i / 7.0;
                Vec3 q = a.lerp(b, f).add(0, 1.0, 0);
                if (i > 0 && i < 7) {
                    q = q.add((r.nextDouble() - 0.5) * 0.9, (r.nextDouble() - 0.5) * 0.7, (r.nextDouble() - 0.5) * 0.9);
                }
                pts[i * 3] = (float) q.x;
                pts[i * 3 + 1] = (float) q.y;
                pts[i * 3 + 2] = (float) q.z;
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float a = fade(time(d.partialTick), life, 1f, 10f);
            d.polyline(pts, 8, 0.1f, 0.06f, RelativaFx.LIGHT, 0xFFFFFF, a, a * 0.6f);
        }
    }
}
