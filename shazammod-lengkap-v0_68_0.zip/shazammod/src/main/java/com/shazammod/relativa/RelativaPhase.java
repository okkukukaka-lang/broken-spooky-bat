package com.shazammod.relativa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;
import com.shazammod.thanos.ThanosSnap;

import net.minecraft.ChatFormatting;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 0.67 Pasif TEROWONGAN KUANTUM (tombol I, nyala / mati, tanpa batas waktu): seluruh atom badan RELATIVA berubah jadi
 * gelombang materi (panjang gelombang de Broglie λ = h/p). Peluang menembus penghalang nggak pernah nol, dan badan yang
 * "tersebar" jadi fungsi gelombang membiarkan segalanya lewat:
 *
 *   serangan apa pun (pukulan, ledakan, api, jatuh, sihir, sinar)   damage dibatalkan, tanpa dorongan / knockback
 *   proyektil (panah, trisula, bola api, ramuan, peluru rival)      menembus badan dan terus melaju (ProjectileImpactEvent)
 *   makhluk & pemain lain                                           menembus badan, nggak mendorongnya (noPhysics di sela tick)
 *   api, beku, tenggelam, efek buruk                                padam / dibuang tiap tick
 *
 * Tetap bisa menyerang, memakai skill, dan memungut barang. Yang tetap kena: /kill dan jatuh ke void (supaya nggak terjebak
 * selamanya); Jentikan Thanos sejak 0.68 nggak menyasar RELATIVA sama sekali (juara dewa, ThanosSnap.isGod). Padam
 * otomatis saat kembali jadi manusia.
 */
public final class RelativaPhase {
    private RelativaPhase() {}

    private static final int TOGGLE_GAP = 10;
    private static final int PASS_FX_GAP = 4;
    private static final Map<UUID, Long> LAST_PASS = new HashMap<>();

    public static boolean phasing(Player p) {
        RelativaData d = RelativaAbilities.data(p);
        return d.transformed && d.phase;
    }

    // ---------------------------------------------------------------- tombol I

    public static void toggle(ServerPlayer p, RelativaData d) {
        if (!d.transformed || d.morphing > 0 || !p.isAlive()) {
            return;
        }
        long now = p.level().getGameTime();
        if (d.lastPhaseToggle != 0L && now >= d.lastPhaseToggle && now - d.lastPhaseToggle < TOGGLE_GAP) {
            return;
        }
        d.lastPhaseToggle = now;
        d.phase = !d.phase;
        if (d.phase) {
            apply(p);
            ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_PHASE_ON);
            p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.RELATIVA_PHASE_ON.get(),
                    SoundSource.PLAYERS, 1.8f, 1f);
            RelativaAbilities.msg(p, "phase_on", ChatFormatting.LIGHT_PURPLE);
        } else {
            remove(p);
            ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_PHASE_OFF);
            p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.RELATIVA_PHASE_OFF.get(),
                    SoundSource.PLAYERS, 1.6f, 1f);
            RelativaAbilities.msg(p, "phase_off", ChatFormatting.GRAY);
        }
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    /** Ledakan & pukulan nggak lagi mendorong badan (gelombang nggak punya titik untuk didorong). */
    static void apply(Player p) {
        AttributeModifier.Operation add = AttributeModifier.Operation.ADD_VALUE;
        RelativaPowers.set(p, Attributes.KNOCKBACK_RESISTANCE, "phase_knockback", 1.0, add);
        RelativaPowers.set(p, Attributes.EXPLOSION_KNOCKBACK_RESISTANCE, "phase_blast", 1.0, add);
    }

    static void remove(Player p) {
        RelativaPowers.clear(p, Attributes.KNOCKBACK_RESISTANCE, "phase_knockback");
        RelativaPowers.clear(p, Attributes.EXPLOSION_KNOCKBACK_RESISTANCE, "phase_blast");
    }

    /** Kembali jadi manusia / mati: pasifnya padam. */
    static void off(ServerPlayer p, RelativaData d) {
        if (d.phase) {
            d.phase = false;
            remove(p);
        }
        LAST_PASS.remove(p.getUUID());
    }

    // ---------------------------------------------------------------- tiap tick

    public static void tick(ServerPlayer p, RelativaData d) {
        if (!d.phase || !d.transformed) {
            return;
        }
        p.clearFire();
        p.setTicksFrozen(0);
        if (p.getAirSupply() < p.getMaxAirSupply()) {
            p.setAirSupply(p.getMaxAirSupply());
        }
        if (p.tickCount % 5 == 0) {
            List<MobEffectInstance> bad = new ArrayList<>();
            for (MobEffectInstance effect : p.getActiveEffects()) {
                if (effect.getEffect().value().getCategory() == MobEffectCategory.HARMFUL) {
                    bad.add(effect);
                }
            }
            for (MobEffectInstance effect : bad) {
                p.removeEffect(effect.getEffect());
            }
        }
    }

    /**
     * Client, sesudah tick pemain: makhluk di client mendorong pemain lokal di sela tick-nya, jadi selama menembus
     * noPhysics dipasang. Player.tick meresetnya ke isSpectator() sebelum bergerak, jadi tabrakan blok tetap normal.
     */
    public static void afterTick(Player p, boolean phasing) {
        if (phasing && !p.isSpectator()) {
            p.noPhysics = true;
        }
    }

    /**
     * Server, awal tiap tick server (sebelum dunia & makhluk di-tick): makhluk nggak bisa mendorong badan yang menembus.
     * Player.tick sendiri meresetnya lagi, jadi paket gerak, portal, pelat tekan & tabrakan blok di server tetap normal.
     */
    public static void beforeWorldTick(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!p.isSpectator() && phasing(p)) {
                p.noPhysics = true;
            }
        }
    }

    // ---------------------------------------------------------------- serangan & benda menembus

    /** Dari RelativaAbilities.guard. true = damage dibatalkan (menembus). */
    static boolean guard(LivingIncomingDamageEvent event, ServerPlayer p, RelativaData d) {
        DamageSource source = event.getSource();
        if (!d.transformed || !d.phase || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || ThanosSnap.isSnap(source)) {
            return false;
        }
        event.setCanceled(true);
        Entity from = source.getDirectEntity() != null ? source.getDirectEntity() : source.getEntity();
        if (from != null && from != p) {
            pass(p, from.position().add(0, from.getBbHeight() * 0.5, 0));
        } else if (source.getSourcePosition() != null) {
            pass(p, source.getSourcePosition());
        }
        return true;
    }

    /** Proyektil menembus badan dan terus melaju (tumbukannya diabaikan). */
    public static void onImpact(ProjectileImpactEvent event) {
        Projectile pr = event.getProjectile();
        if (pr.level().isClientSide() || !(event.getRayTraceResult() instanceof EntityHitResult hit)
                || !(hit.getEntity() instanceof ServerPlayer p) || !phasing(p)) {
            return;
        }
        event.setCanceled(true);
        pass(p, hit.getLocation());
    }

    /** Efek "lewat" di titik masuknya (paket gelombang menembus badan), dibatasi supaya nggak berisik. */
    private static void pass(ServerPlayer p, Vec3 from) {
        long now = p.level().getGameTime();
        Long last = LAST_PASS.get(p.getUUID());
        if (last != null && now >= last && now - last < PASS_FX_GAP) {
            return;
        }
        LAST_PASS.put(p.getUUID(), now);
        Vec3 c = RelativaAbilities.chest(p);
        Vec3 dir = from.subtract(c);
        Vec3 at = dir.lengthSqr() < 1.0E-4 ? c : c.add(dir.normalize().scale(0.45));
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_PHASE_PASS, at);
        p.serverLevel().playSound(null, at.x, at.y, at.z, ShazamSounds.RELATIVA_PHASE_PASS.get(), SoundSource.PLAYERS, 0.9f,
                0.9f + p.getRandom().nextFloat() * 0.25f);
    }
}
