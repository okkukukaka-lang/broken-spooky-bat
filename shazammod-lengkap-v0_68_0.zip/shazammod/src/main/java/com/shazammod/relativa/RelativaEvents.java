package com.shazammod.relativa;

import java.util.Locale;

import com.shazammod.ShazamMod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.ServerChatEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** 0.66 Event RELATIVA di server. */
@EventBusSubscriber(modid = ShazamMod.MODID)
public final class RelativaEvents {
    private RelativaEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player instanceof ServerPlayer sp) {
            RelativaAbilities.tick(sp);
        } else if (player.level().isClientSide()) {   // 0.67 makhluk di client mendorong pemain lokal di sela tick-nya
            RelativaPhase.afterTick(player, (RelativaClientState.flags(player.getId()) & RelativaNetwork.FLAG_PHASE) != 0);
        }
    }

    /** 0.67 Terowongan Kuantum: sebelum dunia di-tick, badan yang sedang menembus nggak bisa didorong makhluk. */
    @SubscribeEvent
    public static void onServerTickPre(ServerTickEvent.Pre event) {
        RelativaPhase.beforeWorldTick(event.getServer());
    }

    /** 0.67 Kecepatan Cahaya: pemegang waktu keluar / mati di tengah jalan, waktu berjalan lagi. */
    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        RelativaLight.serverTick(event.getServer());
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        RelativaLight.clear(event.getServer());   // dunia dicairkan dulu
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            RelativaAbilities.onLogin(player);
            RelativaLight.onLogin(player);   // 0.67 masuk di tengah waktu yang berhenti: ikut membeku
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            RelativaAbilities.onRespawn(player);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            RelativaAbilities.onLogout(player);
        }
    }

    /** Pemain lain masuk jangkauan pandang: kirim status RELATIVA-nya (atom di dada & medan). */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer relativa && event.getEntity() instanceof ServerPlayer viewer
                && RelativaAbilities.active(relativa)) {
            RelativaNetwork.sendStateTo(relativa, viewer);
        }
    }

    /** 0.67 Selama waktu berhenti cuma pukulan pemegang waktu yang dihitung (lebih awal dari yang lain). */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onIncomingEarly(LivingIncomingDamageEvent event) {
        RelativaLight.intercept(event);
    }

    /** Tinju Foton, Superposisi, Terowongan Kuantum, Makalah IV (ledakan). */
    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        RelativaAbilities.guard(event);
    }

    /** 0.67 Paling akhir: damage final ke makhluk yang membeku ditabung (dilepas saat waktu berjalan lagi). */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onIncomingLast(LivingIncomingDamageEvent event) {
        RelativaLight.onIncomingLast(event);
    }

    /** 0.67 Terowongan Kuantum: proyektil menembus badan dan terus melaju. */
    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        RelativaPhase.onImpact(event);
    }

    /** Keterikatan Kuantum: damage yang benar-benar masuk ke satu makhluk mengalir ke pasangannya. */
    @SubscribeEvent
    public static void onDamagePost(LivingDamageEvent.Post event) {
        RelativaSkills.onDamagePost(event);
    }

    /** 0.68 Serangan mematikan saat berwujud RELATIVA: terlempar balik jadi manusia, bukan mati (sama seperti juara lain). */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onDamagePre(LivingDamageEvent.Pre event) {
        RelativaAbilities.onDamagePre(event);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        RelativaAbilities.onDeath(event);
    }

    /** Ketik "relativa" atau "E=mc²" di chat = sama dengan tombol Y. */
    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        String word = event.getRawText().toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
        if (word.equals("relativa") || word.equals("emc")) {
            ServerPlayer player = event.getPlayer();
            player.server.execute(() -> RelativaAbilities.toggleTransform(player));
        }
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        RelativaCommands.register(event.getDispatcher());
    }
}
