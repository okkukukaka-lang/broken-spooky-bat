package com.shazammod;

import java.util.UUID;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;

/**
 * Slow motion sinematik saat berubah jadi Shazam: dunia diperlambat (seperti /tick rate) waktu petir turun
 * dari langit dan selama kostum terbentuk, lalu kembali normal pelan-pelan. Karena memperlambat seluruh
 * dunia, slow motion cuma jalan kalau pemain sendirian di server (pemain lain nggak ikut melambat).
 */
public final class ShazamSlowMo {
    private ShazamSlowMo() {}

    // ======= Angka yang gampang diutak-atik (tick rate normal = 20) =======
    public static final boolean ENABLED = true;
    private static final float DESCENT_RATE = 5f;       // 4x lebih lambat: petir turun 10 tick = 2 detik
    private static final float TRANSFORM_RATE = 10f;    // 2x lebih lambat selama kostum terbentuk
    private static final float[] RAMP = {13f, 16f, 18f};
    private static final int RAMP_HOLD = 2;
    private static final int SAFETY_TICKS = 10;

    private static final SlowMoTimeline TIMELINE = new SlowMoTimeline(DESCENT_RATE, TRANSFORM_RATE, RAMP, RAMP_HOLD);
    private static UUID owner;

    /** Petir mulai turun. */
    public static void begin(ServerPlayer player) {
        MinecraftServer server = player.server;
        if (!ENABLED || server.getPlayerCount() > 1) {
            return;
        }
        owner = player.getUUID();
        apply(server, TIMELINE.begin(server.tickRateManager().tickrate(), ShazamAnim.BOLT_DESCENT, SAFETY_TICKS));
    }

    /** Petir mengenai: lanjut lambat sampai kostum selesai terbentuk. */
    public static void strike(ServerPlayer player) {
        if (player.getUUID().equals(owner)) {
            apply(player.server, TIMELINE.strike(ShazamAnim.TRANSFORM_SLOWMO));
        }
    }

    public static void tick(MinecraftServer server) {
        if (TIMELINE.active()) {
            apply(server, TIMELINE.tick(owner != null && server.getPlayerList().getPlayer(owner) != null));
        }
    }

    public static void end(MinecraftServer server) {
        apply(server, TIMELINE.end());
    }

    private static void apply(MinecraftServer server, float rate) {
        if (!Float.isNaN(rate)) {
            server.tickRateManager().setTickRate(rate);
        }
        if (!TIMELINE.active()) {
            owner = null;
        }
    }

    /** Nada suara ikut turun saat dunia diperlambat. */
    public static float pitch(MinecraftServer server, float pitch) {
        float rate = server == null ? 20f : server.tickRateManager().tickrate();
        return pitch * Mth.clamp((float) Math.sqrt(rate / 20f), 0.5f, 1f);
    }
}
