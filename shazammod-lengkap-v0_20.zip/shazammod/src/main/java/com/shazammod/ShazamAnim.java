package com.shazammod;

/**
 * Animasi yang dikirim server ke semua pemain di sekitar.
 * Urutannya dipakai sebagai id di jaringan, jadi tambah yang baru di paling bawah.
 */
public enum ShazamAnim {
    TRANSFORM,
    REVERT,
    SOLOMON_SIGHT,
    HERCULES_CLAP,
    ATLAS_GROUND,
    ATLAS_DIVE,
    ATLAS_IMPACT,
    ZEUS_CALL,
    ACHILLES_ROAR,
    MERCURY_BLITZ,
    LAUNCH,
    LAND_SOFT,
    LAND_HERO,
    CRASH,
    SONIC_BOOM,
    ROLL_LEFT,
    ROLL_RIGHT,
    SUMMON,      // memanggil enam dewa sebelum petir transformasi
    ZEUS_RAGE,   // amarah Zeus: mata menyala putih
    HOOD_UP,     // tangan meraih ke belakang kepala lalu menarik hood ke depan
    HOOD_DOWN,   // tangan memegang tepi hood di dahi lalu mendorongnya ke belakang
    MERCURY_ON,  // Mode Kilat Mercury menyala: kuda-kuda, listrik meledak dari badan
    MERCURY_OFF, // Mode Kilat Mercury mati
    MERCURY_JAB, // pukulan-pukulan secepat kilat (x, y, z = titik kena)
    MERCURY_CROSS,
    MERCURY_HOOK,
    MERCURY_KICK,
    KNOCKOUT;    // serangan mematikan saat jadi Shazam: badan terhentak, kekuatan tercabut dari dada, balik jadi manusia

    // Waktu (tick) yang dipakai bersama oleh server dan client supaya efek pas dengan gerakan
    public static final int SUMMON_TICKS = 88;      // enam dewa datang satu per satu (lihat client.fx.GodShow), lalu kepalan diangkat
    public static final int TRANSFORM_WINDUP = 8;   // angkat kepalan ke langit
    public static final int BOLT_DESCENT = 10;      // petir turun pelan dari langit ke kepalan (slow motion)
    public static final int TRANSFORM_STRIKE = TRANSFORM_WINDUP + BOLT_DESCENT;   // tick klip TRANSFORM saat petir mengenai
    public static final int TRANSFORM_SLOWMO = 28;  // slow motion berlanjut selama kostum terbentuk (sampai hood terpasang)
    public static final int HOOD_GRAB = 6;          // tangan memegang tepi hood
    public static final int HOOD_MOVE = 10;         // hood ditarik/didorong selama ini
    public static final int HOOD_TICKS = 24;        // panjang animasi hood
    public static final int REVERT_WINDUP = 6;
    public static final int CAST_WINDUP = 5;        // Solomon, Hercules, Atlas (di tanah), Zeus
    public static final int ROAR_WINDUP = 4;        // Achilles
    public static final int ACHILLES_TICKS = 120;   // lama kulit tak tertembus
    public static final int SOLOMON_TICKS = 200;    // lama musuh "terbaca"
    public static final int BLITZ_TICKS = 6;        // lama terjangan Mercury
    public static final int RAGE_WINDUP = 9;        // Zeus Rage: membungkuk, lalu meraung ke langit
    public static final int RAGE_TICKS = 240;       // lama amarah Zeus (12 detik)
    public static final int KNOCKOUT_BURST = 3;     // terlempar balik: kekuatan tercabut keluar dari dada (lengan terentang)

    public static ShazamAnim byId(int id) {
        ShazamAnim[] values = values();
        return id >= 0 && id < values.length ? values[id] : null;
    }
}
