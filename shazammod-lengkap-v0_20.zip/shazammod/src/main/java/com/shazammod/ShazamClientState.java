package com.shazammod;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Salinan data Shazam di sisi client. Sengaja nggak memakai class khusus client,
 * supaya aman dimuat juga di server dedicated.
 */
public final class ShazamClientState {
    private ShazamClientState() {}

    // HUD pemain sendiri
    public static boolean unlocked;
    public static boolean transformed;
    public static boolean storm;
    public static float energy = ShazamPowers.MAX_ENERGY;
    private static List<Integer> cooldowns = List.of();

    // Status semua pemain yang kelihatan, dan antrean animasi yang baru datang
    private static final Map<Integer, ShazamStatePayload> STATES = new HashMap<>();
    private static final ArrayDeque<ShazamAnimPayload> ANIMS = new ArrayDeque<>();

    public static void update(ShazamSyncPayload payload) {
        unlocked = payload.unlocked();
        transformed = payload.transformed();
        storm = payload.storm();
        energy = payload.energy();
        cooldowns = payload.cooldowns();
    }

    /** Sisa cooldown skill ke-index, dalam tick. */
    public static int cooldown(int index) {
        return index < cooldowns.size() ? cooldowns.get(index) : 0;
    }

    /** Sisa waktu pulih (tick) sesudah terlempar balik jadi manusia; dikirim sesudah cooldown semua skill. */
    public static int recovery() {
        return cooldown(ShazamSkills.Skill.values().length);
    }

    public static void onState(ShazamStatePayload payload) {
        STATES.put(payload.entityId(), payload);
    }

    public static boolean isTransformed(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.transformed();
    }

    public static boolean isRaging(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.rage();
    }

    public static boolean isHoodUp(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.hood();
    }

    /** Mode Kilat Mercury sedang menyala. */
    public static boolean isMercury(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.mercury();
    }

    public static boolean isFlying(int entityId) {
        ShazamStatePayload state = STATES.get(entityId);
        return state != null && state.flying();
    }

    public static void onAnim(ShazamAnimPayload payload) {
        if (ANIMS.size() < 256) {
            ANIMS.add(payload);
        }
    }

    public static ShazamAnimPayload pollAnim() {
        return ANIMS.poll();
    }

    public static void reset() {
        unlocked = false;
        transformed = false;
        storm = false;
        energy = ShazamPowers.MAX_ENERGY;
        cooldowns = List.of();
        STATES.clear();
        ANIMS.clear();
    }
}
