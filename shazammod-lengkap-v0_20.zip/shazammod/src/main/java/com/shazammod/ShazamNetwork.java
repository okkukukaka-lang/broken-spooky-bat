package com.shazammod;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Jalur komunikasi client <-> server: tombol, data HUD, status Shazam, dan animasi. */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ShazamNetwork {
    private ShazamNetwork() {}

    public static final int ACTION_TRANSFORM = 0; // 1-6 = skill S-H-A-Z-A-M
    public static final int ACTION_HOOD = 20;   // 1-7 dipakai skill

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("6");   // naikkan tiap format paket berubah
        registrar.playToServer(ShazamActionPayload.TYPE, ShazamActionPayload.STREAM_CODEC, ShazamNetwork::handleAction);
        registrar.playToServer(ShazamFlightPayload.TYPE, ShazamFlightPayload.STREAM_CODEC, ShazamNetwork::handleFlight);
        registrar.playToServer(ShazamMercuryPayload.TYPE, ShazamMercuryPayload.STREAM_CODEC, ShazamNetwork::handleMercury);
        registrar.playToClient(ShazamSyncPayload.TYPE, ShazamSyncPayload.STREAM_CODEC, ShazamNetwork::handleSync);
        registrar.playToClient(ShazamStatePayload.TYPE, ShazamStatePayload.STREAM_CODEC, ShazamNetwork::handleState);
        registrar.playToClient(ShazamAnimPayload.TYPE, ShazamAnimPayload.STREAM_CODEC, ShazamNetwork::handleAnim);
    }

    private static void handleAction(ShazamActionPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (!(context.player() instanceof ServerPlayer player)) {
                return;
            }
            ShazamSkills.Skill[] skills = ShazamSkills.Skill.values();
            int action = payload.action();
            if (action == ACTION_TRANSFORM) {
                ShazamPowers.onSayShazam(player);
            } else if (action >= 1 && action <= skills.length) {
                ShazamSkills.use(player, skills[action - 1]);
            } else if (action == ACTION_HOOD) {
                ShazamPowers.toggleHood(player);
            }
        });
    }

    private static void handleFlight(ShazamFlightPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                ShazamFlightServer.handle(player, payload.action(), payload.speed());
            }
        });
    }

    private static void handleMercury(ShazamMercuryPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                ShazamMercury.strike(player, payload.target(), payload.move());
            }
        });
    }

    private static void handleSync(ShazamSyncPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ShazamClientState.update(payload));
    }

    private static void handleState(ShazamStatePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ShazamClientState.onState(payload));
    }

    private static void handleAnim(ShazamAnimPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ShazamClientState.onAnim(payload));
    }

    /** Data HUD (energi, cooldown, waktu pulih) untuk pemain itu sendiri. */
    public static void sync(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        List<Integer> cooldowns = new ArrayList<>();
        for (ShazamSkills.Skill skill : ShazamSkills.Skill.values()) {
            cooldowns.add(ShazamSkills.cooldownTicks(player, skill));
        }
        cooldowns.add(ShazamPowers.recoveryTicks(player));   // paling belakang: waktu pulih sesudah serangan mematikan
        PacketDistributor.sendToPlayer(player, new ShazamSyncPayload(
                data.unlocked(), data.transformed(), ShazamPowers.isInStorm(player), data.energy(), cooldowns));
    }

    /** Status Shazam pemain ini, ke dirinya dan semua yang melihatnya. */
    public static void broadcastState(ServerPlayer player) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, statePayload(player));
    }

    public static void sendStateTo(ServerPlayer target, ServerPlayer viewer) {
        PacketDistributor.sendToPlayer(viewer, statePayload(target));
    }

    private static ShazamStatePayload statePayload(ServerPlayer player) {
        ShazamData data = ShazamPowers.data(player);
        boolean transformed = data.transformed();
        return new ShazamStatePayload(player.getId(), transformed, transformed && player.getAbilities().flying, data.hoodUp(),
                transformed && ShazamSkills.isRageActive(player), transformed && ShazamMercury.isActive(player));
    }

    /** Animasi untuk pemain lain saja (pemain itu sendiri sudah memutarnya duluan di client-nya). */
    public static void playAnimToOthers(ServerPlayer player, ShazamAnim anim) {
        playAnimToOthers(player, anim, player.position());
    }

    public static void playAnimToOthers(ServerPlayer player, ShazamAnim anim, Vec3 pos) {
        PacketDistributor.sendToPlayersTrackingEntity(player, new ShazamAnimPayload(player.getId(), anim.ordinal(),
                (float) pos.x, (float) pos.y, (float) pos.z));
    }

    public static void playAnim(ServerPlayer player, ShazamAnim anim) {
        playAnim(player, anim, player.position());
    }

    public static void playAnim(ServerPlayer player, ShazamAnim anim, Vec3 pos) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player,
                new ShazamAnimPayload(player.getId(), anim.ordinal(), (float) pos.x, (float) pos.y, (float) pos.z));
    }
}
