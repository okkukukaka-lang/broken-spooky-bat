package com.shazammod.guardian;

import com.shazammod.ShazamEntities;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;

/** Enam penjaga, satu untuk tiap huruf S-H-A-Z-A-M. */
public enum GuardianKind {
    SOLOMON("solomon", "Solomon"),
    HERCULES("hercules", "Hercules"),
    ATLAS("atlas", "Atlas"),
    ZEUS("zeus", "Zeus"),
    ACHILLES("achilles", "Achilles"),
    MERCURY("mercury", "Mercury");

    public final String id;
    public final String godName;

    GuardianKind(String id, String godName) {
        this.id = id;
        this.godName = godName;
    }

    public EntityType<? extends Mob> entityType() {
        return switch (this) {
            case SOLOMON -> ShazamEntities.SCHOLAR_ZOMBIE.get();
            case HERCULES -> ShazamEntities.JUNGLE_BRUTE.get();
            case ATLAS -> ShazamEntities.EARTH_GOLEM.get();
            case ZEUS -> ShazamEntities.STORM_STALKER.get();
            case ACHILLES -> ShazamEntities.UNDEAD_GLADIATOR.get();
            case MERCURY -> ShazamEntities.MERCURY_SPIRIT.get();
        };
    }

    public static GuardianKind byId(String id) {
        for (GuardianKind kind : values()) {
            if (kind.id.equals(id)) {
                return kind;
            }
        }
        return null;
    }
}
