package com.shazammod.guardian;

import com.shazammod.ShazamItems;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.PointedDripstoneBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Penjaga Atlas: 60 detik pertama kebal sambil "menahan langit" yang runtuh, lalu zirahnya retak. */
public class EarthGolem extends IronGolem implements ShazamGuardian, Enemy {
    private static final int SKY_PHASE_TICKS = 1200;
    private final GuardianCore core = new GuardianCore(this, BossEvent.BossBarColor.RED,
            ShazamItems.TOTEM_ATLAS, "hint.shazammod.atlas");
    private int skyTicks = SKY_PHASE_TICKS;
    private int rockCooldown = 20;

    public EarthGolem(EntityType<? extends EarthGolem> type, Level level) {
        super(type, level);
        this.xpReward = 50;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return IronGolem.createAttributes()
                .add(Attributes.MAX_HEALTH, 200.0)
                .add(Attributes.ATTACK_DAMAGE, 12.0)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.SCALE, 1.5);
    }

    @Override
    protected void registerGoals() {
        // Ganti AI golem desa: langsung memburu pemain
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0, true));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public GuardianCore core() {
        return core;
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide) {
            core.tick();
            if (!core.isDormant() && this.isAlive()) {
                tickSky();
            }
        }
        super.aiStep();
    }

    private void tickSky() {
        if (skyTicks > 0 && --skyTicks == 0) {
            crackArmor();
        }
        if (--rockCooldown <= 0) {
            rockCooldown = skyTicks > 0 ? 15 : 60;
            dropRock();
        }
    }

    /** Batu runcing jatuh dari 10 blok di atas pemain terdekat. Pecah saat mendarat, nggak menyisakan blok. */
    private void dropRock() {
        Player target = this.level().getNearestPlayer(this.getX(), this.getY(), this.getZ(), 24.0,
                EntitySelector.NO_CREATIVE_OR_SPECTATOR);
        if (target == null) {
            return;
        }
        BlockPos pos = BlockPos.containing(
                target.getX() + (this.getRandom().nextDouble() - 0.5) * 4.0,
                target.getY() + 10.0,
                target.getZ() + (this.getRandom().nextDouble() - 0.5) * 4.0);
        if (!this.level().getBlockState(pos).isAir()) {
            return; // ada atap: jangan sampai menghapus blok
        }
        BlockState rock = Blocks.POINTED_DRIPSTONE.defaultBlockState()
                .setValue(PointedDripstoneBlock.TIP_DIRECTION, Direction.DOWN);
        FallingBlockEntity falling = FallingBlockEntity.fall(this.level(), pos, rock);
        falling.setHurtsEntities(1.0f, 6);
        falling.dropItem = false;
    }

    private void crackArmor() {
        this.playSound(SoundEvents.IRON_GOLEM_DAMAGE, 2f, 0.5f);
        ((ServerLevel) this.level()).sendParticles(
                new BlockParticleOption(ParticleTypes.BLOCK, Blocks.RED_SANDSTONE.defaultBlockState()),
                this.getX(), this.getY() + this.getBbHeight() * 0.5, this.getZ(), 80, 1.0, 1.0, 1.0, 0.2);
        Component message = Component.translatable("message.shazammod.atlas_cracked").withStyle(ChatFormatting.GOLD);
        for (Player player : this.level().players()) {
            if (player.distanceToSqr(this) < 48 * 48) {
                player.displayClientMessage(message, true);
            }
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide) {
            if (core.isDormant()) {
                core.wake();
            }
            if (skyTicks > 0 && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                this.playSound(SoundEvents.ANVIL_LAND, 0.6f, 1.6f); // masih kebal: cuma dentang
                return false;
            }
        }
        return super.hurt(source, amount);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        core.onDeath();
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || core.isDormant();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        core.startSeen(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        core.stopSeen(player);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        core.save(tag);
        tag.putInt("SkyTicks", skyTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        core.load(tag);
        if (tag.contains("SkyTicks")) {
            skyTicks = tag.getInt("SkyTicks");
        }
    }
}
