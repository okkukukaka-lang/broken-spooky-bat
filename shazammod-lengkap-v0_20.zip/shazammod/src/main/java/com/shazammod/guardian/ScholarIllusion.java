package com.shazammod.guardian;

import java.util.UUID;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/** Bayangan Scholar: lenyap sekali pukul, dan yang memukulnya jadi silau. */
public class ScholarIllusion extends Zombie {
    private UUID ownerId;

    public ScholarIllusion(EntityType<? extends ScholarIllusion> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        equip();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 1.0)
                .add(Attributes.ATTACK_DAMAGE, 1.0)
                .add(Attributes.MOVEMENT_SPEED, 0.26)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    private void equip() {
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOOK)); // buku biasa, nggak berkilau
        this.setDropChance(EquipmentSlot.MAINHAND, 0f);
    }

    public void setOwner(ScholarZombie owner) {
        this.ownerId = owner.getUUID();
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide && this.tickCount % 20 == 0) {
            Entity owner = ownerId == null ? null : ((ServerLevel) this.level()).getEntity(ownerId);
            if (owner == null || !owner.isAlive()) {
                this.discard();
                return;
            }
        }
        super.aiStep();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide || this.isRemoved()) {
            return false;
        }
        if (source.getEntity() instanceof LivingEntity attacker) {
            attacker.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60), this);
        }
        ((ServerLevel) this.level()).sendParticles(ParticleTypes.POOF,
                this.getX(), this.getY() + 1.0, this.getZ(), 15, 0.3, 0.5, 0.3, 0.02);
        this.playSound(SoundEvents.ILLUSIONER_MIRROR_MOVE, 1f, 1.4f);
        this.discard();
        return false;
    }

    @Override
    public boolean shouldBeSaved() {
        return false; // bayangan nggak ikut tersimpan
    }

    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    @Override
    protected boolean convertsInWater() {
        return false;
    }

    @Override
    public void setBaby(boolean baby) {
        super.setBaby(false);
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        equip();
    }
}
