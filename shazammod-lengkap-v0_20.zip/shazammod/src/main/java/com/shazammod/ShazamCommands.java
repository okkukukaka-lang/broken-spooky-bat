package com.shazammod;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.shazammod.guardian.GuardianKind;
import com.shazammod.guardian.ShazamGuardian;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

/** Perintah buat ngetes, sebelum altar dan boss-nya jadi. */
public final class ShazamCommands {
    private ShazamCommands() {}

    private static final List<String> GUARDIAN_IDS =
            Arrays.stream(GuardianKind.values()).map(kind -> kind.id).toList();

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("shazam")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("unlock")
                        .executes(ctx -> unlock(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> unlock(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("lock")
                        .executes(ctx -> lock(ctx.getSource(), List.of(ctx.getSource().getPlayerOrException())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> lock(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("energy")
                        .then(Commands.argument("amount", FloatArgumentType.floatArg(0f, ShazamPowers.MAX_ENERGY))
                                .executes(ctx -> setEnergy(ctx.getSource(), FloatArgumentType.getFloat(ctx, "amount")))))
                .then(Commands.literal("summon")
                        .then(Commands.argument("guardian", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(GUARDIAN_IDS, builder))
                                .executes(ctx -> summon(ctx.getSource(), StringArgumentType.getString(ctx, "guardian"))))));
    }

    private static int unlock(CommandSourceStack source, Collection<ServerPlayer> targets) {
        targets.forEach(ShazamPowers::unlock);
        source.sendSuccess(() -> Component.translatable("commands.shazammod.unlock", targets.size()), true);
        return targets.size();
    }

    private static int lock(CommandSourceStack source, Collection<ServerPlayer> targets) {
        targets.forEach(ShazamPowers::lock);
        source.sendSuccess(() -> Component.translatable("commands.shazammod.lock", targets.size()), true);
        return targets.size();
    }

    private static int setEnergy(CommandSourceStack source, float amount) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ShazamPowers.setData(player, ShazamPowers.data(player).withEnergy(amount));
        source.sendSuccess(() -> Component.translatable("commands.shazammod.energy", Math.round(amount)), true);
        return 1;
    }

    /** Munculkan penjaga 5 blok di depan pemain, langsung bangun. */
    private static int summon(CommandSourceStack source, String id) throws CommandSyntaxException {
        GuardianKind kind = GuardianKind.byId(id);
        if (kind == null) {
            source.sendFailure(Component.translatable("commands.shazammod.unknown_guardian", id));
            return 0;
        }
        ServerPlayer player = source.getPlayerOrException();
        ServerLevel level = player.serverLevel();
        Mob mob = kind.entityType().create(level);
        if (mob == null) {
            return 0;
        }
        Vec3 look = player.getLookAngle();
        mob.moveTo(player.getX() + look.x * 5.0, player.getY(), player.getZ() + look.z * 5.0,
                player.getYRot() + 180f, 0f);
        level.addFreshEntity(mob);
        if (mob instanceof ShazamGuardian guardian) {
            guardian.core().wake();
        }
        source.sendSuccess(() -> Component.translatable("commands.shazammod.summon", mob.getDisplayName()), true);
        return 1;
    }
}
