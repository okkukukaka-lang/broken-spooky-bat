package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamMod;
import com.shazammod.client.fx.ShazamFx;
import com.shazammod.client.fx.ShazamRage;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

/**
 * Mata putih menyala saat Zeus Rage: mata putih terang, pendar biru-putih di sekitarnya,
 * kilau mendatar, dan kilatan listrik kecil yang berganti-ganti.
 */
public class ShazamEyesLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation WHITE = ShazamMod.id("textures/entity/shazam_white.png");

    // ======= Letak mata di wajah skin =======
    // Wajah 8x8 piksel, dihitung dari kiri-atas wajah seperti terlihat dari depan.
    // Skin standar (Steve, Alex, dan kebanyakan skin): mata di baris 4, kolom 1-2 dan 5-6.
    private static final int EYE_ROW = 4;
    private static final int EYE_HEIGHT = 1;
    private static final int[][] EYES = {{1, 2}, {5, 2}};    // {kolom paling kiri, lebar}
    private static final float FRONT_Z = -4.56f;              // di depan wajah dan lapisan topi skin

    public ShazamEyesLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        float rage = ShazamRage.glow(player, partialTick);
        float sight = ShazamFx.sightGlow(player, partialTick);   // Mata Solomon: mata menyala ungu sesaat
        float glow = Math.max(rage, sight);
        if (glow <= 0.01f || player.isInvisible()) {
            return;
        }
        boolean violet = sight > rage;
        int[] core = violet ? new int[] {238, 220, 255} : new int[] {255, 255, 255};
        int[] halo = violet ? new int[] {176, 130, 255} : new int[] {200, 230, 255};
        int[] beam = violet ? new int[] {214, 190, 255} : new int[] {235, 245, 255};
        poseStack.pushPose();
        this.getParentModel().head.translateAndRotate(poseStack);
        poseStack.scale(1f / 16f, 1f / 16f, 1f / 16f);
        PoseStack.Pose pose = poseStack.last();

        // 1) Mata putih menyala
        VertexConsumer solid = buffer.getBuffer(RenderType.entityTranslucent(WHITE));
        int alpha = (int) (glow * 255f);
        for (int[] eye : EYES) {
            float x0 = -4f + eye[0], x1 = x0 + eye[1];
            float y0 = -8f + EYE_ROW, y1 = y0 + EYE_HEIGHT;
            solidVertex(solid, pose, x0, y0, alpha, core);
            solidVertex(solid, pose, x1, y0, alpha, core);
            solidVertex(solid, pose, x1, y1, alpha, core);
            solidVertex(solid, pose, x0, y1, alpha, core);
        }

        // 2) Pendar, kilau mendatar, dan kilatan listrik (aditif)
        VertexConsumer light = buffer.getBuffer(RenderType.lightning());
        RandomSource flicker = RandomSource.create(player.getId() * 31L + (long) (ageInTicks / 2f));
        float pulse = 0.7f + 0.2f * Mth.sin(ageInTicks * 0.6f) + (flicker.nextInt(6) == 0 ? 0.35f : 0f);
        float z = FRONT_Z - 0.03f;
        for (int[] eye : EYES) {
            float x0 = -4f + eye[0], x1 = x0 + eye[1];
            float y0 = -8f + EYE_ROW, y1 = y0 + EYE_HEIGHT;
            float cy = (y0 + y1) / 2f;
            quad(light, pose, x0 - 0.7f, y0 - 0.6f, x1 + 0.7f, y1 + 0.6f, z, halo[0], halo[1], halo[2], 0.55f * glow * pulse);
            quad(light, pose, x0 - 1.8f, cy - 0.14f, x1 + 1.8f, cy + 0.14f, z - 0.01f, beam[0], beam[1], beam[2], 0.45f * glow * pulse);
            for (int k = 0; k < (violet ? 0 : 2); k++) {
                float sx = flicker.nextBoolean() ? x0 - 0.2f : x1 + 0.2f;
                float sy = cy + (flicker.nextFloat() - 0.5f) * EYE_HEIGHT;
                float dir = sx < x0 ? -1f : 1f;
                float mx = sx + dir * (0.6f + flicker.nextFloat() * 0.6f), my = sy + (flicker.nextFloat() - 0.5f) * 1.4f;
                float ex = mx + dir * (0.5f + flicker.nextFloat() * 0.6f), ey = my + (flicker.nextFloat() - 0.5f) * 1.4f;
                streak(light, pose, sx, sy, mx, my, z - 0.02f, 0.9f * glow);
                streak(light, pose, mx, my, ex, ey, z - 0.02f, 0.7f * glow);
            }
        }
        poseStack.popPose();
    }

    private static void solidVertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, int alpha, int[] c) {
        vc.addVertex(pose, x, y, FRONT_Z).setColor(c[0], c[1], c[2], alpha).setUv(0.5f, 0.5f)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 0f, -1f);
    }

    /** Segi empat cahaya, dua sisi. */
    private static void quad(VertexConsumer vc, PoseStack.Pose pose, float xa, float ya, float xb, float yb, float z,
                             int r, int g, int b, float strength) {
        int a = (int) (Mth.clamp(strength, 0f, 1f) * 255f);
        vc.addVertex(pose, xa, ya, z).setColor(r, g, b, a);
        vc.addVertex(pose, xb, ya, z).setColor(r, g, b, a);
        vc.addVertex(pose, xb, yb, z).setColor(r, g, b, a);
        vc.addVertex(pose, xa, yb, z).setColor(r, g, b, a);
        vc.addVertex(pose, xa, yb, z).setColor(r, g, b, a);
        vc.addVertex(pose, xb, yb, z).setColor(r, g, b, a);
        vc.addVertex(pose, xb, ya, z).setColor(r, g, b, a);
        vc.addVertex(pose, xa, ya, z).setColor(r, g, b, a);
    }

    /** Garis kilatan tipis dari (x1, y1) ke (x2, y2). */
    private static void streak(VertexConsumer vc, PoseStack.Pose pose, float x1, float y1, float x2, float y2, float z, float strength) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = Mth.sqrt(dx * dx + dy * dy);
        if (len < 1.0E-4f) {
            return;
        }
        float nx = -dy / len * 0.09f, ny = dx / len * 0.09f;
        int a = (int) (Mth.clamp(strength, 0f, 1f) * 255f);
        vc.addVertex(pose, x1 - nx, y1 - ny, z).setColor(225, 240, 255, a);
        vc.addVertex(pose, x1 + nx, y1 + ny, z).setColor(225, 240, 255, a);
        vc.addVertex(pose, x2 + nx, y2 + ny, z).setColor(225, 240, 255, a);
        vc.addVertex(pose, x2 - nx, y2 - ny, z).setColor(225, 240, 255, a);
        vc.addVertex(pose, x2 - nx, y2 - ny, z).setColor(225, 240, 255, a);
        vc.addVertex(pose, x2 + nx, y2 + ny, z).setColor(225, 240, 255, a);
        vc.addVertex(pose, x1 + nx, y1 + ny, z).setColor(225, 240, 255, a);
        vc.addVertex(pose, x1 - nx, y1 - ny, z).setColor(225, 240, 255, a);
    }
}
