package com.shazammod.client.flight;

import java.util.HashMap;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMercury;
import com.shazammod.ShazamMercuryPayload;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.fx.ShazamFx;

import net.minecraft.ChatFormatting;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Mode Kilat Mercury di client pemain sendiri (geraknya dihitung di sini, seperti terbang):
 * - ada monster dalam RANGE yang kelihatan (nggak terhalang tembok): melesat ke depannya, memukul (jab, cross,
 *   hook, tendangan bergantian), tertahan sekejap seperti pukulan yang benar-benar kena, lalu langsung ke musuh
 *   terdekat berikutnya. Musuh yang baru muncul langsung ikut diserang;
 * - nggak ada musuh: lari super cepat dengan percepatan, belokan yang makin lebar saat makin kencang, rem yang
 *   tergelincir, momentum yang terjaga saat melompat, dan bisa lari di atas air kalau cukup kencang.
 * Tombol M (bisa diganti di Controls): auto-hit nyala/mati. Mati = cuma lari super cepat, monster nggak diserang
 * otomatis (pilihannya diingat sampai game ditutup).
 * Tahan Shift: semuanya ditahan, jalan biasa (misalnya mau lewat tanpa menyerang).
 */
public final class MercuryMode {
    private MercuryMode() {}

    // ======= Angka yang gampang diutak-atik (satuan blok per tick; x20 = blok per detik) =======
    private static final double RANGE = 20.0;          // monster sejauh ini langsung diserang (pemanah menembak dari ±16 blok)
    private static final double CHASE_SPEED = 3.2;     // ±64 blok/detik saat menerjang musuh
    private static final double REACH = 1.6;           // jarak pukul dari tepi badan musuh
    private static final int HIT_STOP = 1;             // tick tertahan sesudah memukul (pukulan terasa berat)
    private static final int CHASE_TIMEOUT = 14;       // nggak sampai-sampai (terhalang): cari musuh lain
    private static final int RESTRIKE = 6;             // musuh yang masih hidup (bos) dipukul lagi sesudah ini
    private static final double RUN_SPEED = 2.6;       // lari super cepat: ±52 blok/detik
    private static final double RUN_ACCEL = 0.2;       // dari diam ke kecepatan puncak ±0,65 detik
    private static final double RUN_BRAKE = 0.3;       // rem: tergelincir ±0,45 detik dari kecepatan puncak
    private static final double RUN_GRIP = 0.42;       // gaya menyamping maksimum: makin kencang, makin lebar belokannya
    private static final double AIR_DRAG = 0.985;      // di udara momentum terjaga, cuma dikurangi hambatan udara
    private static final double WATER_RUN = 1.0;       // secepat ini bisa lari di atas air
    // ==================================================================================================

    private static boolean active;
    private static boolean auto = true;                // auto-hit (tombol M); mati = cuma lari super cepat
    private static int ticks;
    private static Vec3 vel = Vec3.ZERO;               // kecepatan lari mendatar (dihitung sendiri, seperti terbang)
    private static LivingEntity target;
    private static int chaseTicks;
    private static int hitStop;
    private static int moves;                          // urutan jenis pukulan
    private static int pendingTarget = -1;
    private static int pendingMove;
    private static boolean chasing;
    private static boolean onWater;
    private static final Map<Integer, Integer> STRUCK = new HashMap<>();    // id -> tick terakhir dipukul
    private static final Map<Integer, Integer> BLOCKED = new HashMap<>();   // id -> nggak dikejar sampai tick ini

    public static boolean isActive() {
        return active;
    }

    /** Auto-hit nyala (monster di sekitar otomatis diterjang dan dipukul). */
    public static boolean isAuto() {
        return auto;
    }

    /** Tombol M: auto-hit nyala/mati. Lari super cepatnya tetap jalan selama Mode Kilat nyala. */
    public static void toggleAuto(LocalPlayer player) {
        auto = !auto;
        if (!auto) {
            target = null;
            chaseTicks = 0;
        }
        player.displayClientMessage(autoMessage(auto), true);
        player.level().playLocalSound(player.getX(), player.getY(), player.getZ(),
                auto ? SoundEvents.BEACON_POWER_SELECT : SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 0.45f, 2.0f, false);
    }

    private static Component autoMessage(boolean on) {
        Component key = Component.keybind("key.shazammod.mercury_auto");
        return on
                ? Component.translatable("message.shazammod.mercury_auto_on", key).withStyle(ChatFormatting.AQUA)
                : Component.translatable("message.shazammod.mercury_auto_off", key).withStyle(ChatFormatting.YELLOW);
    }

    /** Sedang menerjang/memukul musuh. */
    public static boolean isChasing() {
        return active && chasing;
    }

    /** Sedang lari di atas air. */
    public static boolean isOnWater() {
        return active && onWater;
    }

    /** 0-1: seberapa kencang (buat melebarkan pandangan). */
    public static float speedFactor() {
        if (!active) {
            return 0f;
        }
        return chasing ? 1f : (float) Math.min(1.0, vel.length() / RUN_SPEED);
    }

    // ---------------------------------------------------------------- tiap tick

    /** Sebelum gerak pemain dihitung (sesudah ShazamFlight.preTick). */
    public static void preTick(LocalPlayer player) {
        ticks++;
        boolean on = ShazamClientState.isTransformed(player.getId()) && ShazamClientState.isMercury(player.getId())
                && !player.isSpectator() && !player.isPassenger() && !player.isSleeping();
        if (!on) {
            if (active) {
                reset();
            }
            return;
        }
        if (!active) {
            active = true;
            Vec3 d = player.getDeltaMovement();
            vel = new Vec3(d.x, 0, d.z);
            if (!auto) {   // ingatkan: nyala tanpa auto-hit (pesan ini menimpa pesan "nyala" dari server)
                player.displayClientMessage(autoMessage(false), true);
            }
        }
        if (ticks % 40 == 0) {
            STRUCK.values().removeIf(t -> ticks - t > 100);
            BLOCKED.values().removeIf(t -> t < ticks);
        }
        // tabrakan dari gerak tick lalu: sumbu yang menabrak sudah dinolkan oleh game
        Vec3 moved = player.getDeltaMovement();
        if (player.horizontalCollision) {
            vel = new Vec3(moved.x == 0.0 ? 0.0 : vel.x, 0, moved.z == 0.0 ? 0.0 : vel.z);
        }
        if (hitStop > 0) {   // tertahan sekejap sesudah memukul
            hitStop--;
            chasing = true;
            hold(player, Vec3.ZERO);
            vel = Vec3.ZERO;
            return;
        }
        boolean paused = player.input.shiftKeyDown;   // Shift: auto-hit & lari super cepat ditahan
        boolean hunting = auto && !paused;             // tombol M: auto-hit dimatikan, tinggal lari super cepat
        if (target != null && (!hunting || !valid(player, target))) {
            target = null;
        }
        if (target == null && hunting) {
            target = nearest(player);
            chaseTicks = 0;
        }
        if (target != null) {
            chase(player);
        } else if (paused) {
            chasing = false;
            onWater = false;
            Vec3 d = player.getDeltaMovement();
            vel = new Vec3(d.x, 0, d.z);
        } else {
            run(player);
        }
    }

    /** Sesudah gerak dihitung: kalau sudah dalam jangkauan, pukul. */
    public static void postTick(LocalPlayer player) {
        if (!active || target == null || hitStop > 0 || gap(player, target) > REACH) {
            return;
        }
        int move = moves++ & 3;
        Vec3 hit = target.position().add(0, target.getBbHeight() * 0.6, 0);
        pendingTarget = target.getId();
        pendingMove = move;
        STRUCK.put(target.getId(), ticks);
        // gerakan dan efeknya langsung di sini (pemain lain mendapatnya dari server)
        ShazamAnim anim = ShazamMercury.strikeAnim(move);
        ShazamPoses.start(player, anim);
        ShazamFx.onAnim(player, anim, hit);
        if (move == 0 || move == 2) {
            player.swing(InteractionHand.MAIN_HAND);
        } else if (move == 1) {
            player.swing(InteractionHand.OFF_HAND);
        }
        hitStop = HIT_STOP;
        target = null;
    }

    /** Akhir tick client (posisi tick ini sudah terkirim): kirim pukulan ke server. */
    public static void flush() {
        if (pendingTarget >= 0) {
            PacketDistributor.sendToServer(new ShazamMercuryPayload(pendingTarget, pendingMove));
            pendingTarget = -1;
        }
    }

    public static void reset() {
        active = false;
        target = null;
        vel = Vec3.ZERO;
        hitStop = 0;
        chaseTicks = 0;
        pendingTarget = -1;
        chasing = false;
        onWater = false;
        STRUCK.clear();
        BLOCKED.clear();
    }

    // ---------------------------------------------------------------- menyerang

    private static void hold(LocalPlayer player, Vec3 v) {
        player.setDeltaMovement(v);
        player.fallDistance = 0f;
        if (player.getAbilities().flying) {
            ShazamFlight.override(v);
        }
    }

    /** Melesat ke titik tepat di depan musuh (dari arah datangnya pemain), setinggi kakinya. */
    private static void chase(LocalPlayer player) {
        chasing = true;
        onWater = false;
        Vec3 p = player.position();
        Vec3 t = target.position();
        double ax = p.x - t.x, az = p.z - t.z;
        double al = Math.sqrt(ax * ax + az * az);
        if (al < 1.0E-3) {
            Vec3 look = player.getViewVector(1f);
            ax = -look.x;
            az = -look.z;
            al = Math.sqrt(ax * ax + az * az);
            if (al < 1.0E-3) {
                ax = 1.0;
                az = 0.0;
                al = 1.0;
            }
        }
        double stand = target.getBbWidth() * 0.5 + player.getBbWidth() * 0.5 + 0.35;
        Vec3 spot = new Vec3(t.x + ax / al * stand, t.y, t.z + az / al * stand);
        Vec3 d = spot.subtract(p);
        double dist = d.length();
        Vec3 v = dist > CHASE_SPEED ? d.scale(CHASE_SPEED / dist) : d;
        hold(player, v);
        vel = new Vec3(v.x, 0, v.z);
        if (++chaseTicks > CHASE_TIMEOUT) {   // terhalang: tandai, cari musuh lain
            BLOCKED.put(target.getId(), ticks + 40);
            target = null;
        }
    }

    private static boolean valid(LocalPlayer player, LivingEntity e) {
        return e.isAlive() && !e.isRemoved() && e.level() == player.level()
                && e.distanceToSqr(player) < (RANGE + 6.0) * (RANGE + 6.0) && !recentlyStruck(e);
    }

    private static boolean recentlyStruck(LivingEntity e) {
        Integer t = STRUCK.get(e.getId());
        return t != null && ticks - t < RESTRIKE;
    }

    /** Monster terdekat yang kelihatan (nggak terhalang blok). */
    private static LivingEntity nearest(LocalPlayer player) {
        Level level = player.level();
        AABB area = player.getBoundingBox().inflate(RANGE);
        LivingEntity best = null;
        double bestDist = RANGE * RANGE;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, MercuryMode::hostile)) {
            double d = e.distanceToSqr(player);
            if (d > bestDist || recentlyStruck(e)) {
                continue;
            }
            Integer until = BLOCKED.get(e.getId());
            if (until != null && until >= ticks) {
                continue;
            }
            if (!player.hasLineOfSight(e)) {
                continue;
            }
            best = e;
            bestDist = d;
        }
        return best;
    }

    /** Boleh diserang otomatis: monster; makhluk netral (enderman, zombified piglin) cuma kalau sedang menyerang. */
    private static boolean hostile(LivingEntity e) {
        if (!(e instanceof Enemy) || !e.isAlive() || e.isInvisible()) {
            return false;
        }
        if (e instanceof NeutralMob) {
            return e instanceof Mob mob && mob.isAggressive();
        }
        return true;
    }

    /** Jarak terdekat dari badan pemain ke badan sasaran. */
    private static double gap(LocalPlayer player, LivingEntity e) {
        AABB a = player.getBoundingBox(), b = e.getBoundingBox();
        double dx = Math.max(0.0, Math.max(b.minX - a.maxX, a.minX - b.maxX));
        double dy = Math.max(0.0, Math.max(b.minY - a.maxY, a.minY - b.maxY));
        double dz = Math.max(0.0, Math.max(b.minZ - a.maxZ, a.minZ - b.maxZ));
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    // ---------------------------------------------------------------- lari super cepat

    private static void run(LocalPlayer player) {
        chasing = false;
        onWater = false;
        boolean water = waterSurface(player);
        if (player.getAbilities().flying || player.isFallFlying() || player.isInLava() || (player.isInWater() && !water)) {
            // terbang (ShazamFlight), elytra, berenang, atau di lava: pakai gerak bawaan, momentum lari nggak dibawa
            Vec3 d = player.getDeltaMovement();
            vel = new Vec3(d.x, 0, d.z);
            return;
        }
        Input in = player.input;
        double yaw = Math.toRadians(player.getYRot());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // depan
        double lx = Math.cos(yaw), lz = Math.sin(yaw);    // kiri
        double wx = fx * in.forwardImpulse + lx * in.leftImpulse, wz = fz * in.forwardImpulse + lz * in.leftImpulse;
        double wl = Math.sqrt(wx * wx + wz * wz);
        if (wl > 1.0) {
            wx /= wl;
            wz /= wl;
            wl = 1.0;
        }
        if (player.onGround() || (water && vel.length() >= WATER_RUN)) {
            vel = steer(vel, new Vec3(wx * RUN_SPEED, 0, wz * RUN_SPEED));
        } else {
            vel = vel.scale(AIR_DRAG);   // melompat/jatuh: lintasan melengkung, momentum terjaga
        }
        double speed = vel.length();
        if (speed < 0.08 && wl < 0.01) {   // diam: biarkan gerak bawaan (berdiri, menoleh, melompat di tempat)
            vel = Vec3.ZERO;
            return;
        }
        double vy = player.getDeltaMovement().y;
        if (water && speed >= WATER_RUN) {   // lari di atas air: kaki tetap di permukaan
            onWater = true;
            double surface = Math.floor(player.getY() - 0.25) + 1.0;
            vy = Mth.clamp(surface - player.getY(), -0.3, 0.3);
            player.fallDistance = 0f;
        }
        player.setDeltaMovement(vel.x, vy, vel.z);
    }

    /**
     * Ubah kecepatan v ke arah yang diinginkan dengan batas fisik: percepatan dan rem searah gerak,
     * dan gaya menyamping (cengkeraman kaki) yang terbatas, jadi makin kencang makin lebar belokannya.
     */
    private static Vec3 steer(Vec3 v, Vec3 desired) {
        Vec3 diff = desired.subtract(v);
        double speed = v.length();
        if (speed < 1.0E-4) {
            double dl = diff.length();
            return dl > RUN_ACCEL ? diff.scale(RUN_ACCEL / dl) : desired;
        }
        Vec3 along = v.scale(1.0 / speed);
        double tangential = diff.dot(along);
        Vec3 normal = diff.subtract(along.scale(tangential));
        tangential = tangential >= 0.0 ? Math.min(tangential, RUN_ACCEL) : Math.max(tangential, -RUN_BRAKE);
        double nl = normal.length();
        if (nl > RUN_GRIP) {
            normal = normal.scale(RUN_GRIP / nl);
        }
        return v.add(along.scale(tangential)).add(normal);
    }

    /** Kaki tepat di atas permukaan air (bukan tenggelam). */
    private static boolean waterSurface(LocalPlayer player) {
        Level level = player.level();
        BlockPos below = BlockPos.containing(player.getX(), player.getY() - 0.25, player.getZ());
        BlockPos feet = BlockPos.containing(player.getX(), player.getY() + 0.1, player.getZ());
        return level.getFluidState(below).is(FluidTags.WATER) && !level.getFluidState(feet).is(FluidTags.WATER);
    }
}
