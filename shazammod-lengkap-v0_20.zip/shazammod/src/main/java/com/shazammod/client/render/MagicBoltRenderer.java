package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.MagicBolt;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;

/**
 * Petir sihir digambar oleh mesin efek (lihat client.vfx.BoltVisual), di lapisan cahaya yang nggak menutupi
 * benda di belakangnya. Renderer ini sengaja kosong.
 */
public class MagicBoltRenderer extends EntityRenderer<MagicBolt> {
    public MagicBoltRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(MagicBolt bolt, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
    }

    @Override
    public ResourceLocation getTextureLocation(MagicBolt bolt) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
