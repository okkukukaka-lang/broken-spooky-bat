package com.shazammod.client.fx;

import java.util.Random;

import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.phys.Vec3;

/**
 * Petir "speed force" Mode Kilat Mercury saat lari super cepat:
 * - beberapa sambaran petir TEBAL yang terseret di belakang pelari, mengikuti lintasan lari yang sesungguhnya
 *   (ikut melengkung saat berbelok), berpangkal di badan lalu makin melebar ke belakang. Bentuk zig-zag-nya
 *   dibentuk ulang tiap tick (berkedip seperti petir sungguhan), sedangkan liukannya bergerak halus tiap frame;
 *   inti putih panas, badan biru, pendar udara terionisasi yang lebar, cabang-cabang, dan titik terang di tekukan;
 * - busur listrik yang melompat di antara bayangan-bayangan berjejak, dan listrik kecil yang merayap di badan
 *   bayangan;
 * - pendar biru di sekitar badan pelari.
 * Di sudut pandang orang pertama, bagian yang terlalu dekat kamera nggak digambar.
 */
public final class SpeedForce extends Effect {
    // ======= Angka yang gampang diutak-atik =======
    private static final int BOLTS = 4;                         // sambaran yang terseret di belakang
    private static final float BOLT_WIDTH = 0.17f;              // tebal petir di dekat badan (blok)
    private static final double BOLT_LENGTH = 4.6;              // panjang sambaran terpendek; tiap berikutnya +1,1 blok
    private static final double STEP = 0.3;                     // jarak antar-titik zig-zag (blok)
    private static final int GHOST_ARCS = 3;                    // busur listrik antar-bayangan tiap tick
    private static final int GHOST_CRACKLE = 6;                 // bayangan terbaru yang badannya ikut berlistrik
    private static final int FADE_OUT = 5;                      // berhenti lari: petir padam dalam 5 tick
    private static final float[] HEIGHT = {0.42f, 0.86f, 1.22f, 1.52f};   // pangkal tiap sambaran (× tinggi badan / 1,8)
    private static final float[] SIDE = {-0.2f, 0.24f, -0.12f, 0.16f};
    private static final int[] COLORS = {0x9AF2FF, 0x5EC2FF, 0xCFF9FF, 0x7EDCFF};
    private static final int GLOW_COLOR = 0x3F9CFF;             // pendar udara di sekitar petir
    // ==================================================================================================

    private static final int HISTORY = 16;                      // tick lintasan yang diingat

    private final AbstractClientPlayer owner;
    private final double[] hx = new double[HISTORY], hy = new double[HISTORY], hz = new double[HISTORY];
    private int count;
    private int followUntil;
    private int endAge = -1;
    private float strength = 1f;
    private final long seed;
    private final double[] phases = new double[BOLTS];
    // tempat kerja (dipakai ulang tiap frame)
    private final double[] path = new double[(HISTORY + 1) * 3];
    private final double[] along = new double[HISTORY + 1];
    private float[] pts = new float[64 * 3];
    private float[] ws = new float[64], as = new float[64], glowA = new float[64];
    private final double[] gp = new double[12 * 3];
    private final float[] gl = new float[12];

    public SpeedForce(AbstractClientPlayer owner) {
        super(20 * 60 * 30);
        this.owner = owner;
        this.seed = Vfx.random().nextLong();
        for (int b = 0; b < BOLTS; b++) {
            phases[b] = Vfx.random().nextDouble() * Math.PI * 2.0;
        }
        push(owner.xo, owner.yo, owner.zo);
        push(owner.getX(), owner.getY(), owner.getZ());
        followUntil = 2;
    }

    /** Tetap mengikuti pelari sampai ticks lagi (dipanggil tiap tick selama masih lari kencang). */
    public void sustain(int ticks) {
        followUntil = Math.max(followUntil, age + ticks);
    }

    public boolean following() {
        return endAge < 0 && age < followUntil;
    }

    /** Kekuatan 0-1 (makin kencang makin tebal dan panjang). */
    public void strength(float value) {
        strength = Math.max(0f, Math.min(1f, value));
    }

    private void push(double x, double y, double z) {
        if (count == HISTORY) {
            System.arraycopy(hx, 1, hx, 0, HISTORY - 1);
            System.arraycopy(hy, 1, hy, 0, HISTORY - 1);
            System.arraycopy(hz, 1, hz, 0, HISTORY - 1);
            count--;
        }
        hx[count] = x;
        hy[count] = y;
        hz[count] = z;
        count++;
    }

    @Override
    public boolean tick(ClientLevel level) {
        age++;
        boolean live = endAge < 0 && age < followUntil && owner.isAlive() && !owner.isRemoved();
        if (live) {
            push(owner.getX(), owner.getY(), owner.getZ());
        } else if (endAge < 0) {
            endAge = age;
        }
        return endAge < 0 || age - endAge < FADE_OUT;
    }

    @Override
    public void renderGlow(Draw d) {
        float pt = d.partialTick;
        boolean live = endAge < 0;
        float fade = live ? 1f : 1f - Math.min(1f, (age - endAge + pt) / FADE_OUT);
        float a = strength * fade;
        if (a <= 0.01f || count < 2) {
            return;
        }
        Vec3 head = live ? owner.getPosition(pt) : new Vec3(hx[count - 1], hy[count - 1], hz[count - 1]);
        if (d.distance(head.x, head.y, head.z) > 110.0) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        boolean firstPerson = owner == mc.player && mc.options.getCameraType().isFirstPerson();
        double scale = owner.getBbHeight() / 1.8;

        // lintasan dari kepala (posisi sekarang) mundur ke belakang, dengan panjang kumulatifnya
        int n = 0;
        path[0] = head.x;
        path[1] = head.y;
        path[2] = head.z;
        along[0] = 0.0;
        n = 1;
        for (int i = count - 2; i >= 0; i--) {
            double dx = hx[i] - path[(n - 1) * 3], dy = hy[i] - path[(n - 1) * 3 + 1], dz = hz[i] - path[(n - 1) * 3 + 2];
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 1.0E-3) {
                continue;
            }
            path[n * 3] = hx[i];
            path[n * 3 + 1] = hy[i];
            path[n * 3 + 2] = hz[i];
            along[n] = along[n - 1] + len;
            n++;
        }
        double total = along[n - 1];
        double time = age + pt;

        if (!firstPerson) {   // pendar biru tipis di sekitar badan (udara di sekitar pelari terionisasi)
            d.glow(head.x, head.y + 1.0 * scale, head.z, (float) (1.0 * scale), 0x3F9CFF, 0.11f * a);
        }

        if (total > 0.4) {
            for (int b = 0; b < BOLTS; b++) {
                drawBolt(d, b, total, n, time, scale, a, firstPerson);
            }
        }
        drawGhostArcs(d, pt, fade);
    }

    /** Satu sambaran yang terseret mengikuti lintasan. */
    private void drawBolt(Draw d, int b, double total, int n, double time, double scale, float a, boolean firstPerson) {
        double length = Math.min(total, (BOLT_LENGTH + b * 1.1) * (0.55 + 0.45 * strength));
        if (length < 0.5) {
            return;
        }
        Random random = new Random(seed + age * 7919L + b * 104729L);
        float flick = random.nextInt(6) == 0 ? 1.3f : 0.78f + random.nextFloat() * 0.22f;   // sesekali menyambar terang
        float alpha = a * flick;
        int rgb = COLORS[b % COLORS.length];
        int samples = (int) Math.ceil(length / STEP) + 1;
        if (pts.length < samples * 3) {
            pts = new float[samples * 3];
        }
        int m = 0;
        int seg = 0;
        double start = firstPerson ? 1.4 : 0.0;   // orang pertama: jangan menutupi layar
        for (int k = 0; k < samples; k++) {
            double t = Math.min(length, k * STEP);
            if (t < start) {
                continue;
            }
            while (seg < n - 2 && along[seg + 1] < t) {
                seg++;
            }
            double segLen = Math.max(1.0E-6, along[seg + 1] - along[seg]);
            double u = Math.max(0.0, Math.min(1.0, (t - along[seg]) / segLen));
            int o = seg * 3, p = o + 3;
            double x = path[o] + (path[p] - path[o]) * u;
            double y = path[o + 1] + (path[p + 1] - path[o + 1]) * u;
            double z = path[o + 2] + (path[p + 2] - path[o + 2]) * u;
            // arah ke belakang & samping (mendatar)
            double dx = (path[p] - path[o]) / segLen, dz = (path[p + 2] - path[o + 2]) / segLen;
            double sl = Math.sqrt(dx * dx + dz * dz);
            double sx = sl < 1.0E-4 ? 1.0 : -dz / sl, sz = sl < 1.0E-4 ? 0.0 : dx / sl;
            double f = t / length;   // 0 = di badan, 1 = ujung ekor
            double amp = 0.08 + 0.42 * f;
            double ph = phases[b] + time * 0.35;
            double lat = SIDE[b] * scale * (1.0 - 0.3 * f) + amp * Math.sin(ph + t * 1.6);
            double up = HEIGHT[b] * scale + amp * 0.7 * Math.cos(ph * 1.3 + t * 1.25) - 0.25 * f;
            if (k > 0) {   // zig-zag baru tiap tick
                double jit = 0.05 + 0.2 * f;
                lat += (random.nextDouble() - 0.5) * 2.0 * jit;
                up += (random.nextDouble() - 0.5) * 2.0 * jit;
            }
            pts[m * 3] = (float) (x + sx * lat);
            pts[m * 3 + 1] = (float) (y + up);
            pts[m * 3 + 2] = (float) (z + sz * lat);
            m++;
        }
        if (m < 2) {
            return;
        }
        float w0 = BOLT_WIDTH * (0.75f + 0.25f * strength) * (float) scale;
        // keluar dari badan: tipis & redup di pangkalnya (nggak menutupi badan), paling tebal sedikit di belakang badan,
        // lalu menipis dan padam di ujung ekor. Bagian yang lewat dekat kamera memudar (kamera F5 ada di jalur lari).
        if (ws.length < m) {
            ws = new float[m];
            as = new float[m];
            glowA = new float[m];
        }
        for (int i = 0; i < m; i++) {
            float f = i / (float) (m - 1);
            float rise = Math.min(1f, f / 0.2f);
            float fall = f <= 0.2f ? 1f : 1f - (f - 0.2f) / 0.8f;
            double x = pts[i * 3], y = pts[i * 3 + 1], z = pts[i * 3 + 2];
            float near = d.nearFade(x, y, z, 0.9, 3.2);
            // dilihat searah panjangnya (kamera tepat di belakang pelari), lapisan petir bertumpuk jadi gumpalan putih:
            // bagian yang menghadap kamera diredupkan
            int prev = Math.max(0, i - 1) * 3, next = Math.min(m - 1, i + 1) * 3;
            double tx = pts[next] - pts[prev], ty = pts[next + 1] - pts[prev + 1], tz = pts[next + 2] - pts[prev + 2];
            double vx = x - d.camX, vy = y - d.camY, vz = z - d.camZ;
            double cx = ty * vz - tz * vy, cy = tz * vx - tx * vz, cz = tx * vy - ty * vx;
            double tl = Math.sqrt(tx * tx + ty * ty + tz * tz) * Math.sqrt(vx * vx + vy * vy + vz * vz);
            float across = tl < 1.0E-9 ? 1f : (float) (Math.sqrt(cx * cx + cy * cy + cz * cz) / tl);
            ws[i] = w0 * (0.45f + 0.55f * rise) * (0.3f + 0.7f * fall);
            as[i] = alpha * (0.2f + 0.8f * rise) * fall * near * (0.3f + 0.7f * across);
            glowA[i] = as[i] * d.nearFade(x, y, z, 1.8, 5.0);
        }
        d.polyline(pts, m, ws, as, rgb, 0xFFFFFF);
        float old = d.body(0.35f);   // udara terionisasi di sekitar petir: petirnya terasa tebal
        d.strip(pts, m, ws, 4.5f, glowA, 0.24f, GLOW_COLOR);
        d.body(old);
        // cabang-cabang pendek dan titik terang di tekukan
        for (int k = 0; k < 2; k++) {
            int i = 1 + random.nextInt(Math.max(1, m - 3));
            float f = i / (float) (m - 1);
            double sx = pts[i * 3], sy = pts[i * 3 + 1], sz = pts[i * 3 + 2];
            int j = Math.min(m - 1, i + 1);
            double bx = pts[j * 3] - sx, by = pts[j * 3 + 1] - sy, bz = pts[j * 3 + 2] - sz;
            double bl = Math.sqrt(bx * bx + by * by + bz * bz) + 1.0E-6;
            double len = (0.35 + random.nextDouble() * 0.9) * (0.6 + f);
            double ex = sx + (bx / bl * 0.6 + (random.nextDouble() - 0.5) * 1.6) * len;
            double ey = sy + (by / bl * 0.6 + (random.nextDouble() - 0.5) * 1.6) * len;
            double ez = sz + (bz / bl * 0.6 + (random.nextDouble() - 0.5) * 1.6) * len;
            float[] br = Lightning.path(sx, sy, sz, ex, ey, ez, 3, 0.3, random);
            float near = d.nearFade(sx, sy, sz, 1.5, 4.0);
            if (near <= 0.01f) {
                continue;
            }
            d.polyline(br, br.length / 3, ws[i] * 0.6f, ws[i] * 0.1f, rgb, 0xFFFFFF, as[i] * 0.9f * near, 0f);
            d.glow(sx, sy, sz, (0.2f + 0.22f * (1f - f)) * (float) scale, rgb, as[i] * 0.45f * near);
        }
    }

    /** Busur listrik yang melompat di antara bayangan-bayangan berjejak, dan listrik di badan bayangan terbaru. */
    private void drawGhostArcs(Draw d, float pt, float fade) {
        int g = ShazamPoses.ghostPoints(owner, pt, gp, gl, gl.length);
        if (g < 1) {
            return;
        }
        Random random = new Random(seed * 31L + age * 7919L);
        for (int k = 0; k < GHOST_ARCS && g >= 2; k++) {
            int i = random.nextInt(g - 1);
            int j = Math.min(g - 1, i + 1 + random.nextInt(2));
            float life = Math.min(gl[i], gl[j]) * fade
                    * d.nearFade((gp[i * 3] + gp[j * 3]) * 0.5, (gp[i * 3 + 1] + gp[j * 3 + 1]) * 0.5, (gp[i * 3 + 2] + gp[j * 3 + 2]) * 0.5,
                    1.4, 3.8);
            if (life <= 0.05f) {
                continue;
            }
            double ax = gp[i * 3] + (random.nextDouble() - 0.5) * 0.6, ay = gp[i * 3 + 1] + (random.nextDouble() - 0.5) * 1.3;
            double az = gp[i * 3 + 2] + (random.nextDouble() - 0.5) * 0.6;
            double bx = gp[j * 3] + (random.nextDouble() - 0.5) * 0.6, by = gp[j * 3 + 1] + (random.nextDouble() - 0.5) * 1.3;
            double bz = gp[j * 3 + 2] + (random.nextDouble() - 0.5) * 0.6;
            float[] arc = Lightning.path(ax, ay, az, bx, by, bz, 4, 0.28, random);
            int rgb = random.nextBoolean() ? 0x9AF2FF : 0x6FCBFF;
            d.polyline(arc, arc.length / 3, 0.12f * life, 0.07f * life, rgb, 0xFFFFFF, life, life * 0.7f);
            d.glow(ax, ay, az, 0.3f * life, rgb, 0.4f * life);
        }
        for (int i = 0; i < Math.min(g, GHOST_CRACKLE); i++) {
            float life = gl[i] * fade * d.nearFade(gp[i * 3], gp[i * 3 + 1], gp[i * 3 + 2], 1.4, 3.8);
            if (life <= 0.05f) {
                continue;
            }
            double ax = gp[i * 3] + (random.nextDouble() - 0.5) * 0.6, ay = gp[i * 3 + 1] + (random.nextDouble() - 0.6) * 1.6;
            double az = gp[i * 3 + 2] + (random.nextDouble() - 0.5) * 0.6;
            double bx = ax + (random.nextDouble() - 0.5) * 0.9, by = ay + (random.nextDouble() - 0.5) * 0.9;
            double bz = az + (random.nextDouble() - 0.5) * 0.9;
            float[] arc = Lightning.path(ax, ay, az, bx, by, bz, 3, 0.35, random);
            d.polyline(arc, arc.length / 3, 0.08f * life, 0.05f * life, 0x9AF2FF, 0xFFFFFF, life, life * 0.6f);
        }
    }
}
