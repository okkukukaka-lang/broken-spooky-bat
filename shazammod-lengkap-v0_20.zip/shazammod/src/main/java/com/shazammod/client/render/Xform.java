package com.shazammod.client.render;

/**
 * Transformasi kaku plus skala seragam (murni Java): dunia = t + s · R · lokal.
 * Dipakai untuk ruang badan, leher, kepala, lengan, dan kaki. R disimpan baris demi baris.
 */
public final class Xform implements HoodShape.Frame {
    public double r00 = 1, r01, r02;
    public double r10, r11 = 1, r12;
    public double r20, r21, r22 = 1;
    public double tx, ty, tz;
    public double s = 1.0;

    public Xform() {}

    public Xform(Xform o) {
        set(o);
    }

    public Xform set(Xform o) {
        r00 = o.r00; r01 = o.r01; r02 = o.r02;
        r10 = o.r10; r11 = o.r11; r12 = o.r12;
        r20 = o.r20; r21 = o.r21; r22 = o.r22;
        tx = o.tx; ty = o.ty; tz = o.tz;
        s = o.s;
        return this;
    }

    public Xform identity() {
        r00 = 1; r01 = 0; r02 = 0;
        r10 = 0; r11 = 1; r12 = 0;
        r20 = 0; r21 = 0; r22 = 1;
        tx = 0; ty = 0; tz = 0;
        s = 1.0;
        return this;
    }

    /**
     * Dari matriks 4x4 (kolom c0, c1, c2 = bagian linear, t = translasi), misalnya Matrix4f JOML:
     * c0 = (m00, m01, m02), c1 = (m10, m11, m12), c2 = (m20, m21, m22), t = (m30, m31, m32).
     * Skala diambil dari panjang kolom, rotasinya dirapikan (ortonormal) supaya tetap kaku.
     */
    public Xform setColumns(double c0x, double c0y, double c0z, double c1x, double c1y, double c1z,
                            double c2x, double c2y, double c2z, double px, double py, double pz) {
        double l0 = Math.sqrt(c0x * c0x + c0y * c0y + c0z * c0z);
        double l1 = Math.sqrt(c1x * c1x + c1y * c1y + c1z * c1z);
        double l2 = Math.sqrt(c2x * c2x + c2y * c2y + c2z * c2z);
        s = (l0 + l1 + l2) / 3.0;
        if (!(s > 1.0E-9) || Double.isNaN(s)) {
            identity();
            tx = px; ty = py; tz = pz;
            return this;
        }
        // Gram-Schmidt: x, lalu y tegak lurus x, lalu z = x × y
        double ax = c0x / l0, ay = c0y / l0, az = c0z / l0;
        double d = c1x * ax + c1y * ay + c1z * az;
        double bx = c1x - d * ax, by = c1y - d * ay, bz = c1z - d * az;
        double lb = Math.sqrt(bx * bx + by * by + bz * bz);
        if (lb < 1.0E-9) {
            identity();
            tx = px; ty = py; tz = pz;
            return this;
        }
        bx /= lb; by /= lb; bz /= lb;
        double cx = ay * bz - az * by, cy = az * bx - ax * bz, cz = ax * by - ay * bx;
        r00 = ax; r01 = bx; r02 = cx;
        r10 = ay; r11 = by; r12 = cy;
        r20 = az; r21 = bz; r22 = cz;
        tx = px; ty = py; tz = pz;
        return this;
    }

    /** this = a · b (b dulu, lalu a). Aman walau out sama dengan a atau b. */
    public Xform mul(Xform a, Xform b) {
        double n00 = a.r00 * b.r00 + a.r01 * b.r10 + a.r02 * b.r20;
        double n01 = a.r00 * b.r01 + a.r01 * b.r11 + a.r02 * b.r21;
        double n02 = a.r00 * b.r02 + a.r01 * b.r12 + a.r02 * b.r22;
        double n10 = a.r10 * b.r00 + a.r11 * b.r10 + a.r12 * b.r20;
        double n11 = a.r10 * b.r01 + a.r11 * b.r11 + a.r12 * b.r21;
        double n12 = a.r10 * b.r02 + a.r11 * b.r12 + a.r12 * b.r22;
        double n20 = a.r20 * b.r00 + a.r21 * b.r10 + a.r22 * b.r20;
        double n21 = a.r20 * b.r01 + a.r21 * b.r11 + a.r22 * b.r21;
        double n22 = a.r20 * b.r02 + a.r21 * b.r12 + a.r22 * b.r22;
        double ntx = a.tx + a.s * (a.r00 * b.tx + a.r01 * b.ty + a.r02 * b.tz);
        double nty = a.ty + a.s * (a.r10 * b.tx + a.r11 * b.ty + a.r12 * b.tz);
        double ntz = a.tz + a.s * (a.r20 * b.tx + a.r21 * b.ty + a.r22 * b.tz);
        double ns = a.s * b.s;
        r00 = n00; r01 = n01; r02 = n02;
        r10 = n10; r11 = n11; r12 = n12;
        r20 = n20; r21 = n21; r22 = n22;
        tx = ntx; ty = nty; tz = ntz;
        s = ns;
        return this;
    }

    /** this = kebalikan dari a. */
    public Xform invert(Xform a) {
        double is = 1.0 / a.s;
        double n00 = a.r00, n01 = a.r10, n02 = a.r20;
        double n10 = a.r01, n11 = a.r11, n12 = a.r21;
        double n20 = a.r02, n21 = a.r12, n22 = a.r22;
        double ntx = -is * (n00 * a.tx + n01 * a.ty + n02 * a.tz);
        double nty = -is * (n10 * a.tx + n11 * a.ty + n12 * a.tz);
        double ntz = -is * (n20 * a.tx + n21 * a.ty + n22 * a.tz);
        r00 = n00; r01 = n01; r02 = n02;
        r10 = n10; r11 = n11; r12 = n12;
        r20 = n20; r21 = n21; r22 = n22;
        tx = ntx; ty = nty; tz = ntz;
        s = is;
        return this;
    }

    /** this = this · translasi(x, y, z). */
    public Xform translate(double x, double y, double z) {
        tx += s * (r00 * x + r01 * y + r02 * z);
        ty += s * (r10 * x + r11 * y + r12 * z);
        tz += s * (r20 * x + r21 * y + r22 * z);
        return this;
    }

    /** this = this · putar X(a). */
    public Xform rotateX(double a) {
        double c = Math.cos(a), sn = Math.sin(a);
        double n01 = r01 * c + r02 * sn, n02 = -r01 * sn + r02 * c;
        double n11 = r11 * c + r12 * sn, n12 = -r11 * sn + r12 * c;
        double n21 = r21 * c + r22 * sn, n22 = -r21 * sn + r22 * c;
        r01 = n01; r02 = n02; r11 = n11; r12 = n12; r21 = n21; r22 = n22;
        return this;
    }

    /** this = this · putar Y(a). */
    public Xform rotateY(double a) {
        double c = Math.cos(a), sn = Math.sin(a);
        double n00 = r00 * c - r02 * sn, n02 = r00 * sn + r02 * c;
        double n10 = r10 * c - r12 * sn, n12 = r10 * sn + r12 * c;
        double n20 = r20 * c - r22 * sn, n22 = r20 * sn + r22 * c;
        r00 = n00; r02 = n02; r10 = n10; r12 = n12; r20 = n20; r22 = n22;
        return this;
    }

    /** this = this · putar Z(a). */
    public Xform rotateZ(double a) {
        double c = Math.cos(a), sn = Math.sin(a);
        double n00 = r00 * c + r01 * sn, n01 = -r00 * sn + r01 * c;
        double n10 = r10 * c + r11 * sn, n11 = -r10 * sn + r11 * c;
        double n20 = r20 * c + r21 * sn, n21 = -r20 * sn + r21 * c;
        r00 = n00; r01 = n01; r10 = n10; r11 = n11; r20 = n20; r21 = n21;
        return this;
    }

    @Override
    public void toWorld(double[] p) {
        double x = p[0], y = p[1], z = p[2];
        p[0] = tx + s * (r00 * x + r01 * y + r02 * z);
        p[1] = ty + s * (r10 * x + r11 * y + r12 * z);
        p[2] = tz + s * (r20 * x + r21 * y + r22 * z);
    }

    @Override
    public void toLocal(double[] p) {
        double x = p[0] - tx, y = p[1] - ty, z = p[2] - tz;
        double is = 1.0 / s;
        p[0] = is * (r00 * x + r10 * y + r20 * z);
        p[1] = is * (r01 * x + r11 * y + r21 * z);
        p[2] = is * (r02 * x + r12 * y + r22 * z);
    }

    /** Arah (tanpa skala) lokal -> dunia. */
    public void dirToWorld(double[] d) {
        double x = d[0], y = d[1], z = d[2];
        d[0] = r00 * x + r01 * y + r02 * z;
        d[1] = r10 * x + r11 * y + r12 * z;
        d[2] = r20 * x + r21 * y + r22 * z;
    }

    /** Arah (tanpa skala) dunia -> lokal. */
    public void dirToLocal(double[] d) {
        double x = d[0], y = d[1], z = d[2];
        d[0] = r00 * x + r10 * y + r20 * z;
        d[1] = r01 * x + r11 * y + r21 * z;
        d[2] = r02 * x + r12 * y + r22 * z;
    }

    /**
     * Kecepatan sudut (rad per satuan waktu h) dari putaran prev ke this, dinyatakan di ruang lokal this.
     * out = sumbu × sudut / h.
     */
    public void angularVelocity(Xform prev, double h, double[] out) {
        // Q = R_prevᵀ · R
        double q00 = prev.r00 * r00 + prev.r10 * r10 + prev.r20 * r20;
        double q01 = prev.r00 * r01 + prev.r10 * r11 + prev.r20 * r21;
        double q02 = prev.r00 * r02 + prev.r10 * r12 + prev.r20 * r22;
        double q10 = prev.r01 * r00 + prev.r11 * r10 + prev.r21 * r20;
        double q11 = prev.r01 * r01 + prev.r11 * r11 + prev.r21 * r21;
        double q12 = prev.r01 * r02 + prev.r11 * r12 + prev.r21 * r22;
        double q20 = prev.r02 * r00 + prev.r12 * r10 + prev.r22 * r20;
        double q21 = prev.r02 * r01 + prev.r12 * r11 + prev.r22 * r21;
        double q22 = prev.r02 * r02 + prev.r12 * r12 + prev.r22 * r22;
        double vx = q21 - q12, vy = q02 - q20, vz = q10 - q01;
        double sin2 = Math.sqrt(vx * vx + vy * vy + vz * vz);   // 2 sin(sudut)
        double cos2 = q00 + q11 + q22 - 1.0;                    // 2 cos(sudut)
        double angle = Math.atan2(sin2, cos2);
        if (sin2 < 1.0E-12) {
            out[0] = 0; out[1] = 0; out[2] = 0;
            return;
        }
        double k = angle / (sin2 * h);
        out[0] = vx * k; out[1] = vy * k; out[2] = vz * k;
    }
}
