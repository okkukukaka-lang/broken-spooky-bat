package com.shazammod.client.vfx;

import java.util.Random;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/** Lingkaran sihir: lingkaran rune berputar dan tanda sasaran Mata Solomon. */
public final class Runes {
    private Runes() {}

    /** Bentuk huruf rune: tiap huruf 3-4 goresan di kisi 3x3 (acak tapi tetap untuk benih yang sama). */
    static float[][] glyphs(int count, long seed) {
        Random random = new Random(seed);
        float[][] out = new float[count][];
        for (int g = 0; g < count; g++) {
            int strokes = 3 + random.nextInt(2);
            float[] s = new float[strokes * 4];
            int px = random.nextInt(3) - 1, py = random.nextInt(3) - 1;
            for (int k = 0; k < strokes; k++) {
                int qx, qy;
                do {
                    qx = random.nextInt(3) - 1;
                    qy = random.nextInt(3) - 1;
                } while (qx == px && qy == py);
                s[k * 4] = px; s[k * 4 + 1] = py; s[k * 4 + 2] = qx; s[k * 4 + 3] = qy;
                if (random.nextInt(3) > 0) {   // goresan bersambung
                    px = qx;
                    py = qy;
                } else {
                    px = random.nextInt(3) - 1;
                    py = random.nextInt(3) - 1;
                }
            }
            out[g] = s;
        }
        return out;
    }

    /**
     * Lingkaran rune: cincin bertingkat, garis-garis sisir, busur putus-putus yang berputar, huruf-huruf rune
     * yang berputar berlawanan, dan bintang segi enam di tengah. Muncul memantul lalu memudar.
     */
    public static final class Circle extends Effect {
        private final Lightning.Anchor center;
        private final double nx, ny, nz;
        private final double radius;
        private final int rgb;
        private final float spin;
        private final Draw.Height ground;
        private final float[][] glyphs;
        private final float strength;

        public Circle(Lightning.Anchor center, Vec3 normal, double radius, int rgb, int life, float spin, float strength,
                      Draw.Height ground) {
            super(life);
            this.center = center;
            Vec3 n = normal.normalize();
            this.nx = n.x; this.ny = n.y; this.nz = n.z;
            this.radius = radius;
            this.rgb = rgb;
            this.spin = spin;
            this.ground = ground;
            this.strength = strength;
            this.glyphs = glyphs(12, Vfx.random().nextLong());
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            float time = age + pt;
            float appear = Math.min(1f, time / 8f);
            float scale = (float) (1.0 + 0.18 * Math.sin(Math.PI * appear)) * Fx.outCubic(appear);
            float fade = Math.min(1f, (life - time) / 10f);
            float a = strength * fade * (0.85f + 0.15f * (float) Math.sin(time * 0.4f));
            if (a <= 0.01f || scale <= 0.01f) {
                return;
            }
            Vec3 c = center.at(pt);
            double r = radius * scale;
            double[] e = new double[6];
            Draw.plane(nx, ny, nz, e);
            // cincin
            d.ring(c.x, c.y, c.z, nx, ny, nz, r, 0.085 * scale, rgb, a, 0.1f, ground);
            d.ring(c.x, c.y, c.z, nx, ny, nz, r * 0.8, 0.055 * scale, rgb, a * 0.85f, 0f, ground);
            d.ring(c.x, c.y, c.z, nx, ny, nz, r * 0.4, 0.05 * scale, rgb, a * 0.75f, 0f, ground);
            // sisir di tepi luar
            float rot = time * spin;
            for (int k = 0; k < 36; k++) {
                double ang = Math.PI * 2.0 * k / 36 + rot * 0.3;
                double len = k % 3 == 0 ? 0.12 : 0.06;
                line(d, c, e, ang, r * 1.02, ang, r * 1.02 + len * scale, 0.035f * scale, a * 0.85f);
            }
            // busur putus-putus yang berputar
            for (int k = 0; k < 10; k++) {
                double a0 = Math.PI * 2.0 * k / 10 + rot, a1 = a0 + Math.PI * 2.0 / 10 * 0.6;
                int seg = 4;
                for (int j = 0; j < seg; j++) {
                    double b0 = a0 + (a1 - a0) * j / seg, b1 = a0 + (a1 - a0) * (j + 1) / seg;
                    line(d, c, e, b0, r * 0.9, b1, r * 0.9, 0.066f * scale, a * 0.95f);
                }
            }
            // huruf rune berputar berlawanan, di antara cincin 0,8 dan 0,4
            double gr = r * 0.6, gs = r * 0.075;
            for (int g = 0; g < glyphs.length; g++) {
                double ang = Math.PI * 2.0 * g / glyphs.length - rot * 0.6;
                float[] s = glyphs[g];
                float flick = 0.7f + 0.3f * (float) Math.sin(time * 0.5f + g * 1.3f);
                for (int k = 0; k + 3 < s.length; k += 4) {
                    double[] p0 = glyphPoint(c, e, ang, gr, gs, s[k], s[k + 1]);
                    double[] p1 = glyphPoint(c, e, ang, gr, gs, s[k + 2], s[k + 3]);
                    d.flatLine(p0[0], p0[1], p0[2], p1[0], p1[1], p1[2], nx, ny, nz, (float) (0.048 * scale), rgb, a * flick, a * flick);
                }
            }
            // bintang segi enam di tengah (dua segitiga berputar berlawanan)
            for (int tri = 0; tri < 2; tri++) {
                double base = (tri == 0 ? rot : -rot) * 0.8 + tri * Math.PI / 3.0;
                for (int k = 0; k < 3; k++) {
                    double a0 = base + Math.PI * 2.0 * k / 3, a1 = base + Math.PI * 2.0 * (k + 1) / 3;
                    line(d, c, e, a0, r * 0.4, a1, r * 0.4, 0.048f * scale, a * 0.8f);
                }
            }
            d.glow(c.x + nx * 0.05, c.y + ny * 0.05, c.z + nz * 0.05, (float) (r * 0.55), rgb, a * 0.2f);
        }

        private double[] glyphPoint(Vec3 c, double[] e, double ang, double gr, double gs, float gx, float gy) {
            double cos = Math.cos(ang), sin = Math.sin(ang);
            // arah keluar (radial) dan arah singgung di bidang lingkaran
            double rx = e[0] * cos + e[3] * sin, ry = e[1] * cos + e[4] * sin, rz = e[2] * cos + e[5] * sin;
            double tx = -e[0] * sin + e[3] * cos, ty = -e[1] * sin + e[4] * cos, tz = -e[2] * sin + e[5] * cos;
            double x = c.x + rx * (gr + gy * gs) + tx * gx * gs;
            double y = c.y + ry * (gr + gy * gs) + ty * gx * gs;
            double z = c.z + rz * (gr + gy * gs) + tz * gx * gs;
            if (ground != null) {
                y += ground.at(Math.atan2(z - c.z, x - c.x), Math.hypot(x - c.x, z - c.z));
            }
            return new double[] {x, y, z};
        }

        private void line(Draw d, Vec3 c, double[] e, double a0, double r0, double a1, double r1, float width, float a) {
            double x0 = c.x + (e[0] * Math.cos(a0) + e[3] * Math.sin(a0)) * r0;
            double y0 = c.y + (e[1] * Math.cos(a0) + e[4] * Math.sin(a0)) * r0;
            double z0 = c.z + (e[2] * Math.cos(a0) + e[5] * Math.sin(a0)) * r0;
            double x1 = c.x + (e[0] * Math.cos(a1) + e[3] * Math.sin(a1)) * r1;
            double y1 = c.y + (e[1] * Math.cos(a1) + e[4] * Math.sin(a1)) * r1;
            double z1 = c.z + (e[2] * Math.cos(a1) + e[5] * Math.sin(a1)) * r1;
            if (ground != null) {
                y0 += ground.at(Math.atan2(z0 - c.z, x0 - c.x), Math.hypot(x0 - c.x, z0 - c.z));
                y1 += ground.at(Math.atan2(z1 - c.z, x1 - c.x), Math.hypot(x1 - c.x, z1 - c.z));
            }
            d.flatLine(x0, y0, z0, x1, y1, z1, nx, ny, nz, width, rgb, a, a);
        }
    }

    /** Tanda sasaran di musuh yang "terbaca" Mata Solomon: sudut-sudut bidik berputar dan segitiga di tengah. */
    public static final class Reticle extends Effect {
        private final Entity target;
        private final int rgb;
        private final int delay;

        public Reticle(Entity target, int rgb, int life, int delay) {
            super(life + delay);
            this.target = target;
            this.rgb = rgb;
            this.delay = delay;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return target.isAlive() && !target.isRemoved() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = age + d.partialTick - delay;
            if (time < 0f) {
                return;
            }
            float appear = Math.min(1f, time / 6f);
            float fade = Math.min(1f, (life - delay - time) / 12f);
            float a = fade * (0.75f + 0.25f * (float) Math.sin(time * 0.3f));
            Vec3 p = target.getPosition(d.partialTick).add(0, target.getBbHeight() * 0.55, 0);
            double vx = d.camX - p.x, vy = d.camY - p.y, vz = d.camZ - p.z;
            double vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
            if (vl < 0.5) {
                return;
            }
            vx /= vl; vy /= vl; vz /= vl;
            // sedikit ke arah kamera supaya nggak tenggelam di badan musuh
            double cx = p.x + vx * target.getBbWidth() * 0.7, cy = p.y + vy * target.getBbWidth() * 0.7, cz = p.z + vz * target.getBbWidth() * 0.7;
            double r = Math.max(target.getBbWidth(), target.getBbHeight()) * 0.62 * (1.0 + 0.6 * (1.0 - Fx.outCubic(appear)));
            double[] e = new double[6];
            Draw.plane(vx, vy, vz, e);
            float w = (float) Math.max(0.05, r * 0.065);
            double rot = time * 0.06;
            // empat sudut bidik
            for (int k = 0; k < 4; k++) {
                double mid = rot + k * Math.PI / 2.0 + Math.PI / 4.0;
                for (int j = -2; j < 2; j++) {
                    double a0 = mid + j * 0.12, a1 = mid + (j + 1) * 0.12;
                    seg(d, cx, cy, cz, e, vx, vy, vz, a0, r, a1, r, w, a);
                }
            }
            // segitiga berputar berlawanan di dalam
            for (int k = 0; k < 3; k++) {
                double a0 = -rot * 1.6 + Math.PI * 2.0 * k / 3, a1 = -rot * 1.6 + Math.PI * 2.0 * (k + 1) / 3;
                seg(d, cx, cy, cz, e, vx, vy, vz, a0, r * 0.45, a1, r * 0.45, w * 0.8f, a * 0.8f);
            }
            d.glow(cx, cy, cz, (float) (r * 0.25), rgb, a * 0.5f);
        }

        private void seg(Draw d, double cx, double cy, double cz, double[] e, double nx, double ny, double nz,
                         double a0, double r0, double a1, double r1, float w, float a) {
            double x0 = cx + (e[0] * Math.cos(a0) + e[3] * Math.sin(a0)) * r0;
            double y0 = cy + (e[1] * Math.cos(a0) + e[4] * Math.sin(a0)) * r0;
            double z0 = cz + (e[2] * Math.cos(a0) + e[5] * Math.sin(a0)) * r0;
            double x1 = cx + (e[0] * Math.cos(a1) + e[3] * Math.sin(a1)) * r1;
            double y1 = cy + (e[1] * Math.cos(a1) + e[4] * Math.sin(a1)) * r1;
            double z1 = cz + (e[2] * Math.cos(a1) + e[5] * Math.sin(a1)) * r1;
            d.flatLine(x0, y0, z0, x1, y1, z1, nx, ny, nz, w, rgb, a, a);
        }
    }
}
