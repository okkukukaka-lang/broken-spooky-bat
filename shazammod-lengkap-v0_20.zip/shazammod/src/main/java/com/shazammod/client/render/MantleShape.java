package com.shazammod.client.render;

/**
 * Mantel bahu (murni Java, gampang diuji): kain pendek yang melingkari pangkal kepala lalu jatuh menutupi
 * bahu, dada atas, dan punggung atas. Mantel ini yang menyatukan hood dan jubah jadi satu pakaian:
 * - tepi bawah hood masuk sedikit ke dalam kerah mantel, jadi hood terlihat dijahit ke mantel;
 * - tepi depan mantel muncul tepat di bawah rahang hood, jadi list emas bingkai wajah bersambung
 *   ke list emas tepi depan mantel;
 * - bagian atas jubah tersembunyi di bawah mantel di punggung.
 *
 * Ruang leher: titik nol di poros leher, +Y ke atas, depan = -Z, satuan blok (sebelum dikali ukuran badan),
 * sudah ikut condong badan (misalnya saat jongkok). Lihat BodyRig.neck.
 *
 * Fisikanya (di Cloak): kerah dipaku, sisanya kain sungguhan yang ditahan dekat bentuk pakainya (jarak
 * maksimum + backstop + tarikan pelan), menabrak badan dan kedua lengan, dan selalu di luar bagian atas jubah.
 * Bagian di atas bahu ikut terangkat bersama lengan (seperti kain yang menumpang di bahu).
 * Grid: kolom mengelilingi leher dari tepi depan kiri, lewat bahu kiri, punggung, bahu kanan, ke tepi depan kanan.
 * Baris dari kerah (baris 0, dipaku) ke ujung bawah mantel.
 */
public final class MantleShape {
    private MantleShape() {}

    public static final int COLS = 23;
    public static final int ROWS = 5;

    // ======= Kerah (kotak membulat melingkari pangkal kepala, sedikit di luar tepi bawah hood) =======
    public static final double COLLAR_HALF = 0.334;
    public static final double COLLAR_FRONT = 0.292;
    public static final double COLLAR_BACK = 0.348;
    public static final double COLLAR_Y = 0.014;
    public static final double OPEN_ANGLE = 158.0;    // kolom terluar di ±150° dari punggung: bagian depan terbuka

    // ======= Panjang mantel (turun dari kerah, blok) =======
    public static final double LENGTH_FRONT = 0.31;
    public static final double LENGTH_SIDE = 0.34;
    public static final double LENGTH_BACK = 0.41;
    public static final double BACK_POINT = 0.07;     // ujung lancip di tengah punggung

    // ======= Badan di bawah mantel (relatif leher; kulit + lapisan luar skin) =======
    public static final double ARM_OUTER_X = 0.484;   // sisi luar lengan
    public static final double BODY_Z = 0.132;        // dada / punggung
    public static final double SHOULDER_TOP = 0.0146; // atas bahu
    public static final double CAPE_TOP_Z = 0.17;     // tepi atas jubah di punggung
    public static final double CAPE_CLEAR = 0.035;    // mantel tetap sejauh ini di luar jubah

    // ======= Bahan dan bentuk pakai =======
    public static final double DENSITY = 0.6;          // kg/m²
    private static final double SHEAR = 1.0E-4;
    private static final double BEND = 0.004;          // lebih kaku dari jubah (wol tebal yang dibentuk)
    private static final double COMPRESS = 0.001;
    /**
     * Jarak maksimum dari bentuk pakai tiap baris (blok): kerah dipaku, ujung bawah paling bebas berkibar.
     * Ini cuma jaring pengaman; bentuknya dijaga tarikan pelan + backstop, dan lengan atau jubah boleh mendorongnya.
     */
    private static final double[] MAX_DIST = {0.0, 0.12, 0.2, 0.28, 0.36};
    /** Tarikan pelan ke bentuk pakai (per detik): kain yang dijahit berbentuk, bukan kain lemas. */
    private static final double[] DRIVE = {0.0, 5.0, 3.5, 2.2, 1.4};
    /** Seberapa jauh boleh masuk ke arah badan dari bentuk pakai (blok). */
    private static final double[] BACKSTOP = {0.0, 0.02, 0.04, 0.06, 0.08};
    /** Seberapa banyak bagian bahu ikut lengan (0-1), per baris. Lengan diangkat = kain bahu ikut terangkat. */
    private static final double[] ARM_FOLLOW = {0.0, 0.3, 0.55, 0.7, 0.8};
    /** Bagian bahu paling jauh digeser lengan sejauh ini (blok), supaya lengan yang diangkat tinggi nggak menarik kain lepas. */
    public static final double ARM_REACH = 0.22;

    /** Bentuk mantel saat diam (ruang leher). */
    public static final double[] REST_X = new double[COLS * ROWS];
    public static final double[] REST_Y = new double[COLS * ROWS];
    public static final double[] REST_Z = new double[COLS * ROWS];
    /** Seberapa banyak tiap titik ikut lengan di sisinya (0 = ikut leher saja). */
    public static final double[] ARM_WEIGHT = new double[COLS * ROWS];

    // ======= Hiasan (posisi di grid kain; kolom/baris boleh pecahan) =======
    /** Pelat emas bahu kiri: kolom {awal, akhir}. Bahu kanan dicerminkan. */
    public static final float[] PLATE_COLS = {3.4f, 5.7f};
    /** Tiga lempeng bertumpuk, atas ke bawah: baris {awal, akhir}. */
    public static final float[][] PLATE_ROWS = {{0.62f, 1.72f}, {1.45f, 2.42f}, {2.15f, 3.02f}};
    /** Bros pengait di tepi depan kiri (kanan dicerminkan): kolom dan baris. */
    public static final float CLASP_COL = 0.62f;
    public static final float CLASP_ROW = 0.7f;

    static double smooth(double k) {
        k = Math.max(0.0, Math.min(1.0, k));
        return k * k * (3.0 - 2.0 * k);
    }

    /** Akar bertanda: superelips n=4 (kotak membulat). */
    private static double sroot(double v) {
        return Math.copySign(Math.sqrt(Math.abs(v)), v);
    }

    /** Sudut kolom c dari tengah punggung (radian): negatif = kiri. */
    public static double angle(double c) {
        return Math.toRadians((c / (COLS - 1.0) - 0.5) * 2.0 * OPEN_ANGLE);
    }

    static {
        for (int c = 0; c < COLS; c++) {
            double phi = angle(c);
            double s = Math.sin(phi), co = Math.cos(phi);
            double nx = COLLAR_HALF * sroot(s);
            double nz = (co >= 0 ? COLLAR_BACK : COLLAR_FRONT) * sroot(co);
            double len = Math.hypot(nx, nz);
            double dx = nx / len, dz = nz / len;
            // kerah tepat di atas lengan (bukan di depan/belakang badan): mantel melewati atas bahu
            double shoulder = smooth((0.24 - Math.abs(nz)) / 0.12) * smooth((Math.abs(nx) - 0.20) / 0.08);
            double length = LENGTH_SIDE + (LENGTH_BACK - LENGTH_SIDE) * Math.max(0.0, co)
                    + (LENGTH_FRONT - LENGTH_SIDE) * Math.max(0.0, -co) + BACK_POINT * Math.pow(Math.max(0.0, co), 12);

            // (a) di atas bahu: mendatar melewati atas lengan, lalu turun di sisi luar lengan
            double sideX = Math.copySign(ARM_OUTER_X + 0.034, nx);
            double[] ax = {nx, nx + (sideX - nx) * 0.52, sideX - Math.copySign(0.004, nx), sideX + Math.copySign(0.018, nx),
                    sideX + Math.copySign(0.05, nx)};
            double[] ay = {COLLAR_Y, SHOULDER_TOP + 0.024, SHOULDER_TOP + 0.002, -0.46 * length, -length};
            double[] az = {nz, nz * 0.97, nz * 0.93, nz * 0.95, nz * 1.0};

            // (b) di depan/belakang badan: jatuh lalu merapat ke dada, atau ke punggung (tetap di luar jubah)
            double hemZ = co >= 0 ? Math.max(BODY_Z + 0.05, CAPE_TOP_Z + CAPE_CLEAR + 0.01) : -(BODY_Z + 0.03);
            double hx = nx + dx * 0.04;
            double hz = nz + (hemZ - nz) * smooth(Math.abs(dz) * 1.3);
            double[] bx = {nx, nx + dx * 0.016, nx + (hx - nx) * 0.45 + dx * 0.012, nx + (hx - nx) * 0.78, hx};
            double[] by = {COLLAR_Y, COLLAR_Y - 0.07, -0.42 * length, -0.72 * length, -length};
            double[] bz = {nz, nz + dz * 0.016, nz + (hz - nz) * 0.45 + dz * 0.012, nz + (hz - nz) * 0.78, hz};

            for (int r = 0; r < ROWS; r++) {
                int i = r * COLS + c;
                REST_X[i] = bx[r] + (ax[r] - bx[r]) * shoulder;
                REST_Y[i] = by[r] + (ay[r] - by[r]) * shoulder;
                REST_Z[i] = bz[r] + (az[r] - bz[r]) * shoulder;
                ARM_WEIGHT[i] = ARM_FOLLOW[r] * shoulder;
            }
        }
    }

    public static ClothSim create() {
        ClothSim sim = new ClothSim(COLS, ROWS, REST_X, REST_Y, REST_Z, DENSITY);
        for (int c = 0; c < COLS; c++) {
            sim.pin(c);
        }
        sim.addGridLinks(0.0, SHEAR, BEND);
        sim.compressCompliance = COMPRESS;
        sim.buildTethers(3, 1.02);
        for (int i = COLS; i < sim.count; i++) {
            int r = i / COLS;
            sim.maxDist[i] = MAX_DIST[r];
            sim.drive[i] = DRIVE[r];
            sim.backstop[i] = BACKSTOP[r];
        }
        return sim;
    }

    /** Rantai tepi mantel: tepi depan kiri (kerah -> bawah), ujung bawah (kiri -> kanan), tepi depan kanan (bawah -> kerah). */
    public static int[] edgeChain(int cols, int rows) {
        return ClothDecor.capeChain(cols, rows);
    }

    /** Rantai kerah (atas): dari tepi depan kiri ke tepi depan kanan. */
    public static int[] collarChain(int cols) {
        int[] chain = new int[cols];
        for (int c = 0; c < cols; c++) {
            chain[c] = c;
        }
        return chain;
    }
}
