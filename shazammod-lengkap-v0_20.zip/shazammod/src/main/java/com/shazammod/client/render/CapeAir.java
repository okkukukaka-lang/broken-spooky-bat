package com.shazammod.client.render;

/**
 * Udara di sekitar jubah, mantel, dan hood (murni Java), dalam satuan dunia nyata (meter, detik):
 * - angin sekitar yang arahnya berubah pelan dan berembus (lebih kencang saat hujan dan badai);
 * - "bayangan angin" (wake) di belakang badan: udara tepat di belakang badan yang bergerak ikut terseret badan,
 *   jadi kain di situ menerima aliran yang lebih pelan. Dihitung dengan menelusuri arah datangnya angin dari
 *   tiap titik kain: kalau terhalang badan atau kepala, titik itu terlindung (makin dekat makin terlindung);
 * - turbulensi: pusaran udara yang terbawa aliran (lebih kuat di dalam wake), sumber kibaran alami seperti
 *   bendera. Kecepatan pusaran dibatasi supaya kibarannya tetap terlihat (nggak jadi getar acak) di FPS biasa.
 */
public final class CapeAir {
    private CapeAir() {}

    // ======= Udara =======
    public static final double AIR_DENSITY = 1.225;      // kg/m³
    public static final double WATER_DENSITY = 1000.0;   // kg/m³
    // ======= Angin sekitar (m/s) =======
    public static final double BREEZE = 1.4;
    public static final double RAIN = 2.2;       // pengali saat hujan
    public static final double THUNDER = 3.5;    // pengali saat badai
    // ======= Wake di belakang badan =======
    private static final double SHELTER = 0.7;          // tepat di belakang badan, udara ikut bergerak 70% kecepatan badan
    private static final double WAKE_LENGTH = 1.3;      // makin jauh, makin hilang (m)
    // ======= Turbulensi =======
    private static final double TURBULENCE_FREE = 0.05;  // intensitas di udara bebas (simpangan / kecepatan aliran)
    private static final double TURBULENCE_WAKE = 0.32;  // di dalam wake
    private static final double EDDY_CONVECTION = 0.65;  // pusaran terbawa 65% kecepatan aliran
    private static final double MAX_EDDY_SPEED = 13.0;   // m/s
    private static final double MAX_TURBULENCE = 9.0;    // m/s

    // Penghalang angin (ruang badan, satuan blok sebelum skala): badan+kaki, dan kepala (dengan hood)
    private static final double[][] OCCLUDERS = {
            {0.0, 0.72, 0.0, 0.26, 0.72, 0.14},
            {0.0, 1.645, 0.0, 0.28, 0.27, 0.28}};

    // Pusaran: {kx, ky, kz (arah gelombang, satuan), panjang gelombang (m), arah dorong x, y, z, amplitudo, fase}
    private static final double[][] EDDIES = {
            {0.62, 0.55, 0.56, 1.45, 0.71, -0.20, -0.67, 0.50, 0.3},
            {-0.48, 0.80, 0.36, 1.05, 0.09, 0.42, -0.90, 0.42, 2.1},
            {0.30, -0.36, 0.88, 0.80, -0.86, -0.50, 0.10, 0.36, 4.0},
            {-0.75, -0.30, 0.59, 0.62, 0.36, 0.89, 0.27, 0.30, 1.2},
            {0.12, 0.95, -0.29, 0.47, -0.95, 0.06, -0.31, 0.24, 5.3},
            {0.88, -0.10, -0.46, 0.36, 0.20, 0.97, 0.15, 0.18, 3.4}};
    private static final double EDDY_NORM;

    static {
        double sum = 0.0;
        for (double[] e : EDDIES) {
            sum += e[7] * e[7] * 0.5;
        }
        EDDY_NORM = 1.0 / Math.sqrt(sum);
    }

    /** Angin sekitar (dunia, m/s) pada waktu t (detik). strength: 0 = di dalam ruangan, 1 = cerah, lebih besar = hujan/badai. */
    public static void ambient(double t, double strength, double[] out) {
        double tick = t * 20.0;
        double angle = 0.9 + 0.8 * Math.sin(tick * 0.00031) + 0.35 * Math.sin(tick * 0.0013 + 2.0);
        double gust = 0.55 + 0.3 * Math.sin(tick * 0.021) * Math.sin(tick * 0.0067 + 1.3) + 0.15 * Math.sin(tick * 0.053 + 0.7);
        double speed = BREEZE * strength * Math.max(0.2, gust);
        out[0] = Math.cos(angle) * speed;
        out[1] = 0.0;
        out[2] = Math.sin(angle) * speed;
    }

    /**
     * Isi kecepatan udara relatif bingkai di tiap titik kain (sim.air*, satuan lokal per detik).
     *
     * @param flow   kecepatan udara bebas relatif ke titik asal bingkai (lokal, satuan lokal/s) = Rᵀ(angin - v_bingkai)/s
     * @param omega  kecepatan sudut bingkai (lokal, rad/s; sudah dibatasi)
     * @param toBody ruang kain -> ruang badan (kaku), buat menghitung wake dan pusaran
     * @param scale  ukuran badan (lokal -> meter)
     * @param time   detik (buat turbulensi)
     * @param turbulence pengali turbulensi (0 = tanpa, misalnya di dalam air)
     */
    public static void fill(ClothSim sim, double[] flow, double[] omega, Xform toBody, double scale, double time,
                            double turbulence) {
        double fx = flow[0], fy = flow[1], fz = flow[2];
        double speedLocal = Math.sqrt(fx * fx + fy * fy + fz * fz);
        double speed = speedLocal * scale;   // m/s
        // arah datangnya angin (hulu), di ruang badan
        double[] up = {-fx, -fy, -fz};
        toBody.dirToWorld(up);
        if (speedLocal > 1.0E-9) {
            up[0] /= speedLocal; up[1] /= speedLocal; up[2] /= speedLocal;
        }
        double eddySpeed = Math.min(speed * EDDY_CONVECTION, MAX_EDDY_SPEED);
        double[] p = new double[3], d = new double[3];
        for (int i = 0; i < sim.count; i++) {
            double rX = sim.x[i], rY = sim.y[i], rZ = sim.z[i];
            // udara relatif titik bingkai ini: aliran bebas dikurangi putaran bingkai
            double ux = fx - (omega[1] * rZ - omega[2] * rY);
            double uy = fy - (omega[2] * rX - omega[0] * rZ);
            double uz = fz - (omega[0] * rY - omega[1] * rX);
            p[0] = rX; p[1] = rY; p[2] = rZ;
            toBody.toWorld(p);
            double shelter = speedLocal > 1.0E-6 ? shelter(p, up) : 0.0;
            double keep = 1.0 - shelter;
            ux *= keep; uy *= keep; uz *= keep;
            if (turbulence > 0.0 && speed > 0.05) {
                double intensity = TURBULENCE_FREE + (TURBULENCE_WAKE - TURBULENCE_FREE) * (shelter / SHELTER);
                double amp = Math.min(intensity * speed, MAX_TURBULENCE) * turbulence * EDDY_NORM / scale;
                double tx = 0, ty = 0, tz = 0;
                double mx = p[0] * scale, my = p[1] * scale, mz = p[2] * scale;   // meter, ruang badan
                for (double[] e : EDDIES) {
                    double k = 2.0 * Math.PI / e[3];
                    double phase = k * (e[0] * mx + e[1] * my + e[2] * mz) - k * eddySpeed * time + e[8];
                    double a = sin(phase) * e[7];
                    tx += e[4] * a; ty += e[5] * a; tz += e[6] * a;
                }
                d[0] = tx * amp; d[1] = ty * amp; d[2] = tz * amp;
                toBody.dirToLocal(d);
                ux += d[0]; uy += d[1]; uz += d[2];
            }
            sim.airX[i] = ux; sim.airY[i] = uy; sim.airZ[i] = uz;
        }
    }

    /** Sinus cepat (galat < 0,001), cukup untuk pusaran udara. */
    static double sin(double x) {
        x = x - 2.0 * Math.PI * Math.floor(x / (2.0 * Math.PI) + 0.5);   // ke -PI..PI
        double y = 1.2732395447351628 * x - 0.4052847345693511 * x * Math.abs(x);
        return 0.225 * (y * Math.abs(y) - y) + y;
    }

    /** 0..SHELTER: seberapa terlindung titik p (ruang badan) dari angin yang datang dari arah up. */
    static double shelter(double[] p, double[] up) {
        double best = Double.POSITIVE_INFINITY;
        for (double[] b : OCCLUDERS) {
            double t = ray(p, up, b);
            if (t < best) {
                best = t;
            }
        }
        if (best == Double.POSITIVE_INFINITY) {
            return 0.0;
        }
        return SHELTER * Math.max(0.0, 1.0 - best / WAKE_LENGTH);
    }

    /** Jarak dari p menyusuri arah d sampai mengenai kotak b, atau tak hingga. 0 kalau p di dalam kotak. */
    private static double ray(double[] p, double[] d, double[] b) {
        double tmin = 0.0, tmax = Double.POSITIVE_INFINITY;
        for (int k = 0; k < 3; k++) {
            double lo = b[k] - b[k + 3], hi = b[k] + b[k + 3];
            if (Math.abs(d[k]) < 1.0E-9) {
                if (p[k] < lo || p[k] > hi) {
                    return Double.POSITIVE_INFINITY;
                }
            } else {
                double t1 = (lo - p[k]) / d[k], t2 = (hi - p[k]) / d[k];
                if (t1 > t2) {
                    double tmp = t1; t1 = t2; t2 = tmp;
                }
                tmin = Math.max(tmin, t1);
                tmax = Math.min(tmax, t2);
                if (tmin > tmax) {
                    return Double.POSITIVE_INFINITY;
                }
            }
        }
        return tmin;
    }
}
