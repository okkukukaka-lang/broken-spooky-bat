package com.shazammod.client.render;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Simulasi kain XPBD (murni Java, gampang diuji). Kain = titik-titik grid (baris x kolom) dengan massa
 * sungguhan, disambung batasan jarak.
 *
 * Semua posisi disimpan di ruang lokal "bingkai" tempat kain dipasang (badan, leher, atau kepala), bukan di
 * ruang dunia. Gerak bingkai di dunia masuk lewat gaya semu yang benar secara fisika (percepatan bingkai,
 * gaya sentrifugal, Coriolis, dan Euler), lalu gravitasi dan angin dihitung dalam satuan dunia nyata
 * (meter, detik, kg). Dengan cara ini kain nggak pernah ketinggalan atau meledak saat terbang super cepat
 * atau teleport, dan tetap menempel persis di badan saat digambar.
 *
 * Batasan yang dipakai (XPBD, "small steps": banyak langkah kecil, sedikit iterasi):
 * - tarikan (struktur), geser (diagonal), dan tekuk (lompat dua titik), masing-masing dengan kelenturan;
 * - tali panjang (long-range attachment) ke titik paku terdekat: kain nggak pernah molor;
 * - jarak maksimum + backstop terhadap bentuk pakai (seperti cloth di engine game): pakaian yang dipakai
 *   (hood, mantel) tetap di bentuknya dan nggak bisa nyangkut di sisi yang salah dari badan;
 * - jahitan (dua titik dijahit jadi satu, batasan jarak nol).
 * Tabrakan dikerjakan ClothCollider sesudah batasan.
 */
public final class ClothSim {
    public final int cols;
    public final int rows;
    public final int count;

    /** Posisi sekarang, langkah lalu (buat kecepatan), dan sebelum langkah terakhir (buat interpolasi render). Ruang lokal. */
    public final double[] x, y, z;
    public final double[] px, py, pz;
    public final double[] rx, ry, rz;

    /** Kebalikan massa (0 = dipaku/kinematik) dan massa tiap titik (kg pada skala 1). */
    public final double[] w;
    public final double[] mass;
    /** Posisi bentuk diam (lokal), dipakai juga untuk panjang batasan. */
    public final double[] restX, restY, restZ;

    /** Bentuk tujuan tiap titik (lokal): untuk paku, jarak maksimum, backstop, dan tarikan bentuk. */
    public final double[] tgtX, tgtY, tgtZ;
    /** Normal luar di bentuk tujuan (menjauhi badan), buat backstop. */
    public final double[] outX, outY, outZ;
    /** Jarak maksimum dari tujuan (blok lokal); negatif = bebas. */
    public final double[] maxDist;
    /** Seberapa jauh boleh masuk ke arah badan dari tujuan (blok lokal); negatif = tanpa backstop. */
    public final double[] backstop;
    /** Kekuatan tarikan ke bentuk tujuan (per detik); 0 = tanpa. */
    public final double[] drive;

    /** Normal permukaan (menghadap badan), dihitung tiap langkah. */
    public final double[] nx, ny, nz;
    /** Kecepatan udara relatif bingkai di tiap titik (blok lokal per detik), diisi CapeAir. */
    public final double[] airX, airY, airZ;
    /** Pengali hambatan udara tiap titik (1 = terbuka). */
    public final double[] exposure;

    // batasan jarak
    private int[] linkA = new int[0], linkB = new int[0];
    private double[] linkRest = new double[0], linkCompliance = new double[0], linkLambda = new double[0];
    private boolean[] linkSurface = new boolean[0];   // sambungan antar-tetangga (dipakai mengukur jarak menyusuri kain)
    private boolean[] linkStretch = new boolean[0];   // sambungan tarikan (tetangga lurus & jahitan)
    private int links;
    // tali panjang
    private int[] tetherA = new int[0], tetherB = new int[0];
    private double[] tetherLength = new double[0];
    private int tethers;

    private boolean ready;
    /** Pengali kelenturan sambungan tekuk (1 = bawaan, lebih besar = lebih lemas). */
    public double bendSoftness = 1.0;
    /**
     * Kelenturan saat sambungan tertekan (m/N). Kain sungguhan nggak menahan tekanan, ia melipat; jadi tertarik =
     * kaku, tertekan = lentur. 0 = sama kakunya dengan tertarik.
     */
    public double compressCompliance = 0.0;

    /**
     * @param restX bentuk diam (lokal, satuan blok pada skala 1)
     * @param density massa kain per luas (kg/m²)
     */
    public ClothSim(int cols, int rows, double[] restX, double[] restY, double[] restZ, double density) {
        this.cols = cols;
        this.rows = rows;
        this.count = cols * rows;
        x = new double[count]; y = new double[count]; z = new double[count];
        px = new double[count]; py = new double[count]; pz = new double[count];
        rx = new double[count]; ry = new double[count]; rz = new double[count];
        w = new double[count];
        mass = new double[count];
        this.restX = Arrays.copyOf(restX, count);
        this.restY = Arrays.copyOf(restY, count);
        this.restZ = Arrays.copyOf(restZ, count);
        tgtX = Arrays.copyOf(restX, count); tgtY = Arrays.copyOf(restY, count); tgtZ = Arrays.copyOf(restZ, count);
        outX = new double[count]; outY = new double[count]; outZ = new double[count];
        maxDist = new double[count];
        backstop = new double[count];
        drive = new double[count];
        Arrays.fill(maxDist, -1.0);
        Arrays.fill(backstop, -1.0);
        nx = new double[count]; ny = new double[count]; nz = new double[count];
        airX = new double[count]; airY = new double[count]; airZ = new double[count];
        exposure = new double[count];
        Arrays.fill(exposure, 1.0);

        // Massa dari luas bentuk diam: tiap sel membagi luasnya ke empat sudutnya
        for (int r = 0; r + 1 < rows; r++) {
            for (int c = 0; c + 1 < cols; c++) {
                int a = r * cols + c, b = a + 1, d = a + cols, e = d + 1;
                double area = triArea(a, b, e) + triArea(a, e, d);
                double m = density * area / 4.0;
                mass[a] += m; mass[b] += m; mass[d] += m; mass[e] += m;
            }
        }
        for (int i = 0; i < count; i++) {
            mass[i] = Math.max(mass[i], 1.0E-5);
            w[i] = 1.0 / mass[i];
        }
        // Normal luar bawaan: kebalikan normal grid (normal grid menghadap badan)
        computeNormals(this.restX, this.restY, this.restZ, outX, outY, outZ);
        for (int i = 0; i < count; i++) {
            outX[i] = -outX[i]; outY[i] = -outY[i]; outZ[i] = -outZ[i];
        }
    }

    private double triArea(int a, int b, int c) {
        double ux = restX[b] - restX[a], uy = restY[b] - restY[a], uz = restZ[b] - restZ[a];
        double vx = restX[c] - restX[a], vy = restY[c] - restY[a], vz = restZ[c] - restZ[a];
        double cx = uy * vz - uz * vy, cy = uz * vx - ux * vz, cz = ux * vy - uy * vx;
        return 0.5 * Math.sqrt(cx * cx + cy * cy + cz * cz);
    }

    // ------------------------------------------------------------------ menyusun kain

    /** Paku titik i (ikut bentuk tujuan persis). */
    public void pin(int i) {
        w[i] = 0.0;
    }

    public boolean pinned(int i) {
        return w[i] == 0.0;
    }

    /**
     * Sambungan grid standar.
     * @param stretch kelenturan tarikan (m/N, 0 = nggak bisa molor)
     * @param shear   kelenturan geser
     * @param bend    kelenturan tekuk (makin besar makin gampang dilipat)
     */
    public void addGridLinks(double stretch, double shear, double bend) {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int i = r * cols + c;
                if (c + 1 < cols) addLink(i, i + 1, stretch);
                if (r + 1 < rows) addLink(i, i + cols, stretch);
                markSurface(c + 1 < cols, r + 1 < rows);
            }
        }
        for (int r = 0; r + 1 < rows; r++) {
            for (int c = 0; c + 1 < cols; c++) {
                int i = r * cols + c;
                addLink(i, i + cols + 1, shear);
                addLink(i + 1, i + cols, shear);
                linkSurface[links - 1] = true;
                linkSurface[links - 2] = true;
            }
        }
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int i = r * cols + c;
                if (c + 2 < cols) addLink(i, i + 2, bend);
                if (r + 2 < rows) addLink(i, i + 2 * cols, bend);
            }
        }
    }

    private void markSurface(boolean across, boolean down) {
        int n = (across ? 1 : 0) + (down ? 1 : 0);
        for (int k = 0; k < n; k++) {
            linkSurface[links - 1 - k] = true;
            linkStretch[links - 1 - k] = true;
        }
    }

    /** Batasan jarak dengan panjang dari bentuk diam. */
    public void addLink(int a, int b, double compliance) {
        double dx = restX[b] - restX[a], dy = restY[b] - restY[a], dz = restZ[b] - restZ[a];
        addLink(a, b, Math.sqrt(dx * dx + dy * dy + dz * dz), compliance);
    }

    public void addLink(int a, int b, double restLength, double compliance) {
        if (links == linkA.length) {
            int n = Math.max(16, links * 2);
            linkA = Arrays.copyOf(linkA, n);
            linkB = Arrays.copyOf(linkB, n);
            linkRest = Arrays.copyOf(linkRest, n);
            linkCompliance = Arrays.copyOf(linkCompliance, n);
            linkLambda = Arrays.copyOf(linkLambda, n);
            linkSurface = Arrays.copyOf(linkSurface, n);
            linkStretch = Arrays.copyOf(linkStretch, n);
        }
        linkA[links] = a;
        linkB[links] = b;
        linkRest[links] = restLength;
        linkCompliance[links] = compliance;
        links++;
    }

    /** Jahitan: titik a dan b dijahit jadi satu (batasan jarak nol, dikerjakan bersama batasan lain). */
    public void addSeam(int a, int b) {
        addLink(a, b, 0.0, 0.0);
        linkSurface[links - 1] = true;
        linkStretch[links - 1] = true;
    }

    /**
     * Tali panjang ke titik-titik paku: tiap titik bebas diikat ke `nearest` paku terdekat (jarak diukur
     * menyusuri kain, bukan garis lurus, jadi kain yang melengkung tetap boleh terbentang rata).
     * Panggil sesudah semua paku dan sambungan dibuat.
     */
    public void buildTethers(int nearest, double slack) {
        // jarak menyusuri kain dari tiap paku (Dijkstra sederhana di graf sambungan tarikan & geser)
        List<int[]> edges = new ArrayList<>();
        for (int k = 0; k < links; k++) {
            if (linkSurface[k]) {
                edges.add(new int[] {linkA[k], linkB[k]});
            }
        }
        double[][] adjW = new double[count][];
        int[][] adj = new int[count][];
        int[] deg = new int[count];
        for (int[] e : edges) {
            deg[e[0]]++;
            deg[e[1]]++;
        }
        for (int i = 0; i < count; i++) {
            adj[i] = new int[deg[i]];
            adjW[i] = new double[deg[i]];
            deg[i] = 0;
        }
        for (int[] e : edges) {
            double dx = restX[e[1]] - restX[e[0]], dy = restY[e[1]] - restY[e[0]], dz = restZ[e[1]] - restZ[e[0]];
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            adj[e[0]][deg[e[0]]] = e[1]; adjW[e[0]][deg[e[0]]++] = len;
            adj[e[1]][deg[e[1]]] = e[0]; adjW[e[1]][deg[e[1]]++] = len;
        }
        List<Integer> pins = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            if (w[i] == 0.0) {
                pins.add(i);
            }
        }
        if (pins.isEmpty()) {
            return;
        }
        double[][] dist = new double[pins.size()][];
        for (int p = 0; p < pins.size(); p++) {
            dist[p] = dijkstra(pins.get(p), adj, adjW);
        }
        List<double[]> list = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            if (w[i] == 0.0) {
                continue;
            }
            Integer[] order = new Integer[pins.size()];
            for (int p = 0; p < order.length; p++) {
                order[p] = p;
            }
            final int fi = i;
            Arrays.sort(order, (a, b) -> Double.compare(dist[a][fi], dist[b][fi]));
            for (int k = 0; k < Math.min(nearest, order.length); k++) {
                double d = dist[order[k]][i];
                if (Double.isInfinite(d)) {
                    continue;
                }
                list.add(new double[] {i, pins.get(order[k]), d * slack});
            }
        }
        tethers = list.size();
        tetherA = new int[tethers];
        tetherB = new int[tethers];
        tetherLength = new double[tethers];
        for (int k = 0; k < tethers; k++) {
            double[] t = list.get(k);
            tetherA[k] = (int) t[0];
            tetherB[k] = (int) t[1];
            tetherLength[k] = t[2];
        }
    }

    private double[] dijkstra(int src, int[][] adj, double[][] adjW) {
        double[] d = new double[count];
        Arrays.fill(d, Double.POSITIVE_INFINITY);
        boolean[] done = new boolean[count];
        d[src] = 0.0;
        for (int it = 0; it < count; it++) {
            int u = -1;
            double best = Double.POSITIVE_INFINITY;
            for (int i = 0; i < count; i++) {
                if (!done[i] && d[i] < best) {
                    best = d[i];
                    u = i;
                }
            }
            if (u < 0) {
                break;
            }
            done[u] = true;
            for (int k = 0; k < adj[u].length; k++) {
                int v = adj[u][k];
                double nd = d[u] + adjW[u][k];
                if (nd < d[v]) {
                    d[v] = nd;
                }
            }
        }
        return d;
    }

    // ------------------------------------------------------------------ keadaan

    public boolean isReady() {
        return ready;
    }

    /** Pasang kain di posisi tertentu (lokal), diam. */
    public void reset(double[] lx, double[] ly, double[] lz) {
        System.arraycopy(lx, 0, x, 0, count); System.arraycopy(lx, 0, px, 0, count); System.arraycopy(lx, 0, rx, 0, count);
        System.arraycopy(ly, 0, y, 0, count); System.arraycopy(ly, 0, py, 0, count); System.arraycopy(ly, 0, ry, 0, count);
        System.arraycopy(lz, 0, z, 0, count); System.arraycopy(lz, 0, pz, 0, count); System.arraycopy(lz, 0, rz, 0, count);
        ready = true;
    }

    /** Pasang kain persis di bentuk tujuan, diam. */
    public void resetToTargets() {
        reset(tgtX, tgtY, tgtZ);
    }

    /** Simpan posisi sebelum langkah ini (buat interpolasi render). */
    public void snapshot() {
        System.arraycopy(x, 0, rx, 0, count);
        System.arraycopy(y, 0, ry, 0, count);
        System.arraycopy(z, 0, rz, 0, count);
    }

    /** Pindahkan seluruh keadaan ke bingkai lain: p_baru = to⁻¹ · from · p (dunia tetap sama). */
    public void reframe(Xform from, Xform to) {
        double[] p = new double[3];
        for (int i = 0; i < count; i++) {
            p[0] = x[i]; p[1] = y[i]; p[2] = z[i]; from.toWorld(p); to.toLocal(p); x[i] = p[0]; y[i] = p[1]; z[i] = p[2];
            p[0] = px[i]; p[1] = py[i]; p[2] = pz[i]; from.toWorld(p); to.toLocal(p); px[i] = p[0]; py[i] = p[1]; pz[i] = p[2];
            p[0] = rx[i]; p[1] = ry[i]; p[2] = rz[i]; from.toWorld(p); to.toLocal(p); rx[i] = p[0]; ry[i] = p[1]; rz[i] = p[2];
        }
    }

    // ------------------------------------------------------------------ langkah fisika

    /** Gerak bingkai di dunia, sudah dalam ruang lokal bingkai (satuan blok lokal & detik). */
    public static final class Motion {
        /** Percepatan titik asal bingkai (lokal), sudah dibagi skala. */
        public double ax, ay, az;
        /** Kecepatan sudut dan percepatan sudut bingkai (lokal, rad/s dan rad/s²). */
        public double wx, wy, wz;
        public double alx, aly, alz;
        /** Gravitasi (lokal), sudah dibagi skala. */
        public double gx, gy, gz;
    }

    /**
     * Integrasi satu langkah kecil: titik dipaku pindah ke tujuannya, titik bebas bergerak oleh gravitasi,
     * gaya semu bingkai, dan hambatan udara (dihitung semi-implisit supaya stabil di kecepatan tinggi).
     *
     * @param h        panjang langkah (detik)
     * @param dragN    hambatan udara tegak lurus kain, ½ρC/σ (per blok lokal, sudah dikali skala)
     * @param dragT    gesekan udara searah permukaan
     * @param damping  redaman kecil di dalam kain (per detik)
     */
    public void integrate(double h, Motion m, double dragN, double dragT, double damping) {
        computeNormals(x, y, z, nx, ny, nz);
        double keep = Math.exp(-damping * h);
        for (int i = 0; i < count; i++) {
            if (w[i] == 0.0) {
                px[i] = x[i]; py[i] = y[i]; pz[i] = z[i];
                x[i] = tgtX[i]; y[i] = tgtY[i]; z[i] = tgtZ[i];
                continue;
            }
            double vx = (x[i] - px[i]) / h, vy = (y[i] - py[i]) / h, vz = (z[i] - pz[i]) / h;
            // gaya semu: -a - α×r - ω×(ω×r) - 2ω×v
            double rX = x[i], rY = y[i], rZ = z[i];
            double eX = m.aly * rZ - m.alz * rY, eY = m.alz * rX - m.alx * rZ, eZ = m.alx * rY - m.aly * rX;
            double oX = m.wy * rZ - m.wz * rY, oY = m.wz * rX - m.wx * rZ, oZ = m.wx * rY - m.wy * rX;
            double cX = m.wy * oZ - m.wz * oY, cY = m.wz * oX - m.wx * oZ, cZ = m.wx * oY - m.wy * oX;
            double kX = m.wy * vz - m.wz * vy, kY = m.wz * vx - m.wx * vz, kZ = m.wx * vy - m.wy * vx;
            vx += (m.gx - m.ax - eX - cX - 2.0 * kX) * h;
            vy += (m.gy - m.ay - eY - cY - 2.0 * kY) * h;
            vz += (m.gz - m.az - eZ - cZ - 2.0 * kZ) * h;
            // hambatan udara: kecepatan relatif udara dipecah tegak lurus dan searah kain
            double e = exposure[i];
            if (e > 0.0) {
                double ux = vx - airX[i], uy = vy - airY[i], uz = vz - airZ[i];
                double speed = Math.sqrt(ux * ux + uy * uy + uz * uz);
                double vn = ux * nx[i] + uy * ny[i] + uz * nz[i];
                double tX = ux - vn * nx[i], tY = uy - vn * ny[i], tZ = uz - vn * nz[i];
                double fn = 1.0 / (1.0 + dragN * e * speed * h);
                double ft = 1.0 / (1.0 + dragT * e * speed * h);
                vx = airX[i] + tX * ft + vn * fn * nx[i];
                vy = airY[i] + tY * ft + vn * fn * ny[i];
                vz = airZ[i] + tZ * ft + vn * fn * nz[i];
            }
            vx *= keep; vy *= keep; vz *= keep;
            px[i] = x[i]; py[i] = y[i]; pz[i] = z[i];
            x[i] += vx * h; y[i] += vy * h; z[i] += vz * h;
        }
    }

    /**
     * Selesaikan semua batasan untuk satu langkah kecil. Tiap iterasi: batasan jarak (XPBD), tali panjang,
     * jarak maksimum + backstop, lalu tabrakan (contacts). Tabrakan ikut di dalam iterasi supaya kain yang
     * terdorong badan atau lapisan lain sempat dirapikan lagi oleh batasan jarak (nggak sobek/molor).
     * Tarikan ke bentuk tujuan dikerjakan sekali di awal.
     */
    public void solve(double h, int iterations, Runnable contacts) {
        double h2 = h * h;
        Arrays.fill(linkLambda, 0, links, 0.0);
        applyDrive(h);
        for (int it = 0; it < iterations; it++) {
            for (int k = 0; k < links; k++) {
                if (it > 0 && !linkStretch[k]) {
                    continue;   // geser & tekuk cukup sekali per langkah (lentur); tarikan tiap iterasi
                }
                int a = linkA[k], b = linkB[k];
                double wa = w[a], wb = w[b];
                double wsum = wa + wb;
                if (wsum == 0.0) {
                    continue;
                }
                double dx = x[b] - x[a], dy = y[b] - y[a], dz = z[b] - z[a];
                double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
                if (len < 1.0E-9) {
                    continue;
                }
                double c = len - linkRest[k];
                double compliance = linkSurface[k] ? linkCompliance[k] : linkCompliance[k] * bendSoftness;
                if (c < 0.0) {
                    compliance += compressCompliance;
                }
                double alpha = compliance / h2;
                double dl = (-c - alpha * linkLambda[k]) / (wsum + alpha);
                linkLambda[k] += dl;
                double f = dl / len;
                x[a] -= wa * f * dx; y[a] -= wa * f * dy; z[a] -= wa * f * dz;
                x[b] += wb * f * dx; y[b] += wb * f * dy; z[b] += wb * f * dz;
            }
            tethers();
            applyLimits();
            if (contacts != null) {
                contacts.run();
            }
        }
        // terakhir: kain nggak boleh molor (kalau didorong lengan yang bergerak sangat cepat, lebih baik kain
        // sedikit menembus daripada sobek)
        stretchPass();
    }

    /** Satu putaran batasan tarikan saja (sambungan antar-tetangga yang sedang molor). */
    private void stretchPass() {
        for (int k = 0; k < links; k++) {
            if (!linkStretch[k]) {
                continue;
            }
            int a = linkA[k], b = linkB[k];
            double wa = w[a], wb = w[b];
            double wsum = wa + wb;
            if (wsum == 0.0) {
                continue;
            }
            double dx = x[b] - x[a], dy = y[b] - y[a], dz = z[b] - z[a];
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double c = len - linkRest[k];
            if (c <= 0.0 || len < 1.0E-9) {
                continue;
            }
            double f = -c / (wsum * len);
            x[a] -= wa * f * dx; y[a] -= wa * f * dy; z[a] -= wa * f * dz;
            x[b] += wb * f * dx; y[b] += wb * f * dy; z[b] += wb * f * dz;
        }
    }

    /** Tali panjang: titik nggak boleh lebih jauh dari pakunya daripada panjang tali. */
    public void tethers() {
        for (int k = 0; k < tethers; k++) {
            int i = tetherA[k], j = tetherB[k];
            double dx = x[i] - x[j], dy = y[i] - y[j], dz = z[i] - z[j];
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double max = tetherLength[k];
            if (d > max) {
                double f = max / d;
                x[i] = x[j] + dx * f;
                y[i] = y[j] + dy * f;
                z[i] = z[j] + dz * f;
            }
        }
    }

    /** Tarikan pelan ke bentuk tujuan (pegas teredam lewat posisi; per detik, nggak bergantung panjang langkah). */
    private void applyDrive(double h) {
        for (int i = 0; i < count; i++) {
            double k = drive[i];
            if (w[i] == 0.0 || k <= 0.0) {
                continue;
            }
            double f = 1.0 - Math.exp(-k * h);
            x[i] += (tgtX[i] - x[i]) * f;
            y[i] += (tgtY[i] - y[i]) * f;
            z[i] += (tgtZ[i] - z[i]) * f;
        }
    }

    /** Jarak maksimum dari tujuan dan backstop (nggak boleh masuk ke arah badan lebih dari batasnya). */
    private void applyLimits() {
        for (int i = 0; i < count; i++) {
            if (w[i] == 0.0) {
                continue;
            }
            double max = maxDist[i];
            if (max >= 0.0) {
                double dx = x[i] - tgtX[i], dy = y[i] - tgtY[i], dz = z[i] - tgtZ[i];
                double d2 = dx * dx + dy * dy + dz * dz;
                if (d2 > max * max) {
                    double f = max / Math.sqrt(d2);
                    x[i] = tgtX[i] + dx * f;
                    y[i] = tgtY[i] + dy * f;
                    z[i] = tgtZ[i] + dz * f;
                }
            }
            double back = backstop[i];
            if (back >= 0.0) {
                double dn = (x[i] - tgtX[i]) * outX[i] + (y[i] - tgtY[i]) * outY[i] + (z[i] - tgtZ[i]) * outZ[i];
                if (dn < -back) {
                    double push = -back - dn;
                    x[i] += outX[i] * push;
                    y[i] += outY[i] * push;
                    z[i] += outZ[i] * push;
                }
            }
        }
    }

    /** Ada nilai rusak (NaN/tak hingga)? Kalau ya, pemanggil memasang ulang kain. */
    public boolean broken() {
        for (int i = 0; i < count; i++) {
            if (!Double.isFinite(x[i]) || !Double.isFinite(y[i]) || !Double.isFinite(z[i])
                    || Math.abs(x[i]) > 64.0 || Math.abs(y[i]) > 64.0 || Math.abs(z[i]) > 64.0) {
                return true;
            }
        }
        return false;
    }

    /** Normal halus tiap titik grid, menghadap badan (sama arahnya dengan ClothDecor.normals). */
    public void computeNormals(double[] vx, double[] vy, double[] vz, double[] ox, double[] oy, double[] oz) {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int i = r * cols + c;
                int left = r * cols + Math.max(0, c - 1), right = r * cols + Math.min(cols - 1, c + 1);
                int up = Math.max(0, r - 1) * cols + c, down = Math.min(rows - 1, r + 1) * cols + c;
                double tx = vx[right] - vx[left], ty = vy[right] - vy[left], tz = vz[right] - vz[left];
                double bx = vx[down] - vx[up], by = vy[down] - vy[up], bz = vz[down] - vz[up];
                double ax = ty * bz - tz * by, ay = tz * bx - tx * bz, az = tx * by - ty * bx;
                double len = Math.sqrt(ax * ax + ay * ay + az * az);
                if (len < 1.0E-12) {
                    ox[i] = 0; oy[i] = 0; oz[i] = 0;
                } else {
                    ox[i] = ax / len; oy[i] = ay / len; oz[i] = az / len;
                }
            }
        }
    }
}
