package com.shazammod.client.anim;

import java.util.EnumMap;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.client.fx.GodShow;

/**
 * Semua gerakan Shazam. Tiap skill punya ancang-ancang (badan menegang, gemetar mengumpulkan tenaga),
 * gerakan utama yang cepat dengan sedikit kebablasan (OUT_BACK), lalu kembali pelan.
 * Waktunya pas dengan saat damage di server (ShazamAnim.*_WINDUP).
 *
 * Panduan angka (derajat):
 * - Lengan xRot: 0 = turun, -90 = lurus ke depan, -180 = lurus ke atas, positif = ke belakang.
 * - Lengan zRot (lengan turun): kanan positif / kiri negatif = membuka ke samping.
 *   (lengan ke atas: kanan positif / kiri negatif = ke arah tengah).
 * - Lengan yRot (saat lurus ke depan): kanan negatif / kiri positif = ke arah tengah.
 * - Kaki xRot: negatif = ke depan. Kepala xRot: negatif = mendongak.
 * - tilt: positif = seluruh badan condong ke depan. drop: badan turun (blok), negatif = terangkat.
 * - twist: pinggang berputar, positif = bahu kanan ke belakang. lean: condong ke samping. shake: gemetar.
 */
public final class Clips {
    private Clips() {}

    private static final Map<ShazamAnim, Clip> CLIPS = new EnumMap<>(ShazamAnim.class);

    public static Clip get(ShazamAnim anim) {
        return CLIPS.get(anim);
    }

    static {
        // Transformasi: membungkuk, kepalan ke langit (tick 7), lalu ditahan menegang dan gemetar selama petir turun
        // pelan (tick 8-18, slow motion). Tick 18 petir mengenai: tersentak, terangkat dengan lengan terbuka, berdiri gagah.
        CLIPS.put(ShazamAnim.TRANSFORM, Clip.builder(54)
                .key(0, Ease.LINEAR).rightArm(-20, 0, -4).leftArm(4, 0, -6).head(-5, 0, 0).legs(3).tilt(0)
                .key(3, Ease.OUT_CUBIC).rightArm(18, 0, 14).leftArm(18, 0, -14).head(12, 0, 0).legs(9).tilt(12).drop(0.16f)
                .key(7, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(25, 0, -14).head(-42, 0, 0).legs(6).tilt(-10).drop(-0.06f).shake(0.8f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-183, 0, -4).leftArm(28, 0, -16).head(-48, 0, 0).tilt(-12).drop(-0.08f).shake(1.8f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-177, 0, -7).leftArm(24, 0, -13).head(-44, 0, 0).tilt(-10).drop(-0.05f).shake(2.6f)
                .key(19, Ease.OUT_QUAD).head(-18, 0, 0).tilt(-3).drop(0.12f).shake(0f)
                .key(24, Ease.OUT_CUBIC).rightArm(-152, 0, -34).leftArm(-152, 0, 34).head(-32, 0, 0).legs(10).tilt(-12).drop(-0.35f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-158, 0, -38).leftArm(-158, 0, 38).head(-36, 0, 0).tilt(-8).drop(-0.42f)
                .key(43, Ease.IN_OUT_SINE).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(6, 0, 0).legs(10).tilt(7).drop(0.14f)
                .key(50, Ease.OUT_CUBIC).rightArm(10, 0, 24).leftArm(10, 0, -24).head(-10, 0, 0).legs(8).tilt(-3).drop(0f)
                .fade(2, 5).build());

        // Memakai hood: kedua tangan meraih ke belakang kepala (tick 5), memegang tepi hood (6),
        // menariknya ke depan lewat atas kepala sampai dahi (16), lalu turun lagi.
        CLIPS.put(ShazamAnim.HOOD_UP, Clip.builder(ShazamAnim.HOOD_TICKS)
                .key(0, Ease.LINEAR).rightArm(-20, 0, 6).leftArm(-20, 0, -6)
                .key(5, Ease.IN_OUT_SINE).rightArm(-196, 0, -12).leftArm(-196, 0, 12).head(12, 0, 0)
                .key(6, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-140, 0, -14).leftArm(-140, 0, 14).head(6, 0, 0)
                .key(18, Ease.LINEAR)
                .key(24, Ease.OUT_CUBIC).rightArm(-5, 0, 4).leftArm(-5, 0, -4).head(0, 0, 0)
                .fade(2, 4).build());

        // Melepas hood: tangan memegang tepi hood di dahi (tick 5-6), mendorongnya ke belakang lewat atas kepala
        // sambil sedikit mendongak (16), lalu turun lagi.
        CLIPS.put(ShazamAnim.HOOD_DOWN, Clip.builder(ShazamAnim.HOOD_TICKS)
                .key(0, Ease.LINEAR).rightArm(-20, 0, 6).leftArm(-20, 0, -6)
                .key(5, Ease.IN_OUT_SINE).rightArm(-145, 0, -14).leftArm(-145, 0, 14).head(8, 0, 0)
                .key(6, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-200, 0, -10).leftArm(-200, 0, 10).head(-14, 0, 0)
                .key(18, Ease.LINEAR)
                .key(24, Ease.OUT_CUBIC).rightArm(-5, 0, 4).leftArm(-5, 0, -4).head(0, 0, 0)
                .fade(2, 4).build());

        // Memanggil enam dewa: kepala tertunduk dan lengan terbuka menerima. Dewa datang satu per satu
        // (GodShow.ARRIVE): tiap kedatangan badan sedikit tersentak, lengan makin terbuka, kepala makin terangkat
        // menatap mereka. Menjelang akhir gemetar menahan kekuatan, lalu dilanjutkan TRANSFORM (kepalan ke langit).
        Clip.Builder summon = Clip.builder(ShazamAnim.SUMMON_TICKS)
                .key(0, Ease.LINEAR).rightArm(-8, 0, 10).leftArm(-8, 0, -10).head(10, 0, 0).tilt(2)
                .key(8, Ease.OUT_CUBIC).rightArm(-22, 0, 40).leftArm(-22, 0, -40).head(18, 0, 0).legs(3).tilt(4).drop(0.04f);
        for (int i = 0; i < GodShow.ARRIVE.length; i++) {
            float u = i / (float) (GodShow.ARRIVE.length - 1);
            float at = GodShow.ARRIVE[i];
            float head = 14f - 40f * u;      // makin mendongak
            float open = 42f + 16f * u;      // lengan makin terbuka
            float fwd = -24f - 10f * u;
            summon.key(at - 1.5f, Ease.IN_OUT_SINE).rightArm(fwd, 0, open).leftArm(fwd, 0, -open).head(head + 3, 0, 0)
                    .legs(3).tilt(3 - 9 * u).drop(0.03f - 0.12f * u).shake(0f)
                    .key(at + 1, Ease.OUT_BACK).rightArm(fwd - 7, 0, open + 6).leftArm(fwd - 7, 0, -open - 6).head(head - 7, 0, 0)
                    .tilt(-2 - 9 * u).drop(-0.03f - 0.12f * u).shake(0.7f)
                    .key(at + 6, Ease.IN_OUT_SINE).rightArm(fwd - 2, 0, open + 2).leftArm(fwd - 2, 0, -open - 2).head(head - 2, 0, 0)
                    .tilt(1 - 9 * u).drop(0.01f - 0.12f * u).shake(0.15f);
        }
        float end = ShazamAnim.SUMMON_TICKS;
        float settled = GodShow.ARRIVE[GodShow.ARRIVE.length - 1] + 6;
        summon.key(Math.min(end - 0.5f, Math.max(settled + 1, end - 4)), Ease.IN_OUT_SINE)
                .rightArm(-36, 0, 60).leftArm(-36, 0, -60).head(-30, 0, 0).legs(2).tilt(-9).drop(-0.15f).shake(0.9f)
                .key(end, Ease.IN_OUT_SINE)
                .rightArm(-36, 0, 58).leftArm(-36, 0, -58).head(-30, 0, 0).tilt(-9).drop(-0.15f).shake(1.3f);
        CLIPS.put(ShazamAnim.SUMMON, summon.fade(4, 3).build());

        // Zeus Rage: membungkuk, kepalan mengepal, badan gemetar makin hebat, lalu meraung ke langit dengan lengan
        // menghentak ke bawah-samping (tick 9: mata menyala, petir menyambar) dan tetap bergetar menahan amarah.
        CLIPS.put(ShazamAnim.ZEUS_RAGE, Clip.builder(26)
                .key(0, Ease.OUT_CUBIC).rightArm(14, 0, 8).leftArm(14, 0, -8).head(20, 0, 0).tilt(8).drop(0.08f).shake(1f)
                .key(6, Ease.IN_QUAD).rightArm(28, 0, 18).leftArm(28, 0, -18).head(28, 0, 0).rightLeg(-18, 0, 6).leftLeg(-18, 0, -6)
                        .tilt(15).drop(0.18f).shake(3.5f)
                .key(8.5f, Ease.IN_QUAD).rightArm(34, 0, 10).leftArm(34, 0, -10).tilt(18).drop(0.22f).shake(4.5f)
                .key(9, Ease.OUT_BACK).rightArm(32, 0, 50).leftArm(32, 0, -50).head(-55, 0, 0).rightLeg(0, 0, 9).leftLeg(0, 0, -9)
                        .tilt(-18).drop(-0.06f).shake(2f)
                .key(19, Ease.LINEAR).shake(1.4f)
                .key(26, Ease.IN_OUT_SINE).rightArm(8, 0, 16).leftArm(8, 0, -16).head(-8, 0, 0).rightLeg(0, 0, 3).leftLeg(0, 0, -3)
                        .tilt(-2).drop(0f).shake(0f)
                .fade(2, 5).build());

        // Kembali jadi manusia: kepalan ke atas lagi (gemetar), petir (tick 6), badan lunglai
        CLIPS.put(ShazamAnim.REVERT, Clip.builder(22)
                .key(0, Ease.LINEAR).rightArm(-20, 0, -4).leftArm(4, 0, -6).head(-5, 0, 0)
                .key(5, Ease.OUT_CUBIC).rightArm(-178, 0, -6).leftArm(10, 0, -8).head(-35, 0, 0).shake(1.5f)
                .key(8, Ease.OUT_QUAD).rightArm(-120, 0, 0).head(-8, 0, 0).drop(0.14f).shake(0f)
                .key(16, Ease.IN_OUT_SINE).rightArm(0, 0, 4).leftArm(0, 0, -4).head(10, 0, 0).drop(0.04f)
                .fade(2, 5).build());

        // Terlempar balik jadi manusia (serangan mematikan saat jadi Shazam): badan terhentak ke belakang dengan lengan
        // terlempar ke depan, lalu (tick 3) kekuatan tercabut dari dada: lengan terentang ke belakang, kepala mendongak,
        // gemetar hebat. Lalu lunglai membungkuk dengan lutut goyah dan badan oleng, dan pelan-pelan tegak lagi.
        // Kaki cuma sedikit melangkah, supaya tetap wajar kalau langsung lari menjauh.
        CLIPS.put(ShazamAnim.KNOCKOUT, Clip.builder(30)
                .key(0, Ease.OUT_QUAD).rightArm(-62, 0, 34).leftArm(-62, 0, -34).head(-30, 0, 0)
                        .rightLeg(-22, 0, 6).leftLeg(12, 0, -6).tilt(-24).drop(0.04f).twist(10).shake(3f)
                .key(ShazamAnim.KNOCKOUT_BURST, Ease.OUT_CUBIC).rightArm(24, 0, 66).leftArm(24, 0, -66).head(-48, 0, 0)
                        .rightLeg(-8, 0, 8).leftLeg(6, 0, -8).tilt(-14).drop(-0.05f).twist(0).shake(5f)
                .key(6, Ease.LINEAR).shake(4f)
                .key(10, Ease.IN_QUAD).rightArm(10, 0, 12).leftArm(12, 0, -10).head(30, 0, 0)
                        .rightLeg(-26, 0, 6).leftLeg(16, 0, -6).tilt(24).drop(0.3f).shake(0.8f)
                .key(15, Ease.OUT_QUAD).head(36, 0, 0).tilt(28).drop(0.36f).lean(4).shake(0.4f)
                .key(20, Ease.IN_OUT_SINE).head(26, 0, 0).tilt(22).drop(0.28f).lean(-2).shake(0.2f)
                .key(30, Ease.IN_OUT_SINE).rightArm(4, 0, 8).leftArm(4, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f).lean(0).shake(0f)
                .fade(1, 6).build());

        // S - Mata Solomon: tangan menyapu di depan mata, dua jari ke pelipis sambil menunduk berkonsentrasi,
        // lalu (tick 5) kepala terangkat dan tangan terbuka saat mata menyala dan gelombang pemindai menyebar.
        CLIPS.put(ShazamAnim.SOLOMON_SIGHT, Clip.builder(18)
                .key(0, Ease.LINEAR).rightArm(-30, -10, 0).leftArm(3, 0, -5).head(3, 0, 0)
                .key(2.5f, Ease.OUT_CUBIC).rightArm(-118, -42, 0).head(10, 0, 0).twist(-8)
                .key(4, Ease.IN_OUT_SINE).rightArm(-145, -34, 0).leftArm(8, 0, -10).head(16, 0, 0).tilt(4).drop(0.04f).shake(0.8f)
                .key(5, Ease.OUT_BACK).rightArm(-132, -10, 18).leftArm(14, 0, -24).head(-12, 0, 0).tilt(-6).drop(-0.03f)
                        .twist(6).shake(0f)
                .key(12, Ease.LINEAR)
                .key(18, Ease.IN_OUT_SINE).rightArm(-10, 0, 6).leftArm(3, 0, -5).head(0, 0, 0).tilt(0).drop(0f).twist(0)
                .fade(3, 5).build());

        // H - Tepukan Hercules: kedua tangan dibentang lebar ke belakang sambil menjinjit dan menegang,
        // lalu (tick 5) ditepuk keras di depan sambil melangkah maju, badan terhentak, lalu kembali.
        CLIPS.put(ShazamAnim.HERCULES_CLAP, Clip.builder(14)
                .key(0, Ease.LINEAR).rightArm(-35, 25, 0).leftArm(-35, -25, 0).head(-2, 0, 0).tilt(-2)
                .key(3, Ease.OUT_CUBIC).rightArm(-82, 95, 8).leftArm(-82, -95, -8).head(-10, 0, 0).tilt(-12).drop(-0.06f)
                        .rightLeg(12, 0, 4).leftLeg(-14, 0, -4).shake(1.5f)
                .key(4.2f, Ease.LINEAR).rightArm(-84, 100, 8).leftArm(-84, -100, -8).shake(2.5f)
                .key(5, Ease.OUT_BACK).rightArm(-92, -20, 0).leftArm(-92, 20, 0).head(4, 0, 0).tilt(14).drop(0.1f)
                        .rightLeg(30, 0, 6).leftLeg(-40, 0, -6).shake(0f)
                .key(8, Ease.OUT_QUAD).rightArm(-84, -12, 0).leftArm(-84, 12, 0).tilt(9).drop(0.08f)
                .key(14, Ease.IN_OUT_SINE).rightArm(-20, 0, 6).leftArm(-20, 0, -6).head(0, 0, 0).tilt(0).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(2, 4).build());

        // A - Atlas di tanah: jongkok, lalu melompat kecil dengan kedua kepalan menyatu di atas kepala
        // (hantamannya dilanjutkan ATLAS_IMPACT di tick 5)
        CLIPS.put(ShazamAnim.ATLAS_GROUND, Clip.builder(14)
                .key(0, Ease.LINEAR).rightArm(-30, 0, 6).leftArm(-30, 0, -6).head(-5, 0, 0).tilt(-2)
                .key(2, Ease.OUT_QUAD).rightArm(10, 0, 20).leftArm(10, 0, -20).head(10, 0, 0).rightLeg(-30, 0, 4)
                        .leftLeg(-30, 0, -4).tilt(12).drop(0.18f)
                .key(4.5f, Ease.OUT_CUBIC).rightArm(-172, 0, 14).leftArm(-172, 0, -14).head(-25, 0, 0).rightLeg(15, 0, 3)
                        .leftLeg(25, 0, -3).tilt(-14).drop(-0.32f).shake(1f)
                .fade(1, 3).build());

        // A - Atlas dari udara: menukik dengan kedua kepalan di atas kepala, makin rebah dan bergetar diterpa angin
        CLIPS.put(ShazamAnim.ATLAS_DIVE, Clip.builder(60)
                .key(0, Ease.OUT_CUBIC).rightArm(-168, 0, 12).leftArm(-168, 0, -12).head(-35, 0, 0)
                        .rightLeg(18, 0, 3).leftLeg(28, 0, -3).tilt(30)
                .key(6, Ease.IN_OUT_SINE).tilt(42).shake(1f)
                .fade(2, 6).build());

        // A - Atlas mendarat: kepalan menghantam tanah, satu lutut turun, badan terbenam lalu bangkit pelan
        CLIPS.put(ShazamAnim.ATLAS_IMPACT, Clip.builder(18)
                .key(0, Ease.OUT_QUAD).rightArm(-40, -14, 0).leftArm(-40, 14, 0).head(-28, 0, 0)
                        .rightLeg(-64, 0, 8).leftLeg(44, 0, -8).tilt(32).drop(0.48f).shake(1.6f)
                .key(2, Ease.OUT_CUBIC).rightArm(-34, -14, 0).leftArm(-34, 14, 0).tilt(36).drop(0.54f).shake(1f)
                .key(9, Ease.LINEAR).shake(0.3f)
                .key(13, Ease.IN_OUT_SINE).rightArm(-10, 0, 18).leftArm(-10, 0, -18).head(-10, 0, 0)
                        .rightLeg(-30, 0, 6).leftLeg(20, 0, -6).tilt(14).drop(0.22f).shake(0f)
                .key(18, Ease.IN_OUT_SINE).rightArm(6, 0, 18).leftArm(6, 0, -18).head(-5, 0, 0)
                        .rightLeg(0, 0, 6).leftLeg(0, 0, -6).tilt(0).drop(0f)
                .fade(1, 5).build());

        // Z - Petir Zeus: tangan menyapu ke atas sambil pinggang berputar, menggapai langit (listrik berkumpul,
        // gemetar), sentakan kecil, lalu (tick 5-7) mencambuk menunjuk sasaran sambil melangkah.
        CLIPS.put(ShazamAnim.ZEUS_CALL, Clip.builder(16)
                .key(0, Ease.LINEAR).rightArm(-30, 0, -6).leftArm(4, 0, -6).head(-5, 0, 0)
                .key(2, Ease.OUT_QUAD).rightArm(-110, 30, 0).leftArm(15, 0, -14).head(-18, 0, 0).twist(18).tilt(-4)
                .key(4, Ease.OUT_CUBIC).rightArm(-178, 0, -8).leftArm(22, 0, -18).head(-40, 0, 0).twist(10).tilt(-8)
                        .drop(-0.05f).shake(1.5f)
                .key(5, Ease.IN_QUAD).rightArm(-165, 0, -6).shake(2.5f)
                .key(7, Ease.OUT_BACK).rightArm(-90, 0, 0).aim(1f).leftArm(35, 0, -22).head(0, 0, 0).twist(-14).tilt(8)
                        .drop(0.04f).rightLeg(-18, 0, 3).leftLeg(14, 0, -3).shake(0f)
                .key(12, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-60, 0, 0).aim(0.6f).twist(0).tilt(2).drop(0f).rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(2, 5).build());

        // A - Kulit Achilles: membungkuk dalam dengan kepalan mengepal, gemetar makin hebat, lalu (tick 4) meraung
        // dengan dada membusung dan lengan menghentak ke samping, tetap bergetar.
        CLIPS.put(ShazamAnim.ACHILLES_ROAR, Clip.builder(22)
                .key(0, Ease.OUT_CUBIC).rightArm(20, 0, 22).leftArm(20, 0, -22).head(22, 0, 0).tilt(14).drop(0.16f)
                        .rightLeg(-24, 0, 6).leftLeg(-24, 0, -6).shake(1.5f)
                .key(3.5f, Ease.IN_QUAD).rightArm(32, 0, 28).leftArm(32, 0, -28).head(26, 0, 0).tilt(18).drop(0.24f).shake(3f)
                .key(4, Ease.OUT_BACK).rightArm(22, 0, 64).leftArm(22, 0, -64).head(-42, 0, 0).tilt(-16).drop(-0.04f)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).shake(1.2f)
                .key(16, Ease.LINEAR).shake(0.8f)
                .key(22, Ease.IN_OUT_SINE).rightArm(4, 0, 14).leftArm(4, 0, -14).head(-5, 0, 0).tilt(-2).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0).shake(0f)
                .fade(2, 5).build());

        // M - Kilat Mercury: menerjang dengan tinju di depan, badan rebah rendah, lalu tergelincir berhenti dengan
        // kaki depan menahan dan lengan terbuka menjaga keseimbangan.
        CLIPS.put(ShazamAnim.MERCURY_BLITZ, Clip.builder(12)
                .key(0, Ease.OUT_CUBIC).rightArm(-82, -8, 0).leftArm(62, 0, -14).rightLeg(-40, 0, 0).leftLeg(46, 0, 0)
                        .head(-30, 0, 0).tilt(36).twist(-10).drop(0.08f)
                .key(6, Ease.LINEAR).shake(1f)
                .key(8, Ease.OUT_QUAD).rightArm(-40, 0, 30).leftArm(-30, 0, -36).rightLeg(-34, 0, 6).leftLeg(20, 0, -6)
                        .head(-6, 0, 0).tilt(-12).twist(8).drop(0.12f).shake(0f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-10, 0, 5).leftArm(10, 0, -5).rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                        .head(-5, 0, 0).tilt(2).twist(0).drop(0f)
                .fade(1, 4).build());

        // ---- Mode Kilat Mercury. Pukulan-pukulannya pendek (pukulan berikutnya bisa datang 2-3 tick kemudian):
        // klip lama memudar ke klip baru (ShazamPoses), jadi rangkaian pukulan menyambung seperti satu kombo.

        // Menyala: kuda-kuda rendah, kepalan mengepal dan badan gemetar menahan listrik, lalu (tick 6) menghentak
        // tegak dengan lengan terbuka saat listrik meledak dari badan.
        CLIPS.put(ShazamAnim.MERCURY_ON, Clip.builder(16)
                .key(0, Ease.OUT_CUBIC).rightArm(15, 0, 15).leftArm(15, 0, -15).head(18, 0, 0).tilt(12).drop(0.14f)
                        .rightLeg(-20, 0, 5).leftLeg(-20, 0, -5).shake(1.5f)
                .key(5, Ease.IN_QUAD).rightArm(28, 0, 20).leftArm(28, 0, -20).head(24, 0, 0).tilt(16).drop(0.2f).shake(3.5f)
                .key(6, Ease.OUT_BACK).rightArm(30, 0, 55).leftArm(30, 0, -55).head(-25, 0, 0).tilt(-8).drop(-0.04f)
                        .rightLeg(0, 0, 9).leftLeg(0, 0, -9).shake(1.2f)
                .key(11, Ease.LINEAR).shake(0.6f)
                .key(16, Ease.IN_OUT_SINE).rightArm(-25, 0, 12).leftArm(-25, 0, -12).head(0, 0, 0).tilt(6).drop(0.02f)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).shake(0f)
                .fade(2, 4).build());

        // Mati: lengan dikibaskan melepas sisa listrik.
        CLIPS.put(ShazamAnim.MERCURY_OFF, Clip.builder(10)
                .key(0, Ease.OUT_QUAD).rightArm(-10, 0, 22).leftArm(-10, 0, -22).head(6, 0, 0).shake(2.2f)
                .key(4, Ease.LINEAR).shake(0.6f)
                .key(10, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).shake(0f)
                .fade(1, 4).build());

        // Jab kanan: kepalan ditarik, lalu (tick 1) dilontarkan lurus sambil pinggang berputar dan kaki melangkah.
        CLIPS.put(ShazamAnim.MERCURY_JAB, Clip.builder(9)
                .key(0, Ease.LINEAR).rightArm(-55, 0, 12).leftArm(-50, 15, -10).head(0, 0, 0).twist(10).tilt(12)
                .key(1.2f, Ease.OUT_BACK).rightArm(-93, -6, 0).leftArm(-35, 20, -14).twist(-16).tilt(18).drop(0.04f)
                        .rightLeg(-12, 0, 2).leftLeg(16, 0, -2)
                .key(3, Ease.LINEAR)
                .key(9, Ease.IN_OUT_SINE).rightArm(-35, 0, 8).leftArm(-35, 0, -8).twist(0).tilt(8).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(0.6f, 3).build());

        // Cross kiri: kebalikan jab.
        CLIPS.put(ShazamAnim.MERCURY_CROSS, Clip.builder(9)
                .key(0, Ease.LINEAR).leftArm(-55, 0, -12).rightArm(-50, -15, 10).head(0, 0, 0).twist(-10).tilt(12)
                .key(1.2f, Ease.OUT_BACK).leftArm(-93, 6, 0).rightArm(-35, -20, 14).twist(16).tilt(18).drop(0.04f)
                        .leftLeg(-12, 0, -2).rightLeg(16, 0, 2)
                .key(3, Ease.LINEAR)
                .key(9, Ease.IN_OUT_SINE).rightArm(-35, 0, 8).leftArm(-35, 0, -8).twist(0).tilt(8).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(0.6f, 3).build());

        // Hook kanan: lengan dari samping menyapu mendatar ke depan dengan putaran pinggang yang lebar.
        CLIPS.put(ShazamAnim.MERCURY_HOOK, Clip.builder(9)
                .key(0, Ease.LINEAR).rightArm(-80, 55, 10).leftArm(-45, 15, -10).head(0, 0, 0).twist(22).tilt(10)
                .key(1.3f, Ease.OUT_BACK).rightArm(-88, -35, 0).leftArm(-40, 20, -14).twist(-28).tilt(14).lean(-6)
                        .rightLeg(-8, 0, 4).leftLeg(10, 0, -4)
                .key(3, Ease.LINEAR)
                .key(9, Ease.IN_OUT_SINE).rightArm(-35, 0, 8).leftArm(-35, 0, -8).twist(0).tilt(8).lean(0)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(0.6f, 3).build());

        // Tendangan kanan: kaki diangkat lurus ke depan, badan condong ke belakang, lengan terbuka menjaga keseimbangan.
        CLIPS.put(ShazamAnim.MERCURY_KICK, Clip.builder(10)
                .key(0, Ease.LINEAR).rightLeg(-30, 0, 6).rightArm(-20, 0, 25).leftArm(-50, 0, -20).head(0, 0, 0).tilt(-4)
                .key(1.4f, Ease.OUT_BACK).rightLeg(-100, 0, 10).leftLeg(6, 0, -3).rightArm(25, 0, 35).leftArm(-60, 0, -30)
                        .tilt(-14).lean(-8).drop(0.05f)
                .key(3.2f, Ease.LINEAR)
                .key(10, Ease.IN_OUT_SINE).rightLeg(0, 0, 0).leftLeg(0, 0, 0).rightArm(-30, 0, 8).leftArm(-30, 0, -8)
                        .tilt(6).lean(0).drop(0f)
                .fade(0.6f, 3).build());

        // Lepas landas: jongkok mengumpulkan tenaga, lalu melesat dengan kepalan ke atas
        CLIPS.put(ShazamAnim.LAUNCH, Clip.builder(16)
                .key(0, Ease.OUT_QUAD).rightArm(22, 0, 12).leftArm(22, 0, -12).head(12, 0, 0)
                        .rightLeg(-35, 0, 4).leftLeg(-20, 0, -4).tilt(14).drop(0.28f).shake(1f)
                .key(4, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(15, 0, -12).head(-30, 0, 0)
                        .rightLeg(8, 0, 2).leftLeg(16, 0, -2).tilt(-4).drop(-0.1f).shake(0f)
                .key(10, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-60, 0, 10).leftArm(10, 0, -10).head(-10, 0, 0)
                        .rightLeg(5, 0, 2).leftLeg(10, 0, -2).tilt(0).drop(0f)
                .fade(1, 6).build());

        // Mendarat pelan: lutut menekuk sedikit
        CLIPS.put(ShazamAnim.LAND_SOFT, Clip.builder(10)
                .key(0, Ease.OUT_QUAD).rightArm(-25, 0, 22).leftArm(-25, 0, -22).head(5, 0, 0)
                        .rightLeg(-25, 0, 6).leftLeg(-12, 0, -6).tilt(10).drop(0.2f)
                .key(10, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f)
                .fade(1, 4).build());

        // Hero landing: satu lutut turun, kepalan menghantam tanah, lengan lain ke belakang, badan bergetar sesaat
        CLIPS.put(ShazamAnim.LAND_HERO, Clip.builder(28)
                .key(0, Ease.OUT_QUAD).rightArm(-28, -10, 8).leftArm(48, 0, -38).head(-38, 0, 0)
                        .rightLeg(-78, 0, 10).leftLeg(58, 0, -10).tilt(34).drop(0.58f).shake(1.5f)
                .key(6, Ease.LINEAR).shake(0f)
                .key(14, Ease.LINEAR)
                .key(28, Ease.IN_OUT_SINE).rightArm(10, 0, 24).leftArm(10, 0, -24).head(-8, 0, 0)
                        .rightLeg(0, 0, 8).leftLeg(0, 0, -8).tilt(-3).drop(0f)
                .fade(1, 6).build());

        // Menabrak: lengan menahan di depan muka, badan terpental ke belakang dan sedikit terpelintir
        CLIPS.put(ShazamAnim.CRASH, Clip.builder(18)
                .key(0, Ease.OUT_QUAD).rightArm(-115, -28, 0).leftArm(-115, 28, 0).head(18, 0, 0)
                        .rightLeg(-20, 0, 6).leftLeg(10, 0, -6).tilt(-22).drop(0.08f).twist(12).shake(2f)
                .key(6, Ease.OUT_CUBIC).tilt(-12).twist(4).shake(0f)
                .key(18, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f).twist(0)
                .fade(1, 5).build());
    }
}
