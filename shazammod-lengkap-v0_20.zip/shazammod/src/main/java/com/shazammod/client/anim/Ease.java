package com.shazammod.client.anim;

/** Kurva percepatan antar-keyframe. OUT_BACK sedikit "kebablasan" lalu kembali: bagus buat pukulan. */
public enum Ease {
    LINEAR, IN_QUAD, OUT_QUAD, IN_OUT_SINE, OUT_CUBIC, OUT_BACK;

    public float apply(float t) {
        return switch (this) {
            case LINEAR -> t;
            case IN_QUAD -> t * t;
            case OUT_QUAD -> 1f - (1f - t) * (1f - t);
            case IN_OUT_SINE -> (float) (-(Math.cos(Math.PI * t) - 1.0) / 2.0);
            case OUT_CUBIC -> {
                float u = 1f - t;
                yield 1f - u * u * u;
            }
            case OUT_BACK -> {
                float c1 = 1.70158f;
                float c3 = c1 + 1f;
                float u = t - 1f;
                yield 1f + c3 * u * u * u + c1 * u * u;
            }
        };
    }
}
