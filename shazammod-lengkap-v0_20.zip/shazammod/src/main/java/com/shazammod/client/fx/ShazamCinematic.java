package com.shazammod.client.fx;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.render.ShazamCape;

import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;

/**
 * Kamera sinematik saat berubah jadi Shazam: kalau sedang di sudut pandang orang pertama, kamera pindah ke
 * depan (orang ketiga, menghadap wajah) supaya roh dewa, petir, dan kostum yang terbentuk terlihat jelas.
 * Setelah transformasi selesai, kamera kembali seperti semula. Kalau kamu mengganti kamera sendiri di
 * tengah jalan (F5), pilihanmu yang dipakai.
 */
public final class ShazamCinematic {
    private ShazamCinematic() {}

    public static final boolean ENABLED = true;
    private static final int TIMEOUT = 400;   // pengaman: paling lama 20 detik (tick dunia)

    private static CameraType previous;
    private static CameraType applied;
    private static int ticks;

    public static void start() {
        Minecraft mc = Minecraft.getInstance();
        if (!ENABLED || previous != null || !mc.options.getCameraType().isFirstPerson()) {
            return;
        }
        previous = mc.options.getCameraType();
        applied = CameraType.THIRD_PERSON_FRONT;
        set(mc, applied);
        ticks = 0;
    }

    public static void tick(Minecraft mc) {
        if (previous == null || mc.player == null) {
            return;
        }
        ticks++;
        float reveal = ShazamCape.revealTime(mc.player, 0f);
        boolean done = reveal >= ShazamAnim.TRANSFORM_SLOWMO + 6;
        boolean cancelled = !ShazamClientState.isTransformed(mc.player.getId())
                && ticks > ShazamAnim.SUMMON_TICKS + ShazamAnim.TRANSFORM_STRIKE + 20;
        if (done || cancelled || ticks > TIMEOUT) {
            restore(mc);
        }
    }

    /** Kembalikan kamera (juga dipanggil saat keluar dari dunia). */
    public static void restore(Minecraft mc) {
        if (previous != null && mc.options.getCameraType() == applied) {
            set(mc, previous);
        }
        previous = null;
        applied = null;
    }

    private static void set(Minecraft mc, CameraType type) {
        boolean wasFirst = mc.options.getCameraType().isFirstPerson();
        mc.options.setCameraType(type);
        if (wasFirst != type.isFirstPerson()) {
            mc.gameRenderer.checkEntityPostEffect(type.isFirstPerson() ? mc.getCameraEntity() : null);
        }
        mc.levelRenderer.needsUpdate();
    }
}
