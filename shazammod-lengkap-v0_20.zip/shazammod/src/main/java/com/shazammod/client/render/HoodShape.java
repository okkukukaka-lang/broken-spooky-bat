package com.shazammod.client.render;

/**
 * Bentuk hood (murni Java, gampang diuji).
 * Ruang kepala: titik nol di poros leher, +Y ke atas, depan = -Z, satuan blok (sebelum dikali ukuran badan).
 *
 * Bentuknya mengikuti kepala Minecraft yang kotak (8 px = 0,469 blok, lapisan topi skin 0,264 dari tengah):
 * - penampang kotak dengan sudut atas membulat, jadi pas membungkus kepala tanpa terlihat seperti bola;
 * - bingkai wajah lurus di samping pipi dan atas dahi, bagian atasnya sedikit maju menaungi dahi;
 * - panel samping lurus sampai belakang kepala, lalu panel belakang yang rata dengan jahitan di tengah;
 * - ujung runcing kecil di ubun-ubun belakang (khas hood jubah);
 * - tepi bawahnya melingkari pangkal kepala, tepat di dalam kerah mantel, jadi hood terlihat dijahit ke jubah.
 *
 * Grid: kolom mengelilingi bingkai wajah (rahang kiri -> atas kepala -> rahang kanan),
 * baris dari bingkai wajah (baris 0, dipaku) ke jahitan belakang (baris terakhir, kiri dan kanan dijahit jadi satu).
 *
 * Fisikanya (di Cloak): saat dipakai, hood dihitung di ruang kepala dan ditahan dekat bentuknya (jarak
 * maksimum kecil + backstop), jadi menoleh secepat apa pun hood tetap membungkus kepala dan nggak pernah
 * nyangkut di sisi yang salah. Saat dibuka atau dipasang, pinggirannya dipegang tangan dan sisanya kain bebas.
 */
public final class HoodShape {
    private HoodShape() {}

    public static final int COLS = 11;
    public static final int ROWS = 8;

    // ======= Bentuk hood saat dipakai (blok, ruang kepala) =======
    public static final double HALF_WIDTH = 0.296;    // kepala+topi 0,264: sisa 0,03 buat tebal kain
    public static final double TOP = 0.536;           // atas kepala+topi 0,498
    public static final double CORNER = 0.10;         // jari-jari sudut atas
    public static final double JAW_Y = -0.012;        // ujung bawah bingkai wajah
    public static final double NAPE_Y = -0.032;       // ujung bawah di tengkuk (sedikit lebih rendah)
    public static final double FRONT_Z = -0.276;      // bingkai wajah, tepat di depan wajah
    public static final double BRIM = 0.034;          // bingkai atas maju sejauh ini (menaungi dahi)
    public static final double SIDE_BACK_Z = 0.272;   // panel samping berakhir tepat di belakang kepala
    public static final double BACK_Z = 0.318;        // panel belakang
    public static final double PUFF = 0.016;          // kain sedikit menggembung di tengah
    public static final double PEAK_UP = 0.016;       // ujung lancip kecil di ubun-ubun belakang
    public static final double PEAK_BACK = 0.03;
    private static final int STRAIGHT_ROWS = 6;       // baris 0-5: panel samping; 6-7: panel belakang menutup

    // ======= Bahan dan bentuk pakai =======
    public static final double DENSITY = 0.45;          // kg/m²
    private static final double SHEAR = 1.0E-4;
    private static final double BEND = 0.0015;          // hood menjaga bentuknya
    /** Saat dipakai: jarak maksimum dari bentuk hood tiap baris (blok). Pinggiran wajah dipaku. */
    private static final double[] MAX_DIST_UP = {0.0, 0.012, 0.018, 0.024, 0.03, 0.036, 0.042, 0.048};
    /** Saat dipakai: tarikan ke bentuk hood (per detik). */
    private static final double[] DRIVE_UP = {0.0, 12.0, 11.0, 10.0, 9.0, 8.0, 7.0, 6.0};
    /** Saat dipakai: seberapa jauh boleh masuk ke arah kepala dari bentuknya (blok). */
    private static final double BACKSTOP_UP = 0.004;
    /** Bentuk pakai mulai berlaku saat hood hampir terpasang (down di bawah ini). */
    private static final double UP_RAMP = 0.3;

    /** Bentuk hood saat dipakai (ruang kepala). */
    public static final double[] REST_X = new double[COLS * ROWS];
    public static final double[] REST_Y = new double[COLS * ROWS];
    public static final double[] REST_Z = new double[COLS * ROWS];
    /** Pinggiran hood saat diturunkan: melingkari belakang leher, di luar kerah mantel (ruang badan, relatif leher). */
    public static final double[] DOWN_X = new double[COLS];
    public static final double[] DOWN_Y = new double[COLS];
    public static final double[] DOWN_Z = new double[COLS];

    /** Titik ke-c di bingkai kotak membulat (kiri ke kanan), out = {x, y}. Sudut atas punya titik sendiri. */
    static void arch(int c, double halfWidth, double top, double bottom, double corner, double[] out) {
        int k = Math.min(c, COLS - 1 - c);   // 0 = rahang, 5 = tengah atas
        double x, y;
        double side = top - corner;
        switch (k) {
            case 0 -> { x = -halfWidth; y = bottom; }
            case 1 -> { x = -halfWidth; y = bottom + 0.5 * (side - bottom); }
            case 2 -> { x = -halfWidth; y = side; }
            case 3 -> {
                double a = Math.toRadians(45.0);
                x = -halfWidth + corner - corner * Math.cos(a);
                y = side + corner * Math.sin(a);
            }
            case 4 -> { x = -halfWidth + corner; y = top; }
            default -> { x = 0.0; y = top; }
        }
        out[0] = c > COLS / 2 ? -x : x;
        out[1] = y;
    }

    /** Seberapa dekat kolom ke ubun-ubun (buat ujung runcing): 1 di tengah atas. */
    private static double crown(int c) {
        int k = Math.min(c, COLS - 1 - c);
        return switch (k) {
            case 5 -> 1.0;
            case 4 -> 0.55;
            case 3 -> 0.2;
            default -> 0.0;
        };
    }

    static {
        double[] a = new double[2];
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                int i = r * COLS + c;
                double bottom = JAW_Y + (NAPE_Y - JAW_Y) * r / (ROWS - 1.0);
                if (r < STRAIGHT_ROWS) {
                    double s = r / (STRAIGHT_ROWS - 1.0);
                    double puff = PUFF * Math.sin(Math.PI * s);
                    arch(c, HALF_WIDTH + puff, TOP + puff, bottom, CORNER, a);
                    double z = FRONT_Z + s * (SIDE_BACK_Z - FRONT_Z);
                    if (r == 0) {
                        double topness = clamp((a[1] - 0.30) / (TOP - 0.30));
                        z -= BRIM * topness * topness;   // bingkai atas maju, menaungi dahi
                    }
                    REST_X[i] = a[0];
                    REST_Y[i] = a[1];
                    REST_Z[i] = z;
                } else {
                    // panel belakang: menutup ke jahitan tengah, dengan ujung runcing di ubun-ubun
                    double w = (r - (STRAIGHT_ROWS - 1.0)) / (ROWS - STRAIGHT_ROWS);
                    arch(c, HALF_WIDTH, TOP, bottom, CORNER, a);
                    double peak = crown(c) * w * w;
                    REST_X[i] = a[0] * (1.0 - w);
                    REST_Y[i] = a[1] + PEAK_UP * peak;
                    REST_Z[i] = SIDE_BACK_Z + (BACK_Z - SIDE_BACK_Z) * Math.sqrt(w) + PEAK_BACK * peak;
                }
            }
        }
        for (int c = 0; c < COLS; c++) {
            double ang = (c / (double) (COLS - 1) - 0.5) * Math.toRadians(200.0);
            DOWN_X[c] = 0.335 * Math.sin(ang);
            DOWN_Y[c] = 0.05 + 0.03 * Math.cos(ang);
            DOWN_Z[c] = 0.10 + 0.255 * Math.cos(ang);
        }
    }

    private static double clamp(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }

    /** Ubah posisi dunia <-> ruang lokal (kepala atau badan), langsung di array {x, y, z}. */
    public interface Frame {
        void toLocal(double[] p);

        void toWorld(double[] p);
    }

    // ======= Saat dibuka/dipasang dan saat diturunkan =======
    /** Tarikan pelan mengikuti lintasan hood lewat atas kepala (per detik): tangan yang menuntun kainnya. */
    private static final double DRIVE_MOVE = 7.0;
    /** Lintasan berhenti menuntun di sini (down); sesudahnya hood jatuh sendiri dan tergeletak di punggung. */
    private static final double MOVE_END = 0.75;
    /** Saat diturunkan, kain hood jauh lebih lemas (gampang terlipat) daripada saat dipakai. */
    private static final double SOFT_DOWN = 25.0;
    /** Kelenturan saat tertekan (m/N): saat dipakai kain menjaga bentuk, saat diturunkan gampang melipat. */
    private static final double COMPRESS_UP = 1.0E-4;
    private static final double COMPRESS_DOWN = 0.02;

    /**
     * Atur batasan menurut keadaan hood. down: 0 = dipakai, 1 = diturunkan (sudah diperhalus).
     * Dipakai penuh: jarak maksimum kecil + tarikan + backstop ke bentuk hood (ruang kepala), jadi menoleh secepat
     * apa pun hood tetap membungkus kepala. Saat dibuka/dipasang: kain dituntun pelan lewat atas kepala (tetap kain
     * sungguhan yang menabrak kepala). Saat diturunkan: kain bebas dan lemas, menggantung dari pinggirannya di
     * belakang leher dan tergeletak di atas mantel karena beratnya sendiri.
     */
    public static void constrain(ClothSim sim, double down) {
        double up = 1.0 - smooth(down / UP_RAMP);
        double guide = 1.0 - smooth((down - 0.35) / (MOVE_END - 0.35));
        double loose = smooth((down - 0.3) / 0.6);
        sim.bendSoftness = 1.0 + (SOFT_DOWN - 1.0) * loose;
        sim.compressCompliance = COMPRESS_UP + (COMPRESS_DOWN - COMPRESS_UP) * loose;
        for (int i = COLS; i < sim.count; i++) {
            int r = i / COLS;
            if (up > 0.0) {
                sim.maxDist[i] = MAX_DIST_UP[r] + (0.4 - MAX_DIST_UP[r]) * (1.0 - up);
                sim.drive[i] = DRIVE_UP[r] * up + DRIVE_MOVE * (1.0 - up);
                sim.backstop[i] = up > 0.6 ? BACKSTOP_UP : -1.0;
            } else {
                sim.maxDist[i] = -1.0;
                sim.drive[i] = DRIVE_MOVE * guide;
                sim.backstop[i] = -1.0;
            }
        }
    }

    /** Tujuan tiap titik saat dibuka/dipasang (dunia): bentuk hood yang diputar ke belakang lewat atas kepala. */
    public static void path(int i, double down, Frame head, double[] out) {
        flipped(i, Math.PI * down, out);
        head.toWorld(out);
    }

    // Hood dilepas dengan diputar ke belakang lewat atas kepala, berporos di dekat tengkuk
    private static final double FLIP_PIVOT_Y = 0.22;
    private static final double FLIP_PIVOT_Z = 0.12;

    static double smooth(double k) {
        k = Math.max(0.0, Math.min(1.0, k));
        return k * k * (3.0 - 2.0 * k);
    }

    /** Titik ke-i bentuk hood saat diputar ke belakang (ruang kepala). angle 0 = dipakai, PI = terbalik di belakang leher. */
    public static void flipped(int i, double angle, double[] out) {
        double y = REST_Y[i] - FLIP_PIVOT_Y;
        double z = REST_Z[i] - FLIP_PIVOT_Z;
        double c = Math.cos(angle), s = Math.sin(angle);
        out[0] = REST_X[i];
        out[1] = FLIP_PIVOT_Y + y * c - z * s;
        out[2] = FLIP_PIVOT_Z + z * c + y * s;
    }

    /** Posisi dunia paku pinggiran ke-c. down: 0 = dipakai, 1 = diturunkan (sudah diperhalus). */
    public static void rim(int c, double down, Frame head, Frame neck, double[] out) {
        double[] arc = new double[3];
        flipped(c, Math.PI * down, arc);
        head.toWorld(arc);
        out[0] = DOWN_X[c];
        out[1] = DOWN_Y[c];
        out[2] = DOWN_Z[c];
        neck.toWorld(out);
        double w = smooth((down - 0.55) / 0.45);   // di akhir: menempel melingkari leher
        out[0] = arc[0] + (out[0] - arc[0]) * w;
        out[1] = arc[1] + (out[1] - arc[1]) * w;
        out[2] = arc[2] + (out[2] - arc[2]) * w;
    }

    public static ClothSim create() {
        ClothSim sim = new ClothSim(COLS, ROWS, REST_X, REST_Y, REST_Z, DENSITY);
        for (int c = 0; c < COLS; c++) {
            sim.pin(c);
        }
        sim.addGridLinks(0.0, SHEAR, BEND);
        int last = (ROWS - 1) * COLS;
        for (int i = 0; i < COLS / 2; i++) {
            sim.addSeam(last + i, last + COLS - 1 - i);   // jahitan belakang
        }
        sim.buildTethers(2, 1.02);
        constrain(sim, 0.0);
        return sim;
    }
}
