package com.shazammod.client.vfx;

/**
 * Butiran efek dalam satu kolam (tanpa objek per butir, supaya ringan walau ribuan):
 * - MOTE: butiran cahaya lembut yang melayang dan berkedip;
 * - SPARK: percikan berbentuk garis yang memanjang searah gerak (seperti tertangkap kamera), jatuh dan memantul;
 * - EMBER: bara yang naik pelan sambil mendingin (putih-kuning -> jingga -> merah);
 * - GLINT: bintang kilau empat sudut yang berputar;
 * - DUST: kepulan debu yang mengembang dan memudar (tembus pandang biasa, bervolume);
 * - SMOKE: asap tebal yang naik, melambat, mengembang, dan berkelok terbawa udara.
 *
 * Butiran baru langsung dilangkahkan sekali saat dibuat tapi umurnya tetap 0, jadi sejak frame pertama ia sudah
 * bergerak dan masih seterang-terangnya (dulu umurnya langsung jadi 1 dan awal hidupnya hilang).
 */
final class Particles {
    static final int MOTE = 0, SPARK = 1, EMBER = 2, GLINT = 3, DUST = 4, SMOKE = 5;
    private static final int MAX = 6000;

    private final double[] x = new double[MAX], y = new double[MAX], z = new double[MAX];
    private final double[] ox = new double[MAX], oy = new double[MAX], oz = new double[MAX];
    private final double[] vx = new double[MAX], vy = new double[MAX], vz = new double[MAX];
    private final double[] floor = new double[MAX];
    private final float[] size = new float[MAX], gravity = new float[MAX], drag = new float[MAX], seed = new float[MAX];
    private final int[] age = new int[MAX], life = new int[MAX], color = new int[MAX], type = new int[MAX];
    private final int[] born = new int[MAX];
    private int count;
    private int clock;
    private int pick = 0x2545F491;

    boolean isEmpty() {
        return count == 0;
    }

    void clear() {
        count = 0;
    }

    int spawn(int kind, double px, double py, double pz, double mx, double my, double mz, int rgb, float s, int ticks,
              float grav, float dragPerTick, double floorY, float rand) {
        int i = count < MAX ? count++ : victim();
        type[i] = kind;
        x[i] = px; y[i] = py; z[i] = pz;
        vx[i] = mx; vy[i] = my; vz[i] = mz;
        color[i] = rgb;
        size[i] = s;
        life[i] = Math.max(1, ticks);
        age[i] = 0;
        gravity[i] = grav;
        drag[i] = dragPerTick;
        floor[i] = floorY;
        seed[i] = rand;
        born[i] = clock;
        step(i);
        return i;
    }

    /** Kolam penuh: ganti butiran yang paling dekat habis (dipilih dari beberapa contoh acak, supaya murah). */
    private int victim() {
        int best = 0;
        float most = -1f;
        for (int k = 0; k < 12; k++) {
            pick = pick * 1103515245 + 12345;
            int j = (pick >>> 1) % count;
            float p = age[j] / (float) life[j];
            if (p > most) {
                most = p;
                best = j;
            }
        }
        return best;
    }

    void tick() {
        int i = 0;
        while (i < count) {
            if (born[i] == clock) {   // lahir tick ini: sudah dilangkahkan saat dibuat
                i++;
                continue;
            }
            if (++age[i] >= life[i]) {
                remove(i);
                continue;
            }
            step(i);
            i++;
        }
    }

    /** Dipanggil di akhir tick efek, sesudah semua butiran tick ini dibuat. */
    void endTick() {
        clock++;
    }

    /** Satu langkah gerak (satu tick). */
    private void step(int i) {
        ox[i] = x[i]; oy[i] = y[i]; oz[i] = z[i];
        vy[i] -= gravity[i];
        float k = 1f - drag[i];
        vx[i] *= k; vy[i] *= k; vz[i] *= k;
        int kind = type[i];
        if (kind == EMBER) {   // bara: naik berkelok-kelok
            double a = age[i] * 0.35 + seed[i] * 20.0;
            vx[i] += Math.sin(a) * 0.004;
            vz[i] += Math.cos(a * 1.3) * 0.004;
        } else if (kind == SMOKE) {   // asap: berkelok pelan terbawa pusaran udara
            double a = age[i] * 0.12 + seed[i] * 40.0;
            vx[i] += Math.sin(a) * 0.0025;
            vz[i] += Math.cos(a * 1.4) * 0.0025;
        }
        x[i] += vx[i]; y[i] += vy[i]; z[i] += vz[i];
        if (!Double.isNaN(floor[i]) && y[i] < floor[i]) {   // memantul di tanah
            y[i] = floor[i];
            vy[i] = Math.abs(vy[i]) * 0.35;
            vx[i] *= 0.6;
            vz[i] *= 0.6;
        }
    }

    private void remove(int i) {
        int last = --count;
        if (i == last) {
            return;
        }
        type[i] = type[last];
        x[i] = x[last]; y[i] = y[last]; z[i] = z[last];
        ox[i] = ox[last]; oy[i] = oy[last]; oz[i] = oz[last];
        vx[i] = vx[last]; vy[i] = vy[last]; vz[i] = vz[last];
        floor[i] = floor[last];
        size[i] = size[last]; gravity[i] = gravity[last]; drag[i] = drag[last]; seed[i] = seed[last];
        age[i] = age[last]; life[i] = life[last]; color[i] = color[last]; born[i] = born[last];
    }

    void renderGlow(Draw d) {
        float pt = d.partialTick;
        for (int i = 0; i < count; i++) {
            int kind = type[i];
            if (kind == DUST || kind == SMOKE) {
                continue;
            }
            double px = ox[i] + (x[i] - ox[i]) * pt, py = oy[i] + (y[i] - oy[i]) * pt, pz = oz[i] + (z[i] - oz[i]) * pt;
            float t = Math.min(1f, (age[i] + pt) / life[i]);
            float fade = 1f - t;
            switch (kind) {
                case MOTE -> {
                    float flicker = 0.75f + 0.25f * (float) Math.sin((age[i] + pt) * 0.9f + seed[i] * 40f);
                    float a = fade * fade * flicker;
                    d.glow(px, py, pz, size[i] * (0.7f + 0.45f * fade), color[i], a);
                    d.glow(px, py, pz, size[i] * 0.3f, 0xFFFFFF, a * 0.85f);
                }
                case SPARK -> {
                    // ekor searah gerak, seperti percikan yang tertangkap kamera: makin cepat makin panjang
                    double tx = px - vx[i] * 2.2, ty = py - vy[i] * 2.2, tz = pz - vz[i] * 2.2;
                    float a = fade;
                    d.line(tx, ty, tz, px, py, pz, size[i] * 0.5f, size[i] * 1.35f, color[i], 0f, a);
                    d.line(tx, ty, tz, px, py, pz, size[i] * 0.2f, size[i] * 0.5f, 0xFFFFFF, 0f, a);
                    d.glow(px, py, pz, size[i] * 1.7f, color[i], a * 0.4f);   // kepala yang membara
                }
                case EMBER -> {
                    int c = cool(t);
                    float a = fade * (0.8f + 0.2f * (float) Math.sin((age[i] + pt) * 1.7f + seed[i] * 31f));
                    d.glow(px, py, pz, size[i] * 1.15f, c, a);
                    d.glow(px, py, pz, size[i] * 0.38f, 0xFFF2C0, a * fade);
                }
                case GLINT -> {
                    float a = (float) Math.sin(Math.PI * t);
                    d.glint(px, py, pz, size[i] * (0.5f + 0.5f * a), seed[i] * 6.28f + (age[i] + pt) * 0.12f, color[i], a);
                }
                default -> { }
            }
        }
    }

    void renderSoft(Draw d) {
        float pt = d.partialTick;
        for (int i = 0; i < count; i++) {
            int kind = type[i];
            if (kind != DUST && kind != SMOKE) {
                continue;
            }
            double px = ox[i] + (x[i] - ox[i]) * pt, py = oy[i] + (y[i] - oy[i]) * pt, pz = oz[i] + (z[i] - oz[i]) * pt;
            float t = Math.min(1f, (age[i] + pt) / life[i]);
            int c = color[i];
            if (kind == DUST) {
                float a = 0.72f * (float) Math.sin(Math.PI * Math.min(1f, t * 1.6f + 0.12f)) * (1f - t);
                d.puff(px, py, pz, size[i] * (0.55f + 0.9f * t), Draw.mix(c, 0xFFFFFF, 0.16), Draw.mix(c, 0x000000, 0.38), a);
            } else {
                // asap: cepat menebal, lalu menipis pelan sambil terus mengembang
                float in = Math.min(1f, t / 0.1f);
                float a = 0.55f * in * (float) Math.pow(1f - t, 1.3);
                float r = size[i] * (0.6f + 1.7f * (float) Math.sqrt(t));
                d.puff(px, py, pz, r, Draw.mix(c, 0xFFFFFF, 0.22), Draw.mix(c, 0x000000, 0.35), a);
            }
        }
    }

    /** Warna bara yang mendingin. */
    private static int cool(float t) {
        if (t < 0.35f) {
            return lerpColor(0xFFF0B0, 0xFFA030, t / 0.35f);
        }
        return lerpColor(0xFFA030, 0xC03010, (t - 0.35f) / 0.65f);
    }

    static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 0xFF) + (((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * t);
        int g = (int) (((a >> 8) & 0xFF) + (((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * t);
        int bl = (int) ((a & 0xFF) + ((b & 0xFF) - (a & 0xFF)) * t);
        return (r << 16) | (g << 8) | bl;
    }
}
