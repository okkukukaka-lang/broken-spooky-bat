package com.shazammod.client.render;

/**
 * Bagian tubuh pemain untuk kain (murni Java): ruang tiap bagian dan kotak tabrakannya, dari pose model
 * (ShazamPoses.parts: x, y, z poros dalam piksel model, lalu xRot, yRot, zRot dalam radian, untuk kepala,
 * badan, lengan kanan, lengan kiri, kaki kanan, kaki kiri).
 *
 * Ruang badan: titik nol di kaki, +Y ke atas, depan = -Z, satuan blok sebelum dikali ukuran badan
 * (sama dengan ShazamPoses.bodyMatrix). Model Minecraft dibalik (scale -1, -1, 1), dikecilkan 0,9375, dan
 * digeser 1,501 ke bawah; semua itu sudah dihitung di sini.
 */
public final class BodyRig {
    private BodyRig() {}

    public static final int HEAD = 0, TORSO = 1, RIGHT_ARM = 2, LEFT_ARM = 3, RIGHT_LEG = 4, LEFT_LEG = 5;
    public static final int VALUES = 36;
    /** 1 piksel model = sekian blok. */
    public static final double UNIT = 0.9375 / 16.0;
    /** Pose berdiri biasa (kalau model belum pernah digambar). */
    public static final float[] DEFAULT = {
            0f, 0f, 0f, 0f, 0f, 0f,
            0f, 0f, 0f, 0f, 0f, 0f,
            -5f, 2f, 0f, 0f, 0f, 0f,
            5f, 2f, 0f, 0f, 0f, 0f,
            -1.9f, 12f, 0f, 0f, 0f, 0f,
            1.9f, 12f, 0f, 0f, 0f, 0f};

    /** Ruang bagian tubuh di ruang badan: titik nol di poros bagian, sumbu ikut putarannya (kaku, tanpa skala). */
    public static Xform frame(float[] parts, int part, Xform out) {
        int o = part * 6;
        out.identity();
        out.tx = -parts[o] * UNIT;
        out.ty = 0.9375 * 1.501 - parts[o + 1] * UNIT;
        out.tz = parts[o + 2] * UNIT;
        out.rotateZ(parts[o + 5]).rotateY(-parts[o + 4]).rotateX(-parts[o + 3]);
        return out;
    }

    /**
     * Ruang leher: poros kepala, ikut putaran badan atas (membungkuk, memutar pinggang), tapi tidak ikut
     * putaran kepala. Kerah mantel dan hood yang diturunkan menempel di sini.
     */
    public static Xform neck(float[] parts, Xform out) {
        out.identity();
        out.tx = -parts[0] * UNIT;
        out.ty = 0.9375 * 1.501 - parts[1] * UNIT;
        out.tz = parts[2] * UNIT;
        int o = TORSO * 6;
        out.rotateZ(parts[o + 5]).rotateY(-parts[o + 4]).rotateX(-parts[o + 3]);
        return out;
    }

    /**
     * Kotak tabrakan bagian tubuh di ruang bagiannya: {pusat x, y, z, setengah lebar, tinggi, tebal}.
     * Termasuk lapisan luar skin (topi, jaket, lengan baju, celana).
     */
    public static void box(int part, boolean slim, double[] out) {
        double u = UNIT;
        switch (part) {
            case HEAD -> set(out, 0, 4 * u, 0, 4.5 * u, 4.5 * u, 4.5 * u);
            case TORSO -> set(out, 0, -6 * u, 0, 4.25 * u, 6.25 * u, 2.25 * u);
            case RIGHT_ARM -> set(out, (slim ? 0.5 : 1.0) * u, -4 * u, 0, (slim ? 1.75 : 2.25) * u, 6.25 * u, 2.25 * u);
            case LEFT_ARM -> set(out, -(slim ? 0.5 : 1.0) * u, -4 * u, 0, (slim ? 1.75 : 2.25) * u, 6.25 * u, 2.25 * u);
            default -> set(out, 0, -6 * u, 0, 2.25 * u, 6.25 * u, 2.25 * u);
        }
    }

    private static void set(double[] out, double cx, double cy, double cz, double hx, double hy, double hz) {
        out[0] = cx; out[1] = cy; out[2] = cz; out[3] = hx; out[4] = hy; out[5] = hz;
    }

    /** Campuran dua pose (sudut dan poros dicampur lurus; cukup untuk selang satu frame). */
    public static void lerp(float[] a, float[] b, double t, float[] out) {
        for (int i = 0; i < VALUES; i++) {
            out[i] = (float) (a[i] + (b[i] - a[i]) * t);
        }
    }
}
