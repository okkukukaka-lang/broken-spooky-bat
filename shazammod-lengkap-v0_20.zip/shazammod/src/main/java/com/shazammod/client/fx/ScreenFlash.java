package com.shazammod.client.fx;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/** Layar memutih sesaat saat petir sihir menyambar diri sendiri. */
public final class ScreenFlash {
    private ScreenFlash() {}

    private static float alpha;
    private static float alphaO;
    private static int color = 0xFFF8E0;

    public static void flash(float strength) {
        flash(strength, 0xFFF8E0);
    }

    /** Kilatan layar berwarna (rgb). */
    public static void flash(float strength, int rgb) {
        if (strength >= alpha) {
            color = rgb & 0xFFFFFF;
        }
        alpha = Math.max(alpha, strength);
        alphaO = alpha;
    }

    public static void clear() {
        alpha = 0f;
        alphaO = 0f;
    }

    public static void tick() {
        alphaO = alpha;
        alpha = Math.max(0f, alpha - 0.07f);
    }

    public static void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        float a = Mth.lerp(deltaTracker.getGameTimeDeltaPartialTick(false), alphaO, alpha);
        if (a <= 0.01f) {
            return;
        }
        int argb = ((int) (Math.min(1f, a) * 255f) << 24) | color;
        graphics.fill(0, 0, graphics.guiWidth(), graphics.guiHeight(), argb);
    }
}
