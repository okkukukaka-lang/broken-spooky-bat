package com.shazammod.client.render;

/**
 * Tabrakan kain (murni Java): kotak bagian tubuh (bersudut bulat) yang ikut bergerak, kotak blok dunia, dan
 * lapisan kain lain (mantel di atas jubah, hood yang diturunkan di atas mantel).
 *
 * Arah dorongan selalu diambil dari sisi tempat titik kain berada di langkah sebelumnya (tabrakan menerus),
 * bukan sekadar "sisi terdekat". Jadi kain yang terdorong cepat oleh lengan atau kepala nggak pernah tembus
 * lalu terdorong keluar lewat sisi yang salah dan nyangkut di sana.
 * Gesekan: gerak menyamping di permukaan dikurangi sebanding dalamnya tekanan (gesekan Coulomb versi posisi).
 */
public final class ClothCollider {
    private ClothCollider() {}

    // sisi kotak yang boleh dipakai untuk mendorong keluar
    public static final int POS_X = 1, NEG_X = 2, POS_Y = 4, NEG_Y = 8, POS_Z = 16, NEG_Z = 32, ALL = 63;
    /** Jari-jari sudut kotak bagian tubuh (blok). */
    private static final double ROUND = 0.035;

    /** Kotak berorientasi di ruang lokal kain: ruang kotak -> ruang kain (kaku, tanpa skala). */
    public static final class Box {
        public final Xform now = new Xform();
        public final Xform prev = new Xform();
        public double hx, hy, hz;
        /** Jari-jari sudut membulat (kain meluncur di sudut, nggak tersangkut). */
        public double radius;
        public int faces = ALL;
        public boolean active;
        private boolean hasPrev;

        /** Pasang pose baru kotak; pose lama otomatis jadi "prev" (buat gesekan dan arah dorong). */
        public void update(Xform pose, double cx, double cy, double cz, double hx, double hy, double hz) {
            if (hasPrev) {
                prev.set(now);
            }
            now.set(pose).translate(cx, cy, cz);
            if (!hasPrev) {
                prev.set(now);
                hasPrev = true;
            }
            this.hx = hx;
            this.hy = hy;
            this.hz = hz;
            radius = Math.min(ROUND, 0.8 * Math.min(hx, Math.min(hy, hz)));
            active = true;
        }

        /** Lupakan pose lama (misalnya kain baru dipindah ke bingkai lain). */
        public void forget() {
            hasPrev = false;
        }
    }

    /**
     * Dorong titik-titik bebas keluar dari kotak.
     * @param thick    tebal kain + celah (blok lokal)
     * @param friction koefisien gesek
     * @param from     titik pertama yang dicek (misalnya lewati baris yang dipaku)
     */
    public static void collide(ClothSim sim, Box box, double thick, double friction, int from) {
        if (!box.active) {
            return;
        }
        double ex = box.hx + thick, ey = box.hy + thick, ez = box.hz + thick;
        double r = box.radius;
        double ix = box.hx - r, iy = box.hy - r, iz = box.hz - r;   // kotak dalam (tanpa sudut membulat)
        double reach = r + thick;
        double[] q = new double[3], qp = new double[3];
        // bola pembungkus kotak: titik yang jauh langsung dilewati
        double bx = box.now.tx, by = box.now.ty, bz = box.now.tz;
        double bound = ex * ex + ey * ey + ez * ez;
        for (int i = from; i < sim.count; i++) {
            if (sim.w[i] == 0.0) {
                continue;
            }
            double ox = sim.x[i] - bx, oy = sim.y[i] - by, oz = sim.z[i] - bz;
            if (ox * ox + oy * oy + oz * oz >= bound) {
                continue;
            }
            q[0] = sim.x[i]; q[1] = sim.y[i]; q[2] = sim.z[i];
            box.now.toLocal(q);
            if (Math.abs(q[0]) >= ex || Math.abs(q[1]) >= ey || Math.abs(q[2]) >= ez) {
                continue;
            }
            qp[0] = sim.px[i]; qp[1] = sim.py[i]; qp[2] = sim.pz[i];
            box.prev.toLocal(qp);
            // di luar kotak dalam: dorong menjauhi titik terdekatnya (permukaan membulat, arah mulus)
            double cx = clamp(q[0], ix), cy = clamp(q[1], iy), cz = clamp(q[2], iz);
            double dx = q[0] - cx, dy = q[1] - cy, dz = q[2] - cz;
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            boolean moved;
            if (d > 1.0E-9) {
                if (d >= reach) {
                    continue;
                }
                double nx = dx / d, ny = dy / d, nz = dz / d;
                double depth = reach - d;
                q[0] = cx + nx * reach; q[1] = cy + ny * reach; q[2] = cz + nz * reach;
                friction(q, qp, nx, ny, nz, depth, friction);
                moved = true;
            } else {
                moved = pushOut(q, qp, ex, ey, ez, box.faces, friction);
            }
            if (moved) {
                box.now.toWorld(q);
                sim.x[i] = q[0]; sim.y[i] = q[1]; sim.z[i] = q[2];
            }
        }
    }

    private static double clamp(double v, double h) {
        return v < -h ? -h : (v > h ? h : v);
    }

    /** Gesekan Coulomb versi posisi: gerak menyamping relatif permukaan dikurangi sebanding dalamnya tekanan. */
    private static void friction(double[] q, double[] qp, double nx, double ny, double nz, double depth, double mu) {
        if (mu <= 0.0) {
            return;
        }
        double mx = q[0] - qp[0], my = q[1] - qp[1], mz = q[2] - qp[2];
        double mn = mx * nx + my * ny + mz * nz;
        double tx = mx - mn * nx, ty = my - mn * ny, tz = mz - mn * nz;
        double t = Math.sqrt(tx * tx + ty * ty + tz * tz);
        if (t > 1.0E-12) {
            double f = Math.min(1.0, mu * depth / t);
            q[0] -= tx * f; q[1] -= ty * f; q[2] -= tz * f;
        }
    }

    /**
     * Titik q (ruang kotak, di dalam kotak setengah-ukuran e) didorong ke luar. qp = posisinya di langkah lalu
     * (ruang kotak langkah lalu). Sisi dipilih dari tempat titik datang; kalau sudah di dalam sejak awal,
     * pakai sisi terdekat yang diizinkan.
     */
    static boolean pushOut(double[] q, double[] qp, double ex, double ey, double ez, int faces, double friction) {
        double[] e = {ex, ey, ez};
        int axis = -1;
        double side = 0.0;
        // 1) sisi tempat titik itu datang (paling jauh di luar pada langkah lalu)
        double best = 0.0;
        for (int k = 0; k < 3; k++) {
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                if (!allowed(faces, k, sgn)) {
                    continue;
                }
                double out = sgn * qp[k] - e[k];
                if (out > best) {
                    best = out;
                    axis = k;
                    side = sgn;
                }
            }
        }
        // 2) sudah di dalam: sisi terdekat yang diizinkan
        if (axis < 0) {
            double near = Double.POSITIVE_INFINITY;
            for (int k = 0; k < 3; k++) {
                for (int sgn = -1; sgn <= 1; sgn += 2) {
                    if (!allowed(faces, k, sgn)) {
                        continue;
                    }
                    double dist = e[k] - sgn * q[k];
                    if (dist < near) {
                        near = dist;
                        axis = k;
                        side = sgn;
                    }
                }
            }
        }
        if (axis < 0) {
            return false;
        }
        double depth = side * e[axis] - q[axis];
        q[axis] = side * e[axis];
        if (friction > 0.0) {
            // gerak menyamping relatif ke permukaan kotak selama langkah ini
            double tx = q[0] - qp[0], ty = q[1] - qp[1], tz = q[2] - qp[2];
            if (axis == 0) tx = 0; else if (axis == 1) ty = 0; else tz = 0;
            double t = Math.sqrt(tx * tx + ty * ty + tz * tz);
            if (t > 1.0E-12) {
                double f = Math.min(1.0, friction * Math.abs(depth) / t);
                q[0] -= tx * f; q[1] -= ty * f; q[2] -= tz * f;
            }
        }
        return true;
    }

    private static boolean allowed(int faces, int axis, int sgn) {
        int bit = switch (axis) {
            case 0 -> sgn > 0 ? POS_X : NEG_X;
            case 1 -> sgn > 0 ? POS_Y : NEG_Y;
            default -> sgn > 0 ? POS_Z : NEG_Z;
        };
        return (faces & bit) != 0;
    }

    /**
     * Blok dunia: kotak sejajar sumbu dunia {minX, minY, minZ, maxX, maxY, maxZ, ...}.
     * Kotak yang jauh dari kain disaring dulu sekali per panggilan, jadi di lorong atau gua tetap ringan.
     * @param frame     ruang kain -> dunia sekarang
     * @param prevFrame ruang kain -> dunia di langkah lalu
     */
    public static void world(ClothSim sim, Xform frame, Xform prevFrame, double[] boxes, int boxCount,
                             double thick, double friction, int from) {
        if (boxCount <= 0) {
            return;
        }
        int n = sim.count;
        double[] wx = new double[n], wy = new double[n], wz = new double[n];
        double minX = Double.POSITIVE_INFINITY, minY = minX, minZ = minX;
        double maxX = Double.NEGATIVE_INFINITY, maxY = maxX, maxZ = maxX;
        double[] p = new double[3];
        for (int i = from; i < n; i++) {
            p[0] = sim.x[i]; p[1] = sim.y[i]; p[2] = sim.z[i];
            frame.toWorld(p);
            wx[i] = p[0]; wy[i] = p[1]; wz[i] = p[2];
            minX = Math.min(minX, p[0]); minY = Math.min(minY, p[1]); minZ = Math.min(minZ, p[2]);
            maxX = Math.max(maxX, p[0]); maxY = Math.max(maxY, p[1]); maxZ = Math.max(maxZ, p[2]);
        }
        // kotak yang menyentuh daerah kain saja
        int[] near = new int[boxCount];
        int count = 0;
        for (int b = 0; b < boxCount; b++) {
            int o = b * 6;
            if (boxes[o] - thick > maxX || boxes[o + 3] + thick < minX || boxes[o + 1] - thick > maxY
                    || boxes[o + 4] + thick < minY || boxes[o + 2] - thick > maxZ || boxes[o + 5] + thick < minZ) {
                continue;
            }
            near[count++] = b;
        }
        if (count == 0) {
            return;
        }
        double[] pp = new double[3], q = new double[3], qp = new double[3];
        for (int i = from; i < n; i++) {
            if (sim.w[i] == 0.0) {
                continue;
            }
            p[0] = wx[i]; p[1] = wy[i]; p[2] = wz[i];
            boolean moved = false;
            boolean havePrev = false;
            for (int k = 0; k < count; k++) {
                int o = near[k] * 6;
                double cx = (boxes[o] + boxes[o + 3]) * 0.5, cy = (boxes[o + 1] + boxes[o + 4]) * 0.5, cz = (boxes[o + 2] + boxes[o + 5]) * 0.5;
                double ex = (boxes[o + 3] - boxes[o]) * 0.5 + thick, ey = (boxes[o + 4] - boxes[o + 1]) * 0.5 + thick,
                        ez = (boxes[o + 5] - boxes[o + 2]) * 0.5 + thick;
                q[0] = p[0] - cx; q[1] = p[1] - cy; q[2] = p[2] - cz;
                if (Math.abs(q[0]) >= ex || Math.abs(q[1]) >= ey || Math.abs(q[2]) >= ez) {
                    continue;
                }
                if (!havePrev) {
                    pp[0] = sim.px[i]; pp[1] = sim.py[i]; pp[2] = sim.pz[i];
                    prevFrame.toWorld(pp);
                    havePrev = true;
                }
                qp[0] = pp[0] - cx; qp[1] = pp[1] - cy; qp[2] = pp[2] - cz;
                if (pushOut(q, qp, ex, ey, ez, ALL, friction)) {
                    p[0] = q[0] + cx; p[1] = q[1] + cy; p[2] = q[2] + cz;
                    moved = true;
                }
            }
            if (moved) {
                frame.toLocal(p);
                sim.x[i] = p[0]; sim.y[i] = p[1]; sim.z[i] = p[2];
            }
        }
    }

    /**
     * Lapisan kain lain sebagai permukaan "tinggi" searah +Z ruangnya: titik kain tetap di luar (z lebih besar)
     * permukaan itu, misalnya mantel tetap di luar bagian atas jubah. Satu arah: lapisan bawah nggak terdorong.
     *
     * @param under   kain di bawah (posisi di ruangnya sendiri)
     * @param rows0   baris pertama..terakhir (inklusif) dan kolom pertama..terakhir yang dipakai sebagai permukaan
     * @param toUnder ruang kain ini -> ruang kain bawah (kaku)
     * @param clear   jarak minimum di luar permukaan
     * @param minZ    titik yang z-nya (di ruang kain bawah) kurang dari ini diabaikan (misalnya bagian depan badan)
     */
    public static void layer(ClothSim sim, ClothSim under, int rows0, int rows1, int cols0, int cols1,
                             Xform toUnder, Xform fromUnder, double clear, double minZ, int from) {
        if (under == null || !under.isReady()) {
            return;
        }
        int nr = rows1 - rows0 + 1;
        double[] ry = new double[nr], rz = new double[nr];
        boolean[] ok = new boolean[nr];
        double[] p = new double[3];
        for (int i = from; i < sim.count; i++) {
            if (sim.w[i] == 0.0) {
                continue;
            }
            p[0] = sim.x[i]; p[1] = sim.y[i]; p[2] = sim.z[i];
            toUnder.toWorld(p);   // ruang kain ini -> ruang kain bawah
            if (p[2] < minZ) {
                continue;
            }
            // tinggi (y) dan z permukaan tiap baris di x titik ini
            for (int k = 0; k < nr; k++) {
                int r = rows0 + k;
                ok[k] = false;
                for (int c = cols0; c < cols1; c++) {
                    int a = r * under.cols + c, b = a + 1;
                    double xa = under.x[a], xb = under.x[b];
                    double lo = Math.min(xa, xb), hi = Math.max(xa, xb);
                    if (p[0] < lo || p[0] > hi) {
                        continue;
                    }
                    double f = hi - lo < 1.0E-9 ? 0.5 : (p[0] - xa) / (xb - xa);
                    double yy = under.y[a] + (under.y[b] - under.y[a]) * f;
                    double zz = under.z[a] + (under.z[b] - under.z[a]) * f;
                    if (!ok[k] || zz > rz[k]) {
                        ry[k] = yy;
                        rz[k] = zz;
                        ok[k] = true;
                    }
                }
            }
            double surface = Double.NEGATIVE_INFINITY;
            for (int k = 0; k + 1 < nr; k++) {
                if (!ok[k] || !ok[k + 1]) {
                    continue;
                }
                double y0 = ry[k], y1 = ry[k + 1];
                double lo = Math.min(y0, y1), hi = Math.max(y0, y1);
                if (p[1] < lo || p[1] > hi) {
                    continue;
                }
                double f = hi - lo < 1.0E-9 ? 0.5 : (p[1] - y0) / (y1 - y0);
                surface = Math.max(surface, rz[k] + (rz[k + 1] - rz[k]) * f);
            }
            if (surface > Double.NEGATIVE_INFINITY && p[2] < surface + clear) {
                p[2] = surface + clear;
                fromUnder.toWorld(p);
                sim.x[i] = p[0]; sim.y[i] = p[1]; sim.z[i] = p[2];
            }
        }
    }
}
