package com.shazammod.infinity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/**
 * 0.64 Perubahan dunia oleh Kuasa Infinity, dikerjakan sedikit demi sedikit tiap tick server (nggak bikin lag sekaligus):
 *
 *   Ledakan Kawah     mangkuk raksasa dicungkil dari pusat ke luar (tanpa drop barang), dindingnya hangus: basal,
 *                     batu hitam, magma, obsidian. Blok yang nggak bisa dihancurkan & blok berisi (peti, tungku, dll.)
 *                     dibiarkan.
 *   Tulis Ulang Dunia permukaan dalam lingkaran berubah tema (Kristal, Neraka, End, Beku, Emas palsu) mengikuti gelombang
 *                     yang menyebar, lalu KEMBALI seperti semula sesudah waktunya (atau permanen, rewriteSeconds = 0).
 *                     Blok yang sudah diubah pemain nggak ditimpa. Saat server dimatikan, semua dunia yang berubah
 *                     dikembalikan dulu.
 */
public final class InfinityWorld {
    private InfinityWorld() {}

    public static final int CRYSTAL = 0, NETHER = 1, END = 2, FROST = 3, GOLD = 4, THEMES = 5;
    private static final int CARVE_PER_TICK = 4000;
    private static final int REWRITE_COLUMNS_MIN = 60;

    private interface Job {
        /** false = selesai. */
        boolean tick(MinecraftServer server);
    }

    private static final List<Job> JOBS = new ArrayList<>();

    public static void tick(MinecraftServer server) {
        if (JOBS.isEmpty()) {
            return;
        }
        Iterator<Job> it = new ArrayList<>(JOBS).iterator();
        while (it.hasNext()) {
            Job job = it.next();
            if (!job.tick(server)) {
                JOBS.remove(job);
            }
        }
    }

    /** Server dimatikan: dunia yang sedang berubah dikembalikan sekarang juga, kawah yang belum selesai dibiarkan. */
    public static void revertAll(MinecraftServer server) {
        for (Job job : new ArrayList<>(JOBS)) {
            if (job instanceof Rewrite rewrite) {
                rewrite.revertNow();
            }
        }
        JOBS.clear();
    }

    static boolean breakable(ServerLevel level, BlockPos pos, BlockState state) {
        return !state.isAir() && level.isLoaded(pos) && state.getDestroySpeed(level, pos) >= 0f && level.getBlockEntity(pos) == null;
    }

    // ---------------------------------------------------------------- Ledakan Kawah

    public static void crater(ServerLevel level, Vec3 center, int radius) {
        RandomSource r = level.random;
        int cx = (int) Math.floor(center.x), cy = (int) Math.floor(center.y), cz = (int) Math.floor(center.z);
        double depth = radius * 0.6;
        List<long[]> carve = new ArrayList<>();
        List<BlockPos> rim = new ArrayList<>();
        int size = 2 * radius + 1;
        float[] jitter = new float[size * size];
        for (int i = 0; i < jitter.length; i++) {
            jitter[i] = (r.nextFloat() - 0.5f) * 0.16f;
        }
        for (int dx = -radius - 1; dx <= radius + 1; dx++) {
            for (int dz = -radius - 1; dz <= radius + 1; dz++) {
                int ji = (Math.max(-radius, Math.min(radius, dx)) + radius) * size + (Math.max(-radius, Math.min(radius, dz)) + radius);
                double edge = 1.0 + jitter[ji];
                double horiz = (dx * dx + dz * dz) / (double) (radius * radius);
                for (int dy = (int) -Math.ceil(depth) - 2; dy <= radius; dy++) {
                    double f = dy <= 0 ? horiz + (dy * dy) / (depth * depth) : (dx * dx + dz * dz + dy * dy) / (double) (radius * radius);
                    if (f <= edge) {
                        carve.add(new long[] {BlockPos.asLong(cx + dx, cy + dy, cz + dz), (long) (dx * dx + dy * dy + dz * dz)});
                    } else if (dy <= 0 && f <= edge + 0.22) {
                        rim.add(new BlockPos(cx + dx, cy + dy, cz + dz));
                    }
                }
            }
        }
        carve.sort((a, b) -> Long.compare(a[1], b[1]));   // dari pusat ke luar
        long[] order = new long[carve.size()];
        for (int i = 0; i < order.length; i++) {
            order[i] = carve.get(i)[0];
        }
        JOBS.add(new Crater(level, order, rim, center, radius));
    }

    private static final class Crater implements Job {
        private final ServerLevel level;
        private final long[] carve;
        private final List<BlockPos> rim;
        private final Vec3 center;
        private final int radius;
        private int index, rimIndex;

        Crater(ServerLevel level, long[] carve, List<BlockPos> rim, Vec3 center, int radius) {
            this.level = level;
            this.carve = carve;
            this.rim = rim;
            this.center = center;
            this.radius = radius;
        }

        @Override
        public boolean tick(MinecraftServer server) {
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
            int end = Math.min(carve.length, index + CARVE_PER_TICK);
            for (; index < end; index++) {
                pos.set(carve[index]);
                BlockState state = level.getBlockState(pos);
                if (breakable(level, pos, state)) {
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                }
            }
            if (index < carve.length) {
                return true;
            }
            RandomSource r = level.random;
            int rimEnd = Math.min(rim.size(), rimIndex + CARVE_PER_TICK);
            for (; rimIndex < rimEnd; rimIndex++) {   // dinding kawah yang hangus
                BlockPos p = rim.get(rimIndex);
                BlockState state = level.getBlockState(p);
                if (!breakable(level, p, state) || !level.getBlockState(p.above()).isAir() || r.nextFloat() > 0.8f) {
                    continue;
                }
                double d = Math.sqrt(p.distToCenterSqr(center)) / radius;
                float f = r.nextFloat();
                BlockState burnt = (d < 0.75 ? (f < 0.35f ? Blocks.MAGMA_BLOCK : f < 0.6f ? Blocks.OBSIDIAN : f < 0.7f ? Blocks.CRYING_OBSIDIAN
                        : Blocks.BLACKSTONE) : (f < 0.4f ? Blocks.BASALT : f < 0.7f ? Blocks.BLACKSTONE : f < 0.85f ? Blocks.COARSE_DIRT
                        : Blocks.MAGMA_BLOCK)).defaultBlockState();
                level.setBlock(p, burnt, Block.UPDATE_CLIENTS);
            }
            return rimIndex < rim.size();
        }
    }

    // ---------------------------------------------------------------- Tulis Ulang Dunia

    public static void rewrite(ServerLevel level, Vec3 center, int radius, int theme, int revertTicks, int casterId) {
        List<int[]> columns = new ArrayList<>();
        int cx = (int) Math.floor(center.x), cz = (int) Math.floor(center.z);
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                int d2 = dx * dx + dz * dz;
                if (d2 <= radius * radius) {
                    columns.add(new int[] {cx + dx, cz + dz, d2});
                }
            }
        }
        columns.sort((a, b) -> Integer.compare(a[2], b[2]));
        JOBS.add(new Rewrite(level, center, radius, Math.floorMod(theme, THEMES), revertTicks, casterId, columns));
    }

    private static final class Rewrite implements Job {
        private final ServerLevel level;
        private final Vec3 center;
        private final int radius, theme, revertTicks, casterId;
        private final List<int[]> columns;
        private final Map<BlockPos, BlockState[]> changed = new LinkedHashMap<>();
        private Iterator<Map.Entry<BlockPos, BlockState[]>> reverting;
        private int age, colIndex;

        Rewrite(ServerLevel level, Vec3 center, int radius, int theme, int revertTicks, int casterId, List<int[]> columns) {
            this.level = level;
            this.center = center;
            this.radius = radius;
            this.theme = theme;
            this.revertTicks = revertTicks;
            this.casterId = casterId;
            this.columns = columns;
        }

        @Override
        public boolean tick(MinecraftServer server) {
            age++;
            int spread = ShazamAnim.INF_REWRITE_SPREAD;
            if (colIndex < columns.size()) {   // gelombang menyebar dari pusat
                double front = radius * Math.min(1.0, age / (double) spread);
                double front2 = front * front;
                int done = 0;
                while (colIndex < columns.size() && (columns.get(colIndex)[2] <= front2 || done < REWRITE_COLUMNS_MIN && age > spread)) {
                    int[] c = columns.get(colIndex++);
                    column(c[0], c[1]);
                    done++;
                }
                return true;
            }
            if (revertTicks <= 0) {
                return false;   // permanen
            }
            if (reverting == null) {
                if (age < spread + revertTicks) {
                    return true;
                }
                reverting = changed.entrySet().iterator();
                level.playSound(null, center.x, center.y, center.z, ShazamSounds.INFINITY_REWRITE_END.get(), SoundSource.PLAYERS, 4f, 1f);
                if (level.getEntity(casterId) instanceof ServerPlayer caster) {
                    ShazamNetwork.playAnim(caster, ShazamAnim.INF_REWRITE_END, center);
                }
            }
            for (int i = 0; i < CARVE_PER_TICK && reverting.hasNext(); i++) {
                restore(reverting.next());
            }
            return reverting.hasNext();
        }

        void revertNow() {
            if (reverting == null) {
                reverting = changed.entrySet().iterator();
            }
            while (reverting.hasNext()) {
                restore(reverting.next());
            }
        }

        private void restore(Map.Entry<BlockPos, BlockState[]> e) {
            BlockPos pos = e.getKey();
            if (level.isLoaded(pos) && level.getBlockState(pos) == e.getValue()[1]) {   // yang sudah diubah pemain nggak ditimpa
                level.setBlock(pos, e.getValue()[0], Block.UPDATE_CLIENTS);
            }
        }

        private void column(int x, int z) {
            BlockPos probe = new BlockPos(x, (int) center.y, z);
            if (!level.isLoaded(probe)) {
                return;
            }
            RandomSource r = level.random;
            int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, x, z) - 1;
            int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z) - 1;
            if (Math.abs(ground - center.y) > radius) {
                return;   // tebing / gua jauh di atas atau bawah: lewati
            }
            for (int y = Math.max(top, ground + 1); y >= ground - 3 && y >= level.getMinBuildHeight(); y--) {
                BlockPos pos = new BlockPos(x, y, z);
                BlockState state = level.getBlockState(pos);
                if (state.isAir() || level.getBlockEntity(pos) != null || state.getDestroySpeed(level, pos) < 0f) {
                    continue;
                }
                BlockState to = map(state, ground - y, r);
                if (to != null && to != state) {
                    changed.put(pos, new BlockState[] {state, to});
                    level.setBlock(pos, to, Block.UPDATE_CLIENTS);
                }
            }
        }

        /** depth: 0 = permukaan, 1.. = di bawahnya, < 0 = di atas tanah (daun, tanaman). */
        private BlockState map(BlockState s, int depth, RandomSource r) {
            boolean water = s.getFluidState().is(FluidTags.WATER) && s.getFluidState().isSource() && s.is(Blocks.WATER);
            if (water) {
                return theme == FROST ? Blocks.PACKED_ICE.defaultBlockState() : null;
            }
            if (!s.getFluidState().isEmpty()) {
                return null;
            }
            boolean leaves = s.is(BlockTags.LEAVES), log = s.is(BlockTags.LOGS);
            boolean plant = !leaves && !log && s.canBeReplaced();
            float f = r.nextFloat();
            Block b;
            if (plant) {
                b = switch (theme) {
                    case CRYSTAL -> f < 0.5f ? Blocks.AMETHYST_CLUSTER : Blocks.SMALL_AMETHYST_BUD;
                    case NETHER -> f < 0.5f ? Blocks.CRIMSON_ROOTS : Blocks.CRIMSON_FUNGUS;
                    case END -> f < 0.12f ? Blocks.END_ROD : Blocks.AIR;
                    case FROST -> Blocks.SNOW;
                    default -> f < 0.3f ? Blocks.DANDELION : null;
                };
            } else if (leaves) {
                b = switch (theme) {
                    case CRYSTAL -> f < 0.5f ? Blocks.LIGHT_BLUE_STAINED_GLASS : Blocks.PINK_STAINED_GLASS;
                    case NETHER -> f < 0.12f ? Blocks.SHROOMLIGHT : Blocks.NETHER_WART_BLOCK;
                    case END -> f < 0.5f ? Blocks.PURPLE_STAINED_GLASS : Blocks.MAGENTA_STAINED_GLASS;
                    case FROST -> Blocks.SNOW_BLOCK;
                    default -> Blocks.YELLOW_STAINED_GLASS;
                };
            } else if (log) {
                b = switch (theme) {
                    case CRYSTAL -> Blocks.AMETHYST_BLOCK;
                    case NETHER -> Blocks.CRIMSON_STEM;
                    case END -> Blocks.PURPUR_PILLAR;
                    case FROST -> Blocks.PACKED_ICE;
                    default -> Blocks.OCHRE_FROGLIGHT;
                };
            } else if (!s.isSolid()) {
                return null;
            } else if (depth <= 0) {   // permukaan
                b = switch (theme) {
                    case CRYSTAL -> f < 0.55f ? Blocks.AMETHYST_BLOCK : Blocks.CALCITE;
                    case NETHER -> f < 0.7f ? Blocks.CRIMSON_NYLIUM : Blocks.NETHERRACK;
                    case END -> Blocks.END_STONE;
                    case FROST -> f < 0.5f ? Blocks.SNOW_BLOCK : Blocks.PACKED_ICE;
                    default -> f < 0.5f ? Blocks.YELLOW_TERRACOTTA : Blocks.HONEYCOMB_BLOCK;
                };
            } else {   // di bawah permukaan
                b = switch (theme) {
                    case CRYSTAL -> Blocks.CALCITE;
                    case NETHER -> depth > 2 ? Blocks.BLACKSTONE : Blocks.NETHERRACK;
                    case END -> depth > 2 ? Blocks.END_STONE_BRICKS : Blocks.END_STONE;
                    case FROST -> Blocks.PACKED_ICE;
                    default -> Blocks.YELLOW_TERRACOTTA;
                };
            }
            return b == null ? null : b.defaultBlockState();
        }
    }
}
