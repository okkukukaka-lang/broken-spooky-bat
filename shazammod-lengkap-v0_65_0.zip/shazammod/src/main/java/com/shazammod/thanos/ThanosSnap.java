package com.shazammod.thanos;

import java.util.ArrayList;
import java.util.List;

import org.joml.Vector3f;

import java.util.Collections;
import java.util.Random;

import com.shazammod.PralayaGod;
import com.shazammod.PralayaProgress;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamMod;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.phases.EnderDragonPhase;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * 0.62 JENTIKAN Thanos (R, keenam batu terpasang, energi penuh): SEMUA makhluk hidup dalam radius bisa lenyap jadi debu:
 * monster, hewan, warga desa, peliharaan, yang bernama, bos vanilla (Ender Dragon, Wither, Warden) maupun bos mod ini
 * (rival juara, Subjek Tiga, penjaga kuil), dan pemain. Separuhnya dipilih acak (snapHalf).
 *
 * Nggak kena: Thanos sendiri, pemain spectator / creative, armor stand, dan pemain yang punya JUARA DEWA (isGod).
 *
 * Mutlak: damage-nya (data/shazammod/damage_type/thanos_snap.json) ada di tag bypasses_invulnerability & kawan-kawan,
 * jadi menembus kebal, armor, efek, totem, juga semua pertahanan di mod ini yang memang menghormati tag itu (dilempar
 * balik jadi manusia, Bangkit Lagi Subjek Tiga, rival yang menghindar/menangkis, penjaga kuil yang kebal). Pasif juara
 * dilewati di ShazamPowers.onIncomingDamage. Aturan PvP & tim server tetap berlaku untuk pemain.
 */
public final class ThanosSnap {
    private ThanosSnap() {}

    public static final ResourceKey<DamageType> SNAP = ResourceKey.create(Registries.DAMAGE_TYPE, ShazamMod.id("thanos_snap"));

    private static final DustParticleOptions DUST = new DustParticleOptions(new Vector3f(0.45f, 0.34f, 0.26f), 1.6f);

    public static boolean isSnap(DamageSource source) {
        return source.is(SNAP);
    }

    public static DamageSource source(ServerPlayer thanos) {
        return new DamageSource(thanos.serverLevel().registryAccess()
                .registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolderOrThrow(SNAP), thanos);
    }

    /**
     * Pemain dengan juara dewa: kebal Jentikan. Sekarang: PRALAYA Fase Dewa (keenam inti terpasang). Bawaan: cukup sudah
     * memilikinya; godImmuneOnlyInArmor = true kalau cuma kebal selama armornya dipakai. Juara dewa baru: tambahkan di sini.
     */
    public static boolean isGod(ServerPlayer player) {
        if (ThanosConfig.GOD_ONLY_IN_ARMOR.get()) {
            return PralayaGod.god(player);
        }
        return PralayaProgress.phase(player) >= 3;
    }

    public static boolean eligible(ServerPlayer thanos, LivingEntity e) {
        if (e == thanos || !e.isAlive() || e instanceof ArmorStand) {
            return false;
        }
        if (e instanceof ServerPlayer player) {
            if (player.isSpectator() || !ThanosConfig.SNAP_PLAYERS.get()) {
                return false;
            }
            if (player.isCreative() && !ThanosConfig.SNAP_CREATIVE.get()) {
                return false;
            }
            return !isGod(player);
        }
        return true;   // bos, rival, yang bernama, peliharaan: semuanya ikut
    }

    /** Semua makhluk yang bisa kena, dalam bola radius snapRadius. */
    public static List<LivingEntity> targets(ServerPlayer thanos) {
        double r = ThanosConfig.SNAP_RADIUS.get();
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : thanos.serverLevel().getEntitiesOfClass(LivingEntity.class, thanos.getBoundingBox().inflate(r))) {
            if (e.distanceToSqr(thanos) <= r * r && eligible(thanos, e)) {
                out.add(e);
            }
        }
        return out;
    }

    /** Jadi debu. true = benar-benar lenyap (pemain yang dilindungi aturan PvP / tim server tetap hidup). */
    public static boolean vanish(ServerPlayer thanos, LivingEntity e, DamageSource source) {
        double x = e.getX(), y = e.getY() + e.getBbHeight() * 0.5, z = e.getZ();
        double w = Math.max(0.3, e.getBbWidth() * 0.45), h = Math.max(0.3, e.getBbHeight() * 0.4);
        e.invulnerableTime = 0;
        e.hurt(source, e.getMaxHealth() * 4f + e.getAbsorptionAmount() + 1000f);
        if (e.isAlive()) {
            if (e instanceof Player) {
                return false;
            }
            if (e instanceof EnderDragon dragon) {
                // sekarat = animasi mati vanilla jalan (XP & portal keluar tetap muncul); belum = dihabisi lewat jalan /kill
                if (dragon.getPhaseManager().getCurrentPhase().getPhase() != EnderDragonPhase.DYING) {
                    dragon.kill();
                }
            } else {
                e.discard();   // makhluk (dari mod lain) yang menolak semua damage: tetap lenyap
            }
        }
        ServerLevel level = thanos.serverLevel();
        level.sendParticles(DUST, x, y, z, 40, w, h, w, 0.02);
        level.sendParticles(ParticleTypes.ASH, x, y, z, 30, w, h, w, 0.01);
        return true;
    }

    /** Pemain juara dewa di sekitar diberi tahu bahwa kuasanya menahan Jentikan. */
    public static void notifyImmune(ServerPlayer thanos) {
        double r = ThanosConfig.SNAP_RADIUS.get();
        for (ServerPlayer player : thanos.serverLevel().players()) {
            if (player != thanos && player.distanceToSqr(thanos) <= r * r && !player.isSpectator() && isGod(player)) {
                player.displayClientMessage(Component.translatable("message.shazammod.thanos.snap_immune")
                        .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), true);
            }
        }
    }

    // ---------------------------------------------------------------- mengisi & menjentikkan

    /** R: mulai mengisi (TITAN_SNAP_AT tick; keenam batu menyala satu per satu), atau batal kalau sedang mengisi. */
    public static void toggle(ServerPlayer p, ThanosData d) {
        if (d.snapCharge > 0) {
            cancel(p, d, true);
            return;
        }
        if (!ThanosSkills.free(p)) {
            return;
        }
        if (d.stones != StoneType.ALL) {
            ThanosAbilities.msg(p, "snap_need_all", ChatFormatting.GRAY, Integer.bitCount(d.stones));
            return;
        }
        if (!ThanosAbilities.hasGauntlet(p)) {
            ThanosAbilities.msg(p, "no_gauntlet", ChatFormatting.GRAY);
            return;
        }
        if (d.cooldowns[ThanosData.SLOT_SNAP] > 0) {
            ThanosAbilities.msg(p, "cooldown", ChatFormatting.RED, (d.cooldowns[ThanosData.SLOT_SNAP] + 19) / 20);
            return;
        }
        if (!p.getAbilities().instabuild && d.energy < ThanosData.MAX_ENERGY) {
            ThanosAbilities.msg(p, "snap_need_energy", ChatFormatting.RED);
            return;
        }
        d.snapCharge = ShazamAnim.TITAN_SNAP_AT;
        ThanosSkills.busy(p, ShazamAnim.TITAN_SNAP_AT + 4);
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_SNAP);
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.THANOS_SNAP_CHARGE.get(), SoundSource.PLAYERS,
                2.4f, 1f);
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, d.snapCharge + 5, 3, false, false));
        ThanosAbilities.msg(p, "snap_charging", ChatFormatting.GOLD);
        double warn = ThanosConfig.SNAP_RADIUS.get() + 16.0;
        Component warning = Component.translatable("message.shazammod.thanos.snap_warning", p.getDisplayName())
                .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD);
        for (ServerPlayer other : p.serverLevel().players()) {
            if (other != p && other.distanceToSqr(p) < warn * warn) {
                other.displayClientMessage(warning, true);
            }
        }
    }

    public static void cancel(ServerPlayer p, ThanosData d, boolean announce) {
        if (d.snapCharge <= 0) {
            return;
        }
        d.snapCharge = 0;
        ThanosSkills.release(p);
        p.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        ShazamNetwork.playAnim(p, ShazamAnim.TITAN_SNAP_CANCEL);
        if (announce) {
            ThanosAbilities.msg(p, "snap_cancel", ChatFormatting.GRAY);
        }
    }

    public static void tick(ServerPlayer p, ThanosData d) {
        if (d.snapCharge <= 0) {
            return;
        }
        if (!d.transformed || d.stones != StoneType.ALL || !ThanosAbilities.hasGauntlet(p)) {
            cancel(p, d, true);
            return;
        }
        if (--d.snapCharge == 0) {
            execute(p, d);
        }
    }

    /** Jari dijentikkan: separuh (acak) dari semua yang bisa kena jadi debu. */
    static void execute(ServerPlayer p, ThanosData d) {
        ServerLevel level = p.serverLevel();
        level.playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.THANOS_SNAP.get(), SoundSource.PLAYERS, 4.0f, 1f);
        ShazamNetwork.playAnim(p, ShazamAnim.TITAN_SNAP_WAVE, p.position());
        List<LivingEntity> pool = targets(p);
        Collections.shuffle(pool, new Random(p.getRandom().nextLong()));
        int n = ThanosConfig.SNAP_HALF.get() ? (pool.size() + 1) / 2 : pool.size();
        n = Math.min(n, ThanosConfig.SNAP_MAX_TARGETS.get());
        DamageSource source = source(p);
        int gone = 0, players = 0, marked = 0;
        for (int i = 0; i < n; i++) {
            LivingEntity e = pool.get(i);
            boolean player = e instanceof Player;
            Vec3 at = e.position().add(0, e.getBbHeight() * 0.5, 0);
            if (vanish(p, e, source)) {
                gone++;
                if (player) {
                    players++;
                }
                if (marked < 48) {   // debu lenyap (efek client) untuk 48 makhluk pertama; sisanya cuma partikel server
                    marked++;
                    ShazamNetwork.playAnim(p, ShazamAnim.TITAN_DUST, at);
                    if (marked <= 10) {
                        level.playSound(null, at.x, at.y, at.z, ShazamSounds.THANOS_DUST.get(), SoundSource.PLAYERS, 1.2f,
                                0.85f + p.getRandom().nextFloat() * 0.3f);
                    }
                }
            }
        }
        notifyImmune(p);
        // harganya: energi habis, badan lemas sebentar, dan cooldown panjang
        d.energy = 0f;
        d.cooldowns[ThanosData.SLOT_SNAP] = ThanosConfig.SNAP_COOLDOWN.get() * 20;
        p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 600, 1));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 1));
        float selfHurt = Math.min(6f, p.getHealth() - 1f);
        if (selfHurt > 0f) {
            p.hurt(p.damageSources().magic(), selfHurt);
        }
        p.displayClientMessage(Component.translatable("message.shazammod.thanos.snap_done", gone, players)
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        ThanosNetwork.sync(p);
    }
}
