package com.shazammod;

/**
 * Animasi yang dikirim server ke semua pemain di sekitar (0.30: juga dari Rival Juara, yang di client digambar sebagai
 * pemain boneka, lihat client.RivalPuppets).
 * Urutannya dipakai sebagai id di jaringan, jadi tambah yang baru di paling bawah.
 */
public enum ShazamAnim {
    TRANSFORM,
    REVERT,
    SOLOMON_SIGHT,
    HERCULES_CLAP,
    ATLAS_GROUND,
    ATLAS_DIVE,
    ATLAS_IMPACT,
    ZEUS_CALL,
    ACHILLES_ROAR,
    MERCURY_BLITZ,
    LAUNCH,
    LAND_SOFT,
    LAND_HERO,
    CRASH,
    SONIC_BOOM,
    ROLL_LEFT,
    ROLL_RIGHT,
    SUMMON,      // memanggil enam dewa sebelum petir transformasi
    ZEUS_RAGE,   // amarah Zeus: mata menyala putih
    HOOD_UP,     // tangan meraih ke belakang kepala lalu menarik hood ke depan
    HOOD_DOWN,   // tangan memegang tepi hood di dahi lalu mendorongnya ke belakang
    MERCURY_ON,  // Mode Kilat Mercury menyala: kuda-kuda, listrik meledak dari badan
    MERCURY_OFF, // Mode Kilat Mercury mati
    MERCURY_JAB, // pukulan-pukulan secepat kilat (x, y, z = titik kena)
    MERCURY_CROSS,
    MERCURY_HOOK,
    MERCURY_KICK,
    KNOCKOUT,    // serangan mematikan saat jadi Shazam: badan terhentak, kekuatan tercabut dari dada, balik jadi manusia
    // ======= Black Adam (dewa-dewa Mesir) =======
    ADAM_SHU,         // S - Pusaran Shu: lengan terentang lalu terangkat, badai pasir berputar mengangkat musuh
    ADAM_HERU,        // H - Sambaran Heru: merunduk, lalu menerjang secepat elang (x, y, z = titik akhir terjangan)
    ADAM_AMON,        // A - Tinju Amon: melompat kecil, menghantam tanah, tanah terbelah lurus ke depan (x, y, z = ujungnya)
    ADAM_ZEHUTI,      // Z - Segel Zehuti: dua jari ke pelipis lalu menunjuk, hieroglif mengikat musuh
    ADAM_ZEHUTI_MARK, // segel hieroglif di satu musuh (x, y, z = posisinya); tanpa gerakan badan
    ADAM_ATON,        // A - Sinar Aton: tangan ke langit, cakram matahari terbentuk di atas telapak
    ADAM_ATON_RAY,    // satu sinar Aton ke satu musuh (x, y, z = sasaran); tanpa gerakan badan
    ADAM_MEHEN,       // M - Lilitan Mehen: kedua lengan menyilang, ular raksasa membelit badan
    ADAM_MEHEN_BITE,  // ular Mehen mematuk satu musuh (x, y, z = sasaran); tanpa gerakan badan
    ADAM_RAGE,        // Murka Kahndaq: badan terangkat, kepalan mengepal di samping, lalu meraung - mata emas menyala
    // ======= 0.22 =======
    ADAM_CALL,        // M (Black Adam): Panggil Petir Kahndaq - kepalan ke langit, petir sihir menyambar badan sendiri
    ADAM_DEFLECT,     // proyektil memantul dari kulit Black Adam (x, y, z = titik kena); tanpa gerakan badan
    ADAM_PUNCH,       // tinju Black Adam mengenai (x, y, z = titik kena): percikan petir; tanpa gerakan badan
    KAHNDAQ_TRIAL,    // Ujian Kahndaq dimulai: Skarabe Teth-Adam diangkat, badai pasir bangkit (wujud manusia)
    KAHNDAQ_RISE,     // makhluk makam bangkit dari pasir / runtuh jadi pasir (x, y, z); tanpa gerakan badan
    KAHNDAQ_AWAKEN,   // lulus ujian: skarabe bangkit, petir Kahndaq memilih juaranya (Black Adam terbuka)
    KAHNDAQ_END,      // ujian selesai/gagal: badai pasir reda; tanpa gerakan badan
    SHAZAM_CHOSEN,    // enam totem dewa menyatu: Penyihir memilih juaranya (Shazam terbuka)
    // ======= 0.23: Shazam, juara para dewa =======
    HERCULES_THROW,   // Shift+X: Lemparan Hercules - musuh diangkat ke atas kepala lalu dilempar (x, y, z = sasaran)
    HERCULES_IMPACT,  // musuh yang dilempar menghantam (x, y, z); tanpa gerakan badan
    ATLAS_GLOBE,      // Beban Langit: bola langit jatuh ke titik ini (x, y, z); tanpa gerakan badan
    ZEUS_CHAIN_START, // petir dari ujung jari ke sasaran pertama (x, y, z); tanpa gerakan badan
    ZEUS_CHAIN,       // petir melompat dari sasaran sebelumnya ke sasaran ini (x, y, z); tanpa gerakan badan
    ACHILLES_NOVA,    // Ledakan Keberanian: damage yang ditahan perisai Achilles dilepas (lengan menghentak)
    THUNDER_PUNCH,    // Pukulan Guntur (Muatan Petir penuh) mengenai (x, y, z); tanpa gerakan badan
    MERCURY_DODGE,    // Refleks Mercury: serangan dihindari (x, y, z = posisi sebelum mengelak); tanpa gerakan badan
    HERO_CALL,        // Hati Pahlawan: makhluk tak berdosa diserang (x, y, z = penyerangnya); tanpa gerakan badan
    STORM_ABSORB,     // Penangkal Petir Hidup: petir alam diserap badan; tanpa gerakan badan
    GOD_SOLOMON,      // Badai Para Dewa: dewa di lingkaran menyerang (x, y, z = sasaran); tanpa gerakan badan
    GOD_HERCULES,
    GOD_ATLAS,
    GOD_ZEUS,
    GOD_ACHILLES,
    GOD_MERCURY,
    // ======= 0.25 =======
    ROD_STRIKE,       // Penangkal Petir Hidup: petir sihir menyambar Shazam tiap 2 detik (turun ROD_DESCENT tick, lalu
                      // menghantam dada); tanpa ganti klip badan (sentakan kecil di badan ditumpuk di atas gerakan apa pun)
    // ======= 0.26 =======
    FAMILY_CALL,      // Kekuatan Keluarga (J): kepalan ke langit, tautan petir ke keluarga, lalu (tick FAMILY_WINDUP) petir
                      // menyambar semuanya bersamaan dan lengan terbuka lebar
    // ======= 0.27 Tangan Kahndaq (Black Adam) =======
    ADAM_CATCH,       // satu proyektil berhenti di udara (pos = proyektil); tanpa gerakan badan
    ADAM_HOLD,        // telapak kanan terangkat menahan proyektil-proyektil yang melayang
    ADAM_RELEASE,     // tombol J: tangan dikibaskan, semua proyektil melesat balik ke penembaknya
    // ======= 0.28 Black Adam setara Shazam =======
    ADAM_BLOCK,       // Tangkisan Kahndaq: serangan ditahan kulit (pos = titik kena), panas matahari menyembur balik
    // ======= 0.28.1 Black Adam: kekuatan dari matahari Aton =======
    ADAM_SUN,         // Cakram Aton berdenyut tiap 2 detik: sinar bertangan menyentuh badan (ROD_DESCENT tick), lalu menyembur
    ADAM_SUNPUNCH,    // Tinju Aton: ledakan cahaya & api matahari di sasaran (pos)
    // ======= 0.29 pasif tiap 2 detik padam / menyala =======
    ADAM_SUN_SET,     // Cakram Aton terbenam (malam / Nether / End): turun ke balik punggung, mengecil, memerah, padam
    ADAM_SUN_RISE,    // Cakram Aton terbit lagi (pagi): naik dari balik punggung, membesar, keemasan, sinar terbuka
    ROD_FADE,         // petir Shazam padam (gurun / es & salju / Nether): listrik tersendat lalu habis
    // ======= 0.30 Sabbac (enam iblis S-A-B-B-A-C) =======
    SABBAC_HORNS,     // Z - Tanduk Setan: menunduk, lalu menyeruduk seperti banteng neraka (x, y, z = titik akhir)
    SABBAC_GORE,      // tanduk menyeruduk satu musuh (pos); tanpa gerakan badan
    SABBAC_AYM,       // X - Tubuh Aym: kulit membatu jadi obsidian berurat magma
    SABBAC_AYM_BURST, // Letusan Aym: cangkang magma pecah, damage yang ditahan meledak keluar
    SABBAC_CHAINS,    // C - Rantai Belial: tangan mencakar tanah, rantai neraka menyeruak
    SABBAC_CHAIN_BIND,// satu rantai membelit musuh (pos); tanpa gerakan badan
    SABBAC_BREATH,    // V - Napas Beelzebub: mendongak, lalu menyemburkan api neraka selama BREATH_TICKS
    SABBAC_ROAR,      // B - Teror Asmodeus: meraung, gelombang teror
    SABBAC_WINGS,     // N - Kepakan Crateis: sayap api terbentang, satu kepakan dahsyat
    SABBAC_HELLGATE,  // R - Gerbang Neraka: membesar jadi raksasa, lingkaran api neraka
    SABBAC_GEYSER,    // semburan api neraka dari tanah di bawah satu musuh (pos); tanpa gerakan badan
    SABBAC_CALL,      // M - Panggil Petir Neraka: petir hitam-merah menyembur dari bawah tanah ke badan sendiri
    SABBAC_LEGION,    // J - Pasukan Iblis: tangan ke tanah, retakan neraka, prajurit iblis bangkit
    SABBAC_RISE,      // satu prajurit iblis bangkit / runtuh jadi bara (pos); tanpa gerakan badan
    SABBAC_PULSE,     // Api Neraka tiap 2 detik: tanah retak membara, api & petir neraka menyembur naik menelan badan
    SABBAC_HELLPUNCH, // Tinju Neraka (Muatan Neraka penuh) mengenai (pos); tanpa gerakan badan
    SABBAC_ENGULF,    // Kulit Bara: serangan ditelan api (pos = titik kena); tanpa gerakan badan
    SABBAC_FIRE_OUT,  // Api Neraka padam (di bawah matahari / di dalam air)
    SABBAC_FIRE_IN,   // Api Neraka menyala lagi
    SABBAC_PUNCH,     // tinju Sabbac mengenai (pos): bara & api kecil; tanpa gerakan badan
    SABBAC_PACT,      // Perjanjian Enam Iblis (wujud manusia): Mahkota Sabbac diangkat, enam iblis menjawab
    // ======= 0.30 Rival Juara =======
    RIVAL_ARRIVE,     // rival juara datang (pos): petir / semburan api neraka di titik datang; tanpa gerakan badan
    RIVAL_DEPART,     // rival juara pergi (pos); tanpa gerakan badan
    // ======= 0.32 Lintang (juara bintang, L-I-N-T-A-N-G) =======
    LINTANG_DASH,      // L - Lesatan Bintang: merunduk, lalu melesat lurus (x, y, z = titik akhir)
    LINTANG_EYES,      // I - Iris Surya: mata memanas, lalu sinar panas dari kedua mata selama IRIS_TICKS
    LINTANG_BREATH,    // N - Napas Salju: menarik napas, lalu menghembus angin beku selama FROST_TICKS
    LINTANG_CLAP,      // T - Tepukan Guruh: lengan terentang ke belakang, lalu tepukan menggelegar (tick SONIC_WINDUP)
    LINTANG_BARRAGE,   // A - Amukan Kilat: rentetan pukulan secepat kilat (x, y, z = sasaran)
    LINTANG_HIT,       // satu pukulan mengenai (pos); tanpa gerakan badan
    LINTANG_LEAP,      // N - Napak Langit: melompat tinggi / menukik
    LINTANG_SLAM,      // hantaman Napak Langit di tanah (pos); tanpa gerakan badan
    LINTANG_FLARE,     // G - Gelegar Surya: menyerap cahaya, lalu meledakkannya (tick FLARE_WINDUP)
    LINTANG_CALL,      // M - Serap Surya: lengan terangkat menyerap cahaya langit
    LINTANG_RESCUE,    // J - Selamatkan: melesat ke semua sekutu
    LINTANG_SAVE,      // satu sekutu diselamatkan (pos); tanpa gerakan badan
    LINTANG_LANCE,     // tombak cahaya menyambar satu musuh (pos); tanpa gerakan badan
    LINTANG_PULSE,     // Serapan Cahaya tiap 2 detik (sinar matahari / bintang menyentuh badan); tanpa gerakan badan
    LINTANG_DAWNPUNCH, // Tinju Fajar (Muatan Cahaya penuh) mengenai (pos); tanpa gerakan badan
    LINTANG_PARRY,     // Tepisan Beku (pos = titik kena); tanpa gerakan badan
    LINTANG_BOUNCE,    // Kulit Baja: serangan lemah memantul (pos); tanpa gerakan badan
    LINTANG_PUNCH,     // tinju Lintang mengenai (pos); tanpa gerakan badan
    LINTANG_FADE,      // cahaya meredup (bawah tanah / Nether / End / dekat Kelam); tanpa gerakan badan
    LINTANG_RETURN,    // cahaya kembali; tanpa gerakan badan
    LINTANG_KELAM,     // Batu Kelam menghisap cahaya (pos); tanpa gerakan badan
    LINTANG_RITE,      // Penyatuan Bintang (wujud manusia): Kristal Bintang diangkat ke matahari
    LINTANG_ICE,       // 0.36 Napas Salju: musuh membeku jadi patung es (pos = dadanya); tanpa gerakan badan
    LINTANG_ICE_BREAK, // 0.36 patung es pecah dipukul / mencair (pos); tanpa gerakan badan
    LINTANG_GUST,      // 0.37 Napas Topan (Shift + C): menarik napas, lalu menghembus angin topan selama FROST_TICKS
    LINTANG_COMBO,     // 0.37 Kombo Langit (Shift + Z): melesat ke sasaran (pos = titik tiba), lalu uppercut
    LINTANG_COMBO_RISE,  // Kombo Langit: naik secepat kilat ke atas sasaran yang melayang (pos = titik tujuan)
    LINTANG_COMBO_SMASH, // Kombo Langit: menghantam sasaran ke bawah dengan dua kepalan lalu ikut menukik (pos = tujuan)
    LINTANG_NOVA,      // 0.37 Ledakan Surya (Shift + R): meringkuk mengumpulkan panas SOLAR_NOVA_WINDUP tick, lalu meledak
    LINTANG_STEAM,     // 0.40 fisika: air/es/salju menguap kena panas, atau lava didinginkan (pos); tanpa gerakan badan
    LINTANG_MELT,      // 0.40 fisika: blok meleleh kena sinar mata (pasir jadi kaca, batu jadi magma) (pos); tanpa gerakan
    LINTANG_SHATTER,   // 0.40 fisika: kaca pecah kena gelombang tekanan / benda terlempar (pos); tanpa gerakan badan
    LINTANG_IRIS_CHARGE, // 0.42 Iris Surya: X ditahan, mata mengumpulkan panas (makin lama makin kuat)
    LINTANG_IRIS_FIRE,   // 0.42 X dilepas: sinar ditembakkan (x = charge 0-1, y = lama sinar dalam tick, z = daya 0-1)
    LINTANG_BLITZ,       // 0.42 Lintas Detik (Z): dunia seakan berhenti, Lintang menyambar musuh satu per satu
    LINTANG_BLITZ_HIT,   // satu musuh disambar saat dunia berhenti (pos = dadanya); tanpa gerakan badan
    LINTANG_BLITZ_END,   // waktu jalan lagi: semua pukulan mendarat bersamaan (pos = posisi Lintang); tanpa gerakan badan
    LINTANG_SUN,         // 0.42 Nyala Mentari (N): cahaya dikumpulkan di tangan lalu didorong (pos = titik matahari mini)
    LINTANG_SUN_PUNCH,   // tinju udara ke matahari mini: melesat jadi komet (x, y, z = arah lesatnya)
    LINTANG_SUN_BOOM,    // komet matahari menghantam (pos); tanpa gerakan badan
    LINTANG_SUN_COLLAPSE, // matahari mini runtuh lalu meledak (pos); tanpa gerakan badan
    // ======= 0.43 Projek Helion-6 (kekuatan dari radiasi Batu Cryon, lemah di bawah matahari) =======
    HELION_RITE,        // Eksperimen Proyek Helion-6 (wujud manusia): serum Cryon disuntik, radiasi menjalar, meledak
    HELION_DASH,        // H - Hempasan Lesat (Z): merunduk, lalu melesat lurus (pos = titik akhir)
    HELION_DASH_HIT,    // satu musuh dihantam radiasi (pos); tanpa gerakan badan
    HELION_EYES,        // E - Emisi Cryon (X): mata mengumpulkan radiasi HELION_EYES_WINDUP tick, lalu sinar HELION_EYES_TICKS
    HELION_QUAKE,       // I - Injakan Cryon (V): melompat, lalu berlutut menghantam tanah di tick HELION_QUAKE_WINDUP
    HELION_NOVA,        // 6 - Supernova-6 (R): meringkuk menyerap radiasi HELION_NOVA_WINDUP tick, lalu terbuka meledak
    HELION_NOVA_BLAST,  // Supernova meledak (x = jari-jari, y = kekuatan 0-1); tanpa gerakan badan
    HELION_INHALE,      // M - Hirup Cryon: pecahan diremukkan & dihirup, radiasi melonjak di tick HELION_INHALE_WINDUP
    HELION_PULSE,       // Denyut Cryon tiap 2 detik; tanpa gerakan badan
    HELION_PUNCH,       // tinju Helion-6 mengenai (pos); tanpa gerakan badan
    HELION_CRYON_PUNCH, // Tinju Cryon (muatan penuh) mengenai (pos); tanpa gerakan badan
    HELION_DEFLECT,     // Kulit Cryon: serangan lemah memantul (pos); tanpa gerakan badan
    HELION_SUN_BURN,    // mulai terbakar matahari: kulit berasap; tanpa gerakan badan
    HELION_SUN_CLEAR,   // keluar dari sinar matahari: radiasi menyala lagi; tanpa gerakan badan
    HELION_COLLAPSE,    // radiasi habis di bawah matahari: jatuh berlutut
    // ======= 0.45 sisa skill Helion-6 & gaya komik =======
    HELION_LAHAP,        // L - Lahap Radiasi (C): tangan terentang menghisap radiasi musuh selama HELION_LAHAP_TICKS
    HELION_ORBIT,        // O - Orbit Cryon (B): kristal Cryon terbentuk & mengorbit, lalu ditunjuk satu per satu
    HELION_SHARD,        // satu kristal melesat memburu musuh (pos = titik sasaran); tanpa gerakan badan
    HELION_NISAN,        // N - Nisan Kristal (N): telapak menghantam tanah, kristal meletus berderet (pos = arah datar)
    HELION_TOMB_LOCK,    // musuh terkurung kristal (x = id makhluk, y = lama); tanpa gerakan badan
    HELION_TOMB_SHATTER, // kurungan kristal pecah (pos); tanpa gerakan badan
    HELION_ECLIPSE,      // J - Gerhana Buatan: kepalan diangkat ke matahari, gerhana menutupnya (pos = pusat wilayah)
    HELION_TAUNT,        // balon kata ejekan khas komik (x = jenis, y = nomor kalimat); tanpa gerakan badan
    HELION_DUEL_LINE,    // 0.47 dialog duel (z 0-1) / 0.48 sekutu (z 2-3) Lintang & Helion-6 (x = nomor, y = kategori)
    // ======= 0.48 Subjek Tiga (Helion-3): efeknya di Helion3Fx, posenya dari data entity-nya =======
    HELION3_EMERGE,      // merangkak keluar dari tanah, raungan pertama di Helion3.EMERGE_ROAR
    HELION3_ROAR,        // raungan (gelombang di Helion3.ROAR_HIT)
    HELION3_LEAP,        // melompat (pos = titik mendarat)
    HELION3_SLAM,        // menghantam tanah dari udara (pos)
    HELION3_CHARGE,      // menyeruduk (pos = arah ujung)
    HELION3_CRASH,       // serudukan menabrak tembok (pos)
    HELION3_SMASH,       // hantaman kena (pos)
    HELION3_POUND,       // kedua kepalan menghantam tanah (pos)
    HELION3_ADAPT,       // tubuh beradaptasi (x = jenis serangan, y = 1 kebal total)
    HELION3_IMMUNE,      // serangan nggak mempan (x = jenis)
    HELION3_ABSORB,      // radiasi Cryon diserap (pos = dada)
    HELION3_FALL,        // tumbang (satu nyawa habis)
    HELION3_REVIVE,      // kepompong sel mati, lalu bangkit
    HELION3_DEATH,       // hancur (nyawa terakhir)
    // 0.49 Subjek Tiga yang bisa dimainkan (wujud HELION3): H-E-L-I-O-N-3
    SUBJEK_RITE,         // Inkubasi Subjek Tiga (wujud manusia): sel mati menjalar, kepompong, lalu pecah
    SUBJEK_SMASH,        // H - Hantam (Z): kanan, kiri, lalu kedua kepalan menghantam tanah
    SUBJEK_ROAR,         // E - Erangan (X): raungan (gelombang di SUBJEK_ROAR_HIT)
    SUBJEK_LEAP,         // L - Lompat (C): melompat ke titik bidik (pos = titik mendarat)
    SUBJEK_COCOON,       // I - Inkubasi (V): meringkuk di kepompong sel mati SUBJEK_COCOON_TICKS, lalu pecah
    SUBJEK_SPIKES,       // O - Onak Tulang (B): kedua cakar menancap, duri tulang meletus melingkar (x = jari-jari)
    SUBJEK_CHARGE,       // N - Nyeruduk (N): mengais tanah, lalu menyeruduk lurus (pos = titik akhir)
    SUBJEK_RAGE,         // 3 - Evolusi Ketiga (R): tubuh membengkak, raungan panjang, mata & dada menyala
    SUBJEK_ABSORB,       // M - Serap Cryon: pecahan diremukkan di dada, radiasinya diserap
    SUBJEK_BURROW,       // J - Terobos Tanah: menyelam ke tanah, lalu meletus di titik bidik (pos = titik muncul)
    SUBJEK_FALL,         // tumbang: satu nyawa habis, sel mati mulai membungkus
    SUBJEK_REVIVE,       // Bangkit Lagi: kepompong pecah, berdiri & meraung
    SUBJEK_HIT,          // hantaman kena (pos); tanpa gerakan badan
    SUBJEK_POUND,        // kedua kepalan menghantam tanah (pos); tanpa gerakan badan
    SUBJEK_SLAM,         // mendarat dari lompatan (pos); tanpa gerakan badan
    SUBJEK_CRASH,        // serudukan menabrak tembok / berhenti (pos); tanpa gerakan badan
    SUBJEK_BURST,        // kepompong pecah (pos); tanpa gerakan badan
    SUBJEK_ADAPT,        // tubuh beradaptasi (x = jenis serangan, y = 1 kebal total); tanpa gerakan badan
    SUBJEK_IMMUNE,       // serangan nggak mempan (x = jenis); tanpa gerakan badan
    SUBJEK_PUNCH,        // cakar mengenai (pos); tanpa gerakan badan
    SUBJEK_THORN,        // duri sel mati menusuk penyerang (pos); tanpa gerakan badan
    SUBJEK_PULSE,        // denyut regenerasi; tanpa gerakan badan
    SUBJEK_EMERGE,       // muncul dari tanah di ujung Terobos Tanah (pos); tanpa gerakan badan
    SUBJEK_RAGE_END,     // Evolusi Ketiga selesai; tanpa gerakan badan
    // ======= 0.50 Aksara, Sang Penulis Ulang: gerakan badan (AKSARA_*) & penanda efek (SABDA_*), efeknya di AksaraFx =======
    AKSARA_RITE,         // Penulisan Ulang (wujud manusia): enam aksara terangkat dari lontar, menggurat badan, lalu menyatu
    AKSARA_BEAM,         // Z  Sinar Daya: telapak kanan ke depan, sinar merah menyala AKSARA_BEAM_TICKS (ikut bidikan)
    AKSARA_NOVA,         // Shift+Z  Ledak Daya: melayang, tenaga dikumpulkan di dada, lalu meledak (AKSARA_NOVA_WINDUP)
    AKSARA_FOLD,         // X  Lipat Ruang: jentikan jari, ruang terlipat (pos = titik tujuan)
    AKSARA_GATE,         // Shift+X  Gerbang Ruang: tangan melukis lingkaran, gerbang terbuka di depan (pos = pusat gerbang)
    AKSARA_LANCE,        // C  Tusuk Benak: dua jari di pelipis, lalu menunjuk (pos = sasaran)
    AKSARA_DOMINION,     // Shift+C  Kuasa Benak: kedua tangan di pelipis, kepala mendongak, gelombang benak
    AKSARA_REWRITE,      // V  Ubah Maya: jari menulis di udara, lalu dihentakkan (pos = titik bidik)
    AKSARA_VEIL,         // Shift+V  Cermin Maya: kibasan tangan, badan memudar jadi bayangan cermin
    AKSARA_TIMESTOP,     // B  Henti Kala: lengan diangkat, kepalan digenggam: waktu berhenti
    AKSARA_REWIND,       // Shift+B  Putar Kala: lengan bersilang lalu berputar balik (pos = titik 5 detik lalu)
    AKSARA_SOUL,         // N  Rampas Atma: cakar terbuka ke depan, jiwa ditarik, lalu dicabut (AKSARA_SOUL_RIP)
    AKSARA_WARD,         // Shift+N  Tirai Atma: telapak dikatupkan, lalu dibentangkan
    AKSARA_PURNA,        // R  Sabda Purna: naik, lengan terentang, keenam cakram menyala
    AKSARA_ERASE,        // Shift+R  Penghapusan: naik tinggi, heksagram raksasa, gelombang penghapus (AKSARA_ERASE_HIT)
    AKSARA_DISCS,        // M  Lontar Cakram: sapuan lengan, enam cakram dilempar
    AKSARA_SHIELD,       // Shift+M  Perisai Sabda: lengan kiri di depan, cakram membentuk perisai
    AKSARA_STEP,         // J  Langkah Ruang: condong, lenyap, muncul (pos = titik tujuan)
    AKSARA_SELF,         // Shift+J  Tulis Ulang Diri: telapak di dada, garis prada menyala, lalu terlepas
    AKSARA_SKYSPEAR,     // 0.60 Alt+Z  Tombak Langit: lengan menunjuk langit, lalu dihentak ke sasaran (pos = titik jatuh)
    AKSARA_GRAVITY,      // 0.60 Alt+X  Sumur Graviton: telapak terbuka ke depan, lalu digenggam (pos = pusat sumur)
    AKSARA_NEURAL,       // 0.60 Alt+C  Jaring Saraf: jari di pelipis, lalu jemari direntangkan
    AKSARA_SPIKES,       // 0.60 Alt+V  Duri Maya: telapak menyapu rendah ke tanah (pos = satu blok di depan, arah gelombang)
    AKSARA_ECHO,         // 0.60 Alt+B  Gema Kala: lengan memutar lingkaran jam di depan dada
    AKSARA_TETHER,       // 0.60 Alt+N  Tambatan Atma: tangan mencengkeram, lalu ditarik ke dada (pos = sasaran)
    SABDA_PULSE,         // Halo Sabda: denyut pasif tiap 2 detik; tanpa gerakan badan
    SABDA_PUNCH,         // tinju Aksara kena (pos); tanpa gerakan badan
    SABDA_SIXFOLD,       // Tinju Enam Sabda: muatan penuh kena (pos); tanpa gerakan badan
    SABDA_PHASE,         // Tangkal Ruang: serangan dilipat, muncul di belakang penyerang (pos = titik baru); tanpa gerakan badan
    SABDA_HIT,           // serangan ranah kena (pos, warna dari sabda terakhir); tanpa gerakan badan
    SABDA_IMPLODE,       // ruang terlipat di satu titik (pos); tanpa gerakan badan
    SABDA_SKYGATE,       // gerbang di langit memuntahkan musuh (pos); tanpa gerakan badan
    SABDA_STUN,          // benak musuh terkunci (pos); tanpa gerakan badan
    SABDA_POOF,          // musuh kecil ditulis ulang jadi makhluk jinak (pos); tanpa gerakan badan
    SABDA_TIME_END,      // waktu berjalan lagi: damage yang ditabung ditagih (pos = pusat); tanpa gerakan badan
    SABDA_SOUL_RIP,      // jiwa dicabut dari satu musuh (pos); tanpa gerakan badan
    SABDA_DISC,          // satu cakram mengenai (pos); dikirim berurutan Daya..Atma; tanpa gerakan badan
    SABDA_DRONE,         // 0.51 drone otonom (pasif) menembak (pos); tanpa gerakan badan
    SABDA_DRONE_CORE,    // 0.54 inti drone yang menembak berikutnya (x = inti 0-5), dikirim tepat sebelum SABDA_DRONE
    SABDA_CORE_FOUND,    // 0.55 inti pertama kali dipegang (x = inti 0-5, y = fase sekarang, z = 1 kalau fasenya naik)
    SABDA_UPGRADE,       // 0.55 modul armor terpasang (x = 0 Nether / 1 End, y = jumlah modul terpasang)
    SABDA_HUMAN_CORE,    // 0.55 inti dipakai TANPA armor (x = inti 0-5): kilau di tangan, tanpa gerakan badan
    SABDA_DASH,          // 0.55 J tanpa Inti Ruang: semburan pendorong (pos = titik berangkat), tanpa gerakan badan
    SABDA_WORLD,         // 0.56 skill Fase Dewa kena seluruh world: denyut layar warna inti (x = inti 0-6) di SEMUA pemain
    SABDA_WORLD_TIME,    // 0.56 Henti Waktu Dunia mulai (x = 1) / selesai (x = 0, y = jumlah yang ditagih), ke SEMUA pemain
    SABDA_BLOCK,         // Perisai Sabda menahan serangan (pos); tanpa gerakan badan
    SABDA_INSCRIBE,      // satu sabda tertulis (x = ranah 0-5, y = 1 kalau keenamnya lengkap); tanpa gerakan badan
    SABDA_PURNA_END,     // Sabda Purna padam; tanpa gerakan badan
    SABDA_ERASED,        // satu musuh terhapus (pos); tanpa gerakan badan
    SABDA_VEIL_END,      // Cermin Maya pecah / habis (pos); tanpa gerakan badan
    SABDA_RUIN,          // 0.58 ledakan besar Inti Daya di ujung Sinar Daya (pos); Fase Dewa lebih besar
    SABDA_PSY_BURST,     // 0.58 benak musuh meledak (pos)
    SABDA_SOUL_BURST,    // 0.58 jiwa yang tercabut meledak (pos)
    SABDA_SLAM,          // 0.58 musuh dibanting Kuasa Benak (pos = tanah tempat jatuh)
    SABDA_SKYFALL,       // 0.60 tombak tambahan Tombak Langit Fase Dewa jatuh (pos)
    SABDA_NEURAL_NODE,   // 0.60 satu benak tersambung ke Jaring Saraf (pos = dadanya)
    SABDA_NEURAL_PULSE,  // 0.60 damage mengalir lewat Jaring Saraf ke benak ini (pos)
    SABDA_ECHO_HIT,      // 0.60 serangan yang terekam Gema Kala terulang di sini (pos)
    SABDA_TETHER,        // 0.60 jiwa ini dirantai Tambatan Atma (pos = dadanya)
    SABDA_TETHER_PULSE,  // 0.60 damage dialihkan lewat rantai jiwa ke sini (pos)
    // ======= 0.63 THANOS (fan-made): gerakan badan (THANOS_*) & penanda efek (TITAN_*), efeknya di ThanosFx =======
    THANOS_BIND,         // Sumpah Titan (wujud manusia): Gauntlet diangkat, energi kosmik terkumpul, lalu menyatu (TITAN_BIND_BURST)
    THANOS_TRANSFORM,    // U  kepalan Gauntlet ke langit, batu menyala satu per satu, ledakan kosmik (TITAN_MORPH_BURST)
    THANOS_REVERT,       // kembali: kepalan diturunkan, energi padam
    THANOS_PUNCH,        // Z  Tinju Daya: kepalan ditarik lalu dihantamkan, gelombang ungu ke depan (TITAN_PUNCH_HIT)
    THANOS_NOVA,         // Shift+Z  Ledakan Daya: lompat kecil, kepalan menghantam tanah (TITAN_NOVA_HIT)
    THANOS_STEP,         // X  Langkah Kosmik: tangan merobek ruang, melangkah masuk (pos = tujuan, TITAN_STEP_AT)
    THANOS_MOON,         // Shift+X  Hujan Bulan: kepalan diangkat, langit robek, batu bulan berjatuhan (pos = pusat)
    THANOS_MIND,         // C  Belenggu Pikiran: Gauntlet diarahkan, sinar ke sasaran (pos = sasaran, TITAN_MIND_HIT)
    THANOS_MINDSTORM,    // Shift+C  Badai Pikiran: tangan di pelipis, gelombang pikiran (TITAN_MINDSTORM_HIT)
    THANOS_WRAP,         // V  Kenyataan Palsu: tangan diputar, pita membelit sasaran (pos = sasaran, TITAN_WRAP_HIT)
    THANOS_REALITY,      // Shift+V  Badai Realitas: lengan menyapu, kenyataan di sekitar terdistorsi (TITAN_REALITY_HIT)
    THANOS_REWIND,       // B  Putar Balik: lengan memutar lingkaran jam, diri diputar mundur (pos = titik 3 detik lalu)
    THANOS_TIMESTOP,     // Shift+B  Henti Waktu: kepalan digenggam di atas kepala, kubah waktu (TITAN_TIMESTOP_HIT)
    THANOS_HARVEST,      // N  Panen Jiwa: cakar terbuka ke depan, jiwa ditarik ke Gauntlet (TITAN_HARVEST_HIT)
    THANOS_SHIELD,       // Shift+N  Perisai Jiwa: kepalan di dada, perisai jiwa (TITAN_SHIELD_HIT)
    THANOS_SNAP,         // R  JENTIKAN: Gauntlet diangkat, keenam batu menyala, lalu jari dijentikkan (TITAN_SNAP_AT)
    THANOS_RAGE,         // Shift+R  Murka Titan: membungkuk, lalu meraung ke langit (TITAN_RAGE_HIT)
    THANOS_SPIN,         // M  Putaran Pedang (TITAN_SPIN_HIT)
    THANOS_THROW,        // Shift+M / Shift + klik kanan pedang: Lemparan Pedang (TITAN_THROW_AT)
    THANOS_LEAP,         // J  Hantaman Titan: merunduk lalu melompat (TITAN_LEAP_JUMP); mendaratnya = TITAN_SLAM
    TITAN_STONE_FOUND,   // batu ditemukan & tercatat di Gauntlet (x = batu 0-5, y = jumlah batu)
    TITAN_METEOR,        // satu batu bulan mulai jatuh, menghantam TITAN_METEOR_FALL tick kemudian (pos = titik hantam)
    TITAN_THRALL,        // sasaran Belenggu Pikiran (pos = dadanya)
    TITAN_WRAP_BURST,    // pita Kenyataan Palsu meledak (pos)
    TITAN_DUST,          // satu makhluk lenyap jadi debu oleh Jentikan (pos = tengah badannya)
    TITAN_SNAP_WAVE,     // gelombang Jentikan menyapu (pos = Thanos)
    TITAN_SLAM,          // Hantaman Titan mendarat (pos)
    TITAN_SIGNAL,        // Sinyal Batu (x, z = letak kuil, y = batu)
    TITAN_PARRY,         // tangkisan Pedang Dua Mata (pos)
    TITAN_RAGE_END,      // Murka Titan padam
    TITAN_SNAP_CANCEL,   // Jentikan dibatalkan saat mengisi (cahaya batu padam, lengan turun)
    // ======= 0.64 Kuasa Infinity (Thanos Alt+Z/X/V/N, PRALAYA Alt+Shift+Z/X/V/N lebih OP), efeknya di InfinityFx =======
    INFINITY_SURGE,      // Daya Tak Terbatas: kepalan digenggam di depan dada, lalu badan meledak tenaga (INF_SURGE_HIT)
    INFINITY_CRATER,     // Ledakan Kawah (selama Daya Tak Terbatas): bola daya dilontarkan ke titik bidik (pos = titik hantam)
    INFINITY_PORTAL,     // Gerbang Kosmik: tangan melukis gerbang, lalu melangkah masuk (pos = tujuan, INF_PORTAL_STEP)
    INFINITY_REWRITE,    // Tulis Ulang Dunia: kedua tangan terbuka lebar, kenyataan berubah (INF_REWRITE_HIT)
    INFINITY_RAISE,      // Bangkitkan Undead: telapak ke tanah, lalu diangkat (INF_RAISE_HIT)
    INF_CRATER_HIT,      // bola daya menghantam: kawah raksasa (pos)
    INF_PORTAL_EXIT,     // gerbang tujuan terbuka (pos)
    INF_REWRITE_WAVE,    // gelombang tulis ulang dunia (pos.x, pos.z = pusat; pos.y = y + (tema + 1) * 2000)
    INF_REWRITE_END,     // dunia kembali seperti semula (pos = pusat)
    INF_TRANSMUTE,       // satu makhluk diubah kenyataan (pos)
    INF_RISE,            // satu undead bangkit dari tanah (pos)
    INF_CRUMBLE,         // undead hancur jadi tulang & debu jiwa (pos)
    INF_SURGE_END,       // Daya Tak Terbatas padam
    // ======= 0.66 RELATIVA (orisinal, terinspirasi teori-teori Einstein): gerakan badan (RELATIVA_*) & penanda efek
    // (PHYS_*), efeknya di RelativaFx, tick puncaknya REL_* di bawah =======
    RELATIVA_RITE,       // Eksperimen Pikiran (wujud manusia): empat makalah 1905 mengorbit, berkas cahaya dikejar (REL_RITE_BURST)
    RELATIVA_TRANSFORM,  // Y  telunjuk menulis E=mc² di udara, persamaannya dipadatkan ke dada jadi atom (REL_MORPH_BURST)
    RELATIVA_REVERT,     // kembali: atom di dada terurai jadi foton
    RELATIVA_DASH,       // Z  Lesat Cahaya: merunduk, lalu melesat secepat cahaya (pos = tujuan, REL_DASH_AT)
    RELATIVA_DILATION,   // Shift+Z  Dilatasi Waktu: lengan memutar lingkaran jam, medan waktu melambat (REL_DILATION_HIT)
    RELATIVA_WARP,       // X  Lengkung Ruang-Waktu: telapak menekan ke bawah, ruang-waktu melengkung (pos = pusat, REL_WARP_SLAM)
    RELATIVA_BLACKHOLE,  // Shift+X  LUBANG HITAM: kedua tangan memadatkan massa, lalu dilepas (pos = pusat, REL_BH_FORM)
    RELATIVA_TUNNEL,     // C  Terowongan Kuantum: badan jadi gelombang, menembus dinding (pos = tujuan, REL_TUNNEL_AT)
    RELATIVA_ENTANGLE,   // Shift+C  Keterikatan Kuantum: dua jari ditarik berpasangan (REL_ENTANGLE_HIT)
    RELATIVA_FISSION,    // V  Fisi Berantai: neutron dijentikkan (pos = sasaran pertama, REL_FISSION_HIT)
    RELATIVA_CRITICAL,   // Shift+V  Massa Kritis: inti uranium dilempar, lalu meledak (pos = titik ledak, REL_CRIT_BOOM)
    RELATIVA_FUSION,     // B  Fusi Bintang: dua proton dipertemukan di telapak, bintang mini dilempar (REL_FUSION_THROW)
    RELATIVA_TOKAMAK,    // Shift+B  Tokamak: kedua lengan membentang, cincin plasma mengurung (REL_TOKAMAK_HIT)
    RELATIVA_EMC,        // N  E=mc²: persamaan ditulis di udara lalu dilempar ke sasaran (pos = sasaran, REL_EMC_HIT)
    RELATIVA_ANNIHILATE, // Shift+N  Anihilasi: elektron & positron dipertemukan, dua sinar gamma berlawanan (REL_ANNIHILATE_AT)
    RELATIVA_UNIFIED,    // R  Teori Medan Terpadu: empat gaya mengorbit lalu menyatu (REL_UNIFIED_HIT)
    RELATIVA_BEC,        // Shift+R  Kondensat Bose-Einstein: telapak ke tanah, suhu jatuh ke nol mutlak (REL_BEC_HIT)
    RELATIVA_PHOTO,      // M  Efek Fotolistrik: rentetan foton dari telapak (REL_PHOTO_FIRST, tiap REL_PHOTO_GAP)
    RELATIVA_LASER,      // Shift+M  Laser: atom tereksitasi di telapak, lalu sinar koheren (REL_LASER_CHARGE)
    RELATIVA_GWAVE,      // J  Gelombang Gravitasi: lompat kecil, menghentak tanah (REL_GWAVE_HIT)
    RELATIVA_BROWN,      // Shift+J  Gerak Brown: badan bergetar, melompat-lompat acak (tiap REL_BROWN_GAP)
    PHYS_PAPER,          // satu makalah 1905 tertulis (x = makalah 0-3, y = jumlah yang sudah tertulis)
    PHYS_FROM,           // titik asal garis berikutnya: dikirim TEPAT sebelum PHYS_NEUTRON / PHYS_ARC / PHYS_BROWN
    PHYS_NEUTRON,        // neutron melompat dari PHYS_FROM ke sini (pos)
    PHYS_FISSION,        // inti atom membelah di sini (pos)
    PHYS_ARC,            // fotoelektron melompat dari PHYS_FROM ke sini (pos)
    PHYS_PHOTON,         // satu foton dari tangan ke sini (pos = titik kena)
    PHYS_FUSION_SHOT,    // bintang mini dilempar ke sini (pos = titik hantam; lama terbang = jarak / RelativaData.FUSION_SPEED)
    PHYS_ENTANGLE,       // makhluk ini terikat kuantum (pos = dadanya)
    PHYS_ENTANGLE_PULSE, // damage mengalir lewat keterikatan ke sini (pos = dadanya)
    PHYS_FROZEN,         // makhluk ini membeku di kondensat (pos = dadanya)
    PHYS_UNIFIED_HIT,    // satu makhluk dihantam keempat gaya (pos = dadanya)
    PHYS_BH_END,         // lubang hitam menguap: ledakan radiasi Hawking (pos)
    PHYS_CRIT_BOOM,      // massa kritis meledak (pos)
    PHYS_DISRUPT,        // cincin plasma tokamak pecah (pos = pusatnya)
    PHYS_BROWN,          // satu lompatan Gerak Brown (pos = titik baru)
    PHYS_DODGE,          // Superposisi: serangan "lewat" badan (pos = posisi badan)
    PHYS_PUNCH,          // Tinju Foton kena (pos)
    // 0.67 RELATIVA: Kecepatan Cahaya (waktu dunia berhenti) & pasif Terowongan Kuantum (badan menembus segalanya)
    RELATIVA_LIGHT,      // ancang-ancang Kecepatan Cahaya, waktu berhenti di REL_LIGHT_WINDUP
    RELATIVA_LIGHT_END,  // waktu berjalan lagi sesudah REL_LIGHT_RESUME
    RELATIVA_PHASE_ON,   // seluruh atom badan berubah jadi gelombang (REL_PHASE_SWEEP)
    RELATIVA_PHASE_OFF,  // fungsi gelombang runtuh, badan padat lagi (REL_PHASE_OFF)
    PHYS_TIME_HIT,       // pukulan ke makhluk yang membeku ditabung (pos)
    PHYS_PHASE_PASS,     // serangan / benda menembus badan yang sedang menembus (pos)
    // 0.70 RELATIVA: Jembatan Einstein-Rosen, Foton Tanpa Massa, Kucing Schrödinger, Cincin Einstein
    RELATIVA_WORMHOLE,   // L  kedua tangan merobek ruang-waktu, dua mulut lubang cacing terbuka di REL_WORM_OPEN
    RELATIVA_PHOTON_ON,  // F  badan jadi cahaya (massa diam nol), melesat terbang di REL_PHOTON_ON
    RELATIVA_PHOTON_OFF, //    cahaya memadat lagi jadi badan bermassa (REL_PHOTON_OFF)
    RELATIVA_CLONE,      // K  kotak Schrödinger dibuka: badan terbelah jadi superposisi di REL_CLONE_SPLIT
    RELATIVA_CLOAK_ON,   // H  cahaya dibelokkan mengelilingi badan, hilang dari pandangan di REL_CLOAK_AT
    RELATIVA_CLOAK_OFF,  //    lensa dilepas, badan terlihat lagi (REL_CLOAK_OFF)
    PHYS_CLONE_COLLAPSE, // satu salinan teramati: fungsi gelombangnya runtuh jadi partikel (entity = salinan, pos = dadanya)
    PHYS_CLONE_DECOY,    // yang asli dipukul, salinan yang menanggungnya (pos = dada RELATIVA)
    PHYS_CLOAK_STRIKE;   // serangan pertama dari balik Cincin Einstein, damage x2 (pos = titik kena)

    // Waktu (tick) yang dipakai bersama oleh server dan client supaya efek pas dengan gerakan
    public static final int SUMMON_TICKS = 88;      // enam dewa datang satu per satu (lihat client.fx.GodShow), lalu kepalan diangkat
    public static final int TRANSFORM_WINDUP = 8;   // angkat kepalan ke langit
    public static final int BOLT_DESCENT = 10;      // petir turun pelan dari langit ke kepalan (slow motion)
    public static final int TRANSFORM_STRIKE = TRANSFORM_WINDUP + BOLT_DESCENT;   // tick klip TRANSFORM saat petir mengenai
    public static final int TRANSFORM_SLOWMO = 28;  // slow motion berlanjut selama kostum terbentuk (sampai hood terpasang)
    public static final int HOOD_GRAB = 6;          // tangan memegang tepi hood
    public static final int HOOD_MOVE = 10;         // hood ditarik/didorong selama ini
    public static final int HOOD_TICKS = 24;        // panjang animasi hood
    public static final int REVERT_WINDUP = 6;
    // 0.35 Lintang (ala Superman, tanpa sihir): ganti kostum secepat kilat, tanpa dewa / petir / slow motion
    public static final int LINTANG_RIP = 6;        // kedua tangan merobek kemeja: lambang di dada terlihat
    public static final int LINTANG_SUITUP = 12;    // berputar super cepat; di tick ini kostum & jubah terpasang + ledakan udara
    public static final int LINTANG_SUIT_TICKS = 40; // panjang klip ganti kostum (sampai pose pahlawan selesai)
    public static final int LINTANG_ICE_TICKS = 70;  // 0.36 lama musuh membeku jadi patung es (3,5 detik)
    public static final int COMBO_DASH_WINDUP = 2;   // 0.37 Kombo Langit: merunduk sebelum melesat
    public static final int COMBO_DASH_TICKS = 4;    // melesat ke sasaran
    public static final int COMBO_UPPERCUT = COMBO_DASH_WINDUP + COMBO_DASH_TICKS;   // tick uppercut
    public static final int COMBO_RISE = 12;         // tick mulai naik ke atas sasaran yang melayang
    public static final int COMBO_RISE_TICKS = 4;
    public static final int COMBO_SMASH = 17;        // tick hantaman dua kepalan ke bawah
    public static final int COMBO_SMASH_TICKS = 6;   // ikut menukik ke tanah
    public static final int SOLAR_NOVA_WINDUP = 60;  // 0.37 Ledakan Surya: 3 detik mengumpulkan panas, lalu meledak
    public static final int CAST_WINDUP = 5;        // Solomon, Hercules, Atlas (di tanah), Zeus
    public static final int ROAR_WINDUP = 4;        // Achilles
    public static final int ACHILLES_TICKS = 120;   // lama kulit tak tertembus
    public static final int SOLOMON_TICKS = 200;    // lama musuh "terbaca"
    public static final int BLITZ_TICKS = 6;        // lama terjangan Mercury
    public static final int RAGE_WINDUP = 9;        // Zeus Rage: membungkuk, lalu meraung ke langit
    public static final int RAGE_TICKS = 240;       // lama amarah Zeus (12 detik)
    public static final int KNOCKOUT_BURST = 3;     // terlempar balik: kekuatan tercabut keluar dari dada (lengan terentang)
    // Black Adam
    public static final int SHU_TICKS = 50;         // lama pusaran pasir Shu (lalu meledak ke luar)
    public static final int HERU_WINDUP = 3;        // merunduk sebelum menerjang
    public static final int HERU_TICKS = 5;         // lama terjangan Heru (titik awal -> titik akhir)
    public static final int AMON_WINDUP = 7;        // melompat kecil lalu kedua kepalan menghantam tanah
    public static final int AMON_SPREAD = 8;        // tanah terbelah merambat sampai ujung dalam waktu ini
    public static final int ATON_WINDUP = 8;        // cakram matahari terbentuk, lalu sinar pertama
    public static final int ATON_GAP = 2;           // jeda antar-sinar ke tiap musuh
    public static final int MEHEN_WINDUP = 6;       // ular muncul dari bayangan dan melilit
    public static final int MEHEN_TICKS = 160;      // lama lilitan Mehen (8 detik)
    public static final int ADAM_RAGE_WINDUP = 10;  // Murka Kahndaq: menahan amarah, lalu meraung
    public static final int ADAM_CALL_WINDUP = 12;  // Panggil Petir: kepalan diangkat, langit bergemuruh, lalu petir menyambar
    // Jalan mendapatkan juara
    public static final int KAHNDAQ_AWAKEN_TICKS = 70;    // upacara skarabe bangkit
    public static final int KAHNDAQ_AWAKEN_STRIKE = 52;   // petir Kahndaq menyambar (Black Adam terbuka)
    public static final int SHAZAM_CHOSEN_TICKS = 64;     // upacara enam totem
    public static final int SHAZAM_CHOSEN_STRIKE = 48;    // petir Penyihir menyambar (Shazam terbuka)
    // Shazam 0.23: juara para dewa
    public static final int THROW_LIFT = 6;         // Lemparan Hercules: musuh diangkat ke atas kepala selama ini
    public static final int THROW_RELEASE = 9;      // lalu dilempar (tick klip HERCULES_THROW)
    public static final int ATLAS_HOLD = 13;        // Beban Langit: bola langit diangkat, lalu dihantamkan di tick ini
    public static final int ATLAS_GLOBE_DROP = 9;   // bola langit jatuh selama ini sebelum hantaman
    public static final int ZEUS_HOP = 2;           // jeda antar-lompatan Petir Berantai
    public static final int NOVA_WINDUP = 2;        // Ledakan Keberanian: lengan menghentak, lalu meledak
    // 0.25: Penangkal Petir Hidup
    public static final int FAMILY_WINDUP = 10;     // 0.26 Kekuatan Keluarga: kepalan terangkat, lalu petir menyambar semua
    public static final int SUN_SET_TICKS = 32;      // 0.29: lama Cakram Aton terbenam
    public static final int SUN_RISE_TICKS = 20;     // 0.29: lama Cakram Aton terbit (denyut pertama sesudahnya)
    public static final int ROD_FADE_TICKS = 26;     // 0.29: lama listrik Shazam tersendat lalu padam
    public static final int ROD_DESCENT = 3;        // petir turun dari langit selama ini, lalu menghantam (energi, darah,
                                                    // armor pulih tepat di tick ini; SFX rod_strike retak di 0,15 detik)
    // 0.30 Sabbac
    public static final int HORN_WINDUP = 6;        // Tanduk Setan: menunduk & menggaruk tanah seperti banteng
    public static final int HORN_TICKS = 8;         // lama serudukan (titik awal -> titik akhir)
    public static final int AYM_WINDUP = 5;         // Tubuh Aym: kulit membatu
    public static final int AYM_TICKS = 140;        // lama kulit obsidian (7 detik)
    public static final int CHAIN_WINDUP = 6;       // Rantai Belial: rantai menyeruak dari tanah
    public static final int CHAIN_PULL = 20;        // lalu (1 detik kemudian) musuh yang terbelit ditarik
    public static final int BREATH_WINDUP = 8;      // Napas Beelzebub: menarik napas, lalu menyembur
    public static final int BREATH_TICKS = 40;      // lama semburan (2 detik)
    public static final int TERROR_WINDUP = 7;      // Teror Asmodeus: menahan raungan
    public static final int WINGS_WINDUP = 6;       // Kepakan Crateis: sayap terbentang, lalu mengepak
    public static final int HELLGATE_WINDUP = 12;   // Gerbang Neraka: membungkuk menahan api, lalu meraung jadi raksasa
    public static final int SABBAC_CALL_WINDUP = 12; // Panggil Petir Neraka: tanah bergemuruh, lalu petir menyembur naik
    public static final int LEGION_WINDUP = 10;     // Pasukan Iblis: tangan ke tanah, lalu prajurit bangkit
    public static final int PACT_TICKS = 80;        // Perjanjian Enam Iblis
    public static final int PACT_STRIKE = 60;       // petir neraka menyembur naik (Sabbac terbuka)
    public static final int FIRE_OUT_TICKS = 28;    // Api Neraka padam
    public static final int FIRE_IN_TICKS = 16;     // Api Neraka menyala lagi (denyut pertama sesudahnya)
    // 0.32 Lintang
    public static final int LESAT_WINDUP = 4;       // Lesatan Bintang: merunduk, lalu melesat
    public static final int LESAT_TICKS = 6;        // lama lesatan (titik awal -> titik akhir)
    public static final int IRIS_WINDUP = 6;        // Iris Surya: mata memanas
    public static final int IRIS_TICKS = 40;        // lama sinar mata (2 detik)
    public static final int FROST_WINDUP = 8;       // Napas Salju: menarik napas
    public static final int FROST_TICKS = 40;       // lama hembusan (2 detik)
    public static final int SONIC_WINDUP = 6;       // Tepukan Guruh: lengan terentang, lalu tepukan
    public static final int BARRAGE_WINDUP = 3;     // Amukan Kilat: kuda-kuda
    public static final int BARRAGE_TICKS = 24;     // lama rentetan pukulan (pukulan penutup di akhir)
    public static final int LEAP_WINDUP = 4;        // Napak Langit: merunduk, lalu melompat
    public static final int FLARE_WINDUP = 16;      // Gelegar Surya: menyerap cahaya, lalu meledak
    public static final int SUNCALL_WINDUP = 10;    // Serap Surya: lengan terangkat, lalu tiang cahaya menghunjam
    public static final int RESCUE_WINDUP = 4;      // Selamatkan: lalu melesat ke tiap sekutu (2 tick per sekutu)
    public static final int RITE_TICKS = 80;        // Penyatuan Bintang
    public static final int RITE_STRIKE = 60;       // tiang cahaya menghunjam (Lintang terbuka)
    public static final int DIM_TICKS = 24;         // cahaya Lintang meredup
    // 0.42 Lintang
    public static final int IRIS_CHARGE_TICKS = 60; // X ditahan segini lama = charge penuh (3 detik)
    public static final int IRIS_MIN_TICKS = 16;    // lama sinar tanpa charge (0,8 detik)
    public static final int IRIS_MAX_TICKS = 90;    // lama sinar charge penuh (4,5 detik)
    public static final int BLITZ_WINDUP = 5;       // Lintas Detik: dunia berhenti (memucat), lalu sambaran pertama
    public static final int BLITZ_STEP = 3;         // jeda antar-sambaran (dunia masih berhenti). 0.44: 2 -> 3
    public static final int BLITZ_RESUME = 8;       // 0.44: jeda sesaat (semua bayangan & cincin terlihat), lalu waktu jalan lagi
    public static final int SUN_WINDUP = 14;        // Nyala Mentari: cahaya terkumpul di tangan, lalu didorong
    public static final int SUN_TRAVEL = 8;         // matahari mini melayang ke titik bidik
    public static final int SUN_TICKS = 120;        // lama matahari mini menyala (6 detik), lalu runtuh
    public static final int SUN_PUNCH_WINDUP = 3;   // tinju udara: kepalan menghentak, lalu matahari melesat
    // 0.43 Projek Helion-6 (panjang SFX-nya dikunci ke angka ini, lihat tools/sfx/helion_sfx.py)
    public static final int HELION_SUITUP = 16;         // berubah wujud: radiasi terkumpul, lalu meledak & kostum terbentuk
    public static final int HELION_SUIT_TICKS = 46;     // panjang klip berubah wujud (sampai berdiri bersilang tangan)
    public static final int HELION_DASH_WINDUP = 4;     // Hempasan Lesat: merunduk
    public static final int HELION_DASH_TICKS = 5;      // lama melesat
    public static final int HELION_EYES_WINDUP = 10;    // Emisi Cryon: mata mengumpulkan radiasi (SFX 0,5 dtk)
    public static final int HELION_EYES_TICKS = 50;     // lama sinar (2,5 detik)
    public static final int HELION_QUAKE_WINDUP = 12;   // Injakan Cryon: melompat, lalu menghantam (SFX meledak di 0,6 dtk)
    public static final int HELION_NOVA_WINDUP = 60;    // Supernova-6: 3 detik menyerap radiasi, lalu meledak
    public static final int HELION_INHALE_WINDUP = 18;  // Hirup Cryon: diremukkan & dihirup, lalu melonjak (SFX 0,9 dtk)
    public static final int HELION_RITE_TICKS = 150;    // Eksperimen Proyek Helion-6
    public static final int HELION_RITE_STRIKE = 112;   // radiasi meledak keluar (Helion-6 terbuka; SFX 5,6 dtk)
    public static final int HELION_COLLAPSE_TICKS = 40; // jatuh berlutut saat radiasi habis
    // 0.45 sisa skill Helion-6 (SFX dikunci ke angka ini, lihat tools/sfx/helion_sfx.py)
    public static final int HELION_LAHAP_TICKS = 50;     // Lahap Radiasi: lama menghisap (SFX 2,5 dtk)
    public static final int HELION_ORBIT_TICKS = 70;     // Orbit Cryon: paling lama kristal mengorbit
    public static final int HELION_NISAN_WINDUP = 6;     // Nisan Kristal: telapak menghantam tanah (SFX 0,3 dtk), lalu kristal
    public static final int HELION_ECLIPSE_WINDUP = 30;  // Gerhana Buatan: kepalan ke matahari & sinar ke langit (SFX 1,5 dtk)
    // 0.49 Subjek Tiga yang bisa dimainkan
    public static final int SUBJEK_MORPH_BURST = 22;     // berubah wujud: kepompong sel mati pecah, monster terlihat
    public static final int SUBJEK_MORPH_TICKS = 52;     // panjang klip berubah wujud (sampai raungan selesai)
    public static final int SUBJEK_SMASH_HIT1 = 5;       // Hantam: kepalan kanan
    public static final int SUBJEK_SMASH_HIT2 = 12;      // kepalan kiri
    public static final int SUBJEK_SMASH_POUND = 22;     // kedua kepalan menghantam tanah
    public static final int SUBJEK_SMASH_TICKS = 32;
    public static final int SUBJEK_ROAR_HIT = 8;         // Erangan: gelombang raungan keluar
    public static final int SUBJEK_ROAR_TICKS = 30;
    public static final int SUBJEK_LEAP_WINDUP = 5;      // Lompat: merunduk
    public static final int SUBJEK_LEAP_TICKS = 13;      // lama di udara
    public static final int SUBJEK_COCOON_TICKS = 60;    // Inkubasi: lama di dalam kepompong
    public static final int SUBJEK_SPIKES_WINDUP = 8;    // Onak Tulang: kedua cakar menancap ke tanah
    public static final int SUBJEK_SPIKES_TICKS = 26;
    public static final int SUBJEK_CHARGE_WINDUP = 10;   // Nyeruduk: mengais tanah
    public static final int SUBJEK_CHARGE_TICKS = 14;    // lama menyeruduk
    public static final int SUBJEK_RAGE_WINDUP = 24;     // Evolusi Ketiga: tubuh membengkak, lalu meraung
    public static final int SUBJEK_RAGE_TICKS = 50;
    public static final int SUBJEK_ABSORB_WINDUP = 14;   // Serap Cryon: diremukkan di dada, lalu diserap
    public static final int SUBJEK_BURROW_DIVE = 8;      // Terobos Tanah: menyelam
    public static final int SUBJEK_BURROW_TICKS = 16;    // lama di bawah tanah, lalu meletus keluar
    public static final int SUBJEK_FALL_TICKS = 26;      // tumbang
    public static final int SUBJEK_REVIVE_TICKS = 66;    // kepompong, lalu bangkit
    public static final int SUBJEK_REVIVE_BURST = 50;    // kepompong pecah
    public static final int SUBJEK_RITE_TICKS = 150;     // Inkubasi Subjek Tiga (ritual)
    public static final int SUBJEK_RITE_STRIKE = 112;    // kepompong pecah, Subjek Tiga terbuka
    // 0.50 Aksara (dipakai server AksaraSkills/AksaraRite dan client Clips/AksaraFx)
    public static final int AKSARA_MORPH_TICKS = 56;     // berubah: cakram datang, garis prada menggurat badan
    public static final int AKSARA_MORPH_BURST = 44;     //   ... lalu cakram mengunci di punggung (transform di server)
    public static final int AKSARA_RITE_TICKS = 170;     // Penulisan Ulang (ritual)
    public static final int AKSARA_RITE_READ = 50;       //   aksara terangkat dari lontar
    public static final int AKSARA_RITE_ETCH = 110;      //   aksara menggurat badan
    public static final int AKSARA_RITE_BURST = 150;     //   menyatu: Aksara terbuka
    public static final int AKSARA_BEAM_WINDUP = 8;      // Sinar Daya: tenaga di telapak, lalu sinar
    public static final int AKSARA_BEAM_TICKS = 32;      //   lama sinar
    public static final int AKSARA_NOVA_WINDUP = 22;     // Ledak Daya: mengumpulkan, lalu meledak
    public static final int AKSARA_FOLD_SNAP = 5;        // Lipat Ruang: jentikan, lalu pindah
    public static final int AKSARA_GATE_OPEN = 10;       // Gerbang Ruang: gerbang terbuka
    public static final int AKSARA_GATE_SWALLOW = 32;    //   menelan sampai tick ini, lalu dimuntahkan dari langit
    public static final int AKSARA_LANCE_HIT = 9;        // Tusuk Benak
    public static final int AKSARA_DOMINION_HIT = 18;    // Kuasa Benak
    public static final int AKSARA_DOMINION_TICKS = 160; //   lama musuh saling serang
    public static final int AKSARA_REWRITE_HIT = 16;     // Ubah Maya
    public static final int AKSARA_VEIL_HIT = 8;         // Cermin Maya
    public static final int AKSARA_VEIL_TICKS = 160;
    public static final int AKSARA_TIMESTOP_HIT = 12;    // Henti Kala
    public static final int AKSARA_TIMESTOP_TICKS = 100;
    public static final int AKSARA_REWIND_HIT = 10;      // Putar Kala
    public static final int AKSARA_REWIND_BACK = 100;    //   mundur 5 detik
    public static final int AKSARA_SOUL_WINDUP = 8;      // Rampas Atma: lalu jiwa ditarik
    public static final int AKSARA_SOUL_TICKS = 40;
    public static final int AKSARA_SOUL_RIP = AKSARA_SOUL_WINDUP + AKSARA_SOUL_TICKS;
    public static final int AKSARA_WARD_HIT = 12;        // Tirai Atma
    public static final int AKSARA_WARD_TICKS = 200;
    public static final int AKSARA_PURNA_HIT = 34;       // Sabda Purna
    public static final int AKSARA_PURNA_TICKS = 400;
    public static final int AKSARA_ERASE_HIT = 64;       // Penghapusan
    public static final int AKSARA_DISCS_THROW = 6;      // Lontar Cakram: dilempar, lalu terbang
    public static final int AKSARA_DISCS_FLIGHT = 8;
    public static final int AKSARA_SHIELD_TICKS = 100;   // Perisai Sabda
    public static final int AKSARA_SELF_HIT = 16;        // Tulis Ulang Diri
    public static final int AKSARA_SKYSPEAR_STRIKE = 28; // 0.60 Tombak Langit: dibidik sampai tick ini, lalu jatuh
    public static final int AKSARA_GRAVITY_CAST = 10;    // 0.60 Sumur Graviton: sumur muncul
    public static final int AKSARA_GRAVITY_TICKS = 80;   //   lama menyedot (Fase Dewa: AksaraSkills.GOD_WELL_TICKS)
    public static final int AKSARA_NEURAL_HIT = 10;      // 0.60 Jaring Saraf: benak tersambung
    public static final int AKSARA_SPIKES_HIT = 8;       // 0.60 Duri Maya: duri pertama
    public static final int AKSARA_SPIKES_STEPS = 13;    //   gelombang maju 2 blok tiap tick
    public static final int AKSARA_ECHO_CAST = 6;        // 0.60 Gema Kala: mulai merekam
    public static final int AKSARA_ECHO_RECORD = 60;     //   lama merekam (Fase Dewa: AksaraSkills.GOD_ECHO_RECORD)
    public static final int AKSARA_ECHO_DELAY = 10;      //   jeda sebelum terulang
    public static final int AKSARA_TETHER_HIT = 8;       // 0.60 Tambatan Atma: rantai jiwa terpasang
    public static final int AKSARA_TETHER_TICKS = 160;   //   lama tertambat (Fase Dewa: AksaraSkills.GOD_TETHER_TICKS)

    // 0.63 THANOS: tick puncak tiap gerakan (server, klip ThanosClips, efek ThanosFx & SFX thanos_* dikunci ke angka ini)
    public static final int TITAN_BIND_TICKS = 120;      // Sumpah Titan
    public static final int TITAN_BIND_BURST = 90;       //   menyatu: Thanos terbuka
    public static final int TITAN_MORPH_TICKS = 40;      // berubah
    public static final int TITAN_MORPH_BURST = 26;      //   ledakan kosmik: kekuatan Thanos terpasang
    public static final int TITAN_REVERT_TICKS = 18;
    public static final int TITAN_PUNCH_HIT = 7;         // Tinju Daya
    public static final int TITAN_NOVA_HIT = 16;         // Ledakan Daya
    public static final int TITAN_STEP_AT = 6;           // Langkah Kosmik: pindah
    public static final int TITAN_MOON_OPEN = 12;        // Hujan Bulan: langit robek
    public static final int TITAN_MOON_FIRST = 18;       //   batu pertama mulai jatuh
    public static final int TITAN_MOON_GAP = 5;          //   jeda antar-batu
    public static final int TITAN_MOON_COUNT = 8;
    public static final int TITAN_METEOR_FALL = 10;      //   lama batu jatuh sebelum menghantam
    public static final int TITAN_MIND_HIT = 8;          // Belenggu Pikiran
    public static final int TITAN_THRALL_TICKS = 240;    //   lama sasaran jadi budak
    public static final int TITAN_MINDSTORM_HIT = 14;    // Badai Pikiran
    public static final int TITAN_MINDSTORM_TICKS = 160;
    public static final int TITAN_WRAP_HIT = 8;          // Kenyataan Palsu
    public static final int TITAN_WRAP_HOLD = 60;        //   lama terbelit, lalu meledak
    public static final int TITAN_REALITY_HIT = 12;      // Badai Realitas
    public static final int TITAN_REALITY_TICKS = 100;
    public static final int TITAN_REWIND_AT = 10;        // Putar Balik
    public static final int TITAN_REWIND_BACK = 60;      //   mundur 3 detik
    public static final int TITAN_TIMESTOP_HIT = 12;     // Henti Waktu
    public static final int TITAN_TIMESTOP_TICKS = 80;
    public static final int TITAN_HARVEST_HIT = 8;       // Panen Jiwa
    public static final int TITAN_HARVEST_TICKS = 40;
    public static final int TITAN_SHIELD_HIT = 10;       // Perisai Jiwa
    public static final int TITAN_SHIELD_TICKS = 160;
    public static final int TITAN_SNAP_AT = 60;          // JENTIKAN: jari dijentikkan
    public static final int TITAN_SNAP_STAGGER = 8;      //   batu menyala satu per satu tiap 8 tick
    public static final int TITAN_RAGE_HIT = 14;         // Murka Titan
    public static final int TITAN_RAGE_TICKS = 300;
    public static final int TITAN_SPIN_HIT = 6;          // Putaran Pedang
    public static final int TITAN_THROW_AT = 5;          // Lemparan Pedang
    public static final int TITAN_LEAP_JUMP = 6;         // Hantaman Titan: melompat

    // 0.64 Kuasa Infinity (server, klip ThanosClips, efek InfinityFx & SFX infinity_* dikunci ke angka ini)
    public static final int INF_SURGE_HIT = 12;          // Daya Tak Terbatas menyala
    public static final int INF_CRATER_THROW = 14;       // bola daya dilepas
    public static final int INF_CRATER_TRAVEL = 8;       //   lama terbang sampai menghantam
    public static final int INF_PORTAL_OPEN = 10;        // gerbang terbuka
    public static final int INF_PORTAL_STEP = 18;        //   melangkah masuk: pindah
    public static final int INF_REWRITE_HIT = 16;        // kenyataan mulai ditulis ulang
    public static final int INF_REWRITE_SPREAD = 40;     //   gelombangnya sampai tepi
    public static final int INF_RAISE_HIT = 14;          // undead pertama bangkit
    public static final int INF_RAISE_GAP = 3;           //   jeda antar-undead
    // 0.66 RELATIVA (server RelativaSkills, klip RelativaClips, efek RelativaFx & SFX relativa_* dikunci ke angka ini)
    public static final int REL_RITE_TICKS = 170;        // Eksperimen Pikiran
    public static final int REL_RITE_BURST = 140;        //   persamaan menyatu di dada: RELATIVA terbuka
    public static final int REL_MORPH_TICKS = 40;        // berubah
    public static final int REL_MORPH_BURST = 26;        //   E=mc² dipadatkan jadi atom: kekuatan terpasang
    public static final int REL_REVERT_TICKS = 16;
    public static final int REL_DASH_AT = 4;             // Lesat Cahaya: melesat
    public static final int REL_DILATION_HIT = 10;       // Dilatasi Waktu: medan terbentuk
    public static final int REL_DILATION_TICKS = 240;    //   lama medan (0.68 tingkat dewa: 12 dtk)
    public static final int REL_WARP_HIT = 10;           // Lengkung Ruang-Waktu: kisi mulai melengkung & menarik
    public static final int REL_WARP_SLAM = 40;          //   lalu musuh dihempas ke dasar lengkungan
    public static final int REL_BH_FORM = 18;            // LUBANG HITAM: terbentuk
    public static final int REL_BH_TICKS = 140;          //   lama hidup, lalu menguap (radiasi Hawking)
    public static final int REL_TUNNEL_AT = 8;           // Terowongan Kuantum: pindah
    public static final int REL_ENTANGLE_HIT = 10;       // Keterikatan Kuantum: terikat
    public static final int REL_ENTANGLE_TICKS = 300;    // 0.68: 15 dtk
    public static final int REL_FISSION_HIT = 7;         // Fisi Berantai: neutron pertama kena
    public static final int REL_FISSION_GAP = 5;         //   jeda tiap generasi neutron
    public static final int REL_CRIT_CORE = 10;          // Massa Kritis: inti uranium sampai
    public static final int REL_CRIT_BOOM = 46;          //   meledak
    public static final int REL_FUSION_THROW = 14;       // Fusi Bintang: proton menyatu & bintang dilempar
    public static final int REL_TOKAMAK_HIT = 12;        // Tokamak: cincin plasma menyala
    public static final int REL_TOKAMAK_TICKS = 300;     // 0.68: 15 dtk
    public static final int REL_EMC_WRITE = 18;          // E=mc²: persamaan selesai ditulis
    public static final int REL_EMC_HIT = 26;            //   massa sasaran dikonversi jadi energi
    public static final int REL_ANNIHILATE_AT = 16;      // Anihilasi: elektron & positron bertemu
    public static final int REL_ANNIHILATE_TICKS = 12;   //   lama dua sinar gamma
    public static final int REL_UNIFIED_HIT = 64;        // Teori Medan Terpadu: keempat gaya dilepas
    public static final int REL_UNIFIED_TICKS = 90;
    public static final int REL_BEC_HIT = 14;            // Kondensat Bose-Einstein: membeku
    public static final int REL_BEC_TICKS = 160;         //   lama beku (0.68: 8 dtk)
    public static final int REL_PHOTO_FIRST = 4;         // Efek Fotolistrik: foton pertama
    public static final int REL_PHOTO_GAP = 2;           //   jeda antar-foton
    public static final int REL_PHOTO_COUNT = 6;
    public static final int REL_LASER_CHARGE = 10;       // Laser: atom tereksitasi, lalu sinar menyala
    public static final int REL_LASER_TICKS = 50;        //   lama sinar
    public static final int REL_GWAVE_HIT = 8;           // Gelombang Gravitasi: hentakan
    public static final int REL_BROWN_GAP = 3;           // Gerak Brown: jeda antar-lompatan
    public static final int REL_BROWN_COUNT = 8;
    public static final int REL_LIGHT_WINDUP = 16;       // 0.67 Kecepatan Cahaya: dunia melambat, lalu waktu berhenti
    public static final int REL_LIGHT_TICKS = 600;       //   paling lama waktu berhenti (0.68: 30 dtk; energi juga terkuras)
    public static final int REL_LIGHT_RESUME = 12;       //   jeda sebelum waktu berjalan lagi (jam mulai berdetak)
    public static final int REL_PHASE_SWEEP = 24;        // 0.67 Terowongan Kuantum: bidang ukur menyapu badan
    public static final int REL_PHASE_OFF = 14;          //   fungsi gelombang runtuh
    public static final int REL_WORM_OPEN = 16;          // 0.70 Jembatan Einstein-Rosen: kedua mulut terbuka
    public static final int REL_WORM_TICKS = 800;        //   lama terbuka (40 dtk)
    public static final int REL_WORM_GROW = 14;          //   mulutnya mengembang / menciut
    public static final int REL_PHOTON_ON = 10;          // 0.70 Foton Tanpa Massa: lepas landas
    public static final int REL_PHOTON_OFF = 8;          //   memadat lagi
    public static final int REL_CLONE_SPLIT = 14;        // 0.70 Kucing Schrödinger: terbelah jadi superposisi
    public static final int REL_CLONE_TICKS = 600;       //   umur salinan (30 dtk)
    public static final int REL_CLONE_COLLAPSE = 3;      //   salinan yang teramati: lama runtuhnya
    public static final int REL_CLOAK_AT = 12;           // 0.70 Cincin Einstein: hilang dari pandangan
    public static final int REL_CLOAK_OFF = 8;           //   terlihat lagi

    /** Penanda efek di satu titik (bukan gerakan badan): klip pemain yang sedang jalan nggak diganti. */
    public boolean isMarker() {
        return this == ADAM_ZEHUTI_MARK || this == ADAM_ATON_RAY || this == ADAM_MEHEN_BITE || this == ADAM_DEFLECT
                || this == ADAM_PUNCH || this == KAHNDAQ_RISE || this == KAHNDAQ_END
                || this == HERCULES_IMPACT || this == ATLAS_GLOBE || this == ZEUS_CHAIN_START || this == ZEUS_CHAIN
                || this == THUNDER_PUNCH || this == MERCURY_DODGE || this == HERO_CALL || this == STORM_ABSORB || isGodStrike()
                || this == ROD_STRIKE || this == ADAM_CATCH || this == ADAM_BLOCK || this == ADAM_SUN
                || this == ADAM_SUNPUNCH || this == ADAM_SUN_SET || this == ADAM_SUN_RISE || this == ROD_FADE
                || this == SABBAC_GORE || this == SABBAC_CHAIN_BIND || this == SABBAC_GEYSER || this == SABBAC_RISE
                || this == SABBAC_PULSE || this == SABBAC_HELLPUNCH || this == SABBAC_ENGULF || this == SABBAC_FIRE_OUT
                || this == SABBAC_FIRE_IN || this == SABBAC_PUNCH || this == RIVAL_ARRIVE || this == RIVAL_DEPART
                || this == LINTANG_HIT || this == LINTANG_SLAM || this == LINTANG_SAVE || this == LINTANG_LANCE
                || this == LINTANG_PULSE || this == LINTANG_DAWNPUNCH || this == LINTANG_PARRY || this == LINTANG_BOUNCE
                || this == LINTANG_PUNCH || this == LINTANG_FADE || this == LINTANG_RETURN || this == LINTANG_KELAM
                || this == LINTANG_ICE || this == LINTANG_ICE_BREAK || this == LINTANG_STEAM || this == LINTANG_MELT
                || this == LINTANG_SHATTER || this == LINTANG_BLITZ_HIT || this == LINTANG_BLITZ_END
                || this == LINTANG_SUN_BOOM || this == LINTANG_SUN_COLLAPSE
                || this == HELION_DASH_HIT || this == HELION_PULSE || this == HELION_PUNCH || this == HELION_CRYON_PUNCH
                || this == HELION_DEFLECT || this == HELION_SUN_BURN || this == HELION_SUN_CLEAR || this == HELION_NOVA_BLAST
                || this == HELION_SHARD || this == HELION_TOMB_LOCK || this == HELION_TOMB_SHATTER || this == HELION_TAUNT
                || this == HELION_DUEL_LINE || name().startsWith("HELION3_")
                || this == SUBJEK_HIT || this == SUBJEK_POUND || this == SUBJEK_SLAM || this == SUBJEK_CRASH
                || this == SUBJEK_BURST || this == SUBJEK_ADAPT || this == SUBJEK_IMMUNE || this == SUBJEK_PUNCH
                || this == SUBJEK_THORN || this == SUBJEK_PULSE || this == SUBJEK_EMERGE || this == SUBJEK_RAGE_END
                || name().startsWith("SABDA_")    // 0.50 Aksara
                || name().startsWith("TITAN_")    // 0.63 Thanos
                || name().startsWith("INF_")      // 0.64 Kuasa Infinity
                || name().startsWith("PHYS_");    // 0.66 RELATIVA
    }

    /** Serangan salah satu dewa di lingkaran Badai Para Dewa (Shazam, tombol R). */
    public boolean isGodStrike() {
        return ordinal() >= GOD_SOLOMON.ordinal() && ordinal() <= GOD_MERCURY.ordinal();
    }

    /** 0-5 = Solomon, Hercules, Atlas, Zeus, Achilles, Mercury (sama dengan urutan dewa di client.fx.GodFigures). */
    public int godIndex() {
        return ordinal() - GOD_SOLOMON.ordinal();
    }

    public static ShazamAnim godStrike(int god) {
        return values()[GOD_SOLOMON.ordinal() + Math.floorMod(god, 6)];
    }

    public static ShazamAnim byId(int id) {
        ShazamAnim[] values = values();
        return id >= 0 && id < values.length ? values[id] : null;
    }
}
