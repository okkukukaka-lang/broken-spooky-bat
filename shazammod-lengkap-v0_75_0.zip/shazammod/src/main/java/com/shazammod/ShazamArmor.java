package com.shazammod;

import java.util.EnumMap;
import java.util.List;

import net.minecraft.Util;
import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Bahan kostum Shazam: pertahanan setara netherite, diperbaiki pakai emas.
 * Tekstur saat dipakai: assets/shazammod/textures/models/armor/shazam_suit_layer_1.png dan _layer_2.png
 */
public final class ShazamArmor {
    private ShazamArmor() {}

    public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS =
            DeferredRegister.create(Registries.ARMOR_MATERIAL, ShazamMod.MODID);

    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> SHAZAM_SUIT = ARMOR_MATERIALS.register("shazam_suit",
            () -> new ArmorMaterial(
                    Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                        map.put(ArmorItem.Type.BOOTS, 3);
                        map.put(ArmorItem.Type.LEGGINGS, 6);
                        map.put(ArmorItem.Type.CHESTPLATE, 8);
                        map.put(ArmorItem.Type.HELMET, 3);
                        map.put(ArmorItem.Type.BODY, 11);
                    }),
                    15,
                    SoundEvents.ARMOR_EQUIP_DIAMOND,
                    () -> Ingredient.of(Items.GOLD_INGOT),
                    List.of(new ArmorMaterial.Layer(ShazamMod.id("shazam_suit"))),
                    3.0f,
                    0.1f));

    /**
     * 0.75 Zirah Antiradiasi: sedikit di atas besi, diperbaiki pakai Lempeng Antiradiasi; tiap bagian menahan 25% radiasi
     * KALDERA (Kaldera.radShield). Tekstur: textures/models/armor/antiradiasi_layer_1.png & _layer_2.png
     */
    public static final DeferredHolder<ArmorMaterial, ArmorMaterial> ANTIRADIASI = ARMOR_MATERIALS.register("antiradiasi",
            () -> new ArmorMaterial(
                    Util.make(new EnumMap<>(ArmorItem.Type.class), map -> {
                        map.put(ArmorItem.Type.BOOTS, 2);
                        map.put(ArmorItem.Type.LEGGINGS, 5);
                        map.put(ArmorItem.Type.CHESTPLATE, 7);
                        map.put(ArmorItem.Type.HELMET, 2);
                        map.put(ArmorItem.Type.BODY, 7);
                    }),
                    12,
                    SoundEvents.ARMOR_EQUIP_IRON,
                    () -> Ingredient.of(com.shazammod.kaldera.KalderaItems.ANTIRAD_PLATE.get()),
                    List.of(new ArmorMaterial.Layer(ShazamMod.id("antiradiasi"))),
                    1.0f,
                    0.0f));
}
