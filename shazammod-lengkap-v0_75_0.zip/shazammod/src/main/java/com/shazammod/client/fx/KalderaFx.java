package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamSounds;
import com.shazammod.client.render.KalderaModel;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Ground;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Vfx;
import com.shazammod.kaldera.Kaldera;
import com.shazammod.kaldera.KalderaBody;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * 0.73 Efek client KALDERA (0.73.1 Titan Radiasi): uap & butiran radioaktif dari kawahnya, pendar hijau kawah/mata/mulut
 * (ikut bloom & sinar Shader Shazam), getaran & debu tiap telapaknya mendarat, Injakan Bumi (gelombang kejut di tanah),
 * Letusan Inti (denyut radiasi + tiang cahaya hijau & awan berpetir ion), bongkahan uranium yang melengkung dari kawah,
 * ventilasi radiasi, zona radiasi yang tertinggal di tanah, Gunung Runtuh, kritis, tumbang, & tenggelam. Pemain di dekatnya
 * mendengar penghitung geiger yang makin rapat dan tepi layarnya menghijau (0.75 Zirah Antiradiasi meredamnya). 0.75:
 * Penjara Kristal (deret duri kristal yang merambat & penjara yang menutup) dan gempa peringatan sebelum ia bangkit sendiri.
 * Waktu kejadiannya sama dengan server (KalderaBody.*, Kaldera.ZONE_*), jadi efeknya pas dengan damage-nya.
 */
public final class KalderaFx {
    private KalderaFx() {}

    private static final int RAD = 0x7CFF3A, HOT = 0xDFFF8A, DEEP = 0x2E9A12, ASH = 0x2C3529, DUST = 0x8C8072, SMOKE = 0x232B24;
    private static final int VAPOR = 0xBFE8B4, BOLT = 0xB8FFB0, TINT = 0x1E5A0C;
    private static final Vec3 UP = new Vec3(0, 1, 0);
    private static final double WARN = 16.0;   // geiger mulai berdetak sejauh ini di luar auranya
    private static final Map<Integer, State> STATES = new HashMap<>();
    private static final List<Fallout> FALLOUT = new ArrayList<>();
    private static final KalderaBody.Pose POSE = new KalderaBody.Pose();
    private static final float[] TMP = new float[4];
    private static int geigerWait;

    private static final class State {
        final int[] steps = new int[4];
        boolean ready;
        Aura aura;
    }

    public static void clear() {
        STATES.clear();
        FALLOUT.clear();
        geigerWait = 0;
    }

    // ------------------------------------------------------------------ titik-titik tubuh (client)

    /** Pose Kaldera pada partialTick (dipakai bersama renderer). */
    static KalderaBody.Pose pose(Kaldera k, float pt) {
        KalderaBody.pose(POSE, k.action(), k.actionTime(pt), k.stride(pt), k.tickCount + pt, k.isRaging());
        return POSE;
    }

    private static Vec3 local(Kaldera k, float pt, float lx, float ly, float lz) {
        float yaw = Mth.rotLerp(pt, k.yRotO, k.getYRot());
        double ox = Mth.lerp(pt, k.xo, k.getX()), oy = Mth.lerp(pt, k.yo, k.getY()), oz = Mth.lerp(pt, k.zo, k.getZ());
        return new Vec3(KalderaBody.worldX(ox, yaw, lx, lz), oy + ly, KalderaBody.worldZ(oz, yaw, lx, lz));
    }

    static Vec3 bodyPoint(Kaldera k, float pt, float x, float y, float z) {
        KalderaBody.Pose p = pose(k, pt);
        KalderaBody.body(p, x, y, z, TMP);
        return local(k, pt, TMP[0], TMP[1], TMP[2]);
    }

    static Vec3 headPoint(Kaldera k, float pt, float x, float y, float z) {
        KalderaBody.Pose p = pose(k, pt);
        KalderaBody.headLocal(p, x, y, z, TMP);
        return local(k, pt, TMP[0], TMP[1], TMP[2]);
    }

    static Vec3 caldera(Kaldera k, float pt) {
        return bodyPoint(k, pt, 0f, KalderaBody.CALDERA_Y - 1.6f, KalderaBody.CALDERA_Z);
    }

    private static Vec3 facing(Kaldera k) {
        float a = k.getYRot() * Mth.DEG_TO_RAD;
        return new Vec3(-Mth.sin(a), 0, Mth.cos(a));
    }

    private static double viewerDistance(Vec3 p) {
        LocalPlayer me = Minecraft.getInstance().player;
        return me == null ? 1.0E9 : me.position().distanceTo(p);
    }

    private static Ground.Map map(ClientLevel level, Vec3 p, double radius) {
        return ShazamFx.ground(level, p, radius);
    }

    // ------------------------------------------------------------------ tiap tick

    public static void tick(ClientLevel level) {
        Set<Integer> seen = new HashSet<>();
        LocalPlayer me = Minecraft.getInstance().player;
        float dose = 0f, inside = 0f;
        for (Entity e : level.entitiesForRendering()) {
            if (!(e instanceof Kaldera k) || !k.isAlive()) {
                continue;
            }
            seen.add(k.getId());
            State s = STATES.computeIfAbsent(k.getId(), id -> new State());
            if (s.aura == null || s.aura.gone) {
                s.aura = new Aura(k);
                Vfx.add(s.aura);
            }
            if (viewerDistance(k.position()) < 260.0) {
                steps(level, k, s);
                ambient(level, k);
            }
            if (me != null && !me.isSpectator() && !k.isTamed() && k.radiating() && me.distanceToSqr(k) < 120.0 * 120.0) {
                double d = k.partDistance(me), r = k.auraRadius();
                dose = Math.max(dose, (float) Mth.clamp(1.0 - d / (r + WARN), 0.0, 1.0));
                inside = Math.max(inside, (float) Mth.clamp(1.0 - d / r, 0.0, 1.0));
            }
        }
        STATES.keySet().retainAll(seen);
        FALLOUT.removeIf(f -> f.done || level.getGameTime() > f.end);   // juga yang dibuang tanpa sempat selesai
        if (me != null && !me.isSpectator()) {
            for (Fallout f : FALLOUT) {
                if (!f.harmless && f.contains(me.position())) {
                    dose = Math.max(dose, 0.8f);
                    inside = Math.max(inside, 0.55f);
                }
            }
            int shield = Kaldera.radShield(me);   // 0.75 Zirah Antiradiasi: detektornya tetap berdetak, tapi radiasinya tertahan
            inside *= shield >= 4 ? 0f : 1f - 0.25f * shield;
            dose *= 1f - 0.12f * shield;
            exposure(level, me, dose, inside);
        }
    }

    /**
     * Pemain lokal di dekat sumber radiasi: penghitung geiger berdetak makin rapat (mulai WARN blok di luar auranya), dan di
     * dalam aura / zona radiasi tepi layarnya menghijau samar.
     */
    private static void exposure(ClientLevel level, LocalPlayer me, float dose, float inside) {
        if (dose <= 0f) {
            geigerWait = 0;
            return;
        }
        RandomSource r = level.random;
        if (--geigerWait <= 0) {
            level.playLocalSound(me.getX(), me.getY() + 1.0, me.getZ(), ShazamSounds.KALDERA_GEIGER.get(), SoundSource.HOSTILE,
                    0.3f + 0.45f * dose, 0.92f + r.nextFloat() * 0.16f, false);
            geigerWait = Math.max(1, Math.round(Mth.lerp(dose * dose, 16f, 2f))) + r.nextInt(dose > 0.6f ? 2 : 4);
        }
        if (inside > 0f && level.getGameTime() % 10 == 0) {
            ScreenFx.vignette(0.1f + 0.16f * inside, TINT, 18);
        }
    }

    /** Telapak yang baru mendarat: debu, retakan, pecahan, & getaran. */
    private static void steps(ClientLevel level, Kaldera k, State s) {
        KalderaBody.Action a = k.action();
        boolean walking = a == KalderaBody.Action.IDLE || a == KalderaBody.Action.ROAR || a == KalderaBody.Action.ERUPT
                || a == KalderaBody.Action.GEYSER || a == KalderaBody.Action.PRISON;
        KalderaBody.Pose p = pose(k, 0f);
        for (int i = 0; i < 4; i++) {
            int idx = KalderaBody.stepIndex(i, k.strideC);
            if (s.ready && idx > s.steps[i] && walking && p.planted[i]) {
                KalderaBody.gaitFoot(i, k.strideC, TMP);
                Vec3 f = local(k, 0f, TMP[0], 0f, TMP[1]);
                double g = KalderaBody.ground(level, f.x, f.z);
                footfall(level, new Vec3(f.x, Double.isNaN(g) ? f.y : g, f.z), 1f);
            }
            s.steps[i] = idx;
        }
        s.ready = true;
    }

    private static void footfall(ClientLevel level, Vec3 f, float k) {
        LocalPlayer me = Minecraft.getInstance().player;
        boolean riding = me != null && me.getVehicle() instanceof Kaldera;   // 0.74 penunggangnya cukup bergoyang pelan tiap langkah
        ShazamFx.shakeAround(f, 0.55f * k * (riding ? 0.35f : 1f), 70.0);
        if (viewerDistance(f) > 150.0) {
            return;
        }
        Ground.Map m = map(level, f, 12.0);
        if (m != null) {
            Vfx.add(new Fx.Wave(f.add(0, 0.2, 0), UP, 11.0 * k, 2.6, DUST, 26, 0.65f, 0.18f, m, true));
            Vfx.add(new Ground.Cracks(f, m, 6, 6f * k, 140, 24, DEEP, level.random.nextLong()));
            Vfx.add(new Ground.Debris(f, m, (int) (10 * k), 0.32, 0.45, 4.8, 40));
        }
        ShazamFx.dustPuffs(level, f, DUST, (int) (16 * k), 6.0 * k, 0.26);
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(5 * k); i < n; i++) {   // butiran radioaktif yang terhambur dari tanah
            double ang = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * 5.0 * k;
            Vfx.mote(f.x + Math.cos(ang) * rr, f.y + 0.4, f.z + Math.sin(ang) * rr, (r.nextDouble() - 0.5) * 0.04, 0.03 + r.nextDouble() * 0.05,
                    (r.nextDouble() - 0.5) * 0.04, RAD, 0.3f + r.nextFloat() * 0.25f, 40 + r.nextInt(30));
        }
    }

    /** Uap & butiran dari kawah, uap hijau lubang-lubang lerengnya, butiran di dalam auranya, hujan debu radioaktif saat kritis. */
    private static void ambient(ClientLevel level, Kaldera k) {
        RandomSource r = level.random;
        KalderaBody.Action a = k.action();
        if (a == KalderaBody.Action.DEATH && k.actionTime(0f) > KalderaBody.DEATH_STONE - 30 || a == KalderaBody.Action.RUMBLE) {
            return;   // sudah padam / 0.75 masih terkubur di perut bumi
        }
        Vec3 top = caldera(k, 0f);
        boolean rage = k.isRaging();
        float heat = (rage ? 1.6f : 1f) * (k.exposedTicks(0f) > 0f ? 1.5f : 1f);
        if (k.tickCount % 2 == 0) {
            for (int i = 0, n = Vfx.count(2 * heat); i < n; i++) {
                double ang = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * 5.0;
                Vfx.smoke(top.x + Math.cos(ang) * rr, top.y + 1.0, top.z + Math.sin(ang) * rr, (r.nextDouble() - 0.5) * 0.05,
                        0.12 + r.nextDouble() * 0.1, (r.nextDouble() - 0.5) * 0.05, r.nextBoolean() ? ASH : SMOKE,
                        3.5f + r.nextFloat() * 3f, 70 + r.nextInt(50));
            }
        }
        for (int i = 0, n = Vfx.count(2 * heat); i < n; i++) {   // butiran hijau yang naik dari intinya
            double ang = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * 6.0;
            Vfx.mote(top.x + Math.cos(ang) * rr, top.y + 0.5, top.z + Math.sin(ang) * rr, (r.nextDouble() - 0.5) * 0.06,
                    0.12 + r.nextDouble() * 0.2, (r.nextDouble() - 0.5) * 0.06, r.nextInt(3) == 0 ? HOT : RAD, 0.35f + r.nextFloat() * 0.3f,
                    30 + r.nextInt(30));
        }
        if (k.tickCount % 5 == 0) {
            float[] vents = KalderaModel.VENTS;
            for (int i = 0; i < vents.length; i += 2) {
                Vec3 v = bodyPoint(k, 0f, vents[i], ventTop(vents[i], vents[i + 1]), vents[i + 1]);
                Vfx.smoke(v.x, v.y, v.z, (r.nextDouble() - 0.5) * 0.03, 0.08 + r.nextDouble() * 0.05, (r.nextDouble() - 0.5) * 0.03,
                        VAPOR, 1.4f + r.nextFloat(), 40 + r.nextInt(20));
            }
        }
        if (k.radiating() && viewerDistance(k.position()) < 140.0) {   // butiran yang melayang di dalam auranya
            Vec3 c = k.position();
            double reach = 30.0 + k.auraRadius();
            for (int i = 0, n = Vfx.count(rage ? 4 : 2); i < n; i++) {
                double ang = r.nextDouble() * Math.PI * 2.0, rr = Math.sqrt(r.nextDouble()) * reach;
                Vfx.mote(c.x + Math.cos(ang) * rr, c.y + 1.0 + r.nextDouble() * 14.0, c.z + Math.sin(ang) * rr, (r.nextDouble() - 0.5) * 0.02,
                        0.01 + r.nextDouble() * 0.02, (r.nextDouble() - 0.5) * 0.02, RAD, 0.22f + r.nextFloat() * 0.2f, 50 + r.nextInt(40));
            }
        }
        if (rage && k.tickCount % 2 == 0) {   // kritis: debu radioaktif berjatuhan di sekitarnya
            Vec3 c = k.position();
            for (int i = 0, n = Vfx.count(3); i < n; i++) {
                double ang = r.nextDouble() * Math.PI * 2.0, rr = 8.0 + r.nextDouble() * 40.0;
                double x = c.x + Math.cos(ang) * rr, y = c.y + 30.0 + r.nextDouble() * 30.0, z = c.z + Math.sin(ang) * rr;
                if (r.nextInt(3) == 0) {
                    Vfx.mote(x, y, z, (r.nextDouble() - 0.5) * 0.04, -0.09, (r.nextDouble() - 0.5) * 0.04, RAD, 0.3f + r.nextFloat() * 0.2f, 90);
                } else {
                    Vfx.dust(x, y, z, (r.nextDouble() - 0.5) * 0.04, -0.07, (r.nextDouble() - 0.5) * 0.04, ASH, 0.8f + r.nextFloat() * 0.6f, 90);
                }
            }
        }
        if (a == KalderaBody.Action.IDLE && k.strideC != k.strideO && k.tickCount % 4 == 0) {   // kerikil luruh dari perutnya
            Vec3 c = bodyPoint(k, 0f, (r.nextFloat() - 0.5f) * 24f, KalderaBody.BODY_Y - 11f, (r.nextFloat() - 0.5f) * 36f);
            Vfx.shard(c.x, c.y, c.z, (r.nextDouble() - 0.5) * 0.1, -0.05, (r.nextDouble() - 0.5) * 0.1, DUST, 0.4f + r.nextFloat() * 0.4f,
                    60, k.getY());
        }
    }

    /** Tinggi mulut lubang uap (kira-kira, di atas lereng). */
    private static float ventTop(float x, float z) {
        float d = (float) Math.sqrt(x * x + (z - KalderaBody.CALDERA_Z) * (z - KalderaBody.CALDERA_Z));
        float u = Mth.clamp((20f - d) / 11f, 0f, 1f);
        return KalderaBody.BODY_Y + 1f + (KalderaBody.CALDERA_Y - KalderaBody.BODY_Y - 1f) * u + 2.4f;
    }

    // ------------------------------------------------------------------ dari server (ShazamAnimPayload)

    public static void onAnim(Kaldera k, ShazamAnim anim, Vec3 pos) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        switch (anim) {
            case KALDERA_EMERGE -> emerge(k, pos);
            case KALDERA_ROAR -> ShazamFx.schedule(KalderaBody.ROAR_HIT, 1, (lvl, t) -> roar(lvl, k, 1f));
            case KALDERA_STOMP -> stomp(k, pos);
            case KALDERA_ERUPT -> erupt(k, pos);
            case KALDERA_BOMB -> Vfx.add(new Chunk(caldera(k, 0f), pos, k.isTamed()));
            case KALDERA_GEYSER -> ShazamFx.schedule(KalderaBody.GEYSER_SLAM, 1, (lvl, t) -> footfall(lvl, pos, 1.4f));
            case KALDERA_GEYSER_MARK -> Vfx.add(new Fissure(level, pos, k.isTamed()));
            case KALDERA_FALL -> fall(k, pos);
            case KALDERA_RAGE -> rage(k, pos);
            case KALDERA_EXPOSED -> exposed(level, pos);
            case KALDERA_DEATH -> death(k, pos);
            case KALDERA_SINK -> sink(k, pos);
            case KALDERA_FEED -> feed(level, k, pos);
            case KALDERA_TAME -> tame(level, k, pos);
            case KALDERA_PRISON -> prison(k, pos);
            case KALDERA_PRISON_LINE -> Vfx.add(new SpikeLine(level, leftFoot(level, k), pos));
            case KALDERA_PRISON_CAGE -> Vfx.add(new Cage(level, pos));
            case KALDERA_QUAKE -> quake(level, k, pos);
            default -> { }
        }
    }

    // ------------------------------------------------------------------ bangkit & tenggelam

    private static void emerge(Kaldera k, Vec3 c) {
        ShazamFx.schedule(0, KalderaBody.EMERGE_TICKS, (level, t) -> {
            RandomSource r = level.random;
            float prog = t / (float) KalderaBody.EMERGE_TICKS;
            if (t == 0) {
                Ground.Map m = map(level, c, 40.0);
                if (m != null) {
                    Vfx.add(new Ground.Cracks(c, m, 18, 34f, KalderaBody.EMERGE_TICKS + 120, 140, RAD, r.nextLong()));
                }
                if (viewerDistance(c) < 120.0) {
                    ScreenFx.vignette(0.28f, 0x0C2A06, 70);
                }
            }
            if (t % 4 == 0 && t < KalderaBody.EMERGE_TICKS - 16) {
                ShazamFx.shakeAround(c, 0.35f + 0.6f * prog, 160.0);
            }
            if (t % 5 == 0 && t < KalderaBody.EMERGE_TICKS - 16) {   // tanah yang terangkat & merekah di sekeliling
                double ang = r.nextDouble() * Math.PI * 2.0, rr = 16.0 + r.nextDouble() * 18.0;
                Vec3 p = new Vec3(c.x + Math.cos(ang) * rr, c.y, c.z + Math.sin(ang) * rr);
                ShazamFx.dustPuffs(level, p, DUST, 14, 5.0, 0.3);
                for (int i = 0, n = Vfx.count(6); i < n; i++) {
                    Vfx.shard(p.x, p.y + 0.5, p.z, (r.nextDouble() - 0.5) * 0.5, 0.4 + r.nextDouble() * 0.6, (r.nextDouble() - 0.5) * 0.5,
                            DUST, 0.5f + r.nextFloat() * 0.6f, 60, p.y);
                }
            }
            if (t == KalderaBody.EMERGE_BREACH) {   // puncak kawah menembus tanah: semburan cahaya hijau & bebatuan
                Ground.Map m = map(level, c, 30.0);
                if (m != null) {
                    Vfx.add(new Ground.Debris(c, m, 48, 0.9, 1.2, 14.0, 70));
                }
                Vfx.add(new Fx.Flash(c.add(0, 4, 0), 20f, RAD, 12, 0.8f));
                Vfx.add(new Fx.Wave(c.add(0, 2, 0), UP, 26.0, 2.5, HOT, 22, 0.6f, 0.08f, null));
                for (int i = 0; i < 10; i++) {
                    double ang = r.nextDouble() * Math.PI * 2.0;
                    Vfx.add(new Glob(c.add(0, 3, 0), new Vec3(Math.cos(ang) * 0.6, 1.1 + r.nextDouble() * 0.6, Math.sin(ang) * 0.6),
                            1.2f + r.nextFloat(), c.y));
                }
            }
            if (t > KalderaBody.EMERGE_BREACH && t < KalderaBody.EMERGE_TICKS - 20 && t % 2 == 0) {   // batu luruh dari tubuhnya
                Vec3 p = bodyPoint(k, 0f, (r.nextFloat() - 0.5f) * 34f, KalderaBody.BODY_Y + r.nextFloat() * 14f, (r.nextFloat() - 0.5f) * 50f);
                if (p.y > c.y + 2.0) {
                    Vfx.shard(p.x, p.y, p.z, (r.nextDouble() - 0.5) * 0.3, 0.1, (r.nextDouble() - 0.5) * 0.3, DUST,
                            0.6f + r.nextFloat() * 0.8f, 80, c.y);
                    Vfx.dust(p.x, p.y, p.z, 0, -0.05, 0, DUST, 2.5f, 40);
                }
            }
            if (t == KalderaBody.EMERGE_ROAR) {
                roar(level, k, 0.8f);
            }
        });
    }

    private static void sink(Kaldera k, Vec3 c) {
        ShazamFx.schedule(0, KalderaBody.SINK_TICKS, (level, t) -> {
            RandomSource r = level.random;
            if (t == 0) {
                Ground.Map m = map(level, c, 36.0);
                if (m != null) {
                    Vfx.add(new Ground.Cracks(c, m, 14, 30f, KalderaBody.SINK_TICKS + 60, 60, DEEP, r.nextLong()));
                }
            }
            if (t % 4 == 0) {
                ShazamFx.shakeAround(c, 0.5f, 140.0);
                double ang = r.nextDouble() * Math.PI * 2.0, rr = 14.0 + r.nextDouble() * 18.0;
                ShazamFx.dustPuffs(level, new Vec3(c.x + Math.cos(ang) * rr, c.y, c.z + Math.sin(ang) * rr), DUST, 16, 6.0, 0.25);
            }
            if (t == KalderaBody.SINK_TICKS - 10) {
                ShazamFx.smokeCloud(level, c, DUST, 30, 22.0);
            }
        });
    }

    // ------------------------------------------------------------------ raungan

    private static void roar(ClientLevel level, Kaldera k, float s) {
        Vec3 mouth = headPoint(k, 0f, 0f, -1.5f, KalderaBody.HEAD_LEN - 2f);
        Vec3 dir = facing(k).add(0, 0.25, 0).normalize();
        Vfx.add(new Hd.Pressure(mouth, dir, 28.0 * s, 6.0, 0xE6FFD8, 30, 0.9f * s, true));
        Vfx.add(new Fx.Cone(mouth, dir, 36.0 * s, 0.55, DUST, 28, 0.7f * s, 1.2, true));
        Vfx.add(new Fx.Ripple(mouth, dir, 32.0 * s, 2.0, 14.0 * s, 2.6, 0xD0FFC0, 26, 0.6f * s, true));
        Vfx.add(new Fx.Flash(mouth, 10f * s, RAD, 10, 0.6f));
        ShazamFx.shakeAround(mouth, 1.1f * s, 100.0);
        if (viewerDistance(mouth) < 50.0) {
            ScreenFx.vignette(0.3f * s, 0x10380A, 30);
            FovKick.kick(0.05f * s);
        }
    }

    // ------------------------------------------------------------------ injakan bumi

    private static void stomp(Kaldera k, Vec3 c) {
        ShazamFx.schedule(0, KalderaBody.STOMP_HIT + 1, (level, t) -> {
            RandomSource r = level.random;
            if (t < KalderaBody.STOMP_HIT && t % 3 == 0) {   // tanah & kerikil berjatuhan dari kaki depan yang terangkat
                for (int leg = 0; leg < 2; leg++) {
                    KalderaBody.Pose p = pose(k, 0f);
                    KalderaBody.body(p, p.foot[leg * 3], p.foot[leg * 3 + 1], p.foot[leg * 3 + 2], TMP);
                    Vec3 f = local(k, 0f, TMP[0], TMP[1], TMP[2]);
                    Vfx.shard(f.x + (r.nextDouble() - 0.5) * 6, f.y, f.z + (r.nextDouble() - 0.5) * 6, 0, -0.1, 0, DUST, 0.5f, 50, c.y);
                    Vfx.dust(f.x, f.y, f.z, 0, -0.04, 0, DUST, 2.2f, 30);
                }
            }
            if (t == KalderaBody.STOMP_HIT - 10) {
                ShazamFx.shakeAround(c, 0.4f, 90.0);
            }
            if (t == KalderaBody.STOMP_HIT) {
                Ground.Map m = map(level, c, Kaldera.STOMP_RADIUS);
                Vfx.add(new Quake(c, m, Kaldera.STOMP_RADIUS, Kaldera.STOMP_SPEED, 1f));
                if (m != null) {
                    Vfx.add(new Ground.Cracks(c, m, 20, 26f, 200, 70, RAD, r.nextLong()));
                    Vfx.add(new Ground.Debris(c, m, 44, 0.9, 1.0, 12.0, 60));
                }
                ShazamFx.smokeCloud(level, c, DUST, 26, 14.0);
                Vfx.add(new Fx.Flash(c.add(0, 1, 0), 16f, 0xC8FF90, 8, 0.6f));
                ShazamFx.shakeAround(c, 1.7f, 130.0);
            }
        });
    }

    /** Gelombang kejut di tanah: cincin debu yang merambat, dinding debu di mukanya, layar bergetar saat melewatimu. */
    static final class Quake extends Effect {
        private final Vec3 c;
        private final Ground.Map map;
        private final double max, speed;
        private final float strength;
        private boolean passed;

        Quake(Vec3 c, Ground.Map map, double max, double speed, float strength) {
            super((int) Math.ceil(max / speed) + 2);
            this.c = c;
            this.map = map;
            this.max = max;
            this.speed = speed;
            this.strength = strength;
        }

        private double radius(float pt) {
            return 6.0 + speed * (age + pt);
        }

        @Override
        public boolean tick(ClientLevel level) {
            double r = radius(0f);
            RandomSource rnd = level.random;
            for (int i = 0, n = Vfx.count(26 * strength); i < n; i++) {
                double ang = rnd.nextDouble() * Math.PI * 2.0;
                double gy = map != null ? c.y + map.at(ang, Math.min(r, max)) : c.y;
                Vfx.dust(c.x + Math.cos(ang) * r, gy + 0.3, c.z + Math.sin(ang) * r, Math.cos(ang) * 0.25, 0.08 + rnd.nextDouble() * 0.12,
                        Math.sin(ang) * 0.25, DUST, 1.6f + rnd.nextFloat() * 1.4f, 26 + rnd.nextInt(16));
            }
            LocalPlayer me = Minecraft.getInstance().player;
            if (me != null && !passed) {
                double d = Math.sqrt((me.getX() - c.x) * (me.getX() - c.x) + (me.getZ() - c.z) * (me.getZ() - c.z));
                if (d < r + 1.0 && d < max) {
                    passed = true;
                    CameraShake.add(1.1f * strength * (float) (1.0 - 0.5 * d / max));
                }
            }
            return super.tick(level) && r < max;
        }

        @Override
        public void renderSoft(Draw d) {
            double r = radius(d.partialTick);
            float p = (float) Mth.clamp(r / max, 0.0, 1.0);
            d.ring(c.x, c.y + 0.2, c.z, 0, 1, 0, r, 3.0 + 3.0 * p, DUST, 0.55f * strength * (1f - p), 0.04f * (1f - p), map);
        }

        @Override
        public void renderGlow(Draw d) {
            double r = radius(d.partialTick);
            float p = (float) Mth.clamp(r / max, 0.0, 1.0);
            d.ring(c.x, c.y + 0.25, c.z, 0, 1, 0, r, 1.6, RAD, 0.45f * strength * (1f - p) * (1f - p), 0f, map);
        }

        @Override
        public void shade(float pt) {
            double r = radius(pt);
            ShazamShaders.ring(c.x, c.y + 1.0, c.z, 0, 1, 0, r, 3.0, 0.8f * strength * (float) (1.0 - r / max));
        }
    }

    // ------------------------------------------------------------------ letusan inti

    private static void erupt(Kaldera k, Vec3 top) {
        ShazamFx.schedule(0, KalderaBody.ERUPT_FIRE + 1, (level, t) -> {
            RandomSource r = level.random;
            if (t < KalderaBody.ERUPT_FIRE) {   // inti menghimpun: uap menebal, butiran memercik, cahayanya makin terang
                float u = t / (float) KalderaBody.ERUPT_FIRE;
                for (int i = 0, n = Vfx.count(3); i < n; i++) {
                    Vfx.smoke(top.x + (r.nextDouble() - 0.5) * 8, top.y + 1.5, top.z + (r.nextDouble() - 0.5) * 8, 0, 0.15 + r.nextDouble() * 0.1,
                            0, SMOKE, 4f + r.nextFloat() * 3f, 70);
                    Vfx.spark(top.x, top.y + 1, top.z, (r.nextDouble() - 0.5) * 0.6, 0.4 + r.nextDouble() * 0.5, (r.nextDouble() - 0.5) * 0.6,
                            RAD, 0.4f, 30, Double.NaN);
                }
                for (int i = 0, n = Vfx.count(2 + 4 * u); i < n; i++) {   // butiran tersedot ke kawah
                    double ang = r.nextDouble() * Math.PI * 2.0, rr = 10.0 + r.nextDouble() * 10.0;
                    Vfx.streak(top.x + Math.cos(ang) * rr, top.y + (r.nextDouble() - 0.3) * 6, top.z + Math.sin(ang) * rr, -Math.cos(ang) * 0.5,
                            0.05, -Math.sin(ang) * 0.5, RAD, 0.6f, 14);
                }
                if (t % 5 == 0) {
                    ShazamFx.shakeAround(top, 0.25f + 0.35f * u, 120.0);
                }
            } else {
                Vfx.add(new Plume(top, 1f, 110));
                Vfx.add(new Pulse(top, Kaldera.PULSE_R + 14.0, 1f, k.isTamed()));
                Vfx.add(new Fx.Flash(top.add(0, 3, 0), 26f, HOT, 12, 0.9f));
                Vfx.add(new Hd.Nova(top.add(0, 2, 0), 12.0, HOT, RAD, DEEP, SMOKE, 36, 0.9f, false));
                ShazamFx.shakeAround(top, 1.3f, 150.0);
                if (viewerDistance(top) < 70.0) {
                    ScreenFlash.flash(0.25f, RAD);
                }
            }
        });
    }

    /** Denyut radiasi: kulit bola hijau tipis yang mengembang cepat dari intinya, menembus apa saja. */
    static final class Pulse extends Effect {
        private final Vec3 c;
        private final double max;
        private final float strength;
        private boolean passed;

        /** harmless = denyut KALDERA jinak (nggak menyakitimu): tanpa kilat & tepi layar hijau. */
        Pulse(Vec3 c, double max, float strength, boolean harmless) {
            super(26);
            this.c = c;
            this.max = max;
            this.strength = strength;
            this.passed = harmless;
        }

        private double radius(float pt) {
            float u = progress(pt);
            return max * (1.0 - (1.0 - u) * (1.0 - u));
        }

        @Override
        public boolean tick(ClientLevel level) {
            LocalPlayer me = Minecraft.getInstance().player;
            if (me != null && !passed && Math.sqrt((me.getX() - c.x) * (me.getX() - c.x) + (me.getZ() - c.z) * (me.getZ() - c.z)) < radius(0f)) {
                passed = true;
                ScreenFlash.flash(0.18f * strength, RAD);
                ScreenFx.vignette(0.32f * strength, TINT, 30);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float u = progress(d.partialTick);
            double r = radius(d.partialTick);
            float a = (1f - u) * (1f - u) * strength;
            for (int i = 0; i < 3; i++) {   // tiga cincin miring = kulit bola (normalnya harus satuan)
                double ang = i * Math.PI * 2.0 / 3.0, nl = Math.sqrt(1.0 + 0.36);
                d.ring(c.x, c.y, c.z, Math.cos(ang) * 0.6 / nl, 1.0 / nl, Math.sin(ang) * 0.6 / nl, r, 1.6, RAD, 0.55f * a, 0f, null);
            }
            d.ring(c.x, c.y, c.z, 0, 1, 0, r, 2.4, HOT, 0.4f * a, 0f, null);
            d.glow(c.x, c.y, c.z, (float) r * 0.5f, RAD, 0.25f * a);
        }

        @Override
        public void shade(float pt) {
            ShazamShaders.ring(c.x, c.y, c.z, 0, 1, 0, radius(pt), 3.0, 0.6f * strength * (1f - progress(pt)));
        }
    }

    /** Tiang cahaya hijau & awan debu radioaktif dari kawah, dengan petir ion di dalam awannya. */
    static final class Plume extends Effect {
        private final Vec3 base;
        private final float size;
        private final double[] bolt = new double[18];
        private int boltLife;

        Plume(Vec3 base, float size, int life) {
            super(life);
            this.base = base;
            this.size = size;
        }

        private double height(float pt) {
            float t = time(pt);
            return 46.0 * size * Math.min(1.0, t / 14.0);
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            float fade = 1f - progress(0f);
            double h = height(0f);
            for (int i = 0, n = Vfx.count(8 * size * fade); i < n; i++) {   // semburan cahaya hijau naik
                double y = r.nextDouble() * h * 0.6;
                Vfx.flame(base.x + (r.nextDouble() - 0.5) * 4, base.y + y, base.z + (r.nextDouble() - 0.5) * 4, (r.nextDouble() - 0.5) * 0.15,
                        0.6 + r.nextDouble() * 0.6, (r.nextDouble() - 0.5) * 0.15, r.nextBoolean() ? RAD : HOT, 2.2f + r.nextFloat() * 2f, 26);
            }
            for (int i = 0, n = Vfx.count(5 * size); i < n; i++) {   // awan debu yang membubung & melebar
                double ang = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * 14.0 * size * Math.min(1f, age / 30f);
                Vfx.smoke(base.x + Math.cos(ang) * rr, base.y + h * (0.55 + r.nextDouble() * 0.45), base.z + Math.sin(ang) * rr,
                        Math.cos(ang) * 0.08, 0.05 + r.nextDouble() * 0.08, Math.sin(ang) * 0.08, r.nextInt(3) == 0 ? SMOKE : ASH,
                        6f + r.nextFloat() * 6f, 120 + r.nextInt(60));
            }
            for (int i = 0, n = Vfx.count(4 * size * fade); i < n; i++) {
                Vfx.mote(base.x, base.y + r.nextDouble() * h * 0.5, base.z, (r.nextDouble() - 0.5) * 0.9, 0.3 + r.nextDouble() * 0.6,
                        (r.nextDouble() - 0.5) * 0.9, RAD, 0.35f + r.nextFloat() * 0.3f, 50);
            }
            if (--boltLife <= 0 && r.nextInt(6) == 0 && age > 12) {   // petir ion di dalam awan
                boltLife = 3;
                double x = base.x + (r.nextDouble() - 0.5) * 20 * size, y = base.y + h * (0.6 + r.nextDouble() * 0.35);
                double z = base.z + (r.nextDouble() - 0.5) * 20 * size;
                for (int i = 0; i < 6; i++) {
                    bolt[i * 3] = x;
                    bolt[i * 3 + 1] = y;
                    bolt[i * 3 + 2] = z;
                    x += (r.nextDouble() - 0.5) * 7;
                    y -= 1.5 + r.nextDouble() * 3;
                    z += (r.nextDouble() - 0.5) * 7;
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float a = (1f - p) * (1f - p);
            double h = height(d.partialTick);
            d.beam(base.x, base.y, base.z, base.x, base.y + h * 0.7, base.z, 4.5f * size, RAD, HOT, a, a * 0.15f);
            d.glow(base.x, base.y + 2, base.z, 14f * size, RAD, 0.7f * a);
            d.flare(base.x, base.y + 1, base.z, 6f * size, HOT, 0.6f * a);
            if (boltLife > 0) {
                for (int i = 0; i < 5; i++) {
                    d.beam(bolt[i * 3], bolt[i * 3 + 1], bolt[i * 3 + 2], bolt[i * 3 + 3], bolt[i * 3 + 4], bolt[i * 3 + 5], 0.5f, BOLT,
                            0xFFFFFF, 0.9f, 0.9f);
                }
            }
        }

        @Override
        public void shade(float pt) {
            float a = 1f - progress(pt);
            ShazamShaders.light(base.x, base.y + 8, base.z, 24.0 * size, 0.9f * a);
            ShazamShaders.heat(base.x, base.y + 14, base.z, 18.0 * size, 0.5f * a);
        }
    }

    // ------------------------------------------------------------------ bongkahan uranium

    /** Bongkah uranium menyala yang melengkung dari kawah ke titik jatuhnya, tepat BOMB_FLIGHT tick (sama dengan server). */
    static final class Chunk extends Effect {
        private final Vec3 from, to;
        private final double arc;
        private final boolean harmless;

        Chunk(Vec3 from, Vec3 to, boolean harmless) {
            super(KalderaBody.BOMB_FLIGHT);
            this.from = from;
            this.to = to;
            this.harmless = harmless;
            this.arc = 16.0 + 0.35 * Math.sqrt((to.x - from.x) * (to.x - from.x) + (to.z - from.z) * (to.z - from.z));
        }

        private Vec3 at(float pt) {
            double u = Mth.clamp((age + pt) / (double) life, 0.0, 1.0);
            return new Vec3(Mth.lerp(u, from.x, to.x), Mth.lerp(u, from.y, to.y) + arc * 4.0 * u * (1.0 - u), Mth.lerp(u, from.z, to.z));
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            Vec3 p = at(0f);
            Vfx.smoke(p.x, p.y, p.z, 0, 0.02, 0, ASH, 1.6f + r.nextFloat(), 40 + r.nextInt(20));
            Vfx.spark(p.x, p.y, p.z, (r.nextDouble() - 0.5) * 0.2, (r.nextDouble() - 0.5) * 0.2, (r.nextDouble() - 0.5) * 0.2, RAD, 0.35f, 16,
                    Double.NaN);
            boolean alive = super.tick(level);
            if (!alive) {
                impact(level, to, harmless);
            }
            return alive;
        }

        @Override
        public void renderGlow(Draw d) {
            Vec3 p = at(d.partialTick);
            Vec3 q = at(Math.max(0f, d.partialTick - 1.5f));
            d.line(q.x, q.y, q.z, p.x, p.y, p.z, 0.6f, 1.6f, RAD, 0.2f, 0.8f);
            d.glow(p.x, p.y, p.z, 3.2f, RAD, 0.85f);
            d.flare(p.x, p.y, p.z, 1.3f, HOT, 0.9f);
        }

        @Override
        public void shade(float pt) {
            Vec3 p = at(pt);
            ShazamShaders.light(p.x, p.y, p.z, 5.0, 0.4f);
        }
    }

    private static void impact(ClientLevel level, Vec3 at, boolean harmless) {
        RandomSource r = level.random;
        Vfx.add(new Hd.Nova(at.add(0, 0.5, 0), 4.5, HOT, RAD, DEEP, SMOKE, 30, 0.85f, false));
        Vfx.add(new Fx.Flash(at.add(0, 1, 0), 7f, RAD, 7, 0.8f));
        Ground.Map m = map(level, at, Kaldera.ZONE_R + 1.0);
        if (m != null) {
            Vfx.add(new Ground.Cracks(at, m, 7, 5f, 120, 60, RAD, r.nextLong()));
            Vfx.add(new Ground.Debris(at, m, 14, 0.5, 0.6, 3.0, 40));
        }
        fallout(level, at, Kaldera.ZONE_R, Kaldera.ZONE_TICKS, m, harmless);
        for (int i = 0, n = Vfx.count(18); i < n; i++) {
            Vfx.spark(at.x, at.y + 0.5, at.z, (r.nextDouble() - 0.5) * 1.0, 0.3 + r.nextDouble() * 0.7, (r.nextDouble() - 0.5) * 1.0,
                    r.nextBoolean() ? RAD : HOT, 0.45f, 30, at.y);
        }
        for (int i = 0; i < 3; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0;
            Vfx.add(new Glob(at.add(0, 0.6, 0), new Vec3(Math.cos(ang) * 0.35, 0.45 + r.nextDouble() * 0.3, Math.sin(ang) * 0.35),
                    0.6f + r.nextFloat() * 0.5f, at.y));
        }
        ShazamFx.shakeAround(at, 0.6f, 40.0);
    }

    /** Gumpalan cairan radioaktif yang terlempar, jatuh melengkung, lalu memercik di tanah. */
    static final class Glob extends Effect {
        private double x, y, z, ox, oy, oz, vx, vy, vz;
        private final float size;
        private final double floor;

        Glob(Vec3 p, Vec3 v, float size, double floor) {
            super(70);
            x = ox = p.x;
            y = oy = p.y;
            z = oz = p.z;
            vx = v.x;
            vy = v.y;
            vz = v.z;
            this.size = size;
            this.floor = floor;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (!super.tick(level)) {
                return false;
            }
            ox = x;
            oy = y;
            oz = z;
            vy -= 0.045;
            vx *= 0.985;
            vz *= 0.985;
            x += vx;
            y += vy;
            z += vz;
            RandomSource r = level.random;
            if (r.nextInt(2) == 0) {
                Vfx.mote(x, y, z, 0, 0.02, 0, RAD, size * 0.35f, 18);
            }
            if (vy < 0 && y <= floor + 0.1) {   // memercik
                for (int i = 0, n = Vfx.count(6); i < n; i++) {
                    Vfx.spark(x, floor + 0.2, z, (r.nextDouble() - 0.5) * 0.4, 0.15 + r.nextDouble() * 0.25, (r.nextDouble() - 0.5) * 0.4,
                            RAD, 0.3f, 18, floor);
                }
                Vfx.glint(x, floor + 0.3, z, HOT, size * 1.2f, 10);
                return false;
            }
            return true;
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            double px = Mth.lerp(pt, ox, x), py = Mth.lerp(pt, oy, y), pz = Mth.lerp(pt, oz, z);
            d.line(ox, oy, oz, px, py, pz, size * 0.2f, size * 0.55f, RAD, 0.1f, 0.7f);
            d.glow(px, py, pz, size * 1.4f, RAD, 0.75f);
            d.glow(px, py, pz, size * 0.5f, HOT, 0.9f);
        }
    }

    // ------------------------------------------------------------------ zona radiasi

    private static void fallout(ClientLevel level, Vec3 at, double radius, int life, Ground.Map map, boolean harmless) {
        Fallout f = new Fallout(at, radius, life, map, level.getGameTime() + life + 2, harmless);
        FALLOUT.add(f);
        Vfx.add(f);
    }

    /**
     * Zona radiasi di tanah (sama jari-jari & lamanya dengan zona di server): noda gelap teradiasi, genangan cahaya hijau
     * yang berdenyut, butiran & uap tipis yang naik, lalu memudar.
     */
    static final class Fallout extends Effect {
        private final Vec3 at;
        private final double radius;
        private final Ground.Map map;
        final long end;
        final boolean harmless;   // zona KALDERA jinak: cuma menyakiti musuh, jadi geiger-mu diam
        boolean done;

        Fallout(Vec3 at, double radius, int life, Ground.Map map, long end, boolean harmless) {
            super(life);
            this.at = at;
            this.radius = radius;
            this.map = map;
            this.end = end;
            this.harmless = harmless;
        }

        boolean contains(Vec3 p) {
            double dx = p.x - at.x, dz = p.z - at.z;
            return !done && dx * dx + dz * dz <= radius * radius && p.y > at.y - 1.5 && p.y < at.y + 3.5;
        }

        private float fade(float pt) {
            float t = time(pt);
            return Math.min(1f, t / 6f) * Math.min(1f, (life - t) / 30f);
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            if (viewerDistance(at) < 90.0) {
                for (int i = 0, n = Vfx.count(radius * 0.4 * fade(0f)); i < n; i++) {
                    double ang = r.nextDouble() * Math.PI * 2.0, rr = Math.sqrt(r.nextDouble()) * radius;
                    double gy = map != null ? at.y + map.at(ang, rr) : at.y;
                    Vfx.mote(at.x + Math.cos(ang) * rr, gy + 0.2, at.z + Math.sin(ang) * rr, 0, 0.02 + r.nextDouble() * 0.03, 0, RAD,
                            0.25f + r.nextFloat() * 0.2f, 30 + r.nextInt(20));
                }
                if (age % 6 == 0) {
                    double ang = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * radius * 0.8;
                    Vfx.smoke(at.x + Math.cos(ang) * rr, at.y + 0.3, at.z + Math.sin(ang) * rr, 0, 0.03, 0, VAPOR, 1.2f + r.nextFloat(), 40);
                }
            }
            boolean alive = super.tick(level);
            done = !alive;
            return alive;
        }

        @Override
        public void renderSoft(Draw d) {
            d.disc(at.x, at.y + 0.05, at.z, 0, 1, 0, radius * 0.9, 0x0C140A, 0.55f * fade(d.partialTick), 0f, map);
        }

        @Override
        public void renderGlow(Draw d) {
            float f = fade(d.partialTick);
            float beat = 0.75f + 0.25f * Mth.sin((age + d.partialTick) * 0.35f);
            d.disc(at.x, at.y + 0.08, at.z, 0, 1, 0, radius, RAD, 0.42f * f * beat, 0.05f * f, map);
            d.ring(at.x, at.y + 0.1, at.z, 0, 1, 0, radius, 0.5, HOT, 0.3f * f * beat, 0f, map);
        }
    }

    // ------------------------------------------------------------------ ventilasi radiasi

    /** Tanah merekah & menyala hijau selama GEYSER_DELAY tick, lalu menyemburkan uap radioaktif. */
    static final class Fissure extends Effect {
        private final Vec3 at;
        private final Ground.Map map;
        private final boolean harmless;

        Fissure(ClientLevel level, Vec3 at, boolean harmless) {
            super(KalderaBody.GEYSER_DELAY);
            this.at = at;
            this.harmless = harmless;
            this.map = map(level, at, 5.0);
            if (map != null) {
                Vfx.add(new Ground.Cracks(at, map, 8, 4.5f, KalderaBody.GEYSER_DELAY + 120, KalderaBody.GEYSER_DELAY + 50, RAD,
                        level.random.nextLong()));
            }
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            float p = progress(0f);
            if (age % 2 == 0) {
                Vfx.smoke(at.x + (r.nextDouble() - 0.5) * 4, at.y + 0.3, at.z + (r.nextDouble() - 0.5) * 4, 0, 0.06 + 0.1 * p, 0, VAPOR,
                        1.2f + 1.6f * p, 30);
            }
            if (r.nextFloat() < p) {
                Vfx.spark(at.x + (r.nextDouble() - 0.5) * 3, at.y + 0.2, at.z + (r.nextDouble() - 0.5) * 3, 0, 0.3 + r.nextDouble() * 0.3, 0,
                        RAD, 0.3f, 18, Double.NaN);
            }
            boolean alive = super.tick(level);
            if (!alive) {
                Vfx.add(new Vent(at, map));
                fallout(level, at, Kaldera.VENT_ZONE_R, Kaldera.VENT_ZONE_TICKS, map, harmless);
                Vfx.add(new Hd.Nova(at.add(0, 0.5, 0), 3.5, HOT, RAD, DEEP, SMOKE, 24, 0.7f, true));
                Vfx.add(new Fx.Flash(at.add(0, 2, 0), 8f, RAD, 8, 0.7f));
                ShazamFx.shakeAround(at, 0.5f, 36.0);
            }
            return alive;
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            d.disc(at.x, at.y + 0.08, at.z, 0, 1, 0, 3.4, RAD, 0.15f + 0.65f * p * p, 0f, map);
        }
    }

    /** Semburan uap radioaktif: tiang cahaya hijau, lidah cahaya, gumpalan yang terlempar, uap pucat di puncaknya. */
    static final class Vent extends Effect {
        private final Vec3 at;
        private final Ground.Map map;

        Vent(Vec3 at, Ground.Map map) {
            super(44);
            this.at = at;
            this.map = map;
        }

        private double height(float pt) {
            float t = time(pt);
            return Kaldera.GEYSER_H * Math.min(1.0, t / 4.0) * (1.0 - Math.max(0.0, (t - 24.0) / 20.0));
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            double h = height(0f);
            for (int i = 0, n = Vfx.count(6); i < n; i++) {
                Vfx.flame(at.x + (r.nextDouble() - 0.5) * 2.4, at.y + r.nextDouble() * h, at.z + (r.nextDouble() - 0.5) * 2.4,
                        (r.nextDouble() - 0.5) * 0.1, 0.4 + r.nextDouble() * 0.4, (r.nextDouble() - 0.5) * 0.1, r.nextBoolean() ? RAD : HOT,
                        1.6f + r.nextFloat() * 1.2f, 18);
            }
            if (age < 20 && age % 3 == 0) {
                double ang = r.nextDouble() * Math.PI * 2.0;
                Vfx.add(new Glob(at.add(0, h * 0.8, 0), new Vec3(Math.cos(ang) * 0.3, 0.2 + r.nextDouble() * 0.3, Math.sin(ang) * 0.3),
                        0.6f + r.nextFloat() * 0.6f, at.y));
            }
            if (age % 3 == 0) {
                Vfx.smoke(at.x, at.y + h, at.z, (r.nextDouble() - 0.5) * 0.1, 0.12, (r.nextDouble() - 0.5) * 0.1, VAPOR, 2.5f + r.nextFloat() * 2f, 50);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float p = progress(d.partialTick);
            float a = 1f - p * p;
            double h = height(d.partialTick);
            d.beam(at.x, at.y, at.z, at.x, at.y + h, at.z, 2.6f, RAD, HOT, a, a * 0.4f);
            d.glow(at.x, at.y + 1, at.z, 5f, RAD, 0.8f * a);
            d.disc(at.x, at.y + 0.1, at.z, 0, 1, 0, 3.6, RAD, 0.8f * a, 0.1f * a, map);
        }

        @Override
        public void shade(float pt) {
            float a = 1f - progress(pt);
            ShazamShaders.light(at.x, at.y + height(pt) * 0.5, at.z, 8.0, 0.5f * a);
        }
    }

    // ------------------------------------------------------------------ gunung runtuh, kritis, inti terbuka

    private static void fall(Kaldera k, Vec3 c) {
        ShazamFx.schedule(0, KalderaBody.FALL_HIT + 1, (level, t) -> {
            if (t == KalderaBody.FALL_HIT - 8) {
                ShazamFx.shakeAround(c, 0.5f, 120.0);
            }
            if (t == KalderaBody.FALL_HIT) {
                RandomSource r = level.random;
                Ground.Map m = map(level, c, Kaldera.FALL_WAVE_RADIUS);
                Vfx.add(new Quake(c, m, Kaldera.FALL_WAVE_RADIUS, 1.4, 1.3f));
                if (m != null) {
                    Vfx.add(new Ground.Cracks(c, m, 26, 34f, 240, 90, RAD, r.nextLong()));
                    Vfx.add(new Ground.Debris(c, m, 64, 1.1, 1.2, 18.0, 70));
                }
                ShazamFx.smokeCloud(level, c, DUST, 40, 24.0);
                Vfx.add(new Fx.Flash(c.add(0, 2, 0), 26f, 0xC8FF90, 10, 0.7f));
                ShazamFx.shakeAround(c, 2.2f, 170.0);
                if (viewerDistance(c) < 60.0) {
                    ScreenFx.vignette(0.35f, 0x0C2A06, 30);
                    FovKick.kick(0.08f);
                }
            }
        });
    }

    private static void rage(Kaldera k, Vec3 top) {
        ShazamFx.schedule(0, KalderaBody.RAGE_BURST + 1, (level, t) -> {
            if (t == 0 && viewerDistance(top) < 160.0) {
                ScreenFx.vignette(0.45f, 0x2E4A00, 60);
            }
            if (t == KalderaBody.ROAR_HIT) {
                roar(level, k, 1.25f);
            }
            if (t == KalderaBody.RAGE_BURST) {   // intinya menjadi kritis
                Vfx.add(new Plume(top, 1.4f, 140));
                Vfx.add(new Pulse(top, Kaldera.PULSE_R * 1.2 + 18.0, 1.3f, k.isTamed()));
                Vfx.add(new Fx.Flash(top.add(0, 3, 0), 34f, HOT, 14, 1f));
                Vfx.add(new Hd.Nova(top.add(0, 2, 0), 18.0, HOT, RAD, DEEP, SMOKE, 44, 1f, false));
                Vec3 c = k.position();
                Vfx.add(new Quake(c, map(level, c, 36.0), 36.0, 1.3, 1f));
                ShazamFx.shakeAround(top, 1.8f, 180.0);
                if (viewerDistance(top) < 90.0) {
                    ScreenFlash.flash(0.35f, RAD);
                }
            }
        });
    }

    private static void exposed(ClientLevel level, Vec3 top) {
        RandomSource r = level.random;
        Vfx.add(new Fx.Flash(top.add(0, 2, 0), 16f, HOT, 12, 0.8f));
        Vfx.add(new Fx.Wave(top.add(0, 1, 0), UP, 14.0, 1.8, HOT, 20, 0.7f, 0.2f, null));
        for (int i = 0, n = Vfx.count(30); i < n; i++) {
            Vfx.spark(top.x, top.y + 1, top.z, (r.nextDouble() - 0.5) * 1.4, 0.5 + r.nextDouble() * 0.8, (r.nextDouble() - 0.5) * 1.4,
                    r.nextBoolean() ? HOT : RAD, 0.5f, 34, Double.NaN);
        }
    }

    // ------------------------------------------------------------------ 0.74 diberi Batu Cryon & jinak

    /** Batu Cryon diserap: butiran hijau mengalir dari tangan pemberinya ke inti di kawah, kawahnya berkedip terang. */
    private static void feed(ClientLevel level, Kaldera k, Vec3 from) {
        Vec3 top = caldera(k, 0f);
        Vfx.add(new Stream(from, top));
        Vfx.add(new Fx.Flash(top.add(0, 2, 0), 12f, HOT, 10, 0.7f));
        RandomSource r = level.random;
        for (int i = 0, n = Vfx.count(16); i < n; i++) {
            Vfx.spark(top.x, top.y + 1, top.z, (r.nextDouble() - 0.5) * 0.8, 0.3 + r.nextDouble() * 0.5, (r.nextDouble() - 0.5) * 0.8,
                    r.nextBoolean() ? HOT : RAD, 0.4f, 26, Double.NaN);
        }
    }

    /** Arus butiran hijau dari a ke b (melengkung ke atas), lalu meredup di b. */
    static final class Stream extends Effect {
        private final Vec3 a, b;

        Stream(Vec3 a, Vec3 b) {
            super(24);
            this.a = a;
            this.b = b;
        }

        private Vec3 at(double u) {
            double lift = 6.0 + 0.15 * a.distanceTo(b);
            return new Vec3(Mth.lerp(u, a.x, b.x), Mth.lerp(u, a.y, b.y) + lift * 4.0 * u * (1.0 - u), Mth.lerp(u, a.z, b.z));
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            for (int i = 0, n = Vfx.count(6); i < n; i++) {
                double u = Mth.clamp((age + r.nextDouble() * 3.0) / life, 0.0, 1.0);
                Vec3 p = at(u);
                Vfx.mote(p.x + (r.nextDouble() - 0.5) * 0.6, p.y + (r.nextDouble() - 0.5) * 0.6, p.z + (r.nextDouble() - 0.5) * 0.6, 0, 0.01, 0,
                        r.nextInt(3) == 0 ? HOT : RAD, 0.35f + r.nextFloat() * 0.25f, 14);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            double u = Mth.clamp((age + d.partialTick) / life, 0.0, 1.0);
            Vec3 p = at(u), q = at(Math.max(0.0, u - 0.12));
            d.line(q.x, q.y, q.z, p.x, p.y, p.z, 0.2f, 0.7f, RAD, 0.1f, 0.8f);
            d.glow(p.x, p.y, p.z, 1.6f, HOT, 0.9f);
        }
    }

    /** Intinya tunduk: denyut cahaya hijau yang lembut (nggak menyakiti), lingkaran cahaya di kakinya, & butiran naik. */
    private static void tame(ClientLevel level, Kaldera k, Vec3 top) {
        Vfx.add(new Pulse(top, 60.0, 0.8f, true));
        Vfx.add(new Fx.Flash(top.add(0, 3, 0), 30f, HOT, 16, 0.8f));
        Vec3 c = k.position();
        Ground.Map m = map(level, c, 40.0);
        Vfx.add(new Fx.Wave(c.add(0, 0.3, 0), UP, 40.0, 3.0, RAD, 40, 0.7f, 0.12f, m, true));
        ShazamFx.schedule(0, 60, (lvl, t) -> {
            RandomSource r = lvl.random;
            for (int i = 0, n = Vfx.count(6); i < n; i++) {
                double ang = r.nextDouble() * Math.PI * 2.0, rr = 10.0 + r.nextDouble() * 28.0;
                Vfx.mote(c.x + Math.cos(ang) * rr, c.y + 0.5 + r.nextDouble() * 4.0, c.z + Math.sin(ang) * rr, 0, 0.08 + r.nextDouble() * 0.1, 0,
                        r.nextInt(3) == 0 ? HOT : RAD, 0.4f + r.nextFloat() * 0.3f, 50 + r.nextInt(30));
            }
            if (t == 0 && viewerDistance(top) < 120.0) {
                ScreenFx.vignette(0.2f, 0x2E9A12, 40);
            }
        });
    }

    // ------------------------------------------------------------------ 0.75 penjara kristal

    private static final int FACET_DARK = 0x174D0A, FACET_MID = 0x2E9A12, FACET_LIT = 0x5ED62A;
    private static final double[] PRISM_BASE = new double[18], PRISM_TOP = new double[18];   // cuma dipakai di thread gambar

    /**
     * Kristal uranium segi enam dari pangkal (bx, by, bz) sepanjang sumbu satuan (ax, ay, az): panjang len, lebar w.
     * glow = false: sisi-sisinya (lapisan soft, hijau gelap tembus pandang); true: rusuk, inti, & ujung yang berpendar.
     */
    static void prism(Draw d, boolean glow, double bx, double by, double bz, double ax, double ay, double az, double len, double w,
                      float a) {
        if (a <= 0.01f || len <= 0.05) {
            return;
        }
        double hx = Math.abs(ay) < 0.9 ? 0 : 1, hy = 1 - hx;   // sumbu bantu (atas, atau x kalau kristalnya tegak)
        double e1x = -az * hy, e1y = az * hx, e1z = ax * hy - ay * hx;   // e1 = sumbu x silang sumbu bantu
        double l1 = Math.sqrt(e1x * e1x + e1y * e1y + e1z * e1z);
        e1x /= l1;
        e1y /= l1;
        e1z /= l1;
        double e2x = ay * e1z - az * e1y, e2y = az * e1x - ax * e1z, e2z = ax * e1y - ay * e1x;
        double sx = bx + ax * len * 0.72, sy = by + ay * len * 0.72, sz = bz + az * len * 0.72;   // bahu
        double tx = bx + ax * len, ty = by + ay * len, tz = bz + az * len;                        // ujung
        double[] base = PRISM_BASE, top = PRISM_TOP;
        for (int k = 0; k < 6; k++) {
            double ang = k * Math.PI / 3.0 + 0.26;
            double c = Math.cos(ang), sn = Math.sin(ang);
            base[k * 3] = bx + (e1x * c + e2x * sn) * w;
            base[k * 3 + 1] = by + (e1y * c + e2y * sn) * w;
            base[k * 3 + 2] = bz + (e1z * c + e2z * sn) * w;
            top[k * 3] = sx + (e1x * c + e2x * sn) * w * 0.88;
            top[k * 3 + 1] = sy + (e1y * c + e2y * sn) * w * 0.88;
            top[k * 3 + 2] = sz + (e1z * c + e2z * sn) * w * 0.88;
        }
        float ew = (float) Math.max(0.035, w * 0.13);
        for (int k = 0; k < 6; k++) {
            int i = k * 3, j = ((k + 1) % 6) * 3;
            if (glow) {
                d.line(base[i], base[i + 1], base[i + 2], top[i], top[i + 1], top[i + 2], ew, ew, RAD, 0.3f * a, 0.6f * a);
                d.line(top[i], top[i + 1], top[i + 2], tx, ty, tz, ew, ew * 0.6f, HOT, 0.65f * a, 0.8f * a);
            } else {
                d.quad(base[i], base[i + 1], base[i + 2], base[j], base[j + 1], base[j + 2], top[j], top[j + 1], top[j + 2],
                        top[i], top[i + 1], top[i + 2], k % 2 == 0 ? FACET_DARK : FACET_MID, 0.8f * a, 0.8f * a, 0.62f * a, 0.62f * a);
                d.quad(top[i], top[i + 1], top[i + 2], top[j], top[j + 1], top[j + 2], tx, ty, tz, tx, ty, tz,
                        k % 2 == 0 ? FACET_MID : FACET_LIT, 0.66f * a, 0.66f * a, 0.5f * a, 0.5f * a);
            }
        }
        if (glow) {   // inti yang berpendar di dalamnya & kilau di ujungnya
            d.line(bx, by, bz, bx + ax * len * 0.8, by + ay * len * 0.8, bz + az * len * 0.8, (float) (w * 1.1), (float) (w * 0.5),
                    RAD, 0.22f * a, 0.12f * a);
            d.flare(tx, ty, tz, (float) Math.max(0.35, w * 1.1), HOT, 0.5f * a);
        }
    }

    /** Telapak kiri depan (yang menghentak) di tanah, menurut irama langkahnya. */
    private static Vec3 leftFoot(ClientLevel level, Kaldera k) {
        KalderaBody.gaitFoot(KalderaBody.FL, k.strideC, TMP);
        Vec3 f = local(k, 0f, TMP[0], 0f, TMP[1]);
        double g = KalderaBody.ground(level, f.x, f.z);
        return new Vec3(f.x, Double.isNaN(g) ? f.y : g, f.z);
    }

    /** Kaki kiri depan terangkat (kerikil & butiran hijau menghimpun di telapaknya), lalu menghentak di PRISON_SLAM. */
    private static void prison(Kaldera k, Vec3 f) {
        ShazamFx.schedule(0, KalderaBody.PRISON_SLAM + 1, (level, t) -> {
            RandomSource r = level.random;
            if (t < KalderaBody.PRISON_SLAM && t % 2 == 0) {
                KalderaBody.Pose p = pose(k, 0f);
                KalderaBody.body(p, p.foot[0], p.foot[1], p.foot[2], TMP);
                Vec3 ft = local(k, 0f, TMP[0], TMP[1], TMP[2]);
                Vfx.shard(ft.x + (r.nextDouble() - 0.5) * 6, ft.y, ft.z + (r.nextDouble() - 0.5) * 6, 0, -0.1, 0, DUST, 0.5f, 50, f.y);
                double ang = r.nextDouble() * Math.PI * 2.0, rr = 5.0 + r.nextDouble() * 6.0;
                Vfx.mote(ft.x + Math.cos(ang) * rr, ft.y - 2.0 + r.nextDouble() * 4.0, ft.z + Math.sin(ang) * rr, -Math.cos(ang) * 0.2,
                        0.02, -Math.sin(ang) * 0.2, r.nextBoolean() ? HOT : RAD, 0.35f + r.nextFloat() * 0.25f, 22);
            }
            if (t == KalderaBody.PRISON_SLAM) {
                footfall(level, f, 1.3f);
                Vfx.add(new Fx.Flash(f.add(0, 1, 0), 12f, HOT, 8, 0.6f));
                Ground.Map m = map(level, f, 12.0);
                if (m != null) {
                    Vfx.add(new Ground.Cracks(f, m, 12, 9f, 140, 70, RAD, r.nextLong()));
                }
                Vfx.add(new Fx.Wave(f.add(0, 0.3, 0), UP, 12.0, 1.6, RAD, 18, 0.6f, 0.1f, m, true));
            }
        });
    }

    /**
     * Satu deret: retakan hijau merambat di tanah PRISON_SPEED blok per tick, duri-duri kristal menyeruak di belakangnya
     * (jarak & waktunya sama dengan server, lihat Kaldera.prisonLine), bertahan sebentar, lalu luruh ke tanah.
     */
    static final class SpikeLine extends Effect {
        private static final int GROW = 3, HOLD = 16, FADE = 8;
        private final double[] x, y, z, ax, ay, az, len, wid;
        private final int[] born;
        private final double fx, fy, fz, ux, uz, total;
        private final int count;

        SpikeLine(ClientLevel level, Vec3 from, Vec3 end) {
            super(lifeOf(from, end));
            RandomSource r = level.random;
            fx = from.x;
            fy = from.y;
            fz = from.z;
            double dx = end.x - from.x, dz = end.z - from.z;
            total = Math.max(1.0, Math.sqrt(dx * dx + dz * dz));
            ux = dx / total;
            uz = dz / total;
            int n = 0;
            for (double d = Kaldera.SPIKE_START; d < total - Kaldera.CAGE_R; d += Kaldera.SPIKE_GAP) {
                n++;
            }
            count = n * 2;   // tiap titik: satu duri besar + satu kecil di sampingnya
            x = new double[count];
            y = new double[count];
            z = new double[count];
            ax = new double[count];
            ay = new double[count];
            az = new double[count];
            len = new double[count];
            wid = new double[count];
            born = new int[count];
            for (int i = 0; i < count; i++) {
                boolean big = i % 2 == 0;
                double d = Kaldera.SPIKE_START + (i / 2) * Kaldera.SPIKE_GAP + (big ? 0.0 : (r.nextDouble() - 0.5) * 1.2);
                double side = (r.nextDouble() - 0.5) * (big ? 1.2 : 2.6);
                double px = fx + ux * d - uz * side, pz = fz + uz * d + ux * side;
                double g = KalderaBody.ground(level, px, pz);
                x[i] = px;
                y[i] = (Double.isNaN(g) ? Mth.lerp(d / total, from.y, end.y) : g) - 0.3;
                z[i] = pz;
                double lean = big ? 0.25 + r.nextDouble() * 0.25 : 0.5 + r.nextDouble() * 0.4;   // condong ke depan & ke samping
                double sl = (r.nextDouble() - 0.5) * 0.6 + (big ? 0.0 : Math.signum(side) * 0.4);
                double vx = ux * lean - uz * sl, vz = uz * lean + ux * sl, vl = Math.sqrt(vx * vx + 1.0 + vz * vz);
                ax[i] = vx / vl;
                ay[i] = 1.0 / vl;
                az[i] = vz / vl;
                len[i] = big ? 2.2 + r.nextDouble() * 1.6 : 0.9 + r.nextDouble() * 0.8;
                wid[i] = big ? 0.42 + r.nextDouble() * 0.16 : 0.22 + r.nextDouble() * 0.1;
                born[i] = (int) Math.ceil(d / Kaldera.PRISON_SPEED) + (big ? 0 : 1);
            }
        }

        private static int lifeOf(Vec3 from, Vec3 end) {
            double dx = end.x - from.x, dz = end.z - from.z;
            return (int) Math.ceil(Math.sqrt(dx * dx + dz * dz) / Kaldera.PRISON_SPEED) + GROW + HOLD + FADE + 4;
        }

        /** Besar duri ke-i pada waktu t (0 = belum / sudah luruh). */
        private float size(int i, float t) {
            float u = t - born[i];
            if (u <= 0f) {
                return 0f;
            }
            float g = Math.min(1f, u / GROW);
            float s = 1f - (1f - g) * (1f - g) * (1f - g);
            s *= 1f + 0.18f * Mth.sin((float) Math.PI * g);   // menyeruak sedikit melewati ukurannya
            float k = (u - GROW - HOLD) / FADE;
            return k > 0f ? s * Math.max(0f, 1f - k) : s;
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            double front = Math.min(total, age * Kaldera.PRISON_SPEED);
            if (front < total) {   // ujung retakan yang merambat: percikan & debu
                double px = fx + ux * front, pz = fz + uz * front, g = KalderaBody.ground(level, px, pz);
                double py = Double.isNaN(g) ? fy : g;
                for (int i = 0, n = Vfx.count(3); i < n; i++) {
                    Vfx.spark(px + (r.nextDouble() - 0.5), py + 0.2, pz + (r.nextDouble() - 0.5), (r.nextDouble() - 0.5) * 0.2,
                            0.2 + r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.2, r.nextBoolean() ? HOT : RAD, 0.3f, 14, Double.NaN);
                }
                Vfx.dust(px, py + 0.3, pz, (r.nextDouble() - 0.5) * 0.1, 0.06, (r.nextDouble() - 0.5) * 0.1, DUST, 1.1f, 24);
            }
            for (int i = 0; i < count; i += 2) {
                if (born[i] == age) {   // menyeruak: tanah terlempar
                    for (int k = 0, n = Vfx.count(4); k < n; k++) {
                        Vfx.shard(x[i], y[i] + 0.4, z[i], (r.nextDouble() - 0.5) * 0.35, 0.25 + r.nextDouble() * 0.3,
                                (r.nextDouble() - 0.5) * 0.35, DUST, 0.3f + r.nextFloat() * 0.3f, 40, y[i]);
                    }
                    Vfx.dust(x[i], y[i] + 0.4, z[i], 0, 0.05, 0, DUST, 1.4f, 26);
                    if (viewerDistance(new Vec3(x[i], y[i], z[i])) < 16.0) {
                        CameraShake.add(0.06f);
                    }
                }
                if (born[i] + GROW + HOLD == age) {   // luruh jadi serpih hijau
                    for (int k = 0, n = Vfx.count(3); k < n; k++) {
                        Vfx.shard(x[i], y[i] + len[i] * 0.5, z[i], (r.nextDouble() - 0.5) * 0.2, 0.1, (r.nextDouble() - 0.5) * 0.2,
                                FACET_LIT, 0.22f, 30, y[i]);
                    }
                }
            }
            return super.tick(level);
        }

        @Override
        public void renderSoft(Draw d) {
            float t = time(d.partialTick);
            for (int i = 0; i < count; i++) {
                float sz = size(i, t);
                if (sz > 0.01f) {
                    prism(d, false, x[i], y[i], z[i], ax[i], ay[i], az[i], len[i] * sz, wid[i] * Math.min(1f, 0.4f + sz), 1f);
                }
            }
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float fade = Math.min(1f, (life - t) / FADE);
            double front = Math.min(total, t * Kaldera.PRISON_SPEED);
            for (int i = 0; i < count; i++) {   // retakan menyala di sepanjang deretnya (sampai ujung yang merambat)
                if (i % 2 == 1 || i + 2 >= count) {
                    continue;
                }
                double d0 = Kaldera.SPIKE_START + (i / 2) * Kaldera.SPIKE_GAP;
                if (d0 > front) {
                    break;
                }
                d.flatLine(x[i], y[i] + 0.35, z[i], x[i + 2], y[i + 2] + 0.35, z[i + 2], 0, 1, 0, 0.7f, RAD, 0.5f * fade, 0.5f * fade);
            }
            if (front < total) {
                double px = fx + ux * front, pz = fz + uz * front;
                double py = count > 0 ? y[Math.min(count - 1, Math.max(0, (int) ((front - Kaldera.SPIKE_START) / Kaldera.SPIKE_GAP) * 2))] : fy;
                d.glow(px, py + 0.6, pz, 2.2f, HOT, 0.7f);
            }
            for (int i = 0; i < count; i++) {
                float sz = size(i, t);
                if (sz > 0.01f) {
                    prism(d, true, x[i], y[i], z[i], ax[i], ay[i], az[i], len[i] * sz, wid[i] * Math.min(1f, 0.4f + sz), Math.min(1f, sz));
                }
            }
        }
    }

    /**
     * Penjara Kristal menutup: sembilan kristal besar menyeruak melingkar & melengkung ke dalam sampai ujungnya hampir
     * bertemu, berdenyut selama PRISON_HOLD tick, lalu pecah berhamburan.
     */
    static final class Cage extends Effect {
        private static final int BARS = 9, OUTER = 7, BREAK = 10;
        private final Vec3 c;
        private final Ground.Map map;
        private final double[] bx, by, bz, ax, ay, az, len, wid;

        Cage(ClientLevel level, Vec3 c) {
            super(Kaldera.PRISON_HOLD + BREAK + 2);
            this.c = c;
            this.map = map(level, c, 6.0);
            RandomSource r = level.random;
            int n = BARS + OUTER;
            bx = new double[n];
            by = new double[n];
            bz = new double[n];
            ax = new double[n];
            ay = new double[n];
            az = new double[n];
            len = new double[n];
            wid = new double[n];
            double spin = r.nextDouble() * Math.PI * 2.0;
            for (int i = 0; i < n; i++) {
                boolean bar = i < BARS;
                double ang = spin + (bar ? i * Math.PI * 2.0 / BARS : (i - BARS + 0.5) * Math.PI * 2.0 / OUTER) + (r.nextDouble() - 0.5) * 0.2;
                double rad = bar ? Kaldera.CAGE_R + 0.3 : Kaldera.CAGE_R + 1.2 + r.nextDouble() * 0.8;
                double x = c.x + Math.cos(ang) * rad, z = c.z + Math.sin(ang) * rad;
                double g = KalderaBody.ground(level, x, z);
                bx[i] = x;
                by[i] = (Double.isNaN(g) ? c.y : g) - 0.4;
                bz[i] = z;
                double tx, ty, tz;
                if (bar) {   // melengkung ke dalam: ujungnya ke atas tengah penjara
                    tx = c.x + Math.cos(ang) * 0.45;
                    ty = c.y + 4.6 + r.nextDouble() * 0.6;
                    tz = c.z + Math.sin(ang) * 0.45;
                } else {     // kristal kecil di luar, condong keluar
                    tx = x + Math.cos(ang) * 1.2;
                    ty = by[i] + 1.6 + r.nextDouble() * 0.9;
                    tz = z + Math.sin(ang) * 1.2;
                }
                double vx = tx - x, vy = ty - by[i], vz = tz - z, vl = Math.sqrt(vx * vx + vy * vy + vz * vz);
                ax[i] = vx / vl;
                ay[i] = vy / vl;
                az[i] = vz / vl;
                len[i] = vl * (bar ? 0.96 : 1.0);
                wid[i] = bar ? 0.55 + r.nextDouble() * 0.15 : 0.3 + r.nextDouble() * 0.12;
            }
            Vfx.add(new Fx.Flash(c.add(0, 2, 0), 10f, HOT, 8, 0.8f));
            Vfx.add(new Fx.Wave(c.add(0, 0.3, 0), UP, 7.0, 1.4, RAD, 16, 0.7f, 0.15f, map, true));
            if (map != null) {
                Vfx.add(new Ground.Cracks(c, map, 10, 4.5f, Kaldera.PRISON_HOLD + 40, Kaldera.PRISON_HOLD, RAD, r.nextLong()));
            }
            ShazamFx.dustPuffs(level, c, DUST, 16, 4.0, 0.25);
            ShazamFx.shakeAround(c, 0.5f, 30.0);
        }

        private float grow(float t) {
            float g = Math.min(1f, t / 4f);
            return (1f - (1f - g) * (1f - g)) * (1f + 0.12f * Mth.sin((float) Math.PI * g));
        }

        private float broken(float t) {
            return Mth.clamp((t - Kaldera.PRISON_HOLD) / BREAK, 0f, 1f);
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource r = level.random;
            if (age < Kaldera.PRISON_HOLD && age % 3 == 0) {   // butiran radiasi naik di dalam penjaranya
                double ang = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * Kaldera.CAGE_R;
                Vfx.mote(c.x + Math.cos(ang) * rr, c.y + 0.3, c.z + Math.sin(ang) * rr, 0, 0.06 + r.nextDouble() * 0.05, 0,
                        r.nextInt(3) == 0 ? HOT : RAD, 0.3f + r.nextFloat() * 0.2f, 30);
            }
            if (age == Kaldera.PRISON_HOLD) {   // pecah berhamburan
                for (int i = 0; i < BARS; i++) {
                    for (int k = 0, n = Vfx.count(5); k < n; k++) {
                        double u = r.nextDouble();
                        double px = bx[i] + ax[i] * len[i] * u, py = by[i] + ay[i] * len[i] * u, pz = bz[i] + az[i] * len[i] * u;
                        Vfx.shard(px, py, pz, (px - c.x) * 0.12 + (r.nextDouble() - 0.5) * 0.2, 0.2 + r.nextDouble() * 0.3,
                                (pz - c.z) * 0.12 + (r.nextDouble() - 0.5) * 0.2, r.nextBoolean() ? FACET_LIT : FACET_MID,
                                0.25f + r.nextFloat() * 0.25f, 46, c.y);
                    }
                }
                for (int k = 0, n = Vfx.count(14); k < n; k++) {
                    Vfx.glint(c.x + (r.nextDouble() - 0.5) * 5, c.y + r.nextDouble() * 4.5, c.z + (r.nextDouble() - 0.5) * 5, HOT,
                            0.4f + r.nextFloat() * 0.3f, 14 + r.nextInt(8));
                }
                Vfx.add(new Hd.Nova(c.add(0, 1.5, 0), 4.0, HOT, RAD, DEEP, SMOKE, 20, 0.7f, true));
                Vfx.add(new Fx.Flash(c.add(0, 2, 0), 9f, RAD, 8, 0.7f));
                ShazamFx.shakeAround(c, 0.4f, 24.0);
            }
            return super.tick(level);
        }

        private void draw(Draw d, boolean glow) {
            float t = time(d.partialTick);
            float g = grow(t), b = broken(t);
            if (b >= 1f) {
                return;
            }
            float a = 1f - b;
            float pulse = 0.85f + 0.15f * Mth.sin(t * 0.5f);
            for (int i = 0; i < len.length; i++) {
                float sz = g * (i < BARS ? 1f - 0.35f * b : 1f - b);
                prism(d, glow, bx[i], by[i], bz[i], ax[i], ay[i], az[i], len[i] * sz, wid[i], glow ? a * pulse : a);
            }
            if (glow) {
                d.glow(c.x, c.y + 1.8, c.z, 3.6f, RAD, 0.3f * a * pulse);
                d.disc(c.x, c.y + 0.06, c.z, 0, 1, 0, Kaldera.CAGE_R + 0.8, RAD, 0.3f * a * pulse, 0f, map);
            }
        }

        @Override
        public void renderSoft(Draw d) {
            draw(d, false);
        }

        @Override
        public void renderGlow(Draw d) {
            draw(d, true);
        }

        @Override
        public void shade(float pt) {
            float a = 1f - broken(time(pt));
            ShazamShaders.light(c.x, c.y + 2.0, c.z, 7.0, 0.35f * a);
        }
    }

    // ------------------------------------------------------------------ 0.75 gempa peringatan

    /**
     * Satu paket gempa (2 dtk): layar bergetar makin kuat menjelang ia bangkit, debu & kerikil memercik di atas tempatnya,
     * kerikil melompat-lompat di sekitar kakimu, dan di paruh akhirnya tanah di atasnya merekah menyala hijau.
     */
    private static void quake(ClientLevel level, Kaldera k, Vec3 c) {
        float prog = Mth.clamp(k.actionTime(0f) / KalderaBody.RUMBLE_TICKS, 0f, 1f);
        if (prog > 0.45f) {
            Ground.Map m = map(level, c, 32.0);
            if (m != null) {
                Vfx.add(new Ground.Cracks(c, m, 6 + (int) (10 * prog), 10f + 18f * prog, 100, 60, RAD, level.random.nextLong()));
            }
        }
        ShazamFx.schedule(0, 40, (lvl, t) -> {
            RandomSource r = lvl.random;
            if (t % 3 == 0) {
                ShazamFx.shakeAround(c, 0.12f + 0.5f * prog, 190.0);
            }
            if (t % 4 == 0 && viewerDistance(c) < 220.0) {   // debu & kerikil memercik di atas tempatnya
                double ang = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * (8.0 + 22.0 * prog);
                double x = c.x + Math.cos(ang) * rr, z = c.z + Math.sin(ang) * rr, g = KalderaBody.ground(lvl, x, z);
                Vec3 p = new Vec3(x, Double.isNaN(g) ? c.y : g, z);
                ShazamFx.dustPuffs(lvl, p, DUST, 4 + (int) (8 * prog), 2.0 + 3.0 * prog, 0.18);
                for (int i = 0, n = Vfx.count(3 + 5 * prog); i < n; i++) {
                    Vfx.shard(p.x + (r.nextDouble() - 0.5) * 3, p.y + 0.3, p.z + (r.nextDouble() - 0.5) * 3, (r.nextDouble() - 0.5) * 0.2,
                            0.25 + r.nextDouble() * 0.3, (r.nextDouble() - 0.5) * 0.2, DUST, 0.3f + r.nextFloat() * 0.3f, 40, p.y);
                }
                if (prog > 0.5f && r.nextInt(3) == 0) {
                    Vfx.mote(p.x, p.y + 0.3, p.z, 0, 0.06, 0, RAD, 0.35f, 40);
                }
            }
            LocalPlayer me = Minecraft.getInstance().player;
            if (me != null && t % 5 == 0 && me.onGround()) {   // kerikil melompat-lompat di sekitar kakimu
                double dist = me.position().distanceTo(c);
                if (dist < 190.0) {
                    double near = 1.0 - dist / 190.0;
                    for (int i = 0, n = Vfx.count(2 + 4 * near + 2 * prog); i < n; i++) {
                        double ang = r.nextDouble() * Math.PI * 2.0, rr = 1.0 + r.nextDouble() * 5.0;
                        double x = me.getX() + Math.cos(ang) * rr, z = me.getZ() + Math.sin(ang) * rr, g = KalderaBody.ground(lvl, x, z);
                        if (!Double.isNaN(g)) {
                            Vfx.shard(x, g + 0.1, z, 0, 0.1 + r.nextDouble() * 0.15, 0, DUST, 0.16f + r.nextFloat() * 0.14f, 20, g);
                        }
                    }
                }
            }
        });
    }

    // ------------------------------------------------------------------ tumbang

    private static void death(Kaldera k, Vec3 c) {
        ShazamFx.schedule(0, KalderaBody.DEATH_TICKS, (level, t) -> {
            RandomSource r = level.random;
            if (t == 6) {
                roar(level, k, 0.6f);
            }
            if (t > 20 && t < KalderaBody.DEATH_STONE && t % 3 == 0) {   // batu-batu runtuh dari tubuhnya yang retak & padam
                Vec3 p = bodyPoint(k, 0f, (r.nextFloat() - 0.5f) * 32f, KalderaBody.BODY_Y + r.nextFloat() * 16f, (r.nextFloat() - 0.5f) * 48f);
                Vfx.shard(p.x, p.y, p.z, (r.nextDouble() - 0.5) * 0.3, 0.05, (r.nextDouble() - 0.5) * 0.3, DUST, 0.7f + r.nextFloat() * 0.8f, 80, c.y);
                Vfx.smoke(p.x, p.y, p.z, 0, 0.06, 0, VAPOR, 2.5f + r.nextFloat() * 2f, 60);
                if (r.nextInt(3) == 0) {   // sisa radiasi yang lepas
                    Vfx.mote(p.x, p.y, p.z, (r.nextDouble() - 0.5) * 0.08, 0.1 + r.nextDouble() * 0.1, (r.nextDouble() - 0.5) * 0.08, RAD,
                            0.4f, 50);
                }
            }
            if (t == KalderaBody.DEATH_COLLAPSE) {
                Ground.Map m = map(level, c, 34.0);
                Vfx.add(new Quake(c, m, 34.0, 1.1, 0.8f));
                ShazamFx.smokeCloud(level, c, DUST, 34, 22.0);
                ShazamFx.shakeAround(c, 1.6f, 150.0);
            }
            if (t == KalderaBody.DEATH_STONE) {   // membatu: kepulan debu besar menutupi gunungnya yang tumbuh
                ShazamFx.smokeCloud(level, c, DUST, 50, 28.0);
                ShazamFx.smokeCloud(level, c.add(0, 18, 0), 0x6E665E, 30, 22.0);
                ShazamFx.shakeAround(c, 1.2f, 150.0);
            }
            if (t > KalderaBody.DEATH_STONE && t % 4 == 0) {
                double ang = r.nextDouble() * Math.PI * 2.0, rr = r.nextDouble() * 24.0;
                ShazamFx.dustPuffs(level, new Vec3(c.x + Math.cos(ang) * rr, c.y + r.nextDouble() * 20.0, c.z + Math.sin(ang) * rr),
                        0x7A7066, 10, 4.0, 0.15);
            }
        });
    }

    // ------------------------------------------------------------------ pendar tubuh (bloom & sinar)

    /**
     * Pendar yang ikut tubuhnya selama ia ada: kolam inti di kawah, mata hijau, mulut saat terbuka. Digambar ke lapisan
     * cahaya, jadi ikut bloom Shader Shazam; kawahnya juga memberi sinar saat meletus, kritis, atau intinya terbuka.
     */
    static final class Aura extends Effect {
        private final Kaldera k;
        boolean gone;

        Aura(Kaldera k) {
            super(Integer.MAX_VALUE / 4);
            this.k = k;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (k.isRemoved() || !k.isAlive() || k.level() != level) {
                gone = true;
                return false;
            }
            return super.tick(level);
        }

        private float glow(float pt) {
            KalderaBody.Pose p = pose(k, pt);
            float beat = k.isRaging() ? 0.24f : 0.13f;
            return Math.max(0f, p.glow) * (0.9f + 0.1f * Mth.sin((k.tickCount + pt) * beat));
        }

        @Override
        public void renderGlow(Draw d) {
            float pt = d.partialTick;
            if (viewerDistance(k.position()) > 400.0 || k.action() == KalderaBody.Action.RUMBLE) {
                return;
            }
            float g = glow(pt);
            if (g <= 0.02f) {
                return;
            }
            float core = k.exposedTicks(pt) > 0f ? 1.5f + 0.5f * Mth.sin((k.tickCount + pt) * 0.6f) : 1f;
            Vec3 top = caldera(k, pt);
            d.glow(top.x, top.y + 1.0, top.z, 9f + 3f * g, RAD, Math.min(1f, 0.32f * g * core));
            d.flare(top.x, top.y + 0.6, top.z, 4f, HOT, Math.min(1f, 0.25f * g * core));
            KalderaBody.Pose p = pose(k, pt);
            float s = KalderaBody.HEAD_SCALE;
            for (int side = -1; side <= 1; side += 2) {   // tiga pasang mata hijau
                for (int e = 0; e < 3; e++) {
                    float z = 8f + e * 3.1f;
                    float half = Mth.lerp((z - 3.8f) / (17.6f - 3.8f), 7.9f, 4.6f) + 0.3f;
                    Vec3 eye = headPoint(k, pt, side * half * s, (-0.9f - e * 0.15f) * s, z * s);
                    d.glow(eye.x, eye.y, eye.z, 1.8f, HOT, Math.min(1f, 0.55f * g));
                }
            }
            if (p.jaw > 0.08f) {
                Vec3 mouth = headPoint(k, pt, 0f, -4.2f * s, 12f * s);
                d.glow(mouth.x, mouth.y, mouth.z, 3f + 7f * p.jaw, RAD, Math.min(1f, 1.3f * p.jaw * g));
            }
        }

        @Override
        public void shade(float pt) {
            if (viewerDistance(k.position()) > 300.0 || k.action() == KalderaBody.Action.RUMBLE) {
                return;
            }
            float g = glow(pt);
            Vec3 top = caldera(k, pt);
            ShazamShaders.heat(top.x, top.y + 7.0, top.z, 12.0, Math.min(1f, 0.3f * g));
            KalderaBody.Action a = k.action();
            float burst = 0f;
            if (a == KalderaBody.Action.ERUPT) {
                float t = k.actionTime(pt);
                burst = KalderaBody.smooth(0f, KalderaBody.ERUPT_FIRE, t) * (1f - KalderaBody.smooth(KalderaBody.ERUPT_FIRE + 20,
                        KalderaBody.ERUPT_TICKS, t));
            } else if (a == KalderaBody.Action.RAGE) {
                burst = 1f - KalderaBody.smooth(KalderaBody.RAGE_BURST + 20, KalderaBody.RAGE_TICKS, k.actionTime(pt));
            }
            if (k.exposedTicks(pt) > 0f) {
                burst = Math.max(burst, 0.6f);
            }
            if (burst > 0.02f) {
                ShazamShaders.light(top.x, top.y + 2.0, top.z, 16.0, 0.7f * burst);
            }
        }
    }
}
