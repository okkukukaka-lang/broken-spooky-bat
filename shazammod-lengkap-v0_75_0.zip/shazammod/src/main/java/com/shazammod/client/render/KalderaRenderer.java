package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shazammod.ShazamMod;
import com.shazammod.kaldera.Kaldera;
import com.shazammod.kaldera.KalderaBody;

import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * 0.73 Penggambar KALDERA (0.73.1 Titan Radiasi): tubuh dari KalderaModel (batu bijih uranium + kristal, dengan urat,
 * inti, & kilau kristal yang menyala hijau), dipose menurut aksinya (KalderaBody, sama dengan server), telapak menapak di
 * tanah sungguhan, kepala menoleh ke mangsanya. Lima lapisan digambar bergiliran (batu, kristal, urat, inti, kilau)
 * karena tiap lapisan punya RenderType sendiri: yang padat dulu, lalu cahaya-cahayanya.
 */
public class KalderaRenderer extends EntityRenderer<Kaldera> {
    public static final ResourceLocation ROCK = ShazamMod.id("textures/entity/kaldera/rock.png");
    public static final ResourceLocation VEINS = ShazamMod.id("textures/entity/kaldera/veins.png");
    public static final ResourceLocation CORE = ShazamMod.id("textures/entity/kaldera/core.png");
    public static final ResourceLocation CRYSTAL = ShazamMod.id("textures/entity/kaldera/crystal.png");
    public static final ResourceLocation SHINE = ShazamMod.id("textures/entity/kaldera/crystal_glow.png");
    private static final int ROCK_R = 246, ROCK_G = 252, ROCK_B = 244;

    private final KalderaBody.Pose pose = new KalderaBody.Pose();
    private final float[] gain = new float[KalderaModel.ZONES];
    private final float[] footGround = new float[4];

    public KalderaRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0f;
    }

    @Override
    public ResourceLocation getTextureLocation(Kaldera entity) {
        return ROCK;
    }

    @Override
    public void render(Kaldera k, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
        if (k.action() == KalderaBody.Action.RUMBLE) {
            return;   // 0.75 masih terkubur di perut bumi (gempa peringatan): jangan tampak menembus gua
        }
        float age = k.tickCount + partialTick;
        KalderaBody.pose(pose, k.action(), k.actionTime(partialTick), k.stride(partialTick), age, k.isRaging());
        pose.headYaw += k.lookYaw(partialTick);
        pose.headUp += k.lookUp(partialTick);

        // denyut radiasi: pelan & dalam, sesekali berkedip (kritis: lebih cepat)
        float beat = k.isRaging() ? 0.24f : 0.13f;
        float glow = Math.max(0f, pose.glow) * (0.9f + 0.1f * Mth.sin(age * beat) + 0.04f * Mth.sin(age * 0.71f));
        float core = k.exposedTicks(partialTick) > 0f ? 1.6f + 0.6f * Mth.sin(age * 0.6f) : 1f;
        gain[KalderaModel.Z_BODY] = 0.38f * glow;
        gain[KalderaModel.Z_CALDERA] = glow * core;
        gain[KalderaModel.Z_STREAM] = glow;
        gain[KalderaModel.Z_FACE] = Math.min(1.5f, glow * (1f + pose.jaw));
        gain[KalderaModel.Z_LEG] = 0.3f * glow;
        gain[KalderaModel.Z_JOINT] = 0.85f * glow;
        gain[KalderaModel.Z_CRYSTAL] = Math.min(1.4f, glow * (0.8f + 0.25f * (core - 1f)));
        float rock = 1f;
        if (k.action() == KalderaBody.Action.DEATH) {   // padam & memucat jadi batu kelabu
            rock = 1f + 0.25f * KalderaBody.smooth(KalderaBody.DEATH_COLLAPSE, KalderaBody.DEATH_STONE, k.actionTime(partialTick));
        }
        float flow = age * 0.012f;

        float yaw = Mth.rotLerp(partialTick, k.yRotO, k.getYRot());
        double ox = Mth.lerp(partialTick, k.xo, k.getX()), oy = Mth.lerp(partialTick, k.yo, k.getY());
        double oz = Mth.lerp(partialTick, k.zo, k.getZ());
        for (int i = 0; i < 4; i++) {   // tanah di bawah tiap telapak (dicari sekali per gambar)
            float fx = pose.foot[i * 3], fz = pose.foot[i * 3 + 2];
            double g = KalderaBody.ground(k.level(), KalderaBody.worldX(ox, yaw, fx, fz), KalderaBody.worldZ(oz, yaw, fx, fz));
            footGround[i] = Double.isNaN(g) ? 0f : (float) Mth.clamp(g - oy, -14.0, 14.0);
        }

        int sky = LightTexture.sky(LevelRenderer.getLightColor(k.level(), BlockPos.containing(ox, oy + KalderaBody.BODY_Y + 18.0, oz)));
        int block = Math.max(LightTexture.block(packedLight), glow > 0.3f ? 7 : 3);
        int light = LightTexture.pack(block, Math.max(sky, LightTexture.sky(packedLight)));
        int overlay = OverlayTexture.pack(OverlayTexture.u(0f), OverlayTexture.v(k.hurtTime > 0));

        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(-yaw));
        PoseStack.Pose last = poseStack.last();
        draw(buffers.getBuffer(RenderType.entityCutoutNoCull(ROCK)), last, KalderaModel.ROCK, rock, flow, light, overlay);
        draw(buffers.getBuffer(RenderType.entityCutoutNoCull(CRYSTAL)), last, KalderaModel.CRYSTAL, rock, flow, light, overlay);
        draw(buffers.getBuffer(RenderType.eyes(VEINS)), last, KalderaModel.VEIN, rock, flow, light, overlay);
        draw(buffers.getBuffer(RenderType.eyes(CORE)), last, KalderaModel.CORE, rock, flow, light, overlay);
        draw(buffers.getBuffer(RenderType.eyes(SHINE)), last, KalderaModel.SHINE, rock, flow, light, overlay);
        poseStack.popPose();
    }

    private void draw(VertexConsumer vc, PoseStack.Pose last, int layer, float rock, float flow, int light, int overlay) {
        KalderaModel.render(pose, gain, rock, flow, (leg, lx, lz) -> footGround[leg], layer,
                (l, x, y, z, u, v, nx, ny, nz, tint, zone) -> {
                    int r, g, b;
                    if (l == KalderaModel.ROCK || l == KalderaModel.CRYSTAL) {
                        float t = Math.min(1f, tint);
                        r = (int) (ROCK_R * t);
                        g = (int) (ROCK_G * t);
                        b = (int) (ROCK_B * t);
                    } else {
                        int c = (int) (255f * Mth.clamp(tint, 0f, 1f));
                        r = c;
                        g = c;
                        b = c;
                    }
                    vc.addVertex(last, x, y, z).setColor(r, g, b, 255).setUv(u, v).setOverlay(overlay).setLight(light)
                            .setNormal(last, nx, ny, nz);
                });
    }

}
