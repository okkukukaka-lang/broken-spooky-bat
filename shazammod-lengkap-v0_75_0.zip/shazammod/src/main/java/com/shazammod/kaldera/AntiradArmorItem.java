package com.shazammod.kaldera;

import java.util.List;

import com.shazammod.ShazamArmor;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;

/** 0.75 Satu bagian Zirah Antiradiasi: menahan 25% radiasi KALDERA; satu set penuh = kebal radiasinya (Kaldera.radShield). */
public class AntiradArmorItem extends ArmorItem {
    public AntiradArmorItem(ArmorItem.Type type) {
        super(ShazamArmor.ANTIRADIASI, type, new Item.Properties().durability(type.getDurability(25)).rarity(Rarity.UNCOMMON));
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.shazammod.antiradiasi.lore").withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.ITALIC));
        tooltip.add(Component.translatable("item.shazammod.antiradiasi.piece").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.shazammod.antiradiasi.set").withStyle(ChatFormatting.GREEN));
    }
}
