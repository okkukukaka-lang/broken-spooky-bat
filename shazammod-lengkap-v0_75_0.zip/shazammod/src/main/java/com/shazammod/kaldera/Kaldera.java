package com.shazammod.kaldera;

import static com.shazammod.kaldera.KalderaBody.EMERGE_TICKS;
import static com.shazammod.kaldera.KalderaBody.EMERGE_BREACH;
import static com.shazammod.kaldera.KalderaBody.EMERGE_ROAR;
import static com.shazammod.kaldera.KalderaBody.ROAR_TICKS;
import static com.shazammod.kaldera.KalderaBody.ROAR_HIT;
import static com.shazammod.kaldera.KalderaBody.STOMP_TICKS;
import static com.shazammod.kaldera.KalderaBody.STOMP_HIT;
import static com.shazammod.kaldera.KalderaBody.ERUPT_TICKS;
import static com.shazammod.kaldera.KalderaBody.ERUPT_FIRE;
import static com.shazammod.kaldera.KalderaBody.BOMB_GAP;
import static com.shazammod.kaldera.KalderaBody.BOMB_FLIGHT;
import static com.shazammod.kaldera.KalderaBody.GEYSER_TICKS;
import static com.shazammod.kaldera.KalderaBody.GEYSER_SLAM;
import static com.shazammod.kaldera.KalderaBody.GEYSER_DELAY;
import static com.shazammod.kaldera.KalderaBody.FALL_TICKS;
import static com.shazammod.kaldera.KalderaBody.FALL_HIT;
import static com.shazammod.kaldera.KalderaBody.RAGE_TICKS;
import static com.shazammod.kaldera.KalderaBody.RAGE_BURST;
import static com.shazammod.kaldera.KalderaBody.DEATH_TICKS;
import static com.shazammod.kaldera.KalderaBody.DEATH_COLLAPSE;
import static com.shazammod.kaldera.KalderaBody.DEATH_STONE;
import static com.shazammod.kaldera.KalderaBody.SINK_TICKS;
import static com.shazammod.kaldera.KalderaBody.PRISON_TICKS;
import static com.shazammod.kaldera.KalderaBody.PRISON_SLAM;
import static com.shazammod.kaldera.KalderaBody.RUMBLE_TICKS;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.Nullable;

import com.shazammod.LintangItems;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamAnimPayload;
import com.shazammod.ShazamEntities;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;
import com.shazammod.infinity.InfinityWorld;
import com.shazammod.kaldera.KalderaBody.Action;
import com.shazammod.rival.RivalChampion;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.entity.PartEntity;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 0.73 KALDERA, Titan Radiasi (bos, rancangan orisinal; 0.73.1 tema radiasi). Gunung hidup yang tercemar radiasi: tubuh
 * batu bijih uranium sebesar gunung di atas empat kaki tiang batu, kristal uranium yang menyala hijau tumbuh di bahu &
 * sisi badannya, kawah berisi inti radioaktif di punggungnya, kepala batu berlapis dengan celah hijau sebagai mulut dan
 * tiga pasang mata. Tiap langkahnya menggetarkan tanah, mematikan rumput & tanaman di sekitarnya, dan menghancurkan apa
 * pun yang dilewati tubuhnya (pepohonan, bukit, bangunan) kalau mobGriefing nyala.
 *
 * - Aura Radiasi: yang dekat tubuhnya kena sakit radiasi tiap detik (lapar, racun, lemah, layu + damage yang menembus
 *   zirah); makin dekat makin parah. Penghitung geiger berdetak makin rapat saat mendekat.
 * - Muncul dari perut bumi (tanah merekah, gunungnya naik, lalu meraung). Kebal selama muncul.
 * - Injakan Bumi: mendongak, lalu kedua kaki depan menghantam tanah: kawah + gelombang kejut yang merambat di tanah
 *   (lompat tepat waktu buat menghindarinya!).
 * - Letusan Inti: kawahnya memancarkan denyut radiasi, lalu bongkahan uranium berjatuhan ke sekitar; tiap bongkah
 *   meninggalkan zona radiasi beberapa detik. Sesudahnya INTI TERBUKA: kawah (bagian CORE) jauh lebih rapuh.
 * - Ventilasi Radiasi: satu kaki depan menghentak, tanah di bawah tiap mangsa merekah menyala hijau, lalu menyemburkan
 *   uap radioaktif (melempar ke atas & meninggalkan zona radiasi kecil).
 * - Raungan: gelombang tekanan yang melempar, melambatkan, dan memusingkan; daun-daun di depannya rontok.
 * - Fase KRITIS (darah <= 50%): intinya kelebihan muatan: denyut radiasi besar, auranya lebih luas & lebih parah, lebih
 *   cepat, bongkahan lebih banyak, ventilasi berderet, dan jurus Gunung Runtuh (seluruh badannya dihempaskan ke tanah:
 *   kawah raksasa + gelombang kejut, intinya terbuka).
 * - Tumbang: cahayanya padam, badannya ambruk, lalu membatu jadi gunung batu sungguhan berurat kristal hijau (kalau
 *   mobGriefing nyala).
 * - Tanpa mangsa 2 menit: tenggelam lagi ke perut bumi.
 * - 0.74 Bisa DIJINAKKAN: saat INTI TERBUKA, beri Batu Cryon (Pecahan = 1, Bijih = 3, perlu 3). Yang jinak nggak menyakiti
 *   pemiliknya, pemain lain, & makhluk yang nggak bermusuhan; mengikuti pemiliknya & melawan musuhnya; bisa disuruh diam
 *   (jongkok + klik kanan), disembuhkan dengan Batu Cryon, dan DITUNGGANGI (klik kanan): duduk di dahinya, W berjalan ke
 *   arah pandangan, A/D berbelok, tombol skill Z X C V B N R = jurus-jurusnya (lihat riderCommand). Disimpan ke dunia.
 * - 0.75 Penjara Kristal: kaki kiri depan menghentak, deret duri kristal merambat di tanah ke tiap mangsa (lari ke
 *   samping buat menghindarinya!), lalu kristal besar menyeruak melingkar di ujungnya & mengurung yang ada di sana 3 dtk.
 *   Ditunggangi: tombol J.
 * - 0.75 Inti Kaldera (KalderaCoreItem): memanggil KALDERA jinak pulang ke dalamnya (tenggelam ke perut bumi) dan
 *   membangkitkannya lagi di mana saja. Zirah Antiradiasi (radShield): tiap bagian menahan 25% radiasinya, satu set = kebal.
 * - 0.75 Gempa KALDERA (KalderaSpawner): sesekali yang liar bangkit sendiri di dekat pemain, didahului gempa peringatan
 *   20 dtk (aksi RUMBLE: masih di perut bumi, nggak bisa disentuh & nggak memancarkan radiasi).
 * Kotak tabrakannya dibagi jadi beberapa bagian (KalderaPart). Yang liar nggak disimpan ke dunia.
 */
public class Kaldera extends Monster {
    // ================= Angka-angka yang gampang diutak-atik =================
    public static final double HEALTH = 3000.0;
    public static final double ARMOR = 15.0;
    public static final double TOUGHNESS = 8.0;
    public static final float RAGE_AT = 0.5f;            // fase kritis di bawah 50% darah
    public static final double WALK_SPEED = 0.17;        // blok per tick
    public static final float RAGE_SPEED = 1.25f;
    public static final float TURN = 1.1f;               // derajat per tick
    public static final double STOP_DIST = 26.0;         // berhenti mendekat sejarak ini dari mangsanya
    public static final double SIGHT = 160.0;            // jarak mencari mangsa
    public static final int IDLE_SLEEP = 2400;           // tanpa mangsa selama ini: tenggelam lagi
    public static final float STEP_DMG = 30f;            // terinjak telapaknya
    public static final float TREMOR_DMG = 2f;           // getaran tiap langkah (yang berdiri di tanah)
    public static final double TREMOR_R = 10.0;
    public static final float STOMP_DMG = 40f, STOMP_WAVE_DMG = 24f;
    public static final double STOMP_RADIUS = 44.0, STOMP_SPEED = 1.25;
    public static final int STOMP_CRATER = 7;
    public static final float BOMB_DMG = 22f;            // bongkahan uranium
    public static final double BOMB_R = 5.0;
    public static final int BOMBS = 8, RAGE_BOMBS = 14;
    public static final float GEYSER_DMG = 24f;          // ventilasi radiasi
    public static final double GEYSER_R = 3.2, GEYSER_H = 14.0;
    public static final float ROAR_DMG = 6f;
    public static final double ROAR_R = 28.0;
    public static final float FALL_DMG = 45f, FALL_WAVE_DMG = 18f;
    public static final double FALL_R = 22.0, FALL_WAVE_RADIUS = 52.0;
    public static final int FALL_CRATER = 12;
    public static final float CONTACT_DMG = 6f;          // menempel di tubuhnya (tiap 0,5 dtk) + luka radiasi
    public static final float CORE_WEAK = 2.5f;          // kawah saat intinya terbuka
    public static final float HEAD_WEAK = 1.5f;
    public static final float LEG_ARMOR = 0.6f;
    public static final float PROJECTILE_ARMOR = 0.5f, BLAST_ARMOR = 0.75f;
    public static final double AURA_R = 20.0, RAGE_AURA_R = 28.0;   // aura sakit radiasi, diukur dari kulit tubuhnya
    public static final float AURA_DMG = 2f;             // tiap detik di dalam aura (penuh saat menempel, cepat mengecil menjauh)
    public static final float PULSE_DMG = 8f;            // denyut radiasi Letusan Inti (x1,25 saat menjadi kritis)
    public static final double PULSE_R = 40.0;
    public static final float ZONE_DMG = 2f;             // tiap detik di zona radiasi
    public static final int ZONE_TICKS = 160;            // zona bekas bongkahan uranium
    public static final double ZONE_R = 5.0;
    public static final int VENT_ZONE_TICKS = 100;       // zona bekas ventilasi
    public static final double VENT_ZONE_R = 3.5;
    public static final double BLIGHT_R = 14.0;          // rumput & tanaman di sekitar tiap langkahnya mati
    // 0.74 jinak & ditunggangi
    public static final int TAME_NEEDED = 3;             // poin Cryon untuk menjinakkan saat inti terbuka (Pecahan 1, Bijih 3)
    public static final float CRYON_HEAL = 300f;         // Pecahan Cryon menyembuhkan KALDERA jinak (Bijih x3)
    public static final float TAME_REGEN = 10f;          // pulih per detik sesudah 10 dtk nggak bertarung (yang jinak)
    public static final double RIDE_SPEED = 0.32;        // blok per tick saat ditunggangi (W ditahan)
    public static final float RIDE_TURN = 2.2f;          // derajat per tick saat ditunggangi
    public static final int RIDE_STOMP = 120, RIDE_ERUPT = 260, RIDE_VENT = 160, RIDE_ROAR = 160, RIDE_FALL = 400;   // jeda jurus
    public static final int RIDE_CRIT = 2400, CRIT_TICKS = 600;   // jurus KRITIS: jeda 2 menit, kritis 30 dtk
    public static final double FOLLOW_START = 40.0, FOLLOW_STOP = 24.0;   // mulai & berhenti mengikuti pemiliknya
    public static final double GUARD_R = 48.0;           // menjaga pemiliknya: musuh sejauh ini dari pemiliknya dilawan
    public static final float PRISON_DMG = 14f;          // 0.75 Penjara Kristal: yang terkurung (lalu radiasi tiap detik)
    public static final float SPIKE_DMG = 10f;           //   duri kristal di sepanjang deretnya (sekali per jurus)
    public static final float SHATTER_DMG = 8f;          //   penjaranya pecah
    public static final double PRISON_SPEED = 1.6;       //   blok per tick deretnya merambat di tanah
    public static final double PRISON_RANGE = 64.0;      //   deretnya paling jauh segini dari kakinya
    public static final double SPIKE_START = KalderaBody.FOOT_R + 1.0, SPIKE_GAP = 2.0, SPIKE_R = 1.8;
    public static final double CAGE_R = 2.6;             //   sejarak ini dari ujung deretnya = terkurung
    public static final int PRISON_HOLD = 60;            //   lama terkurung (3 dtk)
    public static final int PRISON_LINES = 6;            //   paling banyak deret sekali jurus
    public static final int RIDE_PRISON = 220;           //   jeda saat ditunggangi (tombol J)
    public static final double RELEASE_MIN = 30.0;       // 0.75 Inti Kaldera: bangkit minimal sejauh ini dari pemainnya
    public static final double RELEASE_RANGE = 96.0;     //   titik bidik paling jauh
    public static final double RECALL_RANGE = 512.0;     //   KALDERA milikmu sejauh ini (yang termuat) bisa dipanggil pulang
    public static final int EXPOSED_TICKS = 100;
    public static final int CARVE_PER_TICK = 420;        // paling banyak blok yang dihancurkan tubuhnya per tick
    public static final int XP = 1500;
    // waktu tiap gerakan (EMERGE_TICKS, STOMP_HIT, ...) ada di KalderaBody: dipakai bersama pose, efek client, & SFX
    // =========================================================================


    private static final EntityDataAccessor<Integer> DATA_ACTION = SynchedEntityData.defineId(Kaldera.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ACTION_TICK = SynchedEntityData.defineId(Kaldera.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> DATA_STRIDE = SynchedEntityData.defineId(Kaldera.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> DATA_RAGE = SynchedEntityData.defineId(Kaldera.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_EXPOSED = SynchedEntityData.defineId(Kaldera.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_TARGET = SynchedEntityData.defineId(Kaldera.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Optional<UUID>> DATA_OWNER = SynchedEntityData.defineId(Kaldera.class,
            EntityDataSerializers.OPTIONAL_UUID);
    /** Buat HUD penunggang: bit 0-5 = jurus siap (Z X C V B R), 8 = penghancuran nyala, 9 = diam, 10 = sedang bergerak. */
    private static final EntityDataAccessor<Integer> DATA_READY = SynchedEntityData.defineId(Kaldera.class, EntityDataSerializers.INT);
    public static final int READY_SMASH = 1 << 8, READY_STAY = 1 << 9, READY_BUSY = 1 << 10;

    private static final int BOMB = 0, GEYSER_HIT = 1, SPIKE = 2, CAGE = 3;   // jenis pending

    private final ServerBossEvent bar = new ServerBossEvent(Component.translatable("boss.shazammod.kaldera"),
            BossEvent.BossBarColor.GREEN, BossEvent.BossBarOverlay.NOTCHED_10);
    private final KalderaPart head;
    private final KalderaPart bodyFront;
    private final KalderaPart bodyBack;
    private final KalderaPart peak;
    private final KalderaPart[] legs = new KalderaPart[4];
    private final KalderaPart[] parts;
    private final KalderaBody.Pose pose = new KalderaBody.Pose();
    private final float[] v = new float[4];
    private final float[] w = new float[4];
    private final double[] footY = new double[4];
    private final int[] steps = new int[4];
    private final List<double[]> pending = new ArrayList<>();   // {x, y, z, tick jatuh, jenis}
    private final List<double[]> zones = new ArrayList<>();     // zona radiasi {x, y, z, tick habis, jari-jari}
    private final Set<UUID> waveHit = new HashSet<>();
    private Action action = Action.EMERGE;
    private int actionAge;
    private float stride;
    private boolean stepsReady;
    private boolean rage;
    private boolean rageQueued;
    private boolean settled;
    private LivingEntity target;
    private int retarget;
    private int idle;
    private long nextRoar, nextStomp, nextErupt, nextGeyser, nextFall, nextAny, nextCrit, nextPrison;
    private final List<Trap> traps = new ArrayList<>();         // 0.75 yang terkurung Penjara Kristal
    private final Set<UUID> spiked = new HashSet<>();         // 0.75 sudah kena duri kristal di jurus ini
    private boolean recalled;    // 0.75 sudah disimpan ke Inti Kaldera: tenggelam lalu hilang (jangan disimpan ke dunia lagi)
    @Nullable
    private UUID owner;          // 0.74 pemiliknya (null = liar)
    private String ownerName = "";
    private int tameProgress;    // poin Cryon yang sudah diserap intinya
    private boolean smashOn;     // jinak: boleh menghancurkan blok (bawaan mati, dinyalakan penunggangnya)
    private boolean stay;        // jinak: disuruh diam di tempat
    private boolean following;
    private long critUntil;      // jurus KRITIS dari penunggangnya berakhir
    private long lastCombat;
    private final float[] seatTmp = new float[4];
    private long exposedUntil;
    private Vec3 waveC;
    private double waveR, waveMax, waveSpeed;
    private float waveDmg;
    private int carveLayer;
    private double carvedX = Double.NaN, carvedZ;
    private float carvedYaw;
    private int plow;
    private int crumbles;   // pecahan blok remuk yang diperlihatkan tick ini
    private List<int[]> mountain;
    private int mountainIndex;
    private double mountainPerTick;

    // client: langkah yang diinterpolasi antar-tick, & kepala yang menoleh ke mangsanya
    public float strideO, strideC;
    private float lookYawO, lookYawC, lookUpO, lookUpC;

    public Kaldera(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.head = new KalderaPart(this, KalderaPart.Kind.HEAD, 16f, 14f);
        this.bodyFront = new KalderaPart(this, KalderaPart.Kind.BODY, 28f, 22f);
        this.bodyBack = new KalderaPart(this, KalderaPart.Kind.BODY, 30f, 24f);
        this.peak = new KalderaPart(this, KalderaPart.Kind.CORE, 18f, 14f);
        for (int i = 0; i < 4; i++) {
            legs[i] = new KalderaPart(this, KalderaPart.Kind.LEG, 12f, 27f);
        }
        this.parts = new KalderaPart[]{head, bodyFront, bodyBack, peak, legs[0], legs[1], legs[2], legs[3]};
        reserveIds();
        this.noPhysics = true;
        this.setNoGravity(true);
        this.xpReward = 0;
        this.setPersistenceRequired();
        bar.setDarkenScreen(true);
        bar.setPlayBossMusic(true);
        if (!level.isClientSide) {   // bangkitnya dimulai sekarang (client menghitung waktu aksinya dari sini)
            this.entityData.set(DATA_ACTION_TICK, (int) level.getGameTime());
        }
    }

    /**
     * Bagian tubuhnya butuh id entity berurutan sesudah id-nya sendiri (client menebak id bagian dari id induknya). Dipesan
     * dari penghitung id entity; kalau penghitungnya nggak bisa diraih, bagian-bagiannya memang dibuat tepat sesudah
     * badannya, jadi id-nya sudah berurutan.
     */
    private void reserveIds() {
        int base = this.getId();
        try {
            Field f = Entity.class.getDeclaredField("ENTITY_COUNTER");
            f.setAccessible(true);
            if (f.get(null) instanceof AtomicInteger counter) {
                base = counter.getAndAdd(parts.length + 1) + 1;
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // pakai id yang sudah ada
        }
        this.setId(base);
    }

    @Override
    public void setId(int id) {
        super.setId(id);
        if (parts != null) {
            for (int i = 0; i < parts.length; i++) {
                parts[i].setId(id + i + 1);
            }
        }
    }

    @Override
    public boolean isMultipartEntity() {
        return true;
    }

    @Override
    public PartEntity<?>[] getParts() {
        return parts;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, HEALTH)
                .add(Attributes.MOVEMENT_SPEED, WALK_SPEED)
                .add(Attributes.ATTACK_DAMAGE, STEP_DMG)
                .add(Attributes.FOLLOW_RANGE, SIGHT)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.ARMOR, ARMOR)
                .add(Attributes.ARMOR_TOUGHNESS, TOUGHNESS);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ACTION, Action.EMERGE.ordinal());
        builder.define(DATA_ACTION_TICK, 0);
        builder.define(DATA_STRIDE, 0f);
        builder.define(DATA_RAGE, false);
        builder.define(DATA_EXPOSED, 0);
        builder.define(DATA_TARGET, -1);
        builder.define(DATA_OWNER, Optional.empty());
        builder.define(DATA_READY, 0);
    }

    @Override
    protected void registerGoals() {
        // AI sendiri di customServerAiStep
    }

    // ------------------------------------------------------------------ dibaca client

    public Action action() {
        int i = this.entityData.get(DATA_ACTION);
        Action[] all = Action.values();
        return i >= 0 && i < all.length ? all[i] : Action.IDLE;
    }

    /** Tick sejak aksi sekarang dimulai (waktu dunia, jadi sama di server & client). */
    public float actionTime(float partialTick) {
        return Math.max(0f, (float) ((int) this.level().getGameTime() - this.entityData.get(DATA_ACTION_TICK)) + partialTick);
    }

    public boolean isRaging() {
        return this.entityData.get(DATA_RAGE);
    }

    /** Intinya sedang terbuka: sisa tick (0 = tertutup). */
    public float exposedTicks(float partialTick) {
        return Math.max(0f, this.entityData.get(DATA_EXPOSED) - (float) this.level().getGameTime() - partialTick);
    }

    public int targetId() {
        return this.entityData.get(DATA_TARGET);
    }

    /** Langkah yang diinterpolasi (client). */
    public float stride(float partialTick) {
        return Mth.lerp(partialTick, strideO, strideC);
    }

    /** Tolehan kepala ke mangsanya (radian, client), ditambahkan ke pose. */
    public float lookYaw(float partialTick) {
        return Mth.lerp(partialTick, lookYawO, lookYawC);
    }

    public float lookUp(float partialTick) {
        return Mth.lerp(partialTick, lookUpO, lookUpC);
    }

    /** Client: kepala pelan-pelan menoleh ke mangsa yang sedang dikejarnya. */
    private void turnHead() {
        lookYawO = lookYawC;
        lookUpO = lookUpC;
        float wantYaw = 0f, wantUp = 0f;
        int id = this.entityData.get(DATA_TARGET);
        Entity t = id >= 0 ? this.level().getEntity(id) : null;
        Action a = action();
        if (t != null && (a == Action.IDLE || a == Action.ROAR || a == Action.GEYSER || a == Action.ERUPT)) {
            KalderaBody.body(pose, 0f, KalderaBody.NECK_Y, KalderaBody.NECK_Z, v);
            Vec3 neck = world(v[0], v[1], v[2]);
            double dx = t.getX() - neck.x, dz = t.getZ() - neck.z, dy = t.getEyeY() - neck.y;
            float rel = Mth.wrapDegrees((float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90f - this.getYRot()) * Mth.DEG_TO_RAD;
            wantYaw = Mth.clamp(-rel, -0.45f, 0.45f);
            wantUp = Mth.clamp((float) Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)), -0.35f, 0.25f);
        }
        lookYawC += (wantYaw - lookYawC) * 0.08f;
        lookUpC += (wantUp - lookUpC) * 0.08f;
    }

    /** 0.74 Sudah dijinakkan (server & client). */
    public boolean isTamed() {
        return this.entityData.get(DATA_OWNER).isPresent();
    }

    @Nullable
    public UUID ownerId() {
        return this.entityData.get(DATA_OWNER).orElse(null);
    }

    public boolean isOwner(@Nullable Entity e) {
        UUID o = ownerId();
        return o != null && e != null && o.equals(e.getUUID());
    }

    /** Bit-bit HUD penunggang (lihat DATA_READY). */
    public int readyBits() {
        return this.entityData.get(DATA_READY);
    }

    @Nullable
    public Player rider() {
        return this.getFirstPassenger() instanceof Player p ? p : null;
    }

    /** Sedang memancarkan radiasi (dibaca dari aksi yang disinkronkan, jadi sama di server & client). */
    public boolean radiating() {
        float t = actionTime(0f);
        return switch (action()) {
            case EMERGE -> t > EMERGE_BREACH;
            case SINK, RUMBLE -> false;
            case DEATH -> t < DEATH_COLLAPSE;
            default -> true;
        };
    }

    /** Jari-jari aura radiasinya sekarang (dari kulit tubuhnya). */
    public double auraRadius() {
        return isRaging() ? RAGE_AURA_R : AURA_R;
    }

    /** Jarak titik tengah badan e ke kulit tubuhnya: kotak bagian tubuh yang terdekat (server & client). */
    public double partDistance(Entity e) {
        double x = e.getX(), y = e.getY() + e.getBbHeight() * 0.5, z = e.getZ();
        double best = Double.MAX_VALUE;
        for (KalderaPart part : parts) {
            AABB b = part.getBoundingBox();
            double dx = Math.max(Math.max(b.minX - x, x - b.maxX), 0.0);
            double dy = Math.max(Math.max(b.minY - y, y - b.maxY), 0.0);
            double dz = Math.max(Math.max(b.minZ - z, z - b.maxZ), 0.0);
            best = Math.min(best, dx * dx + dy * dy + dz * dz);
        }
        return Math.sqrt(best);
    }

    /** Kebal: sedang muncul, kritis, tumbang, tenggelam, atau 0.75 masih di perut bumi (gempa peringatan). */
    public boolean untouchable() {
        Action a = action();
        return a == Action.EMERGE || a == Action.RAGE || a == Action.DEATH || a == Action.SINK || a == Action.RUMBLE;
    }

    // ------------------------------------------------------------------ alat bantu

    private void anim(ShazamAnim anim, Vec3 pos) {
        if (this.level().isClientSide) {
            return;
        }
        PacketDistributor.sendToPlayersTrackingEntity(this, new ShazamAnimPayload(this.getId(), anim.ordinal(),
                (float) pos.x, (float) pos.y, (float) pos.z));
    }

    private void sound(Vec3 at, SoundEvent sound, float volume, float pitch) {
        this.level().playSound(null, at.x, at.y, at.z, sound, SoundSource.HOSTILE, volume, pitch);
    }

    private float pitchJitter() {
        return 0.92f + this.random.nextFloat() * 0.16f;
    }

    private void act(Action a) {
        action = a;
        actionAge = 0;
        this.entityData.set(DATA_ACTION, a.ordinal());
        this.entityData.set(DATA_ACTION_TICK, (int) this.level().getGameTime());
    }

    private void idleNow(long now) {
        act(Action.IDLE);
        nextAny = now + (rage ? 30 : 50);
    }

    static boolean griefing(ServerLevel level) {
        return level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
    }

    /** Boleh menghancurkan blok: mobGriefing nyala, dan kalau jinak, penghancurannya dinyalakan pemiliknya. */
    private boolean destroys(ServerLevel level) {
        return griefing(level) && (!isTamed() || smashOn);
    }

    /** Titik di ruang lokal (lx, ly, lz) -> dunia. */
    private Vec3 world(float lx, float ly, float lz) {
        float yaw = this.getYRot();
        return new Vec3(KalderaBody.worldX(this.getX(), yaw, lx, lz), this.getY() + ly, KalderaBody.worldZ(this.getZ(), yaw, lx, lz));
    }

    private Vec3 bodyPoint(float x, float y, float z) {
        KalderaBody.body(pose, x, y, z, v);
        return world(v[0], v[1], v[2]);
    }

    private Vec3 headPoint(float x, float y, float z) {
        KalderaBody.headLocal(pose, x, y, z, v);
        return world(v[0], v[1], v[2]);
    }

    /** Puncak kawah (mulut gunungnya). */
    public Vec3 calderaTop() {
        return bodyPoint(0f, KalderaBody.CALDERA_Y, KalderaBody.CALDERA_Z);
    }

    private Vec3 mouth() {
        return headPoint(0f, -1.5f, KalderaBody.HEAD_LEN - 2f);
    }

    /** Tanah di bawah pusat badannya. */
    private Vec3 center() {
        return new Vec3(this.getX(), this.getY(), this.getZ());
    }

    /** Titik mendarat telapak kaki leg menurut irama langkahnya (di tanah). */
    private Vec3 landing(ServerLevel level, int leg) {
        KalderaBody.gaitFoot(leg, stride, w);
        Vec3 p = world(w[0], 0f, w[1]);
        double g = KalderaBody.ground(level, p.x, p.z);
        return new Vec3(p.x, Double.isNaN(g) ? this.getY() : g, p.z);
    }

    /**
     * Siapa pun yang terkena serangan sebesar gunung (semua makhluk, kecuali dirinya & pemain kreatif/penonton). Yang jinak
     * cuma mengenai musuh: lihat friendly.
     */
    private boolean victim(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof Kaldera || e instanceof ArmorStand) {
            return false;
        }
        if (e instanceof Player p && (p.isCreative() || p.isSpectator())) {
            return false;
        }
        return !isTamed() || !friendly(e);
    }

    /**
     * 0.74 KALDERA jinak nggak menyakiti pemiliknya, penunggangnya, peliharaan pemiliknya, pemain lain, & makhluk yang
     * nggak bermusuhan, kecuali yang sedang dilawannya atau baru saja menyerangnya.
     */
    private boolean friendly(LivingEntity e) {
        if (isOwner(e) || e.getVehicle() == this) {
            return true;
        }
        if (e == target || e == this.getLastHurtByMob()) {
            return false;
        }
        if (e instanceof OwnableEntity pet) {
            UUID u = pet.getOwnerUUID();
            if (u != null && u.equals(ownerId())) {
                return true;
            }
        }
        return !(e instanceof Enemy);
    }

    /** Musuh (bukan kawan) di sekitar titik c: sasaran jurus KALDERA jinak. */
    private List<LivingEntity> foes(Vec3 c, double radius) {
        return this.level().getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(radius, 24.0, radius), this::victim);
    }

    /** Yang dikejar: pemain, juara rival, golem besi, dan siapa pun yang menyerangnya. */
    private boolean prey(LivingEntity e) {
        if (!victim(e)) {
            return false;
        }
        return e instanceof Player || e instanceof RivalChampion || e instanceof IronGolem || e == this.getLastHurtByMob()
                || (e instanceof Mob m && m.getTarget() == this);
    }

    private List<LivingEntity> victims(Vec3 c, double radius, double height) {
        return this.level().getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(radius, height, radius), this::victim);
    }

    private static double flat(Vec3 c, Entity e) {
        double dx = e.getX() - c.x, dz = e.getZ() - c.z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private static Vec3 away(Vec3 from, Entity e) {
        Vec3 a = new Vec3(e.getX() - from.x, 0, e.getZ() - from.z);
        return a.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : a.normalize();
    }

    private static void fling(LivingEntity e, Vec3 from, double out, double up) {
        Vec3 a = away(from, e);
        e.push(a.x * out, up, a.z * out);
        e.hurtMarked = true;
    }

    private float power() {
        return rage ? 1.2f : 1f;
    }

    /** Pukulan sekuat gunung; perisai yang sedang dipakai dipatahkan dulu. */
    private boolean strike(LivingEntity e, float damage, boolean blast) {
        if (!victim(e)) {
            return false;
        }
        if (e instanceof Player p && p.isBlocking()) {
            p.getCooldowns().addCooldown(Items.SHIELD, 100);
            p.stopUsingItem();
            p.level().broadcastEntityEvent(p, (byte) 30);
        }
        e.invulnerableTime = 0;
        DamageSource src = blast ? this.damageSources().explosion(this, this) : this.damageSources().mobAttack(this);
        return e.hurt(src, damage * power());
    }

    /** Berdiri di tanah (yang melompat lolos dari gelombang kejut di tanah). */
    private boolean grounded(LivingEntity e) {
        if (e.onGround()) {
            return true;
        }
        double g = KalderaBody.ground(this.level(), e.getX(), e.getZ());
        return !Double.isNaN(g) && e.getY() - g < 0.8;
    }

    private void tell(Component message, double range) {
        if (this.level() instanceof ServerLevel level) {
            for (ServerPlayer p : level.players()) {
                if (p.distanceToSqr(this) < range * range) {
                    p.displayClientMessage(message, true);
                }
            }
        }
    }

    private void updateBar() {
        MutableComponent name = isTamed()
                ? Component.translatable(rage ? "boss.shazammod.kaldera_tamed_rage" : "boss.shazammod.kaldera_tamed", ownerName)
                        .withStyle(rage ? ChatFormatting.YELLOW : ChatFormatting.GREEN, ChatFormatting.BOLD)
                : Component.translatable(rage ? "boss.shazammod.kaldera_rage" : "boss.shazammod.kaldera")
                        .withStyle(rage ? ChatFormatting.YELLOW : ChatFormatting.GREEN, ChatFormatting.BOLD);
        if (exposedUntil > this.level().getGameTime()) {
            name.append(Component.literal("  \u2622 ").withStyle(ChatFormatting.WHITE))
                    .append(Component.translatable("boss.shazammod.kaldera_exposed").withStyle(ChatFormatting.WHITE));
        }
        bar.setName(name);
        bar.setColor(rage ? BossEvent.BossBarColor.YELLOW : BossEvent.BossBarColor.GREEN);
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        if (this.level().isClientSide) {
            strideO = strideC;
            strideC = this.entityData.get(DATA_STRIDE);
            if (Math.abs(strideC - strideO) > 8f) {
                strideO = strideC;
            }
        }
        this.setDeltaMovement(Vec3.ZERO);
        super.tick();
        placeParts();
        if (this.level().isClientSide) {
            turnHead();
        }
    }

    /** Pindahkan kotak tabrakan tiap bagian ke posisi tubuhnya sekarang (server & client). */
    private void placeParts() {
        boolean client = this.level().isClientSide;
        float t = client ? actionTime(0f) : actionAge;
        float st = client ? strideC : stride;
        KalderaBody.pose(pose, client ? action() : action, t, st, this.tickCount, client ? isRaging() : rage);
        float yaw = this.getYRot();
        KalderaBody.headLocal(pose, 0f, 0f, KalderaBody.HEAD_LEN * 0.5f, v);
        place(head, yaw, v[0], v[1], v[2]);
        KalderaBody.body(pose, 0f, KalderaBody.BODY_Y, 11f, v);
        place(bodyFront, yaw, v[0], v[1], v[2]);
        KalderaBody.body(pose, 0f, KalderaBody.BODY_Y + 1f, -15f, v);
        place(bodyBack, yaw, v[0], v[1], v[2]);
        KalderaBody.body(pose, 0f, KalderaBody.CALDERA_Y - 5f, KalderaBody.CALDERA_Z, v);
        place(peak, yaw, v[0], v[1], v[2]);
        for (int i = 0; i < 4; i++) {
            KalderaPart leg = legs[i];
            double wx, wy, wz;
            if (pose.planted[i]) {
                float fx = pose.foot[i * 3], fz = pose.foot[i * 3 + 2];
                wx = KalderaBody.worldX(this.getX(), yaw, fx, fz);
                wz = KalderaBody.worldZ(this.getZ(), yaw, fx, fz);
                double g = KalderaBody.ground(this.level(), wx, wz);
                footY[i] = Double.isNaN(g) ? this.getY() : g;
                wy = footY[i] + pose.foot[i * 3 + 1];
            } else {
                KalderaBody.body(pose, pose.foot[i * 3], pose.foot[i * 3 + 1], pose.foot[i * 3 + 2], v);
                wx = KalderaBody.worldX(this.getX(), yaw, v[0], v[2]);
                wz = KalderaBody.worldZ(this.getZ(), yaw, v[0], v[2]);
                wy = this.getY() + v[1];
                footY[i] = wy;
            }
            move(leg, wx, wy, wz);
        }
    }

    private void place(KalderaPart part, float yaw, float lx, float ly, float lz) {
        move(part, KalderaBody.worldX(this.getX(), yaw, lx, lz), this.getY() + ly - part.getBbHeight() * 0.5,
                KalderaBody.worldZ(this.getZ(), yaw, lx, lz));
    }

    private static void move(KalderaPart part, double x, double y, double z) {
        part.xo = part.getX();
        part.yo = part.getY();
        part.zo = part.getZ();
        part.xOld = part.xo;
        part.yOld = part.yo;
        part.zOld = part.zo;
        part.setPos(x, y, z);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (!(this.level() instanceof ServerLevel level)) {
            return;
        }
        actionAge++;
        long now = level.getGameTime();
        bar.setProgress(Mth.clamp(this.getHealth() / this.getMaxHealth(), 0f, 1f));
        if (this.tickCount % 20 == 0) {
            updateBar();
        }
        if (rageQueued && action != Action.EMERGE && action != Action.DEATH && action != Action.SINK && action != Action.RAGE
                && action != Action.RUMBLE) {
            rageQueued = false;
            enterRage(now);
        }
        if (isTamed()) {
            tickTamed(level, now);
        }
        tickPending(level, now);
        tickWave(level);
        tickAura();
        tickZones(now);
        tickTraps(level, now);
        switch (action) {
            case EMERGE -> tickEmerge(level, now);
            case RUMBLE -> tickRumble(level, now);
            case PRISON -> tickPrison(level, now);
            case ROAR -> {
                if (actionAge == ROAR_HIT) {
                    roarBlast(level, 1f);
                }
                if (actionAge >= ROAR_TICKS) {
                    idleNow(now);
                }
            }
            case STOMP -> tickStomp(level, now);
            case ERUPT -> tickErupt(level, now);
            case GEYSER -> tickGeyser(level, now);
            case FALL -> tickFall(level, now);
            case RAGE -> tickRage(level, now);
            case DEATH -> tickDying(level);
            case SINK -> {
                if (actionAge >= SINK_TICKS) {
                    this.discard();
                }
            }
            default -> {
                if (!isTamed()) {
                    tickHunt(level, now);
                } else if (rider() instanceof ServerPlayer r) {
                    tickRidden(level, now, r);
                } else {
                    tickCompanion(level, now);
                }
            }
        }
        settle(level);
        carve(level);
        if (isTamed()) {
            carveSeat(level);
        }
        if (this.tickCount % 10 == 0 && action != Action.DEATH && action != Action.RUMBLE) {
            contact(level);
        }
        this.entityData.set(DATA_STRIDE, stride);
    }

    // ------------------------------------------------------------------ berjalan

    private float turnRate() {
        return rage ? TURN * 1.3f : TURN;
    }

    private void face(float yaw) {
        this.setYRot(yaw);
        this.yHeadRot = yaw;
        this.yBodyRot = yaw;
    }

    private LivingEntity pickTarget(ServerLevel level) {
        LivingEntity hurtBy = this.getLastHurtByMob();
        if (hurtBy != null && prey(hurtBy) && hurtBy.distanceToSqr(this) < SIGHT * SIGHT) {
            return hurtBy;
        }
        LivingEntity best = null;
        double bestD = SIGHT * SIGHT;
        for (ServerPlayer p : level.players()) {
            double d = p.distanceToSqr(this);
            if (d < bestD && prey(p)) {
                bestD = d;
                best = p;
            }
        }
        return best;
    }

    private void tickHunt(ServerLevel level, long now) {
        if (target == null || !target.isAlive() || !prey(target) || --retarget <= 0 || target.distanceToSqr(this) > SIGHT * SIGHT) {
            target = pickTarget(level);
            retarget = 20;
            this.entityData.set(DATA_TARGET, target == null ? -1 : target.getId());
        }
        if (target == null) {
            if (++idle > IDLE_SLEEP) {
                startSink();
            }
            return;
        }
        idle = 0;
        double dx = target.getX() - this.getX(), dz = target.getZ() - this.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        float want = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90f;
        float delta = Mth.wrapDegrees(want - this.getYRot());
        float turn = Mth.clamp(delta, -turnRate(), turnRate());
        face(this.getYRot() + turn);
        stride += Math.abs(turn) * 0.12f;
        if (chooseAttack(level, now, dist, Math.abs(delta))) {
            return;
        }
        if (dist > STOP_DIST) {
            double speed = WALK_SPEED * (rage ? RAGE_SPEED : 1f) * Mth.clamp(Mth.cos(delta * Mth.DEG_TO_RAD), 0.2f, 1f);
            if (plow > 600) {   // menerobos bukit: melambat
                speed *= 0.6;
            }
            walk(level, speed);
        }
    }

    private void walk(ServerLevel level, double speed) {
        float a = this.getYRot() * Mth.DEG_TO_RAD;
        double fx = -Mth.sin(a), fz = Mth.cos(a);
        double nx = this.getX() + fx * speed, nz = this.getZ() + fz * speed;
        double ax = nx + fx * 40.0, az = nz + fz * 40.0;   // jangan masuk ke chunk yang belum dimuat / melewati batas dunia
        if (!level.isLoaded(BlockPos.containing(ax, this.getY(), az)) || !level.getWorldBorder().isWithinBounds(ax, az)) {
            return;
        }
        this.setPos(nx, this.getY(), nz);
        stride += (float) speed;
    }

    /** Ikuti tanah di bawah telapak-telapaknya, dan hantamkan telapak yang baru mendarat. */
    private void settle(ServerLevel level) {
        KalderaBody.pose(pose, action, actionAge, stride, this.tickCount, rage);
        float yaw = this.getYRot();
        double sum = 0;
        int n = 0;
        for (int i = 0; i < 4; i++) {
            if (!pose.planted[i]) {
                continue;
            }
            float fx = pose.foot[i * 3], fz = pose.foot[i * 3 + 2];
            double g = KalderaBody.ground(level, KalderaBody.worldX(this.getX(), yaw, fx, fz), KalderaBody.worldZ(this.getZ(), yaw, fx, fz));
            if (!Double.isNaN(g)) {
                sum += g;
                n++;
            }
        }
        double base;
        if (n > 0) {
            base = sum / n;
        } else {
            double g = KalderaBody.ground(level, this.getX(), this.getZ());
            base = Double.isNaN(g) ? this.getY() : g;
        }
        double y = this.getY();
        double ny = !settled || Math.abs(base - y) > 24.0 ? base : y + Mth.clamp(base - y, -0.35, 0.35);
        settled = true;
        if (Math.abs(ny - y) > 1.0E-4) {
            this.setPos(this.getX(), ny, this.getZ());
        }
        boolean walking = action == Action.IDLE || action == Action.ERUPT || action == Action.GEYSER || action == Action.ROAR
                || action == Action.PRISON;
        for (int i = 0; i < 4; i++) {
            int s = KalderaBody.stepIndex(i, stride);
            if (stepsReady && s > steps[i] && walking && pose.planted[i]) {
                footfall(level, i);
            }
            steps[i] = s;
        }
        stepsReady = true;
    }

    /** Telapak raksasa menghantam tanah: yang terinjak remuk, tanah bergetar, jejak kakinya hangus. */
    private void footfall(ServerLevel level, int leg) {
        Vec3 f = landing(level, leg);
        sound(f, ShazamSounds.KALDERA_STEP.get(), 6f, 0.85f + this.random.nextFloat() * 0.25f);
        double crush = KalderaBody.FOOT_R + 1.5;
        for (LivingEntity e : victims(f, TREMOR_R, 6.0)) {
            double d = flat(f, e);
            if (d < crush && Math.abs(e.getY() - f.y) < 5.0) {
                if (strike(e, STEP_DMG, false)) {
                    fling(e, f, 1.0, 0.9);
                }
            } else if (d < TREMOR_R && grounded(e)) {
                strike(e, TREMOR_DMG, false);
                e.push(0, 0.32, 0);
                e.hurtMarked = true;
            }
        }
        if (destroys(level)) {
            footprint(level, f, KalderaBody.FOOT_R);
            blight(level, f, BLIGHT_R, 48);
        }
    }

    // ------------------------------------------------------------------ memilih serangan

    private boolean chooseAttack(ServerLevel level, long now, double dist, float angle) {
        if (now < nextAny) {
            return false;
        }
        List<Action> options = new ArrayList<>(5);
        if (now >= nextRoar && dist < 30.0 && angle < 50f) {
            options.add(Action.ROAR);
        }
        if (now >= nextStomp && dist < 42.0) {
            options.add(Action.STOMP);
        }
        if (now >= nextErupt && dist > 10.0 && dist < 72.0) {
            options.add(Action.ERUPT);
        }
        if (now >= nextGeyser && dist < 80.0) {
            options.add(Action.GEYSER);
        }
        if (rage && now >= nextFall && dist < 26.0) {
            options.add(Action.FALL);
        }
        if (now >= nextPrison && dist > 12.0 && dist < PRISON_RANGE + 8.0) {   // 0.75 yang menjaga jarak dikurung
            options.add(Action.PRISON);
        }
        if (options.isEmpty()) {
            return false;
        }
        float cd = rage ? 0.7f : 1f;
        switch (options.get(this.random.nextInt(options.size()))) {
            case ROAR -> {
                nextRoar = now + (long) ((420 + this.random.nextInt(160)) * cd);
                beginRoar();
            }
            case STOMP -> {
                nextStomp = now + (long) ((220 + this.random.nextInt(80)) * cd);
                beginStomp(level);
            }
            case ERUPT -> {
                nextErupt = now + (long) ((340 + this.random.nextInt(120)) * cd);
                beginErupt();
            }
            case GEYSER -> {
                nextGeyser = now + (long) ((260 + this.random.nextInt(100)) * cd);
                beginGeyser(level);
            }
            case FALL -> {
                nextFall = now + (long) ((600 + this.random.nextInt(200)) * cd);
                beginFall();
            }
            case PRISON -> {
                nextPrison = now + (long) ((320 + this.random.nextInt(120)) * cd);
                beginPrison(level);
            }
            default -> { }
        }
        return true;
    }

    private void beginRoar() {
        act(Action.ROAR);
        anim(ShazamAnim.KALDERA_ROAR, mouth());
        sound(mouth(), ShazamSounds.KALDERA_ROAR.get(), 14f, pitchJitter());
    }

    private void beginStomp(ServerLevel level) {
        act(Action.STOMP);
        Vec3 c = landing(level, KalderaBody.FL).add(landing(level, KalderaBody.FR)).scale(0.5);
        anim(ShazamAnim.KALDERA_STOMP, c);
        sound(c, ShazamSounds.KALDERA_STRAIN.get(), 10f, pitchJitter());
    }

    private void beginErupt() {
        act(Action.ERUPT);
        Vec3 top = calderaTop();
        anim(ShazamAnim.KALDERA_ERUPT, top);
        sound(top, ShazamSounds.KALDERA_ERUPT.get(), 16f, 1f);
    }

    private void beginGeyser(ServerLevel level) {
        act(Action.GEYSER);
        anim(ShazamAnim.KALDERA_GEYSER, landing(level, KalderaBody.FR));
    }

    private void beginFall() {
        act(Action.FALL);
        anim(ShazamAnim.KALDERA_FALL, center());
        sound(center(), ShazamSounds.KALDERA_FALL.get(), 16f, 1f);
    }

    // ------------------------------------------------------------------ muncul & tenggelam

    private void tickEmerge(ServerLevel level, long now) {
        if (actionAge == 1) {
            anim(ShazamAnim.KALDERA_EMERGE, center());
            sound(center(), ShazamSounds.KALDERA_EMERGE.get(), 16f, 1f);
            for (ServerPlayer p : level.players()) {
                if (isTamed()) {   // 0.75 yang jinak (dari Inti Kaldera): cukup kabar untuk pemiliknya, tanpa judul layar
                    if (isOwner(p)) {
                        p.displayClientMessage(Component.translatable("message.shazammod.kaldera_rise_tamed")
                                .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), true);
                    }
                } else if (p.distanceToSqr(this) < 200.0 * 200.0) {
                    p.connection.send(new ClientboundSetTitlesAnimationPacket(10, 80, 25));
                    p.connection.send(new ClientboundSetTitleTextPacket(Component.translatable("title.shazammod.kaldera")
                            .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD)));
                    p.connection.send(new ClientboundSetSubtitleTextPacket(Component.translatable("title.shazammod.kaldera_sub")
                            .withStyle(ChatFormatting.YELLOW, ChatFormatting.ITALIC)));
                }
            }
        }
        if (actionAge % 10 == 5 && actionAge < EMERGE_TICKS - 20) {   // tanah terangkat: yang di atasnya terlempar ke luar
            Vec3 c = center();
            for (LivingEntity e : victims(c, 28.0, 40.0)) {
                if (flat(c, e) < 26.0) {
                    strike(e, 3f, false);
                    fling(e, c, 1.2, 0.6);
                }
            }
        }
        if (actionAge == EMERGE_ROAR) {
            roarBlast(level, 0.8f);
        }
        if (actionAge >= EMERGE_TICKS) {
            act(Action.IDLE);
            nextAny = now + 40;
            nextStomp = now + 100;
            nextErupt = now + 160;
            nextGeyser = now + 220;
            nextRoar = now + 300;
            nextFall = now + 300;
            nextPrison = now + 260;
            updateBar();
        }
    }

    private void startSink() {
        act(Action.SINK);
        anim(ShazamAnim.KALDERA_SINK, center());
        sound(center(), ShazamSounds.KALDERA_SINK.get(), 16f, 1f);
        tell(Component.translatable("message.shazammod.kaldera_sleep").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), 200.0);
    }

    // ------------------------------------------------------------------ raungan

    /** Gelombang tekanan dari mulutnya: terlempar, lambat, pusing; proyektil hancur; daun-daun di depannya rontok. */
    private void roarBlast(ServerLevel level, float k) {
        Vec3 c = mouth();
        double r = ROAR_R * k;
        for (LivingEntity e : victims(c, r, r)) {
            double d = Math.sqrt(e.distanceToSqr(c));
            if (d > r) {
                continue;
            }
            float f = (float) (1.0 - d / r);
            strike(e, ROAR_DMG * k, false);
            fling(e, c, 2.2 * f + 0.4, 0.5 * f + 0.2);
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
            if (e instanceof Player) {
                e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0));
            }
        }
        for (Projectile shot : level.getEntitiesOfClass(Projectile.class, new AABB(c, c).inflate(r), p -> p.getOwner() != this
                && !(isTamed() && p.getOwner() instanceof LivingEntity le && friendly(le)))) {   // jinak: tembakan kawan dibiarkan
            shot.discard();
        }
        if (destroys(level)) {   // daun pepohonan di depannya rontok
            BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
            int rr = (int) (14 * k), cx = Mth.floor(c.x), cy = Mth.floor(c.y), cz = Mth.floor(c.z), stripped = 0;
            for (int dx = -rr; dx <= rr && stripped < 1500; dx++) {
                for (int dz = -rr; dz <= rr && stripped < 1500; dz++) {
                    for (int dy = -rr; dy <= rr; dy++) {
                        if (dx * dx + dy * dy + dz * dz > rr * rr) {
                            continue;
                        }
                        p.set(cx + dx, cy + dy, cz + dz);
                        BlockState s = level.getBlockState(p);
                        if (s.is(BlockTags.LEAVES)) {
                            level.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                            if (++stripped % 40 == 0) {
                                level.levelEvent(2001, p, Block.getId(s));
                            }
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ injakan bumi

    private void tickStomp(ServerLevel level, long now) {
        if (actionAge == STOMP_HIT) {
            Vec3 l = landing(level, KalderaBody.FL), r = landing(level, KalderaBody.FR);
            Vec3 c = l.add(r).scale(0.5);
            sound(c, ShazamSounds.KALDERA_STOMP.get(), 14f, pitchJitter());
            for (LivingEntity e : victims(c, 26.0, 12.0)) {
                if (flat(l, e) < 9.0 || flat(r, e) < 9.0) {
                    if (strike(e, STOMP_DMG, false)) {
                        fling(e, c, 1.6, 1.1);
                    }
                }
            }
            if (destroys(level)) {
                InfinityWorld.crater(level, l, STOMP_CRATER, IRRADIATED);
                InfinityWorld.crater(level, r, STOMP_CRATER, IRRADIATED);
            }
            startWave(c, STOMP_RADIUS, STOMP_SPEED, STOMP_WAVE_DMG);
        }
        if (actionAge >= STOMP_TICKS) {
            idleNow(now);
        }
    }

    private void startWave(Vec3 c, double max, double speed, float damage) {
        waveC = c;
        waveR = 6.0;
        waveMax = max;
        waveSpeed = speed;
        waveDmg = damage;
        waveHit.clear();
    }

    /** Gelombang kejut yang merambat di tanah: yang berdiri di tanah saat mukanya lewat terlempar (yang melompat lolos). */
    private void tickWave(ServerLevel level) {
        if (waveC == null) {
            return;
        }
        double r0 = waveR, r1 = waveR + waveSpeed;
        waveR = r1;
        for (LivingEntity e : victims(waveC, r1 + 1.0, 10.0)) {
            double d = flat(waveC, e);
            if (d < r0 - 1.0 || d > r1 + 1.0 || waveHit.contains(e.getUUID()) || !grounded(e)) {
                continue;
            }
            waveHit.add(e.getUUID());
            float k = (float) (1.0 - 0.65 * d / waveMax);
            if (strike(e, waveDmg * k, false)) {
                fling(e, waveC, 1.1 * k, 0.75 * k + 0.25);
            }
        }
        if (waveR >= waveMax) {
            waveC = null;
        }
    }

    // ------------------------------------------------------------------ letusan inti & bongkahan uranium

    private void tickErupt(ServerLevel level, long now) {
        int count = rage ? RAGE_BOMBS : BOMBS;
        int k = actionAge - ERUPT_FIRE;
        if (k == 0) {   // denyut radiasi dari intinya; yang berdiri di dekat kawah terlempar
            Vec3 top = calderaTop();
            for (LivingEntity e : victims(top, 16.0, 16.0)) {
                if (strike(e, 12f, true)) {
                    fling(e, top, 1.4, 1.2);
                }
            }
            pulse(PULSE_R, 0, PULSE_DMG);
        }
        if (k >= 0 && k < count * BOMB_GAP && k % BOMB_GAP == 0) {
            launchBomb(level, now);
        }
        if (actionAge >= ERUPT_TICKS) {
            expose(now);
            idleNow(now);
        }
    }

    private void launchBomb(ServerLevel level, long now) {
        RandomSource r = this.random;
        double tx, tz;
        Vec3 focus = isTamed() ? strikeFocus() : null;   // 0.74 jinak: titik bidik penunggangnya / musuh yang dilawannya
        LivingEntity aim = null;
        if (!isTamed()) {
            aim = r.nextFloat() < 0.6f ? randomPrey(level, 72.0) : null;
        } else if (focus != null && r.nextFloat() < 0.6f) {
            List<LivingEntity> near = foes(focus, 14.0);
            aim = near.isEmpty() ? null : near.get(r.nextInt(near.size()));
        }
        if (aim != null) {
            Vec3 lead = aim.getDeltaMovement().scale(BOMB_FLIGHT * 0.5);
            tx = aim.getX() + lead.x + (r.nextDouble() - 0.5) * 10.0;
            tz = aim.getZ() + lead.z + (r.nextDouble() - 0.5) * 10.0;
        } else if (focus != null) {
            tx = focus.x + (r.nextDouble() - 0.5) * 18.0;
            tz = focus.z + (r.nextDouble() - 0.5) * 18.0;
        } else {
            double a = r.nextDouble() * Math.PI * 2.0, d = 14.0 + r.nextDouble() * 34.0;
            tx = this.getX() + Math.cos(a) * d;
            tz = this.getZ() + Math.sin(a) * d;
        }
        double g = KalderaBody.ground(level, tx, tz);
        Vec3 at = new Vec3(tx, Double.isNaN(g) ? this.getY() : g, tz);
        pending.add(new double[]{at.x, at.y, at.z, now + BOMB_FLIGHT, BOMB});
        anim(ShazamAnim.KALDERA_BOMB, at);
        sound(at, ShazamSounds.KALDERA_BOMB_FLY.get(), 3f, pitchJitter());
    }

    private LivingEntity randomPrey(ServerLevel level, double range) {
        List<LivingEntity> list = new ArrayList<>();
        for (ServerPlayer p : level.players()) {
            if (p.distanceToSqr(this) < range * range && prey(p)) {
                list.add(p);
            }
        }
        if (target != null && prey(target) && !list.contains(target) && target.distanceToSqr(this) < range * range) {
            list.add(target);
        }
        return list.isEmpty() ? null : list.get(this.random.nextInt(list.size()));
    }

    /** Bongkahan & ventilasi yang sedang dalam perjalanan (tetap jatuh walau Kaldera sudah ganti gerakan). */
    private void tickPending(ServerLevel level, long now) {
        if (pending.isEmpty()) {
            return;
        }
        Iterator<double[]> it = pending.iterator();
        List<double[]> due = new ArrayList<>();
        while (it.hasNext()) {
            double[] p = it.next();
            if (p[3] <= now) {
                due.add(p);
                it.remove();
            }
        }
        for (double[] p : due) {
            Vec3 at = new Vec3(p[0], p[1], p[2]);
            switch ((int) p[4]) {
                case BOMB -> bombHit(level, at);
                case SPIKE -> spikeHit(at);
                case CAGE -> cageHit(at, now);
                default -> geyserHit(level, at);
            }
        }
    }

    /** Bongkahan uranium menghantam tanah: ledakan, sakit radiasi, kawah kecil teradiasi, dan zona radiasi beberapa detik. */
    private void bombHit(ServerLevel level, Vec3 at) {
        sound(at, ShazamSounds.KALDERA_BOMB.get(), 5f, pitchJitter());
        for (LivingEntity e : victims(at, BOMB_R, BOMB_R)) {
            double d = Math.sqrt(e.distanceToSqr(at.add(0, 0.5, 0)));
            if (d > BOMB_R + 0.5) {
                continue;
            }
            float f = (float) Mth.clamp(1.0 - d / (BOMB_R + 0.5), 0.25, 1.0);
            if (strike(e, BOMB_DMG * f, true)) {
                fling(e, at, 0.9 * f, 0.5 * f + 0.2);
            }
            irradiate(e, 1, 0f, 140);
        }
        zone(at, ZONE_R, ZONE_TICKS);
        if (destroys(level)) {
            InfinityWorld.crater(level, at, 3, IRRADIATED);
            blight(level, at, 8.0, 24);
        }
    }

    // ------------------------------------------------------------------ radiasi

    /** Dinding kawah teradiasi: tuf, batu dalam, kerikil, tanah kasar, sesekali kristal hijau yang menyala. */
    private static final InfinityWorld.Rim IRRADIATED = (d, f) -> (d < 0.75
            ? (f < 0.1f ? Blocks.VERDANT_FROGLIGHT : f < 0.4f ? Blocks.TUFF : f < 0.7f ? Blocks.COBBLED_DEEPSLATE : Blocks.GRAVEL)
            : (f < 0.04f ? Blocks.VERDANT_FROGLIGHT : f < 0.4f ? Blocks.COARSE_DIRT : f < 0.65f ? Blocks.GRAVEL : f < 0.85f ? Blocks.TUFF
            : Blocks.PODZOL)).defaultBlockState();

    /**
     * Sakit radiasi. strength 0: lapar; 1: + racun & lemah; 2: + layu & semuanya lebih parah. Damage-nya sihir (menembus
     * zirah & perisai). ticks = lama efeknya (aura & zona memperbaruinya tiap detik).
     */
    private void irradiate(LivingEntity e, int strength, float damage, int ticks) {
        if (!victim(e)) {
            return;
        }
        int shield = radShield(e);   // 0.75 Zirah Antiradiasi: tiap bagian menahan 25%, satu set penuh = kebal
        if (shield > 0 && this.random.nextInt(3) == 0) {
            wearSuit(e);
        }
        if (shield >= 4) {
            return;
        }
        float keep = 1f - 0.25f * shield;
        ticks = Math.max(20, Math.round(ticks * keep));
        damage *= keep;
        int s = Mth.clamp(strength - (shield >= 2 ? 1 : 0), 0, 2);
        e.addEffect(new MobEffectInstance(MobEffects.HUNGER, ticks, s), this);
        if (s >= 1) {
            e.addEffect(new MobEffectInstance(MobEffects.POISON, ticks, s - 1), this);
            e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, s - 1), this);
        }
        if (s >= 2) {
            e.addEffect(new MobEffectInstance(MobEffects.WITHER, ticks, 0), this);
        }
        if (damage > 0f) {
            e.invulnerableTime = 0;
            e.hurt(this.damageSources().indirectMagic(this, this), damage * power());
        }
    }

    /** 0.75 Berapa bagian Zirah Antiradiasi yang dipakai e (0-4); 4 = kebal radiasi KALDERA (server & client). */
    public static int radShield(LivingEntity e) {
        int n = 0;
        if (e.getItemBySlot(EquipmentSlot.HEAD).is(KalderaItems.ANTIRAD_HELMET.get())) {
            n++;
        }
        if (e.getItemBySlot(EquipmentSlot.CHEST).is(KalderaItems.ANTIRAD_CHEST.get())) {
            n++;
        }
        if (e.getItemBySlot(EquipmentSlot.LEGS).is(KalderaItems.ANTIRAD_LEGS.get())) {
            n++;
        }
        if (e.getItemBySlot(EquipmentSlot.FEET).is(KalderaItems.ANTIRAD_BOOTS.get())) {
            n++;
        }
        return n;
    }

    /** Lempeng zirahnya terkikis sedikit tiap menahan radiasi. */
    private static void wearSuit(LivingEntity e) {
        for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack stack = e.getItemBySlot(slot);
            if (stack.getItem() instanceof AntiradArmorItem) {
                stack.hurtAndBreak(1, e, slot);
            }
        }
    }

    private List<LivingEntity> nearBody(double radius) {
        return victims(center().add(0, 30, 0), radius + 46.0, radius + 36.0);
    }

    /** Aura radiasi: tiap detik yang dekat tubuhnya kena sakit radiasi (penuh saat menempel, cepat mengecil menjauh). */
    private void tickAura() {
        if (this.tickCount % 20 != 7 || !radiating()) {
            return;
        }
        double r = auraRadius();
        for (LivingEntity e : nearBody(r)) {
            double d = partDistance(e);
            if (d > r) {
                continue;
            }
            float u = (float) (1.0 - d / r);
            irradiate(e, (u > 0.7f ? 1 : 0) + (rage ? 1 : 0), AURA_DMG * (0.15f + 0.85f * u * u), 90);
        }
    }

    /** Denyut radiasi dari intinya: semua yang dekat tubuhnya kena sakit radiasi sekaligus, makin dekat makin parah. */
    private void pulse(double radius, int strength, float damage) {
        for (LivingEntity e : nearBody(radius)) {
            double d = partDistance(e);
            if (d > radius) {
                continue;
            }
            float u = (float) (1.0 - d / radius);
            irradiate(e, strength + (u > 0.6f ? 1 : 0), damage * (0.3f + 0.7f * u), 160);
        }
    }

    /** Zona radiasi baru (sisa bongkahan uranium / ventilasi). */
    private void zone(Vec3 at, double radius, int ticks) {
        if (zones.size() >= 48) {
            zones.remove(0);
        }
        zones.add(new double[]{at.x, at.y, at.z, this.level().getGameTime() + ticks, radius});
    }

    /** Yang berdiri di zona radiasi kena sakit radiasi tiap detik (zona yang bertumpuk menambah dosisnya). */
    private void tickZones(long now) {
        if (zones.isEmpty()) {
            return;
        }
        zones.removeIf(z -> z[3] <= now);
        if (this.tickCount % 20 != 13) {
            return;
        }
        for (double[] z : zones) {
            Vec3 c = new Vec3(z[0], z[1], z[2]);
            for (LivingEntity e : victims(c, z[4], 4.0)) {
                if (flat(c, e) <= z[4] && e.getY() > c.y - 1.5 && e.getY() < c.y + 3.5) {
                    irradiate(e, 1 + (rage ? 1 : 0), ZONE_DMG, 90);
                }
            }
        }
    }

    /** Radiasi mematikan tanah: tanaman layu (hilang / jadi semak mati), rumput & lumut jadi tanah kasar. */
    private void blight(ServerLevel level, Vec3 c, double radius, int tries) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int i = 0; i < tries; i++) {
            double a = this.random.nextDouble() * Math.PI * 2.0, d = Math.sqrt(this.random.nextDouble()) * radius;
            int x = Mth.floor(c.x + Math.cos(a) * d), z = Mth.floor(c.z + Math.sin(a) * d);
            p.set(x, Mth.floor(c.y), z);
            if (!level.isLoaded(p)) {
                continue;
            }
            p.setY(level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1);
            BlockState s = level.getBlockState(p);
            boolean wilted = false;
            for (int k = 0; k < 2 && s.getBlock() instanceof BushBlock; k++) {   // tanaman (dua blok untuk yang tinggi)
                level.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                wilted = true;
                p.move(0, -1, 0);
                s = level.getBlockState(p);
            }
            if (s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.MYCELIUM) || s.is(Blocks.MOSS_BLOCK) || s.is(Blocks.DIRT)
                    || s.is(Blocks.ROOTED_DIRT)) {
                level.setBlock(p, (this.random.nextInt(4) == 0 ? Blocks.PODZOL : Blocks.COARSE_DIRT).defaultBlockState(), Block.UPDATE_CLIENTS);
                p.move(0, 1, 0);
                if (wilted && this.random.nextInt(3) == 0 && level.getBlockState(p).isAir()) {
                    level.setBlock(p, Blocks.DEAD_BUSH.defaultBlockState(), Block.UPDATE_CLIENTS);
                }
            }
        }
    }

    /** Sesudah meletus / ambruk: kawahnya terbuka & rapuh beberapa detik. */
    private void expose(long now) {
        exposedUntil = now + EXPOSED_TICKS;
        this.entityData.set(DATA_EXPOSED, (int) exposedUntil);
        anim(ShazamAnim.KALDERA_EXPOSED, calderaTop());
        tell(Component.translatable("message.shazammod.kaldera_exposed").withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD), 120.0);
        updateBar();
    }

    // ------------------------------------------------------------------ ventilasi radiasi

    private void tickGeyser(ServerLevel level, long now) {
        if (actionAge == GEYSER_SLAM) {
            Vec3 f = landing(level, KalderaBody.FR);
            sound(f, ShazamSounds.KALDERA_STEP.get(), 8f, 0.8f);
            for (LivingEntity e : victims(f, KalderaBody.FOOT_R + 2.0, 6.0)) {
                if (strike(e, STEP_DMG, false)) {
                    fling(e, f, 1.0, 0.9);
                }
            }
            if (destroys(level)) {
                footprint(level, f, KalderaBody.FOOT_R + 1f);
            }
            List<Vec3> spots = new ArrayList<>();
            if (isTamed()) {   // 0.74 jinak: di titik bidik penunggangnya / musuh yang dilawannya, berderet dari kakinya ke sana
                Vec3 focus = strikeFocus();
                if (focus != null) {
                    spots.add(spot(level, focus.x, focus.z));
                    for (LivingEntity e : foes(focus, 18.0)) {
                        spots.add(spot(level, e.getX() + e.getDeltaMovement().x * 8.0, e.getZ() + e.getDeltaMovement().z * 8.0));
                    }
                    for (int i = 1; i <= 5; i++) {
                        double u = i / 6.0;
                        spots.add(spot(level, Mth.lerp(u, f.x, focus.x), Mth.lerp(u, f.z, focus.z)));
                    }
                }
            } else {
                for (ServerPlayer p : level.players()) {
                    if (p.distanceToSqr(this) < 80.0 * 80.0 && prey(p)) {
                        spots.add(spot(level, p.getX() + p.getDeltaMovement().x * 8.0, p.getZ() + p.getDeltaMovement().z * 8.0));
                    }
                }
                if (target != null && !(target instanceof Player) && prey(target)) {
                    spots.add(spot(level, target.getX(), target.getZ()));
                }
                if (rage && target != null) {   // kritis: ventilasi berderet dari kakinya ke mangsanya
                    for (int i = 1; i <= 5; i++) {
                        double u = i / 6.0;
                        spots.add(spot(level, Mth.lerp(u, f.x, target.getX()), Mth.lerp(u, f.z, target.getZ())));
                    }
                }
            }
            for (int i = 0; i < 3; i++) {   // beberapa di sekitar kakinya
                double a = this.random.nextDouble() * Math.PI * 2.0, d = 10.0 + this.random.nextDouble() * 20.0;
                spots.add(spot(level, f.x + Math.cos(a) * d, f.z + Math.sin(a) * d));
            }
            int n = 0;
            for (Vec3 s : spots) {
                if (n++ >= 14) {
                    break;
                }
                pending.add(new double[]{s.x, s.y, s.z, now + GEYSER_DELAY, GEYSER_HIT});
                anim(ShazamAnim.KALDERA_GEYSER_MARK, s);
                sound(s, ShazamSounds.KALDERA_GEYSER_WARN.get(), 2.5f, pitchJitter());
            }
        }
        if (actionAge >= GEYSER_TICKS) {
            idleNow(now);
        }
    }

    private Vec3 spot(ServerLevel level, double x, double z) {
        double g = KalderaBody.ground(level, x, z);
        return new Vec3(x, Double.isNaN(g) ? this.getY() : g, z);
    }

    /** Ventilasi radiasi menyembur: yang di atasnya terlempar ke atas, sakit radiasi, dan zona radiasi kecil tertinggal. */
    private void geyserHit(ServerLevel level, Vec3 at) {
        sound(at, ShazamSounds.KALDERA_GEYSER.get(), 5f, pitchJitter());
        for (LivingEntity e : victims(at.add(0, GEYSER_H * 0.5, 0), GEYSER_R, GEYSER_H * 0.5 + 1.0)) {
            if (flat(at, e) > GEYSER_R || e.getY() < at.y - 1.5) {
                continue;
            }
            if (strike(e, GEYSER_DMG, false)) {
                e.push(0, 1.6, 0);
                e.hurtMarked = true;
            }
            irradiate(e, 1 + (rage ? 1 : 0), 0f, 140);
        }
        zone(at, VENT_ZONE_R, VENT_ZONE_TICKS);
        if (destroys(level)) {   // lubang ventilasinya: tuf & batu dalam, kerikil di tepinya, intinya kristal hijau
            BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
            int cx = Mth.floor(at.x), cy = Mth.floor(at.y) - 1, cz = Mth.floor(at.z);
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    int d2 = dx * dx + dz * dz;
                    if (d2 > 5 || (d2 > 0 && this.random.nextFloat() > 0.7f)) {
                        continue;
                    }
                    p.set(cx + dx, cy, cz + dz);
                    BlockState s = level.getBlockState(p);
                    if (breakable(level, p, s) && KalderaBody.solidGround(s)) {
                        Block b = d2 == 0 ? Blocks.VERDANT_FROGLIGHT : d2 <= 2 ? (this.random.nextBoolean() ? Blocks.TUFF
                                : Blocks.COBBLED_DEEPSLATE) : this.random.nextBoolean() ? Blocks.GRAVEL : Blocks.COARSE_DIRT;
                        level.setBlock(p, b.defaultBlockState(), Block.UPDATE_CLIENTS);
                    }
                }
            }
            blight(level, at, 5.0, 12);
        }
    }

    // ------------------------------------------------------------------ gunung runtuh (kritis)

    private void tickFall(ServerLevel level, long now) {
        if (actionAge == FALL_HIT) {
            Vec3 c = center();
            sound(c, ShazamSounds.KALDERA_STOMP.get(), 16f, 0.75f);
            for (LivingEntity e : victims(c, FALL_R, 30.0)) {
                double d = flat(c, e);
                if (d < FALL_R && e.getY() < c.y + 28.0) {
                    if (strike(e, FALL_DMG * (float) (1.0 - 0.5 * d / FALL_R), false)) {
                        fling(e, c, 2.0, 1.0);
                    }
                }
            }
            if (destroys(level)) {
                InfinityWorld.crater(level, c, FALL_CRATER, IRRADIATED);
            }
            startWave(c, FALL_WAVE_RADIUS, 1.4, FALL_WAVE_DMG);
            expose(now);
        }
        if (actionAge >= FALL_TICKS) {
            idleNow(now);
        }
    }

    // ------------------------------------------------------------------ kritis (fase 2)

    private void enterRage(long now) {
        rage = true;
        this.entityData.set(DATA_RAGE, true);
        act(Action.RAGE);
        Vec3 top = calderaTop();
        anim(ShazamAnim.KALDERA_RAGE, top);
        sound(top, ShazamSounds.KALDERA_RAGE.get(), 18f, 1f);
        tell(Component.translatable("message.shazammod.kaldera_rage").withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD), 200.0);
        nextStomp = Math.min(nextStomp, now + 160);
        nextFall = Math.min(nextFall, now + 260);
        updateBar();
    }

    private void tickRage(ServerLevel level, long now) {
        if (actionAge == ROAR_HIT) {
            roarBlast(level, 1.2f);
        }
        int k = actionAge - RAGE_BURST;
        if (k == 0) {   // intinya meledak jadi kritis: denyut radiasi besar + gelombang kejut
            startWave(center(), 36.0, 1.3, 16f);
            pulse(PULSE_R * 1.2, 1, PULSE_DMG * 1.25f);
        }
        if (k >= 0 && k < RAGE_BOMBS * 2 && k % 2 == 0) {
            launchBomb(level, now);
        }
        if (actionAge >= RAGE_TICKS) {
            idleNow(now);
        }
    }

    // ------------------------------------------------------------------ menghancurkan apa yang dilewati

    /**
     * Ruang yang diisi tubuhnya dikosongkan: badan, kawah, kepala, dan tiang-tiang kakinya menerobos pepohonan, bukit, dan
     * bangunan. Tiap tick cuma seperempat lapisan (bergiliran) dan paling banyak CARVE_PER_TICK blok, kolom yang seluruhnya
     * di bawah ruang itu dilewati, dan tanah tempat kakinya berpijak nggak pernah ikut dikeruk.
     */
    private void carve(ServerLevel level) {
        if (!destroys(level) || action == Action.DEATH || action == Action.SINK || action == Action.RUMBLE) {
            plow = 0;
            return;
        }
        boolean moved = Double.isNaN(carvedX) || Math.abs(this.getX() - carvedX) + Math.abs(this.getZ() - carvedZ) > 0.05
                || Math.abs(Mth.wrapDegrees(this.getYRot() - carvedYaw)) > 0.2f || action != Action.IDLE;
        if (!moved && this.tickCount % 10 != 0) {
            plow = plow * 3 / 4;
            return;
        }
        carvedX = this.getX();
        carvedZ = this.getZ();
        carvedYaw = this.getYRot();
        carveLayer = (carveLayer + 1) & 3;
        crumbles = 0;
        int[] budget = {CARVE_PER_TICK};
        int floor = Mth.floor(this.getY()) + 1;
        int removed = 0;
        removed += ellipsoid(level, 0f, KalderaBody.BODY_Y, 11f, 16.5f, 12f, 15f, floor, budget);
        removed += ellipsoid(level, 0f, KalderaBody.BODY_Y + 1f, -15f, 18f, 12.5f, 16f, floor, budget);
        removed += ellipsoid(level, 0f, KalderaBody.CALDERA_Y - 9f, KalderaBody.CALDERA_Z, 15f, 10f, 15f, floor, budget);
        KalderaBody.headLocal(pose, 0f, 0f, KalderaBody.HEAD_LEN * 0.5f, v);
        removed += ellipsoidLocal(level, v[0], v[1], v[2], 10f, 8f, 13f, floor, budget);
        for (int i = 0; i < 4; i++) {
            removed += column(level, legs[i].getX(), legs[i].getZ(), Math.max(floor, Mth.floor(footY[i]) + 1),
                    Mth.floor(this.getY() + KalderaBody.PIVOT_Y + pose.bodyY + 1.0), KalderaBody.LEG_R + 0.5f, budget);
        }
        plow = plow * 3 / 4 + removed;
    }

    private int ellipsoid(ServerLevel level, float x, float y, float z, float rx, float ry, float rz, int floor, int[] budget) {
        KalderaBody.body(pose, x, y, z, w);
        return ellipsoidLocal(level, w[0], w[1], w[2], rx, ry, rz, floor, budget);
    }

    private int ellipsoidLocal(ServerLevel level, float lx, float ly, float lz, float rx, float ry, float rz, int floor, int[] budget) {
        if (budget[0] <= 0) {
            return 0;
        }
        float yaw = this.getYRot();
        double cx = KalderaBody.worldX(this.getX(), yaw, lx, lz), cz = KalderaBody.worldZ(this.getZ(), yaw, lx, lz);
        double cy = this.getY() + ly;
        float a = yaw * Mth.DEG_TO_RAD, ca = Mth.cos(a), sa = Mth.sin(a);
        int reach = Mth.ceil(Math.max(rx, rz));
        int y0 = Math.max(floor, Mth.floor(cy - ry)), y1 = Mth.floor(cy + ry);
        if (y1 < y0) {
            return 0;
        }
        int ix0 = Mth.floor(cx) - reach, iz0 = Mth.floor(cz) - reach;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int removed = 0;
        for (int ix = ix0; ix <= ix0 + 2 * reach; ix++) {
            for (int iz = iz0; iz <= iz0 + 2 * reach; iz++) {
                double dx = ix + 0.5 - cx, dz = iz + 0.5 - cz;
                double ex = (dx * ca + dz * sa) / rx, ez = (-dx * sa + dz * ca) / rz;
                double h = 1.0 - ex * ex - ez * ez;
                if (h <= 0.0) {
                    continue;
                }
                int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, ix, iz);   // kolom di bawah ruangnya: lewati
                double half = Math.sqrt(h) * ry;
                int ya = Math.max(y0, Mth.floor(cy - half)), yb = Math.min(y1, Math.min(top, Mth.floor(cy + half)));
                for (int iy = ya + Math.floorMod(carveLayer - ya, 4); iy <= yb; iy += 4) {
                    p.set(ix, iy, iz);
                    if (smash(level, p)) {
                        removed++;
                        if (--budget[0] <= 0) {
                            return removed;
                        }
                    }
                }
            }
        }
        return removed;
    }

    private int column(ServerLevel level, double x, double z, int y0, int y1, float r, int[] budget) {
        if (budget[0] <= 0 || y1 < y0) {
            return 0;
        }
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int reach = Mth.ceil(r), removed = 0;
        for (int ix = Mth.floor(x) - reach; ix <= Mth.floor(x) + reach; ix++) {
            for (int iz = Mth.floor(z) - reach; iz <= Mth.floor(z) + reach; iz++) {
                double dx = ix + 0.5 - x, dz = iz + 0.5 - z;
                if (dx * dx + dz * dz > r * r) {
                    continue;
                }
                int top = Math.min(y1, level.getHeight(Heightmap.Types.MOTION_BLOCKING, ix, iz));
                for (int iy = y0 + Math.floorMod(carveLayer - y0, 4); iy <= top; iy += 4) {
                    p.set(ix, iy, iz);
                    if (smash(level, p)) {
                        removed++;
                        if (--budget[0] <= 0) {
                            return removed;
                        }
                    }
                }
            }
        }
        return removed;
    }

    static boolean breakable(ServerLevel level, BlockPos pos, BlockState state) {
        return !state.isAir() && level.isLoaded(pos) && state.getDestroySpeed(level, pos) >= 0f && !state.is(BlockTags.WITHER_IMMUNE)
                && level.getBlockEntity(pos) == null;
    }

    /** Hancurkan satu blok (tanpa jatuhan barang; air & lahar dibiarkan). */
    private boolean smash(ServerLevel level, BlockPos p) {
        BlockState s = level.getBlockState(p);
        if (!breakable(level, p, s) || !s.getFluidState().isEmpty()) {
            return false;
        }
        level.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
        if (crumbles < 3 && this.random.nextInt(40) == 0) {   // pecahan & suara blok remuk (sesekali saja)
            crumbles++;
            level.levelEvent(2001, p, Block.getId(s));
        }
        return true;
    }

    /** Jejak telapak: yang ada di atas tanah remuk, tanahnya amblas satu blok dan teradiasi (tanah kasar, tuf, kerikil). */
    private void footprint(ServerLevel level, Vec3 f, float radius) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        int cx = Mth.floor(f.x), cz = Mth.floor(f.z), gy = Mth.floor(f.y);
        int reach = Mth.ceil(radius);
        for (int dx = -reach; dx <= reach; dx++) {
            for (int dz = -reach; dz <= reach; dz++) {
                double d2 = (dx + 0.5 - (f.x - cx)) * (dx + 0.5 - (f.x - cx)) + (dz + 0.5 - (f.z - cz)) * (dz + 0.5 - (f.z - cz));
                if (d2 > radius * radius) {
                    continue;
                }
                for (int y = gy; y < gy + 9; y++) {
                    p.set(cx + dx, y, cz + dz);
                    smash(level, p);
                }
                boolean inner = d2 <= radius * radius * 0.6;
                p.set(cx + dx, gy - 1, cz + dz);
                BlockState top = level.getBlockState(p);
                if (inner && breakable(level, p, top) && top.getFluidState().isEmpty()) {
                    level.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                    p.set(cx + dx, gy - 2, cz + dz);
                    scorch(level, p);
                } else if (this.random.nextFloat() < 0.35f) {
                    scorch(level, p);
                }
            }
        }
    }

    private void scorch(ServerLevel level, BlockPos p) {
        BlockState s = level.getBlockState(p);
        if (!breakable(level, p, s) || !KalderaBody.solidGround(s) || s.is(Blocks.VERDANT_FROGLIGHT)) {
            return;
        }
        float f = this.random.nextFloat();
        Block b = f < 0.06f ? Blocks.VERDANT_FROGLIGHT : f < 0.38f ? Blocks.COARSE_DIRT : f < 0.62f ? Blocks.TUFF : f < 0.82f ? Blocks.GRAVEL
                : Blocks.PODZOL;
        level.setBlock(p, b.defaultBlockState(), Block.UPDATE_CLIENTS);
    }

    // ------------------------------------------------------------------ tubuh radioaktif

    /** Yang menempel / masuk ke tubuhnya kena luka radiasi parah & didorong keluar. */
    private void contact(ServerLevel level) {
        Vec3 c = center();
        for (LivingEntity e : victims(c.add(0, 30, 0), 38.0, 40.0)) {
            Vec3 from = null;
            for (KalderaPart part : parts) {
                if (part.getBoundingBox().inflate(0.6).intersects(e.getBoundingBox())) {
                    from = part.position();
                    break;
                }
            }
            if (from == null) {
                continue;
            }
            strike(e, CONTACT_DMG, false);
            irradiate(e, 2, 0f, 90);
            fling(e, from, 0.9, 0.3);
        }
    }

    // ------------------------------------------------------------------ damage

    /** Damage dari salah satu bagian tubuhnya (kepala & kawah yang terbuka lebih rapuh, kaki batunya keras). */
    public boolean hurtFromPart(KalderaPart part, DamageSource source, float amount) {
        float k = switch (part.kind) {
            case HEAD -> HEAD_WEAK;
            case CORE -> exposedUntil > this.level().getGameTime() ? CORE_WEAK : 1f;
            case LEG -> LEG_ARMOR;
            default -> 1f;
        };
        return this.hurt(source, amount * k);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide) {
            return false;
        }
        if (source.is(DamageTypes.GENERIC_KILL) || source.is(DamageTypes.FELL_OUT_OF_WORLD)) {
            return super.hurt(source, amount);
        }
        if (isTamed() && source.getEntity() != null && (isOwner(source.getEntity()) || source.getEntity().getVehicle() == this)) {
            return false;   // 0.74 pukulan / tembakan pemiliknya sendiri
        }
        if (untouchable() || source.getEntity() == this || source.is(DamageTypeTags.IS_FALL) || source.is(DamageTypes.IN_WALL)
                || source.is(DamageTypes.DROWN) || source.is(DamageTypes.CRAMMING) || source.is(DamageTypes.CACTUS)
                || source.is(DamageTypes.SWEET_BERRY_BUSH) || source.is(DamageTypes.FLY_INTO_WALL) || source.is(DamageTypes.STARVE)) {
            return false;
        }
        float k = 1f;
        if (source.is(DamageTypeTags.IS_PROJECTILE)) {
            k *= PROJECTILE_ARMOR;
        }
        if (source.is(DamageTypeTags.IS_EXPLOSION)) {
            k *= BLAST_ARMOR;
        }
        boolean hit = super.hurt(source, amount * k);
        if (hit) {
            lastCombat = this.level().getGameTime();
        }
        if (hit && !rage && !isTamed() && this.getHealth() <= this.getMaxHealth() * RAGE_AT) {
            rageQueued = true;
        }
        return hit;
    }

    @Override
    public boolean canBeAffected(MobEffectInstance effect) {
        return false;   // gunung nggak bisa diracun
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    protected void pushEntities() {
    }

    @Override
    public void push(double x, double y, double z) {
    }

    @Override
    public void push(Entity entity) {
    }

    /** Damage yang bakal menghabisinya: badannya nggak langsung lenyap, tapi tumbang & membatu dulu (aksi DEATH). */
    @Override
    public void die(DamageSource source) {
        if (this.level().isClientSide || source.is(DamageTypes.GENERIC_KILL) || source.is(DamageTypes.FELL_OUT_OF_WORLD)) {
            super.die(source);
            return;
        }
        this.setHealth(1f);
        if (action != Action.DEATH) {
            startDeath();
        }
    }

    // ------------------------------------------------------------------ tumbang & membatu

    private void startDeath() {
        act(Action.DEATH);
        pending.clear();
        traps.clear();
        waveC = null;
        target = null;
        this.entityData.set(DATA_TARGET, -1);
        this.entityData.set(DATA_EXPOSED, 0);
        exposedUntil = 0;
        bar.setProgress(0f);
        anim(ShazamAnim.KALDERA_DEATH, center());
        sound(center(), ShazamSounds.KALDERA_DEATH.get(), 18f, 1f);
        if (isTamed()) {   // 0.74 penunggangnya diturunkan dulu dengan selamat
            ejectRiders();
            if (this.level() instanceof ServerLevel level && owner != null && level.getPlayerByUUID(owner) instanceof ServerPlayer o) {
                o.sendSystemMessage(Component.translatable("message.shazammod.kaldera_owner_dead").withStyle(ChatFormatting.RED));
            }
        }
    }

    private void tickDying(ServerLevel level) {
        if (actionAge == DEATH_COLLAPSE) {   // badannya ambruk: yang di bawahnya terlempar keluar
            Vec3 c = center();
            for (LivingEntity e : victims(c, 26.0, 30.0)) {
                if (flat(c, e) < 24.0) {
                    fling(e, c, 1.6, 0.6);
                }
            }
        }
        if (actionAge == DEATH_STONE - 10 && destroys(level)) {
            planMountain(level);
        }
        if (mountain != null && actionAge >= DEATH_STONE) {
            int end = actionAge >= DEATH_TICKS ? mountain.size()
                    : Math.min(mountain.size(), (int) Math.ceil((actionAge - DEATH_STONE + 1) * mountainPerTick));
            buildMountain(level, end);
        }
        if (actionAge >= DEATH_TICKS) {
            if (!isTamed()) {   // yang jinak tumbang tanpa hadiah
                dropRewards(level);
            }
            tell(Component.translatable("message.shazammod.kaldera_dead").withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), 200.0);
            this.discard();
        }
    }

    /**
     * Rencana gunung batu di tempat badannya ambruk: lonjong mengikuti badannya, batu dalam & tuf, lereng berurat kristal
     * hijau yang menyala, dan kawah kecil dengan kolam kaca hijau di atas dasar kristal yang menyala.
     */
    private void planMountain(ServerLevel level) {
        List<int[]> plan = new ArrayList<>();
        RandomSource r = this.random;
        float yaw = this.getYRot();
        double base = this.getY();
        double ax = 23.0, az = 30.0, peakH = 30.0, crater = 5.0;
        long seed = r.nextLong();
        int reach = (int) Math.ceil(az);
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        Vec3 mid = world(0f, 0f, -3f);
        for (int dx = -reach; dx <= reach; dx++) {
            for (int dz = -reach; dz <= reach; dz++) {
                int x = Mth.floor(mid.x) + dx, z = Mth.floor(mid.z) + dz;
                KalderaBody.toLocal(mid.x, mid.z, yaw, x + 0.5, z + 0.5, w);
                double ex = w[0] / ax, ez = w[1] / az;
                double d = Math.sqrt(ex * ex + ez * ez);
                double ang = Math.atan2(w[1], w[0]);
                double rough = 1.0 + 0.12 * Math.sin(ang * 5.0 + seed % 7) + 0.07 * Math.sin(ang * 11.0 + seed % 13)
                        + 0.05 * (r.nextDouble() - 0.5);
                if (d > rough) {
                    continue;
                }
                double u = d / rough;
                double h = peakH * Math.pow(1.0 - u * u, 0.85);
                double cr = crater / (ax * rough);
                boolean inCrater = u < cr;
                int top = Mth.floor(base + h - (inCrater ? 4.0 * (1.0 - u / cr) : 0.0));
                int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                for (int y = Math.min(ground, Mth.floor(base) + 1); y <= top; y++) {
                    p.set(x, y, z);
                    BlockState s = level.getBlockState(p);
                    if (!(s.isAir() || s.canBeReplaced() || !s.getFluidState().isEmpty() || s.is(BlockTags.LEAVES) || s.is(BlockTags.LOGS))) {
                        continue;
                    }
                    if (!s.isAir() && !breakable(level, p, s)) {
                        continue;
                    }
                    double hh = (y - base) / peakH;
                    boolean surface = y == top;
                    int block;
                    if (inCrater) {   // kolam kaca hijau di atas dasar kristal yang menyala, dinding batu dalam & tuf
                        boolean pool = u < cr * 0.6;
                        block = pool && surface ? 6 : pool && y == top - 1 ? 5 : surface ? (r.nextBoolean() ? 1 : 3) : 0;
                    } else if (surface) {
                        float f = r.nextFloat();
                        block = hh > 0.75 ? (f < 0.4f ? 1 : f < 0.65f ? 2 : f < 0.85f ? 3 : f < 0.95f ? 0 : 5)
                                : (f < 0.3f ? 3 : f < 0.5f ? 4 : f < 0.7f ? 1 : f < 0.85f ? 2 : f < 0.96f ? 0 : 5);
                    } else {
                        float f = r.nextFloat();
                        block = f < 0.55f ? 0 : f < 0.8f ? 3 : 2;
                    }
                    plan.add(new int[]{x, y, z, block});
                }
            }
        }
        plan.sort((a, b) -> Integer.compare(a[1], b[1]));   // dari bawah ke atas: gunungnya seperti tumbuh
        mountain = plan;
        mountainIndex = 0;
        mountainPerTick = Math.max(1.0, plan.size() / (double) Math.max(1, DEATH_TICKS - DEATH_STONE - 10));
    }

    private static final Block[] MOUNTAIN = {Blocks.DEEPSLATE, Blocks.COBBLED_DEEPSLATE, Blocks.SMOOTH_BASALT, Blocks.TUFF,
            Blocks.COARSE_DIRT, Blocks.VERDANT_FROGLIGHT, Blocks.LIME_STAINED_GLASS};

    private void buildMountain(ServerLevel level, int end) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (; mountainIndex < end; mountainIndex++) {
            int[] b = mountain.get(mountainIndex);
            p.set(b[0], b[1], b[2]);
            if (!level.isLoaded(p)) {
                continue;
            }
            level.setBlock(p, MOUNTAIN[b[3]].defaultBlockState(), Block.UPDATE_CLIENTS);
        }
    }

    private void dropRewards(ServerLevel level) {
        Vec3 at = headPoint(0f, 0f, KalderaBody.HEAD_LEN + 6f);
        double g = KalderaBody.ground(level, at.x, at.z);
        Vec3 pos = new Vec3(at.x, (Double.isNaN(g) ? this.getY() : g) + 0.5, at.z);
        ExperienceOrb.award(level, pos, XP);
        ItemStack[] loot = {new ItemStack(Items.NETHER_STAR), new ItemStack(Items.NETHERITE_INGOT, 2), new ItemStack(Items.DIAMOND, 10),
                new ItemStack(Items.ANCIENT_DEBRIS, 4), new ItemStack(Items.EMERALD, 16), new ItemStack(Items.VERDANT_FROGLIGHT, 8),
                new ItemStack(KalderaItems.ANTIRAD_PLATE.get(), 8)};   // 0.75 bahan Zirah Antiradiasi
        for (ItemStack stack : loot) {
            ItemEntity item = new ItemEntity(level, pos.x, pos.y, pos.z, stack);
            item.setDefaultPickUpDelay();
            item.setGlowingTag(true);
            level.addFreshEntity(item);
        }
    }

    // ------------------------------------------------------------------ 0.74 jinak & ditunggangi

    /** Nilai Batu Cryon di tangan: Pecahan Cryon = 1, Bijih Cryon = 3, lainnya 0. */
    private static int cryonValue(ItemStack stack) {
        if (stack.is(LintangItems.KELAM_SHARD.get())) {
            return 1;
        }
        return stack.is(LintangItems.KELAM_ORE_ITEM.get()) ? 3 : 0;
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        return interactFrom(player, hand);
    }

    /**
     * Klik kanan badan / salah satu bagiannya. Liar: Batu Cryon saat INTI TERBUKA menjinakkannya sedikit demi sedikit.
     * Jinak (cuma pemiliknya): Batu Cryon menyembuhkan, jongkok + klik = diam / ikut, selain itu = naik ke dahinya.
     */
    public InteractionResult interactFrom(Player player, InteractionHand hand) {
        Action a = action();
        if (a == Action.DEATH || a == Action.SINK || a == Action.EMERGE || a == Action.RUMBLE || recalled || player.isSpectator()) {
            return InteractionResult.PASS;
        }
        boolean client = this.level().isClientSide;
        ItemStack stack = player.getItemInHand(hand);
        int cryon = cryonValue(stack);
        if (!isTamed()) {
            if (cryon <= 0) {
                return InteractionResult.PASS;
            }
            if (!client) {
                feed(player, stack, cryon);
            }
            return InteractionResult.sidedSuccess(client);
        }
        if (!isOwner(player)) {
            if (!client) {
                player.displayClientMessage(Component.translatable("message.shazammod.kaldera_not_yours", ownerName)
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return InteractionResult.PASS;
        }
        if (cryon > 0 && this.getHealth() < this.getMaxHealth()) {
            if (!client) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                float amount = CRYON_HEAL * cryon;
                this.heal(amount);
                anim(ShazamAnim.KALDERA_FEED, player.getEyePosition());
                sound(calderaTop(), ShazamSounds.KALDERA_FEED.get(), 8f, 1.1f);
                player.displayClientMessage(Component.translatable("message.shazammod.kaldera_heal", (int) amount)
                        .withStyle(ChatFormatting.GREEN), true);
            }
            return InteractionResult.sidedSuccess(client);
        }
        if (player.isSecondaryUseActive()) {
            if (!client) {
                stay = !stay;
                following = false;
                player.displayClientMessage(Component.translatable(stay ? "message.shazammod.kaldera_stay"
                        : "message.shazammod.kaldera_follow").withStyle(ChatFormatting.GREEN), true);
            }
            return InteractionResult.sidedSuccess(client);
        }
        if (!player.isPassenger() && this.getPassengers().isEmpty()) {
            if (!client && player.startRiding(this)) {   // di chat: bar aksi sedang dipakai pesan "Shift untuk turun"
                player.displayClientMessage(Component.translatable("message.shazammod.kaldera_ride").withStyle(ChatFormatting.GREEN), false);
            }
            return InteractionResult.sidedSuccess(client);
        }
        return InteractionResult.PASS;
    }

    /** Batu Cryon diserap intinya yang terbuka: 3 poin = jinak. */
    private void feed(Player player, ItemStack stack, int cryon) {
        if (exposedUntil <= this.level().getGameTime()) {
            player.displayClientMessage(Component.translatable("message.shazammod.kaldera_tame_closed").withStyle(ChatFormatting.YELLOW),
                    true);
            return;
        }
        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        tameProgress += cryon;
        anim(ShazamAnim.KALDERA_FEED, player.getEyePosition());
        sound(calderaTop(), ShazamSounds.KALDERA_FEED.get(), 8f, 1f);
        if (tameProgress >= TAME_NEEDED && player instanceof ServerPlayer sp) {
            tame(sp);
        } else {
            player.displayClientMessage(Component.translatable("message.shazammod.kaldera_tame_progress",
                    Math.min(tameProgress, TAME_NEEDED), TAME_NEEDED).withStyle(ChatFormatting.GREEN), true);
        }
    }

    /** Jadikan milik p (tanpa efek): pemilik disinkronkan, bar darahnya jadi milik p seorang. */
    private void adopt(ServerPlayer p) {
        owner = p.getUUID();
        ownerName = p.getGameProfile().getName();
        this.entityData.set(DATA_OWNER, Optional.of(owner));
        bar.setDarkenScreen(false);
        bar.setPlayBossMusic(false);
        for (ServerPlayer other : new ArrayList<>(bar.getPlayers())) {
            if (!isOwner(other)) {
                bar.removePlayer(other);
            }
        }
        updateBar();
    }

    /** Intinya tunduk: berhenti bertarung, pulih penuh, & jadi milik p. */
    private void tame(ServerPlayer p) {
        adopt(p);
        tameProgress = 0;
        rage = false;
        rageQueued = false;
        critUntil = 0;
        this.entityData.set(DATA_RAGE, false);
        target = null;
        this.entityData.set(DATA_TARGET, -1);
        pending.clear();
        zones.clear();
        waveC = null;
        exposedUntil = 0;
        this.entityData.set(DATA_EXPOSED, 0);
        smashOn = false;
        stay = false;
        following = false;
        this.setHealth(this.getMaxHealth());
        long now = this.level().getGameTime();
        nextStomp = nextErupt = nextGeyser = nextRoar = nextFall = nextCrit = nextPrison = nextAny = now;
        traps.clear();
        if (action != Action.FALL) {   // badannya yang terhempas bangkit sendiri (jangan melompat ke pose berdiri)
            act(Action.IDLE);
        }
        anim(ShazamAnim.KALDERA_TAME, calderaTop());
        sound(center(), ShazamSounds.KALDERA_TAME.get(), 16f, 1f);
        if (p.distanceToSqr(this) < 200.0 * 200.0) {
            bar.addPlayer(p);
        }
        updateBar();
        tell(Component.translatable("message.shazammod.kaldera_tamed", ownerName).withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), 200.0);
        p.sendSystemMessage(Component.translatable("message.shazammod.kaldera_tamed_hint").withStyle(ChatFormatting.GREEN));
        giveCore(p);
    }

    /** Tiap tick selama jinak: jurus KRITIS yang habis, pulih pelan di luar pertarungan, & bit HUD penunggangnya. */
    private void tickTamed(ServerLevel level, long now) {
        if (critUntil > 0 && now >= critUntil && action != Action.RAGE) {
            critUntil = 0;
            rage = false;
            this.entityData.set(DATA_RAGE, false);
            updateBar();
            if (rider() instanceof ServerPlayer r) {
                r.displayClientMessage(Component.translatable("message.shazammod.kaldera_calm").withStyle(ChatFormatting.GREEN), true);
            }
        }
        if (this.tickCount % 20 == 0 && action != Action.DEATH && now - lastCombat > 200 && this.getHealth() < this.getMaxHealth()) {
            this.heal(TAME_REGEN);
        }
        if (this.tickCount % 2 == 0) {
            int bits = 0;
            long[] next = {nextStomp, nextErupt, nextGeyser, nextRoar, nextFall, nextCrit, nextPrison};
            for (int i = 0; i < next.length; i++) {
                if (now >= next[i]) {
                    bits |= 1 << i;
                }
            }
            if (smashOn) {
                bits |= READY_SMASH;
            }
            if (stay) {
                bits |= READY_STAY;
            }
            if (action != Action.IDLE) {
                bits |= READY_BUSY;
            }
            if (bits != this.entityData.get(DATA_READY)) {
                this.entityData.set(DATA_READY, bits);
            }
        }
    }

    private float rideTurn() {
        return rage ? RIDE_TURN * 1.3f : RIDE_TURN;
    }

    /** Ditunggangi pemiliknya: W berjalan sambil berbelok ke arah pandangan penunggang, A/D berbelok (juga di tempat). */
    private void tickRidden(ServerLevel level, long now, ServerPlayer r) {
        if (target != null || this.entityData.get(DATA_TARGET) != -1) {
            target = null;
            this.entityData.set(DATA_TARGET, -1);
        }
        idle = 0;
        following = false;
        float fwd = r.zza, side = r.xxa, rate = rideTurn();
        float delta = Mth.wrapDegrees(r.getYRot() - this.getYRot());
        float turn = 0f;
        if (Math.abs(side) > 0.05f) {
            turn = -Math.signum(side) * rate;   // A = kiri (yaw berkurang), D = kanan
        } else if (fwd > 0.05f) {
            turn = Mth.clamp(delta, -rate, rate);
        }
        if (turn != 0f) {
            face(this.getYRot() + turn);
            stride += Math.abs(turn) * 0.12f;
        }
        if (fwd > 0.05f) {
            double speed = RIDE_SPEED * Math.min(1f, fwd) * (rage ? RAGE_SPEED : 1f);
            if (Math.abs(side) <= 0.05f) {
                speed *= Mth.clamp(Mth.cos(delta * Mth.DEG_TO_RAD), 0.25f, 1f);
            }
            if (plow > 600) {
                speed *= 0.6;
            }
            walk(level, speed);
        }
    }

    /** Jinak & nggak ditunggangi: melawan musuh pemiliknya, mengikuti pemiliknya, atau diam kalau disuruh. */
    private void tickCompanion(ServerLevel level, long now) {
        Player o = owner == null ? null : level.getPlayerByUUID(owner);
        if (--retarget <= 0 || target != null && (!target.isAlive() || target.isRemoved() || !victim(target))) {
            target = guardTarget(level, o);
            retarget = 20;
            this.entityData.set(DATA_TARGET, target == null ? -1 : target.getId());
        }
        idle = 0;
        if (target != null) {
            double dx = target.getX() - this.getX(), dz = target.getZ() - this.getZ();
            double dist = Math.sqrt(dx * dx + dz * dz);
            float delta = turnToward(dx, dz, turnRate());
            if (chooseAttack(level, now, dist, Math.abs(delta))) {
                return;
            }
            if (!stay && dist > STOP_DIST) {
                double speed = WALK_SPEED * (rage ? RAGE_SPEED : 1f) * Mth.clamp(Mth.cos(delta * Mth.DEG_TO_RAD), 0.2f, 1f);
                walk(level, plow > 600 ? speed * 0.6 : speed);
            }
            return;
        }
        if (o == null || stay || o.level() != level) {
            following = false;
            return;
        }
        double dx = o.getX() - this.getX(), dz = o.getZ() - this.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > FOLLOW_START && dist < 400.0) {   // terlalu jauh (atau beda dunia): menunggu di tempat
            following = true;
        } else if (dist < FOLLOW_STOP || dist >= 400.0) {
            following = false;
        }
        if (following) {
            float delta = turnToward(dx, dz, turnRate());
            walk(level, WALK_SPEED * 1.3 * Mth.clamp(Mth.cos(delta * Mth.DEG_TO_RAD), 0.2f, 1f));
        }
    }

    /** Berbelok ke arah (dx, dz) paling banyak rate derajat; mengembalikan sisa sudutnya (derajat). */
    private float turnToward(double dx, double dz, float rate) {
        float want = (float) (Mth.atan2(dz, dx) * Mth.RAD_TO_DEG) - 90f;
        float delta = Mth.wrapDegrees(want - this.getYRot());
        float turn = Mth.clamp(delta, -rate, rate);
        face(this.getYRot() + turn);
        stride += Math.abs(turn) * 0.12f;
        return delta;
    }

    /**
     * Musuh yang dilawan KALDERA jinak: yang menyerang pemiliknya / dirinya, monster yang diserang pemiliknya, lalu monster
     * terdekat di sekitar pemiliknya (yang sedang mengincar pemiliknya didahulukan).
     */
    @Nullable
    private LivingEntity guardTarget(ServerLevel level, @Nullable Player o) {
        Vec3 c = o != null && o.level() == level ? o.position() : center();
        double far = (GUARD_R + 30.0) * (GUARD_R + 30.0);
        LivingEntity hit = o != null && o.getLastHurtMob() instanceof Enemy && o.tickCount - o.getLastHurtMobTimestamp() < 200
                ? o.getLastHurtMob() : null;
        for (LivingEntity e : new LivingEntity[]{o == null ? null : o.getLastHurtByMob(), this.getLastHurtByMob(), hit}) {
            if (e != null && e.isAlive() && !isOwner(e) && e.getVehicle() != this && !(e instanceof Kaldera) && e.distanceToSqr(c) < far
                    && !(e instanceof Player p && (p.isCreative() || p.isSpectator()))) {
                return e;
            }
        }
        Mob best = null;
        double bestD = GUARD_R * GUARD_R;
        for (Mob m : level.getEntitiesOfClass(Mob.class, new AABB(c, c).inflate(GUARD_R, 24.0, GUARD_R),
                m -> m instanceof Enemy && m.isAlive() && !(m instanceof Kaldera))) {
            double d = m.distanceToSqr(c) * (o != null && m.getTarget() == o || m.getTarget() == this ? 0.25 : 1.0);
            if (d < bestD) {
                bestD = d;
                best = m;
            }
        }
        return best;
    }

    /** Titik sasaran jurus KALDERA jinak: yang dibidik penunggangnya, atau musuh yang sedang dilawannya. */
    @Nullable
    private Vec3 strikeFocus() {
        if (rider() instanceof ServerPlayer r) {
            return riderAim(r);
        }
        return target != null && target.isAlive() ? target.position() : null;
    }

    /** Titik yang dilihat penunggangnya: blok / tanah yang dibidiknya, sampai 160 blok. */
    private Vec3 riderAim(Player r) {
        Vec3 eye = r.getEyePosition(), end = eye.add(r.getLookAngle().scale(160.0));
        BlockHitResult hit = this.level().clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, r));
        Vec3 p = hit.getType() == HitResult.Type.MISS ? end : hit.getLocation();
        double g = KalderaBody.ground(this.level(), p.x, p.z);
        return new Vec3(p.x, Double.isNaN(g) ? p.y : g, p.z);
    }

    /**
     * 0.74 Tombol skill saat menunggangi KALDERA milik sendiri (dari ShazamNetwork): Z Injakan Bumi, X Letusan Inti (ke arah
     * pandangan), C Ventilasi Radiasi (ke arah pandangan), V Raungan, B Gunung Runtuh, N penghancuran nyala/mati, R KRITIS,
     * 0.75 J Penjara Kristal (ke arah pandangan). true = sudah dipakai (jangan diteruskan ke skill juara).
     */
    public static boolean handleRiderKey(ServerPlayer player, int key) {
        int cmd = key == ShazamNetwork.ACTION_FAMILY ? 8 : key;
        if (cmd < 1 || cmd > 8 || !(player.getVehicle() instanceof Kaldera k) || !k.isOwner(player)) {
            return false;
        }
        k.riderCommand(player, cmd);
        return true;
    }

    private void riderCommand(ServerPlayer r, int key) {
        if (!(this.level() instanceof ServerLevel level) || action == Action.DEATH) {
            return;
        }
        long now = level.getGameTime();
        if (key == 6) {
            smashOn = !smashOn;
            r.displayClientMessage(Component.translatable(smashOn ? "message.shazammod.kaldera_smash_on" : "message.shazammod.kaldera_smash_off")
                    .withStyle(smashOn ? ChatFormatting.GOLD : ChatFormatting.GREEN), true);
            if (smashOn && !griefing(level)) {
                r.sendSystemMessage(Component.translatable("message.shazammod.kaldera_smash_rule").withStyle(ChatFormatting.GRAY));
            }
            return;
        }
        if (action != Action.IDLE) {
            return;   // jurus sebelumnya masih berjalan
        }
        switch (key) {
            case 1 -> {
                if (ready(r, now, nextStomp, "stomp")) {
                    nextStomp = now + RIDE_STOMP;
                    beginStomp(level);
                }
            }
            case 2 -> {
                if (ready(r, now, nextErupt, "erupt")) {
                    nextErupt = now + RIDE_ERUPT;
                    beginErupt();
                }
            }
            case 3 -> {
                if (ready(r, now, nextGeyser, "vent")) {
                    nextGeyser = now + RIDE_VENT;
                    beginGeyser(level);
                }
            }
            case 4 -> {
                if (ready(r, now, nextRoar, "roar")) {
                    nextRoar = now + RIDE_ROAR;
                    beginRoar();
                }
            }
            case 5 -> {
                if (ready(r, now, nextFall, "fall")) {
                    nextFall = now + RIDE_FALL;
                    beginFall();
                }
            }
            case 8 -> {
                if (ready(r, now, nextPrison, "prison")) {
                    nextPrison = now + RIDE_PRISON;
                    beginPrison(level);
                }
            }
            case 7 -> {
                if (ready(r, now, nextCrit, "crit")) {
                    nextCrit = now + RIDE_CRIT;
                    critUntil = now + RAGE_TICKS + CRIT_TICKS;
                    enterRage(now);
                }
            }
            default -> { }
        }
    }

    private static boolean ready(ServerPlayer r, long now, long next, String move) {
        if (now >= next) {
            return true;
        }
        r.displayClientMessage(Component.translatable("message.shazammod.kaldera_cooldown", Component.translatable("hud.shazammod.kaldera." + move),
                (next - now + 19) / 20).withStyle(ChatFormatting.GRAY), true);
        return false;
    }

    /** 0.74 Penunggang KALDERA nggak tercekik di dalam bukit, jatuh, terbentur, atau terkena jurus tunggangannya sendiri. */
    public static boolean shieldRider(LivingEntity e, DamageSource source) {
        if (!(e.getVehicle() instanceof Kaldera k)) {
            return false;
        }
        return source.is(DamageTypes.IN_WALL) || source.is(DamageTypeTags.IS_FALL) || source.is(DamageTypes.FLY_INTO_WALL)
                || source.is(DamageTypes.CRAMMING) || source.getEntity() == k;
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        Action a = action();
        return this.getPassengers().isEmpty() && passenger instanceof Player p && isOwner(p) && a != Action.DEATH && a != Action.SINK
                && a != Action.EMERGE && a != Action.RUMBLE && !recalled;
    }

    /** Titik duduk penunggang di dunia (dahinya). */
    public Vec3 seatPosition() {
        KalderaBody.seat(pose, seatTmp);
        return world(seatTmp[0], seatTmp[1], seatTmp[2]);
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction callback) {
        if (!this.hasPassenger(passenger)) {
            return;
        }
        Vec3 seat = seatPosition();
        Vec3 off = passenger.getVehicleAttachmentPoint(this);
        callback.accept(passenger, seat.x - off.x, seat.y - off.y, seat.z - off.z);
    }

    /**
     * Darahnya 3000: jangan diganti baris hati kendaraan vanilla di HUD penunggangnya (ia punya panel sendiri, KalderaHud).
     * Sengaja tanpa @Override supaya tetap aman kalau nama method vanilla-nya berubah.
     */
    public boolean showVehicleHealth() {
        return false;
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        passenger.fallDistance = 0f;
        return dismountSpot();
    }

    /** Tempat turun yang aman: di tanah samping kepalanya (kanan dulu), di depan kaki depannya. */
    private Vec3 dismountSpot() {
        for (float side : new float[]{-1f, 1f}) {
            Vec3 p = world(side * 22f, 0f, 30f);
            double g = KalderaBody.ground(this.level(), p.x, p.z);
            if (!Double.isNaN(g)) {
                return new Vec3(p.x, g + 0.05, p.z);
            }
        }
        return new Vec3(this.getX(), this.getY() + 0.05, this.getZ());
    }

    /** Turunkan semua penunggangnya ke tanah dengan selamat (tumbang / hilang). */
    private void ejectRiders() {
        for (Entity e : new ArrayList<>(this.getPassengers())) {
            e.stopRiding();
            e.fallDistance = 0f;
            if (e instanceof LivingEntity le) {
                le.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 100, 0));
            }
        }
    }

    /** Penghancuran nyala & ditunggangi: ruang di sekitar penunggangnya ikut dikosongkan (nggak tercekik di dalam bukit). */
    private void carveSeat(ServerLevel level) {
        if (rider() == null || !destroys(level)) {
            return;
        }
        KalderaBody.seat(pose, seatTmp);
        int[] budget = {120};
        ellipsoidLocal(level, seatTmp[0], seatTmp[1] + 1.2f, seatTmp[2], 2.6f, 2.4f, 2.6f, Mth.floor(this.getY()) + 1, budget);
    }

    // ------------------------------------------------------------------ 0.75 penjara kristal

    private void beginPrison(ServerLevel level) {
        act(Action.PRISON);
        spiked.clear();
        Vec3 f = landing(level, KalderaBody.FL);
        anim(ShazamAnim.KALDERA_PRISON, f);
        sound(f, ShazamSounds.KALDERA_STRAIN.get(), 7f, 1.2f);
    }

    /** Kaki kiri depan menghentak: deret kristal merambat di tanah ke tiap mangsa, ujungnya mengurung yang ada di sana. */
    private void tickPrison(ServerLevel level, long now) {
        if (actionAge == PRISON_SLAM) {
            Vec3 f = landing(level, KalderaBody.FL);
            sound(f, ShazamSounds.KALDERA_STEP.get(), 8f, 0.8f);
            sound(f, ShazamSounds.KALDERA_PRISON.get(), 12f, pitchJitter());
            for (LivingEntity e : victims(f, KalderaBody.FOOT_R + 2.0, 6.0)) {
                if (strike(e, STEP_DMG, false)) {
                    fling(e, f, 1.0, 0.9);
                }
            }
            if (destroys(level)) {
                footprint(level, f, KalderaBody.FOOT_R + 1f);
            }
            int n = 0;
            for (Vec3 end : prisonTargets(level, f)) {
                if (n++ >= PRISON_LINES) {
                    break;
                }
                prisonLine(level, now, f, end);
            }
        }
        if (actionAge >= PRISON_TICKS) {
            idleNow(now);
        }
    }

    /**
     * Ujung-ujung deret kristal: tempat mangsanya bakal berada saat deretnya sampai (ditebak dari geraknya, separuh saja
     * supaya masih bisa dihindari). Yang jinak: musuh di sekitar titik bidik penunggangnya / musuh yang dilawannya.
     */
    private List<Vec3> prisonTargets(ServerLevel level, Vec3 f) {
        List<LivingEntity> aims = new ArrayList<>();
        List<Vec3> out = new ArrayList<>();
        if (isTamed()) {
            Vec3 focus = strikeFocus();
            if (focus == null) {
                return out;
            }
            List<LivingEntity> near = foes(focus, 14.0);
            if (near.isEmpty()) {
                out.add(reach(f, focus));   // nggak ada musuh di sana: deretnya tetap ke titik bidik
            }
            aims.addAll(near);
        } else {
            double range = PRISON_RANGE + 40.0;
            for (ServerPlayer p : level.players()) {
                if (p.distanceToSqr(this) < range * range && prey(p)) {
                    aims.add(p);
                }
            }
            if (target != null && !aims.contains(target) && prey(target)) {
                aims.add(target);
            }
        }
        for (LivingEntity e : aims) {
            double dx = e.getX() - f.x, dz = e.getZ() - f.z;
            double lead = Math.min(Math.sqrt(dx * dx + dz * dz) / PRISON_SPEED, 24.0) * 0.6;
            Vec3 end = reach(f, new Vec3(e.getX() + (e.getX() - e.xo) * lead, e.getY(), e.getZ() + (e.getZ() - e.zo) * lead));
            out.add(end);
            if (rage && !isTamed() && e == target) {   // kritis: dua deret tambahan mengapit mangsanya
                out.add(reach(f, turn(f, end, -16f)));
                out.add(reach(f, turn(f, end, 16f)));
            }
        }
        return out;
    }

    /** Titik p yang jarak datarnya dari kaki f dibatasi 8..PRISON_RANGE. */
    private static Vec3 reach(Vec3 f, Vec3 p) {
        double dx = p.x - f.x, dz = p.z - f.z, d = Math.sqrt(dx * dx + dz * dz);
        if (d < 1.0E-3) {
            return new Vec3(f.x + 8.0, p.y, f.z);
        }
        double k = Mth.clamp(d, 8.0, PRISON_RANGE) / d;
        return new Vec3(f.x + dx * k, p.y, f.z + dz * k);
    }

    /** p diputar deg derajat mengelilingi c (bidang datar). */
    private static Vec3 turn(Vec3 c, Vec3 p, float deg) {
        double a = deg * Mth.DEG_TO_RAD, cs = Math.cos(a), sn = Math.sin(a);
        double dx = p.x - c.x, dz = p.z - c.z;
        return new Vec3(c.x + dx * cs - dz * sn, p.y, c.z + dx * sn + dz * cs);
    }

    /**
     * Satu deret: duri-duri kristal menyeruak bergantian dari kaki f ke ujungnya (SPIKE_GAP blok sekali, PRISON_SPEED blok
     * per tick), lalu penjaranya menutup di ujung. Client menggambar deret yang sama dari kaki kirinya (KalderaFx).
     */
    private void prisonLine(ServerLevel level, long now, Vec3 f, Vec3 end) {
        double dx = end.x - f.x, dz = end.z - f.z, len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0) {
            return;
        }
        double ux = dx / len, uz = dz / len;
        for (double d = SPIKE_START; d < len - CAGE_R; d += SPIKE_GAP) {
            Vec3 p = spot(level, f.x + ux * d, f.z + uz * d);
            pending.add(new double[]{p.x, p.y, p.z, now + (long) Math.ceil(d / PRISON_SPEED), SPIKE});
        }
        Vec3 c = spot(level, end.x, end.z);
        pending.add(new double[]{c.x, c.y, c.z, now + (long) Math.ceil(len / PRISON_SPEED), CAGE});
        anim(ShazamAnim.KALDERA_PRISON_LINE, c);
    }

    /** Duri kristal menyeruak: yang berdiri di atasnya tertusuk & terlempar sedikit (sekali per jurus). */
    private void spikeHit(Vec3 at) {
        for (LivingEntity e : victims(at.add(0, 1.5, 0), SPIKE_R + 0.5, 3.0)) {
            if (flat(at, e) > SPIKE_R || e.getY() < at.y - 1.5 || e.getY() > at.y + 3.5 || !spiked.add(e.getUUID())) {
                continue;
            }
            if (strike(e, SPIKE_DMG, false)) {
                e.push(0, 0.75, 0);
                e.hurtMarked = true;
            }
            irradiate(e, 0, 0f, 60);
        }
    }

    /** Ujung deret: kristal besar menyeruak melingkar & menutup di atas: yang di dalamnya terkurung PRISON_HOLD tick. */
    private void cageHit(Vec3 at, long now) {
        sound(at, ShazamSounds.KALDERA_PRISON_TRAP.get(), 6f, pitchJitter());
        anim(ShazamAnim.KALDERA_PRISON_CAGE, at);
        for (LivingEntity e : victims(at.add(0, 2.0, 0), CAGE_R + 0.5, 4.0)) {
            if (flat(at, e) > CAGE_R || e.getY() < at.y - 2.0 || e.getY() > at.y + 5.0 || trapped(e)) {
                continue;
            }
            strike(e, PRISON_DMG, false);
            irradiate(e, 1, 0f, 100);
            if (e.isAlive() && e.getBbWidth() <= 3.5f && e.getBbHeight() <= 5f) {   // yang terlalu besar cuma kena damage
                traps.add(new Trap(e, at.x, at.y, at.z, now + PRISON_HOLD));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, PRISON_HOLD, 5, false, false, true), this);
                if (e instanceof ServerPlayer p) {
                    p.displayClientMessage(Component.translatable("message.shazammod.kaldera_trapped")
                            .withStyle(ChatFormatting.GREEN, ChatFormatting.BOLD), true);
                }
            }
        }
    }

    private boolean trapped(LivingEntity e) {
        for (Trap t : traps) {
            if (t.e == e) {
                return true;
            }
        }
        return false;
    }

    /** Yang terkurung ditahan di tengah penjaranya (yang mencoba keluar ditarik balik), radiasi kristalnya terus mengenai. */
    private void tickTraps(ServerLevel level, long now) {
        if (traps.isEmpty()) {
            return;
        }
        Iterator<Trap> it = traps.iterator();
        while (it.hasNext()) {
            Trap t = it.next();
            LivingEntity e = t.e;
            if (e.isRemoved() || !e.isAlive() || e.level() != level || !victim(e)) {
                it.remove();
                continue;
            }
            if (now >= t.until) {   // penjaranya pecah
                it.remove();
                Vec3 c = new Vec3(t.x, t.y, t.z);
                strike(e, SHATTER_DMG, false);
                fling(e, c, 0.5, 0.45);
                sound(c, ShazamSounds.KALDERA_PRISON_TRAP.get(), 4f, 1.45f);
                continue;
            }
            double dx = e.getX() - t.x, dz = e.getZ() - t.z;
            if (dx * dx + dz * dz > 0.9 || e.getY() > t.y + 2.6 || e.getY() < t.y - 1.5) {
                if (e instanceof ServerPlayer p) {
                    p.connection.teleport(t.x, t.y, t.z, p.getYRot(), p.getXRot());
                } else {
                    e.teleportTo(t.x, t.y, t.z);
                }
            }
            e.setDeltaMovement(0, Math.min(0.0, e.getDeltaMovement().y), 0);
            if (e instanceof ServerPlayer) {
                e.hurtMarked = true;
            }
            if (now >= t.dose) {
                t.dose = now + 20;
                irradiate(e, 1, 2f, 60);
            }
        }
    }

    /** 0.75 Yang terkurung Penjara Kristal: ditahan di (x, y, z) sampai tick until. */
    private static final class Trap {
        final LivingEntity e;
        final double x, y, z;
        final long until;
        long dose;

        Trap(LivingEntity e, double x, double y, double z, long until) {
            this.e = e;
            this.x = x;
            this.y = y;
            this.z = z;
            this.until = until;
            this.dose = until - PRISON_HOLD + 20;
        }
    }

    // ------------------------------------------------------------------ 0.75 gempa KALDERA (bangkit sendiri)

    /**
     * Gempa peringatan: masih di perut bumi (nggak kelihatan, nggak bisa disentuh, tanpa radiasi), bumi bergemuruh makin
     * kuat & rumput di atasnya mati, lalu bangkit (EMERGE) seperti biasa. Dipakai KalderaSpawner.
     */
    @Nullable
    public static Kaldera rumble(ServerLevel level, Vec3 at, float yaw) {
        Kaldera k = ShazamEntities.KALDERA.get().create(level);
        if (k == null) {
            return null;
        }
        k.moveTo(at.x, at.y, at.z, yaw, 0f);
        k.face(yaw);
        k.act(Action.RUMBLE);
        k.bar.setVisible(false);
        return level.addFreshEntity(k) ? k : null;
    }

    private void tickRumble(ServerLevel level, long now) {
        float prog = actionAge / (float) RUMBLE_TICKS;
        if (actionAge == 1) {
            tell(Component.translatable("message.shazammod.kaldera_quake_start").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), 220.0);
        }
        if (actionAge % 40 == 1) {
            anim(ShazamAnim.KALDERA_QUAKE, center());
            if (actionAge % 80 == 1) {
                sound(center(), ShazamSounds.KALDERA_QUAKE.get(), 8f + 8f * prog, 0.9f + this.random.nextFloat() * 0.15f);
            }
        }
        if (actionAge == RUMBLE_TICKS * 3 / 5) {
            tell(Component.translatable("message.shazammod.kaldera_quake_near").withStyle(ChatFormatting.YELLOW, ChatFormatting.BOLD), 220.0);
        }
        if (destroys(level) && actionAge > RUMBLE_TICKS / 2 && actionAge % 10 == 0) {   // radiasinya merembes: rumput di atasnya mati
            blight(level, center(), 6.0 + 18.0 * prog, 12);
        }
        if (actionAge >= RUMBLE_TICKS) {
            act(Action.EMERGE);
            bar.setVisible(true);
            updateBar();
        }
    }

    // ------------------------------------------------------------------ 0.75 Inti Kaldera

    /** Bisa dipanggil pulang ke Inti Kaldera sekarang (jinak & nggak sedang bangkit / tenggelam / tumbang). */
    public boolean recallable() {
        Action a = action();
        return isTamed() && !recalled && a != Action.DEATH && a != Action.SINK && a != Action.EMERGE && a != Action.RUMBLE;
    }

    /** KALDERA milik p yang dipanggil Inti Kaldera: yang ditungganginya, atau yang terdekat (termuat, dunia yang sama). */
    @Nullable
    public static Kaldera ownedNear(ServerPlayer p) {
        if (p.getVehicle() instanceof Kaldera mount && mount.isOwner(p) && !mount.recalled) {
            return mount;
        }
        Kaldera best = null;
        double bestD = RECALL_RANGE * RECALL_RANGE;
        for (Kaldera c : p.serverLevel().getEntities(ShazamEntities.KALDERA.get(), x -> x.isOwner(p) && !x.recalled && x.isAlive())) {
            double d = c.distanceToSqr(p);
            if (d < bestD) {
                bestD = d;
                best = c;
            }
        }
        return best;
    }

    /** Klik kanan Inti Kaldera yang kosong: KALDERA terdekat milik p disimpan ke dalamnya, lalu tenggelam ke perut bumi. */
    public static void recallInto(ServerPlayer p, ItemStack core) {
        Kaldera k = ownedNear(p);
        if (k == null) {
            p.displayClientMessage(Component.translatable("message.shazammod.kaldera_core_none").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (!k.recallable()) {
            p.displayClientMessage(Component.translatable("message.shazammod.kaldera_core_busy").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        String name = k.ownerName;
        float hp = k.getHealth(), max = k.getMaxHealth();
        KalderaCoreItem.store(core, k.recall(), name, hp, max);
        p.displayClientMessage(Component.translatable("message.shazammod.kaldera_core_recall").withStyle(ChatFormatting.GREEN), true);
    }

    /** Disimpan: data lengkapnya (darah, pemilik, pengaturan) dikembalikan, lalu ia tenggelam & hilang tanpa disimpan lagi. */
    private CompoundTag recall() {
        ejectRiders();
        traps.clear();
        pending.clear();
        zones.clear();
        waveC = null;
        target = null;
        this.entityData.set(DATA_TARGET, -1);
        critUntil = 0;
        rage = false;
        this.entityData.set(DATA_RAGE, false);
        CompoundTag tag = this.saveWithoutId(new CompoundTag());
        tag.remove("Passengers");
        recalled = true;
        act(Action.SINK);
        anim(ShazamAnim.KALDERA_SINK, center());
        sound(center(), ShazamSounds.KALDERA_SINK.get(), 16f, 1.1f);
        bar.removeAllPlayers();
        return tag;
    }

    /** Klik kanan Inti Kaldera yang berisi: bangkit di titik yang dibidik p (minimal RELEASE_MIN blok), jadi milik p. */
    public static void releaseFrom(ServerPlayer p, ItemStack core) {
        CompoundTag data = KalderaCoreItem.stored(core);
        if (data == null) {
            return;
        }
        Vec3 at = releaseSpot(p);
        Kaldera k = at == null ? null : ShazamEntities.KALDERA.get().create(p.serverLevel());
        if (k == null) {
            p.displayClientMessage(Component.translatable("message.shazammod.kaldera_core_blocked").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        String before = KalderaCoreItem.storedOwner(core);
        k.load(data);
        k.setUUID(UUID.randomUUID());   // KALDERA yang sama, tapi entity baru
        float yaw = (float) (Mth.atan2(p.getZ() - at.z, p.getX() - at.x) * Mth.RAD_TO_DEG) - 90f;
        k.moveTo(at.x, at.y, at.z, yaw, 0f);
        k.face(yaw);
        k.setDeltaMovement(Vec3.ZERO);
        k.adopt(p);   // yang membangkitkannya jadi pemiliknya
        k.stay = false;
        k.following = false;
        k.act(Action.EMERGE);
        if (!p.serverLevel().addFreshEntity(k)) {
            p.displayClientMessage(Component.translatable("message.shazammod.kaldera_core_blocked").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        KalderaCoreItem.clear(core);
        if (!before.isEmpty() && !before.equals(p.getGameProfile().getName())) {
            p.sendSystemMessage(Component.translatable("message.shazammod.kaldera_core_other", before).withStyle(ChatFormatting.GREEN));
        }
    }

    /** Titik bangkit dari Inti Kaldera: yang dibidik p, sejauh RELEASE_MIN..RELEASE_RANGE blok, di tanah terbuka yang termuat. */
    @Nullable
    private static Vec3 releaseSpot(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        if (level.dimensionType().hasCeiling()) {
            return null;   // Nether: terlalu sempit (tanahnya = atap batuan dasar)
        }
        Vec3 eye = p.getEyePosition(), look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : flat.normalize();
        BlockHitResult hit = level.clip(new ClipContext(eye, eye.add(look.scale(RELEASE_RANGE)), ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, p));
        Vec3 aim = hit.getType() == HitResult.Type.MISS ? p.position().add(flat.scale(40.0)) : hit.getLocation();
        double dx = aim.x - p.getX(), dz = aim.z - p.getZ();
        if (dx * dx + dz * dz < RELEASE_MIN * RELEASE_MIN) {
            aim = new Vec3(p.getX() + flat.x * RELEASE_MIN, aim.y, p.getZ() + flat.z * RELEASE_MIN);
        }
        for (double[] o : new double[][]{{0, 0}, {40, 0}, {-40, 0}, {0, 40}, {0, -40}}) {   // badannya muat & chunk-nya termuat
            BlockPos b = BlockPos.containing(aim.x + o[0], aim.y, aim.z + o[1]);
            if (!level.isLoaded(b) || !level.getWorldBorder().isWithinBounds(aim.x + o[0], aim.z + o[1])) {
                return null;
            }
        }
        double g = KalderaBody.ground(level, aim.x, aim.z);
        if (Double.isNaN(g) || g <= level.getMinBuildHeight() + 2) {
            return null;   // kehampaan (End)
        }
        return new Vec3(aim.x, g, aim.z);
    }

    /** Beri p sebuah Inti Kaldera kosong, kalau belum punya yang kosong. */
    static void giveCore(ServerPlayer p) {
        for (ItemStack s : p.getInventory().items) {
            if (s.getItem() instanceof KalderaCoreItem && !KalderaCoreItem.filled(s)) {
                return;
            }
        }
        if (p.getOffhandItem().getItem() instanceof KalderaCoreItem && !KalderaCoreItem.filled(p.getOffhandItem())) {
            return;
        }
        ItemStack core = new ItemStack(KalderaItems.KALDERA_CORE.get());
        if (!p.getInventory().add(core)) {
            p.drop(core, false);
        }
        p.sendSystemMessage(Component.translatable("message.shazammod.kaldera_core_given").withStyle(ChatFormatting.GREEN));
    }

    // ------------------------------------------------------------------ suara

    @Override
    protected SoundEvent getAmbientSound() {
        return action == Action.IDLE ? ShazamSounds.KALDERA_AMBIENT.get() : null;
    }

    @Override
    public int getAmbientSoundInterval() {
        return 180;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ShazamSounds.KALDERA_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return null;   // suara tumbangnya diputar sendiri (kaldera_death)
    }

    @Override
    protected float getSoundVolume() {
        return 8f;
    }

    // ------------------------------------------------------------------ gambar & siklus hidup

    @Override
    public AABB getBoundingBoxForCulling() {
        double r = KalderaBody.REACH + 6.0;
        return new AABB(this.getX() - r, this.getY() - KalderaBody.EMERGE_DEPTH - 4.0, this.getZ() - r,
                this.getX() + r, this.getY() + KalderaBody.TOP + 8.0, this.getZ() + r);
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 640.0 * 640.0;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (!isTamed() || isOwner(player)) {   // yang jinak: bar darahnya cuma untuk pemiliknya
            bar.addPlayer(player);
        }
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bar.removePlayer(player);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        if (!this.level().isClientSide && (reason == Entity.RemovalReason.KILLED || reason == Entity.RemovalReason.DISCARDED)) {
            ejectRiders();   // jangan jatuhkan penunggangnya dari ketinggian 40 blok
        }
        super.remove(reason);
        bar.removeAllPlayers();
    }

    @Override
    public boolean shouldBeSaved() {
        return isTamed() && !recalled && action != Action.DEATH && super.shouldBeSaved();   // 0.74 yang liar tetap nggak disimpan
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return !isTamed();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (owner != null) {
            tag.putUUID("KalderaOwner", owner);
            tag.putString("KalderaOwnerName", ownerName);
            tag.putBoolean("KalderaSmash", smashOn);
            tag.putBoolean("KalderaStay", stay);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("KalderaOwner")) {
            owner = tag.getUUID("KalderaOwner");
            ownerName = tag.getString("KalderaOwnerName");
            smashOn = tag.getBoolean("KalderaSmash");
            stay = tag.getBoolean("KalderaStay");
            this.entityData.set(DATA_OWNER, Optional.of(owner));
            bar.setDarkenScreen(false);
            bar.setPlayBossMusic(false);
            act(Action.IDLE);   // dimuat ulang: langsung berdiri, nggak bangkit dari perut bumi lagi
        }
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    /** /shazam kaldera: bangkit sejauh distance blok di depan pemain, menghadap pemainnya. */
    public static Kaldera summon(ServerPlayer player, double distance) {
        return summon(player, distance, false);
    }

    /** 0.74 tamed = langsung jadi milik pemainnya (tetap bangkit dari perut bumi dulu). */
    public static Kaldera summon(ServerPlayer player, double distance, boolean tamed) {
        ServerLevel level = player.serverLevel();
        Kaldera k = ShazamEntities.KALDERA.get().create(level);
        if (k == null) {
            return null;
        }
        Vec3 look = player.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : flat.normalize();
        double x = player.getX() + flat.x * distance, z = player.getZ() + flat.z * distance;
        double g = KalderaBody.ground(level, x, z);
        float yaw = (float) (Mth.atan2(player.getZ() - z, player.getX() - x) * Mth.RAD_TO_DEG) - 90f;
        k.moveTo(x, Double.isNaN(g) ? player.getY() : g, z, yaw, 0f);
        k.face(yaw);
        if (tamed) {
            k.adopt(player);
            giveCore(player);   // 0.75
        }
        level.addFreshEntity(k);
        return k;
    }
}
