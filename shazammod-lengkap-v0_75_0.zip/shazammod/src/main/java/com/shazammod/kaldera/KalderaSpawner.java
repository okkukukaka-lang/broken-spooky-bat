package com.shazammod.kaldera;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Nullable;

import com.shazammod.ShazamEntities;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 0.75 Gempa KALDERA: sesekali KALDERA liar bangkit sendiri di dekat pemain. Tiap menit, untuk tiap pemain di permukaan
 * Overworld (bukan Creative / penonton / Peaceful, nggak sedang menunggangi KALDERA) ada peluang KalderaConfig.CHANCE
 * persen; cuma kalau belum ada KALDERA liar lain di dunia itu. Tempatnya 64-96 blok dari pemainnya, di tanah (bukan laut
 * dalam), lalu gempa peringatan 20 dtk (Kaldera.rumble) sebelum ia bangkit. Sesudahnya pemain di sekitarnya aman selama
 * KalderaConfig.COOLDOWN menit. Buat ngetes: /shazam kaldera gempa.
 */
public final class KalderaSpawner {
    private KalderaSpawner() {}

    public static final int CHECK_TICKS = 20 * 60;          // dicek tiap menit
    public static final double MIN_DISTANCE = 64.0, MAX_DISTANCE = 96.0;
    public static final double COOLDOWN_SHARE_R = 320.0;    // pemain sejauh ini dari gempanya ikut dapat jeda

    private static final Map<UUID, Long> NEXT = new HashMap<>();

    public static void clear() {
        NEXT.clear();
    }

    public static void tick(MinecraftServer server) {
        if (server.getTickCount() % 20 != 11) {
            return;
        }
        boolean on;
        double chance;
        long cooldown, grace;
        try {
            on = KalderaConfig.EVENTS.get();
            chance = KalderaConfig.CHANCE.get();
            cooldown = KalderaConfig.COOLDOWN.get() * 1200L;
            grace = KalderaConfig.GRACE.get() * 1200L;
        } catch (IllegalStateException notLoaded) {
            return;
        }
        if (!on) {
            return;
        }
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            ServerLevel level = player.serverLevel();
            long now = level.getGameTime();
            Long next = NEXT.get(player.getUUID());
            if (next == null) {
                NEXT.put(player.getUUID(), now + grace);
                continue;
            }
            if (now < next) {
                continue;
            }
            NEXT.put(player.getUUID(), now + CHECK_TICKS);
            if (!eligible(player) || level.random.nextDouble() * 100.0 >= chance) {
                continue;
            }
            if (start(player, false) != null) {
                for (ServerPlayer other : level.players()) {
                    if (other.distanceToSqr(player) < COOLDOWN_SHARE_R * COOLDOWN_SHARE_R) {
                        NEXT.put(other.getUUID(), now + cooldown);
                    }
                }
            }
        }
    }

    private static boolean eligible(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        if (player.isCreative() || player.isSpectator() || !player.isAlive() || level.dimension() != Level.OVERWORLD
                || level.getDifficulty() == Difficulty.PEACEFUL || player.getVehicle() instanceof Kaldera
                || !level.canSeeSky(player.blockPosition().above())) {
            return false;
        }
        return level.getEntities(ShazamEntities.KALDERA.get(), k -> !k.isTamed() && k.isAlive()).isEmpty();
    }

    /**
     * Mulai gempanya di dekat witness. forced (perintah): tempatnya di depan pandangannya kalau bisa, tanpa syarat lain.
     * null = nggak ada tempat yang cocok.
     */
    @Nullable
    public static Kaldera start(ServerPlayer witness, boolean forced) {
        ServerLevel level = witness.serverLevel();
        RandomSource r = level.random;
        Vec3 at = null;
        if (forced) {
            Vec3 look = witness.getLookAngle();
            double a = Mth.atan2(look.z, look.x);
            at = spot(level, witness, a, (MIN_DISTANCE + MAX_DISTANCE) * 0.5);
        }
        for (int i = 0; i < 16 && at == null; i++) {
            at = spot(level, witness, r.nextDouble() * Math.PI * 2.0, MIN_DISTANCE + r.nextDouble() * (MAX_DISTANCE - MIN_DISTANCE));
        }
        if (at == null) {
            return null;
        }
        float yaw = (float) (Mth.atan2(witness.getZ() - at.z, witness.getX() - at.x) * Mth.RAD_TO_DEG) - 90f;
        return Kaldera.rumble(level, at, yaw);
    }

    /** Tanah terbuka yang termuat (badannya muat), bukan laut dalam / kehampaan, angle & distance dari witness. */
    @Nullable
    private static Vec3 spot(ServerLevel level, ServerPlayer witness, double angle, double distance) {
        double x = witness.getX() + Math.cos(angle) * distance, z = witness.getZ() + Math.sin(angle) * distance;
        for (double[] o : new double[][]{{0, 0}, {44, 0}, {-44, 0}, {0, 44}, {0, -44}}) {
            if (!level.isLoaded(BlockPos.containing(x + o[0], witness.getY(), z + o[1]))
                    || !level.getWorldBorder().isWithinBounds(x + o[0], z + o[1])) {
                return null;
            }
        }
        double g = KalderaBody.ground(level, x, z);
        if (Double.isNaN(g) || g <= level.getMinBuildHeight() + 8) {
            return null;
        }
        if (!level.getFluidState(BlockPos.containing(x, g + 10.0, z)).isEmpty()) {
            return null;   // laut / danau dalam
        }
        return new Vec3(x, g, z);
    }
}
