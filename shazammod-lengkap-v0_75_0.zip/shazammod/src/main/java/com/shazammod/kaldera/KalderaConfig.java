package com.shazammod.kaldera;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * 0.75 Pengaturan gempa KALDERA, per world: serverconfig/shazammod-kaldera-server.toml (bisa diubah tanpa build ulang;
 * berlaku sesudah world dibuka lagi).
 */
public final class KalderaConfig {
    private KalderaConfig() {}

    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.BooleanValue EVENTS;
    public static final ModConfigSpec.DoubleValue CHANCE;
    public static final ModConfigSpec.IntValue COOLDOWN;
    public static final ModConfigSpec.IntValue GRACE;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.comment("Gempa KALDERA: sesekali KALDERA liar bangkit sendiri 64-96 blok dari pemain di Overworld (di permukaan,",
                "bukan Creative / Peaceful), didahului gempa peringatan 20 detik. Cuma satu yang liar sekaligus.").push("events");
        EVENTS = b.comment("false = KALDERA cuma muncul lewat telur spawn / perintah").define("naturalEvents", true);
        CHANCE = b.comment("Peluang tiap menit (persen) untuk tiap pemain yang memenuhi syarat").defineInRange("chancePercentPerMinute",
                1.0, 0.0, 100.0);
        COOLDOWN = b.comment("Sesudah satu gempa, pemain di sekitarnya aman sekian menit").defineInRange("cooldownMinutes", 90, 1, 100000);
        GRACE = b.comment("Menit pertama sesudah masuk world tanpa gempa").defineInRange("graceMinutes", 15, 0, 100000);
        b.pop();
        SPEC = b.build();
    }
}
