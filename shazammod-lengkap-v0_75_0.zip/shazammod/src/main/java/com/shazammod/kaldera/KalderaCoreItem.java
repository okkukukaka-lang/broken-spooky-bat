package com.shazammod.kaldera;

import java.util.List;

import javax.annotation.Nullable;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

/**
 * 0.75 Inti Kaldera: kristal inti yang beresonansi dengan KALDERA jinak.
 * - Kosong, klik kanan: KALDERA milikmu yang terdekat (atau yang kamu tunggangi) dipanggil pulang: data lengkapnya (darah,
 *   pemilik, pengaturan) disimpan ke inti ini, lalu ia tenggelam ke perut bumi (Kaldera.recallInto).
 * - Berisi (berkilau), klik kanan: KALDERA-nya bangkit di titik yang kamu bidik, minimal 30 blok darimu, dan jadi milik
 *   yang membangkitkannya (bisa diberikan ke pemain lain lewat intinya). Nggak bisa di Nether (Kaldera.releaseFrom).
 * Datanya di komponen custom_data (kunci KalderaStored). Tahan api, dan yang berisi nggak hilang dimakan waktu kalau
 * terjatuh.
 */
public class KalderaCoreItem extends Item {
    static final String KEY = "KalderaStored", OWNER = "KalderaOwnerName", HP = "KalderaHealth", MAX = "KalderaMaxHealth";

    public KalderaCoreItem(Item.Properties properties) {
        super(properties);
    }

    public static boolean filled(ItemStack stack) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        return data != null && data.contains(KEY);
    }

    /** Data KALDERA yang tersimpan (salinan), atau null kalau kosong. */
    @Nullable
    static CompoundTag stored(ItemStack stack) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        if (data == null || !data.contains(KEY)) {
            return null;
        }
        return data.copyTag().getCompound(KEY);
    }

    /** Nama pemilik KALDERA yang tersimpan ("" kalau kosong). */
    static String storedOwner(ItemStack stack) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        return data == null ? "" : data.copyTag().getString(OWNER);
    }

    static void store(ItemStack stack, CompoundTag kaldera, String owner, float health, float maxHealth) {
        CompoundTag root = new CompoundTag();
        root.put(KEY, kaldera);
        root.putString(OWNER, owner);
        root.putFloat(HP, health);
        root.putFloat(MAX, maxHealth);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(root));
    }

    static void clear(ItemStack stack) {
        stack.remove(DataComponents.CUSTOM_DATA);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player instanceof ServerPlayer sp) {
            if (filled(stack)) {
                Kaldera.releaseFrom(sp, stack);
            } else {
                Kaldera.recallInto(sp, stack);
            }
            sp.getCooldowns().addCooldown(this, 40);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return filled(stack);
    }

    @Override
    public Component getName(ItemStack stack) {
        return filled(stack) ? Component.translatable("item.shazammod.kaldera_core.filled") : super.getName(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        if (data != null && data.contains(KEY)) {
            CompoundTag t = data.copyTag();
            tooltip.add(Component.translatable("item.shazammod.kaldera_core.stored", t.getString(OWNER)).withStyle(ChatFormatting.GREEN));
            tooltip.add(Component.translatable("item.shazammod.kaldera_core.health", (int) Math.ceil(t.getFloat(HP)), (int) t.getFloat(MAX))
                    .withStyle(ChatFormatting.GRAY));
            tooltip.add(Component.translatable("item.shazammod.kaldera_core.hint_full").withStyle(ChatFormatting.DARK_GREEN));
        } else {
            tooltip.add(Component.translatable("item.shazammod.kaldera_core.lore").withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.ITALIC));
            tooltip.add(Component.translatable("item.shazammod.kaldera_core.hint_empty").withStyle(ChatFormatting.GRAY));
        }
    }

    /** NeoForge: inti yang berisi titan nggak hilang dimakan waktu kalau terjatuh. Sengaja tanpa @Override. */
    public int getEntityLifespan(ItemStack stack, Level level) {
        return filled(stack) ? Integer.MAX_VALUE : 6000;
    }
}
