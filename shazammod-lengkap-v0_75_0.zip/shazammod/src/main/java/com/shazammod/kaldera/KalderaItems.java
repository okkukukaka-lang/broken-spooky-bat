package com.shazammod.kaldera;

import com.shazammod.LintangItems;
import com.shazammod.ShazamMod;

import net.minecraft.ChatFormatting;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * 0.75 Barang-barang KALDERA:
 * - Inti Kaldera (kaldera_core): memanggil KALDERA jinak pulang ke dalamnya & membangkitkannya lagi di mana saja (lihat
 *   KalderaCoreItem). Didapat saat menjinakkannya, atau dibuat dari 4 Pecahan Cryon + Mutiara Ender.
 * - Lempeng Antiradiasi: 2 batangan besi + 1 Pecahan Cryon = 2 lempeng; KALDERA liar yang tumbang menjatuhkan 8.
 * - Zirah Antiradiasi (helm, zirah, celana, sepatu): tiap bagian menahan 25% radiasi KALDERA, satu set penuh = kebal
 *   radiasinya (lihat Kaldera.radShield). Bahannya ShazamArmor.ANTIRADIASI.
 * Resep di data/shazammod/recipe/.
 */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class KalderaItems {
    private KalderaItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ShazamMod.MODID);

    public static final DeferredItem<KalderaCoreItem> KALDERA_CORE = ITEMS.register("kaldera_core",
            () -> new KalderaCoreItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));

    public static final DeferredItem<LintangItems.LoreItem> ANTIRAD_PLATE = ITEMS.register("antiradiasi_plate",
            () -> new LintangItems.LoreItem(new Item.Properties().rarity(Rarity.UNCOMMON), "item.shazammod.antiradiasi_plate",
                    ChatFormatting.DARK_GREEN, false));

    public static final DeferredItem<AntiradArmorItem> ANTIRAD_HELMET = armor("antiradiasi_helmet", ArmorItem.Type.HELMET);
    public static final DeferredItem<AntiradArmorItem> ANTIRAD_CHEST = armor("antiradiasi_chestplate", ArmorItem.Type.CHESTPLATE);
    public static final DeferredItem<AntiradArmorItem> ANTIRAD_LEGS = armor("antiradiasi_leggings", ArmorItem.Type.LEGGINGS);
    public static final DeferredItem<AntiradArmorItem> ANTIRAD_BOOTS = armor("antiradiasi_boots", ArmorItem.Type.BOOTS);

    private static DeferredItem<AntiradArmorItem> armor(String name, ArmorItem.Type type) {
        return ITEMS.register(name, () -> new AntiradArmorItem(type));
    }

    @SubscribeEvent
    public static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(ANTIRAD_HELMET.get());
            event.accept(ANTIRAD_CHEST.get());
            event.accept(ANTIRAD_LEGS.get());
            event.accept(ANTIRAD_BOOTS.get());
        }
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(ANTIRAD_PLATE.get());
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(KALDERA_CORE.get());
        }
    }
}
