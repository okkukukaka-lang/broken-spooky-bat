"""SFX KALDERA, Titan Radiasi (0.73, bos orisinal; 0.73.1 tema radiasi). Dibuat dari nol dengan synth.py (+ aksara_sfx.py).

    python3 tools/sfx/kaldera_sfx.py src/main/resources/assets/shazammod/sounds [nama ...]

Ciri suaranya: GUNUNG YANG TERCEMAR RADIASI. Tubuhnya tetap geologi (geraman sangat rendah dari perut bumi, nada dasar
40-55 Hz dengan formant "oo" yang gelap, batu bergesekan & retak, gemuruh panjang yang memantul), tapi intinya
radioaktif: dengung listrik rendah (harmonik 45-60 Hz), keretak ionisasi, sambaran listrik singkat, dan penghitung geiger
yang makin rapat saat intinya menghimpun tenaga. Puncaknya dikunci ke tick KalderaBody.* (20 tick = 1 dtk), putar di
pitch ~1:

    kaldera_emerge 6,5 dtk: kawah menembus tanah 1,2 (= EMERGE_BREACH), raungan 5,4 (= EMERGE_ROAR)
    kaldera_roar: puncak 0,8 (= ROAR_HIT) | kaldera_strain: mendongak 0-1,7, berhenti sebelum kaldera_stomp (= STOMP_HIT)
    kaldera_erupt: dengung naik & geiger makin rapat 0-2,0, LETUSAN INTI 2,0 (= ERUPT_FIRE) | kaldera_bomb_fly: 1,7 dtk
    (= BOMB_FLIGHT), diputar di titik jatuhnya | kaldera_geyser_warn 1,3 dtk (= GEYSER_DELAY) | kaldera_fall: hantaman
    2,1 (= FALL_HIT) | kaldera_rage: raungan 0,8, jerit kritis, ledakan 1,7 (= RAGE_BURST) | kaldera_death: ambruk 3,0
    (= DEATH_COLLAPSE), geiger melambat sampai diam, membatu 6,0 (= DEATH_STONE) | kaldera_geiger: detak pendek 1-4 klik,
    diputar client makin rapat saat pemain mendekat | 0.74 kaldera_feed: Batu Cryon diserap (denting kristal 0,5) |
    kaldera_tame: KALDERA tunduk (akor kristal 0,6, geiger melambat sampai diam) | 0.75 kaldera_prison: deret duri kristal
    merambat menjauh 2,5 dtk (= jarak / PRISON_SPEED) | kaldera_prison_trap: penjaranya menutup (juga pecah, pitch 1,45) |
    kaldera_quake: gempa peringatan 4,6 dtk (diputar tiap 4 dtk) | sisanya langsung (dipicu saat kejadiannya)
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_argv = sys.argv
sys.argv = [sys.argv[0]]
import synth as s                 # noqa: E402
import aksara_sfx as a            # noqa: E402  (alat bantu: place)
sys.argv = _argv

SR = s.SR
place = a.place


def n_of(dur):
    return int(dur * SR)


def env(dur, tau):
    return s.env_exp(n_of(dur), tau)


def ramp(dur, p=1.0, lo=0.0):
    return lo + (1 - lo) * np.linspace(0, 1, n_of(dur)) ** p


def slow_mod(n, rng, rate, depth, lo=0.25, hi=2.0):
    return np.clip(1 + depth * s.unit(s.lp(rng.standard_normal(n), rate)), lo, hi)


# ------------------------------------------------------------------ tubuh gunung (geologi)

def grind(dur, rng, f=140.0, depth=70.0, rate=7.0, amp=1.0):
    """Batu raksasa bergesekan: derau cokelat lewat pita yang bergoyang pelan."""
    n = n_of(dur)
    curve = f + depth * np.abs(np.sin(np.linspace(0, rate, 256) + rng.uniform(0, 3)))
    return s.sweep_filter(s.brown(n, rng), curve, "band", 1.7) * slow_mod(n, rng, 9, 0.6) * amp


def rumble(dur, rng, cut=120.0, amp=1.0, a=0.05, r=None):
    n = n_of(dur)
    y = s.lp(s.brown(n, rng), cut) * slow_mod(n, rng, 4, 0.55)
    return y * s.env_adsr(dur, a, 0.4, 0.8, r if r is not None else dur * 0.5) * amp


def vapor(dur, rng, lo=2500.0, hi=11000.0, amp=1.0, att=0.15):
    """Desis uap radioaktif dari celah-celahnya."""
    n = n_of(dur)
    y = s.bp(s.white(n, rng), lo, hi) * slow_mod(n, rng, 14, 0.35)
    return y * s.env_adsr(dur, att, 0.3, 0.75, dur * 0.45) * amp


def growl(dur, rng, f0=46.0, amp=1.0, vowel_end="o"):
    """Geraman gunung: sumber kasar sangat rendah, formant gelap, sub, & gesekan batu di dalamnya (bukan pekikan)."""
    n = n_of(dur)
    t = np.linspace(0, 1, n)
    jit = 1 + 0.05 * s.lp(rng.standard_normal(n), 18) * 22
    f = f0 * (1 + 0.18 * np.sin(np.pi * np.minimum(t * 1.3, 1))) * jit
    src = s.osc(f, dur, "saw") + 0.45 * s.osc(f * 0.5, dur, "square")
    src = src * (1 + 0.6 * s.lp(rng.standard_normal(n), 60) * 14)
    body = s.formant(src + s.bp(s.white(n, rng), 120, 1500) * 0.35, "o")
    if vowel_end != "o":
        w = np.clip(t * 1.4, 0, 1)
        body = body * (1 - w) + s.formant(src, vowel_end) * w
    sub = s.osc(f * 0.5, dur) * 0.9
    y = s.mix(s.lp(body, 900) * 1.4, sub, grind(dur, rng, 110, 60, 5, 0.6), s.lp(src, 260) * 0.5)
    return s.sat(y * s.env_adsr(dur, 0.12, 0.35, 0.85, dur * 0.45) * amp, 2.6)


def boom(rng, f0=44.0, dur=3.0, amp=1.0):
    return s.mix(s.thump(rng, f0, 16, dur, 1.1, 1.0, 0.55) * 1.4 * amp, s.sub_drop(90, 15, dur * 0.9, 1.4, 4) * 1.6 * amp,
                 s.lp(s.white(n_of(0.8), rng), 420) * env(0.8, 0.12) * 1.8 * amp)


def rocks(dur, rng, density=40.0, amp=1.0, curve=None):
    """Bebatuan berjatuhan & retak."""
    c = curve if curve is not None else np.linspace(1, 0.2, 30)
    y = 0
    for lo, hi in ((150, 600), (450, 1800), (1300, 4500)):
        y = y + s.crackle(dur, density, rng, lo, hi, 0.01, c)
    return y * amp


# ------------------------------------------------------------------ inti radioaktif

def hum(dur, rng, f0=50.0, amp=1.0, buzz=0.45, rise=None, wobble=0.25):
    """Dengung radiasi: dengung listrik rendah (harmonik f0) + dengung kasar di pita tengah, berdenyut pelan.
    rise = (kali awal, kali akhir) nada dasarnya untuk dengung yang naik/turun."""
    n = n_of(dur)
    f = f0 * (np.geomspace(rise[0], rise[1], n) if rise else np.ones(n))
    base = s.osc(f, dur) + 0.5 * s.osc(f * 2, dur) + 0.3 * s.osc(f * 3, dur) + 0.12 * s.osc(f * 5, dur)
    bz = s.bp(s.osc(f * 1.003, dur, "saw"), 250, 2600) * buzz
    beat = 1 + 0.18 * np.sin(2 * np.pi * 0.85 * np.arange(n) / SR + rng.uniform(0, 6))
    return (base * 0.55 + bz) * beat * slow_mod(n, rng, 3, wobble) * amp


def click_kernels(rng, count=6):
    k = n_of(0.01)
    tk = np.arange(k) / SR
    return [s.hp(rng.standard_normal(k), 1800) * np.exp(-tk / 0.0005) * 0.9
            + np.sin(2 * np.pi * rng.uniform(2500, 3300) * tk) * np.exp(-tk / 0.0014) * 0.45 for _ in range(count)]


def geiger(dur, rng, rate_curve, amp=1.0):
    """Penghitung geiger: klik tajam acak (proses Poisson), kerapatannya mengikuti kurva (klik per detik)."""
    n = n_of(dur)
    y = np.zeros(n)
    curve = np.interp(np.arange(n), np.linspace(0, n - 1, len(rate_curve)), np.asarray(rate_curve, float))
    kernels = click_kernels(rng)
    k = len(kernels[0])
    t = rng.exponential(1.0 / max(curve[0], 0.5))
    while t < dur:
        i = min(int(t * SR), n - 1)
        if curve[i] > 0.05:
            ker = kernels[rng.integers(len(kernels))] * rng.uniform(0.6, 1.0)
            e = min(n, i + k)
            y[i:e] += ker[: e - i]
        t += rng.exponential(1.0 / max(curve[i], 0.5))
    return y * amp


def ions(dur, rng, density=300.0, amp=1.0, curve=None):
    """Keretak ionisasi: percikan listrik halus bernada tinggi."""
    return s.crackle(dur, density, rng, 3000, 12000, 0.0012, curve) * amp


def zap(rng, f0=1800.0, f1=110.0, dur=0.4, amp=1.0):
    """Sambaran listrik singkat: nada kasar yang menukik + keretak yang mereda."""
    n = n_of(dur)
    sweep = s.bp(s.osc(np.geomspace(f0, f1, n), dur, "saw"), 120, 6500) * env(dur, dur * 0.3)
    fizz = s.crackle(dur, 1100, rng, 2500, 11000, 0.0015, np.linspace(1, 0, 20) ** 1.5)
    return s.sat(sweep * 0.8 + fizz * 0.9, 2.2) * amp


def pulse(rng, dur=1.4, amp=1.0):
    """Denyut radiasi yang mengembang: 'vwuum' rendah yang menukik + desis terang yang membengkak lalu lewat."""
    n = n_of(dur)
    tone = s.osc(np.geomspace(900, 45, n), dur) * env(dur, dur * 0.35)
    swell = s.sweep_filter(s.white(n, rng), np.geomspace(7000, 600, 64), "band", 1.2) * np.sin(np.pi * np.linspace(0, 1, n)) ** 1.4
    return s.sat(tone * 1.1 + swell * 0.7, 1.8) * amp


# ------------------------------------------------------------------ resep

def kaldera_step(rng, v):          # telapak raksasa mendarat: dentum berat, tanah remuk, kerikil, gemuruh singkat, sedikit geiger
    total = 2.6
    thud = s.mix(s.thump(rng, 52 - 4 * v, 20, 1.6, 0.6, 1.0, 0.5) * 1.6, s.sub_drop(80, 22, 1.4, 0.5, 5) * 1.3,
                 s.lp(s.white(n_of(0.25), rng), 700) * env(0.25, 0.05) * 1.6)
    crunch = rocks(0.9, rng, 160, 0.9, np.linspace(1, 0, 20) ** 1.6)
    rum = rumble(total, rng, 110, 1.0, 0.01, 1.8)
    y = place(total, (0, thud), (0.01, crunch), (0, rum), (0.05, rocks(1.6, rng, 25, 0.35)),
              (0.06, geiger(0.9, rng, (30, 12, 4), 0.22)))
    return s.limiter(s.reverb(s.sat(y, 1.8), 2.2, 0.28, rng=rng, size=2.2), 0.95)


def kaldera_roar(rng, v):          # raungan gunung: menghimpun, PUNCAK 0,8 dtk (= ROAR_HIT), geraman panjang, dengung & keretak
    total = 3.8
    pre = growl(0.9, rng, 40, 0.5) * ramp(0.9, 1.6, 0.2)
    main = growl(2.6, rng, 48, 1.2, "a")
    blast = s.mix(s.lp(s.white(n_of(1.2), rng), 1600) * env(1.2, 0.35) * 0.9, s.sub_drop(70, 28, 1.6, 0.6, 4) * 1.0)
    y = place(total, (0, pre), (0.7, main), (0.78, blast), (0.6, hum(2.8, rng, 55, 0.35) * env(2.8, 1.4)),
              (0.8, ions(2.4, rng, 260, 0.5, np.linspace(1, 0.1, 20))), (0.9, vapor(2.2, rng, 2500, 9000, 0.2, 0.3)),
              (0.8, rocks(2.4, rng, 30, 0.4)), (0, rumble(total, rng, 100, 0.9, 0.3, 1.6)))
    return s.limiter(s.reverb(s.sat(y, 1.6), 3.4, 0.32, rng=rng, size=2.8), 0.95)


def kaldera_strain(rng, v):        # mendongak 1,7 dtk: geraman menahan beban, batu berderak, dengung menegang
    total = 1.75
    g = growl(total, rng, 38, 0.8) * ramp(total, 0.8, 0.3)
    creak = grind(total, rng, 180, 120, 9, 1.1) * ramp(total, 1.2, 0.4)
    y = place(total, (0, g), (0, creak), (0.2, rocks(1.4, rng, 30, 0.45, np.linspace(0.3, 1, 30))),
              (0, hum(total, rng, 50, 0.3, rise=(0.9, 1.25)) * ramp(total, 1.5, 0.2)))
    return s.fade(s.reverb(s.sat(y, 1.6), 2.0, 0.25, rng=rng, size=2.0), 0.01, 0.06)


def kaldera_stomp(rng, v):         # Injakan Bumi: DENTUM raksasa, tanah terbelah & berkeretak, gelombang kejut, gemuruh yang memantul
    total = 6.5
    crack = s.mix(s.transient(0.03, 500, 0.006, 3.4, rng), s.lp(s.white(n_of(0.4), rng), 1100) * env(0.4, 0.06) * 2.0)
    items = [(0, crack), (0, boom(rng, 40 - 3 * v, 4.0, 1.1)), (0.02, rocks(2.2, rng, 140, 1.0, np.linspace(1, 0, 30) ** 1.3)),
             (0, rumble(total, rng, 140, 1.6, 0.02, 4.6)), (0.1, s.earth_crack(rng, 0) * 0.6),
             (0.15, s.air_whoosh(2.4, rng, 500, 1600, 200, 0.8, 0.1) * 0.7), (0.04, ions(1.2, rng, 500, 0.6, np.linspace(1, 0, 20) ** 2)),
             (0.05, geiger(1.6, rng, (160, 40, 6), 0.35))]
    for d, g in ((1.3, 0.45), (2.5, 0.3), (3.8, 0.18)):   # gema dari bukit-bukit
        items.append((d + rng.uniform(-0.1, 0.1), s.mix(s.thump(rng, 46, 18, 2.0, 0.7, 0.8, 0.5), s.sub_drop(70, 20, 1.8, 0.6, 4)) * g))
    return s.limiter(s.reverb(s.sat(place(total, *items), 1.9), 4.5, 0.3, rng=rng, size=3.0), 0.95)


def kaldera_erupt(rng, v):         # Letusan Inti: dengung naik, geiger makin rapat sampai mendengung (0-2,0), LETUSAN 2,0
    F, total = 2.0, 8.0            #   (= ERUPT_FIRE): ledakan, sambaran, denyut radiasi, tiang cahaya menderu & berkeretak
    n = n_of(F)
    whine = s.osc(np.geomspace(260, 2200, n), F) * ramp(F, 2.2) * 0.12
    build = s.mix(rumble(F, rng, 90, 1.1, 0.3, 0.05) * ramp(F, 1.6, 0.2), hum(F, rng, 42, 0.9, 0.6, rise=(0.7, 2.4)) * ramp(F, 1.4, 0.15),
                  geiger(F, rng, np.geomspace(6, 700, 40), 0.6), ions(F, rng, 400, 0.6, np.linspace(0.05, 1, 20) ** 2), whine) * 0.55
    blast = s.mix(s.transient(0.04, 700, 0.008, 3.8, rng), boom(rng, 38, 4.5, 1.7), zap(rng, 2600, 70, 0.7, 1.3),
                  s.crackle(1.0, 1800, rng, 1200, 9000, 0.002, np.linspace(1, 0, 20) ** 2) * 1.1)
    jet = s.sweep_filter(s.pink(n_of(5.5), rng), np.concatenate([np.geomspace(300, 1400, 20), np.geomspace(1400, 500, 44)]), "band", 0.9)
    jet = jet * s.env_adsr(5.5, 0.05, 0.6, 0.8, 3.5) * slow_mod(n_of(5.5), rng, 10, 0.4) * 1.2
    y = place(total, (0, build), (F, blast), (F + 0.05, pulse(rng, 1.4, 1.1)), (F, jet), (F + 0.1, rocks(3.0, rng, 45, 0.6)),
              (F, rumble(total - F, rng, 120, 1.3, 0.02, 4.0)), (F, hum(total - F, rng, 60, 0.7, 0.5) * env(total - F, 2.6)),
              (F + 0.1, geiger(total - F, rng, np.geomspace(500, 15, 40), 0.5)),
              (F + 0.2, ions(total - F - 0.2, rng, 350, 0.7, np.linspace(1, 0.1, 30))))
    return s.limiter(s.reverb(s.sat(y, 1.8), 4.5, 0.32, rng=rng, size=3.0), 0.95)


def kaldera_bomb_fly(rng, v):      # bongkahan uranium mendekat 1,7 dtk (= BOMB_FLIGHT): deru yang makin keras, dengung & keretak
    dur = 1.7
    n = n_of(dur)
    roar_ = s.sweep_filter(s.pink(n, rng), np.geomspace(1800 + 300 * v, 420, 64), "band", 1.4) * ramp(dur, 2.4, 0.05) * 1.4
    drone = s.bp(s.osc(np.geomspace(240 + 20 * v, 150, n), dur, "saw"), 120, 2400) * ramp(dur, 2.0, 0.05) * 0.45
    fizz = ions(dur, rng, 220, 0.55, np.linspace(0.2, 1, 30))
    tick = geiger(dur, rng, np.geomspace(5, 160, 30), 0.3)
    return s.fade(s.sat(s.mix(roar_, drone, fizz, tick), 1.5), 0.05, 0.02)


def kaldera_bomb(rng, v):          # bongkahan uranium menghantam: ledakan, sambaran, batu berhamburan, geiger yang mereda
    total = 3.0
    hit = s.mix(s.transient(0.03, 800, 0.006, 3.2, rng), s.thump(rng, 70 - 6 * v, 28, 1.4, 0.45, 1.0, 0.6) * 1.4,
                s.lp(s.white(n_of(0.5), rng), 1400) * env(0.5, 0.08) * 1.6)
    y = place(total, (0, hit), (0.01, zap(rng, 1500 + 200 * v, 90, 0.45, 0.8)),
              (0.05, rocks(1.6, rng, 80, 0.8, np.linspace(1, 0, 20) ** 1.4)), (0.05, ions(2.0, rng, 300, 0.6, np.linspace(1, 0, 20))),
              (0.1, vapor(2.2, rng, 2500, 10000, 0.3, 0.02)), (0.08, geiger(2.6, rng, np.geomspace(260, 6, 30), 0.45)),
              (0, rumble(total, rng, 140, 0.9, 0.01, 2.0)))
    return s.limiter(s.reverb(s.sat(y, 1.7), 2.4, 0.28, rng=rng, size=2.2), 0.95)


def kaldera_geyser_warn(rng, v):   # tanah merekah menyala hijau 1,3 dtk (= GEYSER_DELAY): retakan, dengung naik, geiger makin rapat
    dur = 1.3
    y = s.mix(rocks(dur, rng, 60, 0.7, np.linspace(0.2, 1.0, 30)), hum(dur, rng, 55, 0.7, 0.6, rise=(0.8, 1.9)) * ramp(dur, 1.4, 0.1),
              rumble(dur, rng, 100, 0.8, 0.5, 0.05) * ramp(dur, 1.2, 0.3), geiger(dur, rng, np.geomspace(10, 380, 30), 0.6),
              vapor(dur, rng, 1500, 8000, 0.4, 0.9) * ramp(dur, 1.6))
    return s.fade(s.sat(y, 1.5), 0.02, 0.03)


def kaldera_geyser(rng, v):        # ventilasi radiasi menyembur: semburan menderu, sambaran, desis uap, keretak & geiger
    total = 3.0
    burst = s.mix(s.transient(0.03, 600, 0.006, 2.8, rng), s.thump(rng, 64 - 4 * v, 26, 1.2, 0.4, 0.9, 0.5) * 1.2)
    gush = s.sweep_filter(s.pink(n_of(2.4), rng), np.geomspace(500, 2200, 64), "band", 1.0) * s.env_adsr(2.4, 0.03, 0.4, 0.7, 1.4) * 1.3
    y = place(total, (0, burst), (0, gush), (0.02, zap(rng, 2000, 160, 0.35, 0.7)), (0.2, vapor(2.6, rng, 2500, 11000, 0.45, 0.05)),
              (0.05, ions(2.4, rng, 320, 0.6, np.linspace(1, 0.1, 20))), (0.05, geiger(2.4, rng, np.geomspace(220, 10, 30), 0.4)),
              (0.4, rocks(1.8, rng, 40, 0.4)), (0, rumble(total, rng, 120, 0.8, 0.01, 2.0)))
    return s.limiter(s.reverb(s.sat(y, 1.6), 2.6, 0.3, rng=rng, size=2.3), 0.95)


def kaldera_fall(rng, v):          # Gunung Runtuh: geraman naik & tubuh terangkat (0-1,5), jatuh menderu, HANTAMAN 2,1 (= FALL_HIT),
    H, total = 2.1, 9.0            #   gemuruh panjang, batu-batu berguguran, tanah berkeretak
    rise = s.mix(growl(1.6, rng, 42, 0.9) * ramp(1.6, 0.7, 0.3), grind(1.6, rng, 160, 100, 8, 0.8))
    drop = s.air_whoosh(0.7, rng, 250, 900, 160, 1.0, 0.85) * 1.1
    crack = s.mix(s.transient(0.04, 400, 0.008, 3.8, rng), s.lp(s.white(n_of(0.5), rng), 900) * env(0.5, 0.08) * 2.2)
    items = [(0, rise), (H - 0.6, drop), (H, crack), (H, boom(rng, 34, 5.0, 1.5)), (H + 0.02, rocks(4.0, rng, 120, 1.1)),
             (H, rumble(total - H, rng, 130, 1.8, 0.02, 5.0)), (H + 0.15, s.earth_crack(rng, 0) * 0.8),
             (H + 0.03, ions(2.0, rng, 450, 0.6, np.linspace(1, 0, 20) ** 1.5)), (H + 0.05, geiger(3.0, rng, np.geomspace(300, 8, 30), 0.4))]
    for d, g in ((1.4, 0.5), (2.7, 0.32), (4.1, 0.2)):
        items.append((H + d, s.mix(s.thump(rng, 40, 16, 2.2, 0.8, 0.8, 0.5), s.sub_drop(60, 18, 2.0, 0.7, 4)) * g))
    return s.limiter(s.reverb(s.sat(place(total, *items), 1.9), 5.0, 0.32, rng=rng, size=3.0), 0.95)


def kaldera_rage(rng, v):          # KRITIS: raungan terbesar (puncak 0,8 = ROAR_HIT), jerit inti yang naik & geiger mendengung,
    B, total = 1.7, 9.0            #   lalu ledakan inti 1,7 (= RAGE_BURST): sambaran, denyut radiasi, tiang cahaya menderu
    roar_ = s.mix(growl(0.9, rng, 38, 0.35) * ramp(0.9, 1.5, 0.2))
    main = s.mix(growl(3.2, rng, 44, 1.5, "a"), s.lp(s.white(n_of(1.0), rng), 1400) * env(1.0, 0.3) * 0.7)
    main = main * np.interp(np.arange(len(main)) / SR, [0, 0.55, 0.98, 3.2], [1, 1, 0.3, 0.15])   # mereda sebelum ledakan inti
    w = B - 0.6
    nw = n_of(w)
    scream = s.osc(np.geomspace(380, 1700, nw), w) * (0.7 + 0.3 * np.sin(2 * np.pi * 9 * np.arange(nw) / SR)) * ramp(w, 1.5, 0.1) * 0.22
    charge = s.mix(scream, geiger(w, rng, np.geomspace(60, 900, 30), 0.6), hum(w, rng, 50, 0.8, 0.7, rise=(1.0, 2.6)) * ramp(w, 1.2, 0.3)) * 0.55
    blast = s.mix(s.transient(0.05, 600, 0.01, 4.2, rng), boom(rng, 34, 5.5, 1.9), zap(rng, 3000, 60, 0.9, 1.4),
                  s.crackle(1.4, 2000, rng, 1200, 10000, 0.002, np.linspace(1, 0, 20) ** 2) * 1.2)
    jet = s.sweep_filter(s.pink(n_of(6.0), rng), np.geomspace(1200, 350, 64), "band", 0.9) * s.env_adsr(6.0, 0.05, 0.7, 0.8, 4.0) * 1.2
    y = place(total, (0, roar_), (0.7, main), (0.6, charge), (B, blast), (B + 0.05, pulse(rng, 1.8, 1.3)), (B, jet),
              (B + 0.1, rocks(4.0, rng, 50, 0.7)), (0, rumble(total, rng, 120, 1.6, 0.4, 5.0)),
              (B, hum(total - B, rng, 62, 0.8, 0.6) * env(total - B, 3.2)), (B + 0.2, ions(5.0, rng, 380, 0.7, np.linspace(1, 0.1, 30))),
              (B + 0.1, geiger(total - B, rng, np.geomspace(600, 30, 40), 0.5)))
    return s.limiter(s.reverb(s.sat(y, 1.9), 5.0, 0.34, rng=rng, size=3.2), 0.95)


def kaldera_hurt(rng, v):          # kena pukul: batu retak, percikan listrik, geraman pendek tertahan
    total = 1.2
    crack = s.mix(s.transient(0.02, 900, 0.004, 2.4, rng), rocks(0.5, rng, 200, 0.8, np.linspace(1, 0, 20) ** 2))
    g = growl(0.7, rng, 52 + 6 * v, 0.7) * env(0.7, 0.35)
    y = place(total, (0, crack), (0.03, g), (0, s.thump(rng, 70, 30, 0.6, 0.2, 0.8, 0.4) * 0.8),
              (0.01, ions(0.4, rng, 900, 0.5, np.linspace(1, 0, 20) ** 2)), (0.02, geiger(0.5, rng, (60, 10), 0.3)))
    return s.limiter(s.reverb(s.sat(y, 1.6), 1.6, 0.25, rng=rng, size=1.8), 0.95)


def kaldera_death(rng, v):         # tumbang: raungan lemah, tubuh retak, dengung turun & melemah, AMBRUK 3,0 (= DEATH_COLLAPSE),
    C, S, total = 3.0, 6.0, 10.0   #   geiger melambat sampai diam, lalu batu mengendap jadi gunung 6,0 (= DEATH_STONE)
    weak = growl(1.8, rng, 40, 0.9, "u") * env(1.8, 0.9)
    cracks = rocks(C, rng, 50, 0.7, np.linspace(0.4, 1.0, 30))
    groan = grind(C, rng, 120, 80, 6, 0.9) * ramp(C, 1.0, 0.3)
    collapse = s.mix(boom(rng, 36, 4.5, 1.3), rocks(3.0, rng, 140, 1.0, np.linspace(1, 0.1, 30)))
    die_down = hum(7.0, rng, 52, 0.75, 0.5, rise=(1.0, 0.32)) * np.linspace(1, 0, n_of(7.0)) ** 1.6
    ticks = geiger(8.0, rng, np.concatenate([np.geomspace(80, 30, 12), np.geomspace(30, 1.2, 20), np.zeros(8)]), 0.45)
    settle = s.mix(s.thump(rng, 38, 14, 3.0, 1.0, 0.9, 0.5) * 0.9, rumble(3.5, rng, 90, 1.2, 0.3, 2.5), rocks(3.0, rng, 40, 0.6))
    y = place(total, (0, weak), (0.8, cracks), (0.8, groan), (0, die_down), (0, ticks), (C, collapse),
              (C, rumble(total - C, rng, 120, 1.3, 0.02, 4.0)), (C + 0.5, vapor(4.0, rng, 2500, 10000, 0.35, 0.1)), (S, settle))
    return s.limiter(s.reverb(s.sat(y, 1.7), 5.0, 0.32, rng=rng, size=3.0), 0.95)


def kaldera_ambient(rng, v):       # napas gunung: geraman pelan, dengung inti, geiger yang jarang, keretak tipis
    total = 3.2
    breath = growl(2.6, rng, 36 + 4 * v, 0.55) * np.sin(np.pi * np.linspace(0, 1, n_of(2.6))) ** 1.2
    y = place(total, (0.1, breath), (0, hum(total, rng, 48 + 4 * v, 0.4, 0.5) * np.sin(np.pi * np.linspace(0, 1, n_of(total))) ** 0.6),
              (0, geiger(total, rng, (8, 14, 6, 12), 0.3)), (0.3, ions(2.6, rng, 60, 0.35)), (0, rumble(total, rng, 80, 0.6, 0.6, 1.4)))
    return s.reverb(s.sat(y, 1.4), 2.6, 0.3, rng=rng, size=2.4)


def kaldera_emerge(rng, v):        # bangkit 6,5 dtk: bumi bergemuruh makin keras, KAWAH MENEMBUS TANAH 1,2 (= EMERGE_BREACH),
    B, R, total = 1.2, 5.4, 8.5    #   gunung terangkat (batu bergesekan, dengung inti makin keras), RAUNGAN 5,4 (= EMERGE_ROAR)
    quake = rumble(total, rng, 100, 1.6, 0.8, 2.5) * np.clip(np.linspace(0.4, 1.4, n_of(total)), 0, 1.2)
    breach = s.mix(s.transient(0.04, 500, 0.008, 3.4, rng), boom(rng, 40, 3.5, 1.1), s.earth_crack(rng, 0) * 0.9,
                   zap(rng, 2200, 80, 0.6, 0.9))
    rise = s.mix(grind(R - B, rng, 130, 90, 10, 0.8), rocks(R - B, rng, 70, 0.7, np.linspace(0.6, 1.0, 30)),
                 vapor(R - B, rng, 2000, 8000, 0.2, 0.8)) * np.linspace(1.0, 0.45, n_of(R - B))
    core = s.mix(hum(R - B, rng, 46, 0.8, 0.5, rise=(0.8, 1.3)) * ramp(R - B, 1.0, 0.2),
                 geiger(R - B, rng, np.geomspace(20, 160, 30), 0.35), ions(R - B, rng, 160, 0.4))
    roar_ = s.mix(growl(2.8, rng, 44, 1.9, "a"), s.lp(s.white(n_of(1.0), rng), 1400) * env(1.0, 0.3) * 0.8)
    items = [(0, quake), (B, breach), (B, rise), (B, core), (R - 0.1, roar_), (R, s.sub_drop(70, 28, 1.6, 0.6, 4) * 1.0),
             (R, hum(2.8, rng, 56, 0.5) * env(2.8, 1.2))]
    for k in range(4):
        items.append((B + 0.6 + k * 0.9 + rng.uniform(-0.15, 0.15), s.earth_crack(rng, 0) * 0.4))
    return s.limiter(s.reverb(s.sat(place(total, *items), 1.8), 4.5, 0.32, rng=rng, size=3.0), 0.95)


def kaldera_sink(rng, v):          # tenggelam ke perut bumi: gemuruh & gesekan batu yang makin dalam, dengungnya menjauh
    total = 6.0
    y = s.mix(rumble(total, rng, 100, 1.5, 0.3, 3.0), grind(total, rng, 120, 60, 8, 0.9) * np.linspace(1, 0.2, n_of(total)),
              rocks(total, rng, 40, 0.6, np.linspace(1, 0.1, 30)), growl(2.0, rng, 34, 0.5) * 1.0,
              hum(total, rng, 46, 0.45, 0.4, rise=(1.0, 0.6)) * np.linspace(1, 0, n_of(total)) ** 1.3)
    return s.limiter(s.reverb(s.sat(y, 1.6), 4.0, 0.3, rng=rng, size=2.8), 0.95)


def crystal_chime(freqs, dur, rng, start=0.0, gap=0.07, tau=1.4, amp=1.0):
    """Denting kristal: lonceng-lonceng tinggi yang berbunyi berurutan (arpeggio), ekornya panjang."""
    y = np.zeros(n_of(dur))
    for i, f in enumerate(freqs):
        t0 = start + i * gap
        b = s.bell(f, dur - t0, rng, ((1, 1), (2.41, 0.45), (4.9, 0.22), (7.6, 0.1)), tau, 0.002)
        j = n_of(t0)
        y[j:j + len(b)] += b[: len(y) - j] * (0.8 + 0.2 * rng.uniform())
    return y * amp


def kaldera_feed(rng, v):          # 0.74 Batu Cryon diserap intinya: tarikan uap, denting kristal naik, dengung inti membengkak
    total = 2.4
    pull = s.reverse_swell(0.5, rng, 1200, 9000) * 0.7
    absorb = s.mix(s.thump(rng, 60, 30, 1.0, 0.35, 0.7, 0.4) * 0.8, s.sub_drop(110, 45, 1.2, 0.5, 4) * 0.6)
    swell = hum(1.9, rng, 55, 0.7, 0.4, rise=(0.85, 1.5)) * np.sin(np.pi * np.linspace(0, 1, n_of(1.9))) ** 1.2
    base = 1046.5 * (1.0 + 0.06 * v)
    chime = crystal_chime([base, base * 1.26, base * 1.5, base * 2.0], 1.9, rng, 0.0, 0.06, 1.1, 0.55)
    y = place(total, (0, pull), (0.48, absorb), (0.45, swell), (0.5, chime),
              (0.5, ions(1.2, rng, 260, 0.4, np.linspace(1, 0, 20) ** 1.5)), (0.5, geiger(1.4, rng, (90, 30, 6), 0.3)))
    return s.limiter(s.reverb(s.sat(y, 1.4), 2.6, 0.32, rng=rng, size=2.2), 0.95)


def kaldera_tame(rng, v):          # 0.74 KALDERA tunduk: hela napas gunung yang tenang, akor kristal hangat, geiger melambat
    total = 6.5                    #   sampai diam, dengungnya mereda jadi lembut, tanah mengendap
    sigh = growl(3.0, rng, 38, 0.9, "u") * np.sin(np.pi * np.linspace(0, 1, n_of(3.0))) ** 0.9
    root = 523.25
    chord = s.mix(crystal_chime([root, root * 1.25, root * 1.5, root * 2.0, root * 2.5], 5.0, rng, 0.0, 0.11, 2.2, 0.6),
                  crystal_chime([root * 0.5, root * 0.75], 5.0, rng, 0.05, 0.2, 2.6, 0.35))
    calm = hum(5.5, rng, 50, 0.7, 0.3, rise=(1.25, 0.9)) * np.linspace(1, 0, n_of(5.5)) ** 1.4
    ticks = geiger(4.0, rng, np.concatenate([np.geomspace(60, 4, 24), np.zeros(6)]), 0.35)
    y = place(total, (0, sigh), (0.6, chord), (0, calm), (0, ticks), (0.2, rumble(4.0, rng, 90, 0.9, 0.3, 3.0)),
              (0.5, vapor(3.0, rng, 2500, 9000, 0.25, 0.4)), (0.55, s.sub_drop(80, 30, 2.0, 0.9, 4) * 0.7))
    return s.limiter(s.reverb(s.sat(y, 1.3), 4.0, 0.36, rng=rng, size=2.8), 0.95)


def crystal_hit(rng, f, amp=1.0, cut=14000.0):
    """Satu duri kristal menyeruak: retak kaca yang tajam, denting pendek, & tanah yang remuk di bawahnya."""
    snap = s.transient(0.05, 2500, 0.006, 1.6, rng)
    ping = s.bell(f, 0.4, rng, ((1, 1), (2.41, 0.5), (3.93, 0.28), (6.3, 0.14)), 0.09, 0.004) * 0.55
    crunch = s.bp(s.white(n_of(0.12), rng), 300, 1800) * env(0.12, 0.025) * 0.9
    return s.lp(s.mix(snap, ping, crunch), cut) * amp


def kaldera_prison(rng, v):        # 0.75 Penjara Kristal: kaki menghentak, lalu deret duri kristal menyeruak merambat menjauh
    total = 3.6                    #   (retak kaca + denting berderet tiap ±0,06 dtk, makin jauh makin pelan & redup), batu berderak
    stamp = s.mix(s.thump(rng, 58 - 3 * v, 24, 1.2, 0.45, 0.9, 0.5) * 1.3, s.sub_drop(90, 30, 1.0, 0.4, 5) * 0.9)
    line = np.zeros(n_of(2.9))
    t = 0.04
    while t < 2.5:                 # PRISON_SPEED 1,6 blok/tick & SPIKE_GAP 2 blok = satu duri tiap 1,25 tick
        u = t / 2.5
        hit = crystal_hit(rng, 1700 * (1.0 + 0.3 * rng.uniform()) * (1 + 0.04 * v), (1 - u) ** 1.4 * 0.9, 14000 * (1 - 0.75 * u))
        j = n_of(t)
        line[j:j + len(hit)] += hit[: len(line) - j]
        t += 0.0625 * (0.8 + 0.4 * rng.uniform())
    creep = s.mix(grind(2.6, rng, 220, 160, 12, 0.7), rocks(2.6, rng, 120, 0.7, np.linspace(1, 0.05, 30) ** 1.2))
    creep = s.lp(creep, 3000) * np.linspace(1, 0.15, n_of(2.6)) ** 1.2
    charge = hum(2.2, rng, 55, 0.5, 0.6, rise=(1.0, 1.7)) * np.sin(np.pi * np.linspace(0, 1, n_of(2.2))) ** 1.5
    y = place(total, (0, stamp), (0.01, rocks(0.8, rng, 160, 0.8, np.linspace(1, 0, 20) ** 1.6)), (0.03, line), (0.05, creep),
              (0.02, charge), (0.05, ions(2.4, rng, 380, 0.5, np.linspace(1, 0.05, 30))), (0, rumble(total, rng, 110, 0.7, 0.01, 2.4)),
              (0.1, crystal_chime([2093.0, 2637.0, 3136.0], 2.0, rng, 0.0, 0.05, 0.9, 0.25)))
    return s.limiter(s.reverb(s.sat(y, 1.5), 2.8, 0.3, rng=rng, size=2.4), 0.95)


def kaldera_prison_trap(rng, v):   # 0.75 penjaranya menutup: kristal-kristal besar menyeruak hampir bersamaan, akor kristal yang
    total = 2.4                    #   bergaung panjang, dentum pendek, sambaran kecil & geiger
    y = np.zeros(n_of(total))
    for i in range(6):             # sembilan kristalnya menyeruak dalam ±0,1 dtk
        hit = crystal_hit(rng, 1200 * (1.0 + 0.5 * rng.uniform()), 1.0 - 0.08 * i)
        j = n_of(0.012 + i * 0.017 + rng.uniform(0, 0.01))
        y[j:j + len(hit)] += hit[: len(y) - j]
    root = 659.25 * (1.0 + 0.03 * v)
    chord = crystal_chime([root, root * 1.2, root * 1.5, root * 2.0, root * 2.4], 2.2, rng, 0.02, 0.03, 1.2, 0.6)
    y = place(total, (0, y), (0, chord), (0, s.thump(rng, 70, 30, 0.9, 0.3, 0.7, 0.6) * 0.9), (0.01, zap(rng, 2600, 300, 0.3, 0.45)),
              (0.02, ions(1.4, rng, 300, 0.45, np.linspace(1, 0, 20) ** 1.5)), (0.05, geiger(1.4, rng, np.geomspace(140, 8, 20), 0.3)),
              (0.03, rocks(0.9, rng, 90, 0.5, np.linspace(1, 0, 20) ** 1.5)))
    return s.limiter(s.reverb(s.sat(y, 1.4), 3.0, 0.34, rng=rng, size=2.4), 0.95)


def kaldera_quake(rng, v):         # 0.75 gempa peringatan (diputar tiap 4 dtk, makin keras): gemuruh bumi yang bergulung pelan,
    total = 4.6                    #   batu & kerikil bergetar, derak tanah, geraman yang sangat jauh di dalam bumi
    n = n_of(total)
    roll = s.lp(s.brown(n, rng), 75) * slow_mod(n, rng, 2.2, 0.7, 0.15, 2.4) * 2.2
    body = s.bp(s.pink(n, rng), 40, 180) * slow_mod(n, rng, 5, 0.6) * 0.8
    shape = np.sin(np.pi * np.linspace(0, 1, n)) ** 0.8
    rattle = rocks(total, rng, 35, 0.45, 0.4 + 0.6 * np.sin(np.pi * np.linspace(0, 1, 30)) ** 2)
    creak = s.lp(grind(total, rng, 120, 60, 4, 0.6), 900) * np.sin(np.pi * np.linspace(0, 1, n)) ** 2
    groan = s.lp(growl(2.4, rng, 30 + 2 * v, 0.6, "u"), 260) * np.sin(np.pi * np.linspace(0, 1, n_of(2.4))) ** 1.5
    y = place(total, (0, (roll + body) * shape), (0, rattle), (0, creak), (1.2, groan),
              (0.5, hum(3.4, rng, 44, 0.25, 0.5) * np.sin(np.pi * np.linspace(0, 1, n_of(3.4))) ** 2))
    return s.fade(s.limiter(s.reverb(s.sat(y, 1.6), 3.0, 0.28, rng=rng, size=3.0), 0.95), 0.3, 0.6)


GEIGER_TIMES = ((0.004,), (0.004, 0.071), (0.004, 0.038, 0.097, 0.131))


def kaldera_geiger(rng, v):        # detak geiger pendek (1, 2, atau 4 klik): diputar client makin rapat saat mendekat
    total = 0.3
    kernels = click_kernels(rng, 4)
    y = np.zeros(n_of(total))
    for i, t in enumerate(GEIGER_TIMES[v]):
        k = kernels[i % len(kernels)] * (1.0 if i == 0 else rng.uniform(0.65, 0.95))
        j = n_of(t)
        y[j:j + len(k)] += k
    return s.reverb(y, 0.25, 0.08, rng=rng, size=0.4)


RECIPES = {
    "kaldera_emerge": (kaldera_emerge, 1, 1.0),
    "kaldera_roar": (kaldera_roar, 2, 1.0),
    "kaldera_step": (kaldera_step, 3, 0.95),
    "kaldera_strain": (kaldera_strain, 1, 0.9),
    "kaldera_stomp": (kaldera_stomp, 2, 1.0),
    "kaldera_erupt": (kaldera_erupt, 1, 1.0),
    "kaldera_bomb_fly": (kaldera_bomb_fly, 2, 0.85),
    "kaldera_bomb": (kaldera_bomb, 3, 0.95),
    "kaldera_geyser_warn": (kaldera_geyser_warn, 1, 0.85),
    "kaldera_geyser": (kaldera_geyser, 2, 0.95),
    "kaldera_fall": (kaldera_fall, 1, 1.0),
    "kaldera_rage": (kaldera_rage, 1, 1.0),
    "kaldera_hurt": (kaldera_hurt, 3, 0.85),
    "kaldera_death": (kaldera_death, 1, 1.0),
    "kaldera_ambient": (kaldera_ambient, 2, 0.75),
    "kaldera_sink": (kaldera_sink, 1, 0.95),
    "kaldera_geiger": (kaldera_geiger, 3, 0.85),
    "kaldera_feed": (kaldera_feed, 2, 0.9),
    "kaldera_tame": (kaldera_tame, 1, 0.95),
    "kaldera_prison": (kaldera_prison, 2, 0.95),
    "kaldera_prison_trap": (kaldera_prison_trap, 2, 0.9),
    "kaldera_quake": (kaldera_quake, 2, 1.0),
}
WINDUPS = set()
LOOPS = set()

s.RECIPES.update(RECIPES)
s.WINDUPS.update(WINDUPS)
s.LOOPS.update(LOOPS)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "out"
    only = sys.argv[2:] if len(sys.argv) > 2 else None
    os.makedirs(out, exist_ok=True)
    for name, (fn, count, gain) in RECIPES.items():
        if only and name not in only:
            continue
        for v in range(count):
            y = s.render(name, fn, v, gain)
            fname = f"{name}_{v + 1}.ogg"
            s.encode(y, os.path.join(out, fname))
            rms = 20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)
            print(fname, round(len(y) / SR, 2), "dtk", round(float(rms), 1), "dB", flush=True)
