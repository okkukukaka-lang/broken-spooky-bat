package com.shazammod;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/**
 * 0.55 PRALAYA bukan lagi tubuh yang berubah, tapi ARMOR AI yang dipanggil dari jauh (G / ucapkan PRALAYA), dengan fase:
 *
 *   Fase 1  Mk-I       armor biasa (rakit Inti Armor, klik kanan untuk memasangkan): belum bisa terbang
 *   Fase 2  Enhanced   Modul Tempa Nether dipasang DI NETHER + Modul Kalibrasi End dipasang DI END + Inti Pikiran dari
 *                      benteng reruntuhan bermeteor = pendorong (terbang), armor lebih kuat
 *   Fase 3  Fase Dewa  (opsional) lima inti lainnya, masing-masing di benteng meteornya sendiri = drone, Protokol
 *                      Singularitas & Jentik Pemusnahan, kekuatan penuh
 *
 * Inti yang pernah dipegang tercatat di armor selamanya (skill-nya terbuka di armor). Tanpa armor, inti tetap bisa
 * dipakai kalau DIBAWA di inventori (lihat AksaraSkills: lebih lemah). Benteng meteor nggak ikut worldgen: lokasinya
 * dipilih per pemain, lalu dibangun begitu pemiliknya mendekat (chunk-nya pasti sudah termuat), lengkap dengan kawah,
 * meteor berisi peti inti, reruntuhan, asap sinyal, dan penjaga. Data di attachment "pralaya" (ikut tersimpan).
 */
public final class PralayaProgress {
    private PralayaProgress() {}

    public static final int POWER = 0, SPACE = 1, MIND = 2, REALITY = 3, TIME = 4, SOUL = 5;
    public static final int ALL = 0b111111;
    private static final int MIND_MIN = 350, MIND_MAX = 650;   // jarak benteng Inti Pikiran dari titik awal (blok)
    private static final int REST_MIN = 600, REST_MAX = 1300;  // lima benteng lainnya
    private static final double BUILD_RANGE = 96.0;           // dibangun begitu pemiliknya sedekat ini
    private static final int RADIUS = 13;                     // jari-jari reruntuhan
    private static final String[] DIRS = {"n", "ne", "e", "se", "s", "sw", "w", "nw"};
    private static final String[] ARROWS = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};
    private static final Block[] GLASS = {Blocks.RED_STAINED_GLASS, Blocks.PURPLE_STAINED_GLASS, Blocks.CYAN_STAINED_GLASS,
            Blocks.MAGENTA_STAINED_GLASS, Blocks.ORANGE_STAINED_GLASS, Blocks.LIME_STAINED_GLASS};
    private static final ChatFormatting[] COLOR = {ChatFormatting.RED, ChatFormatting.DARK_PURPLE, ChatFormatting.AQUA,
            ChatFormatting.LIGHT_PURPLE, ChatFormatting.GOLD, ChatFormatting.GREEN};

    // ---------------------------------------------------------------- data

    private static CompoundTag tag(ServerPlayer p) {
        return p.getData(ShazamMod.PRALAYA);
    }

    private static void save(ServerPlayer p, CompoundTag t) {
        p.setData(ShazamMod.PRALAYA, t);
    }

    /** Inti yang sudah ditemukan (bit 0-5: kekuatan, ruang, pikiran, realitas, waktu, jiwa). */
    public static int cores(ServerPlayer p) {
        return tag(p).getInt("cores") & ALL;
    }

    public static boolean hasCore(ServerPlayer p, int core) {
        return core >= 0 && core < 6 && (cores(p) & (1 << core)) != 0;
    }

    public static boolean upgraded(ServerPlayer p, boolean nether) {
        return tag(p).getBoolean(nether ? "nether" : "end");
    }

    /** 0 = belum punya armor, 1 = Mk-I, 2 = Enhanced, 3 = Fase Dewa. */
    public static int phase(ServerPlayer p) {
        if (!ShazamPowers.data(p).aksaraUnlocked()) {
            return 0;
        }
        CompoundTag t = tag(p);
        int cores = t.getInt("cores") & ALL;
        if (!t.getBoolean("nether") || !t.getBoolean("end") || (cores & (1 << MIND)) == 0) {
            return 1;
        }
        return cores == ALL ? 3 : 2;
    }

    /** Buat semua yang melihat (tampilan armor): fase | inti << 2. */
    public static int packed(ServerPlayer p) {
        return phase(p) | (cores(p) << 2);
    }

    public static Component coreName(int core) {
        return Component.translatable("sabda.shazammod." + AksaraSkills.SABDA_IDS[Mth.clamp(core, 0, 5)]);
    }

    /** Inti ini sedang dibawa (inventori, termasuk tangan kedua): bisa dipakai tanpa armor. */
    public static boolean carries(ServerPlayer p, int core) {
        return core >= 0 && core < 6 && (carriedMask(p) & (1 << core)) != 0;
    }

    public static int carriedMask(ServerPlayer p) {
        Inventory inv = p.getInventory();
        int mask = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).getItem() instanceof AksaraItems.CoreItem core) {
                mask |= 1 << core.core;
            }
        }
        return mask;
    }

    // ---------------------------------------------------------------- tiap detik

    public static void tick(ServerPlayer p) {
        if (p.tickCount % 20 != 7) {
            return;
        }
        int fresh = carriedMask(p) & ~cores(p);
        for (int core = 0; core < 6; core++) {
            if ((fresh & (1 << core)) != 0) {
                found(p, core);
            }
        }
        if (ShazamPowers.data(p).aksaraUnlocked()) {
            ensureSites(p);
            tickSites(p);
        } else if (!ShazamPowers.data(p).anyUnlocked() && carriedMask(p) != 0) {
            ShazamNetwork.sync(p);   // pemain tanpa juara yang membawa inti: HUD-nya tetap dapat data (ShazamPowers.tick nggak)
        }
    }

    /** Inti pertama kali dipegang: tercatat di armor; bisa membuka fase baru. */
    private static void found(ServerPlayer p, int core) {
        int before = phase(p);
        CompoundTag t = tag(p);
        int cores = (t.getInt("cores") | (1 << core)) & ALL;
        t.putInt("cores", cores);
        save(p, t);
        int after = phase(p);
        ShazamNetwork.playAnim(p, ShazamAnim.SABDA_CORE_FOUND, new Vec3(core, after, after > before ? 1 : 0));
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.AKSARA_CORE.get(), SoundSource.PLAYERS, 1.8f, 1f);
        boolean paired = ShazamPowers.data(p).aksaraUnlocked();
        p.displayClientMessage(Component.translatable(paired ? "message.shazammod.pralaya.core_found"
                : "message.shazammod.pralaya.core_found_free", coreName(core), Integer.bitCount(cores))
                .withStyle(COLOR[core], ChatFormatting.BOLD), false);
        if (after > before) {
            announce(p, after);
        }
        ShazamNetwork.broadcastState(p);
        ShazamNetwork.sync(p);
    }

    /** Sesudah armor terpasang (AksaraRite): penjelasan fase, lalu sinyal Inti Pikiran pertama. */
    public static void afterPairing(ServerPlayer p) {
        p.displayClientMessage(Component.translatable("message.shazammod.pralaya.paired").withStyle(ChatFormatting.AQUA), false);
        ensureSites(p);
    }

    private static void announce(ServerPlayer p, int phase) {
        if (phase == 2) {
            p.displayClientMessage(Component.translatable("message.shazammod.pralaya.phase2")
                    .withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), false);
            ensureSites(p);
        } else if (phase == 3) {
            p.displayClientMessage(Component.translatable("message.shazammod.pralaya.phase3")
                    .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        }
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.AKSARA_PURNA.get(), SoundSource.PLAYERS,
                phase == 3 ? 2.4f : 1.6f, phase == 3 ? 1f : 1.2f);
    }

    /** Modul upgrade dipakai (klik kanan): harus di dimensinya. */
    public static boolean useModule(ServerPlayer p, boolean nether) {
        if (!ShazamPowers.data(p).aksaraUnlocked()) {
            msg(p, "message.shazammod.pralaya.module_need_armor", ChatFormatting.GRAY);
            return false;
        }
        if (upgraded(p, nether)) {
            msg(p, "message.shazammod.pralaya.module_already", ChatFormatting.GRAY);
            return false;
        }
        if (p.level().dimension() != (nether ? Level.NETHER : Level.END)) {
            p.displayClientMessage(Component.translatable("message.shazammod.pralaya.module_wrong_dim",
                    Component.translatable(nether ? "message.shazammod.pralaya.dim_nether" : "message.shazammod.pralaya.dim_end"))
                    .withStyle(ChatFormatting.RED), true);
            return false;
        }
        int before = phase(p);
        CompoundTag t = tag(p);
        t.putBoolean(nether ? "nether" : "end", true);
        save(p, t);
        int done = (upgraded(p, true) ? 1 : 0) + (upgraded(p, false) ? 1 : 0);
        ShazamNetwork.playAnim(p, ShazamAnim.SABDA_UPGRADE, new Vec3(nether ? 0 : 1, done, 0));
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.AKSARA_TRANSFORM.get(), SoundSource.PLAYERS,
                1.4f, 1.3f);
        p.displayClientMessage(Component.translatable(nether ? "message.shazammod.pralaya.module_nether_done"
                : "message.shazammod.pralaya.module_end_done", done, hasCore(p, MIND)
                ? Component.translatable("message.shazammod.pralaya.mind_ready")
                : Component.translatable("message.shazammod.pralaya.mind_missing")).withStyle(ChatFormatting.GOLD), false);
        int after = phase(p);
        if (after > before) {
            announce(p, after);
        }
        ShazamNetwork.broadcastState(p);
        ShazamNetwork.sync(p);
        return true;
    }

    /** /shazam pralaya <fase>: buat uji coba (operator). Armornya ikut dipasangkan kalau belum. */
    public static void debugPhase(ServerPlayer p, int phase) {
        if (!ShazamPowers.data(p).aksaraUnlocked()) {
            ShazamPowers.unlockAksara(p);
        }
        CompoundTag t = tag(p);
        t.putBoolean("nether", phase >= 2);
        t.putBoolean("end", phase >= 2);
        t.putInt("cores", phase >= 3 ? ALL : phase >= 2 ? 1 << MIND : 0);
        save(p, t);
        ShazamNetwork.broadcastState(p);
        ShazamNetwork.sync(p);
    }

    // ---------------------------------------------------------------- benteng meteor

    private static boolean siteSet(CompoundTag t, int core) {
        return t.contains("s" + core + "x");
    }

    private static BlockPos origin(ServerPlayer p) {
        return p.level().dimension() == Level.OVERWORLD ? p.blockPosition() : p.server.overworld().getSharedSpawnPos();
    }

    private static void assign(ServerPlayer p, int core, BlockPos origin, double angle, int min, int max) {
        double d = min + p.getRandom().nextDouble() * (max - min);
        CompoundTag t = tag(p);
        t.putInt("s" + core + "x", origin.getX() + (int) Math.round(Math.cos(angle) * d));
        t.putInt("s" + core + "z", origin.getZ() + (int) Math.round(Math.sin(angle) * d));
        t.putBoolean("s" + core + "b", false);
        save(p, t);
    }

    /** Sinyal Inti Pikiran sejak armor terpasang; lima sinyal lainnya sejak Fase 2. */
    private static void ensureSites(ServerPlayer p) {
        int ph = phase(p);
        if (ph < 1) {
            return;
        }
        if (!siteSet(tag(p), MIND) && !hasCore(p, MIND)) {
            assign(p, MIND, origin(p), p.getRandom().nextDouble() * Math.PI * 2.0, MIND_MIN, MIND_MAX);
            p.displayClientMessage(Component.translatable("message.shazammod.pralaya.first_signal")
                    .withStyle(ChatFormatting.AQUA), false);
        }
        if (ph < 2) {
            return;
        }
        boolean any = false;
        double base = p.getRandom().nextDouble() * Math.PI * 2.0;
        int k = 0;
        for (int core : new int[] {POWER, SPACE, REALITY, TIME, SOUL}) {
            if (!siteSet(tag(p), core) && !hasCore(p, core)) {
                assign(p, core, origin(p), base + k * Math.PI * 2.0 / 5.0 + (p.getRandom().nextDouble() - 0.5) * 0.6,
                        REST_MIN, REST_MAX);
                any = true;
            }
            k++;
        }
        if (any) {
            p.displayClientMessage(Component.translatable("message.shazammod.pralaya.rest_signals")
                    .withStyle(ChatFormatting.AQUA), false);
        }
    }

    private static void tickSites(ServerPlayer p) {
        if (p.level().dimension() != Level.OVERWORLD) {
            return;
        }
        ServerLevel level = p.serverLevel();
        for (int core = 0; core < 6; core++) {
            CompoundTag t = tag(p);
            if (!siteSet(t, core) || t.getBoolean("s" + core + "b")) {
                continue;
            }
            int x = t.getInt("s" + core + "x"), z = t.getInt("s" + core + "z");
            double dx = x + 0.5 - p.getX(), dz = z + 0.5 - p.getZ();
            if (dx * dx + dz * dz > BUILD_RANGE * BUILD_RANGE || !areaLoaded(level, x, z)) {
                continue;
            }
            build(level, core, x, z);
            t.putBoolean("s" + core + "b", true);
            save(p, t);
            p.displayClientMessage(Component.translatable("message.shazammod.pralaya.site_near", coreName(core))
                    .withStyle(COLOR[core], ChatFormatting.BOLD), true);
            level.playSound(null, x + 0.5, p.getY(), z + 0.5, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 1.2f, 1.4f);
        }
    }

    private static boolean areaLoaded(ServerLevel level, int x, int z) {
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                if (!level.isLoaded(new BlockPos(x + sx * (RADIUS + 3), 64, z + sz * (RADIUS + 3)))) {
                    return false;
                }
            }
        }
        return true;
    }

    /** {inti, x, z} sinyal terdekat yang intinya belum ditemukan, atau null. */
    public static int[] tracked(ServerPlayer p) {
        CompoundTag t = tag(p);
        int cores = t.getInt("cores");
        int[] best = null;
        double bd = Double.MAX_VALUE;
        for (int core = 0; core < 6; core++) {
            if ((cores & (1 << core)) != 0 || !siteSet(t, core)) {
                continue;
            }
            int x = t.getInt("s" + core + "x"), z = t.getInt("s" + core + "z");
            double d = (x - p.getX()) * (x - p.getX()) + (z - p.getZ()) * (z - p.getZ());
            if (d < bd) {
                bd = d;
                best = new int[] {core, x, z};
            }
        }
        return best;
    }

    /** Klik kanan Inti Armor sesudah terpasang: arah & jarak sinyal inti terdekat. */
    public static void showSignal(ServerPlayer p) {
        int[] s = tracked(p);
        if (s == null) {
            msg(p, cores(p) == ALL ? "message.shazammod.pralaya.all_found" : phase(p) == 1 && hasCore(p, MIND)
                    ? "message.shazammod.pralaya.need_modules" : "message.shazammod.pralaya.no_signal", ChatFormatting.GRAY);
            return;
        }
        if (p.level().dimension() != Level.OVERWORLD) {
            msg(p, "message.shazammod.pralaya.signal_dim", ChatFormatting.GRAY);
            return;
        }
        double dx = s[1] + 0.5 - p.getX(), dz = s[2] + 0.5 - p.getZ();
        int dist = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
        double bearing = Math.toDegrees(Math.atan2(dx, -dz));   // 0 = utara, 90 = timur
        int compass = Math.floorMod((int) Math.round(bearing / 45.0), 8);
        float rel = Mth.wrapDegrees((float) Math.toDegrees(Math.atan2(-dx, dz)) - p.getYRot());   // > 0 = ke kanan
        int arrow = Math.floorMod(Math.round(rel / 45f), 8);
        p.displayClientMessage(Component.translatable("message.shazammod.pralaya.signal", coreName(s[0]), dist,
                Component.translatable("message.shazammod.pralaya.dir." + DIRS[compass]), ARROWS[arrow])
                .withStyle(COLOR[s[0]]), true);
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.AKSARA_PULSE.get(), SoundSource.PLAYERS, 0.8f,
                1.6f);
    }

    /** Angka buat HUD pemain sendiri (ditambahkan di akhir ShazamSyncPayload.cooldowns, lihat ShazamClientState). */
    public static void appendSync(ServerPlayer p, List<Integer> out) {
        int[] s = tracked(p);
        out.add(s == null ? -1 : s[0]);
        out.add(s == null ? 0 : s[1]);
        out.add(s == null ? 0 : s[2]);
        for (int slot = 0; slot < 6; slot++) {
            out.add(AksaraSkills.slotCooldown(p, slot));
        }
        out.add(carriedMask(p));
        out.add(phase(p));
        out.add(cores(p));
        out.add((upgraded(p, true) ? 1 : 0) | (upgraded(p, false) ? 2 : 0));
    }

    // ---------------------------------------------------------------- membangun benteng

    private static void set(ServerLevel level, int x, int y, int z, BlockState state) {
        level.setBlock(new BlockPos(x, y, z), state, Block.UPDATE_CLIENTS);
    }

    /** y udara pertama di atas tanah (daun & tanaman diabaikan). */
    private static int surface(ServerLevel level, int x, int z) {
        return level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
    }

    private static BlockState wall(RandomSource r) {
        float f = r.nextFloat();
        return (f < 0.38f ? Blocks.STONE_BRICKS : f < 0.62f ? Blocks.CRACKED_STONE_BRICKS : f < 0.82f ? Blocks.MOSSY_STONE_BRICKS
                : f < 0.94f ? Blocks.POLISHED_BLACKSTONE_BRICKS : Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS).defaultBlockState();
    }

    private static BlockState lining(RandomSource r) {
        float f = r.nextFloat();
        return (f < 0.4f ? Blocks.BLACKSTONE : f < 0.62f ? Blocks.BASALT : f < 0.78f ? Blocks.MAGMA_BLOCK
                : f < 0.94f ? Blocks.COARSE_DIRT : Blocks.CRYING_OBSIDIAN).defaultBlockState();
    }

    private static BlockState meteor(RandomSource r) {
        float f = r.nextFloat();
        return (f < 0.42f ? Blocks.BLACKSTONE : f < 0.6f ? Blocks.MAGMA_BLOCK : f < 0.72f ? Blocks.GILDED_BLACKSTONE
                : f < 0.86f ? Blocks.OBSIDIAN : Blocks.CRYING_OBSIDIAN).defaultBlockState();
    }

    private static boolean clearable(BlockState s) {
        return !s.isAir() && (s.is(BlockTags.LEAVES) || s.is(BlockTags.LOGS)
                || (s.canBeReplaced() && s.getFluidState().isEmpty()));
    }

    /**
     * Benteng reruntuhan bermeteor: kawah bergaris basal & magma, meteor batu hitam berlubang dengan peti inti di
     * tengahnya (vena kaca warna intinya, menyala dari dalam), cincin dinding batu bata yang runtuh di sana-sini, empat
     * menara patah, puing berserakan, dua api unggun sinyal (asapnya terlihat dari jauh), dan penjaga.
     */
    private static void build(ServerLevel level, int core, int cx, int cz) {
        RandomSource r = level.random;
        int ground = surface(level, cx, cz);
        int y0 = ground - 1;   // blok teratas permukaan
        boolean wet = !level.getFluidState(new BlockPos(cx, y0, cz)).isEmpty();
        // bersihkan pohon & tanaman di atas area
        for (int dx = -RADIUS - 2; dx <= RADIUS + 2; dx++) {
            for (int dz = -RADIUS - 2; dz <= RADIUS + 2; dz++) {
                if (dx * dx + dz * dz > (RADIUS + 2) * (RADIUS + 2)) {
                    continue;
                }
                for (int y = y0 + 1; y <= y0 + 14; y++) {
                    BlockPos pos = new BlockPos(cx + dx, y, cz + dz);
                    if (clearable(level.getBlockState(pos))) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                    }
                }
            }
        }
        if (wet) {   // jatuh ke air: pulau puing di permukaan
            for (int dx = -RADIUS - 1; dx <= RADIUS + 1; dx++) {
                for (int dz = -RADIUS - 1; dz <= RADIUS + 1; dz++) {
                    if (dx * dx + dz * dz <= (RADIUS + 1) * (RADIUS + 1)) {
                        set(level, cx + dx, y0, cz + dz, r.nextFloat() < 0.7f ? Blocks.BLACKSTONE.defaultBlockState()
                                : Blocks.COBBLESTONE.defaultBlockState());
                        set(level, cx + dx, y0 - 1, cz + dz, Blocks.COBBLESTONE.defaultBlockState());
                    }
                }
            }
        }
        // kawah
        for (int dx = -9; dx <= 9; dx++) {
            for (int dz = -9; dz <= 9; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > 8.5) {
                    continue;
                }
                int depth = wet ? 0 : (int) Math.round(3.5 * (1.0 - (d / 8.5) * (d / 8.5)));
                for (int y = y0 - depth + 1; y <= y0 + 8; y++) {
                    set(level, cx + dx, y, cz + dz, Blocks.AIR.defaultBlockState());
                }
                set(level, cx + dx, y0 - depth, cz + dz, lining(r));
                set(level, cx + dx, y0 - depth - 1, cz + dz, Blocks.BLACKSTONE.defaultBlockState());
            }
        }
        // meteor berlubang, peti inti di tengah
        int my = wet ? y0 + 3 : y0 - 2;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dy = -3; dy <= 3; dy++) {
                for (int dz = -3; dz <= 3; dz++) {
                    double d = Math.sqrt(dx * dx + dy * dy * 1.2 + dz * dz);
                    if (d <= 1.25) {
                        set(level, cx + dx, my + dy, cz + dz, Blocks.AIR.defaultBlockState());
                    } else if (d <= 2.7) {
                        set(level, cx + dx, my + dy, cz + dz, meteor(r));
                    }
                }
            }
        }
        for (int i = 0; i < 7; i++) {   // vena kaca warna intinya
            double a = r.nextDouble() * Math.PI * 2.0, b = (r.nextDouble() - 0.5) * 1.6;
            set(level, cx + (int) Math.round(Math.cos(a) * 2.0), my + (int) Math.round(b), cz + (int) Math.round(Math.sin(a) * 2.0),
                    GLASS[core].defaultBlockState());
        }
        double open = r.nextDouble() * Math.PI * 2.0;
        double ex = Math.cos(open), ez = Math.sin(open);
        for (int s = 1; s <= 4; s++) {   // lubang masuk ke dalam meteor
            int px = cx + (int) Math.round(ex * s), pz = cz + (int) Math.round(ez * s);
            set(level, px, my, pz, Blocks.AIR.defaultBlockState());
            set(level, px, my + 1, pz, Blocks.AIR.defaultBlockState());
        }
        set(level, cx, my - 1, cz, Blocks.GLOWSTONE.defaultBlockState());
        BlockPos chestPos = new BlockPos(cx, my, cz);
        Direction face = Math.abs(ex) > Math.abs(ez) ? (ex > 0 ? Direction.EAST : Direction.WEST)
                : (ez > 0 ? Direction.SOUTH : Direction.NORTH);   // menghadap lubang masuk
        level.setBlock(chestPos, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, face), Block.UPDATE_ALL);
        if (level.getBlockEntity(chestPos) instanceof ChestBlockEntity chest) {
            chest.setItem(13, new ItemStack(AksaraItems.core(core)));
            chest.setItem(r.nextInt(9), new ItemStack(Items.IRON_INGOT, 3 + r.nextInt(6)));
            chest.setItem(18 + r.nextInt(9), new ItemStack(Items.GOLD_INGOT, 1 + r.nextInt(3)));
            chest.setItem(9 + r.nextInt(4), new ItemStack(Items.ENDER_PEARL, 1 + r.nextInt(2)));
            if (r.nextFloat() < 0.6f) {
                chest.setItem(14 + r.nextInt(4), new ItemStack(Items.DIAMOND, 1 + r.nextInt(2)));
            }
        }
        // cincin dinding yang runtuh di sana-sini
        boolean[] gap = new boolean[96];
        for (int g = 0; g < 5; g++) {
            int c = r.nextInt(96), w = 2 + r.nextInt(4);
            for (int i = -w; i <= w; i++) {
                gap[Math.floorMod(c + i, 96)] = true;
            }
        }
        for (int i = 0; i < 96; i++) {
            if (gap[i]) {
                continue;
            }
            double a = i * Math.PI * 2.0 / 96.0;
            int wx = cx + (int) Math.round(Math.cos(a) * 12.0), wz = cz + (int) Math.round(Math.sin(a) * 12.0);
            int h = surface(level, wx, wz);
            int height = 1 + r.nextInt(4);
            for (int y = h - 1; y < h + height; y++) {
                set(level, wx, y, wz, wall(r));
            }
        }
        // empat menara patah
        for (int k = 0; k < 4; k++) {
            double a = Math.PI / 4.0 + k * Math.PI / 2.0;
            int tx = cx + (int) Math.round(Math.cos(a) * 12.5), tz = cz + (int) Math.round(Math.sin(a) * 12.5);
            int h = surface(level, tx, tz);
            int height = 6 + r.nextInt(4);
            for (int ox = -1; ox <= 1; ox++) {
                for (int oz = -1; oz <= 1; oz++) {
                    int top = h + height - r.nextInt(3);
                    for (int y = h - 2; y < top; y++) {
                        set(level, tx + ox, y, tz + oz, wall(r));
                    }
                }
            }
            int wx = tx + (int) Math.round(Math.cos(a)), wz = tz + (int) Math.round(Math.sin(a));
            set(level, wx, h + 3, wz, Blocks.IRON_BARS.defaultBlockState());
            if (k % 2 == 0) {
                set(level, tx, h + height - 2, tz, Blocks.SOUL_LANTERN.defaultBlockState());
            }
        }
        // puing berserakan
        for (int i = 0; i < 34; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, d = 9.0 + r.nextDouble() * (wet ? 4.0 : 7.0);
            int px = cx + (int) Math.round(Math.cos(a) * d), pz = cz + (int) Math.round(Math.sin(a) * d);
            float f = r.nextFloat();
            set(level, px, surface(level, px, pz), pz, (f < 0.4f ? Blocks.COBBLESTONE : f < 0.7f ? Blocks.MOSSY_COBBLESTONE
                    : f < 0.85f ? Blocks.CRACKED_STONE_BRICKS : Blocks.STONE_BRICK_SLAB).defaultBlockState());
        }
        // dua api unggun sinyal: asapnya tinggi, kelihatan dari jauh
        for (int k = 0; k < 2; k++) {
            double a = open + Math.PI / 2.0 + k * Math.PI;
            int fx = cx + (int) Math.round(Math.cos(a) * 9.5), fz = cz + (int) Math.round(Math.sin(a) * 9.5);
            int h = surface(level, fx, fz);
            set(level, fx, h, fz, Blocks.HAY_BLOCK.defaultBlockState());
            set(level, fx, h + 1, fz, Blocks.CAMPFIRE.defaultBlockState().setValue(CampfireBlock.SIGNAL_FIRE, true));
        }
        // penjaga
        int skeletons = core == MIND ? 2 : 3, blazes = core == MIND ? 1 : 2;
        for (int i = 0; i < skeletons + blazes; i++) {
            Mob mob = (i < skeletons ? EntityType.WITHER_SKELETON : EntityType.BLAZE).create(level);
            if (mob == null) {
                continue;
            }
            double a = r.nextDouble() * Math.PI * 2.0, d = 5.0 + r.nextDouble() * 5.0;
            int mx = cx + (int) Math.round(Math.cos(a) * d), mz = cz + (int) Math.round(Math.sin(a) * d);
            mob.moveTo(mx + 0.5, surface(level, mx, mz), mz + 0.5, r.nextFloat() * 360f, 0f);
            if (i < skeletons) {
                mob.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.STONE_SWORD));
                mob.setDropChance(EquipmentSlot.MAINHAND, 0f);
            }
            mob.setPersistenceRequired();
            level.addFreshEntity(mob);
        }
    }

    private static void msg(ServerPlayer p, String key, ChatFormatting... style) {
        p.displayClientMessage(Component.translatable(key).withStyle(style), true);
    }
}
