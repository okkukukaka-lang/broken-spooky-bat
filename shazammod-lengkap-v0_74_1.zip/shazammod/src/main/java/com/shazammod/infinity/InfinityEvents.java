package com.shazammod.infinity;

import com.shazammod.ShazamMod;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.living.LivingExperienceDropEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** 0.64 Event Kuasa Infinity di server. */
@EventBusSubscriber(modid = ShazamMod.MODID)
public final class InfinityEvents {
    private InfinityEvents() {}

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        InfinityWorld.tick(event.getServer());
        InfinityMinions.tick(event.getServer());
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            InfinitySkills.tick(player);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            InfinitySkills.clear(player);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            InfinitySkills.clear(player);
        }
    }

    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        InfinityMinions.onJoin(event);
    }

    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        InfinityMinions.onIncomingDamage(event);
    }

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        if (InfinityMinions.isMinion(event.getEntity())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onExperience(LivingExperienceDropEvent event) {
        if (InfinityMinions.isMinion(event.getEntity())) {
            event.setDroppedExperience(0);
        }
    }

    /** Server dimatikan: dunia yang sedang berubah dikembalikan, undead dibuang. */
    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent event) {
        InfinityWorld.revertAll(event.getServer());
        InfinityMinions.discardAll();
    }
}
