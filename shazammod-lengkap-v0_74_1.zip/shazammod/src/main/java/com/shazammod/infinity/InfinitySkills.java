package com.shazammod.infinity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.shazammod.PralayaGod;
import com.shazammod.PralayaProgress;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamMod;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamPowers;
import com.shazammod.ShazamSounds;
import com.shazammod.thanos.StoneType;
import com.shazammod.thanos.ThanosAbilities;
import com.shazammod.thanos.ThanosConfig;
import com.shazammod.thanos.ThanosData;
import com.shazammod.thanos.ThanosSkills;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.common.Tags;

/**
 * 0.64 KUASA INFINITY: empat kuasa batu yang mengubah dunia, untuk Thanos (Alt + tombol batu, dalam wujud Thanos) dan
 * PRALAYA (Alt + Shift + tombol inti, berarmor; versi lebih OP, Fase Dewa paling OP). Batunya/intinya harus sudah
 * ditemukan.
 *
 *   Z  Power    Daya Tak Terbatas: buff gila-gilaan (damage, kecepatan, armor, kebal, regenerasi, badan membesar);
 *               tekan LAGI selama buff = Ledakan Kawah: bola daya ke titik bidik, kawah raksasa yang benar-benar
 *               mencungkil tanah (Thanos radius 14, PRALAYA 24, Fase Dewa 30)
 *   X  Space    Gerbang Kosmik: gerbang dibuka, melangkah masuk, keluar dari gerbang di titik bidik sejauh 256 / 512 blok
 *               (PRALAYA ikut membawa peliharaannya)
 *   V  Reality  Tulis Ulang Dunia: permukaan dunia sekitar berubah tema (Kristal / Neraka / End / Beku / Emas palsu)
 *               mengikuti gelombang, monster berubah jadi hewan, lalu dunia kembali (60 / 120 detik)
 *   N  Soul     Bangkitkan Undead: 6 / 12 (Fase Dewa 16) undead bangkit dari tanah dan bertarung untukmu
 */
public final class InfinitySkills {
    private InfinitySkills() {}

    private static final int K_SURGE = 0, K_CRATER = 1, K_PORTAL = 2, K_REWRITE = 3, K_RAISE = 4;
    /** detik cooldown {Thanos, PRALAYA} & energi Thanos, urut K_*. */
    private static final int[][] CD = {{90, 60}, {30, 15}, {20, 8}, {120, 75}, {90, 50}};
    private static final float[] COST = {50f, 40f, 30f, 60f, 50f};
    private static final String[] THEMES = {"crystal", "nether", "end", "frost", "gold"};

    private static final Map<UUID, int[]> PRALAYA_CD = new HashMap<>();
    private static final Map<UUID, Integer> SURGE = new HashMap<>();

    // ---------------------------------------------------------------- pintu masuk

    /** Tombol inti yang punya Kuasa Infinity: Z (Power), X (Space), V (Reality), N (Soul). */
    public static boolean hasPower(int key) {
        return key == 0 || key == 1 || key == 3 || key == 5;
    }

    /** Thanos: Alt + Z..N dalam wujud Thanos. */
    public static void thanos(ServerPlayer p, ThanosData d, int key) {
        StoneType stone = StoneType.byIndex(key);
        if (!d.has(stone)) {
            ThanosAbilities.msg(p, "stone_missing", ChatFormatting.GRAY, ThanosAbilities.stoneName(stone));
            return;
        }
        if (!ThanosAbilities.hasGauntlet(p)) {
            ThanosAbilities.msg(p, "no_gauntlet", ChatFormatting.GRAY);
            return;
        }
        use(p, InfinityTier.THANOS, key, d);
    }

    /** PRALAYA: Alt + Shift + Z..N, berarmor. */
    public static void pralaya(ServerPlayer p, int key) {
        if (!ShazamPowers.isAksara(p)) {
            return;
        }
        if (!PralayaProgress.hasCore(p, key)) {
            msg(p, "core_missing", ChatFormatting.GRAY, PralayaProgress.coreName(key));
            return;
        }
        use(p, PralayaGod.god(p) ? InfinityTier.PRALAYA_GOD : InfinityTier.PRALAYA, key, null);
    }

    private static void use(ServerPlayer p, InfinityTier tier, int key, ThanosData d) {
        if (!ThanosSkills.free(p) || (d != null && d.snapCharge > 0)) {
            return;
        }
        int k = switch (key) {
            case 0 -> SURGE.containsKey(p.getUUID()) ? K_CRATER : K_SURGE;
            case 1 -> K_PORTAL;
            case 3 -> K_REWRITE;
            case 5 -> K_RAISE;
            default -> -1;
        };
        if (k < 0) {
            msg(p, "none", ChatFormatting.GRAY);
            return;
        }
        if (!ready(p, tier, k, d)) {
            return;
        }
        boolean ok = switch (k) {
            case K_SURGE -> surge(p, tier);
            case K_CRATER -> crater(p, tier);
            case K_PORTAL -> portal(p, tier);
            case K_REWRITE -> rewrite(p, tier);
            default -> raise(p, tier);
        };
        if (ok) {
            spend(p, tier, k, d);
        } else {
            msg(p, "no_target", ChatFormatting.GRAY);
        }
        if (d != null) {
            com.shazammod.thanos.ThanosNetwork.sync(p);
        }
    }

    private static int slot(int k) {
        return k == K_CRATER ? ThanosData.SLOT_CRATER : ThanosData.SLOT_ALT + new int[] {0, 0, 1, 3, 5}[k];
    }

    private static boolean ready(ServerPlayer p, InfinityTier tier, int k, ThanosData d) {
        if (d == null) {
            int left = PRALAYA_CD.computeIfAbsent(p.getUUID(), id -> new int[5])[k];
            if (left > 0) {
                msg(p, "cooldown", ChatFormatting.RED, (left + 19) / 20);
                return false;
            }
            return true;
        }
        int left = d.cooldowns[slot(k)];
        if (left > 0) {
            ThanosAbilities.msg(p, "cooldown", ChatFormatting.RED, (left + 19) / 20);
            return false;
        }
        float need = (float) (COST[k] * ThanosConfig.COST_MULT.get());
        if (!p.getAbilities().instabuild && d.energy < need) {
            ThanosAbilities.msg(p, "no_energy", ChatFormatting.RED, Math.round(d.energy), Math.round(need));
            return false;
        }
        return true;
    }

    private static void spend(ServerPlayer p, InfinityTier tier, int k, ThanosData d) {
        if (d == null) {
            PRALAYA_CD.computeIfAbsent(p.getUUID(), id -> new int[5])[k] = CD[k][1] * 20;
            return;
        }
        if (!p.getAbilities().instabuild) {
            d.energy = Math.max(0f, d.energy - (float) (COST[k] * ThanosConfig.COST_MULT.get()));
        }
        d.cooldowns[slot(k)] = (int) Math.round(CD[k][0] * 20.0 * ThanosConfig.COOLDOWN_MULT.get());
    }

    // ---------------------------------------------------------------- Power: Daya Tak Terbatas

    private static boolean surge(ServerPlayer p, InfinityTier tier) {
        ShazamNetwork.playAnim(p, ShazamAnim.INFINITY_SURGE);
        sound(p, p.position(), ShazamSounds.INFINITY_SURGE.get(), 2.8f);
        ThanosSkills.busy(p, ShazamAnim.INF_SURGE_HIT + 4);
        ThanosSkills.later(p, ShazamAnim.INF_SURGE_HIT, sp -> {
            int t = tier.surgeTicks();
            boolean pr = tier.pralaya;
            setMod(sp, Attributes.ATTACK_DAMAGE, "damage", pr ? (tier.god ? 60 : 40) : 20, AttributeModifier.Operation.ADD_VALUE);
            setMod(sp, Attributes.ATTACK_SPEED, "speed_attack", pr ? 2.5 : 1.5, AttributeModifier.Operation.ADD_VALUE);
            setMod(sp, Attributes.MOVEMENT_SPEED, "speed", pr ? 0.6 : 0.4, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
            setMod(sp, Attributes.ARMOR, "armor", pr ? 20 : 10, AttributeModifier.Operation.ADD_VALUE);
            setMod(sp, Attributes.ARMOR_TOUGHNESS, "toughness", pr ? 12 : 6, AttributeModifier.Operation.ADD_VALUE);
            setMod(sp, Attributes.KNOCKBACK_RESISTANCE, "knockback", 1.0, AttributeModifier.Operation.ADD_VALUE);
            setMod(sp, Attributes.SCALE, "scale", pr ? 0.2 : 0.12, AttributeModifier.Operation.ADD_VALUE);
            setMod(sp, Attributes.JUMP_STRENGTH, "jump", pr ? 0.3 : 0.2, AttributeModifier.Operation.ADD_VALUE);
            sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, t, pr ? 3 : 2));
            sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, t, pr ? 4 : 2));
            sp.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, t, pr ? 9 : 4));
            sp.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, t, pr ? 4 : 2));
            sp.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, t, 0));
            SURGE.put(sp.getUUID(), t);
            for (LivingEntity e : enemies(sp, pr ? 9.0 : 6.0)) {   // ledakan tenaga mendorong yang terlalu dekat
                Vec3 away = flat(e.position().subtract(sp.position()));
                e.push(away.x * 1.6, 0.5, away.z * 1.6);
                e.hurtMarked = true;
            }
            msg(sp, "surge_on", ChatFormatting.DARK_PURPLE);
        });
        return true;
    }

    private static void endSurge(ServerPlayer p) {
        SURGE.remove(p.getUUID());
        for (String name : new String[] {"damage", "speed_attack", "speed", "armor", "toughness", "knockback", "scale", "jump"}) {
            clearMod(p, name);
        }
        ShazamNetwork.playAnim(p, ShazamAnim.INF_SURGE_END);
    }

    public static boolean surging(ServerPlayer p) {
        return SURGE.containsKey(p.getUUID());
    }

    // ---------------------------------------------------------------- Power: Ledakan Kawah

    private static boolean crater(ServerPlayer p, InfinityTier tier) {
        HitResult hit = p.pick(tier.pralaya ? 128.0 : 80.0, 1.0f, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            return false;
        }
        Vec3 at = hit.getLocation();
        int radius = tier.craterRadius();
        ShazamNetwork.playAnim(p, ShazamAnim.INFINITY_CRATER, at);
        sound(p, p.position(), ShazamSounds.INFINITY_CRATER_CHARGE.get(), 2.0f);
        ThanosSkills.busy(p, ShazamAnim.INF_CRATER_THROW + 4);
        ThanosSkills.later(p, ShazamAnim.INF_CRATER_THROW + ShazamAnim.INF_CRATER_TRAVEL, sp -> {
            ServerLevel level = sp.serverLevel();
            ShazamNetwork.playAnim(sp, ShazamAnim.INF_CRATER_HIT, at);
            level.playSound(null, at.x, at.y, at.z, ShazamSounds.INFINITY_CRATER.get(), SoundSource.PLAYERS, 8.0f, 1f);
            double reach = radius * 1.2;
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(reach), e -> valid(sp, e))) {
                double dist = e.position().distanceTo(at);
                if (dist > reach) {
                    continue;
                }
                e.invulnerableTime = 0;
                e.hurt(sp.damageSources().explosion(sp, sp), tier.craterDamage() * (float) (1.0 - dist / (reach * 1.3)));
                Vec3 away = flat(e.position().subtract(at));
                e.push(away.x * 2.0, 1.2, away.z * 2.0);
                e.hurtMarked = true;
            }
            if (ThanosConfig.INF_BREAK_BLOCKS.get()) {
                InfinityWorld.crater(level, at, radius);
            }
        });
        return true;
    }

    // ---------------------------------------------------------------- Space: Gerbang Kosmik

    private static boolean portal(ServerPlayer p, InfinityTier tier) {
        Vec3 dest = farAim(p, tier.portalRange());
        if (dest == null) {
            return false;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.INFINITY_PORTAL, dest);
        sound(p, p.position(), ShazamSounds.INFINITY_PORTAL_OPEN.get(), 2.0f);
        ThanosSkills.busy(p, ShazamAnim.INF_PORTAL_STEP + 2);
        ThanosSkills.later(p, ShazamAnim.INF_PORTAL_STEP, sp -> {
            if (!sp.level().noCollision(sp, sp.getBoundingBox().move(dest.subtract(sp.position())))) {
                return;
            }
            Vec3 from = sp.position();
            if (tier.pralaya) {   // PRALAYA membawa peliharaannya lewat gerbang
                for (TamableAnimal pet : sp.serverLevel().getEntitiesOfClass(TamableAnimal.class, sp.getBoundingBox().inflate(8.0),
                        pet -> pet.isOwnedBy(sp) && !pet.isOrderedToSit())) {
                    pet.teleportTo(dest.x, dest.y, dest.z);
                }
            }
            sp.teleportTo(dest.x, dest.y, dest.z);
            sp.resetFallDistance();
            sp.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 60, 0, false, false));
            sound(sp, from, ShazamSounds.INFINITY_PORTAL_CLOSE.get(), 1.6f);
            sound(sp, dest, ShazamSounds.INFINITY_PORTAL_OPEN.get(), 2.0f);
            ShazamNetwork.playAnim(sp, ShazamAnim.INF_PORTAL_EXIT, dest);
        });
        return true;
    }

    /** Titik jauh di arah bidikan (sampai range blok); nggak kena apa-apa = ujung jangkauan, turun ke tanah kalau termuat. */
    private static Vec3 farAim(ServerPlayer p, double range) {
        HitResult hit = p.pick(range, 1.0f, false);
        Vec3 to;
        if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult block) {
            to = Vec3.atBottomCenterOf(block.getBlockPos().relative(block.getDirection()));
        } else {
            Vec3 end = p.getEyePosition().add(p.getLookAngle().scale(range));
            BlockPos col = BlockPos.containing(end);
            if (p.level().isLoaded(col)) {
                int y = p.level().getHeight(Heightmap.Types.MOTION_BLOCKING, col.getX(), col.getZ());
                to = new Vec3(col.getX() + 0.5, Math.max(y, p.level().getMinBuildHeight() + 1), col.getZ() + 0.5);
            } else {
                to = end;
            }
        }
        for (int up = 0; up <= 4; up++) {
            Vec3 c = to.add(0, up, 0);
            if (p.level().noCollision(p, p.getBoundingBox().move(c.subtract(p.position())))) {
                return c;
            }
        }
        return null;
    }

    // ---------------------------------------------------------------- Reality: Tulis Ulang Dunia

    private static boolean rewrite(ServerPlayer p, InfinityTier tier) {
        ShazamNetwork.playAnim(p, ShazamAnim.INFINITY_REWRITE);
        sound(p, p.position(), ShazamSounds.INFINITY_REWRITE.get(), 3.0f);
        ThanosSkills.busy(p, ShazamAnim.INF_REWRITE_HIT + 4);
        ThanosSkills.later(p, ShazamAnim.INF_REWRITE_HIT, sp -> {
            ServerLevel level = sp.serverLevel();
            int theme = level.random.nextInt(InfinityWorld.THEMES);
            int radius = tier.rewriteRadius();
            Vec3 c = sp.position();
            ShazamNetwork.playAnim(sp, ShazamAnim.INF_REWRITE_WAVE, new Vec3(c.x, c.y + (theme + 1) * 2000.0, c.z));
            sp.displayClientMessage(Component.translatable("message.shazammod.infinity.rewrite",
                    Component.translatable("message.shazammod.infinity.theme." + THEMES[theme])).withStyle(ChatFormatting.LIGHT_PURPLE), true);
            transmute(sp, c, radius, tier.transmuteChance());
            if (ThanosConfig.INF_CHANGE_WORLD.get()) {
                InfinityWorld.rewrite(level, c, radius, theme, tier.rewriteTicks(), sp.getId());
            }
        });
        return true;
    }

    /** Monster di zona berubah jadi hewan jinak (bos, makhluk bernama, & undead milik siapa pun nggak). */
    private static void transmute(ServerPlayer p, Vec3 c, int radius, float chance) {
        ServerLevel level = p.serverLevel();
        EntityType<?>[] into = {EntityType.CHICKEN, EntityType.RABBIT, EntityType.SHEEP, EntityType.PIG, EntityType.COW};
        for (Mob mob : level.getEntitiesOfClass(Mob.class, new AABB(c, c).inflate(radius), m -> m instanceof Enemy && m.isAlive()
                && !m.getType().is(Tags.EntityTypes.BOSSES) && !m.hasCustomName() && !InfinityMinions.isMinion(m)
                && m.position().distanceTo(c) <= radius)) {
            if (level.random.nextFloat() > chance) {
                continue;
            }
            if (into[level.random.nextInt(into.length)].create(level) instanceof Mob animal) {
                animal.moveTo(mob.getX(), mob.getY(), mob.getZ(), mob.getYRot(), 0f);
                level.addFreshEntity(animal);
                ShazamNetwork.playAnim(p, ShazamAnim.INF_TRANSMUTE, mob.position().add(0, mob.getBbHeight() * 0.5, 0));
                mob.discard();
            }
        }
    }

    // ---------------------------------------------------------------- Soul: Bangkitkan Undead

    private static boolean raise(ServerPlayer p, InfinityTier tier) {
        InfinityMinions.dismiss(p);
        ShazamNetwork.playAnim(p, ShazamAnim.INFINITY_RAISE);
        sound(p, p.position(), ShazamSounds.INFINITY_RAISE.get(), 2.6f);
        int n = tier.undeadCount();
        ThanosSkills.busy(p, ShazamAnim.INF_RAISE_HIT + 4);
        for (int i = 0; i < n; i++) {
            final int index = i;
            ThanosSkills.later(p, ShazamAnim.INF_RAISE_HIT + i * ShazamAnim.INF_RAISE_GAP, sp -> {
                ServerLevel level = sp.serverLevel();
                double a = index * 2.399 + level.random.nextDouble() * 0.5, r = 2.5 + level.random.nextDouble() * (tier.pralaya ? 6.0 : 4.0);
                int x = (int) Math.floor(sp.getX() + Math.cos(a) * r), z = (int) Math.floor(sp.getZ() + Math.sin(a) * r);
                Vec3 at = new Vec3(x + 0.5, level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), z + 0.5);
                if (Math.abs(at.y - sp.getY()) > 6) {
                    at = sp.position();
                }
                ShazamNetwork.playAnim(sp, ShazamAnim.INF_RISE, at);
                InfinityMinions.spawn(sp, tier, at, index, tier.undeadTicks());
            });
        }
        return true;
    }

    // ---------------------------------------------------------------- tiap tick pemain

    public static void tick(ServerPlayer p) {
        int[] cd = PRALAYA_CD.get(p.getUUID());
        if (cd != null) {
            for (int i = 0; i < cd.length; i++) {
                if (cd[i] > 0) {
                    cd[i]--;
                }
            }
        }
        Integer left = SURGE.get(p.getUUID());
        if (left != null) {
            if (left <= 1 || !p.isAlive()) {
                endSurge(p);
            } else {
                SURGE.put(p.getUUID(), left - 1);
            }
        }
    }

    public static void clear(ServerPlayer p) {
        if (SURGE.containsKey(p.getUUID())) {
            endSurge(p);
        }
        InfinityMinions.dismiss(p);
    }

    // ---------------------------------------------------------------- bantuan

    private static ResourceLocation modId(String name) {
        return ShazamMod.id("infinity_surge_" + name);
    }

    private static void setMod(ServerPlayer p, Holder<Attribute> attribute, String name, double amount, AttributeModifier.Operation op) {
        AttributeInstance instance = p.getAttribute(attribute);
        if (instance != null) {
            instance.removeModifier(modId(name));
            instance.addTransientModifier(new AttributeModifier(modId(name), amount, op));
        }
    }

    private static void clearMod(ServerPlayer p, String name) {
        for (Holder<Attribute> a : java.util.List.of(Attributes.ATTACK_DAMAGE, Attributes.ATTACK_SPEED, Attributes.MOVEMENT_SPEED,
                Attributes.ARMOR, Attributes.ARMOR_TOUGHNESS, Attributes.KNOCKBACK_RESISTANCE, Attributes.SCALE, Attributes.JUMP_STRENGTH)) {
            AttributeInstance instance = p.getAttribute(a);
            if (instance != null) {
                instance.removeModifier(modId(name));
            }
        }
    }

    private static void msg(ServerPlayer p, String key, ChatFormatting color, Object... args) {
        p.displayClientMessage(Component.translatable("message.shazammod.infinity." + key, args).withStyle(color), true);
    }

    private static void sound(ServerPlayer p, Vec3 at, SoundEvent sound, float volume) {
        p.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, 1f);
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : f.normalize();
    }

    private static boolean valid(ServerPlayer p, LivingEntity e) {
        if (e == p || !e.isAlive() || p.isAlliedTo(e) || InfinityMinions.isMinion(e)) {
            return false;
        }
        if (e instanceof TamableAnimal pet && pet.isOwnedBy(p)) {
            return false;
        }
        return !(e instanceof net.minecraft.world.entity.player.Player) || p.server.isPvpAllowed();
    }

    private static java.util.List<LivingEntity> enemies(ServerPlayer p, double radius) {
        return p.serverLevel().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(radius), e -> valid(p, e));
    }
}
