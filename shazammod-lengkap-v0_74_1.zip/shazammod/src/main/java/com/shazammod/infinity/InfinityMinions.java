package com.shazammod.infinity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamMod;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 0.64 Undead yang dibangkitkan Batu Jiwa (Thanos) / Inti Jiwa (PRALAYA): zombie, tengkorak, tengkorak wither (PRALAYA:
 * tengkorak wither, stray, husk yang jauh lebih kuat). Mereka menyerang musuh pemiliknya (yang menyerang pemilik, yang
 * diserang pemilik, lalu monster terdekat), mengikuti pemiliknya, nggak bisa melukai pemiliknya / sesama undead-nya /
 * pemain lain kalau PvP mati, nggak menjatuhkan barang & XP, lalu hancur jadi tulang & debu jiwa saat waktunya habis
 * (atau pemiliknya mati / keluar). Undead sisa sesi sebelumnya (server restart) langsung dibuang saat dimuat.
 */
public final class InfinityMinions {
    private InfinityMinions() {}

    public static final String TAG = "shazammod.undead_minion";

    private static final class Minion {
        final Mob mob;
        final UUID owner;
        int life;

        Minion(Mob mob, UUID owner, int life) {
            this.mob = mob;
            this.owner = owner;
            this.life = life;
        }
    }

    private static final Map<UUID, Minion> ACTIVE = new HashMap<>();

    public static boolean isMinion(Entity e) {
        return e != null && e.getTags().contains(TAG);
    }

    public static UUID ownerOf(Entity e) {
        Minion m = e == null ? null : ACTIVE.get(e.getUUID());
        return m == null ? null : m.owner;
    }

    /** Undead lama milik pemain ini hancur dulu (pasukan baru menggantikan yang lama). */
    public static void dismiss(ServerPlayer owner) {
        for (Minion m : new ArrayList<>(ACTIVE.values())) {
            if (m.owner.equals(owner.getUUID())) {
                crumble(m, owner);
            }
        }
    }

    public static void spawn(ServerPlayer owner, InfinityTier tier, Vec3 at, int index, int life) {
        ServerLevel level = owner.serverLevel();
        EntityType<? extends Mob> type = switch (index % 3) {
            case 0 -> tier.pralaya ? EntityType.WITHER_SKELETON : EntityType.ZOMBIE;
            case 1 -> tier.pralaya ? EntityType.STRAY : EntityType.SKELETON;
            default -> tier.pralaya ? EntityType.HUSK : EntityType.WITHER_SKELETON;
        };
        Mob mob = type.create(level);
        if (mob == null) {
            return;
        }
        mob.moveTo(at.x, at.y, at.z, owner.getYRot() + (float) (level.random.nextDouble() * 60 - 30), 0f);
        mob.addTag(TAG);
        mob.setPersistenceRequired();
        mob.setItemSlot(EquipmentSlot.HEAD, new ItemStack(tier.pralaya ? Items.DIAMOND_HELMET : Items.IRON_HELMET));
        ItemStack weapon = switch (index % 3) {
            case 1 -> new ItemStack(Items.BOW);
            default -> new ItemStack(tier.pralaya ? Items.DIAMOND_SWORD : Items.IRON_SWORD);
        };
        mob.setItemSlot(EquipmentSlot.MAINHAND, weapon);
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            mob.setDropChance(slot, 0f);
        }
        int amp = tier.pralaya ? 1 : 0;
        mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, life + 20, amp + (tier.god ? 1 : 0)));
        mob.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, life + 20, amp));
        mob.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, life + 20, 0));
        if (tier.pralaya) {
            mob.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, life + 20, 0));
            AttributeInstance hp = mob.getAttribute(Attributes.MAX_HEALTH);
            if (hp != null) {
                hp.addPermanentModifier(new AttributeModifier(ShazamMod.id("infinity_undead_health"), tier.god ? 2.0 : 1.0,
                        AttributeModifier.Operation.ADD_MULTIPLIED_BASE));
                mob.setHealth(mob.getMaxHealth());
            }
        }
        ACTIVE.put(mob.getUUID(), new Minion(mob, owner.getUUID(), life));   // terdaftar dulu, baru masuk dunia
        level.addFreshEntity(mob);
    }

    // ---------------------------------------------------------------- tiap tick server

    public static void tick(MinecraftServer server) {
        if (ACTIVE.isEmpty()) {
            return;
        }
        for (Minion m : new ArrayList<>(ACTIVE.values())) {
            ServerPlayer owner = server.getPlayerList().getPlayer(m.owner);
            if (!m.mob.isAlive()) {
                ACTIVE.remove(m.mob.getUUID());
                continue;
            }
            if (--m.life <= 0 || owner == null || !owner.isAlive() || owner.level() != m.mob.level()) {
                crumble(m, owner);
                continue;
            }
            if (m.life % 10 != 0) {
                continue;
            }
            Mob mob = m.mob;
            LivingEntity target = mob.getTarget();
            if (!foe(owner, target)) {
                LivingEntity pick = owner.getLastHurtByMob();
                if (!foe(owner, pick)) {
                    pick = owner.getLastHurtMob();
                }
                if (!foe(owner, pick)) {
                    pick = nearestEnemy(owner, mob);
                }
                mob.setTarget(pick);
                target = pick;
            }
            double d2 = mob.distanceToSqr(owner);
            if (d2 > 48 * 48) {
                Vec3 near = owner.position().add(level(owner).random.nextDouble() * 4 - 2, 0, level(owner).random.nextDouble() * 4 - 2);
                mob.teleportTo(near.x, near.y, near.z);
            } else if (target == null && d2 > 10 * 10) {
                mob.getNavigation().moveTo(owner, 1.2);
            }
        }
    }

    private static ServerLevel level(ServerPlayer p) {
        return p.serverLevel();
    }

    private static boolean foe(ServerPlayer owner, LivingEntity e) {
        if (e == null || !e.isAlive() || e == owner || e.level() != owner.level() || e.distanceToSqr(owner) > 40 * 40) {
            return false;
        }
        if (isMinion(e) || owner.isAlliedTo(e) || (e instanceof TamableAnimal pet && pet.isOwnedBy(owner))) {
            return false;
        }
        return !(e instanceof Player) || owner.server.isPvpAllowed();
    }

    private static LivingEntity nearestEnemy(ServerPlayer owner, Mob mob) {
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (Mob e : mob.level().getEntitiesOfClass(Mob.class, mob.getBoundingBox().inflate(18.0), e -> e instanceof Enemy && foe(owner, e))) {
            double d = e.distanceToSqr(mob);
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        return best;
    }

    private static void crumble(Minion m, ServerPlayer owner) {
        ACTIVE.remove(m.mob.getUUID());
        if (!m.mob.isAlive()) {
            return;
        }
        Vec3 at = m.mob.position().add(0, m.mob.getBbHeight() * 0.5, 0);
        if (owner != null && owner.level() == m.mob.level()) {
            ShazamNetwork.playAnim(owner, ShazamAnim.INF_CRUMBLE, at);
        }
        m.mob.level().playSound(null, at.x, at.y, at.z, ShazamSounds.INFINITY_CRUMBLE.get(), SoundSource.PLAYERS, 1.2f, 1f);
        m.mob.discard();
    }

    public static void discardAll() {
        for (Minion m : ACTIVE.values()) {
            if (m.mob.isAlive()) {
                m.mob.discard();
            }
        }
        ACTIVE.clear();
    }

    // ---------------------------------------------------------------- event

    /** Undead sisa sesi lalu (nggak terdaftar) nggak boleh masuk dunia lagi. */
    public static void onJoin(EntityJoinLevelEvent event) {
        Entity e = event.getEntity();
        if (!event.getLevel().isClientSide() && isMinion(e) && !ACTIVE.containsKey(e.getUUID())) {
            event.setCanceled(true);
        }
    }

    /** Undead nggak melukai pemiliknya, sesama undead-nya, atau pemain lain kalau PvP mati; pemilik nggak melukai undead-nya. */
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        Entity attacker = event.getSource().getEntity();
        if (attacker == null) {
            return;
        }
        UUID attackerOwner = ownerOf(attacker);
        if (attackerOwner != null) {
            if (victim.getUUID().equals(attackerOwner) || attackerOwner.equals(ownerOf(victim))) {
                event.setCanceled(true);
            } else if (victim instanceof ServerPlayer p && (!p.server.isPvpAllowed() || allied(p, attackerOwner))) {
                event.setCanceled(true);
            }
            return;
        }
        UUID victimOwner = ownerOf(victim);
        if (victimOwner != null && attacker.getUUID().equals(victimOwner)) {
            event.setCanceled(true);
        }
    }

    private static boolean allied(ServerPlayer p, UUID owner) {
        ServerPlayer o = p.server.getPlayerList().getPlayer(owner);
        return o != null && o.isAlliedTo(p);
    }

    /** Daftar undead yang masih hidup milik pemain ini (buat efek & hitungan). */
    public static List<Mob> of(ServerPlayer owner) {
        List<Mob> out = new ArrayList<>();
        for (Minion m : ACTIVE.values()) {
            if (m.owner.equals(owner.getUUID()) && m.mob.isAlive()) {
                out.add(m.mob);
            }
        }
        return out;
    }
}
