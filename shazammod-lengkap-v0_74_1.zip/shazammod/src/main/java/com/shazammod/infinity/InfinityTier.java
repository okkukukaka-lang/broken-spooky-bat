package com.shazammod.infinity;

import com.shazammod.thanos.ThanosConfig;

/** 0.64 Seberapa besar Kuasa Infinity: Thanos, PRALAYA (lebih OP), PRALAYA Fase Dewa (paling OP). Angkanya di ThanosConfig. */
public enum InfinityTier {
    THANOS(false, false),
    PRALAYA(true, false),
    PRALAYA_GOD(true, true);

    public final boolean pralaya;
    public final boolean god;

    InfinityTier(boolean pralaya, boolean god) {
        this.pralaya = pralaya;
        this.god = god;
    }

    private double godMul() {
        return god ? 1.25 : 1.0;
    }

    public int craterRadius() {
        return pralaya ? (int) Math.round(ThanosConfig.CRATER_PRALAYA.get() * godMul()) : ThanosConfig.CRATER_THANOS.get();
    }

    public float craterDamage() {
        return pralaya ? (god ? 120f : 80f) : 40f;
    }

    public int rewriteRadius() {
        return pralaya ? (int) Math.round(ThanosConfig.REALITY_PRALAYA.get() * godMul()) : ThanosConfig.REALITY_THANOS.get();
    }

    /** 0 = permanen. */
    public int rewriteTicks() {
        int sec = ThanosConfig.REALITY_SECONDS.get();
        return sec <= 0 ? 0 : sec * 20 * (pralaya ? 2 : 1);
    }

    /** Peluang tiap monster di zona berubah jadi hewan jinak. */
    public float transmuteChance() {
        return pralaya ? 1f : 0.4f;
    }

    public int portalRange() {
        return pralaya ? ThanosConfig.PORTAL_PRALAYA.get() : ThanosConfig.PORTAL_THANOS.get();
    }

    public int undeadCount() {
        return pralaya ? ThanosConfig.UNDEAD_PRALAYA.get() + (god ? 4 : 0) : ThanosConfig.UNDEAD_THANOS.get();
    }

    public int undeadTicks() {
        return ThanosConfig.UNDEAD_SECONDS.get() * 20 * (pralaya ? 2 : 1);
    }

    public int surgeTicks() {
        return pralaya ? (god ? 1200 : 900) : 600;
    }
}
