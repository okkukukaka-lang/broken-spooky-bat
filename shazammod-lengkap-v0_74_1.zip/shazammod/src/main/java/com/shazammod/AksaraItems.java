package com.shazammod;

import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Barang PRALAYA (0.55: armor yang dipanggil dari jauh, lihat PralayaProgress):
 * - Inti Armor PRALAYA (id lama lontar_sabda, supaya dunia lama aman): dirakit dari blok besi, blok redstone, berlian &
 *   blok emas. Klik kanan dalam wujud manusia = armor dipasangkan ke tubuhmu (AksaraRite); sesudahnya klik kanan =
 *   pelacak sinyal benteng meteor terdekat. Nggak habis dipakai.
 * - Modul Tempa Nether / Modul Kalibrasi End: dipasang (klik kanan) DI dimensinya. Keduanya + Inti Pikiran = Fase 2.
 * - Enam inti (Kekuatan, Ruang, Pikiran, Realitas, Waktu, Jiwa): cuma ada di benteng meteor. Pernah dipegang = tercatat
 *   di armor selamanya; DIBAWA di inventori = skill intinya bisa dipakai tanpa armor (lebih lemah).
 */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class AksaraItems {
    private AksaraItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ShazamMod.MODID);

    public static final DeferredItem<LontarItem> LONTAR = ITEMS.register("lontar_sabda",
            () -> new LontarItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final DeferredItem<ModuleItem> MODULE_NETHER = ITEMS.register("modul_tempa_nether",
            () -> new ModuleItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE).fireResistant(), true));
    public static final DeferredItem<ModuleItem> MODULE_END = ITEMS.register("modul_kalibrasi_end",
            () -> new ModuleItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE).fireResistant(), false));

    /** Urutan sama dengan inti di AksaraSkills: kekuatan, ruang, pikiran, realitas, waktu, jiwa. */
    public static final String[] CORE_IDS = {"inti_daya", "inti_ruang", "inti_benak", "inti_maya", "inti_kala", "inti_atma"};
    private static final ChatFormatting[] CORE_COLOR = {ChatFormatting.RED, ChatFormatting.DARK_PURPLE, ChatFormatting.AQUA,
            ChatFormatting.LIGHT_PURPLE, ChatFormatting.GOLD, ChatFormatting.GREEN};
    @SuppressWarnings("unchecked")
    private static final DeferredItem<CoreItem>[] CORES = new DeferredItem[6];

    static {
        for (int i = 0; i < 6; i++) {
            final int core = i;
            CORES[i] = ITEMS.register(CORE_IDS[i], () -> new CoreItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)
                    .fireResistant(), core));
        }
    }

    public static Item core(int core) {
        return CORES[Math.max(0, Math.min(5, core))].get();
    }

    @SubscribeEvent
    public static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(LONTAR.get());
            event.accept(MODULE_NETHER.get());
            event.accept(MODULE_END.get());
            for (DeferredItem<CoreItem> core : CORES) {
                event.accept(core.get());
            }
        }
    }

    /** Inti Armor PRALAYA: belum terpasang = pasangkan armornya; sudah = pelacak sinyal inti. */
    public static class LontarItem extends LintangItems.LoreItem {
        public LontarItem(Item.Properties properties) {
            super(properties, "item.shazammod.lontar_sabda", ChatFormatting.GOLD, true);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (player instanceof ServerPlayer serverPlayer) {
                if (ShazamPowers.data(serverPlayer).aksaraUnlocked()) {
                    PralayaProgress.showSignal(serverPlayer);
                } else {
                    AksaraRite.tryBegin(serverPlayer);
                }
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
    }

    /** Modul upgrade armor: dipasang di Nether / di End. Habis kalau terpasang. */
    public static class ModuleItem extends LintangItems.LoreItem {
        private final boolean nether;

        public ModuleItem(Item.Properties properties, boolean nether) {
            super(properties, nether ? "item.shazammod.modul_tempa_nether" : "item.shazammod.modul_kalibrasi_end",
                    nether ? ChatFormatting.RED : ChatFormatting.LIGHT_PURPLE, true);
            this.nether = nether;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (player instanceof ServerPlayer serverPlayer && PralayaProgress.useModule(serverPlayer, nether)
                    && !serverPlayer.getAbilities().instabuild) {
                stack.shrink(1);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
    }

    /** Salah satu enam inti. Dibawa di inventori = skill intinya bisa dipakai tanpa armor. */
    public static class CoreItem extends LintangItems.LoreItem {
        public final int core;

        public CoreItem(Item.Properties properties, int core) {
            super(properties, "item.shazammod." + CORE_IDS[core], CORE_COLOR[core], true);
            this.core = core;
        }
    }
}
