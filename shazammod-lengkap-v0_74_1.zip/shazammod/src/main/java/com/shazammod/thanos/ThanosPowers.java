package com.shazammod.thanos;

import com.shazammod.ShazamMod;

import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

/** 0.62 Stat wujud Thanos (modifier atribut sementara, dipasang ulang saat login). Angkanya di ThanosConfig. */
public final class ThanosPowers {
    private ThanosPowers() {}

    private static final AttributeModifier.Operation ADD = AttributeModifier.Operation.ADD_VALUE;

    public static void apply(Player p) {
        set(p, Attributes.MAX_HEALTH, "health", ThanosConfig.HEALTH.get(), ADD);
        set(p, Attributes.ARMOR, "armor", ThanosConfig.ARMOR.get(), ADD);
        set(p, Attributes.ARMOR_TOUGHNESS, "toughness", ThanosConfig.TOUGHNESS.get(), ADD);
        set(p, Attributes.ATTACK_DAMAGE, "damage", ThanosConfig.DAMAGE.get(), ADD);
        set(p, Attributes.KNOCKBACK_RESISTANCE, "knockback", ThanosConfig.KNOCKBACK.get(), ADD);
        set(p, Attributes.MOVEMENT_SPEED, "speed", ThanosConfig.SPEED.get(), AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        set(p, Attributes.JUMP_STRENGTH, "jump", ThanosConfig.JUMP.get(), ADD);
        set(p, Attributes.SCALE, "scale", ThanosConfig.SCALE.get(), ADD);
        set(p, Attributes.STEP_HEIGHT, "step", 0.5, ADD);
        set(p, Attributes.SAFE_FALL_DISTANCE, "fall", 12.0, ADD);
    }

    public static void remove(Player p) {
        clear(p, Attributes.MAX_HEALTH, "health");
        clear(p, Attributes.ARMOR, "armor");
        clear(p, Attributes.ARMOR_TOUGHNESS, "toughness");
        clear(p, Attributes.ATTACK_DAMAGE, "damage");
        clear(p, Attributes.KNOCKBACK_RESISTANCE, "knockback");
        clear(p, Attributes.MOVEMENT_SPEED, "speed");
        clear(p, Attributes.JUMP_STRENGTH, "jump");
        clear(p, Attributes.SCALE, "scale");
        clear(p, Attributes.STEP_HEIGHT, "step");
        clear(p, Attributes.SAFE_FALL_DISTANCE, "fall");
        if (p.getHealth() > p.getMaxHealth()) {
            p.setHealth(p.getMaxHealth());
        }
    }

    private static ResourceLocation id(String name) {
        return ShazamMod.id("thanos_" + name);
    }

    private static void set(Player p, Holder<Attribute> attribute, String name, double amount, AttributeModifier.Operation op) {
        AttributeInstance instance = p.getAttribute(attribute);
        if (instance != null) {
            instance.removeModifier(id(name));
            if (amount != 0.0) {
                instance.addTransientModifier(new AttributeModifier(id(name), amount, op));
            }
        }
    }

    private static void clear(Player p, Holder<Attribute> attribute, String name) {
        AttributeInstance instance = p.getAttribute(attribute);
        if (instance != null) {
            instance.removeModifier(id(name));
        }
    }
}
