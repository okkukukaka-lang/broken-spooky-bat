package com.shazammod.thanos.entity;

import java.util.HashSet;
import java.util.Set;

import com.shazammod.thanos.ThanosConfig;
import com.shazammod.thanos.ThanosRegistry;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.62 Pedang Dua Mata yang dilempar: menembus musuh, berbalik sesudah 25 tick atau menabrak blok, lalu kembali ke
 * tangan pelemparnya (tiap musuh bisa kena sekali saat pergi dan sekali saat kembali). Kalau pemiliknya mati, pindah
 * dimensi, atau terlalu jauh: pedangnya jatuh di tempat (nggak pernah hilang).
 */
public class ThrownDoubleBlade extends ThrowableItemProjectile {
    private static final int OUT_TICKS = 25;
    private static final int MAX_AGE = 200;

    private boolean returning;
    private int age;
    private final Set<Integer> hit = new HashSet<>();

    public ThrownDoubleBlade(EntityType<? extends ThrownDoubleBlade> type, Level level) {
        super(type, level);
    }

    public ThrownDoubleBlade(Level level, LivingEntity owner, ItemStack stack) {
        super(ThanosRegistry.THROWN_BLADE.get(), owner, level);
        setItem(stack);
        setNoGravity(true);
    }

    @Override
    protected Item getDefaultItem() {
        return ThanosRegistry.DOUBLE_BLADE.get();
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity target = result.getEntity();
        if (level().isClientSide || target == getOwner() || !hit.add(target.getId())) {
            return;
        }
        target.hurt(damageSources().thrown(this, getOwner()), ThanosConfig.THROW_DAMAGE.get().floatValue());
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        turnBack();
    }

    private void turnBack() {
        if (!returning) {
            returning = true;
            hit.clear();
        }
    }

    @Override
    public void tick() {
        if (!level().isClientSide) {
            if (++age > OUT_TICKS) {
                turnBack();
            }
            if (returning) {
                Entity owner = getOwner();
                if (!(owner instanceof Player player) || !player.isAlive() || player.level() != level()
                        || distanceToSqr(player) > 64.0 * 64.0 || age > MAX_AGE) {
                    spawnAtLocation(getItem());
                    discard();
                    return;
                }
                noPhysics = true;
                Vec3 to = player.getEyePosition().subtract(position());
                if (to.lengthSqr() < 2.5) {
                    if (!player.getAbilities().instabuild && !player.getInventory().add(getItem())) {
                        player.drop(getItem(), false);
                    }
                    discard();
                    return;
                }
                setDeltaMovement(to.normalize().scale(1.6));
                hasImpulse = true;
            }
        }
        super.tick();
    }
}
