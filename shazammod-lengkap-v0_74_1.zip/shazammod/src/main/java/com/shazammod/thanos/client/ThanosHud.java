package com.shazammod.thanos.client;

import com.shazammod.thanos.StoneType;
import com.shazammod.thanos.ThanosClientState;
import com.shazammod.thanos.ThanosData;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * 0.63 HUD Thanos, di kanan hotbar (HUD juara ada di kiri atas, jadi nggak bertabrakan):
 *
 *   sinyal kuil terdekat (warna batunya, jarak & arah)
 *   enam kotak batu Z X C V B N: berwarna = tercatat di Gauntlet, gelap = belum; redup = kuasa normal cooldown,
 *   garis di bawahnya = kuasa Shift cooldown
 *   R Jentikan (siap / butuh 6 batu / cooldown), Murka Titan & Perisai Jiwa (sisa detik)
 *   bar Energi Thanos (emas saat penuh)
 *
 * Saat mengisi Jentikan: hitung mundur besar di atas bidikan.
 */
public final class ThanosHud {
    private ThanosHud() {}

    private static final int BOX = 11, GAP = 2;
    private static final int SHADE = 0xA0000000, EMPTY = 0xFF22202A, EDGE = 0xFF5A5468;
    private static final int ENERGY = 0xFFB070F0, ENERGY_FULL = 0xFFFFD34D;
    private static final String[] ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || !ThanosClientState.bound) {
            return;
        }
        Font font = mc.font;
        boolean form = ThanosClientState.transformed;
        int width = StoneType.COUNT * BOX + (StoneType.COUNT - 1) * GAP;
        int x = g.guiWidth() / 2 + 91 + 30;   // lewat indikator serangan & slot tangan kiri
        if (x + width + 40 > g.guiWidth()) {
            x = g.guiWidth() - width - 40;
        }
        int bottom = g.guiHeight();

        // sinyal kuil terdekat
        int sig = ThanosClientState.signalStone;
        if (sig >= 0) {
            StoneType s = StoneType.byIndex(sig);
            double dx = ThanosClientState.signalX + 0.5 - mc.player.getX(), dz = ThanosClientState.signalZ + 0.5 - mc.player.getZ();
            int dist = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
            float rel = Mth.wrapDegrees((float) Math.toDegrees(Math.atan2(-dx, dz)) - mc.player.getYRot());
            String arrow = ARROWS[Math.floorMod(Math.round(rel / 45f), 8)];
            Component line = Component.translatable("hud.shazammod.thanos.signal", Component.translatable("stone.shazammod." + s.id),
                    dist, arrow);
            g.drawString(font, line, x, bottom - (form ? 56 : 30), 0xFF000000 | s.rgb);
        }
        if (!form) {
            g.drawString(font, Component.translatable("hud.shazammod.thanos.human"), x, bottom - 18, 0xFF9A8AB0);
            return;
        }

        // enam kotak batu
        int boxY = bottom - 44;
        for (StoneType t : StoneType.values()) {
            int bx = x + t.ordinal() * (BOX + GAP);
            boolean has = (ThanosClientState.stones & t.bit()) != 0;
            g.fill(bx - 1, boxY - 1, bx + BOX + 1, boxY + BOX + 1, has ? 0xFF0A0A0A : EDGE);
            g.fill(bx, boxY, bx + BOX, boxY + BOX, has ? 0xFF000000 | t.rgb : EMPTY);
            int cd = ThanosClientState.cooldown(t.ordinal());
            if (has && cd > 0) {
                g.fill(bx, boxY, bx + BOX, boxY + BOX, 0xB0000000);
            }
            int cdShift = ThanosClientState.cooldown(t.ordinal() + ThanosData.SLOT_SHIFT);
            g.fill(bx, boxY + BOX + 2, bx + BOX, boxY + BOX + 4, has ? (cdShift > 0 ? 0xFF3A3640 : 0xFF000000 | t.rgb) : EMPTY);
            g.drawString(font, t.key, bx + 3, boxY + 2, has ? (cd > 0 ? 0xFF888888 : 0xFF101010) : 0xFF6A6478, false);
        }

        // R & status
        StringBuilder status = new StringBuilder();
        int snapCd = ThanosClientState.cooldown(ThanosData.SLOT_SNAP);
        Component snap = ThanosClientState.stones != StoneType.ALL
                ? Component.translatable("hud.shazammod.thanos.snap_need", Integer.bitCount(ThanosClientState.stones))
                : snapCd > 0 ? Component.translatable("hud.shazammod.thanos.snap_cd", seconds(snapCd))
                : Component.translatable("hud.shazammod.thanos.snap_ready");
        g.drawString(font, snap, x, bottom - 28, ThanosClientState.stones == StoneType.ALL && snapCd <= 0 ? 0xFFFFD34D : 0xFFB8B0C8);
        if (ThanosClientState.rageTicks > 0) {
            status.append("\u2620 ").append(seconds(ThanosClientState.rageTicks)).append("  ");
        }
        if (ThanosClientState.shieldTicks > 0) {
            status.append("\u2726 ").append(seconds(ThanosClientState.shieldTicks));
        }
        if (!status.isEmpty()) {
            g.drawString(font, status.toString(), x + width + 4, boxY + 2, 0xFFFF8A50);
        }

        // energi
        int barY = bottom - 8;
        float energy = ThanosClientState.energy;
        g.fill(x - 1, barY - 1, x + width + 1, barY + 4, SHADE);
        g.fill(x, barY, x + Math.round(width * energy / ThanosData.MAX_ENERGY), barY + 3,
                energy >= ThanosData.MAX_ENERGY ? ENERGY_FULL : ENERGY);
        g.drawString(font, String.valueOf(Math.round(energy)), x + width + 4, barY - 3, 0xFFB8B0C8);

        if (ThanosClientState.snapCharge > 0) {
            Component charging = Component.translatable("hud.shazammod.thanos.snap_charging", (ThanosClientState.snapCharge + 19) / 20);
            g.drawCenteredString(font, charging, g.guiWidth() / 2, g.guiHeight() / 2 - 30, 0xFFFFD040);
        }
    }

    private static String seconds(int ticks) {
        int s = (ticks + 19) / 20;
        return s >= 60 ? (s / 60) + ":" + String.format("%02d", s % 60) : s + "s";
    }
}
