package com.shazammod.thanos;

import java.util.Locale;

import com.shazammod.ShazamMod;

import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.ServerChatEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/** 0.62 Event Thanos di server. */
@EventBusSubscriber(modid = ShazamMod.MODID)
public final class ThanosEvents {
    private ThanosEvents() {}

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ThanosAbilities.tick(player);
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ThanosAbilities.onLogin(player);
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ThanosAbilities.onRespawn(player);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            ThanosSkills.clear(player);
        }
    }

    /** Pemain lain masuk jangkauan pandang: kirim status Thanos-nya (aura & cahaya batu). */
    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof ServerPlayer thanos && event.getEntity() instanceof ServerPlayer viewer
                && ThanosAbilities.active(thanos)) {
            ThanosNetwork.sendStateTo(thanos, viewer);
        }
    }

    /** Tangkisan Pedang Dua Mata & pantulan Perisai Jiwa. */
    @SubscribeEvent
    public static void onIncomingDamage(LivingIncomingDamageEvent event) {
        ThanosAbilities.guard(event);
    }

    /** Ketik "thanos" di chat = sama dengan tombol U. */
    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        String word = event.getRawText().toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
        if (word.equals("thanos")) {
            ServerPlayer player = event.getPlayer();
            player.server.execute(() -> ThanosAbilities.toggleTransform(player));
        }
    }
}
