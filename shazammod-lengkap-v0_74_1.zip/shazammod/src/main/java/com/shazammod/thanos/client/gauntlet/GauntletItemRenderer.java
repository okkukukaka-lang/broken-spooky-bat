package com.shazammod.thanos.client.gauntlet;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** 0.65 Infinity Gauntlet sebagai barang 3D (models/item/infinity_gauntlet.json = builtin/entity). */
public class GauntletItemRenderer extends BlockEntityWithoutLevelRenderer {
    public GauntletItemRenderer() {
        super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext displayContext, PoseStack poseStack,
                             MultiBufferSource buffer, int packedLight, int packedOverlay) {
        try {
            GauntletRender.renderItem(stack, displayContext, poseStack, buffer, packedLight, packedOverlay);
        } catch (Throwable ignored) {
            // biarkan kosong daripada membuat GUI macet
        }
    }
}
