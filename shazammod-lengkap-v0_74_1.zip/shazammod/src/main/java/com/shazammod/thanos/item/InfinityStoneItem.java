package com.shazammod.thanos.item;

import java.util.List;

import com.shazammod.thanos.StoneType;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/** 0.63 Salah satu enam batu: begitu dipegang (masuk inventori), tercatat di Gauntlet pemiliknya selamanya. */
public class InfinityStoneItem extends Item {
    public final StoneType type;

    public InfinityStoneItem(StoneType type, Item.Properties properties) {
        super(properties);
        this.type = type;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shazammod.thanos.stone." + type.id, type.key)
                .withStyle(s -> s.withColor(type.rgb)));
        tooltip.add(Component.translatable("tooltip.shazammod.thanos.stone_record").withStyle(ChatFormatting.GRAY));
    }
}
