package com.shazammod.thanos;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.Supplier;

import com.shazammod.ShazamMod;
import com.shazammod.thanos.entity.ThrownDoubleBlade;
import com.shazammod.thanos.item.DoubleBladeSwordItem;
import com.shazammod.thanos.item.InfinityGauntletItem;
import com.shazammod.thanos.item.InfinityStoneItem;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.component.Unbreakable;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/** 0.62 Semua yang didaftarkan untuk Thanos: data pemain, Pedang Dua Mata, Infinity Gauntlet, enam batu, pedang terlempar. */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ThanosRegistry {
    private ThanosRegistry() {}

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, ShazamMod.MODID);

    public static final Supplier<AttachmentType<ThanosData>> DATA = ATTACHMENTS.register("thanos",
            () -> AttachmentType.builder(() -> new ThanosData())
                    .serialize(ThanosData.CODEC)
                    .copyOnDeath()
                    .build());

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ShazamMod.MODID);

    /** Damage 11 (netherite +6), 1,2 serangan/detik, nggak bisa rusak. */
    public static final DeferredItem<DoubleBladeSwordItem> DOUBLE_BLADE = ITEMS.register("thanos_double_blade",
            () -> new DoubleBladeSwordItem(new Item.Properties().fireResistant().rarity(Rarity.EPIC)
                    .component(DataComponents.UNBREAKABLE, new Unbreakable(true))
                    .attributes(SwordItem.createAttributes(Tiers.NETHERITE, 6, -2.8f))));

    public static final DeferredItem<InfinityGauntletItem> GAUNTLET = ITEMS.register("infinity_gauntlet",
            () -> new InfinityGauntletItem(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC)));

    private static final Map<StoneType, DeferredItem<InfinityStoneItem>> STONES = new EnumMap<>(StoneType.class);

    static {
        for (StoneType type : StoneType.values()) {
            STONES.put(type, ITEMS.register(type.id + "_stone",
                    () -> new InfinityStoneItem(type, new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC))));
        }
    }

    public static Item stone(StoneType type) {
        return STONES.get(type).get();
    }

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, ShazamMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<ThrownDoubleBlade>> THROWN_BLADE = ENTITIES.register(
            "thrown_double_blade", () -> EntityType.Builder.<ThrownDoubleBlade>of(ThrownDoubleBlade::new, MobCategory.MISC)
                    .sized(0.9f, 0.9f).clientTrackingRange(6).updateInterval(3).build("thrown_double_blade"));

    public static void register(IEventBus modEventBus) {
        ATTACHMENTS.register(modEventBus);
        ITEMS.register(modEventBus);
        ENTITIES.register(modEventBus);
    }

    @SubscribeEvent
    public static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(DOUBLE_BLADE.get());
            event.accept(GAUNTLET.get());
            for (StoneType type : StoneType.values()) {
                event.accept(stone(type));
            }
        }
    }
}
