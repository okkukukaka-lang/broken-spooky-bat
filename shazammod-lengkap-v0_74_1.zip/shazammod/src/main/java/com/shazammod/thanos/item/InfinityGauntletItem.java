package com.shazammod.thanos.item;

import java.util.List;

import com.shazammod.thanos.StoneType;
import com.shazammod.thanos.ThanosClientState;
import com.shazammod.thanos.ThanosSanctum;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * 0.63 Infinity Gauntlet. Klik kanan pertama kali = Sumpah Titan (Gauntlet terikat, Thanos terbuka); sesudahnya klik
 * kanan = Sinyal Batu (arah & jarak Kuil Titan terdekat). Selama ada di inventori Gauntlet dianggap dipakai: syarat
 * berubah jadi Thanos & memakai kuasa batu. Batu nggak dipasang ke barangnya: yang pernah dipegang tercatat di pemiliknya
 * selamanya (sama seperti inti PRALAYA), jadi Gauntlet baru tetap memuat semua batumu.
 */
public class InfinityGauntletItem extends Item {
    public InfinityGauntletItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player instanceof ServerPlayer serverPlayer) {
            ThanosSanctum.beginBind(serverPlayer);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return ThanosClientState.stones == StoneType.ALL;   // cuma dipakai client (gambar kilau)
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(ThanosClientState.bound ? "tooltip.shazammod.thanos.gauntlet_bound"
                : "tooltip.shazammod.thanos.gauntlet_unbound").withStyle(ChatFormatting.DARK_PURPLE));
        for (StoneType type : StoneType.values()) {
            boolean has = (ThanosClientState.stones & type.bit()) != 0;
            tooltip.add(Component.literal((has ? "\u25C6 " : "\u25C7 ") + type.key + "  ")
                    .append(Component.translatable("item.shazammod." + type.id + "_stone"))
                    .withStyle(s -> s.withColor(has ? type.rgb : 0x555555)));
        }
        tooltip.add(Component.translatable("tooltip.shazammod.thanos.gauntlet").withStyle(ChatFormatting.GRAY));
    }
}
