package com.shazammod.thanos;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;
import com.shazammod.thanos.item.InfinityStoneItem;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/**
 * 0.63 Batu Infinity, konsepnya SAMA dengan inti PRALAYA:
 *
 *   Sumpah Titan   klik kanan Infinity Gauntlet (wujud manusia): Gauntlet terikat padamu, Thanos terbuka, sinyal Batu
 *                  Kekuatan pertama muncul (350-650 blok dari tempatmu)
 *   Kuil Titan     tiap batu di kuilnya sendiri, letaknya dipilih per pemain dan dibangun begitu pemiliknya mendekat
 *                  (96 blok, Overworld): pelataran batu hitam, enam pilar patah, altar bertingkat dengan peti batu,
 *                  urat kaca warna batunya, api sinyal (asapnya kelihatan dari jauh), dan penjaga
 *   Tercatat       batu yang pernah dipegang tercatat di Gauntlet selamanya: dua kuasanya (tombolnya, normal & Shift)
 *                  langsung terbuka. Sesudah Batu Kekuatan, sinyal lima batu lainnya muncul (600-1300 blok)
 *   Sinyal         klik kanan Gauntlet (atau Shift+J sebagai Thanos): arah & jarak kuil terdekat
 *   Keenamnya      Jentikan (R) terbuka
 */
public final class ThanosSanctum {
    private ThanosSanctum() {}

    private static final int FIRST_MIN = 350, FIRST_MAX = 650;
    private static final int REST_MIN = 600, REST_MAX = 1300;
    private static final double BUILD_RANGE = 96.0;
    private static final int RADIUS = 11;
    private static final String[] DIRS = {"n", "ne", "e", "se", "s", "sw", "w", "nw"};
    private static final String[] ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};

    // ---------------------------------------------------------------- tiap detik

    public static void tick(ServerPlayer p) {
        if (p.tickCount % 20 != 11) {
            return;
        }
        ThanosData d = ThanosAbilities.data(p);
        int fresh = carriedMask(p) & ~d.stones;
        for (StoneType stone : StoneType.values()) {
            if ((fresh & stone.bit()) != 0) {
                found(p, d, stone);
            }
        }
        if (d.bound) {
            ensureSites(p, d);
            tickSites(p, d);
        }
    }

    public static int carriedMask(ServerPlayer p) {
        Inventory inv = p.getInventory();
        int mask = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).getItem() instanceof InfinityStoneItem stone) {
                mask |= stone.type.bit();
            }
        }
        return mask;
    }

    /** Batu pertama kali dipegang: tercatat di Gauntlet selamanya, dua kuasanya terbuka. */
    static void found(ServerPlayer p, ThanosData d, StoneType stone) {
        d.stones |= stone.bit();
        int count = Integer.bitCount(d.stones);
        ShazamNetwork.playAnim(p, ShazamAnim.TITAN_STONE_FOUND, new Vec3(stone.ordinal(), count, 0));
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.THANOS_STONE_FOUND.get(), SoundSource.PLAYERS,
                1.8f, 1f);
        p.displayClientMessage(Component.translatable(d.bound ? "message.shazammod.thanos.stone_found"
                        : "message.shazammod.thanos.stone_found_unbound", ThanosAbilities.stoneName(stone), count)
                .withStyle(ChatFormatting.BOLD), false);
        p.displayClientMessage(Component.translatable("message.shazammod.thanos.stone_skills." + stone.id, stone.key)
                .withStyle(s -> s.withColor(stone.rgb)), false);
        if (d.stones == StoneType.ALL) {
            p.displayClientMessage(Component.translatable("message.shazammod.thanos.all_stones")
                    .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD), false);
        }
        if (d.bound) {
            ensureSites(p, d);
        }
        ThanosNetwork.sync(p);
        ThanosNetwork.broadcastState(p);
    }

    // ---------------------------------------------------------------- Sumpah Titan

    /** Klik kanan Gauntlet yang belum terikat: ritual Sumpah Titan (TITAN_BIND_TICKS), lalu Thanos terbuka. */
    public static void beginBind(ServerPlayer p) {
        ThanosData d = ThanosAbilities.data(p);
        if (d.bound) {
            showSignal(p);
            return;
        }
        if (ThanosAbilities.championBusy(p)) {
            ThanosAbilities.msg(p, "champion_active", ChatFormatting.GRAY);
            return;
        }
        if (!ThanosSkills.free(p)) {
            return;
        }
        ThanosSkills.busy(p, ShazamAnim.TITAN_BIND_TICKS);
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_BIND);
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.THANOS_BIND.get(), SoundSource.PLAYERS, 2.2f, 1f);
        p.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN,
                ShazamAnim.TITAN_BIND_BURST, 5, false, false));
        ThanosAbilities.msg(p, "bind_start", ChatFormatting.DARK_PURPLE);
        ThanosSkills.later(p, ShazamAnim.TITAN_BIND_BURST, sp -> {
            ThanosData data = ThanosAbilities.data(sp);
            if (data.bound || !ThanosAbilities.hasGauntlet(sp)) {
                return;
            }
            data.bound = true;
            sp.displayClientMessage(Component.translatable("message.shazammod.thanos.bound")
                    .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD), false);
            sp.displayClientMessage(Component.translatable("message.shazammod.thanos.bound_help")
                    .withStyle(ChatFormatting.LIGHT_PURPLE), false);
            ensureSites(sp, data);
            ThanosNetwork.sync(sp);
        });
    }

    // ---------------------------------------------------------------- Kuil Titan

    private static BlockPos origin(ServerPlayer p) {
        return p.level().dimension() == Level.OVERWORLD ? p.blockPosition() : p.server.overworld().getSharedSpawnPos();
    }

    private static void assign(ServerPlayer p, ThanosData d, StoneType stone, BlockPos origin, double angle, int min, int max) {
        double dist = min + p.getRandom().nextDouble() * (max - min);
        d.siteX[stone.ordinal()] = origin.getX() + (int) Math.round(Math.cos(angle) * dist);
        d.siteZ[stone.ordinal()] = origin.getZ() + (int) Math.round(Math.sin(angle) * dist);
        d.sitesSet |= stone.bit();
        d.sitesBuilt &= ~stone.bit();
    }

    /** Sinyal Batu Kekuatan sejak Gauntlet terikat; lima lainnya sejak Batu Kekuatan tercatat. */
    static void ensureSites(ServerPlayer p, ThanosData d) {
        if (!d.bound) {
            return;
        }
        if ((d.sitesSet & StoneType.POWER.bit()) == 0 && !d.has(StoneType.POWER)) {
            assign(p, d, StoneType.POWER, origin(p), p.getRandom().nextDouble() * Math.PI * 2.0, FIRST_MIN, FIRST_MAX);
            p.displayClientMessage(Component.translatable("message.shazammod.thanos.first_signal")
                    .withStyle(ChatFormatting.LIGHT_PURPLE), false);
        }
        if (d.stones == 0) {
            return;
        }
        boolean any = false;
        double base = p.getRandom().nextDouble() * Math.PI * 2.0;
        int k = 0;
        for (StoneType stone : StoneType.values()) {
            if (stone == StoneType.POWER) {
                continue;
            }
            if ((d.sitesSet & stone.bit()) == 0 && !d.has(stone)) {
                assign(p, d, stone, origin(p), base + k * Math.PI * 2.0 / 5.0 + (p.getRandom().nextDouble() - 0.5) * 0.6,
                        REST_MIN, REST_MAX);
                any = true;
            }
            k++;
        }
        if (any) {
            p.displayClientMessage(Component.translatable("message.shazammod.thanos.rest_signals")
                    .withStyle(ChatFormatting.LIGHT_PURPLE), false);
        }
    }

    private static void tickSites(ServerPlayer p, ThanosData d) {
        if (p.level().dimension() != Level.OVERWORLD) {
            return;
        }
        ServerLevel level = p.serverLevel();
        for (StoneType stone : StoneType.values()) {
            int bit = stone.bit();
            if ((d.sitesSet & bit) == 0 || (d.sitesBuilt & bit) != 0 || d.has(stone)) {
                continue;
            }
            int x = d.siteX[stone.ordinal()], z = d.siteZ[stone.ordinal()];
            double dx = x + 0.5 - p.getX(), dz = z + 0.5 - p.getZ();
            if (dx * dx + dz * dz > BUILD_RANGE * BUILD_RANGE || !areaLoaded(level, x, z)) {
                continue;
            }
            build(level, stone, x, z);
            d.sitesBuilt |= bit;
            p.displayClientMessage(Component.translatable("message.shazammod.thanos.site_near", ThanosAbilities.stoneName(stone))
                    .withStyle(ChatFormatting.BOLD), true);
            level.playSound(null, x + 0.5, p.getY(), z + 0.5, SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 1.2f, 0.7f);
        }
    }

    private static boolean areaLoaded(ServerLevel level, int x, int z) {
        for (int sx = -1; sx <= 1; sx += 2) {
            for (int sz = -1; sz <= 1; sz += 2) {
                if (!level.isLoaded(new BlockPos(x + sx * (RADIUS + 3), 64, z + sz * (RADIUS + 3)))) {
                    return false;
                }
            }
        }
        return true;
    }

    /** {batu, x, z} kuil terdekat yang batunya belum tercatat, atau null. */
    public static int[] tracked(ServerPlayer p) {
        ThanosData d = ThanosAbilities.data(p);
        int[] best = null;
        double bd = Double.MAX_VALUE;
        for (StoneType stone : StoneType.values()) {
            if (d.has(stone) || (d.sitesSet & stone.bit()) == 0) {
                continue;
            }
            int x = d.siteX[stone.ordinal()], z = d.siteZ[stone.ordinal()];
            double dist = (x - p.getX()) * (x - p.getX()) + (z - p.getZ()) * (z - p.getZ());
            if (dist < bd) {
                bd = dist;
                best = new int[] {stone.ordinal(), x, z};
            }
        }
        return best;
    }

    /** Klik kanan Gauntlet yang sudah terikat (atau Shift+J): arah & jarak kuil terdekat. */
    public static void showSignal(ServerPlayer p) {
        ThanosData d = ThanosAbilities.data(p);
        int[] s = tracked(p);
        if (s == null) {
            ThanosAbilities.msg(p, d.stones == StoneType.ALL ? "all_found" : "no_signal", ChatFormatting.GRAY);
            return;
        }
        if (p.level().dimension() != Level.OVERWORLD) {
            ThanosAbilities.msg(p, "signal_dim", ChatFormatting.GRAY);
            return;
        }
        StoneType stone = StoneType.byIndex(s[0]);
        double dx = s[1] + 0.5 - p.getX(), dz = s[2] + 0.5 - p.getZ();
        int dist = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
        double bearing = Math.toDegrees(Math.atan2(dx, -dz));   // 0 = utara, 90 = timur
        int compass = Math.floorMod((int) Math.round(bearing / 45.0), 8);
        float rel = Mth.wrapDegrees((float) Math.toDegrees(Math.atan2(-dx, dz)) - p.getYRot());   // > 0 = ke kanan
        int arrow = Math.floorMod(Math.round(rel / 45f), 8);
        p.displayClientMessage(Component.translatable("message.shazammod.thanos.signal", ThanosAbilities.stoneName(stone), dist,
                Component.translatable("message.shazammod.pralaya.dir." + DIRS[compass]), ARROWS[arrow])
                .withStyle(s2 -> s2.withColor(stone.rgb)), true);
        ShazamNetwork.playAnim(p, ShazamAnim.TITAN_SIGNAL, new Vec3(s[1] + 0.5, stone.ordinal(), s[2] + 0.5));
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.THANOS_SIGNAL.get(), SoundSource.PLAYERS, 0.9f, 1f);
    }

    // ---------------------------------------------------------------- membangun Kuil Titan

    private static void set(ServerLevel level, int x, int y, int z, BlockState state) {
        level.setBlock(new BlockPos(x, y, z), state, Block.UPDATE_CLIENTS);
    }

    private static int surface(ServerLevel level, int x, int z) {
        return level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
    }

    private static boolean clearable(BlockState s) {
        return !s.isAir() && (s.is(BlockTags.LEAVES) || s.is(BlockTags.LOGS) || (s.canBeReplaced() && s.getFluidState().isEmpty()));
    }

    private static BlockState floor(RandomSource r) {
        float f = r.nextFloat();
        return (f < 0.62f ? Blocks.POLISHED_BLACKSTONE_BRICKS : f < 0.84f ? Blocks.CRACKED_POLISHED_BLACKSTONE_BRICKS
                : f < 0.92f ? Blocks.POLISHED_BLACKSTONE : f < 0.97f ? Blocks.GILDED_BLACKSTONE : Blocks.CRYING_OBSIDIAN)
                .defaultBlockState();
    }

    private static BlockState pillar(RandomSource r) {
        float f = r.nextFloat();
        return (f < 0.55f ? Blocks.DEEPSLATE_BRICKS : f < 0.8f ? Blocks.CRACKED_DEEPSLATE_BRICKS
                : f < 0.93f ? Blocks.DEEPSLATE_TILES : Blocks.CHISELED_DEEPSLATE).defaultBlockState();
    }

    /**
     * Kuil Titan: pelataran bundar batu hitam (pecah di sana-sini, retakan obsidian menangis), enam pilar deepslate patah
     * di lingkaran luar dengan kaca warna batunya di puncak, altar tiga tingkat di tengah dengan peti batu di atasnya
     * (cahaya dari bawah kaca), empat batang ujung (end rod) di sudut altar, kristal kecubung, dua api sinyal, & penjaga.
     */
    private static void build(ServerLevel level, StoneType stone, int cx, int cz) {
        RandomSource r = level.random;
        int y0 = surface(level, cx, cz) - 1;
        boolean wet = !level.getFluidState(new BlockPos(cx, y0, cz)).isEmpty();
        BlockState glass = stone.glass().defaultBlockState();
        for (int dx = -RADIUS - 2; dx <= RADIUS + 2; dx++) {   // bersihkan pohon & tanaman
            for (int dz = -RADIUS - 2; dz <= RADIUS + 2; dz++) {
                if (dx * dx + dz * dz > (RADIUS + 2) * (RADIUS + 2)) {
                    continue;
                }
                for (int y = y0 + 1; y <= y0 + 16; y++) {
                    BlockPos pos = new BlockPos(cx + dx, y, cz + dz);
                    if (clearable(level.getBlockState(pos))) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                    }
                }
            }
        }
        // pelataran (dan fondasinya, supaya nggak melayang di lereng)
        for (int dx = -RADIUS; dx <= RADIUS; dx++) {
            for (int dz = -RADIUS; dz <= RADIUS; dz++) {
                double dd = Math.sqrt(dx * dx + dz * dz);
                if (dd > RADIUS + 0.4) {
                    continue;
                }
                if (dd > RADIUS - 1.2 && r.nextFloat() < 0.35f) {
                    continue;   // tepi yang runtuh
                }
                int x = cx + dx, z = cz + dz;
                for (int y = y0 - 3; y < y0; y++) {
                    if (wet || level.getBlockState(new BlockPos(x, y, z)).canBeReplaced()) {
                        set(level, x, y, z, Blocks.COBBLED_DEEPSLATE.defaultBlockState());
                    }
                }
                set(level, x, y0, z, floor(r));
                for (int y = y0 + 1; y <= y0 + 7; y++) {
                    set(level, x, y, z, Blocks.AIR.defaultBlockState());
                }
            }
        }
        // retakan obsidian menangis yang memancar dari altar
        for (int k = 0; k < 6; k++) {
            double a = k * Math.PI / 3.0 + Math.PI / 6.0;
            for (int s = 3; s <= RADIUS - 2; s++) {
                if (r.nextFloat() < 0.75f) {
                    set(level, cx + (int) Math.round(Math.cos(a) * s), y0, cz + (int) Math.round(Math.sin(a) * s),
                            (r.nextFloat() < 0.7f ? Blocks.CRYING_OBSIDIAN : Blocks.OBSIDIAN).defaultBlockState());
                }
            }
        }
        // enam pilar patah
        for (int k = 0; k < 6; k++) {
            double a = k * Math.PI / 3.0;
            int px = cx + (int) Math.round(Math.cos(a) * (RADIUS - 2.5)), pz = cz + (int) Math.round(Math.sin(a) * (RADIUS - 2.5));
            int height = 4 + r.nextInt(5);
            for (int ox = 0; ox <= 1; ox++) {
                for (int oz = 0; oz <= 1; oz++) {
                    int top = y0 + height - (r.nextFloat() < 0.5f ? r.nextInt(3) : 0);
                    for (int y = y0 + 1; y <= top; y++) {
                        set(level, px + ox, y, pz + oz, pillar(r));
                    }
                }
            }
            set(level, px, y0 + height + 1, pz, glass);
            if (k % 2 == 0) {
                set(level, px + 1, y0 + height + 1, pz + 1, Blocks.SOUL_LANTERN.defaultBlockState());
            }
        }
        // altar tiga tingkat
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                int m = Math.max(Math.abs(dx), Math.abs(dz));
                set(level, cx + dx, y0 + 1, cz + dz, (m == 3 ? Blocks.DEEPSLATE_TILES : Blocks.POLISHED_DEEPSLATE).defaultBlockState());
                if (m <= 2) {
                    set(level, cx + dx, y0 + 2, cz + dz, (m == 2 ? Blocks.POLISHED_BLACKSTONE_BRICKS
                            : Blocks.CHISELED_POLISHED_BLACKSTONE).defaultBlockState());
                }
            }
        }
        for (int[] c : new int[][] {{-2, -2}, {2, -2}, {-2, 2}, {2, 2}}) {   // sudut altar: kaca menyala & batang ujung
            set(level, cx + c[0], y0 + 1, cz + c[1], Blocks.GLOWSTONE.defaultBlockState());
            set(level, cx + c[0], y0 + 2, cz + c[1], glass);
            set(level, cx + c[0], y0 + 3, cz + c[1], Blocks.END_ROD.defaultBlockState());
        }
        set(level, cx, y0 + 1, cz, Blocks.GLOWSTONE.defaultBlockState());
        set(level, cx, y0 + 2, cz, glass);
        Direction face = Direction.Plane.HORIZONTAL.getRandomDirection(r);
        BlockPos chestPos = new BlockPos(cx, y0 + 3, cz);
        level.setBlock(chestPos, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, face), Block.UPDATE_ALL);
        if (level.getBlockEntity(chestPos) instanceof ChestBlockEntity chest) {
            chest.setItem(13, new ItemStack(ThanosRegistry.stone(stone)));
            chest.setItem(r.nextInt(9), new ItemStack(Items.GOLD_INGOT, 3 + r.nextInt(5)));
            chest.setItem(18 + r.nextInt(9), new ItemStack(Items.EMERALD, 2 + r.nextInt(5)));
            chest.setItem(9 + r.nextInt(4), new ItemStack(Items.ENDER_PEARL, 1 + r.nextInt(3)));
            if (r.nextFloat() < 0.55f) {
                chest.setItem(14 + r.nextInt(4), new ItemStack(Items.DIAMOND, 1 + r.nextInt(2)));
            }
        }
        // kristal kecubung & puing
        for (int i = 0; i < 18; i++) {
            double a = r.nextDouble() * Math.PI * 2.0, dd = 4.0 + r.nextDouble() * (RADIUS - 5.0);
            int x = cx + (int) Math.round(Math.cos(a) * dd), z = cz + (int) Math.round(Math.sin(a) * dd);
            BlockPos at = new BlockPos(x, y0 + 1, z);
            if (level.getBlockState(at).isAir()) {
                float f = r.nextFloat();
                level.setBlock(at, (f < 0.35f ? Blocks.AMETHYST_CLUSTER : f < 0.65f ? Blocks.COBBLED_DEEPSLATE
                        : f < 0.85f ? Blocks.BLACKSTONE : Blocks.AMETHYST_BLOCK).defaultBlockState(), Block.UPDATE_CLIENTS);
            }
        }
        // dua api sinyal: asapnya tinggi, kelihatan dari jauh
        for (int k = 0; k < 2; k++) {
            double a = k * Math.PI + Math.PI / 2.0;
            int fx = cx + (int) Math.round(Math.cos(a) * (RADIUS - 4.5)), fz = cz + (int) Math.round(Math.sin(a) * (RADIUS - 4.5));
            set(level, fx, y0 + 1, fz, Blocks.HAY_BLOCK.defaultBlockState());
            set(level, fx, y0 + 2, fz, Blocks.SOUL_CAMPFIRE.defaultBlockState().setValue(CampfireBlock.SIGNAL_FIRE, true));
        }
        // penjaga: batu pertama lebih ringan
        boolean first = stone == StoneType.POWER;
        int vindicators = first ? 2 : 3, evokers = 1, pillagers = first ? 0 : 2;
        for (int i = 0; i < vindicators + evokers + pillagers; i++) {
            EntityType<? extends Mob> type = i < vindicators ? EntityType.VINDICATOR
                    : i < vindicators + evokers ? EntityType.EVOKER : EntityType.PILLAGER;
            Mob mob = type.create(level);
            if (mob == null) {
                continue;
            }
            double a = r.nextDouble() * Math.PI * 2.0, dd = 4.5 + r.nextDouble() * 4.0;
            int mx = cx + (int) Math.round(Math.cos(a) * dd), mz = cz + (int) Math.round(Math.sin(a) * dd);
            mob.moveTo(mx + 0.5, y0 + 1, mz + 0.5, r.nextFloat() * 360f, 0f);
            if (i < vindicators) {
                mob.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_AXE));
                mob.setDropChance(EquipmentSlot.MAINHAND, 0f);
            } else if (i >= vindicators + evokers) {
                mob.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.CROSSBOW));
                mob.setDropChance(EquipmentSlot.MAINHAND, 0f);
            }
            mob.setPersistenceRequired();
            level.addFreshEntity(mob);
        }
    }
}
