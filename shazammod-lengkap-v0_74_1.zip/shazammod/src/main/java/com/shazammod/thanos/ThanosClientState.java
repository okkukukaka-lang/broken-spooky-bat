package com.shazammod.thanos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 0.63 Status Thanos di sisi client: data HUD pemain ini sendiri, dan siapa saja di sekitar yang sedang jadi Thanos
 * (buat aura & cahaya batu). Cuma field biasa tanpa kelas client, jadi aman ikut termuat di server dedicated.
 */
public final class ThanosClientState {
    private ThanosClientState() {}

    public static boolean bound;
    public static boolean transformed;
    public static float energy = ThanosData.MAX_ENERGY;
    public static int stones;
    public static int snapCharge;
    public static int signalStone = -1;
    public static int signalX;
    public static int signalZ;
    public static int rageTicks;
    public static int shieldTicks;
    private static List<Integer> cooldowns = List.of();

    /** Pemain lain (dan diri sendiri) yang sedang jadi Thanos: id entity -> status. */
    public record Other(int stones, boolean rage, boolean shield) {}

    private static final Map<Integer, Other> OTHERS = new HashMap<>();

    public static void update(ThanosNetwork.SyncPayload p) {
        bound = p.bound();
        transformed = p.transformed();
        energy = p.energy();
        stones = p.stones();
        snapCharge = p.snapCharge();
        signalStone = p.signalStone();
        signalX = p.signalX();
        signalZ = p.signalZ();
        rageTicks = p.rageTicks();
        shieldTicks = p.shieldTicks();
        cooldowns = p.cooldowns();
    }

    public static void onState(ThanosNetwork.StatePayload p) {
        if (p.transformed()) {
            OTHERS.put(p.entityId(), new Other(p.stones(), p.rage(), p.shield()));
        } else {
            OTHERS.remove(p.entityId());
        }
    }

    public static Other thanos(int entityId) {
        return OTHERS.get(entityId);
    }

    public static Map<Integer, Other> all() {
        return OTHERS;
    }

    public static int cooldown(int slot) {
        return slot >= 0 && slot < cooldowns.size() ? cooldowns.get(slot) : 0;
    }

    public static void reset() {
        bound = false;
        transformed = false;
        energy = ThanosData.MAX_ENERGY;
        stones = 0;
        snapCharge = 0;
        signalStone = -1;
        rageTicks = 0;
        shieldTicks = 0;
        cooldowns = List.of();
        OTHERS.clear();
    }
}
