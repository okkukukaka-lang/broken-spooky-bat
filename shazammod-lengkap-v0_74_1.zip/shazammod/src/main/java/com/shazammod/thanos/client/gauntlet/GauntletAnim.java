package com.shazammod.thanos.client.gauntlet;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.client.anim.Ease;

/**
 * 0.65 Animasi Infinity Gauntlet 3D: pose jari (kepal, cakar, tunjuk, jentik), cahaya batu yang dikunci ke tick puncak
 * tiap kuasa (ShazamAnim.TITAN_* / INF_*, sama dengan server, ThanosClips, ThanosFx), dan gerak tangan ORANG PERTAMA tiap
 * skill. Murni Java (tanpa kelas Minecraft) supaya bisa diuji di luar game.
 *
 * Gerak orang pertama ditulis di ruang pandang tangan (blok; kamera di 0,0,0 menghadap -Z, +Y atas, +X kanan): H = titik
 * tangan, S = jangkar bahu (di luar layar), U = arah punggung tangan (tempat batu). Lengan dibangun ulang dari ketiganya,
 * jadi pose bawaan Minecraft (tangan kosong) bisa dicampur mulus dengan pose skill.
 */
public final class GauntletAnim {
    private GauntletAnim() {}

    // ------------------------------------------------------------------ pose jari {telunjuk, tengah, manis, kelingking, renggang, ibu jari, tekan}

    static final float[] RELAX = {0.62f, 0.66f, 0.70f, 0.74f, 0.12f, 0.45f, 0f};
    static final float[] FIST = {1f, 1f, 1f, 1f, 0f, 1f, 0f};
    static final float[] OPEN = {0.06f, 0.04f, 0.07f, 0.1f, 0.9f, 0.05f, 0f};
    static final float[] CLAW = {0.42f, 0.4f, 0.44f, 0.48f, 1f, 0.25f, 0f};
    static final float[] POINT = {0f, 0.95f, 1f, 1f, 0.1f, 0.75f, 0f};
    static final float[] SNAP_SET = {0.55f, 0.22f, 0.85f, 0.95f, 0.1f, 0.55f, 1f};
    static final float[] SNAP_HIT = {0.62f, 1f, 0.9f, 0.95f, 0.1f, 0.05f, 0f};
    static final float[] GRIP = {0.45f, 0.45f, 0.48f, 0.5f, 0.6f, 0.4f, 0f};
    /** Ikon barang: kepalan rapat. */
    public static final float[] ITEM = {0.94f, 0.96f, 0.98f, 1f, 0f, 0.92f, 0f};

    // ------------------------------------------------------------------ pose orang pertama (lengan kanan) {H, S, U}

    /** Diam: kepalan Gauntlet tegak di kanan bawah, punggung tangan (mahkota batu) menghadap mata. */
    static final float[] R_IDLE = {0.615f, -0.346f, -0.95f, 0.68f, -1.05f, -0.75f, -0.35f, 0.1f, 0.93f};
    static final float[] R_GUARD = {0.582f, -0.268f, -0.85f, 0.65f, -0.80f, -0.30f, 0.1f, 0.9f, 0.5f};
    static final float[] R_PUNCH = {0.174f, -0.147f, -1.40f, 0.45f, -0.55f, -0.65f, 0.0f, 1.0f, 0.15f};
    static final float[] R_HIGH = {0.411f, 0.27f, -1.10f, 0.60f, -0.75f, -0.80f, 0.05f, 0.1f, 1.0f};
    static final float[] R_UP = {0.392f, 0.404f, -1.05f, 0.60f, -0.60f, -0.85f, 0.0f, 0.05f, 1.0f};
    static final float[] R_SNAP = {0.33f, 0.18f, -1.05f, 0.55f, -0.73f, -0.80f, 0.1f, 0.05f, 1.0f};
    static final float[] R_AIM = {0.233f, 0.044f, -1.25f, 0.55f, -0.70f, -0.75f, 0.0f, 0.4f, 1.0f};
    static final float[] R_CHEST = {0.149f, -0.308f, -0.80f, 0.50f, -0.75f, -0.25f, 0.0f, 0.8f, 0.6f};
    static final float[] R_LOWER = {0.35f, -1.0f, -0.90f, 0.50f, -1.5f, -0.50f, 0.0f, 0.8f, 0.6f};
    static final float[] R_TEMPLE = {0.55f, 0.50f, -0.45f, 0.60f, -0.30f, -0.20f, 0.5f, 0.2f, 0.8f};
    static final float[] R_WIDE = {1.06f, -0.035f, -1.0f, 0.60f, -0.55f, -0.40f, 0.1f, 1.0f, 0.3f};
    static final float[] R_CENTER = {-0.062f, -0.035f, -1.0f, 0.50f, -0.60f, -0.45f, 0.0f, 1.0f, 0.3f};
    /** Turun di luar layar (tangan yang sedang memegang barang lain, sebelum & sesudah skill). */
    static final float[] R_HIDDEN = {0.55f, -1.3f, -0.8f, 0.62f, -1.8f, -0.4f, 0.2f, 0.6f, 0.8f};

    // ------------------------------------------------------------------ jalur keyframe

    /** Keyframe dengan n saluran; tiap key menyalin key sebelumnya, ease = cara bergerak MENUJU key itu (seperti Clip). */
    static final class Track {
        final float len, fadeIn, fadeOut;
        final float[] ticks;
        final Ease[] eases;
        final float[][] vals;
        private final float[] tmp;

        Track(float len, float fadeIn, float fadeOut, float[] ticks, Ease[] eases, float[][] vals) {
            this.len = len;
            this.fadeIn = fadeIn;
            this.fadeOut = fadeOut;
            this.ticks = ticks;
            this.eases = eases;
            this.vals = vals;
            this.tmp = new float[vals[0].length];
        }

        float weight(float t) {
            if (t < 0f || t > len) {
                return 0f;
            }
            float a = fadeIn <= 0f ? 1f : smooth01(t / fadeIn);
            float b = fadeOut <= 0f ? 1f : smooth01((len - t) / fadeOut);
            return Math.min(a, b);
        }

        void sample(float t, float[] out) {
            int n = ticks.length;
            if (t <= ticks[0] || n == 1) {
                System.arraycopy(vals[0], 0, out, 0, out.length);
                return;
            }
            int i = 0;
            while (i + 1 < n && ticks[i + 1] <= t) {
                i++;
            }
            if (i + 1 >= n) {
                System.arraycopy(vals[n - 1], 0, out, 0, out.length);
                return;
            }
            float u = (t - ticks[i]) / Math.max(1.0E-4f, ticks[i + 1] - ticks[i]);
            u = eases[i + 1].apply(Math.max(0f, Math.min(1f, u)));
            float[] a = vals[i], b = vals[i + 1];
            for (int c = 0; c < out.length; c++) {
                out[c] = a[c] + (b[c] - a[c]) * u;
            }
        }

        /** Dihaluskan seperti otot (5 cuplikan dalam 1,6 tick): awal OUT_* nggak menyentak dalam satu frame. */
        void sampleSmooth(float t, float[] out) {
            for (int c = 0; c < out.length; c++) {
                out[c] = 0f;
            }
            for (int j = 0; j < 5; j++) {
                sample(t + (j - 2) * 0.4f, tmp);
                float w = SMOOTH_W[j];
                for (int c = 0; c < out.length; c++) {
                    out[c] += tmp[c] * w;
                }
            }
        }
    }

    private static final float[] SMOOTH_W = {1 / 16f, 4 / 16f, 6 / 16f, 4 / 16f, 1 / 16f};

    static final class TB {
        private final int n;
        private final float len;
        private float fin = 2f, fout = 5f;
        private final List<Float> ticks = new ArrayList<>();
        private final List<Ease> eases = new ArrayList<>();
        private final List<float[]> vals = new ArrayList<>();
        private boolean mirror;

        TB(int n, float len) {
            this.n = n;
            this.len = len;
        }

        TB k(float tick, Ease ease) {
            float[] v = vals.isEmpty() ? new float[n] : vals.get(vals.size() - 1).clone();
            ticks.add(tick);
            eases.add(ease);
            vals.add(v);
            return this;
        }

        TB set(int off, float... v) {
            System.arraycopy(v, 0, vals.get(vals.size() - 1), off, v.length);
            return this;
        }

        /** Pose jari. */
        TB p(float[] pose) {
            return set(0, pose);
        }

        /** Pose orang pertama lengkap {H, S, U}; lengan kiri: dicerminkan otomatis. */
        TB pose(float[] hsu) {
            float[] v = hsu.clone();
            if (mirror) {
                v[0] = -v[0];
                v[3] = -v[3];
                v[6] = -v[6];
            }
            return set(0, v);
        }

        TB h(float x, float y, float z) {
            return set(0, mirror ? -x : x, y, z);
        }

        TB u(float x, float y, float z) {
            return set(6, mirror ? -x : x, y, z);
        }

        TB shake(float a) {
            return set(9, a);
        }

        TB fade(float in, float out) {
            fin = in;
            fout = out;
            return this;
        }

        TB mirrored() {
            mirror = true;
            return this;
        }

        Track build() {
            float[] t = new float[ticks.size()];
            for (int i = 0; i < t.length; i++) {
                t[i] = ticks.get(i);
            }
            return new Track(len, fin, fout, t, eases.toArray(new Ease[0]), vals.toArray(new float[0][]));
        }
    }

    private static TB hand(float len) {
        return new TB(7, len);
    }

    private static TB fp(float len) {
        return new TB(10, len);
    }

    private static final Map<ShazamAnim, Track> HANDS = new EnumMap<>(ShazamAnim.class);
    private static final Map<ShazamAnim, Track> FP_RIGHT = new EnumMap<>(ShazamAnim.class);
    private static final Map<ShazamAnim, Track> FP_LEFT = new EnumMap<>(ShazamAnim.class);

    static {
        registerHands();
        registerFirstPerson();
    }

    // ------------------------------------------------------------------ jari tiap skill

    private static void registerHands() {
        Ease oc = Ease.OUT_CUBIC, io = Ease.IN_OUT_SINE, iq = Ease.IN_QUAD, ob = Ease.OUT_BACK, li = Ease.LINEAR;
        int bb = ShazamAnim.TITAN_BIND_BURST;
        HANDS.put(ShazamAnim.THANOS_BIND, hand(ShazamAnim.TITAN_BIND_TICKS).k(0, oc).p(RELAX).k(22, io).p(OPEN)
                .k(bb - 4, iq).p(CLAW).k(bb, ob).p(FIST).k(ShazamAnim.TITAN_BIND_TICKS, io).p(RELAX).fade(3, 10).build());
        HANDS.put(ShazamAnim.THANOS_TRANSFORM, hand(ShazamAnim.TITAN_MORPH_TICKS).k(0, oc).p(FIST).k(30, li).p(FIST)
                .k(ShazamAnim.TITAN_MORPH_TICKS, io).p(RELAX).fade(2, 8).build());
        HANDS.put(ShazamAnim.THANOS_REVERT, hand(ShazamAnim.TITAN_REVERT_TICKS).k(0, oc).p(FIST)
                .k(ShazamAnim.TITAN_REVERT_TICKS, io).p(RELAX).fade(1, 6).build());
        int ph = ShazamAnim.TITAN_PUNCH_HIT;
        HANDS.put(ShazamAnim.THANOS_PUNCH, hand(ph + 15).k(0, oc).p(FIST).k(ph + 15, io).p(FIST).fade(1, 6).build());
        int nh = ShazamAnim.TITAN_NOVA_HIT;
        HANDS.put(ShazamAnim.THANOS_NOVA, hand(nh + 18).k(0, oc).p(FIST).k(nh + 18, io).p(FIST).fade(1, 6).build());
        int sa = ShazamAnim.TITAN_STEP_AT;
        HANDS.put(ShazamAnim.THANOS_STEP, hand(sa + 12).k(0, oc).p(CLAW).k(sa, ob).p(GRIP).k(sa + 12, io).p(RELAX)
                .fade(1, 5).build());
        int mo = ShazamAnim.TITAN_MOON_OPEN;
        HANDS.put(ShazamAnim.THANOS_MOON, hand(mo + 34).k(0, oc).p(OPEN).k(mo - 2, iq).p(OPEN).k(mo, ob).p(CLAW)
                .k(mo + 8, iq).p(FIST).k(mo + 34, io).p(RELAX).fade(2, 8).build());
        int mh = ShazamAnim.TITAN_MIND_HIT;
        HANDS.put(ShazamAnim.THANOS_MIND, hand(mh + 14).k(0, oc).p(OPEN).k(mh, ob).p(OPEN).set(4, 1.15f)
                .k(mh + 14, io).p(RELAX).fade(1, 6).build());
        int sh = ShazamAnim.TITAN_MINDSTORM_HIT;
        HANDS.put(ShazamAnim.THANOS_MINDSTORM, hand(sh + 16).k(0, oc).p(CLAW).k(sh - 2, iq).p(CLAW).set(0, 0.3f, 0.3f, 0.32f, 0.35f)
                .k(sh, ob).p(OPEN).set(4, 1.2f).k(sh + 16, io).p(RELAX).fade(2, 6).build());
        int wh = ShazamAnim.TITAN_WRAP_HIT;
        HANDS.put(ShazamAnim.THANOS_WRAP, hand(wh + 16).k(0, oc).p(OPEN).k(wh / 2f, io).p(CLAW).k(wh, ob).p(FIST)
                .k(wh + 16, io).p(RELAX).fade(1, 6).build());
        int rh = ShazamAnim.TITAN_REALITY_HIT;
        HANDS.put(ShazamAnim.THANOS_REALITY, hand(rh + 18).k(0, oc).p(GRIP).k(rh, ob).p(OPEN).set(4, 1.2f)
                .k(rh + 18, io).p(RELAX).fade(1, 6).build());
        int ra = ShazamAnim.TITAN_REWIND_AT;
        HANDS.put(ShazamAnim.THANOS_REWIND, hand(ra + 14).k(0, oc).p(POINT).k(ra * 0.9f, li).p(POINT).k(ra, ob).p(OPEN)
                .k(ra + 14, io).p(RELAX).fade(1, 6).build());
        int th = ShazamAnim.TITAN_TIMESTOP_HIT;
        HANDS.put(ShazamAnim.THANOS_TIMESTOP, hand(th + 18).k(0, oc).p(OPEN).k(th - 2, iq).p(CLAW).k(th, ob).p(FIST)
                .k(th + 18, io).p(RELAX).fade(1, 6).build());
        int hh = ShazamAnim.TITAN_HARVEST_HIT, ht = ShazamAnim.TITAN_HARVEST_TICKS;
        HANDS.put(ShazamAnim.THANOS_HARVEST, hand(hh + ht + 10).k(0, oc).p(CLAW).k(hh, ob).p(CLAW).set(4, 1.2f)
                .k(hh + ht - 4, li).p(CLAW).set(0, 0.55f, 0.55f, 0.58f, 0.6f).k(hh + ht, ob).p(FIST)
                .k(hh + ht + 10, io).p(RELAX).fade(1, 6).build());
        int sd = ShazamAnim.TITAN_SHIELD_HIT;
        HANDS.put(ShazamAnim.THANOS_SHIELD, hand(sd + 16).k(0, oc).p(FIST).k(sd - 1, iq).p(FIST).k(sd, ob).p(OPEN)
                .k(sd + 16, io).p(RELAX).fade(1, 6).build());
        int sn = ShazamAnim.TITAN_SNAP_AT;
        HANDS.put(ShazamAnim.THANOS_SNAP, hand(sn + 24).k(0, oc).p(RELAX).k(12, io).p(SNAP_SET).k(sn - 1, li).p(SNAP_SET)
                .k(sn, ob).p(SNAP_HIT).k(sn + 10, li).p(SNAP_HIT).k(sn + 24, io).p(RELAX).fade(2, 10).build());
        int gh = ShazamAnim.TITAN_RAGE_HIT;
        HANDS.put(ShazamAnim.THANOS_RAGE, hand(gh + 22).k(0, oc).p(FIST).k(gh - 1, iq).p(FIST).k(gh, ob).p(CLAW)
                .set(4, 1.2f).k(gh + 22, io).p(RELAX).fade(2, 8).build());
        int ps = ShazamAnim.TITAN_SPIN_HIT, ta = ShazamAnim.TITAN_THROW_AT, lj = ShazamAnim.TITAN_LEAP_JUMP;
        HANDS.put(ShazamAnim.THANOS_SPIN, hand(ps + 14).k(0, oc).p(FIST).k(ps + 14, io).p(FIST).fade(1, 5).build());
        HANDS.put(ShazamAnim.THANOS_THROW, hand(ta + 10).k(0, oc).p(FIST).k(ta, ob).p(OPEN).k(ta + 10, io).p(RELAX)
                .fade(1, 5).build());
        HANDS.put(ShazamAnim.THANOS_LEAP, hand(lj + 16).k(0, oc).p(FIST).k(lj + 16, li).p(FIST).fade(1, 8).build());
        int us = ShazamAnim.INF_SURGE_HIT;
        HANDS.put(ShazamAnim.INFINITY_SURGE, hand(us + 20).k(0, oc).p(FIST).k(us - 1, iq).p(FIST).k(us, ob).p(OPEN)
                .set(4, 1.2f).k(us + 20, io).p(RELAX).fade(2, 8).build());
        int ct = ShazamAnim.INF_CRATER_THROW;
        HANDS.put(ShazamAnim.INFINITY_CRATER, hand(ct + 16).k(0, oc).p(GRIP).k(ct - 1, iq).p(GRIP).k(ct, ob).p(OPEN)
                .k(ct + 16, io).p(RELAX).fade(1, 6).build());
        int po = ShazamAnim.INF_PORTAL_OPEN, ps2 = ShazamAnim.INF_PORTAL_STEP;
        HANDS.put(ShazamAnim.INFINITY_PORTAL, hand(ps2 + 10).k(0, oc).p(POINT).k(po * 0.9f, li).p(POINT).k(po, ob).p(OPEN)
                .k(ps2 + 10, io).p(RELAX).fade(1, 6).build());
        int rw = ShazamAnim.INF_REWRITE_HIT;
        HANDS.put(ShazamAnim.INFINITY_REWRITE, hand(rw + 24).k(0, oc).p(RELAX).k(rw - 1, iq).p(GRIP).k(rw, ob).p(OPEN)
                .set(4, 1.2f).k(rw + 24, io).p(RELAX).fade(2, 8).build());
        int rr = ShazamAnim.INF_RAISE_HIT;
        HANDS.put(ShazamAnim.INFINITY_RAISE, hand(rr + 22).k(0, oc).p(OPEN).k(rr - 1, iq).p(OPEN).k(rr, ob).p(CLAW)
                .k(rr + 22, io).p(RELAX).fade(2, 8).build());
    }

    // ------------------------------------------------------------------ orang pertama tiap skill

    private static void registerFirstPerson() {
        Ease oc = Ease.OUT_CUBIC, io = Ease.IN_OUT_SINE, iq = Ease.IN_QUAD, oq = Ease.OUT_QUAD, ob = Ease.OUT_BACK,
                li = Ease.LINEAR;

        // Sumpah Titan: Gauntlet diangkat pelan di depan mata, punggung tangan (batu) menghadap kamera, gemetar makin
        // kuat, lalu di TITAN_BIND_BURST dikepal & dihentak ke atas
        int bb = ShazamAnim.TITAN_BIND_BURST, bt = ShazamAnim.TITAN_BIND_TICKS;
        FP_RIGHT.put(ShazamAnim.THANOS_BIND, fp(bt).k(0, oc).pose(R_GUARD).k(22, io).pose(R_HIGH).shake(0.002f)
                .k(60, io).pose(R_SNAP).h(0.30f, 0.22f, -1.0f).shake(0.006f)
                .k(bb - 4, iq).h(0.30f, 0.26f, -0.98f).shake(0.013f)
                .k(bb, ob).pose(R_UP).shake(0.008f)
                .k(bb + 12, io).pose(R_HIGH).shake(0.002f)
                .k(bt, io).pose(R_IDLE).shake(0f).fade(4, 14).build());

        // Berubah: kepalan ditarik ke dada mengumpulkan tenaga, lalu dihentak ke atas: batu menyala satu per satu
        int mb = ShazamAnim.TITAN_MORPH_BURST, mt = ShazamAnim.TITAN_MORPH_TICKS;
        FP_RIGHT.put(ShazamAnim.THANOS_TRANSFORM, fp(mt).k(0, oc).pose(R_CHEST).k(12, io).pose(R_CHEST)
                .h(0.15f, -0.36f, -0.75f).shake(0.006f).k(mb - 2, iq).h(0.15f, -0.38f, -0.73f).shake(0.013f)
                .k(mb, ob).pose(R_HIGH).shake(0.006f).k(mb + 8, li).shake(0.002f).k(mt, io).pose(R_IDLE).shake(0f)
                .fade(2, 8).build());

        FP_RIGHT.put(ShazamAnim.THANOS_REVERT, fp(ShazamAnim.TITAN_REVERT_TICKS).k(0, oc).pose(R_CHEST)
                .k(6, io).pose(R_GUARD).shake(0.003f).k(ShazamAnim.TITAN_REVERT_TICKS, io).pose(R_HIDDEN).shake(0f)
                .fade(1, 6).build());

        // Tinju Daya: kepalan ditarik ke kanan bawah, lalu dihantamkan lurus ke tengah layar
        int ph = ShazamAnim.TITAN_PUNCH_HIT;
        FP_RIGHT.put(ShazamAnim.THANOS_PUNCH, fp(ph + 15).k(0, oc).pose(R_GUARD).k(ph - 1, iq).h(0.62f, -0.33f, -0.78f)
                .shake(0.004f).k(ph, ob).pose(R_PUNCH).shake(0.003f).k(ph + 5, li).shake(0f).k(ph + 15, io).pose(R_IDLE)
                .fade(1, 6).build());

        // Ledakan Daya: kepalan diangkat tinggi, lalu dihantam ke tanah (lepas ke bawah layar)
        int nh = ShazamAnim.TITAN_NOVA_HIT;
        FP_RIGHT.put(ShazamAnim.THANOS_NOVA, fp(nh + 18).k(0, oc).pose(R_HIGH).k(nh - 4, oq).pose(R_UP).shake(0.008f)
                .k(nh, ob).pose(R_LOWER).shake(0.012f).k(nh + 8, li).shake(0.003f).k(nh + 18, io).pose(R_IDLE).shake(0f)
                .fade(1, 6).build());

        // Langkah Kosmik: cakar merobek ruang dari kanan ke tengah, lalu ditarik
        int sa = ShazamAnim.TITAN_STEP_AT;
        FP_RIGHT.put(ShazamAnim.THANOS_STEP, fp(sa + 12).k(0, oc).pose(R_AIM).h(0.55f, 0.05f, -1.15f)
                .k(sa - 1, iq).pose(R_CENTER).shake(0.004f).k(sa, ob).pose(R_GUARD).h(0.4f, -0.4f, -0.8f).shake(0f)
                .k(sa + 12, io).pose(R_IDLE).fade(1, 5).build());

        // Hujan Bulan: tangan meraih langit, mencengkeram (langit robek), lalu menyeret turun sekuat tenaga
        int mo = ShazamAnim.TITAN_MOON_OPEN;
        FP_RIGHT.put(ShazamAnim.THANOS_MOON, fp(mo + 34).k(0, oc).pose(R_HIGH).k(mo - 2, iq).pose(R_UP)
                .h(0.38f, 0.5f, -1.05f).shake(0.006f).k(mo, ob).h(0.38f, 0.46f, -1.05f).shake(0.009f)
                .k(mo + 8, iq).pose(R_GUARD).h(0.45f, -0.45f, -0.8f).shake(0.013f).k(mo + 24, li).shake(0.008f)
                .k(mo + 34, io).pose(R_IDLE).shake(0f).fade(2, 8).build());

        // Belenggu Pikiran: telapak terbuka diarahkan ke depan, lalu didorong saat sinar dilepas
        int mh = ShazamAnim.TITAN_MIND_HIT;
        FP_RIGHT.put(ShazamAnim.THANOS_MIND, fp(mh + 14).k(0, oc).pose(R_AIM).k(mh - 1, iq).shake(0.006f)
                .k(mh, ob).pose(R_AIM).h(0.2f, 0.03f, -1.38f).shake(0.002f).k(mh + 14, io).pose(R_IDLE).shake(0f)
                .fade(1, 6).build());

        // Badai Pikiran: kedua tangan ke pelipis (keluar layar atas), lalu dihentak terbuka ke samping
        int sh = ShazamAnim.TITAN_MINDSTORM_HIT;
        for (int side = 0; side < 2; side++) {
            TB b = fp(sh + 16);
            if (side == 1) {
                b.mirrored();
            }
            b.k(0, oc).pose(R_TEMPLE).k(sh - 2, iq).pose(R_TEMPLE).shake(0.01f).k(sh, ob).pose(R_WIDE).shake(0.004f)
                    .k(sh + 16, io).pose(side == 0 ? R_IDLE : R_HIDDEN).shake(0f).fade(2, 6);
            (side == 0 ? FP_RIGHT : FP_LEFT).put(ShazamAnim.THANOS_MINDSTORM, b.build());
        }

        // Kenyataan Palsu: pergelangan diputar ke kanan lalu ke kiri (memelintir kenyataan), lalu dikepal
        int wh = ShazamAnim.TITAN_WRAP_HIT;
        FP_RIGHT.put(ShazamAnim.THANOS_WRAP, fp(wh + 16).k(0, oc).pose(R_AIM).u(0.85f, 0.5f, 0.3f)
                .k(wh / 2f, io).u(-0.7f, 0.45f, 0.55f).shake(0.004f).k(wh, ob).pose(R_AIM).h(0.21f, 0.0f, -1.3f)
                .u(0f, 0.6f, 1f).shake(0.009f).k(wh + 6, li).shake(0.003f).k(wh + 16, io).pose(R_IDLE).shake(0f)
                .fade(1, 6).build());

        // Badai Realitas: tangan terbuka menyapu dari tengah ke kanan
        int rh = ShazamAnim.TITAN_REALITY_HIT;
        FP_RIGHT.put(ShazamAnim.THANOS_REALITY, fp(rh + 18).k(0, oc).pose(R_CENTER).k(rh - 2, iq).shake(0.005f)
                .k(rh, ob).pose(R_WIDE).shake(0.003f).k(rh + 8, io).h(0.95f, -0.12f, -1.0f).shake(0f)
                .k(rh + 18, io).pose(R_IDLE).fade(1, 6).build());

        // Putar Balik: telunjuk menggambar lingkaran jam berlawanan arah jarum, lalu telapak didorong
        int ra = ShazamAnim.TITAN_REWIND_AT;
        float[] circle = {0.52f, 0f, -1.2f, 0.55f, -0.7f, -0.7f, 0f, 0.3f, 1f};
        FP_RIGHT.put(ShazamAnim.THANOS_REWIND, fp(ra + 14).k(0, li).pose(circle)
                .k(ra * 0.3f, li).h(0.3f, 0.22f, -1.2f).k(ra * 0.6f, li).h(0.08f, 0f, -1.2f)
                .k(ra * 0.9f, li).h(0.3f, -0.22f, -1.2f).shake(0.003f)
                .k(ra, ob).pose(R_AIM).h(0.25f, -0.02f, -1.3f).shake(0.004f).k(ra + 14, io).pose(R_IDLE).shake(0f)
                .fade(1, 6).build());

        // Henti Waktu: tangan terbuka diangkat, lalu digenggam kuat: waktu berhenti
        int th = ShazamAnim.TITAN_TIMESTOP_HIT;
        FP_RIGHT.put(ShazamAnim.THANOS_TIMESTOP, fp(th + 18).k(0, oc).pose(R_HIGH).k(th - 2, iq).pose(R_UP)
                .shake(0.007f).k(th, ob).pose(R_UP).h(0.39f, 0.34f, -1.05f).shake(0.011f).k(th + 8, li).shake(0.003f)
                .k(th + 18, io).pose(R_IDLE).shake(0f).fade(1, 6).build());

        // Panen Jiwa: cakar terbuka ke depan, gemetar makin kuat selama jiwa ditarik, lalu direnggut ke dada
        int hh = ShazamAnim.TITAN_HARVEST_HIT, ht = ShazamAnim.TITAN_HARVEST_TICKS;
        FP_RIGHT.put(ShazamAnim.THANOS_HARVEST, fp(hh + ht + 10).k(0, oc).pose(R_AIM).k(hh - 1, iq).shake(0.004f)
                .k(hh, ob).pose(R_AIM).h(0.2f, -0.02f, -1.35f).shake(0.008f).k(hh + ht - 4, li).shake(0.016f)
                .k(hh + ht, ob).pose(R_CHEST).shake(0.004f).k(hh + ht + 10, io).pose(R_IDLE).shake(0f)
                .fade(1, 6).build());

        // Perisai Jiwa: kepalan di dada, lalu kedua lengan terbuka
        int sd = ShazamAnim.TITAN_SHIELD_HIT;
        for (int side = 0; side < 2; side++) {
            TB b = fp(sd + 16);
            if (side == 1) {
                b.mirrored();
            }
            b.k(0, oc).pose(R_CHEST).k(sd - 1, iq).shake(0.008f).k(sd, ob).pose(R_WIDE).shake(0.002f)
                    .k(sd + 16, io).pose(side == 0 ? R_IDLE : R_HIDDEN).shake(0f).fade(1, 6);
            (side == 0 ? FP_RIGHT : FP_LEFT).put(ShazamAnim.THANOS_SHIELD, b.build());
        }

        // JENTIKAN: Gauntlet diangkat di depan mata, keenam batu menyala satu per satu (makin gemetar), lalu dijentikkan:
        // semua getaran berhenti seketika (hening)
        int sn = ShazamAnim.TITAN_SNAP_AT;
        FP_RIGHT.put(ShazamAnim.THANOS_SNAP, fp(sn + 24).k(0, oc).pose(R_HIGH).k(12, io).pose(R_SNAP).shake(0.002f)
                .k(40, io).h(0.32f, 0.2f, -1.02f).shake(0.005f).k(sn - 3, iq).h(0.32f, 0.21f, -1.0f).shake(0.01f)
                .k(sn, ob).h(0.33f, 0.16f, -1.05f).shake(0f).k(sn + 8, li).h(0.33f, 0.17f, -1.05f)
                .k(sn + 24, io).pose(R_IDLE).fade(2, 10).build());

        // Murka Titan: membungkuk menahan amarah (kepalan rendah gemetar), lalu kedua lengan terhentak terbuka
        int gh = ShazamAnim.TITAN_RAGE_HIT;
        for (int side = 0; side < 2; side++) {
            TB b = fp(gh + 22);
            if (side == 1) {
                b.mirrored();
            }
            b.k(0, oc).pose(R_CHEST).h(0.35f, -0.5f, -0.8f).shake(0.006f).k(gh - 2, iq).shake(0.013f)
                    .k(gh, ob).pose(R_WIDE).shake(0.008f).k(gh + 12, li).shake(0.004f)
                    .k(gh + 22, io).pose(side == 0 ? R_IDLE : R_HIDDEN).shake(0f).fade(2, 8);
            (side == 0 ? FP_RIGHT : FP_LEFT).put(ShazamAnim.THANOS_RAGE, b.build());
        }

        // Daya Tak Terbatas: kedua kepalan di depan dada menahan tenaga, lalu dihentak ke samping-bawah
        int us = ShazamAnim.INF_SURGE_HIT;
        for (int side = 0; side < 2; side++) {
            TB b = fp(us + 20);
            if (side == 1) {
                b.mirrored();
            }
            b.k(0, oc).pose(R_CHEST).k(us - 2, iq).h(0.15f, -0.36f, -0.75f).shake(0.013f)
                    .k(us, ob).pose(R_WIDE).h(0.95f, -0.5f, -0.95f).shake(0.006f).k(us + 8, li).shake(0.002f)
                    .k(us + 20, io).pose(side == 0 ? R_IDLE : R_HIDDEN).shake(0f).fade(2, 8);
            (side == 0 ? FP_RIGHT : FP_LEFT).put(ShazamAnim.INFINITY_SURGE, b.build());
        }

        // Ledakan Kawah: bola daya digenggam tinggi, lalu dilontarkan ke depan-bawah
        int ct = ShazamAnim.INF_CRATER_THROW;
        FP_RIGHT.put(ShazamAnim.INFINITY_CRATER, fp(ct + 16).k(0, oc).pose(R_HIGH).k(ct - 2, iq).pose(R_UP)
                .shake(0.012f).k(ct, ob).pose(R_PUNCH).h(0.2f, -0.22f, -1.35f).u(0f, 0.6f, 1f).shake(0.004f)
                .k(ct + 6, li).shake(0f).k(ct + 16, io).pose(R_IDLE).fade(1, 6).build());

        // Gerbang Kosmik: telunjuk melukis lingkaran gerbang, lalu telapak didorong: gerbang terbuka
        int po = ShazamAnim.INF_PORTAL_OPEN, pst = ShazamAnim.INF_PORTAL_STEP;
        FP_RIGHT.put(ShazamAnim.INFINITY_PORTAL, fp(pst + 10).k(0, li).pose(circle)
                .k(po * 0.33f, li).h(0.3f, 0.22f, -1.2f).k(po * 0.66f, li).h(0.08f, 0f, -1.2f)
                .k(po, ob).pose(R_AIM).h(0.22f, -0.02f, -1.3f).shake(0.003f).k(pst, li).shake(0f)
                .k(pst + 10, io).pose(R_IDLE).fade(1, 6).build());

        // Tulis Ulang Dunia: kedua tangan dikatupkan di dada, lalu disapu terbuka lebar
        int rw = ShazamAnim.INF_REWRITE_HIT;
        for (int side = 0; side < 2; side++) {
            TB b = fp(rw + 24);
            if (side == 1) {
                b.mirrored();
            }
            b.k(0, oc).pose(R_CHEST).h(0.1f, -0.25f, -0.85f).k(rw - 2, iq).shake(0.008f)
                    .k(rw, ob).pose(R_WIDE).h(1.0f, 0.1f, -1.0f).shake(0.005f).k(rw + 16, li).shake(0.002f)
                    .k(rw + 24, io).pose(side == 0 ? R_IDLE : R_HIDDEN).shake(0f).fade(2, 8);
            (side == 0 ? FP_RIGHT : FP_LEFT).put(ShazamAnim.INFINITY_REWRITE, b.build());
        }

        // Bangkitkan Undead: telapak menghadap tanah, lalu diangkat seperti menarik yang mati keluar dari bumi
        int rr = ShazamAnim.INF_RAISE_HIT;
        for (int side = 0; side < 2; side++) {
            TB b = fp(rr + 22);
            if (side == 1) {
                b.mirrored();
            }
            b.k(0, oc).pose(R_GUARD).h(0.4f, -0.6f, -1.0f).u(0f, 1f, 0.2f).k(rr - 2, iq).shake(0.009f)
                    .k(rr, ob).pose(R_HIGH).shake(0.006f).k(rr + 14, li).shake(0.002f)
                    .k(rr + 22, io).pose(side == 0 ? R_IDLE : R_HIDDEN).shake(0f).fade(2, 8);
            (side == 0 ? FP_RIGHT : FP_LEFT).put(ShazamAnim.INFINITY_RAISE, b.build());
        }
    }

    // ------------------------------------------------------------------ jari & cahaya untuk satu gambar

    private static final float[] HP = new float[7];
    private static final float[] HS = new float[7];

    /** Pose jari: santai (sedikit bergerak sendiri) + skill yang sedang jalan + kepalan saat memukul biasa. */
    public static void hand(GauntletGeo.State st, ShazamAnim anim, float t, float age, float attack) {
        System.arraycopy(RELAX, 0, HP, 0, 7);
        for (int i = 0; i < 4; i++) {
            HP[i] += 0.035f * (float) Math.sin(age * 0.07f + i * 0.9f);
        }
        Track tr = anim == null ? null : HANDS.get(anim);
        if (tr != null) {
            float w = tr.weight(t);
            if (w > 0f) {
                tr.sampleSmooth(t, HS);
                for (int c = 0; c < 7; c++) {
                    HP[c] += (HS[c] - HP[c]) * w;
                }
            }
        }
        if (attack > 0f) {
            float k = (float) Math.sin(Math.min(1f, attack) * Math.PI);
            for (int c = 0; c < 7; c++) {
                HP[c] += (FIST[c] - HP[c]) * k;
            }
        }
        st.setHand(HP);
    }

    /**
     * Cahaya batu, inti, alur tenaga. owned = batu tercatat; transformed = wujud Thanos; rage = Murka Titan; shield =
     * Perisai Jiwa aktif; anim & t = skill yang sedang jalan (ShazamPoses) dan umurnya dalam tick.
     */
    public static void glow(GauntletGeo.State st, int owned, boolean transformed, boolean rage, boolean shield,
                            ShazamAnim anim, float t, float age) {
        st.owned = owned;
        for (int k = 0; k < 6; k++) {
            boolean has = (owned & (1 << k)) != 0;
            st.glow[k] = !has ? 0f : transformed ? 0.36f + 0.1f * (float) Math.sin(age * 0.11f + k * 1.3f)
                    : 0.12f + 0.04f * (float) Math.sin(age * 0.08f + k * 1.3f);
        }
        st.core = transformed ? 0.3f + 0.08f * (float) Math.sin(age * 0.09f) : 0.06f;
        st.coreRgb = 0xC8B0FF;
        st.line = transformed ? 0.22f + 0.06f * (float) Math.sin(age * 0.13f) : 0f;
        st.lineRgb = 0x8A5CFF;
        st.flash = 0f;
        st.flashRgb = 0xFFF2D8;
        if (rage) {
            st.line = 0.75f + 0.25f * (float) Math.sin(age * 0.55f);
            st.lineRgb = 0xFF4020;
            st.core = Math.max(st.core, 0.6f);
            st.coreRgb = 0xFF8060;
        }
        if (shield) {
            st.glow[5] = Math.max(st.glow[5], 1.05f + 0.15f * (float) Math.sin(age * 0.3f));
        }
        if (anim == null || t < 0f) {
            return;
        }
        switch (anim) {
            case THANOS_SNAP -> snapGlow(st, t);
            case THANOS_TRANSFORM -> transformGlow(st, owned, t);
            case THANOS_BIND -> bindGlow(st, owned, t);
            default -> {
                int k = stoneOf(anim), hit = hitOf(anim), len = lenOf(anim);
                if (len <= 0 || t > len) {
                    return;
                }
                if (k >= 0) {
                    flare(st, k, t, hit, len, anim == ShazamAnim.THANOS_HARVEST);
                }
                if (anim == ShazamAnim.INFINITY_SURGE) {
                    float tail = smooth01((len - t) / 8f), charge = clamp01(t / Math.max(1f, hit));
                    for (int j = 0; j < 6; j++) {
                        if ((owned & (1 << j)) != 0) {
                            st.glow[j] = Math.max(st.glow[j], (0.6f + 0.6f * charge) * tail);
                        }
                    }
                }
                if (anim == ShazamAnim.THANOS_RAGE) {
                    float tail = smooth01((len - t) / 8f);
                    float g = t < hit ? 0.5f + 0.5f * clamp01(t / hit) : 0.8f + 0.8f * (float) Math.exp(-(t - hit) / 5f);
                    st.line = Math.max(st.line, g * tail);
                    st.lineRgb = 0xFF4020;
                    st.coreRgb = 0xFF8060;
                    st.core = Math.max(st.core, g * tail);
                }
            }
        }
    }

    /** Batu yang sedang dipakai: naik menjelang tick puncak, berkobar di puncak, lalu meredup. */
    private static void flare(GauntletGeo.State st, int k, float t, int hit, int len, boolean hold) {
        float g;
        if (t < hit) {
            float u = t / Math.max(1f, hit);
            g = 0.55f + 0.6f * u * u;
        } else {
            g = 0.75f + 1.25f * (float) Math.exp(-(t - hit) / 5f);
            if (hold && t < hit + ShazamAnim.TITAN_HARVEST_TICKS) {
                g = Math.max(g, 1.1f + 0.2f * (float) Math.sin(t * 0.8f));
            }
        }
        float tail = smooth01((len - t) / 8f);
        st.glow[k] = Math.max(st.glow[k], st.glow[k] + (g - st.glow[k]) * tail);
        st.core = Math.max(st.core, (0.25f + 0.45f * g) * tail);
        st.coreRgb = mix(0xC8B0FF, GauntletGeo.STONE_RGB[k], 0.6f);
        st.line = Math.max(st.line, (0.35f + 0.45f * g) * tail);
        st.lineRgb = GauntletGeo.STONE_RGB[k];
    }

    /** Jentikan: batu menyala satu per satu tiap TITAN_SNAP_STAGGER tick, lalu kilatan putih-emas di TITAN_SNAP_AT. */
    private static void snapGlow(GauntletGeo.State st, float t) {
        int at = ShazamAnim.TITAN_SNAP_AT, stag = ShazamAnim.TITAN_SNAP_STAGGER, len = at + 24;
        if (t > len) {
            return;
        }
        float tail = smooth01((len - t) / 14f);
        for (int k = 0; k < 6; k++) {
            float on = t - k * stag;
            if (on < 0f) {
                continue;
            }
            float g = 1.0f + 0.9f * (float) Math.exp(-on / 4f) + 0.3f * clamp01((t - 40f) / 20f)
                    + 0.06f * (float) Math.sin(t * 1.7f + k);
            st.glow[k] = Math.max(st.glow[k], st.glow[k] + (g - st.glow[k]) * tail);
        }
        float charge = clamp01(t / at);
        st.core = Math.max(st.core, (0.4f + 1.0f * charge * charge) * tail);
        st.coreRgb = 0xFFF0D0;
        st.line = Math.max(st.line, (0.3f + 0.7f * charge) * tail);
        st.lineRgb = 0xFFC861;
        if (t >= at) {
            float f = (float) Math.exp(-(t - at) / 4.5f);
            st.flash = f;
            st.flashRgb = 0xFFF2D8;
            for (int k = 0; k < 6; k++) {
                st.glow[k] = Math.max(st.glow[k], 2.0f * f);
            }
            st.core = Math.max(st.core, 2.2f * f);
        }
    }

    /** Berubah: batu yang dimiliki menyala satu per satu (4 + 3 tick tiap batu, sama dengan ThanosFx), ledakan kosmik. */
    private static void transformGlow(GauntletGeo.State st, int owned, float t) {
        int burst = ShazamAnim.TITAN_MORPH_BURST, len = ShazamAnim.TITAN_MORPH_TICKS;
        if (t > len) {
            return;
        }
        float tail = smooth01((len - t) / 8f);
        int j = 0;
        for (int k = 0; k < 6; k++) {
            if ((owned & (1 << k)) == 0) {
                continue;
            }
            float on = t - (4 + j * 3);
            j++;
            if (on >= 0f) {
                float g = 0.9f + 0.8f * (float) Math.exp(-on / 3f);
                st.glow[k] = Math.max(st.glow[k], st.glow[k] + (g - st.glow[k]) * tail);
            }
        }
        float charge = clamp01(t / burst);
        st.core = Math.max(st.core, (0.3f + 0.9f * charge) * tail);
        st.coreRgb = 0xE6D8FF;
        st.line = Math.max(st.line, (0.3f + 0.6f * charge) * tail);
        if (t >= burst) {
            float f = (float) Math.exp(-(t - burst) / 4f);
            st.flash = 0.85f * f;
            st.flashRgb = 0xE6D8FF;
            st.core = Math.max(st.core, 2.0f * f);
        }
    }

    /** Sumpah Titan: inti & alur makin terang selama energi kosmik terkumpul, kilatan saat menyatu. */
    private static void bindGlow(GauntletGeo.State st, int owned, float t) {
        int burst = ShazamAnim.TITAN_BIND_BURST, len = ShazamAnim.TITAN_BIND_TICKS;
        if (t > len) {
            return;
        }
        float tail = smooth01((len - t) / 12f), charge = clamp01(t / burst);
        st.core = Math.max(st.core, (0.2f + 1.4f * charge * charge) * tail);
        st.coreRgb = 0xE6D8FF;
        st.line = Math.max(st.line, (0.15f + 0.85f * charge) * tail);
        st.lineRgb = 0x8A5CFF;
        for (int k = 0; k < 6; k++) {
            if ((owned & (1 << k)) != 0) {
                st.glow[k] = Math.max(st.glow[k], (0.3f + 0.9f * charge) * tail);
            }
        }
        if (t >= burst) {
            float f = (float) Math.exp(-(t - burst) / 5f);
            st.flash = 0.9f * f;
            st.flashRgb = 0xE6D8FF;
        }
    }

    static int stoneOf(ShazamAnim a) {
        return switch (a) {
            case THANOS_PUNCH, THANOS_NOVA, INFINITY_SURGE, INFINITY_CRATER -> 0;
            case THANOS_STEP, THANOS_MOON, INFINITY_PORTAL -> 1;
            case THANOS_MIND, THANOS_MINDSTORM -> 2;
            case THANOS_WRAP, THANOS_REALITY, INFINITY_REWRITE -> 3;
            case THANOS_REWIND, THANOS_TIMESTOP -> 4;
            case THANOS_HARVEST, THANOS_SHIELD, INFINITY_RAISE -> 5;
            default -> -1;
        };
    }

    static int hitOf(ShazamAnim a) {
        return switch (a) {
            case THANOS_PUNCH -> ShazamAnim.TITAN_PUNCH_HIT;
            case THANOS_NOVA -> ShazamAnim.TITAN_NOVA_HIT;
            case THANOS_STEP -> ShazamAnim.TITAN_STEP_AT;
            case THANOS_MOON -> ShazamAnim.TITAN_MOON_OPEN;
            case THANOS_MIND -> ShazamAnim.TITAN_MIND_HIT;
            case THANOS_MINDSTORM -> ShazamAnim.TITAN_MINDSTORM_HIT;
            case THANOS_WRAP -> ShazamAnim.TITAN_WRAP_HIT;
            case THANOS_REALITY -> ShazamAnim.TITAN_REALITY_HIT;
            case THANOS_REWIND -> ShazamAnim.TITAN_REWIND_AT;
            case THANOS_TIMESTOP -> ShazamAnim.TITAN_TIMESTOP_HIT;
            case THANOS_HARVEST -> ShazamAnim.TITAN_HARVEST_HIT;
            case THANOS_SHIELD -> ShazamAnim.TITAN_SHIELD_HIT;
            case THANOS_RAGE -> ShazamAnim.TITAN_RAGE_HIT;
            case INFINITY_SURGE -> ShazamAnim.INF_SURGE_HIT;
            case INFINITY_CRATER -> ShazamAnim.INF_CRATER_THROW;
            case INFINITY_PORTAL -> ShazamAnim.INF_PORTAL_OPEN;
            case INFINITY_REWRITE -> ShazamAnim.INF_REWRITE_HIT;
            case INFINITY_RAISE -> ShazamAnim.INF_RAISE_HIT;
            default -> -1;
        };
    }

    /** Panjang gerak (tick), sama dengan klip ThanosClips. */
    static int lenOf(ShazamAnim a) {
        Track tr = HANDS.get(a);
        return tr == null ? -1 : (int) tr.len;
    }

    // ------------------------------------------------------------------ orang pertama

    /** Pose lengan orang pertama: H titik tangan, S jangkar bahu, U arah punggung tangan (ruang pandang, blok). */
    public static final class Fp {
        public float hx, hy, hz, sx, sy, sz, ux, uy, uz, shake;

        void set(float[] v) {
            hx = v[0];
            hy = v[1];
            hz = v[2];
            sx = v[3];
            sy = v[4];
            sz = v[5];
            ux = v[6];
            uy = v[7];
            uz = v[8];
            shake = v.length > 9 ? v[9] : 0f;
        }
    }

    private static final float[] FV = new float[10];

    /** Bobot (0..1) gerak orang pertama skill ini untuk lengan kanan/kiri; pose diisi ke out. 0 = nggak ada. */
    public static float firstPerson(ShazamAnim anim, float t, boolean left, Fp out) {
        Track tr = anim == null ? null : (left ? FP_LEFT : FP_RIGHT).get(anim);
        if (tr == null) {
            return 0f;
        }
        float w = tr.weight(t);
        if (w <= 0f) {
            return 0f;
        }
        tr.sampleSmooth(t, FV);
        out.set(FV);
        return w;
    }

    /** Bobot gerak orang pertama skill ini (0 = nggak ada / sudah selesai). */
    public static float skillWeight(ShazamAnim anim, float t, boolean left) {
        Track tr = anim == null ? null : (left ? FP_LEFT : FP_RIGHT).get(anim);
        return tr == null ? 0f : tr.weight(t);
    }

    private static final Fp BASE_T = new Fp(), SKILL_T = new Fp(), REST0 = new Fp();

    /**
     * Pose akhir satu lengan orang pertama: dasar (lengan Gauntlet = R_IDLE, lengan biasa = bawaan Minecraft, hidden =
     * di bawah layar) + ayunan memukul & ganti barang bawaan + gerak skill + gemetar. Mengembalikan bobot skill.
     */
    public static float firstPersonPose(ShazamAnim anim, float t, float age, boolean left, boolean slim,
                                        boolean gauntletArm, boolean hidden, float swing, float equip, Fp out) {
        if (hidden) {
            hidden(left, BASE_T);
        } else if (gauntletArm) {
            idle(swing, equip, left, slim, BASE_T);
        } else {
            rest(swing, equip, left, slim, BASE_T);
        }
        float w = firstPerson(anim, t, left, SKILL_T);
        blend(BASE_T, w > 0f ? SKILL_T : BASE_T, Math.max(0f, w), out);
        shake(out, age + (left ? 17f : 0f));
        return w;
    }

    /** Diam (R_IDLE) + gerak bawaan Minecraft (selisih pose bawaan dengan & tanpa ayunan / ganti barang). */
    public static void idle(float swing, float equip, boolean left, boolean slim, Fp out) {
        rest(swing, equip, left, slim, out);
        rest(0f, 0f, left, slim, REST0);
        float f = left ? -1f : 1f;
        out.hx = f * R_IDLE[0] + (out.hx - REST0.hx);
        out.hy = R_IDLE[1] + (out.hy - REST0.hy);
        out.hz = R_IDLE[2] + (out.hz - REST0.hz);
        out.sx = f * R_IDLE[3] + (out.sx - REST0.sx);
        out.sy = R_IDLE[4] + (out.sy - REST0.sy);
        out.sz = R_IDLE[5] + (out.sz - REST0.sz);
        out.ux = f * R_IDLE[6] + (out.ux - REST0.ux);
        out.uy = R_IDLE[7] + (out.uy - REST0.uy);
        out.uz = R_IDLE[8] + (out.uz - REST0.uz);
        out.shake = 0f;
    }

    /** Skill ini menggerakkan lengan kiri juga (dua tangan)? */
    public static boolean twoHanded(ShazamAnim anim) {
        return anim != null && FP_LEFT.containsKey(anim);
    }

    /** Pose "tersembunyi" di bawah layar (tangan yang memegang barang lain). */
    public static void hidden(boolean left, Fp out) {
        out.set(R_HIDDEN);
        if (left) {
            out.hx = -out.hx;
            out.sx = -out.sx;
            out.ux = -out.ux;
        }
    }

    /** x titik acuan tangan (tengah kubus lengan) di ruang lengan, piksel. */
    static float handX(boolean left, boolean slim) {
        float c = slim ? -0.5f : -1f;
        return left ? -c : c;
    }

    /**
     * Pose bawaan Minecraft untuk tangan kosong, sama persis dengan ItemInHandRenderer.renderPlayerArm (ayunan memukul &
     * turun-naik saat ganti barang ikut), ditambah letak & putaran bawaan ModelPart lengan di tangan orang pertama.
     */
    public static void rest(float swing, float equip, boolean left, boolean slim, Fp out) {
        float f = left ? -1f : 1f;
        Xf x = XF.reset();
        float f1 = (float) Math.sqrt(Math.max(0f, swing));
        float f2 = -0.3f * (float) Math.sin(f1 * Math.PI);
        float f3 = 0.4f * (float) Math.sin(f1 * Math.PI * 2.0);
        float f4 = -0.4f * (float) Math.sin(swing * Math.PI);
        x.translate(f * (f2 + 0.64000005f), f3 - 0.6f + equip * -0.6f, f4 - 0.71999997f);
        x.rot(1, f * 45f);
        float f5 = (float) Math.sin(swing * swing * Math.PI);
        float f6 = (float) Math.sin(f1 * Math.PI);
        x.rot(1, f * f6 * 70f);
        x.rot(2, f * f5 * -20f);
        x.translate(f * -1f, 3.6f, 3.5f);
        x.rot(2, f * 120f);
        x.rot(0, 200f);
        x.rot(1, f * -135f);
        x.translate(f * 5.6f, 0f, 0f);
        // ModelPart lengan: pivot (-5, 2, 0) & ayunan napas di umur 0 (zRot = 0,1 rad)
        x.translate(f * -5f / 16f, 2f / 16f, 0f);
        x.rot(2, (float) Math.toDegrees(f * 0.1f));
        float cx = handX(left, slim) / 16f;
        x.point(cx, 9f / 16f, 0f, V3);
        out.hx = V3[0];
        out.hy = V3[1];
        out.hz = V3[2];
        x.point(cx, -2f / 16f, 0f, V3);
        out.sx = V3[0];
        out.sy = V3[1];
        out.sz = V3[2];
        x.dir(-f, 0f, 0f, V3);
        out.ux = V3[0];
        out.uy = V3[1];
        out.uz = V3[2];
        out.shake = 0f;
    }

    public static void blend(Fp a, Fp b, float w, Fp out) {
        out.hx = a.hx + (b.hx - a.hx) * w;
        out.hy = a.hy + (b.hy - a.hy) * w;
        out.hz = a.hz + (b.hz - a.hz) * w;
        out.sx = a.sx + (b.sx - a.sx) * w;
        out.sy = a.sy + (b.sy - a.sy) * w;
        out.sz = a.sz + (b.sz - a.sz) * w;
        out.ux = a.ux + (b.ux - a.ux) * w;
        out.uy = a.uy + (b.uy - a.uy) * w;
        out.uz = a.uz + (b.uz - a.uz) * w;
        out.shake = b.shake * w;
    }

    /** Gemetar menahan tenaga: geser titik tangan sedikit (blok). */
    public static void shake(Fp p, float age) {
        if (p.shake <= 0f) {
            return;
        }
        p.hx += p.shake * noise(age, 0.7f);
        p.hy += p.shake * noise(age, 2.3f);
        p.hz += p.shake * 0.5f * noise(age, 4.1f);
    }

    private static float noise(float age, float seed) {
        return (float) (Math.sin(age * 2.3 + seed) * 0.5 + Math.sin(age * 3.7 + seed * 1.9) * 0.3
                + Math.sin(age * 6.1 + seed * 3.1) * 0.2);
    }

    /**
     * Bangun matriks ruang lengan dari pose: tq = {tx, ty, tz, qx, qy, qz, qw}. Sumbu lengan: +Y lokal = dari bahu ke tangan,
     * punggung tangan = -X lokal (kanan) / +X lokal (kiri).
     */
    public static float[] frame(Fp p, boolean left, boolean slim, float[] tq) {
        float dx = p.hx - p.sx, dy = p.hy - p.sy, dz = p.hz - p.sz;
        float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dl < 1.0E-5f) {
            dx = 0f;
            dy = 1f;
            dz = 0f;
        } else {
            dx /= dl;
            dy /= dl;
            dz /= dl;
        }
        float ud = p.ux * dx + p.uy * dy + p.uz * dz;
        float ox = p.ux - ud * dx, oy = p.uy - ud * dy, oz = p.uz - ud * dz;
        float ol = (float) Math.sqrt(ox * ox + oy * oy + oz * oz);
        if (ol < 1.0E-4f) {   // U searah lengan: pilih tegak lurus apa saja
            ox = -dz;
            oy = 0f;
            oz = dx;
            ol = (float) Math.sqrt(ox * ox + oz * oz);
            if (ol < 1.0E-4f) {
                ox = 0f;
                oz = 1f;
                ol = 1f;
            }
        }
        ox /= ol;
        oy /= ol;
        oz /= ol;
        float s = left ? 1f : -1f;
        float xx = s * ox, xy = s * oy, xz = s * oz;                       // X lokal
        float zx = xy * dz - xz * dy, zy = xz * dx - xx * dz, zz = xx * dy - xy * dx;   // Z = X x Y
        // matriks rotasi kolom (X, Y=D, Z) -> kuaternion
        float m00 = xx, m10 = xy, m20 = xz, m01 = dx, m11 = dy, m21 = dz, m02 = zx, m12 = zy, m22 = zz;
        float qx, qy, qz, qw;
        float tr = m00 + m11 + m22;
        if (tr > 0f) {
            float q = (float) Math.sqrt(tr + 1f) * 2f;
            qw = 0.25f * q;
            qx = (m21 - m12) / q;
            qy = (m02 - m20) / q;
            qz = (m10 - m01) / q;
        } else if (m00 > m11 && m00 > m22) {
            float q = (float) Math.sqrt(1f + m00 - m11 - m22) * 2f;
            qw = (m21 - m12) / q;
            qx = 0.25f * q;
            qy = (m01 + m10) / q;
            qz = (m02 + m20) / q;
        } else if (m11 > m22) {
            float q = (float) Math.sqrt(1f + m11 - m00 - m22) * 2f;
            qw = (m02 - m20) / q;
            qx = (m01 + m10) / q;
            qy = 0.25f * q;
            qz = (m12 + m21) / q;
        } else {
            float q = (float) Math.sqrt(1f + m22 - m00 - m11) * 2f;
            qw = (m10 - m01) / q;
            qx = (m02 + m20) / q;
            qy = (m12 + m21) / q;
            qz = 0.25f * q;
        }
        float hlx = handX(left, slim) / 16f, hly = 9f / 16f;
        tq[0] = p.hx - (m00 * hlx + m01 * hly);
        tq[1] = p.hy - (m10 * hlx + m11 * hly);
        tq[2] = p.hz - (m20 * hlx + m21 * hly);
        tq[3] = qx;
        tq[4] = qy;
        tq[5] = qz;
        tq[6] = qw;
        return tq;
    }

    /** Titik di ruang lengan (piksel) -> ruang pandang (blok), memakai hasil frame(). */
    public static void apply(float[] tq, float px, float py, float pz, float[] out3) {
        float x = px / 16f, y = py / 16f, z = pz / 16f;
        float qx = tq[3], qy = tq[4], qz = tq[5], qw = tq[6];
        // v' = v + 2w(q x v) + 2 q x (q x v)
        float cx = qy * z - qz * y, cy = qz * x - qx * z, cz = qx * y - qy * x;
        float ccx = qy * cz - qz * cy, ccy = qz * cx - qx * cz, ccz = qx * cy - qy * cx;
        out3[0] = tq[0] + x + 2f * (qw * cx + ccx);
        out3[1] = tq[1] + y + 2f * (qw * cy + ccy);
        out3[2] = tq[2] + z + 2f * (qw * cz + ccz);
    }

    // ------------------------------------------------------------------ geser + putar (pengganti PoseStack, murni)

    private static final float[] V3 = new float[3];
    private static final Xf XF = new Xf();

    /** Translasi + kuaternion; urutan operasi sama dengan PoseStack (translate lalu mulPose dari kiri ke kanan). */
    static final class Xf {
        float tx, ty, tz, qx, qy, qz, qw = 1f;

        Xf reset() {
            tx = ty = tz = 0f;
            qx = qy = qz = 0f;
            qw = 1f;
            return this;
        }

        void translate(float x, float y, float z) {
            rotate(x, y, z, V3T);
            tx += V3T[0];
            ty += V3T[1];
            tz += V3T[2];
        }

        /** axis 0 = X, 1 = Y, 2 = Z (derajat, kaidah tangan kanan seperti Axis.XP/YP/ZP). */
        void rot(int axis, float deg) {
            float h = (float) Math.toRadians(deg) * 0.5f, s = (float) Math.sin(h), c = (float) Math.cos(h);
            float bx = axis == 0 ? s : 0f, by = axis == 1 ? s : 0f, bz = axis == 2 ? s : 0f, bw = c;
            float nx = qw * bx + qx * bw + qy * bz - qz * by;
            float ny = qw * by - qx * bz + qy * bw + qz * bx;
            float nz = qw * bz + qx * by - qy * bx + qz * bw;
            float nw = qw * bw - qx * bx - qy * by - qz * bz;
            qx = nx;
            qy = ny;
            qz = nz;
            qw = nw;
        }

        void rotate(float x, float y, float z, float[] o) {
            float cx = qy * z - qz * y, cy = qz * x - qx * z, cz = qx * y - qy * x;
            float ccx = qy * cz - qz * cy, ccy = qz * cx - qx * cz, ccz = qx * cy - qy * cx;
            o[0] = x + 2f * (qw * cx + ccx);
            o[1] = y + 2f * (qw * cy + ccy);
            o[2] = z + 2f * (qw * cz + ccz);
        }

        void point(float x, float y, float z, float[] o) {
            rotate(x, y, z, o);
            o[0] += tx;
            o[1] += ty;
            o[2] += tz;
        }

        void dir(float x, float y, float z, float[] o) {
            rotate(x, y, z, o);
        }
    }

    private static final float[] V3T = new float[3];

    // ------------------------------------------------------------------ alat bantu

    static float smooth01(float v) {
        v = clamp01(v);
        return v * v * (3f - 2f * v);
    }

    static float clamp01(float v) {
        return v < 0f ? 0f : Math.min(v, 1f);
    }

    static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return (r << 16) | (g << 8) | bl;
    }
}
