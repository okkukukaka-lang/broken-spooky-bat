package com.shazammod.thanos;

import java.util.ArrayList;
import java.util.List;

import com.shazammod.ShazamMod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * 0.63 Paket Thanos. Tombol Z X C V B N R M J G memakai paket juara yang sudah ada (ShazamNetwork.handleAction ->
 * ThanosAbilities.handleSharedKey); di sini: tombol U, status HUD pemain sendiri, dan status Thanos yang dilihat pemain
 * lain (aura, cahaya Gauntlet, Murka Titan, Perisai Jiwa).
 */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ThanosNetwork {
    private ThanosNetwork() {}

    public static final int ACTION_TRANSFORM = 0;

    /** Client -> server: tombol U. */
    public record ActionPayload(int action) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<ActionPayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("thanos_action"));

        public static final StreamCodec<ByteBuf, ActionPayload> STREAM_CODEC =
                ByteBufCodecs.VAR_INT.map(ActionPayload::new, ActionPayload::action);

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> client: data HUD pemain itu sendiri. */
    public record SyncPayload(boolean bound, boolean transformed, float energy, int stones, int snapCharge, int signalStone,
                              int signalX, int signalZ, int rageTicks, int shieldTicks, List<Integer> cooldowns)
            implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<SyncPayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("thanos_sync"));

        public static final StreamCodec<ByteBuf, SyncPayload> STREAM_CODEC = StreamCodec.of(
                (buf, p) -> {
                    ByteBufCodecs.BOOL.encode(buf, p.bound());
                    ByteBufCodecs.BOOL.encode(buf, p.transformed());
                    ByteBufCodecs.FLOAT.encode(buf, p.energy());
                    ByteBufCodecs.VAR_INT.encode(buf, p.stones());
                    ByteBufCodecs.VAR_INT.encode(buf, p.snapCharge());
                    ByteBufCodecs.VAR_INT.encode(buf, p.signalStone() + 1);
                    ByteBufCodecs.INT.encode(buf, p.signalX());
                    ByteBufCodecs.INT.encode(buf, p.signalZ());
                    ByteBufCodecs.VAR_INT.encode(buf, p.rageTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.shieldTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.cooldowns().size());
                    for (int c : p.cooldowns()) {
                        ByteBufCodecs.VAR_INT.encode(buf, c);
                    }
                },
                buf -> {
                    boolean bound = ByteBufCodecs.BOOL.decode(buf);
                    boolean transformed = ByteBufCodecs.BOOL.decode(buf);
                    float energy = ByteBufCodecs.FLOAT.decode(buf);
                    int stones = ByteBufCodecs.VAR_INT.decode(buf);
                    int snapCharge = ByteBufCodecs.VAR_INT.decode(buf);
                    int signalStone = ByteBufCodecs.VAR_INT.decode(buf) - 1;
                    int signalX = ByteBufCodecs.INT.decode(buf);
                    int signalZ = ByteBufCodecs.INT.decode(buf);
                    int rage = ByteBufCodecs.VAR_INT.decode(buf);
                    int shield = ByteBufCodecs.VAR_INT.decode(buf);
                    int n = Math.min(ByteBufCodecs.VAR_INT.decode(buf), 64);
                    List<Integer> cooldowns = new ArrayList<>(n);
                    for (int i = 0; i < n; i++) {
                        cooldowns.add(ByteBufCodecs.VAR_INT.decode(buf));
                    }
                    return new SyncPayload(bound, transformed, energy, stones, snapCharge, signalStone, signalX, signalZ,
                            rage, shield, cooldowns);
                });

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> pemain di sekitar: siapa yang sedang jadi Thanos (buat aura & cahaya batu di Gauntlet). */
    public record StatePayload(int entityId, boolean transformed, int stones, boolean rage, boolean shield)
            implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<StatePayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("thanos_state"));

        public static final StreamCodec<ByteBuf, StatePayload> STREAM_CODEC = StreamCodec.of(
                (buf, p) -> {
                    ByteBufCodecs.VAR_INT.encode(buf, p.entityId());
                    ByteBufCodecs.BOOL.encode(buf, p.transformed());
                    ByteBufCodecs.VAR_INT.encode(buf, p.stones());
                    ByteBufCodecs.BOOL.encode(buf, p.rage());
                    ByteBufCodecs.BOOL.encode(buf, p.shield());
                },
                buf -> new StatePayload(ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.BOOL.decode(buf),
                        ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.BOOL.decode(buf), ByteBufCodecs.BOOL.decode(buf)));

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("2");
        registrar.playToServer(ActionPayload.TYPE, ActionPayload.STREAM_CODEC, ThanosNetwork::handleAction);
        registrar.playToClient(SyncPayload.TYPE, SyncPayload.STREAM_CODEC, ThanosNetwork::handleSync);
        registrar.playToClient(StatePayload.TYPE, StatePayload.STREAM_CODEC, ThanosNetwork::handleState);
    }

    private static void handleAction(ActionPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player && payload.action() == ACTION_TRANSFORM) {
                ThanosAbilities.toggleTransform(player);
            }
        });
    }

    private static void handleSync(SyncPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ThanosClientState.update(payload));
    }

    private static void handleState(StatePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ThanosClientState.onState(payload));
    }

    public static void sync(ServerPlayer player) {
        ThanosData d = ThanosAbilities.data(player);
        int[] signal = ThanosSanctum.tracked(player);
        List<Integer> cooldowns = new ArrayList<>(ThanosData.SLOTS);
        for (int c : d.cooldowns) {
            cooldowns.add(c);
        }
        PacketDistributor.sendToPlayer(player, new SyncPayload(d.bound, d.transformed, d.energy, d.stones, d.snapCharge,
                signal == null ? -1 : signal[0], signal == null ? 0 : signal[1], signal == null ? 0 : signal[2],
                d.rageTicks, d.shieldTicks, cooldowns));
    }

    private static StatePayload state(ServerPlayer player) {
        ThanosData d = ThanosAbilities.data(player);
        return new StatePayload(player.getId(), d.transformed, d.stones, d.rageTicks > 0, d.shieldTicks > 0);
    }

    /** Status Thanos pemain ini ke dirinya sendiri & semua yang melihatnya. */
    public static void broadcastState(ServerPlayer player) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, state(player));
    }

    /** Pemain baru melihat pemain ini (masuk jangkauan): kirim statusnya. */
    public static void sendStateTo(ServerPlayer thanos, ServerPlayer viewer) {
        PacketDistributor.sendToPlayer(viewer, state(thanos));
    }
}
