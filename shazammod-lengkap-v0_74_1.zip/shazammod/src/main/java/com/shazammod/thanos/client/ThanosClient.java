package com.shazammod.thanos.client;

import org.lwjgl.glfw.GLFW;

import com.shazammod.ShazamMod;
import com.shazammod.client.fx.ThanosFx;
import com.shazammod.thanos.ThanosClientState;
import com.shazammod.thanos.ThanosNetwork;
import com.shazammod.thanos.ThanosRegistry;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 0.63 Khusus client: tombol U (Wujud Thanos), pedang terlempar, HUD, dan tick efek ThanosFx. Tombol lain (G Z X C V B N R M J)
 * memakai tombol juara yang sudah ada di ShazamClient.
 */
public final class ThanosClient {
    private ThanosClient() {}

    public static final KeyMapping TRANSFORM = new KeyMapping("key.shazammod.thanos", GLFW.GLFW_KEY_U, "key.categories.shazammod");

    @EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModEvents {
        private ModEvents() {}

        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(TRANSFORM);
        }

        @SubscribeEvent
        public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ThanosRegistry.THROWN_BLADE.get(), context -> new ThrownItemRenderer<>(context, 1.5f, true));
        }

        @SubscribeEvent
        public static void registerHud(RegisterGuiLayersEvent event) {
            event.registerAbove(VanillaGuiLayers.HOTBAR, ShazamMod.id("thanos_hud"), ThanosHud::render);
        }
    }

    @EventBusSubscriber(modid = ShazamMod.MODID, value = Dist.CLIENT)
    public static final class GameEvents {
        private GameEvents() {}

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) {
                return;
            }
            ThanosFx.tick(mc.level);   // aura & cahaya batu di Gauntlet setiap Thanos yang terlihat
            com.shazammod.client.fx.InfinityFx.tick(mc.level);   // 0.64 petir Daya Tak Terbatas, langit zona tulis ulang
            while (TRANSFORM.consumeClick()) {
                PacketDistributor.sendToServer(new ThanosNetwork.ActionPayload(ThanosNetwork.ACTION_TRANSFORM));
            }
        }

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
            ThanosClientState.reset();
        }
    }
}
