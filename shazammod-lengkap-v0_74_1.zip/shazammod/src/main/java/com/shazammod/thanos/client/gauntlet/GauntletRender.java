package com.shazammod.thanos.client.gauntlet;

import org.joml.Quaternionf;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamMod;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.thanos.ThanosClientState;
import com.shazammod.thanos.ThanosRegistry;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderHandEvent;

/**
 * 0.65 Menggambar Infinity Gauntlet 3D (GauntletGeo) di tiga tempat:
 *
 *   dipakai di lengan   GauntletLayer: lengan kanan selama wujud Thanos (dan Sumpah Titan), atau lengan yang memegang
 *                       Gauntlet dalam wujud manusia. Ikut semua gerak badan ThanosClips, jari & batu ikut skill.
 *   orang pertama       RenderHandEvent: lengan Gauntlet digambar sendiri (kulit asli + Gauntlet) dengan pose bawaan
 *                       Minecraft (ayunan & ganti barang tetap jalan), dan tiap skill punya gerak tangan sendiri
 *                       (GauntletAnim). Skill dua tangan ikut menggerakkan lengan kiri yang kosong.
 *   barang              GauntletItemRenderer: ikon 3D di inventori, di tanah, di bingkai; di tangan pemain nggak
 *                       digambar (sudah dipakai di lengan).
 */
public final class GauntletRender {
    private GauntletRender() {}

    public static final ResourceLocation TEXTURE = ShazamMod.id("textures/entity/thanos/infinity_gauntlet.png");

    private static final GauntletGeo GEO = new GauntletGeo();
    private static final GauntletGeo.State ST = new GauntletGeo.State();
    private static final McSink SINK = new McSink();

    /** Sedang menggambar pemain (RenderPlayerEvent Pre..Post): Gauntlet yang dipegangnya digambar di lengan saja. */
    static boolean renderingPlayer;

    private static final GauntletAnim.Fp POSE = new GauntletAnim.Fp();
    private static final float[] TQ = new float[7];
    private static final float[] P3 = new float[3];
    // tangan orang pertama terakhir (ruang pandang), buat efek yang keluar dari tangan
    private static final float[] FP_CROWN = new float[3];
    private static long fpTime;
    private static boolean fpLeft;

    /** Kirim sisi GauntletGeo ke VertexConsumer; sx = -1 untuk lengan kiri (dicerminkan, urutan titik dibalik). */
    static final class McSink implements GauntletGeo.Sink {
        VertexConsumer vc;
        PoseStack.Pose pose;
        int light;
        int overlay;
        float sx = 1f;

        @Override
        public void quad(float[] p, float[] uv, float nx, float ny, float nz, int rgb) {
            int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
            if (sx < 0f) {
                for (int k = 3; k >= 0; k--) {
                    vertex(p, uv, k, nx, ny, nz, r, g, b);
                }
            } else {
                for (int k = 0; k < 4; k++) {
                    vertex(p, uv, k, nx, ny, nz, r, g, b);
                }
            }
        }

        private void vertex(float[] p, float[] uv, int k, float nx, float ny, float nz, int r, int g, int b) {
            vc.addVertex(pose, p[k * 3] * sx / 16f, p[k * 3 + 1] / 16f, p[k * 3 + 2] / 16f)
                    .setColor(r, g, b, 255)
                    .setUv(uv[k * 2], uv[k * 2 + 1])
                    .setOverlay(overlay)
                    .setLight(light)
                    .setNormal(pose, nx * sx, ny, nz);
        }
    }

    /** Gambar Gauntlet; ps sudah di ruang lengan (sesudah translateAndRotate lengan). */
    static void draw(PoseStack ps, MultiBufferSource buffers, int light, int overlay, boolean left, GauntletGeo.State st) {
        McSink s = SINK;
        s.pose = ps.last();
        s.sx = left ? -1f : 1f;
        s.light = light;
        s.overlay = overlay;
        s.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        GEO.solid(st, s);
        s.vc = buffers.getBuffer(RenderType.eyes(TEXTURE));
        s.light = LightTexture.FULL_BRIGHT;
        s.overlay = OverlayTexture.NO_OVERLAY;
        GEO.glow(st, s);
        s.vc = null;
        s.pose = null;
    }

    // ------------------------------------------------------------------ siapa memakai di lengan mana

    static boolean isThanos(AbstractClientPlayer p) {
        return p == Minecraft.getInstance().player ? ThanosClientState.transformed : ThanosClientState.thanos(p.getId()) != null;
    }

    /** Lengan yang memakai Gauntlet sekarang, atau null. */
    public static HumanoidArm wornArm(AbstractClientPlayer p) {
        if (isThanos(p)) {
            return HumanoidArm.RIGHT;   // tangan kuasa batu (sama dengan ThanosClips & ThanosFx)
        }
        if (ShazamPoses.currentAnim(p) == ShazamAnim.THANOS_BIND
                && ShazamPoses.animTime(p, 0f) <= ShazamAnim.TITAN_BIND_TICKS) {
            return HumanoidArm.RIGHT;   // Sumpah Titan: Gauntlet diangkat dengan tangan kanan
        }
        Item g = ThanosRegistry.GAUNTLET.get();
        if (p.getMainHandItem().is(g)) {
            return p.getMainArm();
        }
        if (p.getOffhandItem().is(g)) {
            return p.getMainArm().getOpposite();
        }
        return null;
    }

    /** Pose jari & cahaya batu pemain ini sekarang. */
    static GauntletGeo.State state(AbstractClientPlayer p, float pt) {
        GauntletGeo.State st = ST;
        st.slim = p.getSkin().model() == PlayerSkin.Model.SLIM;
        st.inflate = 0.45f;
        boolean self = p == Minecraft.getInstance().player;
        ThanosClientState.Other o = ThanosClientState.thanos(p.getId());
        boolean transformed = self ? ThanosClientState.transformed : o != null;
        int owned = self ? ThanosClientState.stones : o != null ? o.stones() : 0;
        boolean rage = self ? ThanosClientState.rageTicks > 0 : o != null && o.rage();
        boolean shield = self ? ThanosClientState.shieldTicks > 0 : o != null && o.shield();
        ShazamAnim anim = ShazamPoses.currentAnim(p);
        float t = ShazamPoses.animTime(p, pt);
        float age = p.tickCount + pt;
        GauntletAnim.hand(st, anim, t, age, p.getAttackAnim(pt));
        GauntletAnim.glow(st, owned, transformed, rage, shield, anim, t, age);
        return st;
    }

    // ------------------------------------------------------------------ dipakai di lengan (orang ketiga)

    static void renderWorn(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p,
                           PlayerModel<AbstractClientPlayer> model, float pt) {
        if (p.isInvisible()) {
            return;
        }
        HumanoidArm arm = wornArm(p);
        if (arm == null) {
            return;
        }
        boolean left = arm == HumanoidArm.LEFT;
        ModelPart part = left ? model.leftArm : model.rightArm;
        if (!part.visible) {
            return;
        }
        GauntletGeo.State st = state(p, pt);
        if (!p.getItemBySlot(EquipmentSlot.CHEST).isEmpty()) {
            st.inflate = 1.15f;   // di atas lengan zirah dada
        }
        ps.pushPose();
        try {
            part.translateAndRotate(ps);
            draw(ps, buffers, light, LivingEntityRenderer.getOverlayCoords(p, 0f), left, st);
        } finally {
            ps.popPose();
        }
    }

    // ------------------------------------------------------------------ orang pertama

    static void renderHand(RenderHandEvent e) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null) {
            return;
        }
        HumanoidArm arm = e.getHand() == InteractionHand.MAIN_HAND ? p.getMainArm() : p.getMainArm().getOpposite();
        boolean left = arm == HumanoidArm.LEFT;
        ItemStack stack = e.getItemStack();
        Item gauntlet = ThanosRegistry.GAUNTLET.get();
        HumanoidArm worn = wornArm(p);
        float pt = mc.getTimer().getGameTimeDeltaPartialTick(true);
        ShazamAnim anim = ShazamPoses.currentAnim(p);
        float t = ShazamPoses.animTime(p, pt);
        boolean slim = p.getSkin().model() == PlayerSkin.Model.SLIM;
        boolean wearing = worn == arm;
        boolean hidden;
        float w;
        if (wearing) {
            w = GauntletAnim.skillWeight(anim, t, left);
            boolean free = stack.isEmpty() || stack.is(gauntlet);
            if (!free && w <= 0f) {
                return;   // memegang barang lain & nggak sedang skill: biarkan bawaan
            }
            hidden = !free;   // barangnya disembunyikan selama skill, lengan Gauntlet naik dari bawah layar
        } else {
            if (worn != null && stack.is(gauntlet)) {
                e.setCanceled(true);   // Gauntlet sudah dipakai di lengan kanan (wujud Thanos): jangan digambar dobel
                return;
            }
            if (worn == null || !stack.isEmpty() || !GauntletAnim.twoHanded(anim)) {
                return;
            }
            w = GauntletAnim.skillWeight(anim, t, left);
            if (w <= 0f) {
                return;
            }
            hidden = e.getHand() != InteractionHand.MAIN_HAND;   // tangan kedua yang kosong biasanya nggak terlihat
        }
        e.setCanceled(true);
        if (p.isInvisible()) {
            return;
        }
        float wPose = GauntletAnim.firstPersonPose(anim, t, p.tickCount + pt, left, slim, wearing, hidden,
                e.getSwingProgress(), e.getEquipProgress(), POSE);
        GauntletAnim.frame(POSE, left, slim, TQ);
        PoseStack ps = e.getPoseStack();
        MultiBufferSource buffers = e.getMultiBufferSource();
        int light = e.getPackedLight();
        ps.pushPose();
        try {
            ps.translate(TQ[0], TQ[1], TQ[2]);
            ps.mulPose(new Quaternionf(TQ[3], TQ[4], TQ[5], TQ[6]));
            skinArm(ps, buffers, light, p, left, wearing || wPose > 0.01f);
            if (wearing) {
                GauntletGeo.State st = state(p, pt);
                draw(ps, buffers, light, OverlayTexture.NO_OVERLAY, left, st);
                GauntletGeo.crownPoint(st, P3);
                GauntletAnim.apply(TQ, left ? -P3[0] : P3[0], P3[1], P3[2], FP_CROWN);
                fpLeft = left;
                fpTime = System.nanoTime();
            }
        } finally {
            ps.popPose();
        }
    }

    /**
     * Lengan kulit asli pemain di pose sekarang (sama dengan PlayerRenderer.renderHand, tapi letaknya dari kita). extend =
     * sambungan lengan ke arah bahu supaya ujung potongan lengan nggak terlihat saat tangan diangkat tinggi.
     */
    private static void skinArm(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, boolean left,
                                boolean extend) {
        if (!(Minecraft.getInstance().getEntityRenderDispatcher().getRenderer(p) instanceof PlayerRenderer renderer)) {
            return;
        }
        PlayerModel<AbstractClientPlayer> model = renderer.getModel();
        ModelPart arm = left ? model.leftArm : model.rightArm;
        ModelPart sleeve = left ? model.leftSleeve : model.rightSleeve;
        float[] a = save(arm), s = save(sleeve);
        boolean av = arm.visible, sv = sleeve.visible;
        try {
            zero(arm);
            zero(sleeve);
            arm.visible = true;
            sleeve.visible = p.isModelPartShown(left ? PlayerModelPart.LEFT_SLEEVE : PlayerModelPart.RIGHT_SLEEVE);
            ResourceLocation skin = p.getSkin().texture();
            VertexConsumer solid = buffers.getBuffer(RenderType.entitySolid(skin));
            arm.render(ps, solid, light, OverlayTexture.NO_OVERLAY);
            if (extend) {
                ps.pushPose();
                ps.translate(0f, -12f / 16f, 0f);
                arm.render(ps, solid, light, OverlayTexture.NO_OVERLAY);
                ps.popPose();
            }
            if (sleeve.visible) {
                VertexConsumer layer = buffers.getBuffer(RenderType.entityTranslucent(skin));
                sleeve.render(ps, layer, light, OverlayTexture.NO_OVERLAY);
                if (extend) {
                    ps.pushPose();
                    ps.translate(0f, -12f / 16f, 0f);
                    sleeve.render(ps, layer, light, OverlayTexture.NO_OVERLAY);
                    ps.popPose();
                }
            }
        } finally {
            load(arm, a);
            load(sleeve, s);
            arm.visible = av;
            sleeve.visible = sv;
        }
    }

    private static float[] save(ModelPart m) {
        return new float[] {m.x, m.y, m.z, m.xRot, m.yRot, m.zRot};
    }

    private static void load(ModelPart m, float[] v) {
        m.x = v[0];
        m.y = v[1];
        m.z = v[2];
        m.xRot = v[3];
        m.yRot = v[4];
        m.zRot = v[5];
    }

    private static void zero(ModelPart m) {
        m.x = 0f;
        m.y = 0f;
        m.z = 0f;
        m.xRot = 0f;
        m.yRot = 0f;
        m.zRot = 0f;
    }

    /**
     * Mahkota batu Gauntlet orang pertama di dunia (buat efek yang keluar dari tangan), atau null kalau Gauntlet orang
     * pertama nggak sedang digambar untuk tangan ini. Ruang pandang tangan memakai FOV 70: digeser ke FOV dunia.
     */
    public static Vec3 firstPersonHand(AbstractClientPlayer p, boolean right, float pt) {
        if (System.nanoTime() - fpTime > 250_000_000L || fpLeft == right) {
            return null;
        }
        Minecraft mc = Minecraft.getInstance();
        Vec3 eye = p.getEyePosition(pt);
        Vec3 look = p.getViewVector(pt);
        Vec3 side = look.cross(new Vec3(0, 1, 0));
        side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
        Vec3 up = side.cross(look);
        double k = Math.tan(Math.toRadians(mc.options.fov().get()) * 0.5) / Math.tan(Math.toRadians(35.0));
        return eye.add(side.scale(FP_CROWN[0] * k)).add(up.scale(FP_CROWN[1] * k)).add(look.scale(-FP_CROWN[2]));
    }

    // ------------------------------------------------------------------ barang

    static void renderItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buffers, int light,
                           int overlay) {
        boolean thirdHand = ctx == ItemDisplayContext.THIRD_PERSON_LEFT_HAND || ctx == ItemDisplayContext.THIRD_PERSON_RIGHT_HAND;
        if (thirdHand && renderingPlayer) {
            return;   // pemainnya memakai Gauntlet di lengan (GauntletLayer)
        }
        GauntletGeo.State st = ST;
        st.slim = false;
        st.inflate = 0.45f;
        st.setHand(GauntletAnim.ITEM);
        float time = (System.nanoTime() / 1_000_000L % 1_000_000L) / 50f;
        int owned = ThanosClientState.stones;
        GauntletAnim.glow(st, owned, false, false, false, null, -1f, time);
        for (int k = 0; k < 6; k++) {
            if ((owned & (1 << k)) != 0) {
                st.glow[k] = 0.5f + 0.12f * (float) Math.sin(time * 0.1f + k);
            }
        }
        st.core = 0.3f + 0.1f * (float) Math.sin(time * 0.07f);
        st.line = owned != 0 ? 0.2f : 0f;
        ps.pushPose();
        try {
            // ruang barang 0..1: Gauntlet berdiri (tangan di atas), punggung tangan menghadap ke depan
            ps.translate(0.5f, 0.5f, 0.5f);
            ps.mulPose(Axis.YP.rotationDegrees(90f));
            ps.scale(1.6f, 1.6f, 1.6f);
            ps.translate(1.23f / 16f, -7.18f / 16f, 0f);   // pusat kotak batas model
            draw(ps, buffers, light, overlay, false, st);
        } finally {
            ps.popPose();
        }
    }
}
