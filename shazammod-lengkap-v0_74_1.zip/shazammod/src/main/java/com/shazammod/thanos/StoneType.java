package com.shazammod.thanos;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

/**
 * 0.63 Enam batu Infinity Gauntlet. Urutan & tombolnya SAMA dengan enam inti PRALAYA (Z Kekuatan, X Ruang, C Pikiran,
 * V Realitas, B Waktu, N Jiwa), dan urutan ini dipakai di save (bit) & jaringan: jangan diubah.
 */
public enum StoneType {
    POWER("power", 0x9B45E0, "Z"),
    SPACE("space", 0x3F7BFF, "X"),
    MIND("mind", 0xFFD23A, "C"),
    REALITY("reality", 0xE5262E, "V"),
    TIME("time", 0x35D654, "B"),
    SOUL("soul", 0xFF8A1C, "N");

    public static final int COUNT = 6;
    public static final int ALL = (1 << COUNT) - 1;
    private static final StoneType[] VALUES = values();

    public final String id;
    public final int rgb;
    public final String key;

    StoneType(String id, int rgb, String key) {
        this.id = id;
        this.rgb = rgb;
        this.key = key;
    }

    public int bit() {
        return 1 << ordinal();
    }

    public float r() {
        return ((rgb >> 16) & 0xFF) / 255f;
    }

    public float g() {
        return ((rgb >> 8) & 0xFF) / 255f;
    }

    public float b() {
        return (rgb & 0xFF) / 255f;
    }

    /** Kaca berwarna batu ini (urat yang menyala di Kuil Titan). */
    public Block glass() {
        return switch (this) {
            case POWER -> Blocks.PURPLE_STAINED_GLASS;
            case SPACE -> Blocks.BLUE_STAINED_GLASS;
            case MIND -> Blocks.YELLOW_STAINED_GLASS;
            case REALITY -> Blocks.RED_STAINED_GLASS;
            case TIME -> Blocks.LIME_STAINED_GLASS;
            case SOUL -> Blocks.ORANGE_STAINED_GLASS;
        };
    }

    public static StoneType byIndex(int index) {
        return VALUES[Math.floorMod(index, COUNT)];
    }
}
