package com.shazammod.thanos.client.gauntlet;

/**
 * 0.65 Model 3D Infinity Gauntlet (desain ORISINAL, bukan aset film/komik): baja gunmetal berpanel, manset ungu tua berlis
 * emas, mahkota enam batu berbentuk segi enam di punggung tangan yang mengelilingi inti kosmik, alur tenaga yang menyala,
 * dan jari beruas tiga + ibu jari yang benar-benar bisa mengepal, mencakar, menunjuk, dan menjentik.
 *
 * Satuan = piksel model lengan KANAN pemain (ruang sesudah ModelPart.translateAndRotate): kubus lengan x -3..1 (lebar)
 * atau -2..1 (ramping), y -2 (bahu) .. 10 (tangan), z -2..2. Punggung tangan = sisi luar (-X), telapak = +X, ibu jari =
 * sisi depan (-Z); jari menjulur ke +Y dan menekuk ke arah telapak (+X). Lengan kiri = cermin X (lihat GauntletRender).
 *
 * Murni Java (tanpa kelas Minecraft) supaya bentuk & animasinya bisa diuji di luar game. Dipakai dari render thread saja.
 */
public final class GauntletGeo {

    /** Penerima sisi model. */
    public interface Sink {
        /**
         * Satu segi empat: p = 4 titik (x,y,z berurutan, berlawanan jarum jam dilihat dari luar), uv = 4 pasang (0..1),
         * normal satuan, warna 0xRRGGBB (sudah termasuk terang-redupnya).
         */
        void quad(float[] p, float[] uv, float nx, float ny, float nz, int rgb);
    }

    /** Pose jari & cahaya untuk satu gambar. Diisi GauntletAnim. */
    public static final class State {
        public boolean slim;
        /** Seberapa jauh pelat menjauhi kulit lengan (piksel); lebih tebal kalau memakai zirah dada. */
        public float inflate = 0.45f;
        /** Tekukan telunjuk, tengah, manis, kelingking: 0 lurus .. 1 mengepal. */
        public final float[] curl = {0.62f, 0.66f, 0.70f, 0.74f};
        /** 0 rapat .. 1 terbuka lebar. */
        public float spread = 0.12f;
        /** Ibu jari: 0 terbuka .. 1 terlipat. */
        public float thumb = 0.45f;
        /** 0..1 ibu jari menekan jari tengah (siap menjentik). */
        public float press;
        /** Batu yang terpasang (bit = urutan StoneType). */
        public int owned;
        /** Cahaya tiap batu: 0 padam, 1 menyala, 2 berkobar. */
        public final float[] glow = new float[6];
        /** Cahaya inti tengah. */
        public float core;
        public int coreRgb = 0xC8B0FF;
        /** Tenaga yang mengalir di alur lengan bawah & jari-jari mahkota. */
        public float line;
        public int lineRgb = 0x8A5CFF;
        /** Seluruh Gauntlet berkilat (Jentikan, ledakan berubah wujud). */
        public float flash;
        public int flashRgb = 0xFFF2D8;

        public void setHand(float[] p) {
            curl[0] = p[0];
            curl[1] = p[1];
            curl[2] = p[2];
            curl[3] = p[3];
            spread = p[4];
            thumb = p[5];
            press = p[6];
        }
    }

    /** Warna enam batu, urutan StoneType: Kekuatan, Ruang, Pikiran, Realitas, Waktu, Jiwa. */
    public static final int[] STONE_RGB = {0x9B45E0, 0x3F7BFF, 0xFFD23A, 0xE5262E, 0x35D654, 0xFF8A1C};

    // ------------------------------------------------------------------ tekstur (64x64, tools/textures/gauntlet_3d.py)

    public static final int TEX = 64;
    static final int STEEL = 0, STEEL_DK = 1, VIOLET = 2, GOLD = 3, DORSAL = 4, FINGER = 5, NAIL = 6, KNUCKLE = 7,
            SOCKET = 8, GEM = 9, WHITE = 10, GROOVE = 11, HALO = 12, CORE = 13, RIDGE = 14, FLARE = 15, PALM = 16;
    /** {u0, v0, u1, v1} dalam texel. */
    private static final int[][] SW = {
            {0, 0, 16, 16}, {16, 0, 32, 16}, {32, 0, 48, 16}, {48, 0, 64, 16},
            {0, 16, 16, 32}, {16, 16, 24, 24}, {24, 16, 32, 24}, {16, 24, 24, 32},
            {24, 24, 32, 32}, {32, 16, 40, 24}, {41, 17, 43, 19}, {45, 17, 47, 19},
            {48, 16, 64, 32}, {32, 24, 40, 32}, {0, 32, 16, 40}, {16, 32, 32, 48}, {40, 24, 48, 32},
    };

    // gaya kotak: tekstur tiap sisi, urutan -X, +X, -Y, +Y, -Z, +Z (-1 = sisi nggak digambar)
    private static final int[] PLATE = {STEEL, PALM, STEEL, STEEL, STEEL, STEEL};
    private static final int[] SIDE = {STEEL_DK, STEEL_DK, STEEL_DK, STEEL_DK, STEEL_DK, STEEL_DK};
    private static final int[] CUFF = {VIOLET, VIOLET, GOLD, GOLD, VIOLET, VIOLET};
    private static final int[] TRIM = {GOLD, GOLD, GOLD, GOLD, GOLD, GOLD};
    private static final int[] DORSAL_PLATE = {DORSAL, STEEL, GOLD, GOLD, GOLD, GOLD};
    private static final int[] RIDGE_S = {RIDGE, STEEL, GOLD, GOLD, GOLD, GOLD};
    private static final int[] BEZEL = {SOCKET, GOLD, GOLD, GOLD, GOLD, GOLD};
    private static final int[] SEG = {FINGER, PALM, FINGER, FINGER, FINGER, FINGER};
    private static final int[] TIP = {NAIL, PALM, NAIL, NAIL, NAIL, NAIL};
    private static final int[] KNUCK = {KNUCKLE, KNUCKLE, KNUCKLE, KNUCKLE, KNUCKLE, KNUCKLE};
    private static final int[] GEMS = {GEM, GEM, GEM, GEM, GEM, GEM};
    private static final int[] CORES = {CORE, CORE, CORE, CORE, CORE, CORE};
    private static final int[] GLOW = {WHITE, WHITE, WHITE, WHITE, WHITE, WHITE};

    // ------------------------------------------------------------------ ukuran (piksel)

    /** Pusat mahkota batu (y) & jari-jarinya. */
    static final float CROWN_Y = 8.42f, CROWN_R = 1.36f;
    private static final float[] FINGER_Z = {-1.62f, -0.54f, 0.54f, 1.62f};
    private static final float[] FINGER_LEN = {0.96f, 1.06f, 1.0f, 0.84f};
    private static final float[] FINGER_WID = {1f, 1f, 1f, 0.9f};
    private static final float[] SEG_L = {2.0f, 1.32f, 1.02f};
    private static final float[] SEG_W = {0.92f, 0.86f, 0.78f};
    private static final float[] SEG_T = {1.0f, 0.9f, 0.8f};
    /** Sudut tekuk tiap ruas saat mengepal penuh (derajat). */
    private static final float[] SEG_A = {86f, 98f, 72f};

    // ------------------------------------------------------------------ keadaan bangun (dipakai ulang tiap gambar)

    private Sink out;
    private int mode;               // 0 = padat, 1 = cahaya (semua sisi putih, warna = tint)
    private int tint = 0xFFFFFF;
    /** Kalau >= 0: semua sisi memakai warna ini (kilatan seluruh Gauntlet). */
    private int override = -1;
    private final int[] idx = new int[4];
    private final float[] m = new float[12];
    private final float[] stack = new float[12 * 12];
    private int depth;
    private final float[] corner = new float[24];
    private final float[] local = new float[24];
    private final float[] qp = new float[12];
    private final float[] quv = new float[8];
    private final float[] tmp = new float[3];

    /** Pusat mahkota batu di ruang lengan kanan (dipakai efek & kamera orang pertama). */
    public static void crownPoint(State st, float[] out3) {
        float ox = (st.slim ? -2f : -3f) - st.inflate;
        out3[0] = ox - 0.9f;
        out3[1] = CROWN_Y + handShift(st);
        out3[2] = 0f;
    }

    private static float handShift(State st) {
        return Math.max(0f, st.inflate - 0.45f);
    }

    // ------------------------------------------------------------------ pintu masuk

    /** Lintasan padat: logam, manset, permata (ikut cahaya dunia). */
    public void solid(State st, Sink sink) {
        out = sink;
        mode = 0;
        identity();
        body(st);
        out = null;
    }

    /** Lintasan cahaya (aditif): batu, inti, alur tenaga, pendar, kilatan. */
    public void glow(State st, Sink sink) {
        out = sink;
        mode = 1;
        identity();
        glowPass(st);
        out = null;
    }

    // ------------------------------------------------------------------ bentuk

    private void body(State st) {
        float xo = st.slim ? -2f : -3f, xi = 1f, e = st.inflate;
        float ox = xo - e, ix = xi + e, hz = 2f + e, cx = (xo + xi) * 0.5f;
        float d = handShift(st);

        // manset: cincin ungu tua, list emas atas-bawah, paku keling emas
        tint = 0xFFFFFF;
        box(ox - 0.42f, 3.85f, -hz - 0.42f, ix + 0.42f, 5.05f, hz + 0.42f, CUFF);
        box(ox - 0.62f, 3.5f, -hz - 0.62f, ix + 0.62f, 3.92f, hz + 0.62f, TRIM);
        box(ox - 0.3f, 4.98f, -hz - 0.3f, ix + 0.3f, 5.28f, hz + 0.3f, TRIM);
        for (int k = -1; k <= 1; k++) {
            float z = k * 1.25f;
            box(ox - 0.58f, 4.28f, z - 0.17f, ox - 0.4f, 4.62f, z + 0.17f, TRIM);
        }
        for (int s = -1; s <= 1; s += 2) {
            for (int k = 0; k < 2; k++) {
                float x = Lerp.of(ox, ix, 0.3f + 0.4f * k);
                float z0 = s < 0 ? -hz - 0.58f : hz + 0.4f;
                box(x - 0.17f, 4.28f, z0, x + 0.17f, 4.62f, z0 + 0.18f, TRIM);
            }
        }

        // lengan bawah: selongsong baja, rusuk punggung bergaris emas (alur tenaga di tengahnya), pelindung samping
        box(ox, 5.0f, -hz, ix, 7.1f + d, hz, PLATE);
        box(ox - 0.34f, 4.9f, -0.78f, ox + 0.02f, 6.95f + d, 0.78f, RIDGE_S);
        box(ox + 0.5f, 5.3f, hz - 0.02f, ix - 0.5f, 6.85f, hz + 0.22f, SIDE);
        box(ox + 0.5f, 5.3f, -hz - 0.22f, ix - 0.5f, 6.85f, -hz + 0.02f, SIDE);

        // tangan: cangkang, pelat punggung tangan (tempat mahkota), pelindung buku jari
        box(ox, 7.05f + d, -hz, ix, 9.75f + d, hz, PLATE);
        float ps = ox - 0.5f;
        box(ps, 6.72f + d, -hz + 0.22f, ox + 0.02f, 10.12f + d, hz - 0.22f, DORSAL_PLATE);
        box(ox - 0.22f, 9.5f + d, -hz + 0.05f, ox + 1.15f, 10.2f + d, hz - 0.05f, KNUCK);

        // mahkota: alur gelap dari inti ke tiap batu, bezel emas, permata (kalau batunya sudah tercatat), inti
        float yc = CROWN_Y + d;
        tint = 0x2A2230;
        for (int k = 0; k < 6; k++) {
            stripX(ps - 0.004f, yc, 0f, yc + stoneY(k), stoneZ(k), 0.2f, GROOVE);
        }
        tint = 0xFFFFFF;
        for (int k = 0; k < 6; k++) {
            float sy = yc + stoneY(k), sz = stoneZ(k);
            box(ps - 0.16f, sy - 0.46f, sz - 0.46f, ps + 0.02f, sy + 0.46f, sz + 0.46f, BEZEL);
            if ((st.owned & (1 << k)) != 0) {
                int rgb = STONE_RGB[k];
                tint = shade(rgb, 0.78f);
                box(ps - 0.46f, sy - 0.34f, sz - 0.34f, ps - 0.1f, sy + 0.34f, sz + 0.34f, GEMS);
                tint = shade(rgb, 1.05f);
                box(ps - 0.64f, sy - 0.2f, sz - 0.2f, ps - 0.4f, sy + 0.2f, sz + 0.2f, GEMS);
                tint = 0xFFFFFF;
            }
        }
        box(ps - 0.2f, yc - 0.62f, -0.62f, ps + 0.02f, yc + 0.62f, 0.62f, BEZEL);
        tint = shade(st.coreRgb, 0.55f + 0.25f * Math.min(1f, st.core));
        box(ps - 0.52f, yc - 0.46f, -0.46f, ps - 0.12f, yc + 0.46f, 0.46f, CORES);
        box(ps - 0.74f, yc - 0.27f, -0.27f, ps - 0.46f, yc + 0.27f, 0.27f, CORES);
        tint = 0xFFFFFF;

        fingers(st, ox, hz, d, false);
        thumb(st, cx, hz, d, false);
    }

    private void fingers(State st, float ox, float hz, float d, boolean glowOnly) {
        float xa = ox + 0.52f, y0 = 9.92f + d, zs = hz / 2.45f;
        for (int i = 0; i < 4; i++) {
            float c = clamp01(st.curl[i]);
            push();
            translate(xa, y0, FINGER_Z[i] * zs);
            rotX(st.spread * (i - 1.5f) * 12f);
            for (int j = 0; j < 3; j++) {
                float a = c * SEG_A[j] * (i == 3 ? 1.06f : 1f);
                float l = SEG_L[j] * FINGER_LEN[i], w = SEG_W[j] * FINGER_WID[i] * 0.5f, t = SEG_T[j] * 0.5f;
                rotZ(-a * 0.5f);
                if (!glowOnly) {
                    // tutup sendi: kubus di titik tekuk, diputar setengah sudut supaya celah antar-ruas tertutup
                    box(-t * 1.02f, -t, -w * 1.04f, t * 1.02f, t, w * 1.04f, j == 0 ? KNUCK : SEG);
                }
                rotZ(-a * 0.5f);
                if (!glowOnly) {
                    box(-t, 0f, -w, t, l, w, j == 2 ? TIP : SEG);
                }
                translate(0f, l, 0f);
            }
            if (!glowOnly) {
                box(-0.3f, -0.05f, -0.24f, 0.1f, 0.42f, 0.24f, TIP);   // ujung cakar
            }
            pop();
        }
    }

    private void thumb(State st, float cx, float hz, float d, boolean glowOnly) {
        float t = clamp01(st.thumb), p = clamp01(st.press);
        push();
        translate(cx + 0.35f, 8.15f + d, -hz + 0.15f);
        rotX(-(Lerp.of(38f, 6f, t) + p * 10f));
        rotZ(-(Lerp.of(8f, 52f, t) + p * 26f));
        if (!glowOnly) {
            box(-0.5f, 0f, -0.5f, 0.5f, 1.65f, 0.5f, SEG);
        }
        translate(0f, 1.65f, 0f);
        float tip = Lerp.of(10f, 62f, t) + p * 18f;
        rotZ(-tip * 0.5f);
        if (!glowOnly) {
            box(-0.47f, -0.45f, -0.47f, 0.47f, 0.45f, 0.47f, SEG);
        }
        rotZ(-tip * 0.5f);
        if (!glowOnly) {
            box(-0.45f, 0f, -0.45f, 0.45f, 1.25f, 0.45f, TIP);
            translate(0f, 1.25f, 0f);
            box(-0.28f, -0.05f, -0.22f, 0.1f, 0.38f, 0.22f, TIP);
        }
        pop();
    }

    // ------------------------------------------------------------------ cahaya

    private void glowPass(State st) {
        float xo = st.slim ? -2f : -3f, e = st.inflate;
        float ox = xo - e, ps = ox - 0.5f, d = handShift(st), yc = CROWN_Y + d;

        // alur tenaga di rusuk lengan bawah (dari manset ke mahkota)
        if (st.line > 0.01f) {
            tint = scale(st.lineRgb, Math.min(1f, st.line));
            stripX(ox - 0.35f, 4.95f, 0f, 6.9f + d, 0f, 0.26f, WHITE);
            tint = scale(st.lineRgb, Math.min(1f, st.line) * 0.5f);
            stripX(ox - 0.36f, 4.95f, 0f, 6.9f + d, 0f, 0.7f, HALO);
            tint = scale(st.lineRgb, Math.min(1f, st.line) * 0.6f);
            stripX(ps - 0.01f, yc - 0.6f, 0f, 6.75f + d, 0f, 0.2f, WHITE);
        }

        // jari-jari mahkota, batu, pendarnya
        for (int k = 0; k < 6; k++) {
            float g = st.glow[k];
            boolean has = (st.owned & (1 << k)) != 0;
            if (g <= 0.01f || !has) {
                continue;
            }
            int rgb = STONE_RGB[k];
            float sy = yc + stoneY(k), sz = stoneZ(k);
            tint = scale(hot(rgb, g), Math.min(1f, 0.25f + 0.55f * g + st.core * 0.15f));
            stripX(ps - 0.012f, yc, 0f, sy, sz, 0.2f, WHITE);
            tint = scale(hot(rgb, g), Math.min(1f, 0.35f + 0.5f * g));
            box(ps - 0.49f, sy - 0.37f, sz - 0.37f, ps - 0.08f, sy + 0.37f, sz + 0.37f, GLOW);
            box(ps - 0.67f, sy - 0.23f, sz - 0.23f, ps - 0.38f, sy + 0.23f, sz + 0.23f, GLOW);
            float gg = Math.min(g, 2.2f);
            tint = scale(rgb, Math.min(0.75f, 0.24f * gg + 0.06f));
            flatX(ps - 0.7f, sy, sz, 0.6f + 0.5f * gg, HALO);
            if (g > 1.2f) {
                tint = scale(hot(rgb, g), Math.min(0.6f, (g - 1.2f) * 0.35f));
                flatX(ps - 0.85f, sy, sz, 1.2f + 1.2f * (g - 1.2f), HALO);
            }
        }

        // inti kosmik di tengah
        if (st.core > 0.01f) {
            float c = Math.min(st.core, 2.2f);
            tint = scale(hot(st.coreRgb, c), Math.min(1f, 0.3f + 0.5f * c));
            box(ps - 0.55f, yc - 0.49f, -0.49f, ps - 0.1f, yc + 0.49f, 0.49f, GLOW);
            box(ps - 0.77f, yc - 0.3f, -0.3f, ps - 0.44f, yc + 0.3f, 0.3f, GLOW);
            tint = scale(st.coreRgb, Math.min(0.8f, 0.24f * c + 0.05f));
            flatX(ps - 0.78f, yc, 0f, 0.8f + 0.6f * c, HALO);
            if (st.core > 1.05f) {
                tint = scale(hot(st.coreRgb, c), Math.min(1f, (c - 1f) * 0.5f));
                flatX(ps - 0.95f, yc, 0f, 1.8f + 2.2f * (c - 1f), FLARE);
            }
        }

        // kilatan: seluruh Gauntlet ikut menyala, bintang cahaya di mahkota
        if (st.flash > 0.01f) {
            float f = Math.min(st.flash, 1f);
            int keep = tint;
            override = scale(st.flashRgb, 0.42f * f);
            mode = 1;
            identity();
            body(st);
            override = -1;
            identity();
            tint = scale(st.flashRgb, f);
            flatX(ps - 1.0f, yc, 0f, 2.5f + 4.5f * f, FLARE);
            tint = scale(st.flashRgb, 0.6f * f);
            flatX(ps - 1.05f, yc, 0f, 4.0f + 3.0f * f, HALO);
            tint = keep;
        }
    }

    // ------------------------------------------------------------------ letak batu (segi enam, diputar 30 derajat)

    static float stoneY(int k) {
        return CROWN_R * (float) Math.cos(Math.toRadians(30 + 60 * k));
    }

    static float stoneZ(int k) {
        return CROWN_R * (float) Math.sin(Math.toRadians(30 + 60 * k));
    }

    // ------------------------------------------------------------------ primitif

    /** Kotak sejajar sumbu (ruang lokal sekarang), tiap sisi bertekstur penuh satu swatch. */
    private void box(float x0, float y0, float z0, float x1, float y1, float z1, int[] style) {
        for (int i = 0; i < 8; i++) {
            float x = (i & 1) != 0 ? x1 : x0, y = (i & 2) != 0 ? y1 : y0, z = (i & 4) != 0 ? z1 : z0;
            local[i * 3] = x;
            local[i * 3 + 1] = y;
            local[i * 3 + 2] = z;
            corner[i * 3] = m[0] * x + m[1] * y + m[2] * z + m[3];
            corner[i * 3 + 1] = m[4] * x + m[5] * y + m[6] * z + m[7];
            corner[i * 3 + 2] = m[8] * x + m[9] * y + m[10] * z + m[11];
        }
        // urutan sudut tiap sisi (berlawanan jarum jam dari luar) & sumbu bidangnya
        face(0, 4, 6, 2, -1f, 0f, 0f, 2, 1, style[0], x0, y0, z0, x1, y1, z1);
        face(1, 3, 7, 5, 1f, 0f, 0f, 2, 1, style[1], x0, y0, z0, x1, y1, z1);
        face(0, 1, 5, 4, 0f, -1f, 0f, 0, 2, style[2], x0, y0, z0, x1, y1, z1);
        face(2, 6, 7, 3, 0f, 1f, 0f, 0, 2, style[3], x0, y0, z0, x1, y1, z1);
        face(0, 2, 3, 1, 0f, 0f, -1f, 0, 1, style[4], x0, y0, z0, x1, y1, z1);
        face(4, 5, 7, 6, 0f, 0f, 1f, 0, 1, style[5], x0, y0, z0, x1, y1, z1);
    }

    private void face(int a, int b, int c, int dd, float nx, float ny, float nz, int ua, int va, int sw,
                      float x0, float y0, float z0, float x1, float y1, float z1) {
        if (sw < 0) {
            return;
        }
        int s = mode == 1 ? WHITE : sw;
        float lo0 = ua == 0 ? x0 : ua == 1 ? y0 : z0, hi0 = ua == 0 ? x1 : ua == 1 ? y1 : z1;
        float lo1 = va == 0 ? x0 : va == 1 ? y0 : z0, hi1 = va == 0 ? x1 : va == 1 ? y1 : z1;
        idx[0] = a;
        idx[1] = b;
        idx[2] = c;
        idx[3] = dd;
        for (int k = 0; k < 4; k++) {
            int i = idx[k];
            qp[k * 3] = corner[i * 3];
            qp[k * 3 + 1] = corner[i * 3 + 1];
            qp[k * 3 + 2] = corner[i * 3 + 2];
            float u = (local[i * 3 + ua] - lo0) / Math.max(1.0E-5f, hi0 - lo0);
            float v = (local[i * 3 + va] - lo1) / Math.max(1.0E-5f, hi1 - lo1);
            quv[k * 2] = uvU(s, u);
            quv[k * 2 + 1] = uvV(s, v);
        }
        dir(nx, ny, nz, tmp);
        emit(tmp[0], tmp[1], tmp[2], tint);
    }

    /** Segi empat datar menghadap -X (punggung tangan), pusat (y,z), setengah sisi h. */
    private void flatX(float x, float y, float z, float h, int sw) {
        corner4(x, y - h, z - h, x, y - h, z + h, x, y + h, z + h, x, y + h, z - h, sw);
    }

    /** Pita datar menghadap -X dari (ya,za) ke (yb,zb), lebar w. */
    private void stripX(float x, float ya, float za, float yb, float zb, float w, int sw) {
        float dy = yb - ya, dz = zb - za, len = (float) Math.sqrt(dy * dy + dz * dz);
        if (len < 1.0E-4f) {
            return;
        }
        float py = -dz / len * w * 0.5f, pz = dy / len * w * 0.5f;
        corner4(x, ya - py, za - pz, x, ya + py, za + pz, x, yb + py, zb + pz, x, yb - py, zb - pz, sw);
    }

    /** Empat titik lokal (uv 00, 10, 11, 01), normal -X lokal. */
    private void corner4(float x0, float y0, float z0, float x1, float y1, float z1, float x2, float y2, float z2,
                         float x3, float y3, float z3, int sw) {
        put(0, x0, y0, z0, sw, 0f, 0f);
        put(1, x1, y1, z1, sw, 1f, 0f);
        put(2, x2, y2, z2, sw, 1f, 1f);
        put(3, x3, y3, z3, sw, 0f, 1f);
        dir(-1f, 0f, 0f, tmp);
        emit(tmp[0], tmp[1], tmp[2], tint);
    }

    private void put(int k, float x, float y, float z, int sw, float u, float v) {
        point(x, y, z, tmp);
        qp[k * 3] = tmp[0];
        qp[k * 3 + 1] = tmp[1];
        qp[k * 3 + 2] = tmp[2];
        quv[k * 2] = uvU(sw, u);
        quv[k * 2 + 1] = uvV(sw, v);
    }

    /** Kirim qp/quv; urutan dibalik kalau arah putarnya nggak cocok dengan normal (aman untuk semua transformasi). */
    private void emit(float nx, float ny, float nz, int rgb) {
        float ax = qp[3] - qp[0], ay = qp[4] - qp[1], az = qp[5] - qp[2];
        float bx = qp[6] - qp[0], by = qp[7] - qp[1], bz = qp[8] - qp[2];
        float cx = ay * bz - az * by, cy = az * bx - ax * bz, cz = ax * by - ay * bx;
        if (cx * nx + cy * ny + cz * nz < 0f) {
            swap3(1, 3);
            swap2(1, 3);
        }
        out.quad(qp, quv, nx, ny, nz, override >= 0 ? override : rgb);
    }

    private void swap3(int i, int j) {
        for (int k = 0; k < 3; k++) {
            float t = qp[i * 3 + k];
            qp[i * 3 + k] = qp[j * 3 + k];
            qp[j * 3 + k] = t;
        }
    }

    private void swap2(int i, int j) {
        for (int k = 0; k < 2; k++) {
            float t = quv[i * 2 + k];
            quv[i * 2 + k] = quv[j * 2 + k];
            quv[j * 2 + k] = t;
        }
    }

    private static float uvU(int sw, float u) {
        int[] r = SW[sw];
        return (r[0] + (r[2] - r[0]) * u) / TEX;
    }

    private static float uvV(int sw, float v) {
        int[] r = SW[sw];
        return (r[1] + (r[3] - r[1]) * v) / TEX;
    }

    // ------------------------------------------------------------------ matriks 3x4 (baris: r00 r01 r02 tx ...)

    private void identity() {
        for (int i = 0; i < 12; i++) {
            m[i] = (i == 0 || i == 5 || i == 10) ? 1f : 0f;
        }
        depth = 0;
    }

    private void push() {
        System.arraycopy(m, 0, stack, depth * 12, 12);
        depth++;
    }

    private void pop() {
        depth--;
        System.arraycopy(stack, depth * 12, m, 0, 12);
    }

    private void translate(float x, float y, float z) {
        m[3] += m[0] * x + m[1] * y + m[2] * z;
        m[7] += m[4] * x + m[5] * y + m[6] * z;
        m[11] += m[8] * x + m[9] * y + m[10] * z;
    }

    /** m = m * R (R rotasi kolom c0, c1, c2). */
    private void mulRot(float a00, float a01, float a02, float a10, float a11, float a12, float a20, float a21, float a22) {
        for (int r = 0; r < 3; r++) {
            float m0 = m[r * 4], m1 = m[r * 4 + 1], m2 = m[r * 4 + 2];
            m[r * 4] = m0 * a00 + m1 * a10 + m2 * a20;
            m[r * 4 + 1] = m0 * a01 + m1 * a11 + m2 * a21;
            m[r * 4 + 2] = m0 * a02 + m1 * a12 + m2 * a22;
        }
    }

    private void rotX(float deg) {
        float a = (float) Math.toRadians(deg), c = (float) Math.cos(a), s = (float) Math.sin(a);
        mulRot(1, 0, 0, 0, c, -s, 0, s, c);
    }

    private void rotZ(float deg) {
        float a = (float) Math.toRadians(deg), c = (float) Math.cos(a), s = (float) Math.sin(a);
        mulRot(c, -s, 0, s, c, 0, 0, 0, 1);
    }

    private void point(float x, float y, float z, float[] o) {
        o[0] = m[0] * x + m[1] * y + m[2] * z + m[3];
        o[1] = m[4] * x + m[5] * y + m[6] * z + m[7];
        o[2] = m[8] * x + m[9] * y + m[10] * z + m[11];
    }

    private void dir(float x, float y, float z, float[] o) {
        float a = m[0] * x + m[1] * y + m[2] * z;
        float b = m[4] * x + m[5] * y + m[6] * z;
        float c = m[8] * x + m[9] * y + m[10] * z;
        float l = (float) Math.sqrt(a * a + b * b + c * c);
        l = l < 1.0E-6f ? 1f : l;
        o[0] = a / l;
        o[1] = b / l;
        o[2] = c / l;
    }

    // ------------------------------------------------------------------ warna

    private static float clamp01(float v) {
        return v < 0f ? 0f : Math.min(v, 1f);
    }

    /** Kali kecerahan (k boleh > 1, tiap kanal dibatasi 255). */
    static int shade(int rgb, float k) {
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * k));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * k));
        int b = Math.min(255, (int) ((rgb & 255) * k));
        return (r << 16) | (g << 8) | b;
    }

    static int scale(int rgb, float k) {
        return shade(rgb, Math.max(0f, k));
    }

    /** Makin terang makin memutih (inti api). */
    static int hot(int rgb, float g) {
        float t = clamp01((g - 0.9f) * 0.55f);
        int r = (rgb >> 16) & 255, gg = (rgb >> 8) & 255, b = rgb & 255;
        r = (int) (r + (255 - r) * t);
        gg = (int) (gg + (255 - gg) * t);
        b = (int) (b + (255 - b) * t);
        return (r << 16) | (gg << 8) | b;
    }

    /** Lerp kecil tanpa kelas Minecraft. */
    static final class Lerp {
        private Lerp() {}

        static float of(float a, float b, float t) {
            return a + (b - a) * t;
        }
    }
}
