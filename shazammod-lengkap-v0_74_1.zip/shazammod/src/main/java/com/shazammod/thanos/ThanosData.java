package com.shazammod.thanos;

import java.util.ArrayList;
import java.util.List;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/**
 * 0.63 Data Thanos milik tiap pemain (attachment "thanos", ikut tersimpan & tetap ada sesudah mati).
 *
 * bound       = Infinity Gauntlet sudah terikat lewat Sumpah Titan (Thanos terbuka)
 * stones      = batu yang pernah dipegang: tercatat di Gauntlet selamanya (bit StoneType), sama seperti inti PRALAYA
 * site*       = letak Kuil Titan tiap batu (per pemain); sitesSet = sudah dipilih, sitesBuilt = sudah dibangun
 * cooldowns   = per slot (tick): 0-5 Z..N, 6-11 Shift+Z..N, lalu SLOT_* (0.64: 18-23 Alt+Z..N, 24 Ledakan Kawah)
 */
public final class ThanosData {
    public static final int SLOT_SHIFT = 6;
    public static final int SLOT_SNAP = 12, SLOT_RAGE = 13, SLOT_SPIN = 14, SLOT_THROW = 15, SLOT_LEAP = 16,
            SLOT_SIGNAL = 17, SLOT_ALT = 18, SLOT_CRATER = 24, SLOTS = 25;   // 0.64 18-23 = Alt+Z..N, 24 = Ledakan Kawah
    public static final float MAX_ENERGY = 100f;

    public boolean bound;
    public boolean transformed;
    public float energy = MAX_ENERGY;
    public int stones;
    public final int[] cooldowns = new int[SLOTS];
    public final int[] siteX = new int[StoneType.COUNT];
    public final int[] siteZ = new int[StoneType.COUNT];
    public int sitesSet;
    public int sitesBuilt;

    // ---- nggak disimpan
    public int snapCharge;
    public long lastToggle;
    public int morphing;
    public int rageTicks;
    public int shieldTicks;

    public static final Codec<ThanosData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.BOOL.optionalFieldOf("bound", false).forGetter((ThanosData d) -> d.bound),
            Codec.BOOL.optionalFieldOf("transformed", false).forGetter((ThanosData d) -> d.transformed),
            Codec.FLOAT.optionalFieldOf("energy", MAX_ENERGY).forGetter((ThanosData d) -> d.energy),
            Codec.INT.optionalFieldOf("stones", 0).forGetter((ThanosData d) -> d.stones),
            Codec.INT.listOf().optionalFieldOf("cooldowns", List.of()).forGetter((ThanosData d) -> list(d.cooldowns)),
            Codec.INT.listOf().optionalFieldOf("site_x", List.of()).forGetter((ThanosData d) -> list(d.siteX)),
            Codec.INT.listOf().optionalFieldOf("site_z", List.of()).forGetter((ThanosData d) -> list(d.siteZ)),
            Codec.INT.optionalFieldOf("sites_set", 0).forGetter((ThanosData d) -> d.sitesSet),
            Codec.INT.optionalFieldOf("sites_built", 0).forGetter((ThanosData d) -> d.sitesBuilt)
    ).apply(instance, ThanosData::new));

    public ThanosData() {}

    private ThanosData(boolean bound, boolean transformed, float energy, int stones, List<Integer> cooldowns,
                       List<Integer> siteX, List<Integer> siteZ, int sitesSet, int sitesBuilt) {
        this.bound = bound;
        this.transformed = transformed && bound;
        this.energy = Math.max(0f, Math.min(MAX_ENERGY, energy));
        this.stones = stones & StoneType.ALL;
        copy(cooldowns, this.cooldowns);
        copy(siteX, this.siteX);
        copy(siteZ, this.siteZ);
        this.sitesSet = sitesSet & StoneType.ALL;
        this.sitesBuilt = sitesBuilt & StoneType.ALL;
    }

    private static List<Integer> list(int[] values) {
        List<Integer> out = new ArrayList<>(values.length);
        for (int v : values) {
            out.add(v);
        }
        return out;
    }

    private static void copy(List<Integer> from, int[] to) {
        for (int i = 0; i < Math.min(from.size(), to.length); i++) {
            to[i] = from.get(i);
        }
    }

    public boolean has(StoneType stone) {
        return (stones & stone.bit()) != 0;
    }

    public boolean coolingDown() {
        for (int c : cooldowns) {
            if (c > 0) {
                return true;
            }
        }
        return false;
    }
}
