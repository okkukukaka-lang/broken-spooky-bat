package com.shazammod.thanos.item;

import java.util.List;

import com.shazammod.thanos.ThanosAbilities;
import com.shazammod.thanos.ThanosSkills;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

/** 0.63 Pedang Dua Mata: tahan klik kanan = tangkis, Shift + klik kanan (atau Shift+M) = lempar (kembali sendiri), M Putaran. */
public class DoubleBladeSwordItem extends SwordItem {
    public DoubleBladeSwordItem(Item.Properties properties) {
        super(Tiers.NETHERITE, properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!ThanosAbilities.canUse(player)) {
            if (player instanceof ServerPlayer serverPlayer) {
                ThanosAbilities.msg(serverPlayer, "need_form", ChatFormatting.GRAY);
            }
            return InteractionResultHolder.pass(stack);
        }
        if (player.isShiftKeyDown()) {
            if (player instanceof ServerPlayer serverPlayer) {
                ThanosSkills.throwBlade(serverPlayer, hand);   // animasi THANOS_THROW, lalu pedang dilempar di TITAN_THROW_AT
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        player.startUsingItem(hand);   // tangkis
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BLOCK;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 72000;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shazammod.thanos.blade").withStyle(ChatFormatting.GRAY));
    }
}
