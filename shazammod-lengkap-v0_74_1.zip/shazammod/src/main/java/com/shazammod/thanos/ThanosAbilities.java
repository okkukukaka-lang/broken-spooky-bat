package com.shazammod.thanos;

import com.shazammod.AksaraRite;
import com.shazammod.Helion3Rite;
import com.shazammod.HelionRite;
import com.shazammod.KahndaqTrial;
import com.shazammod.LintangRite;
import com.shazammod.PralayaGod;
import com.shazammod.SabbacPact;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamPowers;
import com.shazammod.ShazamSounds;
import com.shazammod.ShazamTotems;
import com.shazammod.thanos.item.InfinityGauntletItem;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 0.63 THANOS (fan-made): wujud terpisah dari juara ShazamForm, tapi nggak bisa aktif bareng juara mana pun.
 *
 *   Klik kanan Infinity Gauntlet   Sumpah Titan (sekali): Gauntlet terikat, Thanos terbuka, sinyal batu pertama
 *   U / ketik THANOS               berubah (animasi THANOS_TRANSFORM, kekuatan terpasang di TITAN_MORPH_BURST) / kembali
 *   Z X C V B N (+Shift)           kuasa batu (ThanosSkills), R Jentikan / Shift+R Murka Titan, M pedang, J lompat/sinyal
 *   G                              kembali jadi manusia
 *
 * Gauntlet harus ADA DI INVENTORI (dianggap dipakai) untuk berubah & memakai kuasa batu. Semua logika di server.
 */
public final class ThanosAbilities {
    private ThanosAbilities() {}

    private static final int TOGGLE_GAP = 20;
    private static final int SYNC_EVERY = 10;

    // ---------------------------------------------------------------- data & syarat

    public static ThanosData data(Player p) {
        return p.getData(ThanosRegistry.DATA);
    }

    public static boolean active(Player p) {
        return data(p).transformed;
    }

    /** Pedang berkekuatan (di client: tebakan dari status yang disinkronkan). */
    public static boolean canUse(Player p) {
        if (p.level().isClientSide()) {
            return ThanosClientState.transformed;
        }
        return data(p).transformed || !ThanosConfig.REQUIRE_FORM.get();
    }

    public static boolean hasGauntlet(Player p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).getItem() instanceof InfinityGauntletItem) {
                return true;
            }
        }
        return false;
    }

    /** Sedang (atau mulai) jadi juara lain, atau di tengah ritual juara. */
    public static boolean championBusy(ServerPlayer p) {
        return ShazamPowers.isTransformed(p) || ShazamPowers.isToggling(p) || ShazamTotems.isAwakening(p)
                || KahndaqTrial.isAwakening(p) || SabbacPact.isAwakening(p) || LintangRite.isAwakening(p)
                || HelionRite.isAwakening(p) || Helion3Rite.isAwakening(p) || AksaraRite.isAwakening(p)
                || com.shazammod.relativa.RelativaAbilities.active(p)          // 0.66 RELATIVA
                || com.shazammod.relativa.RelativaRite.isRunning(p);
    }

    public static void msg(ServerPlayer p, String key, ChatFormatting color, Object... args) {
        p.displayClientMessage(Component.translatable("message.shazammod.thanos." + key, args).withStyle(color), true);
    }

    public static Component stoneName(StoneType t) {
        return Component.translatable("item.shazammod." + t.id + "_stone").withStyle(s -> s.withColor(t.rgb));
    }

    // ---------------------------------------------------------------- tombol

    /**
     * Dipanggil dari ShazamNetwork.handleAction. Dalam wujud Thanos tombol juara dipakai Thanos. true = sudah diurus di
     * sini; K (ganti juara) & H tetap seperti biasa.
     */
    public static boolean handleSharedKey(ServerPlayer p, int action) {
        ThanosData d = data(p);
        if (!d.transformed) {
            return false;
        }
        boolean shift = p.isShiftKeyDown();
        if (action == ShazamNetwork.ACTION_FORM || action == ShazamNetwork.ACTION_HOOD) {
            return false;
        }
        if (action == ShazamNetwork.ACTION_TRANSFORM) {
            toggleTransform(p);
        } else if (action >= 1 && action <= 6) {
            ThanosSkills.stone(p, d, action - 1, shift);
        } else if (action == 7) {
            if (shift) {
                ThanosSkills.rage(p, d);
            } else {
                ThanosSnap.toggle(p, d);
            }
        } else if (action == ShazamNetwork.ACTION_ADAM_CALL) {
            if (shift) {
                ThanosSkills.throwBlade(p, net.minecraft.world.InteractionHand.MAIN_HAND);
            } else {
                ThanosSkills.spin(p, d);
            }
        } else if (action >= ShazamNetwork.ACTION_ALT && action < ShazamNetwork.ACTION_ALT + 6) {
            com.shazammod.infinity.InfinitySkills.thanos(p, d, action - ShazamNetwork.ACTION_ALT);   // 0.64 Kuasa Infinity
        } else if (action == ShazamNetwork.ACTION_FAMILY) {
            if (shift) {
                ThanosSkills.signal(p, d);
            } else {
                ThanosSkills.leap(p, d);
            }
        }
        ThanosNetwork.sync(p);
        return true;
    }

    // ---------------------------------------------------------------- berubah

    public static void toggleTransform(ServerPlayer p) {
        ThanosData d = data(p);
        if (p.isSpectator() || !p.isAlive() || PralayaGod.frozen(p) || d.morphing > 0) {
            return;
        }
        long now = p.level().getGameTime();
        if (d.lastToggle != 0L && now >= d.lastToggle && now - d.lastToggle < TOGGLE_GAP) {
            return;
        }
        if (d.transformed) {
            d.lastToggle = now;
            revert(p, d);
            return;
        }
        if (!d.bound) {
            msg(p, "need_bind", ChatFormatting.GRAY);
            return;
        }
        if (!hasGauntlet(p)) {
            msg(p, "no_gauntlet", ChatFormatting.GRAY);
            return;
        }
        if (championBusy(p)) {
            msg(p, "champion_active", ChatFormatting.GRAY);
            return;
        }
        if (!ThanosSkills.free(p)) {
            return;
        }
        d.lastToggle = now;
        d.morphing = ShazamAnim.TITAN_MORPH_BURST;
        ThanosSkills.busy(p, ShazamAnim.TITAN_MORPH_TICKS);
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_TRANSFORM);
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.THANOS_TRANSFORM.get(), SoundSource.PLAYERS,
                2.4f, 1f);
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ShazamAnim.TITAN_MORPH_BURST, 3, false, false));
    }

    /** Ledakan kosmik di TITAN_MORPH_BURST: kekuatan Thanos terpasang. */
    private static void completeMorph(ServerPlayer p, ThanosData d) {
        if (d.transformed || !d.bound || !hasGauntlet(p) || championBusy(p)) {
            return;
        }
        d.transformed = true;
        float ratio = p.getHealth() / Math.max(1f, p.getMaxHealth());
        ThanosPowers.apply(p);
        p.setHealth(Math.max(1f, ratio * p.getMaxHealth()));
        for (LivingEntity e : ThanosSkills.enemies(p, 5.0)) {   // ledakan kosmik mendorong yang terlalu dekat
            Vec3 away = ThanosSkills.flat(e.position().subtract(p.position()));
            e.push(away.x * 1.1, 0.4, away.z * 1.1);
            e.hurtMarked = true;
        }
        msg(p, "transformed", ChatFormatting.DARK_PURPLE);
        ThanosNetwork.sync(p);
        ThanosNetwork.broadcastState(p);
    }

    private static void revert(ServerPlayer p, ThanosData d) {
        ThanosSnap.cancel(p, d, false);
        d.transformed = false;
        d.rageTicks = 0;
        d.shieldTicks = 0;
        ThanosPowers.remove(p);
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_REVERT);
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.THANOS_REVERT.get(), SoundSource.PLAYERS,
                1.4f, 1f);
        msg(p, "reverted", ChatFormatting.GRAY);
        ThanosNetwork.sync(p);
        ThanosNetwork.broadcastState(p);
    }

    // ---------------------------------------------------------------- tick, login, respawn

    public static void tick(ServerPlayer p) {
        ThanosData d = data(p);
        ThanosSanctum.tick(p);
        if (!d.bound && !d.transformed) {
            ThanosSkills.tick(p, d);   // Sumpah Titan yang sedang berjalan
            return;
        }
        if (d.transformed && ShazamPowers.isTransformed(p)) {   // jadi juara lain lewat jalan lain: wujud Thanos lepas
            ThanosSnap.cancel(p, d, false);
            d.transformed = false;
            ThanosPowers.remove(p);
            ThanosNetwork.sync(p);
            ThanosNetwork.broadcastState(p);
        }
        if (PralayaGod.frozen(p)) {   // waktu dunia dihentikan PRALAYA: Thanos ikut membeku
            ThanosSnap.cancel(p, d, true);
            return;
        }
        if (d.morphing > 0 && --d.morphing == 0) {
            completeMorph(p, d);
        }
        ThanosSkills.tick(p, d);
        for (int i = 0; i < d.cooldowns.length; i++) {
            if (d.cooldowns[i] > 0) {
                d.cooldowns[i]--;
            }
        }
        if (d.transformed && p.isAlive()) {
            float regen = ThanosConfig.ENERGY_REGEN.get().floatValue() / 20f * (d.rageTicks > 0 ? 1.5f : 1f);
            d.energy = Math.min(ThanosData.MAX_ENERGY, d.energy + regen);
            if (p.tickCount % 40 == 0 && p.getHealth() < p.getMaxHealth()) {
                p.heal(ThanosConfig.REGEN.get().floatValue());
            }
        }
        if (d.shieldTicks > 0 && --d.shieldTicks == 0) {
            ThanosNetwork.broadcastState(p);
        }
        if (d.rageTicks > 0 && --d.rageTicks == 0) {
            ShazamNetwork.playAnim(p, ShazamAnim.TITAN_RAGE_END);
            ThanosNetwork.broadcastState(p);
        }
        ThanosSnap.tick(p, d);
        if (p.tickCount % SYNC_EVERY == 0 && (d.transformed || d.coolingDown() || d.morphing > 0)) {
            ThanosNetwork.sync(p);
        }
    }

    public static void onLogin(ServerPlayer p) {
        ThanosData d = data(p);
        d.snapCharge = 0;
        d.morphing = 0;
        d.rageTicks = 0;
        d.shieldTicks = 0;
        if (d.transformed && (ShazamPowers.isTransformed(p) || !d.bound)) {
            d.transformed = false;
        }
        if (d.transformed) {
            ThanosPowers.apply(p);   // modifier atribut nggak ikut tersimpan, jadi dipasang ulang
        } else {
            ThanosPowers.remove(p);
        }
        ThanosNetwork.sync(p);
        ThanosNetwork.broadcastState(p);
    }

    /** Hidup lagi sebagai manusia biasa (sama seperti juara lain); Gauntlet & batu tetap tercatat. */
    public static void onRespawn(ServerPlayer p) {
        ThanosData d = data(p);
        d.transformed = false;
        d.snapCharge = 0;
        d.morphing = 0;
        d.rageTicks = 0;
        d.shieldTicks = 0;
        ThanosSkills.clear(p);
        ThanosPowers.remove(p);
        ThanosNetwork.sync(p);
        ThanosNetwork.broadcastState(p);
    }

    // ---------------------------------------------------------------- tangkisan pedang & Perisai Jiwa

    public static void guard(LivingIncomingDamageEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) {
            return;
        }
        DamageSource source = event.getSource();
        if (ThanosSnap.isSnap(source) || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        ThanosData d = data(p);
        if (d.shieldTicks > 0 && source.getEntity() instanceof LivingEntity attacker) {
            ThanosSkills.reflect(p, attacker, event.getAmount());
        }
        if (!p.isUsingItem() || !p.getUseItem().is(ThanosRegistry.DOUBLE_BLADE.get()) || source.is(DamageTypeTags.BYPASSES_SHIELD)) {
            return;
        }
        Vec3 from = source.getSourcePosition();
        if (from == null) {
            return;
        }
        Vec3 to = new Vec3(from.x - p.getX(), 0.0, from.z - p.getZ());
        Vec3 look = p.getLookAngle();
        look = new Vec3(look.x, 0.0, look.z);
        if (to.lengthSqr() < 1.0E-4 || look.lengthSqr() < 1.0E-4 || to.normalize().dot(look.normalize()) < 0.3) {
            return;   // bukan dari depan
        }
        Vec3 spark = p.getEyePosition().add(look.normalize().scale(0.8)).add(0, -0.4, 0);
        if (p.getTicksUsingItem() <= ThanosConfig.PARRY_TICKS.get()) {
            event.setCanceled(true);
            if (source.getEntity() instanceof LivingEntity attacker && attacker != p) {
                attacker.knockback(1.2, p.getX() - attacker.getX(), p.getZ() - attacker.getZ());
                attacker.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 2), p);
            }
            ShazamNetwork.playAnim(p, ShazamAnim.TITAN_PARRY, spark);
            p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.THANOS_PARRY.get(), SoundSource.PLAYERS,
                    1.4f, 1f);
        } else {
            event.setAmount((float) (event.getAmount() * (1.0 - ThanosConfig.GUARD_REDUCTION.get())));
            p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 0.8f, 0.7f);
        }
    }
}
