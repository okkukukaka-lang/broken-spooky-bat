package com.shazammod.thanos.client.gauntlet;

import com.shazammod.ShazamMod;
import com.shazammod.thanos.ThanosRegistry;

import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;

/** 0.65 Khusus client: barang 3D, lapisan lengan, dan tangan orang pertama Infinity Gauntlet. */
public final class GauntletClient {
    private GauntletClient() {}

    @EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModEvents {
        private ModEvents() {}

        @SubscribeEvent
        public static void registerItemExtensions(RegisterClientExtensionsEvent event) {
            event.registerItem(new IClientItemExtensions() {
                private BlockEntityWithoutLevelRenderer renderer;

                @Override
                public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                    if (renderer == null) {
                        renderer = new GauntletItemRenderer();
                    }
                    return renderer;
                }
            }, ThanosRegistry.GAUNTLET.get());
        }

        @SubscribeEvent
        public static void addLayers(EntityRenderersEvent.AddLayers event) {
            for (PlayerSkin.Model skin : event.getSkins()) {
                if (event.getSkin(skin) instanceof PlayerRenderer renderer) {
                    renderer.addLayer(new GauntletLayer(renderer));
                }
            }
        }
    }

    @EventBusSubscriber(modid = ShazamMod.MODID, value = Dist.CLIENT)
    public static final class GameEvents {
        private GameEvents() {}

        @SubscribeEvent
        public static void onRenderHand(RenderHandEvent event) {
            try {
                GauntletRender.renderHand(event);
            } catch (Throwable ignored) {
                // tangan bawaan tetap digambar kalau ada yang salah sebelum dibatalkan
            }
        }

        /** Paling akhir & ikut yang dibatalkan: kalau render pemainnya dibatalkan, Post nggak akan datang. */
        @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
        public static void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
            GauntletRender.renderingPlayer = !event.isCanceled();
        }

        @SubscribeEvent
        public static void onRenderPlayerPost(RenderPlayerEvent.Post event) {
            GauntletRender.renderingPlayer = false;
        }
    }
}
