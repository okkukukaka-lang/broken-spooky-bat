package com.shazammod.thanos;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * 0.62 Pengaturan Thanos, per world: serverconfig/shazammod-thanos-server.toml (ikut disinkronkan ke pemain yang join).
 * Semua angka bisa diubah tanpa build ulang.
 */
public final class ThanosConfig {
    private ThanosConfig() {}

    public static final ModConfigSpec SPEC;

    // ---------------------------------------------------------------- stat wujud Thanos
    public static final ModConfigSpec.DoubleValue HEALTH;
    public static final ModConfigSpec.DoubleValue ARMOR;
    public static final ModConfigSpec.DoubleValue TOUGHNESS;
    public static final ModConfigSpec.DoubleValue DAMAGE;
    public static final ModConfigSpec.DoubleValue KNOCKBACK;
    public static final ModConfigSpec.DoubleValue SPEED;
    public static final ModConfigSpec.DoubleValue JUMP;
    public static final ModConfigSpec.DoubleValue SCALE;
    public static final ModConfigSpec.DoubleValue REGEN;
    public static final ModConfigSpec.DoubleValue ENERGY_REGEN;
    public static final ModConfigSpec.BooleanValue REQUIRE_FORM;

    // ---------------------------------------------------------------- Pedang Dua Mata
    public static final ModConfigSpec.DoubleValue THROW_DAMAGE;
    public static final ModConfigSpec.IntValue PARRY_TICKS;
    public static final ModConfigSpec.DoubleValue GUARD_REDUCTION;

    // ---------------------------------------------------------------- Infinity Gauntlet
    public static final ModConfigSpec.DoubleValue COOLDOWN_MULT;
    public static final ModConfigSpec.DoubleValue COST_MULT;
    public static final ModConfigSpec.DoubleValue BEAM_DAMAGE;
    public static final ModConfigSpec.IntValue SPACE_RANGE;
    public static final ModConfigSpec.DoubleValue SKILL_DAMAGE;

    // ---------------------------------------------------------------- Jentikan
    public static final ModConfigSpec.IntValue SNAP_RADIUS;
    public static final ModConfigSpec.BooleanValue SNAP_HALF;
    public static final ModConfigSpec.IntValue SNAP_MAX_TARGETS;
    public static final ModConfigSpec.BooleanValue SNAP_PLAYERS;
    public static final ModConfigSpec.BooleanValue SNAP_CREATIVE;
    public static final ModConfigSpec.BooleanValue GOD_ONLY_IN_ARMOR;
    public static final ModConfigSpec.IntValue SNAP_COOLDOWN;

    // ---------------------------------------------------------------- 0.64 Kuasa Infinity (Thanos & PRALAYA)
    public static final ModConfigSpec.BooleanValue INF_BREAK_BLOCKS;
    public static final ModConfigSpec.IntValue CRATER_THANOS;
    public static final ModConfigSpec.IntValue CRATER_PRALAYA;
    public static final ModConfigSpec.BooleanValue INF_CHANGE_WORLD;
    public static final ModConfigSpec.IntValue REALITY_THANOS;
    public static final ModConfigSpec.IntValue REALITY_PRALAYA;
    public static final ModConfigSpec.IntValue REALITY_SECONDS;
    public static final ModConfigSpec.IntValue PORTAL_THANOS;
    public static final ModConfigSpec.IntValue PORTAL_PRALAYA;
    public static final ModConfigSpec.IntValue UNDEAD_THANOS;
    public static final ModConfigSpec.IntValue UNDEAD_PRALAYA;
    public static final ModConfigSpec.IntValue UNDEAD_SECONDS;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("Stat tambahan saat wujud Thanos (di atas pemain biasa)").push("stats");
        HEALTH = b.comment("Darah tambahan (2 = 1 hati)").defineInRange("bonusHealth", 40.0, 0.0, 1000.0);
        ARMOR = b.defineInRange("bonusArmor", 20.0, 0.0, 30.0);
        TOUGHNESS = b.defineInRange("bonusToughness", 12.0, 0.0, 20.0);
        DAMAGE = b.defineInRange("bonusAttackDamage", 8.0, 0.0, 100.0);
        KNOCKBACK = b.defineInRange("knockbackResistance", 1.0, 0.0, 1.0);
        SPEED = b.comment("0.2 = +20% kecepatan jalan").defineInRange("speedMultiplier", 0.0, -0.5, 2.0);
        JUMP = b.defineInRange("jumpBonus", 0.15, 0.0, 1.0);
        SCALE = b.comment("Lebih dari 0.1 = nggak muat pintu 2 blok").defineInRange("scaleBonus", 0.1, 0.0, 1.0);
        REGEN = b.comment("Darah yang pulih tiap 2 detik").defineInRange("regenPer2Seconds", 1.0, 0.0, 20.0);
        ENERGY_REGEN = b.comment("Energi Thanos (0-100) yang terisi tiap detik").defineInRange("energyRegenPerSecond", 5.0, 0.0, 100.0);
        REQUIRE_FORM = b.comment("true = pedang & gauntlet cuma berkekuatan dalam wujud Thanos")
                .define("requireThanosForm", true);
        b.pop();

        b.push("weapon");
        THROW_DAMAGE = b.defineInRange("throwDamage", 14.0, 0.0, 200.0);
        PARRY_TICKS = b.comment("Tick pertama menahan klik kanan yang menangkis penuh").defineInRange("parryWindowTicks", 8, 0, 40);
        GUARD_REDUCTION = b.comment("Sesudah jendela tangkis: damage dari depan berkurang segini").defineInRange("guardReduction", 0.6, 0.0, 1.0);
        b.pop();

        b.push("gauntlet");
        COOLDOWN_MULT = b.defineInRange("cooldownMultiplier", 1.0, 0.1, 10.0);
        COST_MULT = b.defineInRange("energyCostMultiplier", 1.0, 0.0, 10.0);
        BEAM_DAMAGE = b.defineInRange("powerBeamDamage", 16.0, 0.0, 200.0);
        SPACE_RANGE = b.defineInRange("spaceStepRange", 32, 4, 128);
        SKILL_DAMAGE = b.comment("Pengali damage semua kuasa batu & pedang (1 = biasa)").defineInRange("skillDamageMultiplier", 1.0, 0.1, 10.0);
        b.pop();

        b.comment("Jentikan (R): semua makhluk bisa lenyap, termasuk bos & pemain, kecuali pemain dengan juara dewa")
                .push("snap");
        SNAP_RADIUS = b.defineInRange("snapRadius", 48, 8, 256);
        SNAP_HALF = b.comment("true = separuh yang kena (acak), false = semuanya").define("snapHalf", true);
        SNAP_MAX_TARGETS = b.comment("Pengaman lag").defineInRange("snapMaxTargets", 150, 1, 2000);
        SNAP_PLAYERS = b.comment("Pemain ikut bisa lenyap (aturan PvP & tim server tetap berlaku)").define("snapHitPlayers", true);
        SNAP_CREATIVE = b.comment("Pemain mode Creative ikut bisa lenyap").define("snapHitCreative", false);
        GOD_ONLY_IN_ARMOR = b.comment("false = pemain yang PUNYA PRALAYA Fase Dewa (keenam inti) selalu kebal;",
                "true = cuma kebal selama armor Fase Dewa-nya sedang dipakai").define("godImmuneOnlyInArmor", false);
        SNAP_COOLDOWN = b.defineInRange("snapCooldownSeconds", 600, 0, 86400);
        b.pop();

        b.comment("Kuasa Infinity: Thanos Alt+Z/X/V/N, PRALAYA Alt+Shift+Z/X/V/N (versi PRALAYA lebih besar)").push("infinity");
        INF_BREAK_BLOCKS = b.comment("Ledakan Kawah benar-benar mencungkil tanah (false = efek saja)").define("craterBreaksBlocks", true);
        CRATER_THANOS = b.defineInRange("craterRadiusThanos", 14, 4, 48);
        CRATER_PRALAYA = b.comment("Fase Dewa: x1,25").defineInRange("craterRadiusPralaya", 24, 4, 64);
        INF_CHANGE_WORLD = b.comment("Tulis Ulang Dunia benar-benar mengubah blok (false = efek & makhluk saja)").define("rewriteChangesBlocks", true);
        REALITY_THANOS = b.defineInRange("rewriteRadiusThanos", 24, 6, 64);
        REALITY_PRALAYA = b.comment("Fase Dewa: x1,25").defineInRange("rewriteRadiusPralaya", 40, 6, 96);
        REALITY_SECONDS = b.comment("Lama dunia berubah sebelum kembali (PRALAYA x2). 0 = permanen").defineInRange("rewriteSeconds", 60, 0, 3600);
        PORTAL_THANOS = b.defineInRange("portalRangeThanos", 256, 16, 2048);
        PORTAL_PRALAYA = b.defineInRange("portalRangePralaya", 512, 16, 4096);
        UNDEAD_THANOS = b.defineInRange("undeadCountThanos", 6, 1, 24);
        UNDEAD_PRALAYA = b.comment("Fase Dewa: +4").defineInRange("undeadCountPralaya", 12, 1, 48);
        UNDEAD_SECONDS = b.comment("Lama undead hidup (PRALAYA x2)").defineInRange("undeadSeconds", 60, 5, 1800);
        b.pop();

        SPEC = b.build();
    }
}
