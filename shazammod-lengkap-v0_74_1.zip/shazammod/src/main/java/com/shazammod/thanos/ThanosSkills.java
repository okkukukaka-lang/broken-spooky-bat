package com.shazammod.thanos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;
import com.shazammod.thanos.entity.ThrownDoubleBlade;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.63 Kuasa THANOS. Tombolnya sama dengan PRALAYA: tiap batu satu tombol, dua kuasa (normal & Shift); kuasa batu cuma
 * terbuka kalau batunya sudah tercatat di Gauntlet DAN Gauntlet-nya ada di inventori. Tick puncak tiap kuasa = konstanta
 * ShazamAnim.TITAN_* (klip ThanosClips, efek ThanosFx, dan SFX thanos_* dikunci ke angka yang sama).
 *
 *   Z  Power    Tinju Daya (kerucut gelombang 8 blok)           | Shift: Ledakan Daya (nova 7 blok, musuh terlempar)
 *   X  Space    Langkah Kosmik (pindah lewat robekan ruang)       | Shift: Hujan Bulan (8 batu bulan dari langit)
 *   C  Mind     Belenggu Pikiran (mob jadi budakmu 12 dtk)        | Shift: Badai Pikiran (mob saling serang 8 dtk)
 *   V  Reality  Kenyataan Palsu (terbelit 3 dtk, lalu meledak)    | Shift: Badai Realitas (zona 9 blok 5 dtk)
 *   B  Time     Putar Balik (kembali ke 3 dtk lalu + darahnya)    | Shift: Henti Waktu (kubah 10 blok, 4 dtk beku)
 *   N  Soul     Panen Jiwa (kuras 10 blok, Thanos pulih)          | Shift: Perisai Jiwa (darah serap + memantulkan)
 *   R  JENTIKAN (keenam batu, lihat ThanosSnap)                   | Shift: Murka Titan (15 dtk: kuat, cepat, kebal)
 *   M  Putaran Pedang                                             | Shift: Lemparan Pedang
 *   J  Hantaman Titan (lompat, lalu menghantam tanah)             | Shift: Sinyal Batu
 */
public final class ThanosSkills {
    private ThanosSkills() {}

    // energi & cooldown (detik): {normal, shift} untuk Z..N
    private static final float[][] COST = {{15, 35}, {15, 45}, {25, 35}, {20, 40}, {25, 45}, {30, 30}};
    private static final int[][] COOLDOWN = {{4, 12}, {4, 25}, {14, 22}, {10, 24}, {16, 30}, {16, 24}};
    private static final float RAGE_COST = 40f, SPIN_COST = 12f, LEAP_COST = 25f;
    private static final int RAGE_CD = 90, SPIN_CD = 5, LEAP_CD = 10;
    private static final int HISTORY = 64;

    // ---------------------------------------------------------------- keadaan tiap pemain (nggak disimpan)

    private static final class Task {
        int delay;
        final Consumer<ServerPlayer> action;

        Task(int delay, Consumer<ServerPlayer> action) {
            this.delay = delay;
            this.action = action;
        }
    }

    private static final class Held {
        final LivingEntity entity;
        int ticks;

        Held(LivingEntity entity, int ticks) {
            this.entity = entity;
            this.ticks = ticks;
        }
    }

    private static final class State {
        int busy;
        final List<Task> tasks = new ArrayList<>();
        final double[] hx = new double[HISTORY], hy = new double[HISTORY], hz = new double[HISTORY];
        final float[] hh = new float[HISTORY];
        @SuppressWarnings("unchecked")
        final ResourceKey<Level>[] hd = new ResourceKey[HISTORY];
        int head, filled;
        final List<Held> thralls = new ArrayList<>();
        final List<Held> wraps = new ArrayList<>();
        final List<Mob> storm = new ArrayList<>();
        int mindTicks;
        Vec3 realityAt;
        int realityTicks;
        Vec3 domeAt;
        int domeTicks;
        final Set<Projectile> stopped = new HashSet<>();
        boolean leaping;
        int leapTicks;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    private static State state(ServerPlayer p) {
        return STATES.computeIfAbsent(p.getUUID(), id -> new State());
    }

    public static void clear(ServerPlayer p) {
        State s = STATES.remove(p.getUUID());
        if (s != null) {
            releaseStopped(s);
        }
    }

    public static boolean free(ServerPlayer p) {
        State s = STATES.get(p.getUUID());
        return s == null || s.busy <= 0;
    }

    public static void busy(ServerPlayer p, int ticks) {
        State s = state(p);
        s.busy = Math.max(s.busy, ticks);
    }

    /** Lepas status sibuk (Jentikan dibatalkan). */
    public static void release(ServerPlayer p) {
        State s = STATES.get(p.getUUID());
        if (s != null) {
            s.busy = 0;
        }
    }

    /** Jalankan action delay tick lagi (dibatalkan kalau pemainnya mati / keluar). */
    public static void later(ServerPlayer p, int delay, Consumer<ServerPlayer> action) {
        state(p).tasks.add(new Task(Math.max(1, delay), action));
    }

    // ---------------------------------------------------------------- tiap tick

    public static void tick(ServerPlayer p, ThanosData d) {
        State s = STATES.get(p.getUUID());
        if (d.bound) {
            if (s == null) {
                s = state(p);
            }
            int i = s.head;   // riwayat 3 detik untuk Putar Balik
            s.hx[i] = p.getX();
            s.hy[i] = p.getY();
            s.hz[i] = p.getZ();
            s.hh[i] = p.getHealth();
            s.hd[i] = p.level().dimension();
            s.head = (i + 1) % HISTORY;
            s.filled = Math.min(HISTORY, s.filled + 1);
        }
        if (s == null) {
            return;
        }
        if (s.busy > 0) {
            s.busy--;
        }
        if (!s.tasks.isEmpty()) {
            List<Task> due = new ArrayList<>();
            Iterator<Task> it = s.tasks.iterator();
            while (it.hasNext()) {
                Task t = it.next();
                if (--t.delay <= 0) {
                    due.add(t);
                    it.remove();
                }
            }
            for (Task t : due) {
                if (p.isAlive() && !p.isRemoved()) {
                    t.action.accept(p);
                }
            }
        }
        tickThralls(p, s);
        tickWraps(p, s);
        tickMindstorm(p, s);
        tickReality(p, s);
        tickDome(p, s);
        tickLeap(p, s);
    }

    // ---------------------------------------------------------------- syarat

    private static boolean ready(ServerPlayer p, ThanosData d, StoneType stone, int slot, float cost) {
        if (!free(p) || d.snapCharge > 0) {
            return false;
        }
        if (stone != null) {
            if (!d.has(stone)) {
                ThanosAbilities.msg(p, "stone_missing", ChatFormatting.GRAY, ThanosAbilities.stoneName(stone));
                return false;
            }
            if (!ThanosAbilities.hasGauntlet(p)) {
                ThanosAbilities.msg(p, "no_gauntlet", ChatFormatting.GRAY);
                return false;
            }
        }
        if (d.cooldowns[slot] > 0) {
            ThanosAbilities.msg(p, "cooldown", ChatFormatting.RED, (d.cooldowns[slot] + 19) / 20);
            return false;
        }
        float need = (float) (cost * ThanosConfig.COST_MULT.get());
        if (!p.getAbilities().instabuild && d.energy < need) {
            ThanosAbilities.msg(p, "no_energy", ChatFormatting.RED, Math.round(d.energy), Math.round(need));
            return false;
        }
        return true;
    }

    private static void spend(ServerPlayer p, ThanosData d, int slot, float cost, int cooldownSec) {
        if (!p.getAbilities().instabuild) {
            d.energy = Math.max(0f, d.energy - (float) (cost * ThanosConfig.COST_MULT.get()));
        }
        d.cooldowns[slot] = (int) Math.round(cooldownSec * 20.0 * ThanosConfig.COOLDOWN_MULT.get());
    }

    // ---------------------------------------------------------------- tombol batu

    /** Z..N (index 0-5), shift = kuasa kedua. */
    public static void stone(ServerPlayer p, ThanosData d, int index, boolean shift) {
        StoneType stone = StoneType.byIndex(index);
        int slot = stone.ordinal() + (shift ? ThanosData.SLOT_SHIFT : 0);
        float cost = COST[stone.ordinal()][shift ? 1 : 0];
        if (!ready(p, d, stone, slot, cost)) {
            return;
        }
        boolean ok = switch (stone) {
            case POWER -> shift ? nova(p) : punch(p);
            case SPACE -> shift ? moon(p) : step(p);
            case MIND -> shift ? mindstorm(p) : mind(p);
            case REALITY -> shift ? realityStorm(p) : wrap(p);
            case TIME -> shift ? timestop(p) : rewind(p);
            case SOUL -> shift ? shield(p, d) : harvest(p);
        };
        if (ok) {
            spend(p, d, slot, cost, COOLDOWN[stone.ordinal()][shift ? 1 : 0]);
        } else {
            ThanosAbilities.msg(p, "no_target", ChatFormatting.GRAY);
        }
    }

    // Z  Tinju Daya
    private static boolean punch(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_PUNCH);
        sound(p, p.position(), ShazamSounds.THANOS_POWER_PUNCH.get(), 1.8f);
        busy(p, ShazamAnim.TITAN_PUNCH_HIT + 4);
        later(p, ShazamAnim.TITAN_PUNCH_HIT, sp -> {
            Vec3 eye = sp.getEyePosition();
            Vec3 look = sp.getLookAngle();
            for (LivingEntity e : enemies(sp, 8.5)) {
                Vec3 to = e.position().add(0, e.getBbHeight() * 0.5, 0).subtract(eye);
                double dist = to.length();
                if (dist > 8.5 || (dist > 1.8 && to.normalize().dot(look) < 0.55)) {
                    continue;
                }
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 16f * (float) (1.0 - dist / 14.0)));
                e.push(look.x * 2.2, 0.45, look.z * 2.2);
                e.hurtMarked = true;
            }
        });
        return true;
    }

    // Shift+Z  Ledakan Daya
    private static boolean nova(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_NOVA);
        sound(p, p.position(), ShazamSounds.THANOS_POWER_NOVA.get(), 2.6f);
        busy(p, ShazamAnim.TITAN_NOVA_HIT + 8);
        later(p, ShazamAnim.TITAN_NOVA_HIT, sp -> {
            for (LivingEntity e : enemies(sp, 7.5)) {
                double dist = e.distanceTo(sp);
                if (dist > 7.5) {
                    continue;
                }
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 22f * (float) (1.0 - dist / 10.0)));
                Vec3 away = flat(e.position().subtract(sp.position()));
                e.push(away.x * 1.6, 0.9, away.z * 1.6);
                e.hurtMarked = true;
            }
            sp.resetFallDistance();
        });
        return true;
    }

    // X  Langkah Kosmik
    private static boolean step(ServerPlayer p) {
        Vec3 dest = safeAim(p, ThanosConfig.SPACE_RANGE.get());
        if (dest == null) {
            return false;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_STEP, dest);
        sound(p, p.position(), ShazamSounds.THANOS_SPACE_STEP.get(), 1.6f);
        busy(p, ShazamAnim.TITAN_STEP_AT + 2);
        later(p, ShazamAnim.TITAN_STEP_AT, sp -> {
            if (!sp.level().noCollision(sp, sp.getBoundingBox().move(dest.subtract(sp.position())))) {
                return;
            }
            sp.teleportTo(dest.x, dest.y, dest.z);
            sp.resetFallDistance();
            sound(sp, dest, ShazamSounds.THANOS_SPACE_STEP.get(), 1.6f);
            for (LivingEntity e : enemies(sp, 3.5)) {
                e.hurt(magic(sp), dmg(sp, 8f));
                Vec3 away = flat(e.position().subtract(dest));
                e.push(away.x * 1.2, 0.4, away.z * 1.2);
                e.hurtMarked = true;
            }
        });
        return true;
    }

    // Shift+X  Hujan Bulan
    private static boolean moon(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        HitResult hit = p.pick(48.0, 1.0f, false);
        Vec3 c = hit.getLocation();
        if (hit.getType() != HitResult.Type.BLOCK) {
            Vec3 ahead = p.position().add(flat(p.getLookAngle()).scale(18.0));
            c = new Vec3(ahead.x, level.getHeight(Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(ahead.x),
                    (int) Math.floor(ahead.z)), ahead.z);
        }
        final Vec3 center = c;
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_MOON, center);
        sound(p, p.position(), ShazamSounds.THANOS_MOON_RIFT.get(), 2.0f);
        busy(p, ShazamAnim.TITAN_MOON_OPEN + 10);
        later(p, ShazamAnim.TITAN_MOON_OPEN, sp -> sound(sp, center.add(0, 20, 0), ShazamSounds.THANOS_MOON_RIFT.get(), 3.5f));
        for (int i = 0; i < ShazamAnim.TITAN_MOON_COUNT; i++) {
            final boolean first = i == 0;
            later(p, ShazamAnim.TITAN_MOON_FIRST + i * ShazamAnim.TITAN_MOON_GAP, sp -> {
                double a = sp.getRandom().nextDouble() * Math.PI * 2.0, r = first ? 0.0 : 1.5 + sp.getRandom().nextDouble() * 5.0;
                int x = (int) Math.floor(center.x + Math.cos(a) * r), z = (int) Math.floor(center.z + Math.sin(a) * r);
                Vec3 at = new Vec3(x + 0.5, sp.serverLevel().getHeight(Heightmap.Types.MOTION_BLOCKING, x, z), z + 0.5);
                ShazamNetwork.playAnim(sp, ShazamAnim.TITAN_METEOR, at);
                sp.serverLevel().playSound(null, at.x, at.y, at.z, ShazamSounds.THANOS_METEOR.get(), SoundSource.PLAYERS, 3.0f,
                        0.9f + sp.getRandom().nextFloat() * 0.2f);
                later(sp, ShazamAnim.TITAN_METEOR_FALL, sp2 -> meteorImpact(sp2, at));
            });
        }
        return true;
    }

    private static void meteorImpact(ServerPlayer p, Vec3 at) {
        for (LivingEntity e : p.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(at, at).inflate(4.0),
                e -> valid(p, e))) {
            double dist = e.position().distanceTo(at);
            if (dist > 4.0) {
                continue;
            }
            e.invulnerableTime = 0;
            e.hurt(p.damageSources().explosion(p, p), dmg(p, 14f * (float) (1.0 - dist / 6.0)));
            e.igniteForSeconds(3);
            Vec3 away = flat(e.position().subtract(at));
            e.push(away.x * 1.0, 0.6, away.z * 1.0);
            e.hurtMarked = true;
        }
        p.serverLevel().sendParticles(ParticleTypes.EXPLOSION, at.x, at.y + 0.5, at.z, 2, 0.6, 0.3, 0.6, 0.0);
    }

    // C  Belenggu Pikiran
    private static boolean mind(ServerPlayer p) {
        LivingEntity target = aimed(p, 24.0);
        if (target == null) {
            return false;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_MIND, chest(target));
        sound(p, p.position(), ShazamSounds.THANOS_MIND.get(), 1.6f);
        busy(p, ShazamAnim.TITAN_MIND_HIT + 4);
        later(p, ShazamAnim.TITAN_MIND_HIT, sp -> {
            if (!target.isAlive() || target.distanceTo(sp) > 30.0) {
                return;
            }
            ShazamNetwork.playAnim(sp, ShazamAnim.TITAN_THRALL, chest(target));
            target.hurt(magic(sp), dmg(sp, 4f));
            if (target instanceof Mob mob) {
                State s = state(sp);
                s.thralls.removeIf(h -> h.entity == mob);
                s.thralls.add(new Held(mob, ShazamAnim.TITAN_THRALL_TICKS));
                mob.setTarget(null);
                mob.addEffect(new MobEffectInstance(MobEffects.GLOWING, ShazamAnim.TITAN_THRALL_TICKS, 0), sp);
            } else {
                target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 160, 0), sp);
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 1), sp);
                target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0), sp);
                target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 0), sp);
            }
        });
        return true;
    }

    private static void tickThralls(ServerPlayer p, State s) {
        if (s.thralls.isEmpty()) {
            return;
        }
        Iterator<Held> it = s.thralls.iterator();
        while (it.hasNext()) {
            Held h = it.next();
            if (--h.ticks <= 0 || !h.entity.isAlive() || h.entity.level() != p.level()) {
                if (h.entity instanceof Mob mob && mob.getTarget() != null && !(mob.getTarget() instanceof Player)) {
                    mob.setTarget(null);
                }
                it.remove();
                continue;
            }
            if (h.ticks % 5 == 0 && h.entity instanceof Mob mob) {
                LivingEntity t = mob.getTarget();
                if (t == null || t == p || !t.isAlive() || t instanceof Player || isThrall(s, t)) {
                    mob.setTarget(nearestFoe(p, s, mob));
                }
            }
        }
    }

    private static boolean isThrall(State s, LivingEntity e) {
        for (Held h : s.thralls) {
            if (h.entity == e) {
                return true;
            }
        }
        return false;
    }

    private static LivingEntity nearestFoe(ServerPlayer owner, State s, Mob thrall) {
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (Mob m : thrall.level().getEntitiesOfClass(Mob.class, thrall.getBoundingBox().inflate(16.0),
                m -> m != thrall && m.isAlive() && m instanceof Enemy && !isThrall(s, m))) {
            double dist = m.distanceToSqr(thrall);
            if (dist < bd) {
                bd = dist;
                best = m;
            }
        }
        return best;
    }

    // Shift+C  Badai Pikiran
    private static boolean mindstorm(ServerPlayer p) {
        List<Mob> mobs = p.serverLevel().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(14.0), m -> valid(p, m));
        boolean players = false;
        for (LivingEntity e : enemies(p, 10.0)) {
            players |= e instanceof Player;
        }
        if (mobs.size() < 2 && !players) {
            return false;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_MINDSTORM);
        sound(p, p.position(), ShazamSounds.THANOS_MINDSTORM.get(), 2.0f);
        busy(p, ShazamAnim.TITAN_MINDSTORM_HIT + 4);
        later(p, ShazamAnim.TITAN_MINDSTORM_HIT, sp -> {
            State s = state(sp);
            s.storm.clear();
            for (Mob m : sp.serverLevel().getEntitiesOfClass(Mob.class, sp.getBoundingBox().inflate(14.0), m -> valid(sp, m))) {
                s.storm.add(m);
                m.addEffect(new MobEffectInstance(MobEffects.GLOWING, ShazamAnim.TITAN_MINDSTORM_TICKS, 0), sp);
            }
            s.mindTicks = ShazamAnim.TITAN_MINDSTORM_TICKS;
            retargetStorm(s);
            for (LivingEntity e : enemies(sp, 10.0)) {
                if (e instanceof Player) {
                    e.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0), sp);
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 0), sp);
                }
            }
        });
        return true;
    }

    private static void retargetStorm(State s) {
        s.storm.removeIf(m -> !m.isAlive());
        int n = s.storm.size();
        if (n < 2) {
            return;
        }
        for (int i = 0; i < n; i++) {
            s.storm.get(i).setTarget(s.storm.get((i + 1) % n));
        }
    }

    private static void tickMindstorm(ServerPlayer p, State s) {
        if (s.mindTicks <= 0) {
            return;
        }
        if (--s.mindTicks % 20 == 0) {
            retargetStorm(s);
        }
        if (s.mindTicks == 0) {
            for (Mob m : s.storm) {
                if (m.isAlive()) {
                    m.setTarget(null);
                }
            }
            s.storm.clear();
        }
    }

    // V  Kenyataan Palsu
    private static boolean wrap(ServerPlayer p) {
        LivingEntity target = aimed(p, 24.0);
        if (target == null) {
            return false;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_WRAP, chest(target));
        sound(p, p.position(), ShazamSounds.THANOS_REALITY_WRAP.get(), 1.6f);
        busy(p, ShazamAnim.TITAN_WRAP_HIT + 4);
        later(p, ShazamAnim.TITAN_WRAP_HIT, sp -> {
            if (!target.isAlive() || target.distanceTo(sp) > 30.0) {
                return;
            }
            target.hurt(magic(sp), dmg(sp, 6f));
            State s = state(sp);
            s.wraps.removeIf(h -> h.entity == target);
            s.wraps.add(new Held(target, ShazamAnim.TITAN_WRAP_HOLD));
        });
        return true;
    }

    private static void tickWraps(ServerPlayer p, State s) {
        if (s.wraps.isEmpty()) {
            return;
        }
        Iterator<Held> it = s.wraps.iterator();
        while (it.hasNext()) {
            Held h = it.next();
            LivingEntity e = h.entity;
            if (!e.isAlive() || e.level() != p.level()) {
                it.remove();
                continue;
            }
            if (h.ticks % 5 == 0) {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 9, false, false), p);
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 10, 2, false, false), p);
                e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 10, 4, false, false), p);
            }
            Vec3 v = e.getDeltaMovement();
            e.setDeltaMovement(0.0, Math.min(0.0, v.y), 0.0);
            if (--h.ticks <= 0) {
                it.remove();
                Vec3 at = chest(e);
                ShazamNetwork.playAnim(p, ShazamAnim.TITAN_WRAP_BURST, at);
                sound(p, at, ShazamSounds.THANOS_REALITY_BURST.get(), 1.8f);
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, 18f));
                e.push(0.0, 0.6, 0.0);
                e.hurtMarked = true;
            }
        }
    }

    // Shift+V  Badai Realitas
    private static boolean realityStorm(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_REALITY);
        sound(p, p.position(), ShazamSounds.THANOS_REALITY_STORM.get(), 2.0f);
        busy(p, ShazamAnim.TITAN_REALITY_HIT + 4);
        later(p, ShazamAnim.TITAN_REALITY_HIT, sp -> {
            State s = state(sp);
            s.realityAt = sp.position();
            s.realityTicks = ShazamAnim.TITAN_REALITY_TICKS;
        });
        return true;
    }

    private static void tickReality(ServerPlayer p, State s) {
        if (s.realityTicks <= 0 || s.realityAt == null) {
            return;
        }
        s.realityTicks--;
        ServerLevel level = p.serverLevel();
        AABB box = new AABB(s.realityAt, s.realityAt).inflate(9.0);
        for (Projectile pr : level.getEntitiesOfClass(Projectile.class, box, x -> x.getOwner() != p)) {
            if (pr.position().distanceTo(s.realityAt) > 9.0) {
                continue;
            }
            level.sendParticles(ParticleTypes.BUBBLE_POP, pr.getX(), pr.getY(), pr.getZ(), 8, 0.2, 0.2, 0.2, 0.0);
            if (pr instanceof ThrownTrident || pr instanceof ThrownDoubleBlade) {
                pr.setDeltaMovement(Vec3.ZERO);   // barang milik orang: cuma dihentikan
            } else {
                pr.discard();
            }
        }
        if (s.realityTicks % 10 == 0) {
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> valid(p, e))) {
                if (e.position().distanceTo(s.realityAt) > 9.0) {
                    continue;
                }
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, 3f));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 1), p);
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 30, 0), p);
                if (e instanceof Mob mob && mob.getTarget() == p) {
                    mob.setTarget(null);   // kenyataan berubah: musuh kehilangan jejak
                }
            }
        }
    }

    // B  Putar Balik
    private static boolean rewind(ServerPlayer p) {
        State s = state(p);
        int back = ShazamAnim.TITAN_REWIND_BACK;
        if (s.filled <= back) {
            return false;
        }
        int i = Math.floorMod(s.head - 1 - back, HISTORY);
        if (s.hd[i] != p.level().dimension()) {
            return false;
        }
        Vec3 old = new Vec3(s.hx[i], s.hy[i], s.hz[i]);
        float oldHealth = s.hh[i];
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_REWIND, old);
        sound(p, p.position(), ShazamSounds.THANOS_REWIND.get(), 1.6f);
        busy(p, ShazamAnim.TITAN_REWIND_AT + 4);
        later(p, ShazamAnim.TITAN_REWIND_AT, sp -> {
            if (sp.level().dimension() == s.hd[i] && sp.level().noCollision(sp, sp.getBoundingBox().move(old.subtract(sp.position())))) {
                sp.teleportTo(old.x, old.y, old.z);
                sp.resetFallDistance();
            }
            sp.setHealth(Math.max(sp.getHealth(), Math.min(sp.getMaxHealth(), oldHealth)));
            sp.clearFire();
            sound(sp, sp.position(), ShazamSounds.THANOS_REWIND.get(), 1.2f);
        });
        return true;
    }

    // Shift+B  Henti Waktu
    private static boolean timestop(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_TIMESTOP);
        sound(p, p.position(), ShazamSounds.THANOS_TIMESTOP.get(), 2.2f);
        busy(p, ShazamAnim.TITAN_TIMESTOP_HIT + 4);
        later(p, ShazamAnim.TITAN_TIMESTOP_HIT, sp -> {
            State s = state(sp);
            releaseStopped(s);
            s.domeAt = sp.position();
            s.domeTicks = ShazamAnim.TITAN_TIMESTOP_TICKS;
        });
        return true;
    }

    private static void tickDome(ServerPlayer p, State s) {
        if (s.domeTicks <= 0 || s.domeAt == null) {
            return;
        }
        ServerLevel level = p.serverLevel();
        AABB box = new AABB(s.domeAt, s.domeAt).inflate(10.0);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> valid(p, e))) {
            if (e.position().distanceTo(s.domeAt) > 10.0) {
                continue;
            }
            e.setDeltaMovement(Vec3.ZERO);
            e.hurtMarked = true;
            if (s.domeTicks % 5 == 0) {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 8, 9, false, false), p);
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 8, 10, false, false), p);
                e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 8, 4, false, false), p);
            }
            if (e instanceof Mob mob) {
                mob.getNavigation().stop();
            }
        }
        for (Projectile pr : level.getEntitiesOfClass(Projectile.class, box, x -> x.getOwner() != p)) {
            if (pr.position().distanceTo(s.domeAt) <= 10.0 && s.stopped.add(pr)) {
                pr.setNoGravity(true);
            }
            pr.setDeltaMovement(Vec3.ZERO);
        }
        if (--s.domeTicks <= 0) {
            releaseStopped(s);
            s.domeAt = null;
        }
    }

    private static void releaseStopped(State s) {
        for (Projectile pr : s.stopped) {
            if (pr.isAlive()) {
                pr.setNoGravity(false);
            }
        }
        s.stopped.clear();
    }

    // N  Panen Jiwa
    private static boolean harvest(ServerPlayer p) {
        if (enemies(p, 10.0).isEmpty()) {
            return false;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_HARVEST);
        sound(p, p.position(), ShazamSounds.THANOS_SOUL_HARVEST.get(), 2.0f);
        busy(p, ShazamAnim.TITAN_HARVEST_HIT + ShazamAnim.TITAN_HARVEST_TICKS);
        for (int k = 0; k < 5; k++) {
            later(p, ShazamAnim.TITAN_HARVEST_HIT + k * 8, sp -> {
                int n = 0;
                for (LivingEntity e : enemies(sp, 10.0)) {
                    e.invulnerableTime = 0;
                    if (e.hurt(magic(sp), dmg(sp, 3.5f))) {
                        n++;
                    }
                }
                sp.heal(Math.min(4f, n * 1.5f));
            });
        }
        later(p, ShazamAnim.TITAN_HARVEST_HIT + ShazamAnim.TITAN_HARVEST_TICKS, sp -> {
            for (LivingEntity e : enemies(sp, 10.0)) {
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 6f));
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1), sp);
            }
        });
        return true;
    }

    // Shift+N  Perisai Jiwa
    private static boolean shield(ServerPlayer p, ThanosData d) {
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_SHIELD);
        sound(p, p.position(), ShazamSounds.THANOS_SOUL_SHIELD.get(), 1.8f);
        busy(p, ShazamAnim.TITAN_SHIELD_HIT + 4);
        later(p, ShazamAnim.TITAN_SHIELD_HIT, sp -> {
            ThanosData data = ThanosAbilities.data(sp);
            data.shieldTicks = ShazamAnim.TITAN_SHIELD_TICKS;
            sp.setAbsorptionAmount(Math.max(sp.getAbsorptionAmount(), 20f));
            sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, ShazamAnim.TITAN_SHIELD_TICKS, 0));
            ThanosNetwork.broadcastState(sp);
        });
        return true;
    }

    /** Selama Perisai Jiwa: 35% damage dari penyerang dipantulkan ke penyerangnya. */
    private static boolean reflecting;

    public static void reflect(ServerPlayer p, LivingEntity attacker, float amount) {
        if (reflecting || attacker == p || !attacker.isAlive() || amount <= 0f) {
            return;   // pantulan nggak dipantulkan lagi (dua Perisai Jiwa saling serang)
        }
        reflecting = true;
        try {
            attacker.hurt(magic(p), amount * 0.35f);
        } finally {
            reflecting = false;
        }
    }

    // ---------------------------------------------------------------- R, M, J

    /** Shift+R Murka Titan. */
    public static void rage(ServerPlayer p, ThanosData d) {
        if (!ready(p, d, null, ThanosData.SLOT_RAGE, RAGE_COST)) {
            return;
        }
        spend(p, d, ThanosData.SLOT_RAGE, RAGE_COST, RAGE_CD);
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_RAGE);
        sound(p, p.position(), ShazamSounds.THANOS_RAGE.get(), 2.6f);
        busy(p, ShazamAnim.TITAN_RAGE_HIT + 6);
        later(p, ShazamAnim.TITAN_RAGE_HIT, sp -> {
            int t = ShazamAnim.TITAN_RAGE_TICKS;
            ThanosAbilities.data(sp).rageTicks = t;
            sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, t, 1));
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, t, 0));
            sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, t, 0));
            sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, t, 0));
            for (LivingEntity e : enemies(sp, 6.0)) {
                Vec3 away = flat(e.position().subtract(sp.position()));
                e.push(away.x * 1.4, 0.35, away.z * 1.4);
                e.hurtMarked = true;
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0), sp);
            }
            ThanosNetwork.broadcastState(sp);
        });
    }

    /** M Putaran Pedang. */
    public static void spin(ServerPlayer p, ThanosData d) {
        if (!p.getMainHandItem().is(ThanosRegistry.DOUBLE_BLADE.get())) {
            ThanosAbilities.msg(p, "no_blade", ChatFormatting.GRAY);
            return;
        }
        if (!ready(p, d, null, ThanosData.SLOT_SPIN, SPIN_COST)) {
            return;
        }
        spend(p, d, ThanosData.SLOT_SPIN, SPIN_COST, SPIN_CD);
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_SPIN);
        sound(p, p.position(), ShazamSounds.THANOS_SPIN.get(), 1.4f);
        busy(p, ShazamAnim.TITAN_SPIN_HIT + 4);
        later(p, ShazamAnim.TITAN_SPIN_HIT, sp -> {
            for (LivingEntity e : enemies(sp, 4.5)) {
                e.invulnerableTime = 0;
                e.hurt(sp.damageSources().playerAttack(sp), dmg(sp, 12f));
                Vec3 away = flat(e.position().subtract(sp.position()));
                e.push(away.x * 1.3, 0.3, away.z * 1.3);
                e.hurtMarked = true;
            }
        });
    }

    /** Shift+M atau Shift + klik kanan pedang: Lemparan Pedang (kembali sendiri). */
    public static void throwBlade(ServerPlayer p, InteractionHand hand) {
        ItemStack stack = p.getItemInHand(hand);
        if (!stack.is(ThanosRegistry.DOUBLE_BLADE.get())) {
            ThanosAbilities.msg(p, "no_blade", ChatFormatting.GRAY);
            return;
        }
        if (!free(p) || ThanosAbilities.data(p).snapCharge > 0 || p.getCooldowns().isOnCooldown(stack.getItem())) {
            return;
        }
        p.getCooldowns().addCooldown(stack.getItem(), 40);
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_THROW);
        busy(p, ShazamAnim.TITAN_THROW_AT + 2);
        later(p, ShazamAnim.TITAN_THROW_AT, sp -> {
            ItemStack held = sp.getItemInHand(hand);
            if (!held.is(ThanosRegistry.DOUBLE_BLADE.get())) {
                return;
            }
            ThrownDoubleBlade blade = new ThrownDoubleBlade(sp.level(), sp, held.copy());
            blade.shootFromRotation(sp, sp.getXRot(), sp.getYRot(), 0.0f, 2.2f, 0.5f);
            sp.level().addFreshEntity(blade);
            sound(sp, sp.position(), ShazamSounds.THANOS_THROW.get(), 1.2f);
            if (!sp.getAbilities().instabuild) {
                sp.setItemInHand(hand, ItemStack.EMPTY);
            }
        });
    }

    /** J Hantaman Titan: melompat, lalu menghantam tanah saat mendarat. */
    public static void leap(ServerPlayer p, ThanosData d) {
        if (!ready(p, d, null, ThanosData.SLOT_LEAP, LEAP_COST)) {
            return;
        }
        spend(p, d, ThanosData.SLOT_LEAP, LEAP_COST, LEAP_CD);
        ShazamNetwork.playAnim(p, ShazamAnim.THANOS_LEAP);
        sound(p, p.position(), ShazamSounds.THANOS_LEAP.get(), 1.4f);
        busy(p, ShazamAnim.TITAN_LEAP_JUMP + 6);
        later(p, ShazamAnim.TITAN_LEAP_JUMP, sp -> {
            Vec3 f = flat(sp.getLookAngle());
            sp.setDeltaMovement(f.x * 1.3, 1.05, f.z * 1.3);
            sp.hurtMarked = true;
            State s = state(sp);
            s.leaping = true;
            s.leapTicks = 0;
        });
    }

    private static void tickLeap(ServerPlayer p, State s) {
        if (!s.leaping) {
            return;
        }
        s.leapTicks++;
        p.resetFallDistance();
        if ((s.leapTicks > 4 && p.onGround()) || s.leapTicks > 50 || p.isInWater()) {
            s.leaping = false;
            Vec3 at = p.position();
            ShazamNetwork.playAnim(p, ShazamAnim.TITAN_SLAM, at);
            sound(p, at, ShazamSounds.THANOS_SLAM.get(), 2.4f);
            for (LivingEntity e : enemies(p, 6.0)) {
                double dist = e.distanceTo(p);
                if (dist > 6.0) {
                    continue;
                }
                e.invulnerableTime = 0;
                e.hurt(p.damageSources().playerAttack(p), dmg(p, 16f * (float) (1.0 - dist / 9.0)));
                Vec3 away = flat(e.position().subtract(at));
                e.push(away.x * 1.1, 0.7, away.z * 1.1);
                e.hurtMarked = true;
            }
        }
    }

    /** Shift+J Sinyal Batu. */
    public static void signal(ServerPlayer p, ThanosData d) {
        if (d.cooldowns[ThanosData.SLOT_SIGNAL] > 0) {
            return;
        }
        d.cooldowns[ThanosData.SLOT_SIGNAL] = 20;
        ThanosSanctum.showSignal(p);
    }

    // ---------------------------------------------------------------- bantuan

    static float dmg(ServerPlayer p, float base) {
        float rage = ThanosAbilities.data(p).rageTicks > 0 ? 1.3f : 1f;
        return Math.max(0f, base) * ThanosConfig.SKILL_DAMAGE.get().floatValue() * rage;
    }

    static DamageSource magic(ServerPlayer p) {
        return p.damageSources().indirectMagic(p, p);
    }

    static void sound(ServerPlayer p, Vec3 at, SoundEvent sound, float volume) {
        p.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume, 1f);
    }

    static Vec3 chest(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.62, 0);
    }

    static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : f.normalize();
    }

    /** Sasaran kuasa (bukan Jentikan): bukan diri sendiri, kawan, peliharaan sendiri, budak pikiran; pemain kalau PvP nyala. */
    static boolean valid(ServerPlayer p, LivingEntity e) {
        if (e == p || !e.isAlive() || e instanceof ArmorStand || p.isAlliedTo(e)) {
            return false;
        }
        if (e instanceof TamableAnimal pet && pet.isOwnedBy(p)) {
            return false;
        }
        State s = STATES.get(p.getUUID());
        if (s != null && isThrall(s, e)) {
            return false;
        }
        return !(e instanceof Player) || p.server.isPvpAllowed();
    }

    static List<LivingEntity> enemies(ServerPlayer p, double radius) {
        return p.serverLevel().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(radius), e -> valid(p, e));
    }

    /** Musuh yang dibidik (paling dekat ke garis pandang, terlihat langsung), atau null. */
    static LivingEntity aimed(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestScore = -1.0;
        for (LivingEntity e : enemies(p, range)) {
            Vec3 to = chest(e).subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.01) {
                continue;
            }
            double dot = to.normalize().dot(look);
            double need = Math.max(0.9, 0.995 - 0.6 / dist);   // makin dekat makin longgar
            if (dot < need || !p.hasLineOfSight(e)) {
                continue;
            }
            double score = dot - dist * 0.002;
            if (score > bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    /** Titik tujuan aman sejauh range di arah bidikan (mundur sampai 4 blok kalau tujuannya sesak), atau null. */
    static Vec3 safeAim(ServerPlayer p, double range) {
        HitResult hit = p.pick(range, 1.0f, false);
        Vec3 to = hit.getLocation();
        if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult block) {
            BlockPos above = block.getBlockPos().relative(block.getDirection());
            to = Vec3.atBottomCenterOf(above);
        }
        Vec3 back = flat(p.getLookAngle()).scale(-1.0);
        for (int i = 0; i <= 4; i++) {
            Vec3 c = to.add(back.scale(i));
            if (p.level().noCollision(p, p.getBoundingBox().move(c.subtract(p.position())))) {
                return c;
            }
        }
        return null;
    }
}
