package com.shazammod.thanos.client.gauntlet;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;

/** 0.65 Infinity Gauntlet 3D yang dipakai di lengan pemain (lihat GauntletRender.wornArm). */
public class GauntletLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public GauntletLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, AbstractClientPlayer player,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw,
                       float headPitch) {
        try {
            GauntletRender.renderWorn(poseStack, buffer, packedLight, player, getParentModel(), partialTick);
        } catch (Throwable ignored) {
            // efek tambahan: jangan sampai menjatuhkan render pemain
        }
    }
}
