package com.shazammod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.shazammod.relativa.RelativaPhase;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * 0.69 Terowongan Kuantum RELATIVA (tombol I): tembok, blok, & benda nggak menahan gerak mendatar, lantai tetap menahan
 * kecuali sedang tenggelam / naik. Aturannya di RelativaPhase.tunnel. require = 0: kalau nama metodenya berubah di versi
 * lain, cuma fitur tembus blok yang nggak jalan, game-nya tetap bisa dibuka.
 */
@Mixin(Entity.class)
public abstract class RelativaTunnelMixin {
    @Inject(method = "collide(Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3;", at = @At("RETURN"),
            cancellable = true, require = 0)
    private void shazammod$quantumTunnel(Vec3 wanted, CallbackInfoReturnable<Vec3> cir) {
        if ((Object) this instanceof Player player && RelativaPhase.tunnels(player)) {
            cir.setReturnValue(RelativaPhase.tunnel(player, wanted, cir.getReturnValue()));
        }
    }
}
