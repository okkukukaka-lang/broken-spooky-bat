package com.shazammod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.shazammod.relativa.RelativaPhase;

import net.minecraft.client.player.LocalPlayer;

/**
 * 0.69 Terowongan Kuantum: pemain lokal yang sedang di dalam tembok nggak didorong keluar ke ruang kosong terdekat
 * (Minecraft biasanya mendorong pemain yang terjepit di dalam blok). require = 0 supaya game tetap jalan kalau nama
 * metodenya berubah.
 */
@Mixin(LocalPlayer.class)
public abstract class RelativaPushOutMixin {
    @Inject(method = "moveTowardsClosestSpace(DD)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void shazammod$stayInsideWall(double x, double z, CallbackInfo ci) {
        if (RelativaPhase.tunnels((LocalPlayer) (Object) this)) {
            ci.cancel();
        }
    }
}
