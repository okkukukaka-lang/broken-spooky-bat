package com.shazammod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.shazammod.relativa.RelativaPhase;

import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;

/**
 * 0.69 Terowongan Kuantum: di dalam tembok badan tetap berdiri tegak (Minecraft biasanya memaksa jongkok / merangkak kalau
 * badan nggak muat di antara blok). require = 0 supaya game tetap jalan kalau nama metodenya berubah.
 */
@Mixin(Player.class)
public abstract class RelativaPoseMixin {
    @Inject(method = "canPlayerFitWithinBlocksAndEntitiesWhen(Lnet/minecraft/world/entity/Pose;)Z", at = @At("HEAD"),
            cancellable = true, require = 0)
    private void shazammod$fitWhileTunnelling(Pose pose, CallbackInfoReturnable<Boolean> cir) {
        if (RelativaPhase.tunnels((Player) (Object) this)) {
            cir.setReturnValue(true);
        }
    }
}
