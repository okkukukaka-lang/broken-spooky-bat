package com.shazammod.kaldera;

import javax.annotation.Nullable;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * 0.73 Satu bagian tubuh KALDERA yang bisa dipukul & ditembak (kepala, badan depan, badan belakang, kawah, empat kaki).
 * Tubuhnya sebesar gunung, jadi satu kotak tabrakan nggak cukup: tiap bagian punya kotak sendiri yang ikut bergerak, dan
 * damage-nya diteruskan ke Kaldera (dengan pengali: kepala & kawah yang terbuka lebih rapuh, kaki batunya paling keras).
 */
public class KalderaPart extends PartEntity<Kaldera> {
    public enum Kind { HEAD, BODY, CORE, LEG }

    public final Kind kind;
    private final EntityDimensions size;

    public KalderaPart(Kaldera parent, Kind kind, float width, float height) {
        super(parent);
        this.kind = kind;
        this.size = EntityDimensions.scalable(width, height);
        this.refreshDimensions();
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    /** 0.74 Penunggangnya sendiri nggak "menunjuk" tubuh tunggangannya: bidikan & kliknya tembus ke dunia di depannya. */
    @Override
    public boolean isPickable() {
        return !(this.level().isClientSide && this.getParent().hasPassenger(e -> e instanceof Player p && p.isLocalPlayer()));
    }

    /** 0.74 Klik kanan bagian mana pun = klik kanan KALDERA-nya (Batu Cryon, naik, diam / ikut). */
    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        return this.getParent().interactFrom(player, hand);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return !this.isInvulnerableTo(source) && this.getParent().hurtFromPart(this, source, amount);
    }

    @Override
    public boolean is(Entity entity) {
        return this == entity || this.getParent() == entity;
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return this.size;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Nullable
    @Override
    public ItemStack getPickResult() {
        return this.getParent().getPickResult();
    }
}
