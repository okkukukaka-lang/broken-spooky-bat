package com.shazammod.kaldera;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * 0.73 Bentuk & gerak tubuh KALDERA yang dihitung sama persis di server (hitbox, telapak kaki yang menghantam tanah, ruang
 * yang dihancurkan) dan di client (model 3D, efek). Satuan blok. Sumbu lokal: +X = sisi kiri, +Y = atas, +Z = depan (arah
 * hadapnya); titik (0, 0, 0) = tanah di bawah pusat badannya (posisi entity).
 *
 * Langkahnya: empat kaki bergantian (kiri belakang, kiri depan, kanan belakang, kanan depan), tiap kaki 3/4 siklus menapak
 * & 1/4 terangkat. Kaki yang menapak diam di tanah (bergerak mundur di ruang lokal secepat badannya maju), jadi tiap
 * siklus = CYCLE blok perjalanan dan tiap kaki menghantam tanah sekali per siklus.
 */
public final class KalderaBody {
    private KalderaBody() {}

    public enum Action { EMERGE, IDLE, ROAR, STOMP, ERUPT, GEYSER, FALL, RAGE, DEATH, SINK }

    // Waktu (tick) tiap gerakan: dipakai bersama server (Kaldera), pose di bawah, efek client (KalderaFx), & SFX kaldera_*
    public static final int EMERGE_TICKS = 130;
    public static final int EMERGE_BREACH = 24;          //   puncak kawahnya menembus permukaan
    public static final int EMERGE_ROAR = 108;
    public static final int ROAR_TICKS = 70, ROAR_HIT = 16;
    public static final int STOMP_TICKS = 76, STOMP_HIT = 34;
    public static final int ERUPT_TICKS = 120, ERUPT_FIRE = 40;
    public static final int BOMB_GAP = 3, BOMB_FLIGHT = 34;
    public static final int GEYSER_TICKS = 84, GEYSER_SLAM = 22, GEYSER_DELAY = 26;
    public static final int FALL_TICKS = 120, FALL_HIT = 42;
    public static final int RAGE_TICKS = 110, RAGE_BURST = 34;
    public static final int DEATH_TICKS = 200, DEATH_COLLAPSE = 60, DEATH_STONE = 120;
    public static final int SINK_TICKS = 110;

    public static final int FL = 0, FR = 1, BL = 2, BR = 3;
    /** Sendi pangkal kaki (bahu & pinggul) di ruang badan: x, y, z untuk FL, FR, BL, BR. */
    public static final float[] HIP = {13.5f, 27f, 16f, -13.5f, 27f, 16f, 14.5f, 26.5f, -18f, -14.5f, 26.5f, -18f};
    /** Telapak kaki saat berdiri diam (sedikit mengangkang ke luar). */
    public static final float[] FOOT = {16.5f, 0f, 19f, -16.5f, 0f, 19f, 17f, 0f, -20f, -17f, 0f, -20f};
    /** Fase langkah tiap kaki (urutan kiri belakang, kiri depan, kanan belakang, kanan depan). */
    public static final float[] PHASE = {0.25f, 0.75f, 0f, 0.5f};
    public static final float UPPER = 13.6f, LOWER = 13.6f;   // panjang paha & betis (dari pinggul sampai pergelangan)
    public static final float CYCLE = 16f;                   // blok perjalanan per satu siklus langkah
    public static final float STANCE = 0.75f;
    public static final float STEP = CYCLE * STANCE;         // jarak telapak bergeser selama menapak (ruang lokal)
    public static final float LIFT = 7f;                     // tinggi kaki terangkat
    public static final float FOOT_R = 6.2f;                 // jari-jari telapak
    public static final float LEG_R = 6.2f;                  // jari-jari berkas tiang kaki
    public static final float HEAD_SCALE = 1.25f;             // kepala & rahang dibangun dalam ukuran dasar lalu dibesarkan
    public static final float NECK_Y = 29.5f, NECK_Z = 24f;  // sendi kepala (pangkal leher)
    public static final float JAW_Y = -3.2f * HEAD_SCALE, JAW_Z = 3.5f * HEAD_SCALE;   // engsel rahang, dari sendi kepala
    public static final float HEAD_LEN = 18f * HEAD_SCALE;   // panjang kepala dari sendinya
    /** 0.74 Tempat duduk penunggang: di dahi kepalanya, di depan jambul (ruang kepala, satuan blok). */
    public static final float SEAT_Y = 8.0f * HEAD_SCALE, SEAT_Z = 12.4f * HEAD_SCALE;
    public static final float PIVOT_Y = 26.5f, PIVOT_Z = -18f; // sumbu badan mendongak (pinggul belakang)
    public static final float BODY_Y = 33.5f, BODY_Z = -2f;  // pusat bongkah badan
    public static final float BODY_RX = 17.5f, BODY_RY = 13f, BODY_RZ = 27.5f;
    public static final float CALDERA_Y = 55f, CALDERA_Z = -4f, CALDERA_R = 8f;
    public static final float TOP = 64f;                     // ujung duri kawah tertinggi
    public static final float REACH = 40f;                   // jari-jari terjauh model dari pusatnya (buat culling)
    public static final float EMERGE_DEPTH = 70f;            // sedalam ini di bawah tanah saat mulai muncul / habis tenggelam

    /** Pose satu saat. Sudut dalam radian. */
    public static final class Pose {
        public float bodyY, pitch, roll;   // pitch > 0 = badan depan terangkat (mendongak), roll > 0 = sisi kiri turun
        public float headYaw, headUp, jaw; // headUp > 0 = moncong naik, jaw > 0 = rahang membuka
        public float glow = 1f;            // terang retakan         public float glow = 1f;            // terang retakan magma (1 = biasa) inti radioaktifnya (1 = biasa)
        public float splay;                // kaki mengangkang ke luar (blok), saat badan ambruk
        /** true = telapak di tanah / mengayun di atas tanah (foot[i*3+1] = tinggi angkat), false = menempel di badan. */
        public final boolean[] planted = new boolean[4];
        /** planted: x, angkat, z lokal (y tanahnya dicari sendiri); tidak: x, y, z di ruang badan (sebelum pose badan). */
        public final float[] foot = new float[12];
    }

    public static float smooth(float a, float b, float t) {
        float k = Mth.clamp((t - a) / Math.max(1.0E-3f, b - a), 0f, 1f);
        return k * k * (3f - 2f * k);
    }

    /** Naik di a..b, tahan, turun di c..d (0..1). */
    public static float env(float a, float b, float c, float d, float t) {
        return smooth(a, b, t) * (1f - smooth(c, d, t));
    }

    /** Langkah ke berapa kaki ini (naik satu tiap kali telapaknya menghantam tanah). */
    public static int stepIndex(int leg, float stride) {
        return Mth.floor(stride / CYCLE + PHASE[leg]);
    }

    /** Kaki ini sedang terangkat (bukan menapak) pada stride ini. */
    public static boolean swinging(int leg, float stride) {
        float ph = frac(stride / CYCLE + PHASE[leg]);
        return ph >= STANCE;
    }

    private static float frac(float v) {
        return v - Mth.floor(v);
    }

    /**
     * Hitung pose: action = urutan Action, t = tick sejak aksi dimulai, stride = jarak langkah total, age = umur
     * (tick, boleh pecahan), rage = sudah kritis (fase 2).
     */
    public static void pose(Pose p, Action action, float t, float stride, float age, boolean rage) {
        float cyc = stride / CYCLE;
        p.bodyY = -0.5f * (0.5f + 0.5f * Mth.cos((float) (Math.PI * 8.0) * cyc)) + 0.3f * Mth.sin(age * 0.045f);
        p.pitch = 0f;
        p.roll = 0.02f * Mth.sin((float) (Math.PI * 2.0) * cyc);
        p.headYaw = 0.06f * Mth.sin(age * 0.013f);
        p.headUp = 0.03f * Mth.sin(age * 0.021f);
        p.jaw = 0.025f + 0.02f * Mth.sin(age * 0.05f);
        p.glow = rage ? 1.35f : 1f;
        p.splay = 0f;
        for (int i = 0; i < 4; i++) {
            float ph = frac(cyc + PHASE[i]);
            float z;
            float lift = 0f;
            if (ph < STANCE) {
                z = FOOT[i * 3 + 2] + STEP * (0.5f - ph / STANCE);
            } else {
                float u = (ph - STANCE) / (1f - STANCE);
                float e = u * u * (3f - 2f * u);
                z = FOOT[i * 3 + 2] - STEP * 0.5f + STEP * e;
                lift = LIFT * Mth.sin((float) Math.PI * u);
            }
            p.planted[i] = true;
            p.foot[i * 3] = FOOT[i * 3];
            p.foot[i * 3 + 1] = lift;
            p.foot[i * 3 + 2] = z;
        }
        switch (action) {
            case EMERGE -> {
                float rise = smooth(0f, EMERGE_TICKS - 26, t);
                float e = 1f - (1f - rise) * (1f - rise);
                p.bodyY = Mth.lerp(e, -EMERGE_DEPTH, 0f) + p.bodyY * rise;
                p.pitch = 0.12f * (1f - rise);
                p.roll += 0.015f * Mth.sin(age * 1.9f) * (1f - rise);
                attachFeet(p, rise < 1f ? 0b1111 : 0, 0f, 0f);
                float roar = env(EMERGE_ROAR - 6, EMERGE_ROAR + 2, EMERGE_TICKS - 8, EMERGE_TICKS, t);
                p.headUp += 0.4f * roar;
                p.jaw += 0.55f * roar;
                p.glow += 0.6f * roar;
            }
            case ROAR -> {
                float k = env(4f, ROAR_HIT, 50f, ROAR_TICKS - 4, t);
                p.headUp += 0.38f * k;
                p.jaw += 0.55f * k;
                p.pitch += 0.05f * k;
                p.roll += 0.01f * Mth.sin(age * 2.7f) * k;
                p.glow += 0.35f * k;
            }
            case STOMP -> {
                float r = smooth(2f, STOMP_HIT - 4, t) * (1f - smooth(STOMP_HIT - 2, STOMP_HIT + 1, t));
                float s = smooth(STOMP_HIT - 2, STOMP_HIT + 1, t) * (1f - smooth(STOMP_HIT + 6, STOMP_TICKS - 8, t));
                p.pitch += 0.27f * r - 0.05f * s;
                p.bodyY += 3f * r - 1.5f * s;
                if (t >= 2f && t < STOMP_HIT + 1) {
                    attachFeet(p, 0b0011, 6f * r, -2f * r);
                }
                p.headUp += 0.15f * r - 0.2f * s;
                p.jaw += 0.3f * r;
                p.glow += 0.25f * r + 0.4f * s;
            }
            case ERUPT -> {
                float w = smooth(0f, ERUPT_FIRE, t) * (1f - smooth(ERUPT_FIRE, ERUPT_FIRE + 4, t));
                float f = smooth(ERUPT_FIRE, ERUPT_FIRE + 3, t) * (1f - smooth(ERUPT_FIRE + 34, ERUPT_TICKS, t));
                p.bodyY += -1.8f * w + 1.0f * f;
                p.roll += 0.012f * Mth.sin(age * 3.1f) * w;
                p.headUp += -0.2f * w + 0.25f * f;
                p.jaw += 0.35f * f;
                p.glow += 0.9f * w + 0.7f * f;
            }
            case GEYSER -> {
                float l = smooth(4f, GEYSER_SLAM - 6, t) * (1f - smooth(GEYSER_SLAM - 3, GEYSER_SLAM, t));
                if (t >= 3f && t < GEYSER_SLAM) {
                    attachFeet(p, 1 << FR, 9f * l, 3f * l);
                }
                float down = env(0f, 18f, 60f, GEYSER_TICKS, t);
                p.headUp -= 0.25f * down;
                p.jaw += 0.2f * down;
                p.roll -= 0.03f * l;
                p.glow += 0.3f * down;
            }
            case FALL -> {
                float up = smooth(0f, 30f, t) * (1f - smooth(32f, 40f, t));
                float drop = smooth(34f, FALL_HIT, t) * (1f - smooth(78f, FALL_TICKS, t));
                p.bodyY += 5f * up - 15f * drop;
                p.splay = 4.5f * drop;
                p.pitch -= 0.04f * drop;
                p.headUp += 0.2f * up - 0.3f * drop;
                p.jaw += 0.4f * up;
                p.glow += 0.5f * drop;
            }
            case RAGE -> {
                float k = env(8f, 22f, 82f, RAGE_TICKS - 4, t);
                float jolt = env(RAGE_BURST - 1, RAGE_BURST + 1, RAGE_BURST + 4, RAGE_BURST + 14, t);
                p.headUp += 0.45f * k;
                p.jaw += 0.6f * k;
                p.pitch += 0.08f * k;
                p.bodyY += 1.4f * jolt;
                p.roll += 0.012f * Mth.sin(age * 2.9f) * k;
                p.glow += 1.2f * k;
            }
            case DEATH -> {
                float roar = env(2f, 10f, 24f, 40f, t);
                float col = smooth(20f, DEATH_COLLAPSE + 30, t);
                float sink = smooth(DEATH_STONE, DEATH_TICKS - 10, t);
                p.bodyY += -14f * col - 30f * sink;
                p.roll += 0.14f * col;
                p.pitch -= 0.06f * col;
                p.headUp += 0.3f * roar - 0.35f * col;
                p.jaw += 0.45f * roar + 0.12f * col;
                p.splay = 5f * col;
                p.glow *= (1f - smooth(DEATH_COLLAPSE - 20, DEATH_STONE, t)) * (1f + 0.6f * roar);
            }
            case SINK -> {
                float s = smooth(10f, SINK_TICKS - 6, t);
                p.bodyY = Mth.lerp(s * s, p.bodyY, -EMERGE_DEPTH);
                p.headUp -= 0.2f * s;
                p.roll += 0.012f * Mth.sin(age * 1.7f) * s;
                attachFeet(p, s > 0f ? 0b1111 : 0, 0f, 0f);
            }
            default -> { }
        }
        if (p.splay != 0f) {   // badan ambruk: telapak yang menapak tergelincir mengangkang ke luar
            for (int i = 0; i < 4; i++) {
                if (p.planted[i]) {
                    p.foot[i * 3] += (FOOT[i * 3] > 0f ? 1f : -1f) * p.splay;
                }
            }
        }
    }

    /** Telapak kaki leg menurut irama langkah saja (tanpa aksi), x & z lokal: titik mendaratnya. out = {x, z}. */
    public static void gaitFoot(int leg, float stride, float[] out) {
        float ph = frac(stride / CYCLE + PHASE[leg]);
        float z;
        if (ph < STANCE) {
            z = FOOT[leg * 3 + 2] + STEP * (0.5f - ph / STANCE);
        } else {
            float u = (ph - STANCE) / (1f - STANCE);
            z = FOOT[leg * 3 + 2] - STEP * 0.5f + STEP * u * u * (3f - 2f * u);
        }
        out[0] = FOOT[leg * 3];
        out[1] = z;
    }

    /** Kaki di mask menempel di badan (ikut terangkat bersama badan), ditambah lipatan (naik & mundur). */
    private static void attachFeet(Pose p, int mask, float up, float back) {
        for (int i = 0; i < 4; i++) {
            if ((mask & (1 << i)) == 0) {
                continue;
            }
            p.planted[i] = false;
            p.foot[i * 3] = FOOT[i * 3];
            p.foot[i * 3 + 1] = FOOT[i * 3 + 1] + up;
            p.foot[i * 3 + 2] = FOOT[i * 3 + 2] + back;
        }
    }

    /** Titik di ruang badan -> ruang lokal (sudah kena pose badan: naik-turun, mendongak, oleng). out = {x, y, z}. */
    public static void body(Pose p, float x, float y, float z, float[] out) {
        float c = Mth.cos(p.pitch), s = Mth.sin(p.pitch);
        float dy = y - PIVOT_Y, dz = z - PIVOT_Z;
        float y1 = PIVOT_Y + dy * c + dz * s;
        float z1 = PIVOT_Z - dy * s + dz * c;
        float cr = Mth.cos(p.roll), sr = Mth.sin(p.roll);
        float dy2 = y1 - PIVOT_Y;
        out[0] = x * cr - dy2 * sr;
        out[1] = PIVOT_Y + x * sr + dy2 * cr + p.bodyY;
        out[2] = z1;
    }

    /** Titik di ruang kepala (dari sendi kepala) -> ruang badan. */
    public static void head(Pose p, float x, float y, float z, float[] out) {
        float c = Mth.cos(p.headUp), s = Mth.sin(p.headUp);
        float y1 = y * c + z * s, z1 = -y * s + z * c;
        float cy = Mth.cos(p.headYaw), sy = Mth.sin(p.headYaw);
        out[0] = x * cy + z1 * sy;
        out[1] = NECK_Y + y1;
        out[2] = NECK_Z - x * sy + z1 * cy;
    }

    /** Titik di ruang kepala -> ruang lokal. */
    public static void headLocal(Pose p, float x, float y, float z, float[] out) {
        head(p, x, y, z, out);
        body(p, out[0], out[1], out[2], out);
    }

    /** 0.74 Titik duduk penunggang (ruang lokal): ikut kepala yang mendongak, menoleh, & badan yang bergoyang. */
    public static void seat(Pose p, float[] out) {
        headLocal(p, 0f, SEAT_Y, SEAT_Z, out);
    }

    /** Ruang lokal -> dunia: posisi entity + putaran hadapnya (yaw dalam derajat, sama dengan Entity.getYRot). */
    public static double worldX(double ox, float yawDeg, float lx, float lz) {
        float a = yawDeg * Mth.DEG_TO_RAD;
        return ox + lx * Mth.cos(a) - lz * Mth.sin(a);
    }

    public static double worldZ(double oz, float yawDeg, float lx, float lz) {
        float a = yawDeg * Mth.DEG_TO_RAD;
        return oz + lx * Mth.sin(a) + lz * Mth.cos(a);
    }

    /** Dunia -> ruang lokal (cuma bidang datar): out = {x, z}. */
    public static void toLocal(double ox, double oz, float yawDeg, double wx, double wz, float[] out) {
        float a = yawDeg * Mth.DEG_TO_RAD;
        double dx = wx - ox, dz = wz - oz;
        out[0] = (float) (dx * Mth.cos(a) + dz * Mth.sin(a));
        out[1] = (float) (-dx * Mth.sin(a) + dz * Mth.cos(a));
    }

    /**
     * Lutut dari pinggul h & telapak f (keduanya ruang lokal): dua tulang (UPPER, LOWER), lutut ditekuk ke arah hint.
     * Kalau telapak lebih jauh dari panjang kaki, kakinya lurus & sedikit memanjang. out = {lutut x, y, z, skala}.
     */
    public static void knee(float hx, float hy, float hz, float fx, float fy, float fz, float ix, float iy, float iz, float[] out) {
        float dx = fx - hx, dy = fy - hy, dz = fz - hz;
        float len = Mth.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1.0E-3f) {
            out[0] = hx;
            out[1] = hy - UPPER;
            out[2] = hz;
            out[3] = 1f;
            return;
        }
        float ux = dx / len, uy = dy / len, uz = dz / len;
        float a = UPPER, b = LOWER, scale = 1f;
        if (len > a + b - 0.05f) {
            scale = len / (a + b - 0.05f);
            a *= scale;
            b *= scale;
        }
        float l = Math.max(len, Math.abs(a - b) + 0.05f);
        float cosA = Mth.clamp((a * a + l * l - b * b) / (2f * a * l), -1f, 1f);
        float along = a * cosA, perp = a * Mth.sqrt(Math.max(0f, 1f - cosA * cosA));
        float dot = ix * ux + iy * uy + iz * uz;
        float wx = ix - dot * ux, wy = iy - dot * uy, wz = iz - dot * uz;
        float wl = Mth.sqrt(wx * wx + wy * wy + wz * wz);
        if (wl < 1.0E-4f) {
            wx = 0f;
            wy = 0f;
            wz = 1f;
            wl = 1f;
        }
        out[0] = hx + ux * along + wx / wl * perp;
        out[1] = hy + uy * along + wy / wl * perp;
        out[2] = hz + uz * along + wz / wl * perp;
        out[3] = scale;
    }

    /** Arah tekuk lutut: kaki depan ke depan, kaki belakang ke belakang, sedikit ke luar. out = {x, y, z}. */
    public static void kneeHint(int leg, float[] out) {
        float side = HIP[leg * 3] > 0f ? 1f : -1f;
        out[0] = 0.35f * side;
        out[1] = 0f;
        out[2] = leg < 2 ? 0.94f : -0.94f;
    }

    // ------------------------------------------------------------------ tanah

    /** Blok yang bisa dipijak telapak raksasanya (bukan udara, air, kayu & daun pohon, atau tanaman). */
    public static boolean solidGround(BlockState s) {
        return !s.isAir() && s.getFluidState().isEmpty() && !s.is(BlockTags.LOGS) && !s.is(BlockTags.LEAVES) && !s.canBeReplaced()
                && s.blocksMotion();
    }

    /**
     * Tinggi tanah (y blok pertama di atas tanah padat) di x, z: menembus pepohonan, tanaman, dan air sampai dasar laut.
     * NaN kalau chunk-nya belum dimuat.
     */
    public static double ground(Level level, double x, double z) {
        int ix = Mth.floor(x), iz = Mth.floor(z);
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(ix, 0, iz);
        if (!level.isLoaded(p)) {
            return Double.NaN;
        }
        int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING, ix, iz);
        int min = Math.max(level.getMinBuildHeight(), top - 80);
        for (int y = top - 1; y >= min; y--) {
            p.setY(y);
            if (solidGround(level.getBlockState(p))) {
                return y + 1;
            }
        }
        return top;
    }
}
