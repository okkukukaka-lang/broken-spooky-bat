package com.shazammod;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * 0.58 Kerusakan medan PRALAYA (Inti Daya & Inti Benak): kawah, terowongan, tanaman & kaca yang tersapu gelombang, dan
 * bongkahan tanah yang terlempar. Blok dihancurkan bertahap (paling banyak BUDGET per tick, dalam dulu) supaya server nggak
 * tersendat dan kerusakannya kelihatan meluas. Ikut gamerule mobGriefing: false = skill tetap melukai, blok aman.
 * Yang nggak pernah dihancurkan: bedrock & blok tak terhancurkan, blok berisi (peti, tungku, spawner, kasur, papan
 * tanda, ...), air & lava, dan blok sekeras obsidian (kecuali Fase Dewa).
 */
public final class PralayaRuin {
    public static final float HARD = 25f;         // batas kekerasan biasa (obsidian 50 selamat)
    public static final float GOD_HARD = 60f;     // Fase Dewa: obsidian pun hancur
    private static final int BUDGET = 900;        // blok yang dihancurkan per tick (semua dimensi)
    private static final int CHECKS = 16000;      // posisi yang diperiksa per tick
    private static final int PARTICLES = 60;      // pecahan blok + suara (levelEvent) per tick
    private static final int MAX_JOB = 100000;    // pengaman: posisi per pekerjaan
    private static final Map<ServerLevel, ArrayDeque<Job>> JOBS = new HashMap<>();

    private PralayaRuin() {}

    private static final class Job {
        final long[] positions;
        final float maxHardness;
        final boolean soft;
        int next;

        Job(long[] positions, float maxHardness, boolean soft) {
            this.positions = positions;
            this.maxHardness = maxHardness;
            this.soft = soft;
        }
    }

    /** Boleh menghancurkan blok di dunia ini (gamerule mobGriefing). */
    public static boolean allowed(ServerLevel level) {
        return level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
    }

    /** Kekerasan maksimum blok yang bisa dihancurkan (Fase Dewa: sampai obsidian). */
    public static float hardness(boolean god) {
        return god ? GOD_HARD : HARD;
    }

    /** Kawah mangkuk di titik ledak (pusat bola sedikit di bawahnya), dari tengah ke luar. */
    public static void crater(ServerLevel level, Vec3 c, double radius, float maxHardness) {
        ball(level, c, radius, maxHardness, true);
    }

    /** Lubang bulat tepat di titik itu (ujung sinar yang mengebor). */
    public static void hole(ServerLevel level, Vec3 c, double radius, float maxHardness) {
        ball(level, c, radius, maxHardness, false);
    }

    private static void ball(ServerLevel level, Vec3 c, double radius, float maxHardness, boolean bowl) {
        if (radius < 0.8 || !allowed(level)) {
            return;
        }
        double cy = bowl ? c.y - radius * 0.35 : c.y;
        int r = (int) Math.ceil(radius);
        double r2 = radius * radius;
        LongArrayList pos = new LongArrayList();
        LongArrayList key = new LongArrayList();
        int bx = Mth.floor(c.x), by = Mth.floor(cy), bz = Mth.floor(c.z);
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    double vy = bowl ? dy * 1.3 : dy;   // mangkuk: sedikit lebih pipih dari bola
                    double d2 = dx * dx + vy * vy + dz * dz;
                    if (d2 > r2 || pos.size() >= MAX_JOB) {
                        continue;
                    }
                    key.add(((long) (d2 * 16.0) << 24) | pos.size());
                    pos.add(BlockPos.asLong(bx + dx, by + dy, bz + dz));
                }
            }
        }
        add(level, ordered(pos, key), maxHardness, false);
    }

    /** Terowongan sepanjang sinar (dari a ke b), berurutan dari pangkal ke ujung. */
    public static void bore(ServerLevel level, Vec3 a, Vec3 b, double radius, float maxHardness) {
        if (radius < 0.5 || !allowed(level)) {
            return;
        }
        Vec3 ab = b.subtract(a);
        double len = ab.length();
        int steps = Math.max(1, (int) Math.ceil(len / 0.75));
        int r = (int) Math.ceil(radius);
        double r2 = radius * radius;
        LongOpenHashSet seen = new LongOpenHashSet();
        LongArrayList out = new LongArrayList();
        for (int i = 0; i <= steps && out.size() < MAX_JOB; i++) {
            Vec3 p = a.add(ab.scale(i / (double) steps));
            int px = Mth.floor(p.x), py = Mth.floor(p.y), pz = Mth.floor(p.z);
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        double ex = px + dx + 0.5 - p.x, ey = py + dy + 0.5 - p.y, ez = pz + dz + 0.5 - p.z;
                        if (ex * ex + ey * ey + ez * ez > r2) {
                            continue;
                        }
                        long key = BlockPos.asLong(px + dx, py + dy, pz + dz);
                        if (seen.add(key)) {
                            out.add(key);
                        }
                    }
                }
            }
        }
        add(level, out.toLongArray(), maxHardness, false);
    }

    /** Gelombang kejut: daun, tanaman, salju tipis, dan kaca di sekitar titik ledak tersapu (tanah & kayu tetap). */
    public static void sweep(ServerLevel level, Vec3 c, double radius) {
        if (radius < 1.0 || !allowed(level)) {
            return;
        }
        int r = (int) Math.ceil(radius);
        double r2 = radius * radius;
        LongArrayList pos = new LongArrayList();
        LongArrayList key = new LongArrayList();
        int bx = Mth.floor(c.x), by = Mth.floor(c.y), bz = Mth.floor(c.z);
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                double d2 = dx * dx + dz * dz;
                if (d2 > r2) {
                    continue;
                }
                for (int dy = -4; dy <= 12 && pos.size() < MAX_JOB; dy++) {   // tanaman & pohon di sekitar permukaan
                    key.add(((long) (d2 * 4.0) << 24) | pos.size());
                    pos.add(BlockPos.asLong(bx + dx, by + dy, bz + dz));
                }
            }
        }
        add(level, ordered(pos, key), 1f, true);
    }

    /**
     * Bongkahan permukaan di sekitar titik ledak terlempar keluar (FallingBlockEntity: mendarat jadi reruntuhan, hilang
     * kalau nggak bisa mendarat). Selama Henti Waktu Dunia bongkahannya ikut membeku di udara.
     */
    public static int fling(ServerLevel level, Vec3 c, double radius, int count, double speed) {
        if (count <= 0 || !allowed(level)) {
            return 0;
        }
        RandomSource r = level.random;
        int made = 0;
        for (int tries = 0; tries < count * 4 && made < count; tries++) {
            double a = r.nextDouble() * Math.PI * 2.0, d = radius * Math.sqrt(r.nextDouble());
            int x = Mth.floor(c.x + Math.cos(a) * d), z = Mth.floor(c.z + Math.sin(a) * d);
            BlockPos top = null;
            for (int y = Mth.floor(c.y) + 4; y >= Mth.floor(c.y) - 8; y--) {
                BlockPos p = new BlockPos(x, y, z);
                if (!level.isLoaded(p)) {
                    break;
                }
                BlockState st = level.getBlockState(p);
                if (!st.isAir() && st.getFluidState().isEmpty()) {
                    top = p;
                    break;
                }
            }
            if (top == null) {
                continue;
            }
            BlockState st = level.getBlockState(top);
            float hard = st.getDestroySpeed(level, top);
            if (st.hasBlockEntity() || hard < 0f || hard > HARD || !st.isCollisionShapeFullBlock(level, top)) {
                continue;
            }
            FallingBlockEntity chunk = FallingBlockEntity.fall(level, top, st);
            chunk.dropItem = false;
            Vec3 out = new Vec3(top.getX() + 0.5 - c.x, 0, top.getZ() + 0.5 - c.z);
            out = out.lengthSqr() < 1.0E-4 ? new Vec3(r.nextDouble() - 0.5, 0, r.nextDouble() - 0.5).normalize() : out.normalize();
            double v = speed * (0.5 + r.nextDouble() * 0.8);
            chunk.setDeltaMovement(out.x * v, 0.45 + r.nextDouble() * 0.55 * speed, out.z * v);
            chunk.hurtMarked = true;
            made++;
        }
        return made;
    }

    private static long[] ordered(LongArrayList pos, LongArrayList key) {
        long[] k = key.toLongArray();
        Arrays.sort(k);
        long[] out = new long[k.length];
        for (int i = 0; i < k.length; i++) {
            out[i] = pos.getLong((int) (k[i] & 0xFFFFFFL));
        }
        return out;
    }

    private static void add(ServerLevel level, long[] positions, float maxHardness, boolean soft) {
        if (positions.length > 0) {
            JOBS.computeIfAbsent(level, l -> new ArrayDeque<>()).addLast(new Job(positions, maxHardness, soft));
        }
    }

    /** Tiap tick server (ShazamEvents): jalankan antrean penghancuran. */
    public static void tick(MinecraftServer server) {
        if (JOBS.isEmpty()) {
            return;
        }
        int budget = BUDGET, checks = CHECKS, particles = PARTICLES;
        Iterator<Map.Entry<ServerLevel, ArrayDeque<Job>>> it = JOBS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<ServerLevel, ArrayDeque<Job>> entry = it.next();
            ServerLevel level = entry.getKey();
            ArrayDeque<Job> queue = entry.getValue();
            while (!queue.isEmpty() && budget > 0 && checks > 0) {
                Job job = queue.peekFirst();
                while (job.next < job.positions.length && budget > 0 && checks > 0) {
                    BlockPos pos = BlockPos.of(job.positions[job.next++]);
                    checks--;
                    if (level.isOutsideBuildHeight(pos) || !level.isLoaded(pos)) {
                        continue;
                    }
                    BlockState state = level.getBlockState(pos);
                    if (!breakable(level, pos, state, job)) {
                        continue;
                    }
                    level.setBlock(pos, state.getFluidState().createLegacyBlock(), Block.UPDATE_ALL);
                    budget--;
                    if (particles > 0 && level.random.nextInt(job.soft ? 4 : 9) == 0) {
                        level.levelEvent(2001, pos, Block.getId(state));   // pecahan & suara blok pecah
                        particles--;
                    }
                }
                if (job.next >= job.positions.length) {
                    queue.pollFirst();
                }
            }
            if (queue.isEmpty()) {
                it.remove();
            }
        }
    }

    private static boolean breakable(ServerLevel level, BlockPos pos, BlockState state, Job job) {
        if (state.isAir() || state.hasBlockEntity() || state.getBlock() instanceof LiquidBlock) {
            return false;
        }
        float hard = state.getDestroySpeed(level, pos);
        if (hard < 0f || hard > job.maxHardness) {
            return false;
        }
        return !job.soft || state.is(BlockTags.LEAVES) || state.is(BlockTags.SAPLINGS) || state.is(BlockTags.FLOWERS)
                || (state.canBeReplaced() && state.getFluidState().isEmpty()) || state.getSoundType() == SoundType.GLASS;
    }

    /** Server berhenti: antrean dibuang. */
    public static void clear() {
        JOBS.clear();
    }
}
