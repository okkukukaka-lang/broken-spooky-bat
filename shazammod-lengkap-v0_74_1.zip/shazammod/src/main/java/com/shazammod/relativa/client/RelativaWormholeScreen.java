package com.shazammod.relativa.client;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import org.lwjgl.glfw.GLFW;

import com.shazammod.relativa.RelativaClientState;
import com.shazammod.relativa.RelativaData;
import com.shazammod.relativa.RelativaNetwork;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 0.70 Layar koordinat Jembatan Einstein-Rosen (tombol L): pilih dimensi (semua dimensi yang ada di server, termasuk dari
 * mod lain), isi X Y Z (Y kosong = permukaan aman dicari sendiri, ~ = posisi sekarang, ~10 = 10 blok dari sini), atau isi
 * otomatis dari posisi sekarang / titik yang dilihat / koordinat setara (x8 dari Nether, :8 ke Nether), lalu Buka. Tombol
 * Tutup meruntuhkan lubang cacing yang sedang terbuka. Isian terakhir diingat.
 */
public final class RelativaWormholeScreen extends Screen {
    private static final int TITLE = 0xFF8FD8FF, TEXT = 0xFFD8E8F8, DIM = 0xFF8FA8C8, WARN = 0xFFFF8A8A, OK = 0xFF9CFFB8;
    private static final double MAX = 30_000_000.0;

    private static String lastDim;
    private static String lastX = "", lastY = "", lastZ = "";

    private final List<ResourceKey<Level>> dims = new ArrayList<>();
    private int dimIndex;
    private EditBox xBox, yBox, zBox;
    private Button dimButton, closeButton;
    private Component error;

    public RelativaWormholeScreen() {
        super(Component.translatable("gui.shazammod.wormhole.title"));
    }

    @Override
    protected void init() {
        Minecraft mc = this.minecraft;
        dims.clear();
        if (mc.getConnection() != null) {
            dims.addAll(mc.getConnection().levels());
        }
        if (dims.isEmpty() && mc.level != null) {
            dims.add(mc.level.dimension());
        }
        dims.sort(Comparator.comparingInt(RelativaWormholeScreen::order).thenComparing(k -> k.location().toString()));
        dimIndex = 0;
        String want = lastDim != null ? lastDim : mc.level != null ? mc.level.dimension().location().toString() : null;
        for (int i = 0; i < dims.size(); i++) {
            if (dims.get(i).location().toString().equals(want)) {
                dimIndex = i;
            }
        }
        int cx = this.width / 2, top = Math.max(8, this.height / 2 - 96);
        dimButton = this.addRenderableWidget(Button.builder(dimLabel(), b -> cycle()).bounds(cx - 102, top + 30, 204, 20).build());
        xBox = box(cx - 102, top + 68, lastX);
        yBox = box(cx - 34, top + 68, lastY);
        zBox = box(cx + 34, top + 68, lastZ);
        yBox.setHint(Component.translatable("gui.shazammod.wormhole.auto"));
        this.addRenderableWidget(Button.builder(Component.translatable("gui.shazammod.wormhole.here"), b -> fillHere())
                .bounds(cx - 102, top + 106, 66, 20).build());
        this.addRenderableWidget(Button.builder(Component.translatable("gui.shazammod.wormhole.look"), b -> fillLook())
                .bounds(cx - 33, top + 106, 66, 20).build());
        this.addRenderableWidget(Button.builder(Component.translatable("gui.shazammod.wormhole.scale"), b -> fillScaled())
                .bounds(cx + 36, top + 106, 66, 20).build());
        this.addRenderableWidget(Button.builder(Component.translatable("gui.shazammod.wormhole.open"), b -> submit())
                .bounds(cx - 102, top + 162, 100, 20).build());
        closeButton = this.addRenderableWidget(Button.builder(Component.translatable("gui.shazammod.wormhole.close"), b -> shut())
                .bounds(cx + 2, top + 162, 100, 20).build());
        closeButton.active = RelativaClientState.wormholeTicks > 0;
        this.addRenderableWidget(Button.builder(CommonComponents.GUI_CANCEL, b -> this.onClose())
                .bounds(cx - 50, top + 186, 100, 20).build());
        this.setInitialFocus(xBox);
    }

    private EditBox box(int x, int y, String value) {
        EditBox b = new EditBox(this.font, x, y, 64, 18, Component.empty());
        b.setMaxLength(12);
        b.setFilter(s -> s.matches("~?-?[0-9]*\\.?[0-9]*"));
        b.setValue(value);
        b.setResponder(s -> error = null);
        return this.addRenderableWidget(b);
    }

    private static int order(ResourceKey<Level> k) {
        if (k == Level.OVERWORLD) {
            return 0;
        }
        if (k == Level.NETHER) {
            return 1;
        }
        return k == Level.END ? 2 : 3;
    }

    static Component dimName(ResourceKey<Level> dim) {
        ResourceLocation loc = dim.location();
        return Component.translatableWithFallback("dimension.shazammod." + loc.getNamespace() + "." + loc.getPath(),
                loc.toString());
    }

    private ResourceKey<Level> selected() {
        return dims.isEmpty() ? Level.OVERWORLD : dims.get(Mth.clamp(dimIndex, 0, dims.size() - 1));
    }

    private Component dimLabel() {
        return Component.translatable("gui.shazammod.wormhole.dim", dimName(selected()));
    }

    private void cycle() {
        if (!dims.isEmpty()) {
            dimIndex = (dimIndex + 1) % dims.size();
            dimButton.setMessage(dimLabel());
            error = null;
        }
    }

    private void select(ResourceKey<Level> dim) {
        int i = dims.indexOf(dim);
        if (i >= 0) {
            dimIndex = i;
            dimButton.setMessage(dimLabel());
        }
    }

    private static String num(double v) {
        return String.valueOf((long) Math.floor(v));
    }

    private void fillHere() {
        LocalPlayer p = this.minecraft.player;
        if (p == null) {
            return;
        }
        BlockPos at = p.blockPosition();
        xBox.setValue(num(at.getX()));
        yBox.setValue(num(at.getY()));
        zBox.setValue(num(at.getZ()));
        select(p.level().dimension());
    }

    private void fillLook() {
        LocalPlayer p = this.minecraft.player;
        if (p == null) {
            return;
        }
        HitResult hit = p.pick(160.0, 1.0f, false);
        BlockPos at = hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult block
                ? block.getBlockPos().relative(block.getDirection()) : BlockPos.containing(hit.getLocation());
        xBox.setValue(num(at.getX()));
        yBox.setValue(num(at.getY()));
        zBox.setValue(num(at.getZ()));
        select(p.level().dimension());
    }

    /** Posisi sekarang diubah ke skala koordinat dimensi yang dipilih (Nether: 1 blok = 8 blok Overworld). */
    private void fillScaled() {
        LocalPlayer p = this.minecraft.player;
        if (p == null) {
            return;
        }
        double k = scale(p.level().dimension()) / scale(selected());
        xBox.setValue(num(p.getX() * k));
        yBox.setValue("");
        zBox.setValue(num(p.getZ() * k));
    }

    private double scale(ResourceKey<Level> dim) {
        Minecraft mc = this.minecraft;
        if (mc.level != null && mc.level.dimension() == dim) {
            return mc.level.dimensionType().coordinateScale();
        }
        if (mc.getConnection() != null) {
            var reg = mc.getConnection().registryAccess().registry(Registries.DIMENSION_TYPE);
            if (reg.isPresent()) {
                DimensionType type = reg.get().get(dim.location());
                if (type != null) {
                    return type.coordinateScale();
                }
            }
        }
        return dim == Level.NETHER ? 8.0 : 1.0;
    }

    /** Angka biasa, "~" (posisi sekarang), atau "~10" (10 blok dari posisi sekarang); null kalau salah. */
    private static Double parse(String raw, double here) {
        String s = raw.trim();
        if (s.isEmpty()) {
            return null;
        }
        try {
            double v;
            if (s.startsWith("~")) {
                String rest = s.substring(1);
                v = here + (rest.isEmpty() || rest.equals("-") ? 0.0 : Double.parseDouble(rest));
            } else {
                v = Double.parseDouble(s);
            }
            return Double.isFinite(v) && Math.abs(v) <= MAX ? v : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void submit() {
        LocalPlayer p = this.minecraft.player;
        if (p == null) {
            return;
        }
        Double x = parse(xBox.getValue(), p.getX());
        Double z = parse(zBox.getValue(), p.getZ());
        boolean auto = yBox.getValue().trim().isEmpty();
        Double y = auto ? Double.valueOf(p.getY()) : parse(yBox.getValue(), p.getY());
        if (x == null || y == null || z == null) {
            error = Component.translatable("gui.shazammod.wormhole.invalid");
            return;
        }
        lastDim = selected().location().toString();
        lastX = xBox.getValue();
        lastY = yBox.getValue();
        lastZ = zBox.getValue();
        PacketDistributor.sendToServer(new RelativaNetwork.WormholeOpenPayload(lastDim, x, y, z,
                auto ? RelativaNetwork.WORM_AUTO_Y : 0));
        this.onClose();
    }

    private void shut() {
        PacketDistributor.sendToServer(new RelativaNetwork.WormholeOpenPayload("", 0, 0, 0, RelativaNetwork.WORM_CLOSE));
        this.onClose();
    }

    @Override
    public void tick() {
        super.tick();
        if (!RelativaClientState.transformed) {
            this.onClose();   // kembali jadi manusia: layarnya ikut tertutup
            return;
        }
        closeButton.active = RelativaClientState.wormholeTicks > 0;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            submit();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        int cx = this.width / 2, top = Math.max(8, this.height / 2 - 96);
        g.drawCenteredString(this.font, this.title, cx, top, TITLE);
        g.drawCenteredString(this.font, Component.translatable("gui.shazammod.wormhole.subtitle"), cx, top + 13, DIM);
        g.drawString(this.font, "X", cx - 102, top + 57, TEXT);
        g.drawString(this.font, "Y", cx - 34, top + 57, TEXT);
        g.drawString(this.font, "Z", cx + 34, top + 57, TEXT);
        g.drawCenteredString(this.font, Component.translatable("gui.shazammod.wormhole.hint"), cx, top + 91, DIM);
        LocalPlayer p = this.minecraft.player;
        Component info = null;
        int color = TEXT;
        if (p != null) {
            Double x = parse(xBox.getValue(), p.getX()), z = parse(zBox.getValue(), p.getZ());
            if (x != null && z != null) {
                if (selected() == p.level().dimension()) {
                    double dist = Math.sqrt((x - p.getX()) * (x - p.getX()) + (z - p.getZ()) * (z - p.getZ()));
                    info = Component.translatable("gui.shazammod.wormhole.distance",
                            String.format(Locale.ROOT, "%,d", Math.round(dist)));
                } else {
                    info = Component.translatable("gui.shazammod.wormhole.cross", dimName(p.level().dimension()),
                            dimName(selected()));
                }
            }
        }
        if (info != null) {
            g.drawCenteredString(this.font, info, cx, top + 132, color);
        }
        int cd = RelativaClientState.cooldown(RelativaData.SLOT_WORMHOLE);
        Component status;
        int sc;
        if (RelativaClientState.wormholeTicks > 0) {
            status = Component.translatable("gui.shazammod.wormhole.status_open", (RelativaClientState.wormholeTicks + 19) / 20);
            sc = OK;
        } else if (cd > 0) {
            status = Component.translatable("gui.shazammod.wormhole.status_cd", (cd + 19) / 20);
            sc = WARN;
        } else {
            status = Component.translatable("gui.shazammod.wormhole.status_ready");
            sc = DIM;
        }
        g.drawCenteredString(this.font, status, cx, top + 145, sc);
        if (error != null) {
            g.drawCenteredString(this.font, error, cx, top + 210, WARN);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
