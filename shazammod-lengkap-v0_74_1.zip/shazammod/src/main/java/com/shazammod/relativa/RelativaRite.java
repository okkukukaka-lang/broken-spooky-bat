package com.shazammod.relativa;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;

/**
 * 0.66 Eksperimen Pikiran (Gedankenexperiment): Jurnal Annus Mirabilis yang keempat makalahnya sudah tertulis diklik kanan
 * dalam wujud manusia. Keempat makalah 1905 melayang mengorbit, kamu "mengejar berkas cahaya" sampai ruang-waktu di
 * sekelilingmu melengkung, lalu (REL_RITE_BURST) semua persamaan menyatu di dadamu: RELATIVA terbuka. Selama eksperimen
 * kamu nggak bisa dilukai (pikiranmu jauh dari badanmu). Jurnalnya nggak habis.
 */
public final class RelativaRite {
    private RelativaRite() {}

    private static final Map<UUID, Long> RITES = new HashMap<>();

    public static boolean isRunning(Player p) {
        Long t = RITES.get(p.getUUID());
        return t != null && p.level().getGameTime() - t <= ShazamAnim.REL_RITE_TICKS + 4;
    }

    public static void clear(ServerPlayer p) {
        RITES.remove(p.getUUID());
    }

    /** Klik kanan Jurnal Annus Mirabilis. */
    public static void tryBegin(ServerPlayer p) {
        RelativaData d = RelativaAbilities.data(p);
        if (isRunning(p)) {
            return;
        }
        if (d.unlocked) {
            RelativaAbilities.msg(p, d.transformed ? "journal_form" : "journal_human", ChatFormatting.AQUA);
            return;
        }
        if (d.papers != RelativaData.PAPERS_ALL) {
            p.displayClientMessage(Component.translatable("message.shazammod.relativa.rite_need",
                    Integer.bitCount(d.papers)).withStyle(ChatFormatting.GOLD), false);
            for (int i = 0; i < RelativaData.PAPERS; i++) {
                boolean has = d.hasPaper(i);
                p.displayClientMessage(Component.literal(has ? "  ✔ " : "  ✘ ")
                        .append(RelativaAbilities.paperName(i))
                        .append(Component.literal(" — "))
                        .append(Component.translatable("message.shazammod.relativa.paper_hint." + i))
                        .withStyle(has ? ChatFormatting.GREEN : ChatFormatting.GRAY), false);
            }
            return;
        }
        if (RelativaAbilities.championBusy(p) || d.transformed) {
            RelativaAbilities.msg(p, "champion_active", ChatFormatting.GRAY);
            return;
        }
        begin(p);
    }

    /** Mulai sekarang juga (dipakai juga /relativa rite, tanpa syarat makalah). */
    public static void begin(ServerPlayer p) {
        if (isRunning(p)) {
            return;
        }
        RITES.put(p.getUUID(), p.level().getGameTime());
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_RITE);
        p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.RELATIVA_RITE.get(), SoundSource.PLAYERS,
                2.0f, 1f);
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ShazamAnim.REL_RITE_TICKS, 6, false, false));
        RelativaAbilities.msg(p, "rite_start", ChatFormatting.AQUA);
    }

    static void tick(ServerPlayer p, RelativaData d) {
        Long start = RITES.get(p.getUUID());
        if (start == null) {
            return;
        }
        if (!p.isAlive()) {
            RITES.remove(p.getUUID());
            return;
        }
        long age = p.level().getGameTime() - start;
        if (age == ShazamAnim.REL_RITE_BURST) {
            d.unlocked = true;
            d.papers = RelativaData.PAPERS_ALL;
            p.displayClientMessage(Component.translatable("message.shazammod.relativa.unlocked")
                    .withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), false);
            p.displayClientMessage(Component.translatable("message.shazammod.relativa.unlocked_help")
                    .withStyle(ChatFormatting.GRAY), false);
            RelativaNetwork.sync(p);
        }
        if (age > ShazamAnim.REL_RITE_TICKS || age < 0) {
            RITES.remove(p.getUUID());
        }
    }
}
