package com.shazammod.relativa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;
import com.shazammod.rival.RivalChampion;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Interaction;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.entity.RelativeMovement;
import net.minecraft.world.entity.boss.EnderDragonPart;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.EvokerFangs;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.border.WorldBorder;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.entity.PartEntity;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 0.70 JEMBATAN EINSTEIN-ROSEN (tombol L): lubang cacing super. Einstein & Rosen (1935) menemukan bahwa ruang-waktu di
 * sekitar massa bisa tersambung lewat "jembatan" ke tempat lain; RELATIVA merobek ruang-waktu dengan kedua tangannya dan
 * membuka dua mulut bola yang saling tersambung:
 *
 *   L               layar koordinat: X Y Z bebas (Y kosong = permukaan aman dicari sendiri), dimensi apa pun yang ada di
 *                   server (Overworld, Nether, End, dimensi mod), tombol "posisi sekarang", "titik yang dilihat",
 *                   "koordinat setara" (x8 / :8 Nether), lalu Buka / Tutup
 *   Shift + L       langsung ke titik yang dilihat (sampai QUICK_RANGE blok), dimensi yang sama
 *
 * Mulut pertama terbuka di depan RELATIVA, mulut kedua di tujuan; keduanya terbuka REL_WORM_TICKS dan DUA ARAH: pemain,
 * makhluk, barang, panah & proyektil lain (kecepatannya tetap), kereta tambang, perahu, kuda yang ditunggangi, salinan
 * Kucing Schrödinger. Yang baru keluar dari satu mulut harus keluar dulu dari bolanya sebelum bisa masuk lagi. Chunk di
 * kedua mulut dijaga tetap termuat selama terbuka. Tempat tujuan dicari yang aman (lantai padat, kepala & kaki kosong,
 * bukan lava / api / air); kalau nggak ada (laut, void End, di dalam batu), lantai obsidian 3x3 dibuat dengan ruang kosong
 * di atasnya. Bedrock / blok yang nggak bisa dihancurkan dan batas dunia tetap dihormati. Menutup sendiri saat waktunya
 * habis, ditutup lagi lewat layarnya, atau saat RELATIVA kembali jadi manusia / keluar / mati.
 */
public final class RelativaWormhole {
    private RelativaWormhole() {}

    // ======= Angka yang gampang diutak-atik =======
    public static final float RADIUS = 2.0f;           // jari-jari mulut (blok)
    private static final float COST = 30f;            // energi (x RelativaTier.COST)
    private static final int COOLDOWN = 20;           // detik (x RelativaTier.COOLDOWN)
    private static final double QUICK_RANGE = 160.0;  // Shift+L: sejauh ini titik yang dilihat
    private static final double AHEAD = 3.5;          // mulut pertama terbuka sejauh ini di depan
    private static final double LIFT = 1.2;           // pusat mulut di atas lantai
    private static final double MIN_GAP = 8.0;        // dua mulut di dimensi yang sama paling dekat sejauh ini
    private static final int SEARCH_XZ = 8, SEARCH_Y = 24;
    private static final int TICKET_EVERY = 100, HUM_EVERY = 40, PASS_FX_GAP = 3;
    // ===============================================

    private record Mouth(ResourceKey<Level> dim, Vec3 c, Vec3 exit) {}

    private static final class Hole {
        final int id;
        final UUID owner;
        final Mouth[] m;
        final int life;
        int age;
        final long[] lastFx = new long[2];
        /** Yang baru keluar dari mulut ke-n: belum boleh tersedot mulut itu lagi sebelum keluar dari bolanya. */
        final Map<UUID, Integer> inside = new HashMap<>();

        Hole(int id, UUID owner, Mouth a, Mouth b, int life) {
            this.id = id;
            this.owner = owner;
            this.m = new Mouth[] {a, b};
            this.life = life;
        }
    }

    private static final Map<UUID, Hole> HOLES = new HashMap<>();
    private static int nextId;

    // ---------------------------------------------------------------- permintaan dari client

    /** Layar koordinat / Shift+L / tombol Tutup. */
    public static void request(ServerPlayer p, RelativaNetwork.WormholeOpenPayload req) {
        RelativaData d = RelativaAbilities.data(p);
        if (!d.transformed || d.morphing > 0 || !p.isAlive() || p.isSpectator()) {
            return;
        }
        int mode = req.mode();
        if ((mode & RelativaNetwork.WORM_CLOSE) != 0) {
            boolean had = close(p.server, p.getUUID());
            RelativaAbilities.msg(p, had ? "wormhole_closed" : "wormhole_none", ChatFormatting.GRAY);
            RelativaNetwork.sync(p);
            return;
        }
        ServerLevel from = p.serverLevel();
        ServerLevel to;
        Vec3 want;
        boolean autoY = (mode & RelativaNetwork.WORM_AUTO_Y) != 0;
        if ((mode & RelativaNetwork.WORM_QUICK) != 0) {
            to = from;
            want = quickTarget(p, from);
            autoY = false;
        } else {
            ResourceLocation rl = ResourceLocation.tryParse(req.dim());
            to = rl == null ? null : p.server.getLevel(ResourceKey.create(Registries.DIMENSION, rl));
            if (to == null) {
                RelativaAbilities.msg(p, "wormhole_no_dim", ChatFormatting.RED, req.dim());
                return;
            }
            if (!Double.isFinite(req.x()) || !Double.isFinite(req.y()) || !Double.isFinite(req.z())) {
                RelativaAbilities.msg(p, "wormhole_bad", ChatFormatting.RED);
                return;
            }
            want = new Vec3(req.x(), req.y(), req.z());
        }
        if (!RelativaSkills.ready(p, d, RelativaData.SLOT_WORMHOLE, COST)) {
            return;
        }
        want = clamp(to, want);
        Vec3 exit = findSafe(to, want, autoY);
        boolean built = false;
        if (exit == null) {
            exit = buildPlatform(to, want, autoY);
            built = exit != null;
        }
        if (exit == null) {
            RelativaAbilities.msg(p, "wormhole_unsafe", ChatFormatting.RED);
            return;
        }
        Vec3 aFeet = sourceExit(p, from);
        Mouth a = new Mouth(from.dimension(), aFeet.add(0, LIFT, 0), aFeet);
        Mouth b = new Mouth(to.dimension(), exit.add(0, LIFT, 0), exit);
        if (from == to && a.c().distanceTo(b.c()) < MIN_GAP) {
            RelativaAbilities.msg(p, "wormhole_close_range", ChatFormatting.GRAY);
            return;
        }
        RelativaSkills.spend(p, d, RelativaData.SLOT_WORMHOLE, COST, COOLDOWN);
        close(p.server, p.getUUID());   // satu RELATIVA satu jembatan: yang lama runtuh
        RelativaSkills.busy(p, ShazamAnim.REL_WORM_OPEN + 2);
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_WORMHOLE, a.c());
        RelativaSkills.sound(p, a.c(), ShazamSounds.RELATIVA_WORMHOLE.get(), 1.8f);
        ticket(to, b.c());   // chunk tujuan disiapkan selagi ruang-waktunya dirobek
        boolean platform = built;
        RelativaSkills.later(p, ShazamAnim.REL_WORM_OPEN, sp -> open(sp, a, b, platform));
        RelativaNetwork.sync(p);
    }

    private static void open(ServerPlayer p, Mouth a, Mouth b, boolean built) {
        ServerLevel la = p.server.getLevel(a.dim()), lb = p.server.getLevel(b.dim());
        if (la == null || lb == null || !RelativaAbilities.active(p)) {
            return;
        }
        Hole h = new Hole(++nextId, p.getUUID(), a, b, ShazamAnim.REL_WORM_TICKS);
        HOLES.put(p.getUUID(), h);
        ticket(la, a.c());
        ticket(lb, b.c());
        send(p.server, h, -1, RelativaNetwork.WORM_OPEN);
        play(la, a.c(), ShazamSounds.RELATIVA_WORMHOLE_HUM.get(), 1.6f);
        play(lb, b.c(), ShazamSounds.RELATIVA_WORMHOLE_PASS.get(), 2.0f);   // di seberang: ruang-waktu tiba-tiba terbuka
        play(lb, b.c(), ShazamSounds.RELATIVA_WORMHOLE_HUM.get(), 1.6f);
        BlockPos e = BlockPos.containing(b.exit());
        RelativaAbilities.msg(p, built ? "wormhole_open_built" : "wormhole_open", ChatFormatting.AQUA, dimName(b.dim()),
                e.getX(), e.getY(), e.getZ(), ShazamAnim.REL_WORM_TICKS / 20);
        RelativaNetwork.sync(p);
    }

    // ---------------------------------------------------------------- tiap tick server

    public static void serverTick(MinecraftServer server) {
        if (HOLES.isEmpty()) {
            return;
        }
        List<Hole> closing = new ArrayList<>();
        for (Hole h : new ArrayList<>(HOLES.values())) {
            h.age++;
            ServerPlayer owner = server.getPlayerList().getPlayer(h.owner);
            if (h.age >= h.life || owner == null || !owner.isAlive() || !RelativaAbilities.active(owner)) {
                closing.add(h);
                continue;
            }
            if (h.age % TICKET_EVERY == 0) {
                for (Mouth m : h.m) {
                    ServerLevel level = server.getLevel(m.dim());
                    if (level != null) {
                        ticket(level, m.c());
                    }
                }
            }
            if (h.age % HUM_EVERY == 0) {
                for (Mouth m : h.m) {
                    ServerLevel level = server.getLevel(m.dim());
                    if (level != null) {
                        play(level, m.c(), ShazamSounds.RELATIVA_WORMHOLE_HUM.get(), 1.2f);
                    }
                }
            }
            if (h.inside.size() > 512) {
                h.inside.clear();
            }
            for (int i = 0; i < 2; i++) {
                if (HOLES.get(h.owner) != h) {
                    break;
                }
                process(server, h, i);
            }
        }
        for (Hole h : closing) {
            shut(server, h);
        }
    }

    private static void process(MinecraftServer server, Hole h, int side) {
        Mouth m = h.m[side];
        ServerLevel level = server.getLevel(m.dim());
        if (level == null || !level.isLoaded(BlockPos.containing(m.c()))) {
            return;
        }
        double r = RADIUS;
        List<Entity> queue = new ArrayList<>();
        for (Entity e : level.getEntities((Entity) null, new AABB(m.c(), m.c()).inflate(r + 1.5), RelativaWormhole::passable)) {
            double dist = e.getBoundingBox().getCenter().distanceTo(m.c());
            Integer in = h.inside.get(e.getUUID());
            if (in != null && in == side) {
                if (dist > r + 0.6) {
                    h.inside.remove(e.getUUID());   // sudah keluar dari bola mulut ini
                }
                continue;
            }
            if (dist < r * 0.85) {
                queue.add(e);
            }
        }
        for (Entity e : queue) {
            pass(server, h, e, side);
        }
    }

    /** Yang boleh lewat: hampir semua yang bergerak, kecuali bos besar, penanda, lukisan, dan yang sedang ditunggangi. */
    private static boolean passable(Entity e) {
        if (!e.isAlive() || e.isRemoved() || e.isSpectator() || e.isPassenger()) {
            return false;
        }
        if (e instanceof HangingEntity || e instanceof Marker || e instanceof Display || e instanceof Interaction
                || e instanceof LightningBolt || e instanceof AreaEffectCloud || e instanceof EvokerFangs) {
            return false;
        }
        if (e instanceof EnderDragon || e instanceof EnderDragonPart || e instanceof WitherBoss || e instanceof PartEntity<?>) {
            return false;
        }
        if (e instanceof RivalChampion || e instanceof com.shazammod.helion3.Helion3) {
            return false;   // pertarungan rival & bos terikat ke tempatnya
        }
        return !(e instanceof Player player) || !player.isSleeping();
    }

    private static void pass(MinecraftServer server, Hole h, Entity e, int from) {
        int to = 1 - from;
        Mouth src = h.m[from], dst = h.m[to];
        ServerLevel target = server.getLevel(dst.dim());
        if (target == null || !e.isAlive() || e.isRemoved()) {
            return;
        }
        UUID id = e.getUUID();
        Vec3 v = e.getDeltaMovement();
        Vec3 at = dst.exit();
        ServerLevel origin = server.getLevel(src.dim());
        if (!e.teleportTo(target, at.x, at.y, at.z, Set.<RelativeMovement>of(), e.getYRot(), e.getXRot())) {
            return;
        }
        Entity moved = e.level() == target && !e.isRemoved() ? e : target.getEntity(id);
        if (moved != null) {
            if (!(moved instanceof Player)) {   // pemain menggerakkan badannya sendiri (client)
                moved.setDeltaMovement(v);   // kecepatannya tetap: panah yang masuk tetap melesat keluar
                moved.hurtMarked = true;
            }
            moved.resetFallDistance();
        }
        h.inside.put(id, to);
        long now = server.getTickCount();
        for (int side = 0; side < 2; side++) {
            if (now - h.lastFx[side] >= PASS_FX_GAP) {
                h.lastFx[side] = now;
                Mouth m = h.m[side];
                ServerLevel level = server.getLevel(m.dim());
                if (level != null) {
                    PacketDistributor.sendToPlayersInDimension(level, payload(h, side, RelativaNetwork.WORM_PASS));
                    play(level, m.c(), ShazamSounds.RELATIVA_WORMHOLE_PASS.get(), e instanceof Player ? 1.4f : 0.8f);
                }
            }
        }
        if (moved instanceof ServerPlayer sp && RelativaAbilities.active(sp)) {
            // salinan Kucing Schrödinger milik RELATIVA ini ikut lewat bersamanya
            for (UUID clone : RelativaClone.bring(sp, origin, target, at)) {
                h.inside.put(clone, to);
            }
            RelativaNetwork.sync(sp);
            RelativaNetwork.broadcastState(sp);
        }
    }

    // ---------------------------------------------------------------- tutup

    /** Tutup lubang cacing milik pemain ini (kalau ada). */
    public static boolean close(MinecraftServer server, UUID owner) {
        Hole h = HOLES.get(owner);
        if (h == null) {
            return false;
        }
        shut(server, h);
        return true;
    }

    public static void close(ServerPlayer p) {
        if (close(p.server, p.getUUID())) {
            RelativaNetwork.sync(p);
        }
    }

    private static void shut(MinecraftServer server, Hole h) {
        if (HOLES.get(h.owner) == h) {
            HOLES.remove(h.owner);
        }
        send(server, h, -1, RelativaNetwork.WORM_SHUT);
        for (Mouth m : h.m) {
            ServerLevel level = server.getLevel(m.dim());
            if (level != null) {
                play(level, m.c(), ShazamSounds.RELATIVA_WORMHOLE_CLOSE.get(), 1.8f);
            }
        }
        ServerPlayer owner = server.getPlayerList().getPlayer(h.owner);
        if (owner != null) {
            RelativaNetwork.sync(owner);
        }
    }

    public static void clear() {
        HOLES.clear();
    }

    /** Sisa tick lubang cacing milik pemain ini (HUD), 0 kalau nggak ada. */
    public static int ticksLeft(ServerPlayer p) {
        Hole h = HOLES.get(p.getUUID());
        return h == null ? 0 : Math.max(0, h.life - h.age);
    }

    /** Pemain baru masuk / pindah dimensi: kirim semua mulut yang terbuka di dimensinya. */
    public static void sendAll(ServerPlayer p) {
        ResourceKey<Level> dim = p.level().dimension();
        for (Hole h : HOLES.values()) {
            for (int side = 0; side < 2; side++) {
                if (h.m[side].dim() == dim) {
                    PacketDistributor.sendToPlayer(p, payload(h, side, RelativaNetwork.WORM_OPEN));
                }
            }
        }
    }

    // ---------------------------------------------------------------- tempat

    /** Shift+L: titik yang dilihat (di atas blok yang kena), atau tanah di bawah ujung pandangan. */
    private static Vec3 quickTarget(ServerPlayer p, ServerLevel level) {
        HitResult hit = p.pick(QUICK_RANGE, 1.0f, false);
        if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult block) {
            return Vec3.atBottomCenterOf(block.getBlockPos().relative(block.getDirection()));
        }
        Vec3 end = hit.getLocation();
        int x = Mth.floor(end.x), z = Mth.floor(end.z);
        int ground = surface(level, x, z, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES);
        return ground > level.getMinBuildHeight() + 1 ? new Vec3(x + 0.5, ground, z + 0.5) : end;
    }

    /** Mulut pertama: AHEAD blok di depan (mundur kalau sesak), titik kakinya di lantai di bawahnya kalau ada. */
    private static Vec3 sourceExit(ServerPlayer p, ServerLevel level) {
        Vec3 flat = RelativaSkills.flat(p.getLookAngle());
        Vec3 feet = p.position();
        for (double f = AHEAD; f >= 0.0; f -= 0.5) {
            Vec3 c = feet.add(flat.scale(f));
            if (level.noCollision(p, p.getBoundingBox().move(c.subtract(feet)))) {
                feet = c;
                break;
            }
        }
        BlockPos at = BlockPos.containing(feet);
        for (int dy = 0; dy <= 3; dy++) {
            BlockPos below = at.below(dy + 1);
            BlockState st = level.getBlockState(below);
            if (!st.getCollisionShape(level, below).isEmpty()) {
                double top = below.getY() + st.getCollisionShape(level, below).max(Direction.Axis.Y);
                return new Vec3(feet.x, Math.max(top, feet.y - 3.0), feet.z);
            }
        }
        return feet;   // melayang: mulutnya terbuka di udara
    }

    private static Vec3 clamp(ServerLevel level, Vec3 want) {
        WorldBorder wb = level.getWorldBorder();
        double x = Mth.clamp(want.x, wb.getMinX() + 1.5, wb.getMaxX() - 1.5);
        double z = Mth.clamp(want.z, wb.getMinZ() + 1.5, wb.getMaxZ() - 1.5);
        double y = Mth.clamp(want.y, level.getMinBuildHeight() + 1, level.getMaxBuildHeight() - 3);
        return new Vec3(x, y, z);
    }

    private static int top(ServerLevel level) {
        int max = level.getMaxBuildHeight() - 3;
        return level.dimensionType().hasCeiling() ? Math.min(max, level.getMinBuildHeight() + level.getLogicalHeight() - 4)
                : max;
    }

    private static int surface(ServerLevel level, int x, int z, Heightmap.Types type) {
        return level.getChunkAt(new BlockPos(x, 0, z)).getHeight(type, x & 15, z & 15) + 1;
    }

    /**
     * Tempat berdiri aman terdekat dari want (titik kaki, tengah blok), atau null. autoY: dari permukaan / langit-langit ke
     * bawah; selain itu: sekitar Y yang diminta (naik-turun sampai SEARCH_Y), melebar sampai SEARCH_XZ blok.
     */
    private static Vec3 findSafe(ServerLevel level, Vec3 want, boolean autoY) {
        int x0 = Mth.floor(want.x), z0 = Mth.floor(want.z);
        int minY = level.getMinBuildHeight() + 1, maxY = top(level);
        boolean ceiling = level.dimensionType().hasCeiling();
        int y0 = Mth.clamp(Mth.floor(want.y), minY, maxY);
        for (int r = 0; r <= SEARCH_XZ; r++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) {
                        continue;
                    }
                    int x = x0 + dx, z = z0 + dz;
                    if (autoY) {
                        int from = ceiling ? maxY : Math.min(maxY, surface(level, x, z, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES));
                        for (int y = from; y >= minY; y--) {
                            BlockPos pos = new BlockPos(x, y, z);
                            if (standable(level, pos)) {
                                return Vec3.atBottomCenterOf(pos);
                            }
                        }
                    } else {
                        for (int k = 0; k <= SEARCH_Y * 2; k++) {
                            int dy = (k + 1) / 2 * (k % 2 == 0 ? -1 : 1);
                            int y = y0 + dy;
                            if (y < minY || y > maxY) {
                                continue;
                            }
                            BlockPos pos = new BlockPos(x, y, z);
                            if (standable(level, pos)) {
                                return Vec3.atBottomCenterOf(pos);
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    private static boolean standable(ServerLevel level, BlockPos pos) {
        if (!level.getWorldBorder().isWithinBounds(pos)) {
            return false;
        }
        BlockPos below = pos.below();
        BlockState ground = level.getBlockState(below);
        if (!ground.isFaceSturdy(level, below, Direction.UP) || hurts(ground)) {
            return false;
        }
        return open(level, pos) && open(level, pos.above());
    }

    private static boolean open(ServerLevel level, BlockPos pos) {
        BlockState st = level.getBlockState(pos);
        return st.getCollisionShape(level, pos).isEmpty() && st.getFluidState().isEmpty() && !hurts(st);
    }

    private static boolean hurts(BlockState st) {
        return st.getFluidState().is(FluidTags.LAVA) || st.getBlock() instanceof BaseFireBlock || st.is(BlockTags.FIRE)
                || st.is(Blocks.MAGMA_BLOCK) || st.is(Blocks.CACTUS) || st.is(Blocks.SWEET_BERRY_BUSH)
                || st.is(Blocks.WITHER_ROSE) || st.is(Blocks.POWDER_SNOW) || st.is(Blocks.CAMPFIRE)
                || st.is(Blocks.SOUL_CAMPFIRE);
    }

    /** Nggak ada tempat aman: lantai obsidian 3x3 + ruang kosong 3x3x3 di atasnya (bedrock & isi peti nggak disentuh). */
    private static Vec3 buildPlatform(ServerLevel level, Vec3 want, boolean autoY) {
        int x = Mth.floor(want.x), z = Mth.floor(want.z);
        int minY = level.getMinBuildHeight() + 2, maxY = top(level) - 1;
        int y;
        if (autoY) {
            int h = surface(level, x, z, Heightmap.Types.MOTION_BLOCKING);
            boolean ceiling = level.dimensionType().hasCeiling();
            // langit-langit (Nether) / void (End): ketinggian tengah; selain itu di permukaan (laut: rakit obsidian)
            y = ceiling || h <= level.getMinBuildHeight() + 1 ? Math.max(level.getSeaLevel() + 1, 64) : h;
        } else {
            y = Mth.floor(want.y);
        }
        y = Mth.clamp(y, minY, maxY);
        BlockPos base = new BlockPos(x, y, z);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                BlockPos floor = base.offset(dx, -1, dz);
                BlockState fs = level.getBlockState(floor);
                if (!fixed(level, floor, fs) && (!fs.isFaceSturdy(level, floor, Direction.UP) || hurts(fs)
                        || !fs.getFluidState().isEmpty())) {
                    level.setBlockAndUpdate(floor, Blocks.OBSIDIAN.defaultBlockState());
                }
                for (int dy = 0; dy <= 2; dy++) {
                    BlockPos q = base.offset(dx, dy, dz);
                    BlockState qs = level.getBlockState(q);
                    if (!qs.isAir() && !fixed(level, q, qs)) {
                        level.setBlockAndUpdate(q, Blocks.AIR.defaultBlockState());
                    }
                }
            }
        }
        return standable(level, base) ? Vec3.atBottomCenterOf(base) : null;
    }

    /** Blok yang nggak boleh diubah: bedrock / barrier / portal End, dan blok berisi (peti, tungku, spawner). */
    private static boolean fixed(ServerLevel level, BlockPos pos, BlockState st) {
        return st.getDestroySpeed(level, pos) < 0f || level.getBlockEntity(pos) != null;
    }

    // ---------------------------------------------------------------- bantuan

    private static void ticket(ServerLevel level, Vec3 c) {
        BlockPos pos = BlockPos.containing(c);
        level.getChunkSource().addRegionTicket(TicketType.PORTAL, new ChunkPos(pos), 3, pos);
    }

    private static void play(ServerLevel level, Vec3 at, SoundEvent sound, float volume) {
        level.playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume * RelativaTier.SOUND, 1f);
    }

    private static void send(MinecraftServer server, Hole h, int only, int state) {
        for (int side = 0; side < 2; side++) {
            if (only >= 0 && side != only) {
                continue;
            }
            ServerLevel level = server.getLevel(h.m[side].dim());
            if (level != null) {
                PacketDistributor.sendToPlayersInDimension(level, payload(h, side, state));
            }
        }
    }

    private static RelativaNetwork.WormholePayload payload(Hole h, int side, int state) {
        Mouth m = h.m[side];
        return new RelativaNetwork.WormholePayload(h.id, side, state, h.m[1 - side].dim().location().toString(), m.c().x,
                m.c().y, m.c().z, RADIUS, h.age, h.life);
    }

    /** Nama dimensi buat pesan: Overworld / Nether / End (file bahasa), selain itu id-nya. */
    public static Component dimName(ResourceKey<Level> dim) {
        ResourceLocation loc = dim.location();
        return Component.translatableWithFallback("dimension.shazammod." + loc.getNamespace() + "." + loc.getPath(),
                loc.toString());
    }
}
