package com.shazammod.relativa.client;

import com.shazammod.relativa.RelativaClientState;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.phys.Vec3;

/**
 * 0.70 Terbang FOTON TANPA MASSA (dihitung di client pemain sendiri, sama seperti terbang juara). Partikel tak bermassa
 * nggak punya kelembaman: arah terbangnya langsung mengikuti pandangan (W ke mana mata memandang, A/D geser, spasi / Shift
 * naik-turun), berhenti seketika saat tombol dilepas (nggak meluncur), dan Sprint = mendekati kecepatan cahaya. Fisika
 * terbang bawaan dimatikan (kecepatan terbang 0) selama terbang foton; mendarat & double-tap spasi tetap seperti biasa.
 */
public final class RelativaPhotonFlight {
    private RelativaPhotonFlight() {}

    // ======= Angka yang gampang diutak-atik (blok per tick; x20 = blok per detik) =======
    private static final double CRUISE = 1.2;     // W: 24 blok/dtk
    private static final double LIGHT = 3.8;      // W + Sprint: 76 blok/dtk ("c")
    private static final double VERTICAL = 0.8;   // spasi / Shift
    private static final double RESPONSE = 0.6;   // tanpa massa: hampir langsung menurut (sisanya biar enak dilihat)
    private static final double STOP = 0.3;       // tombol dilepas: berhenti hampir seketika
    // ===================================================================================

    private static boolean active;
    private static boolean zeroed;
    private static Vec3 velocity = Vec3.ZERO;

    /** Sedang terbang foton (dipakai pose & efek). */
    public static boolean flying() {
        return active && zeroed;
    }

    public static double speed() {
        return flying() ? velocity.length() : 0.0;
    }

    /** Sebelum gerak pemain dihitung. */
    public static void preTick(LocalPlayer player) {
        boolean on = RelativaClientState.transformed && RelativaClientState.photon && !player.isSpectator()
                && !player.isPassenger();
        if (!on) {
            if (active) {
                reset(player);
            }
            return;
        }
        active = true;
        Abilities a = player.getAbilities();
        if (!a.flying) {
            restore(a);
            velocity = Vec3.ZERO;
            return;
        }
        if (a.getFlyingSpeed() != 0f) {
            a.setFlyingSpeed(0f);   // fisika terbang bawaan dimatikan; geraknya diatur di sini
        }
        if (!zeroed) {
            velocity = player.getDeltaMovement();   // baru lepas landas: dorongan ke atas dari server tetap terasa
        }
        zeroed = true;
        Input in = player.input;
        Vec3 look = player.getViewVector(1f);
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : flat.normalize();
        Vec3 right = new Vec3(-flat.z, 0, flat.x);
        Vec3 dir = look.scale(in.forwardImpulse).add(right.scale(-in.leftImpulse));
        if (dir.lengthSqr() > 1.0) {
            dir = dir.normalize();
        }
        int vert = (in.jumping ? 1 : 0) - (in.shiftKeyDown ? 1 : 0);
        boolean sprint = Minecraft.getInstance().options.keySprint.isDown() || player.isSprinting();
        double sp = sprint ? LIGHT : CRUISE;
        Vec3 target = dir.scale(sp).add(0, vert * VERTICAL * (sprint ? 1.8 : 1.0), 0);
        boolean input = dir.lengthSqr() > 1.0E-4 || vert != 0;
        velocity = input ? velocity.lerp(target, RESPONSE) : velocity.scale(STOP);
        if (velocity.lengthSqr() < 1.0E-5) {
            velocity = Vec3.ZERO;
        }
        player.setDeltaMovement(velocity);
        player.resetFallDistance();
    }

    private static void restore(Abilities a) {
        if (zeroed) {
            if (a.getFlyingSpeed() == 0f) {
                a.setFlyingSpeed(0.05f);   // terbang kreatif biasa
            }
            zeroed = false;
        }
    }

    public static void reset(LocalPlayer player) {
        if (player != null) {
            restore(player.getAbilities());
        }
        zeroed = false;
        active = false;
        velocity = Vec3.ZERO;
    }
}
