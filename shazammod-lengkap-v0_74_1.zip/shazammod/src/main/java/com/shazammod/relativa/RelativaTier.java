package com.shazammod.relativa;

/**
 * 0.68 RELATIVA juara tingkat dewa (setara PRALAYA Fase Dewa). Satu tempat buat semua pengali "besar"-nya, dipakai server
 * (RelativaSkills, RelativaLight, RelativaAbilities) dan client (RelativaFx, RelativaEffects, RelativaQuantum) supaya
 * dampak di server dan ukuran efek di layar selalu sama besar. Ubah angka di sini untuk membesarkan / mengecilkan semuanya
 * sekaligus (1 = ukuran 0.66-0.67).
 */
public final class RelativaTier {
    private RelativaTier() {}

    /** Radius, jangkauan, & ukuran efek area semua skill (2 = dua kali lipat 0.67). */
    public static final double AREA = 2.0;
    public static final float AREA_F = (float) AREA;
    /** Pengali damage semua skill. */
    public static final float DAMAGE = 3.0f;
    /** Pengali hempasan (knockback) skill. */
    public static final double PUSH = 1.6;
    /** Cooldown skill: 0,35 = tinggal 35% dari 0.67. */
    public static final float COOLDOWN = 0.35f;
    /** Biaya energi skill: 0,5 = separuh. */
    public static final float COST = 0.5f;
    /** Ukuran efek yang menempel di badan / tangan / sasaran (kilatan, inti atom, sinar, bintang mini). */
    public static final float FX = 1.5f;
    /** Guncangan kamera, kilatan layar, & jangkauan guncangan untuk pemain lain. */
    public static final float SHAKE = 1.5f;
    /** Volume suara skill (lebih dari 1 = terdengar lebih jauh: 16 blok x volume). */
    public static final float SOUND = 1.6f;

    // ======= 0.71 SKALA GUNUNG: Massa Kritis (Shift+V) & Lubang Hitam (Shift+X) =======
    // Ukuran dunia dalam blok, dipakai server (RelativaSkills: damage, tarikan, kawah) DAN client (RelativaFx,
    // RelativaEffects: bola api, awan jamur, gelombang kejut, piringan akresi, lensa), jadi yang terlihat = yang kena.

    /** Lubang Hitam & Massa Kritis selalu muncul minimal sejauh ini (mendatar) dari pemain: kamu nggak ikut terkubur kawahnya. */
    public static final double MOUNTAIN_MIN = 48.0;

    /** Massa Kritis: jari-jari bola api (semua yang di dalamnya kena damage penuh seketika). */
    public static final double NUKE_FIREBALL = 30.0;
    /** Massa Kritis: gelombang kejut merambat sampai sejauh ini. */
    public static final double NUKE_RADIUS = 100.0;
    /** Massa Kritis: kecepatan gelombang kejut (blok per tick, server & client sama). */
    public static final double NUKE_WAVE_SPEED = 3.5;
    /** Massa Kritis: jari-jari kawah (dalamnya 0,6x; mobGriefing). */
    public static final int NUKE_CRATER = 40;
    /** Massa Kritis: tinggi puncak awan jamur di atas titik nol, dan jari-jari kepalanya. */
    public static final double NUKE_CLOUD = 130.0, NUKE_CAP = 50.0;
    /** Massa Kritis: zona radiasi sisa (jari-jari, lama dalam tick). */
    public static final double NUKE_RAD = 44.0;
    public static final int NUKE_RAD_TICKS = 400;

    /** Lubang Hitam: jari-jari cakrawala peristiwa saat penuh (piringan akresinya ±4,8x, jetnya ±6x). */
    public static final double HOLE_HORIZON = 14.0;
    /** Lubang Hitam: melayang setinggi ini di atas tanah yang dibidik. */
    public static final double HOLE_LIFT = 26.0;
    /** Lubang Hitam: makhluk ditarik dari sejauh ini. */
    public static final double HOLE_PULL = 100.0;
    /** Lubang Hitam: tanah di bawahnya dicabut sampai jari-jari ini (mendatar) & sedalam HOLE_DIG di tengah. */
    public static final double HOLE_EAT = 36.0, HOLE_DIG = 16.0;
    /** Lubang Hitam: ledakan Hawking (jari-jari damage, jari-jari kawah). */
    public static final double HAWKING_RADIUS = 64.0;
    public static final int HAWKING_CRATER = 26;

    /** Cooldown (detik) sesudah dikali COOLDOWN, paling sedikit 1 detik. Lama medan yang menyala ada di ShazamAnim.REL_*. */
    public static int cooldown(int seconds) {
        return seconds <= 0 ? 0 : Math.max(1, Math.round(seconds * COOLDOWN));
    }
}
