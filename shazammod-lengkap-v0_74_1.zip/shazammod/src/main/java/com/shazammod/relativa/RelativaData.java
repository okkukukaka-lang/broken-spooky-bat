package com.shazammod.relativa;

import java.util.ArrayList;
import java.util.List;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/**
 * 0.66 Data RELATIVA milik tiap pemain (attachment "relativa", ikut tersimpan & tetap ada sesudah mati).
 *
 * unlocked    = Eksperimen Pikiran sudah berhasil (RELATIVA terbuka), atau lewat /relativa unlock
 * transformed = sedang dalam wujud RELATIVA
 * energy      = Energi (E), 0-100
 * papers      = makalah 1905 (Annus Mirabilis) yang sudah tertulis di Jurnal: bit 0 Efek Fotolistrik, 1 Gerak Brown,
 *               2 Relativitas Khusus, 3 E=mc²
 * cooldowns   = per slot (tick): 0-5 Z..N, 6-11 Shift+Z..N, lalu SLOT_*
 * phase       = 0.67 pasif Terowongan Kuantum menyala (tombol I, tanpa batas waktu, padam saat kembali jadi manusia)
 * photon      = 0.70 Foton Tanpa Massa: mode terbang (tombol F, tanpa batas waktu)
 * cloak       = 0.70 Cincin Einstein: tak terlihat (tombol H, tanpa batas waktu)
 */
public final class RelativaData {
    public static final float MAX_ENERGY = 100f;
    public static final int SLOT_SHIFT = 6;
    public static final int SLOT_R = 12, SLOT_R_SHIFT = 13, SLOT_M = 14, SLOT_M_SHIFT = 15, SLOT_J = 16, SLOT_J_SHIFT = 17,
            SLOT_LIGHT = 18, SLOT_KNOCKOUT = 19,   // 0.68 SLOT_KNOCKOUT: jeda sesudah terlempar balik jadi manusia
            SLOT_WORMHOLE = 20, SLOT_CLONE = 21, SLOTS = 22;   // 0.70 Jembatan Einstein-Rosen & Kucing Schrödinger
    public static final int PAPER_PHOTO = 0, PAPER_BROWN = 1, PAPER_RELATIVITY = 2, PAPER_EMC = 3, PAPERS = 4;
    public static final int PAPERS_ALL = (1 << PAPERS) - 1;
    /** Kecepatan bintang mini Fusi Bintang (blok/tick), dipakai server & client supaya ledakannya jatuh di tick yang sama. */
    public static final double FUSION_SPEED = 1.8;

    public boolean unlocked;
    public boolean transformed;
    public float energy = MAX_ENERGY;
    public int papers;
    public final int[] cooldowns = new int[SLOTS];
    public boolean phase;
    public boolean photon;          // 0.70 Foton Tanpa Massa
    public boolean cloak;           // 0.70 Cincin Einstein

    // ---- nggak disimpan
    public int morphing;
    public long lastToggle;
    public int dilationTicks;
    public int tokamakTicks;
    public int entangleTicks;
    public int holeTicks;
    public int dodgeCooldown;
    public int lightState;          // 0.67 Kecepatan Cahaya: RelativaLight.NONE / WINDUP / ACTIVE / RESUME
    public int lightTicks;          //   sisa tick waktu berhenti (buat HUD)
    public long lastPhaseToggle;
    public long lastPhotonToggle;   // 0.70
    public long lastCloakToggle;
    public int cloakReveal;         //   sisa tick terlihat sesudah menyerang dari balik Cincin Einstein
    public boolean cloakShown;      //   status tak terlihat yang terakhir dikirim ke pemain lain
    public int decoyGap;            //   jeda antar-salinan Kucing Schrödinger yang menanggung pukulan

    public static final Codec<RelativaData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.BOOL.optionalFieldOf("unlocked", false).forGetter((RelativaData d) -> d.unlocked),
            Codec.BOOL.optionalFieldOf("transformed", false).forGetter((RelativaData d) -> d.transformed),
            Codec.FLOAT.optionalFieldOf("energy", MAX_ENERGY).forGetter((RelativaData d) -> d.energy),
            Codec.INT.optionalFieldOf("papers", 0).forGetter((RelativaData d) -> d.papers),
            Codec.INT.listOf().optionalFieldOf("cooldowns", List.of()).forGetter((RelativaData d) -> list(d.cooldowns)),
            Codec.BOOL.optionalFieldOf("phase", false).forGetter((RelativaData d) -> d.phase),
            Codec.BOOL.optionalFieldOf("photon", false).forGetter((RelativaData d) -> d.photon),
            Codec.BOOL.optionalFieldOf("cloak", false).forGetter((RelativaData d) -> d.cloak)
    ).apply(instance, RelativaData::new));

    public RelativaData() {}

    private RelativaData(boolean unlocked, boolean transformed, float energy, int papers, List<Integer> cooldowns,
                         boolean phase, boolean photon, boolean cloak) {
        this.unlocked = unlocked;
        this.transformed = transformed && unlocked;
        this.energy = Math.max(0f, Math.min(MAX_ENERGY, energy));
        this.papers = papers & PAPERS_ALL;
        for (int i = 0; i < Math.min(cooldowns.size(), this.cooldowns.length); i++) {
            this.cooldowns[i] = Math.max(0, cooldowns.get(i));
        }
        this.phase = phase && this.transformed;
        this.photon = photon;   // 0.70: dipasang ulang / dilepas saat masuk (RelativaAbilities.onLogin)
        this.cloak = cloak && this.transformed;
    }

    private static List<Integer> list(int[] values) {
        List<Integer> out = new ArrayList<>(values.length);
        for (int v : values) {
            out.add(v);
        }
        return out;
    }

    public boolean hasPaper(int paper) {
        return (papers & (1 << paper)) != 0;
    }

    public boolean coolingDown() {
        for (int c : cooldowns) {
            if (c > 0) {
                return true;
            }
        }
        return false;
    }
}
