package com.shazammod.relativa;

import java.util.function.Supplier;

import com.shazammod.ShazamMod;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

/** 0.66 Semua yang didaftarkan untuk RELATIVA: data pemain & Jurnal Annus Mirabilis (0.70: salinan Kucing Schrödinger). */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class RelativaRegistry {
    private RelativaRegistry() {}

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, ShazamMod.MODID);

    public static final Supplier<AttachmentType<RelativaData>> DATA = ATTACHMENTS.register("relativa",
            () -> AttachmentType.builder(() -> new RelativaData())
                    .serialize(RelativaData.CODEC)
                    .copyOnDeath()
                    .build());

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ShazamMod.MODID);

    /** Jurnal Annus Mirabilis: empat makalah 1905 ditulis dengan mengalaminya sendiri, lalu Eksperimen Pikiran. */
    public static final DeferredItem<AnnusMirabilisItem> JOURNAL = ITEMS.register("annus_mirabilis",
            () -> new AnnusMirabilisItem(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC)));

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, ShazamMod.MODID);

    /** 0.70 Salinan Kucing Schrödinger: seukuran pemain, digambar sebagai pemain boneka di client. Nggak disimpan. */
    public static final DeferredHolder<EntityType<?>, EntityType<RelativaClone>> CLONE = ENTITIES.register("relativa_clone",
            () -> EntityType.Builder.<RelativaClone>of(RelativaClone::new, MobCategory.MISC)
                    .fireImmune().sized(0.6f, 1.8f).eyeHeight(1.62f).clientTrackingRange(10).updateInterval(2).noSave()
                    .build("relativa_clone"));

    public static void register(IEventBus modEventBus) {
        ATTACHMENTS.register(modEventBus);
        ITEMS.register(modEventBus);
        ENTITIES.register(modEventBus);
    }

    @SubscribeEvent
    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(CLONE.get(), RelativaClone.createAttributes().build());
    }

    @SubscribeEvent
    public static void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(JOURNAL.get());
        }
    }
}
