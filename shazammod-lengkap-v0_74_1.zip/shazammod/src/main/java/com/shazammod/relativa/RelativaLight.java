package com.shazammod.relativa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.shazammod.PralayaGod;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 0.67 KECEPATAN CAHAYA (tombol O): RELATIVA melesat mendekati kecepatan cahaya. Dilatasi waktu t' = γt: makin dekat ke c,
 * γ makin besar, dan dari kerangka acuan RELATIVA semua jam lain berdetak makin lambat sampai praktis BERHENTI.
 *
 *   ancang-ancang (REL_LIGHT_WINDUP)  dunia di sekitar melambat: makhluk merayap, proyektil tertahan di udara
 *   waktu berhenti                    tick freeze bawaan Minecraft (sama dengan /tick freeze & Henti Waktu Dunia PRALAYA):
 *                                     makhluk, proyektil, item, redstone, siang-malam membeku. Pemain lain ikut terkunci.
 *                                     RELATIVA bebas bergerak (jauh lebih cepat), pukulannya ke makhluk yang membeku
 *                                     DITABUNG (energi kinetik relativistik) lalu dilepas sekaligus x2 saat waktu jalan lagi
 *   selesai                           tekan O lagi, energi habis (terkuras tiap detik), atau REL_LIGHT_TICKS habis;
 *                                     jeda REL_LIGHT_RESUME (jam mulai berdetak) lalu waktu berjalan lagi
 *
 * Cuma satu pemegang waktu sekaligus: nggak bisa dipakai saat dunia sudah beku (PRALAYA / /tick freeze), dan PRALAYA nggak
 * bisa menghentikan waktu selama RELATIVA memegangnya.
 */
public final class RelativaLight {
    private RelativaLight() {}

    // ======= Angka yang gampang diutak-atik =======
    // 0.68 tingkat dewa: lebih murah, lebih lama (REL_LIGHT_TICKS 30 dtk), tagihan x2, cooldown 8 dtk
    public static final float COST = 15f;              // energi saat mulai
    public static final float DRAIN = 2f;              // energi per detik selama waktu berhenti
    public static final int COOLDOWN = 8 * 20;         // tick, sesudah waktu berjalan lagi
    public static final double SLOW_RADIUS = 96.0;     // jangkauan perlambatan saat ancang-ancang
    public static final float INTEREST = 2.0f;         // damage yang ditabung ditagih x2
    public static final double SPEED = 3.0;            // +300% kecepatan lari selama waktu berhenti
    public static final double JUMP = 0.15;
    public static final double STEP = 0.6;
    private static final double PUSH = 0.6, PUSH_MAX = 3.4;
    private static final int HUM_EVERY = 60;

    public static final int NONE = 0, WINDUP = 1, ACTIVE = 2, RESUME = 3;

    private static UUID owner;
    private static int state = NONE;
    private static int timer;
    private static boolean wasFrozen;
    private static final Map<UUID, Float> STORED = new HashMap<>();
    private static final Map<UUID, Vec3> PUSHED = new HashMap<>();
    private static final Map<UUID, Vec3> LOCKED = new HashMap<>();
    private static final Map<UUID, Long> HIT_FX = new HashMap<>();
    /** Proyektil yang ditahan saat ancang-ancang: kecepatan aslinya dikembalikan saat waktu berjalan lagi. */
    private static final Map<Projectile, Vec3> HELD = new HashMap<>();

    // ---------------------------------------------------------------- status

    /** Ada RELATIVA yang sedang memegang waktu (ancang-ancang, waktu berhenti, atau menunggu jalan lagi). */
    public static boolean holdsTime() {
        return owner != null;
    }

    public static boolean owns(Player p) {
        return owner != null && owner.equals(p.getUUID());
    }

    /** Waktu dunia sedang benar-benar berhenti (bukan ancang-ancang). */
    public static boolean stopped() {
        return owner != null && (state == ACTIVE || state == RESUME);
    }

    /** Pemain ini ikut membeku karena waktu dihentikan RELATIVA lain (dipakai PralayaGod.frozen di server). */
    public static boolean freezes(Player p) {
        return stopped() && !p.level().isClientSide() && !owner.equals(p.getUUID()) && !p.isCreative() && !p.isSpectator();
    }

    // ---------------------------------------------------------------- tombol O

    public static void toggle(ServerPlayer p, RelativaData d) {
        if (!d.transformed || d.morphing > 0 || !p.isAlive() || PralayaGod.frozen(p)) {
            return;
        }
        if (owns(p)) {
            if (state == ACTIVE) {
                beginResume(p, d);
            }
            return;
        }
        if (owner != null) {
            RelativaAbilities.msg(p, "light_busy", ChatFormatting.GRAY);
            return;
        }
        MinecraftServer server = p.server;
        if (PralayaGod.stopped() || server.tickRateManager().isFrozen()) {
            RelativaAbilities.msg(p, "light_frozen", ChatFormatting.GRAY);
            return;
        }
        if (!RelativaSkills.free(p)) {
            return;
        }
        if (d.cooldowns[RelativaData.SLOT_LIGHT] > 0) {
            RelativaAbilities.msg(p, "cooldown", ChatFormatting.RED, (d.cooldowns[RelativaData.SLOT_LIGHT] + 19) / 20);
            return;
        }
        if (!p.getAbilities().instabuild && d.energy < COST) {
            RelativaAbilities.msg(p, "no_energy", ChatFormatting.RED, Math.round(d.energy), Math.round(COST));
            return;
        }
        if (!p.getAbilities().instabuild) {
            d.energy -= COST;
        }
        owner = p.getUUID();
        state = WINDUP;
        timer = ShazamAnim.REL_LIGHT_WINDUP;
        STORED.clear();
        PUSHED.clear();
        LOCKED.clear();
        HIT_FX.clear();
        HELD.clear();
        d.lightState = WINDUP;
        d.lightTicks = ShazamAnim.REL_LIGHT_TICKS;
        RelativaSkills.busy(p, ShazamAnim.REL_LIGHT_WINDUP);
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_LIGHT);
        RelativaSkills.sound(p, p.position(), ShazamSounds.RELATIVA_LIGHT_ON.get(), 3.0f);
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    // ---------------------------------------------------------------- tiap tick pemiliknya

    public static void tick(ServerPlayer p, RelativaData d) {
        if (!owns(p)) {
            return;
        }
        MinecraftServer server = p.server;
        if (!d.transformed || !p.isAlive()) {
            end(server, true);
            return;
        }
        switch (state) {
            case WINDUP -> {
                slowWorld(p, ShazamAnim.REL_LIGHT_WINDUP - timer);
                if (--timer <= 0) {
                    freeze(p, d);
                }
            }
            case ACTIVE -> {
                if (!server.tickRateManager().isFrozen()) {   // dicairkan dari luar (/tick unfreeze): ikut selesai
                    end(server, false);
                    return;
                }
                timer++;
                d.lightTicks = Math.max(0, ShazamAnim.REL_LIGHT_TICKS - timer);
                if (!p.getAbilities().instabuild) {
                    d.energy = Math.max(0f, d.energy - DRAIN / 20f);
                }
                if (timer % HUM_EVERY == 0) {
                    RelativaSkills.sound(p, p.position(), ShazamSounds.RELATIVA_LIGHT_HUM.get(), 1.6f);
                }
                p.resetFallDistance();
                lockPlayers(server);
                if (timer >= ShazamAnim.REL_LIGHT_TICKS || (!p.getAbilities().instabuild && d.energy <= 0f)) {
                    beginResume(p, d);
                }
            }
            case RESUME -> {
                if (!server.tickRateManager().isFrozen()) {
                    end(server, false);
                    return;
                }
                p.resetFallDistance();
                lockPlayers(server);
                if (--timer <= 0) {
                    end(server, true);
                }
            }
            default -> { }
        }
    }

    /** Ancang-ancang: makin dekat ke c, waktu di sekitar makin lambat (makhluk merayap, proyektil tertahan). */
    private static void slowWorld(ServerPlayer p, int age) {
        if (age % 2 != 0) {
            return;
        }
        ServerLevel level = p.serverLevel();
        Vec3 c = p.position();
        int amp = Math.min(6, 1 + age / 3);
        for (LivingEntity e : RelativaSkills.around(p, c, SLOW_RADIUS)) {
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 8, amp, false, false), p);
            e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 8, amp, false, false), p);
        }
        AABB box = new AABB(c, c).inflate(SLOW_RADIUS);
        for (Projectile pr : level.getEntitiesOfClass(Projectile.class, box, x -> x.getOwner() != p)) {
            if (!HELD.containsKey(pr)) {
                HELD.put(pr, pr.getDeltaMovement());
                pr.setNoGravity(true);
            }
            pr.setDeltaMovement(pr.getDeltaMovement().scale(0.68));
            pr.hurtMarked = true;
        }
    }

    private static void freeze(ServerPlayer p, RelativaData d) {
        MinecraftServer server = p.server;
        if (PralayaGod.stopped()) {   // keduluan PRALAYA di tick yang sama: batal, energi dikembalikan
            d.energy = Math.min(RelativaData.MAX_ENERGY, d.energy + COST);
            reset(p, d, false);
            return;
        }
        wasFrozen = server.tickRateManager().isFrozen();
        server.tickRateManager().setFrozen(true);
        state = ACTIVE;
        timer = 0;
        d.lightState = ACTIVE;
        AttributeModifier.Operation mul = AttributeModifier.Operation.ADD_MULTIPLIED_BASE;
        RelativaPowers.set(p, Attributes.MOVEMENT_SPEED, "light_speed", SPEED, mul);
        RelativaPowers.set(p, Attributes.JUMP_STRENGTH, "light_jump", JUMP, AttributeModifier.Operation.ADD_VALUE);
        RelativaPowers.set(p, Attributes.STEP_HEIGHT, "light_step", STEP, AttributeModifier.Operation.ADD_VALUE);
        RelativaNetwork.broadcastWorld(p.getId(), 1);
        for (ServerPlayer other : server.getPlayerList().getPlayers()) {
            if (other != p) {
                other.displayClientMessage(Component.translatable("message.shazammod.relativa.light_world", p.getDisplayName())
                        .withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), false);
            }
        }
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    private static void beginResume(ServerPlayer p, RelativaData d) {
        state = RESUME;
        timer = ShazamAnim.REL_LIGHT_RESUME;
        d.lightState = RESUME;
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_LIGHT_END);
        RelativaSkills.sound(p, p.position(), ShazamSounds.RELATIVA_LIGHT_END.get(), 3.0f);
        RelativaNetwork.sync(p);
    }

    /** Pemain lain ikut membeku: posisinya dikunci (sama seperti Henti Waktu Dunia PRALAYA). */
    private static void lockPlayers(MinecraftServer server) {
        for (ServerPlayer other : server.getPlayerList().getPlayers()) {
            if (!freezes(other) || !other.isAlive()) {
                LOCKED.remove(other.getUUID());
                continue;
            }
            Vec3 at = LOCKED.get(other.getUUID());
            if (at == null) {
                other.stopRiding();
                LOCKED.put(other.getUUID(), other.position());
                continue;
            }
            if (other.position().distanceToSqr(at) > 0.0025) {
                other.connection.teleport(at.x, at.y, at.z, other.getYRot(), other.getXRot());
            }
            other.setDeltaMovement(Vec3.ZERO);
            other.fallDistance = 0f;
        }
    }

    // ---------------------------------------------------------------- waktu berjalan lagi

    /** Waktu berjalan lagi: semua pukulan yang ditabung dilepas sekaligus. unfreeze false = sudah dicairkan dari luar. */
    public static void end(MinecraftServer server, boolean unfreeze) {
        if (owner == null) {
            return;
        }
        ServerPlayer p = server.getPlayerList().getPlayer(owner);
        boolean frozeWorld = state == ACTIVE || state == RESUME;
        int ownerId = p != null ? p.getId() : -1;
        owner = null;
        state = NONE;
        if (frozeWorld && unfreeze) {
            server.tickRateManager().setFrozen(wasFrozen);
        }
        for (Map.Entry<Projectile, Vec3> e : HELD.entrySet()) {   // proyektil melesat lagi dengan kecepatan aslinya
            Projectile pr = e.getKey();
            if (pr.isAlive()) {
                pr.setNoGravity(false);
                pr.setDeltaMovement(e.getValue());
                pr.hurtMarked = true;
            }
        }
        HELD.clear();
        float total = 0f;
        int count = 0;
        for (Map.Entry<UUID, Float> e : STORED.entrySet()) {
            for (ServerLevel level : server.getAllLevels()) {
                if (level.getEntity(e.getKey()) instanceof LivingEntity m && m.isAlive()) {
                    float amount = e.getValue() * INTEREST;
                    PralayaGod.chargeDebt(m, p != null ? RelativaSkills.magic(p) : level.damageSources().magic(), amount);
                    Vec3 push = PUSHED.get(e.getKey());
                    if (push != null) {   // semua pukulan yang ditabung melempar korbannya sekaligus
                        m.push(push.x, push.y, push.z);
                        m.hurtMarked = true;
                    }
                    total += amount;
                    count++;
                    break;
                }
            }
        }
        STORED.clear();
        PUSHED.clear();
        LOCKED.clear();
        HIT_FX.clear();
        if (frozeWorld) {
            RelativaNetwork.broadcastWorld(ownerId, 0);
        }
        if (p != null) {
            RelativaData d = RelativaAbilities.data(p);
            reset(p, d, frozeWorld);
            if (count > 0) {
                p.displayClientMessage(Component.translatable("message.shazammod.relativa.light_resume", count,
                        Math.round(total)).withStyle(ChatFormatting.AQUA), false);
            }
        }
    }

    private static void reset(ServerPlayer p, RelativaData d, boolean cooldown) {
        owner = null;
        state = NONE;
        d.lightState = NONE;
        d.lightTicks = 0;
        if (cooldown) {
            d.cooldowns[RelativaData.SLOT_LIGHT] = COOLDOWN;
        }
        RelativaPowers.clear(p, Attributes.MOVEMENT_SPEED, "light_speed");
        RelativaPowers.clear(p, Attributes.JUMP_STRENGTH, "light_jump");
        RelativaPowers.clear(p, Attributes.STEP_HEIGHT, "light_step");
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    /** Tiap tick server: pemiliknya keluar / mati di tengah jalan, waktu langsung berjalan lagi. */
    public static void serverTick(MinecraftServer server) {
        if (owner == null) {
            return;
        }
        ServerPlayer p = server.getPlayerList().getPlayer(owner);
        if (p == null || !p.isAlive() || p.isRemoved()) {
            end(server, true);
        }
    }

    /** Pemain masuk di tengah waktu yang berhenti: client-nya dikabari (layar membeku). */
    public static void onLogin(ServerPlayer player) {
        if (stopped()) {
            ServerPlayer p = player.server.getPlayerList().getPlayer(owner);
            RelativaNetwork.sendWorld(player, p != null ? p.getId() : -1, 1);
        }
    }

    /** Pemilik kembali jadi manusia / keluar / respawn: waktu langsung berjalan lagi (tanpa jeda). */
    public static void drop(ServerPlayer p) {
        if (owns(p)) {
            end(p.server, true);
        }
    }

    public static void clear(MinecraftServer server) {
        end(server, true);
    }

    // ---------------------------------------------------------------- damage selama waktu berhenti

    /**
     * Lebih awal: selama waktu berhenti cuma pukulan RELATIVA pemegang waktu ke makhluk (bukan pemain) yang dihitung
     * (ditabung di onIncomingLast); damage lain ke siapa pun selain pemiliknya diabaikan (waktu mereka sedang berhenti).
     */
    public static void intercept(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        if (!stopped() || victim.level().isClientSide() || owner.equals(victim.getUUID()) || PralayaGod.collectingDebt()
                || event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        if (!(victim instanceof Player) && isOwner(event.getSource().getEntity())) {
            return;   // dibiarkan lewat dulu (pengali Tinju Foton & skill dihitung), ditabung di onIncomingLast
        }
        event.setCanceled(true);
    }

    /** Paling akhir: damage final RELATIVA ke makhluk yang membeku ditabung lalu dibatalkan. */
    public static void onIncomingLast(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        Entity attacker = event.getSource().getEntity();
        if (!stopped() || victim.level().isClientSide() || PralayaGod.collectingDebt() || owner.equals(victim.getUUID())
                || victim instanceof Player || !isOwner(attacker) || event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return;
        }
        float amount = event.getAmount();
        event.setCanceled(true);
        if (amount <= 0f) {
            return;
        }
        STORED.merge(victim.getUUID(), amount, Float::sum);
        boolean melee = event.getSource().getDirectEntity() == attacker;
        Vec3 dir = melee ? attacker.getLookAngle() : victim.position().subtract(attacker.position());
        dir = new Vec3(dir.x, 0, dir.z);
        dir = dir.lengthSqr() < 1.0E-4 ? Vec3.ZERO : dir.normalize().scale(melee ? PUSH : PUSH * 0.4);
        Vec3 push = PUSHED.getOrDefault(victim.getUUID(), Vec3.ZERO).add(dir.x, melee ? 0.14 : 0.05, dir.z);
        double flat = Math.sqrt(push.x * push.x + push.z * push.z);
        if (flat > PUSH_MAX) {
            push = new Vec3(push.x * PUSH_MAX / flat, push.y, push.z * PUSH_MAX / flat);
        }
        PUSHED.put(victim.getUUID(), new Vec3(push.x, Math.min(push.y, 1.1), push.z));
        if (attacker instanceof ServerPlayer p) {
            long now = p.server.getTickCount();
            Long last = HIT_FX.get(victim.getUUID());
            if (last == null || now - last >= 3) {   // pukulan membeku di udara (efek & suara, dibatasi)
                HIT_FX.put(victim.getUUID(), now);
                Vec3 at = melee ? hitPoint(p, victim) : RelativaAbilities.chest(victim);
                ShazamNetwork.playAnim(p, ShazamAnim.PHYS_TIME_HIT, at);
                RelativaSkills.sound(p, at, ShazamSounds.RELATIVA_TIME_HIT.get(), 1.4f);
            }
            float total = STORED.getOrDefault(victim.getUUID(), 0f) * INTEREST;
            p.displayClientMessage(Component.translatable("message.shazammod.relativa.light_debt", victim.getDisplayName(),
                    Math.round(total)).withStyle(ChatFormatting.AQUA), true);
        }
    }

    private static boolean isOwner(Entity e) {
        return owner != null && e != null && owner.equals(e.getUUID());
    }

    /** Titik pukulan di badan korban (sisi yang menghadap penyerang). */
    private static Vec3 hitPoint(ServerPlayer p, LivingEntity victim) {
        Vec3 c = RelativaAbilities.chest(victim);
        Vec3 toward = p.getEyePosition().subtract(c);
        toward = new Vec3(toward.x, 0, toward.z);
        if (toward.lengthSqr() < 1.0E-4) {
            return c;
        }
        return c.add(toward.normalize().scale(victim.getBbWidth() * 0.5));
    }

    /** Daftar korban yang sedang menabung damage (buat efek & perintah). */
    public static List<UUID> stored() {
        return new ArrayList<>(STORED.keySet());
    }
}
