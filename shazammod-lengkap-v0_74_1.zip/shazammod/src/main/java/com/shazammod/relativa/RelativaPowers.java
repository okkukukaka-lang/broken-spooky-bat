package com.shazammod.relativa;

import com.shazammod.ShazamMod;

import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;

/**
 * Stat wujud RELATIVA (modifier atribut sementara, dipasang ulang saat login).
 *
 * 0.68 tingkat dewa, setara PRALAYA Fase Dewa: darah sampai batas maksimal Minecraft (1024), armor & ketangguhan setara
 * juara lain (full netherite), kebal knockback, hempasan, kecepatan pukul, jangkauan, & pecah blok seperti juara, badan 10%
 * lebih besar, plus perisai E=mc² (absorption) yang bisa terisi sampai 60. Damage yang diterima (5%), tinju dewa, dan
 * pulihnya ada di RelativaAbilities.
 */
public final class RelativaPowers {
    private RelativaPowers() {}

    // ======= Angka yang gampang diutak-atik =======
    public static final double HEALTH = 1004.0;       // 0.68 darah 20 -> 1024, batas maksimal darah di Minecraft (2 = 1 hati)
    public static final double ARMOR = 20.0;          // setara full netherite, sama dengan juara lain
    public static final double TOUGHNESS = 12.0;
    public static final double KNOCKBACK = 1.0;       // kebal knockback
    public static final double ATTACK_KNOCKBACK = 2.5; // musuh yang dipukul terpental jauh (sama dengan Shazam)
    public static final double ATTACK_SPEED = 1.0;    // pukulan penuh lebih cepat (sama dengan juara)
    public static final double SPEED = 0.6;           // +60% kecepatan jalan (juara cahaya)
    public static final double JUMP = 0.25;
    public static final double STEP = 0.6;
    public static final double SAFE_FALL = 40.0;
    public static final double REACH = 1.0;           // jangkauan pukul +1 blok
    public static final double BREAK = 3.0;           // memecah blok 4x lebih cepat
    public static final double GROWTH = 0.1;          // badan 10% lebih besar, sama dengan juara
    public static final double SHIELD = 60.0;         // batas perisai E=mc² (absorption)

    private static final AttributeModifier.Operation ADD = AttributeModifier.Operation.ADD_VALUE;

    public static void apply(Player p) {
        set(p, Attributes.MAX_HEALTH, "health", HEALTH, ADD);
        set(p, Attributes.ARMOR, "armor", ARMOR, ADD);
        set(p, Attributes.ARMOR_TOUGHNESS, "toughness", TOUGHNESS, ADD);
        clear(p, Attributes.ATTACK_DAMAGE, "damage");   // 0.68 tinju dihitung RelativaAbilities (tinju dewa)
        set(p, Attributes.KNOCKBACK_RESISTANCE, "knockback", KNOCKBACK, ADD);
        set(p, Attributes.ATTACK_KNOCKBACK, "attack_knockback", ATTACK_KNOCKBACK, ADD);
        set(p, Attributes.ATTACK_SPEED, "attack_speed", ATTACK_SPEED, ADD);
        set(p, Attributes.MOVEMENT_SPEED, "speed", SPEED, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        set(p, Attributes.JUMP_STRENGTH, "jump", JUMP, ADD);
        set(p, Attributes.STEP_HEIGHT, "step", STEP, ADD);
        set(p, Attributes.SAFE_FALL_DISTANCE, "fall", SAFE_FALL, ADD);
        set(p, Attributes.ENTITY_INTERACTION_RANGE, "reach", REACH, ADD);
        set(p, Attributes.BLOCK_BREAK_SPEED, "break", BREAK, AttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        set(p, Attributes.SCALE, "growth", GROWTH, ADD);
        set(p, Attributes.MAX_ABSORPTION, "shield", SHIELD, ADD);
    }

    public static void remove(Player p) {
        clear(p, Attributes.MAX_HEALTH, "health");
        clear(p, Attributes.ARMOR, "armor");
        clear(p, Attributes.ARMOR_TOUGHNESS, "toughness");
        clear(p, Attributes.ATTACK_DAMAGE, "damage");
        clear(p, Attributes.KNOCKBACK_RESISTANCE, "knockback");
        clear(p, Attributes.ATTACK_KNOCKBACK, "attack_knockback");
        clear(p, Attributes.ATTACK_SPEED, "attack_speed");
        clear(p, Attributes.MOVEMENT_SPEED, "speed");
        clear(p, Attributes.JUMP_STRENGTH, "jump");
        clear(p, Attributes.STEP_HEIGHT, "step");
        clear(p, Attributes.SAFE_FALL_DISTANCE, "fall");
        clear(p, Attributes.ENTITY_INTERACTION_RANGE, "reach");
        clear(p, Attributes.BLOCK_BREAK_SPEED, "break");
        clear(p, Attributes.SCALE, "growth");
        clear(p, Attributes.MAX_ABSORPTION, "shield");
        if (p.getHealth() > p.getMaxHealth()) {
            p.setHealth(p.getMaxHealth());
        }
        float maxShield = (float) p.getAttributeValue(Attributes.MAX_ABSORPTION);
        if (p.getAbsorptionAmount() > maxShield) {
            p.setAbsorptionAmount(maxShield);   // perisai E=mc² dipangkas ke batas manusia
        }
    }

    private static ResourceLocation id(String name) {
        return ShazamMod.id("relativa_" + name);
    }

    static void set(Player p, Holder<Attribute> attribute, String name, double amount, AttributeModifier.Operation op) {
        AttributeInstance instance = p.getAttribute(attribute);
        if (instance != null) {
            instance.removeModifier(id(name));
            if (amount != 0.0) {
                AttributeModifier modifier = new AttributeModifier(id(name), amount, op);
                if (attribute == Attributes.MAX_HEALTH) {
                    // 0.68 darah tambahan disimpan bersama data pemain (sama seperti juara), jadi darah 1024 tetap utuh
                    // sesudah keluar-masuk world (modifier sementara hilang dulu saat dimuat, darahnya terpangkas ke 20)
                    instance.addPermanentModifier(modifier);
                } else {
                    instance.addTransientModifier(modifier);
                }
            }
        }
    }

    static void clear(Player p, Holder<Attribute> attribute, String name) {
        AttributeInstance instance = p.getAttribute(attribute);
        if (instance != null) {
            instance.removeModifier(id(name));
        }
    }
}
