package com.shazammod.relativa;

import java.util.Collection;
import java.util.List;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * 0.66 Perintah buat ngetes RELATIVA (butuh cheat). Jalan sungguhannya: empat makalah di Jurnal Annus Mirabilis, lalu
 * Eksperimen Pikiran.
 *
 *   /relativa unlock [pemain]       RELATIVA terbuka langsung
 *   /relativa lock [pemain]         dikunci lagi (makalah ikut dihapus)
 *   /relativa rite [pemain]         Eksperimen Pikiran sekarang juga (tanpa syarat makalah)
 *   /relativa papers <0-15>         atur makalah yang tertulis (bit 0-3)
 *   /relativa energy <0-100>        atur Energi
 */
public final class RelativaCommands {
    private RelativaCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("relativa")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("unlock")
                        .executes(ctx -> unlock(ctx.getSource(), self(ctx.getSource()), true))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> unlock(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"), true))))
                .then(Commands.literal("lock")
                        .executes(ctx -> unlock(ctx.getSource(), self(ctx.getSource()), false))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> unlock(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets"), false))))
                .then(Commands.literal("rite")
                        .executes(ctx -> rite(ctx.getSource(), self(ctx.getSource())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> rite(ctx.getSource(), EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("papers")
                        .then(Commands.argument("mask", IntegerArgumentType.integer(0, RelativaData.PAPERS_ALL))
                                .executes(ctx -> papers(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "mask")))))
                .then(Commands.literal("energy")
                        .then(Commands.argument("amount", FloatArgumentType.floatArg(0f, RelativaData.MAX_ENERGY))
                                .executes(ctx -> energy(ctx.getSource(), FloatArgumentType.getFloat(ctx, "amount"))))));
    }

    private static List<ServerPlayer> self(CommandSourceStack source) throws CommandSyntaxException {
        return List.of(source.getPlayerOrException());
    }

    private static int unlock(CommandSourceStack source, Collection<ServerPlayer> targets, boolean open) {
        for (ServerPlayer p : targets) {
            RelativaData d = RelativaAbilities.data(p);
            if (open) {
                d.unlocked = true;
                d.papers = RelativaData.PAPERS_ALL;
            } else {
                if (d.transformed) {
                    RelativaAbilities.dropForm(p, d);
                }
                d.unlocked = false;
                d.papers = 0;
            }
            RelativaNetwork.sync(p);
        }
        source.sendSuccess(() -> Component.translatable(open ? "commands.shazammod.relativa.unlock"
                : "commands.shazammod.relativa.lock", targets.size()), true);
        return targets.size();
    }

    private static int rite(CommandSourceStack source, Collection<ServerPlayer> targets) {
        for (ServerPlayer p : targets) {
            RelativaRite.begin(p);
        }
        source.sendSuccess(() -> Component.translatable("commands.shazammod.relativa.rite", targets.size()), true);
        return targets.size();
    }

    private static int papers(CommandSourceStack source, int mask) throws CommandSyntaxException {
        ServerPlayer p = source.getPlayerOrException();
        RelativaData d = RelativaAbilities.data(p);
        d.papers = mask & RelativaData.PAPERS_ALL;
        RelativaNetwork.sync(p);
        source.sendSuccess(() -> Component.translatable("commands.shazammod.relativa.papers", Integer.bitCount(mask)), true);
        return 1;
    }

    private static int energy(CommandSourceStack source, float amount) throws CommandSyntaxException {
        ServerPlayer p = source.getPlayerOrException();
        RelativaAbilities.data(p).energy = Math.max(0f, Math.min(RelativaData.MAX_ENERGY, amount));
        RelativaNetwork.sync(p);
        source.sendSuccess(() -> Component.translatable("commands.shazammod.relativa.energy", Math.round(amount)), true);
        return 1;
    }
}
