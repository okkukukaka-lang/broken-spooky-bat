package com.shazammod.relativa.client;

import com.shazammod.client.fx.RelativaFx;
import com.shazammod.relativa.RelativaClientState;
import com.shazammod.relativa.RelativaData;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * 0.66 HUD RELATIVA, di KIRI hotbar (HUD Thanos di kanan, HUD juara di kiri atas, jadi nggak bertabrakan):
 *
 *   medan yang menyala (Dilatasi Waktu, Lubang Hitam, Keterikatan, Tokamak: sisa detik)
 *   sembilan kotak Z X C V B N R M J berwarna ranah fisikanya: redup = kuasa normal cooldown, garis di bawahnya = kuasa
 *   Shift cooldown
 *   bar Energi "E = mc²" (emas saat penuh)
 *
 * 0.67: kotak ke-10 = Kecepatan Cahaya (O, berpendar saat waktu berhenti), kotak ke-11 = pasif Terowongan Kuantum (I, ungu
 * saat menyala), dan baris v = 0,99c · γ selama waktu berhenti.
 *
 * Wujud manusia: kemajuan empat makalah Jurnal Annus Mirabilis, atau pengingat tombol Y (0.68: atau sisa waktu sesudah
 * terlempar balik jadi manusia).
 *
 * 0.68: baris hati diganti bar darah RELATIVA (darah sampai 1024, tingkat dewa) di tempat hati biasa, plus perisai E=mc².
 *
 * 0.70: baris kedua di atasnya = L Jembatan Einstein-Rosen (terang saat terbuka), F Foton Tanpa Massa, K Kucing
 * Schrödinger (angka = salinan yang masih hidup), H Cincin Einstein; redup = cooldown.
 */
public final class RelativaHud {
    private RelativaHud() {}

    private static final int BOX = 11, GAP = 2, KEYS = 9;
    private static final String[] LABEL = {"Z", "X", "C", "V", "B", "N", "R", "M", "J"};
    /** Warna ranah: relativitas khusus, gravitasi, kuantum, fisi, fusi, E=mc², medan terpadu, foton, gelombang gravitasi. */
    public static final int[] COLOR = {0x8FD8FF, 0x9A6BFF, 0x5CFFE1, 0x7CFF5A, 0xFF7AD9, 0xFFD34D, 0xFFFFFF, 0xFFF07A, 0xB28CFF};
    private static final int[] NORMAL = {0, 1, 2, 3, 4, 5, RelativaData.SLOT_R, RelativaData.SLOT_M, RelativaData.SLOT_J};
    private static final int[] SHIFT = {6, 7, 8, 9, 10, 11, RelativaData.SLOT_R_SHIFT, RelativaData.SLOT_M_SHIFT,
            RelativaData.SLOT_J_SHIFT};
    private static final int SHADE = 0xA0000000, EDGE = 0xFF4A5468;
    private static final int LIGHT = 0xFFE8FBFF, PHASE_ON = 0xFFB07CFF, PHASE_OFF = 0xFF3A3150;
    // 0.70 baris kedua: lubang cacing, foton, kucing Schrödinger, cincin Einstein (nyala / mati)
    private static final int[] SPACE_ON = {0xFF7FE8FF, 0xFFFFF07A, 0xFF5CFFE1, 0xFFD8C8FF};
    private static final int[] SPACE_OFF = {0xFF1E3A48, 0xFF4A4420, 0xFF1C4A42, 0xFF3A3450};
    private static final int ENERGY = 0xFF5CE1FF, ENERGY_FULL = 0xFFFFD34D;
    private static final int HP_EDGE = 0xFF3A5A8A, HP_BACK = 0xFF0A1020, HP_FILL = 0xFF3FB8FF, HP_SHINE = 0xFFB8F0FF,
            HP_SHIELD = 0xFFFFD34D;

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null) {
            return;
        }
        Font font = mc.font;
        int width = (KEYS + 2) * BOX + (KEYS + 1) * GAP;
        int x = g.guiWidth() / 2 - 91 - 32 - width;   // kiri hotbar, lewat slot tangan kiri
        int bottom = g.guiHeight();
        if (x < 4) {   // layar sempit: naik sedikit supaya nggak menutupi slot tangan kiri
            x = 4;
            bottom -= 24;
        }
        if (!RelativaClientState.unlocked) {
            if (RelativaClientState.papers != 0) {
                int n = Integer.bitCount(RelativaClientState.papers);
                Component line = Component.translatable(n >= RelativaData.PAPERS ? "hud.shazammod.relativa.papers_done"
                        : "hud.shazammod.relativa.papers", n, RelativaData.PAPERS);
                g.drawString(font, line, x, bottom - 18, n >= RelativaData.PAPERS ? 0xFFFFD34D : 0xFF8FD8FF);
            }
            return;
        }
        if (!RelativaClientState.transformed) {
            int knockout = RelativaClientState.cooldown(RelativaData.SLOT_KNOCKOUT);
            Component line = knockout > 0 ? Component.translatable("hud.shazammod.relativa.knockout", seconds(knockout))
                    : Component.translatable("hud.shazammod.relativa.human");
            g.drawString(font, line, x, bottom - 18, knockout > 0 ? 0xFFFF8A8A : 0xFF8FA8C8);
            return;
        }
        renderHealth(g, mc, mc.player);

        // sembilan kotak
        int boxY = bottom - 30;
        for (int k = 0; k < KEYS; k++) {
            int bx = x + k * (BOX + GAP);
            int rgb = 0xFF000000 | COLOR[k];
            int cd = RelativaClientState.cooldown(NORMAL[k]);
            int cdShift = RelativaClientState.cooldown(SHIFT[k]);
            g.fill(bx - 1, boxY - 1, bx + BOX + 1, boxY + BOX + 1, EDGE);
            g.fill(bx, boxY, bx + BOX, boxY + BOX, rgb);
            if (cd > 0) {
                g.fill(bx, boxY, bx + BOX, boxY + BOX, 0xB0000000);
            }
            g.fill(bx, boxY + BOX + 2, bx + BOX, boxY + BOX + 4, cdShift > 0 ? 0xFF2E3440 : rgb);
            g.drawString(font, LABEL[k], bx + 3, boxY + 2, cd > 0 ? 0xFF888888 : 0xFF101018, false);
        }
        // 0.67 Kecepatan Cahaya & Terowongan Kuantum
        int lx0 = x + KEYS * (BOX + GAP);
        boolean lightOn = RelativaClientState.lightState != 0;
        int lightCd = RelativaClientState.cooldown(RelativaData.SLOT_LIGHT);
        int pulse = (int) (Math.sin(mc.level != null ? (mc.level.getGameTime() + delta.getGameTimeDeltaPartialTick(true)) * 0.4
                : 0) * 40 + 200);
        g.fill(lx0 - 1, boxY - 1, lx0 + BOX + 1, boxY + BOX + 1, lightOn ? 0xFF000000 | (pulse << 16) | (pulse << 8) | 0xFF : EDGE);
        g.fill(lx0, boxY, lx0 + BOX, boxY + BOX, LIGHT);
        if (lightCd > 0) {
            g.fill(lx0, boxY, lx0 + BOX, boxY + BOX, 0xB0000000);
        }
        g.drawString(font, key(RelativaClient.LIGHT), lx0 + 3, boxY + 2, lightCd > 0 ? 0xFF888888 : 0xFF101018, false);
        int px0 = lx0 + BOX + GAP;
        boolean phase = RelativaClientState.phase;
        g.fill(px0 - 1, boxY - 1, px0 + BOX + 1, boxY + BOX + 1, phase ? 0xFFE0C8FF : EDGE);
        g.fill(px0, boxY, px0 + BOX, boxY + BOX, phase ? PHASE_ON : PHASE_OFF);
        g.drawString(font, key(RelativaClient.PHASE), px0 + 3, boxY + 2, phase ? 0xFF140A24 : 0xFF8A80A0, false);

        // 0.70 baris kedua: L F K H
        int rowY = boxY - BOX - 6;
        boolean[] on = {RelativaClientState.wormholeTicks > 0, RelativaClientState.photon, RelativaClientState.clones > 0,
                RelativaClientState.cloak};
        int[] cds = {RelativaClientState.cooldown(RelativaData.SLOT_WORMHOLE), 0, RelativaClientState.cooldown(RelativaData.SLOT_CLONE),
                0};
        String[] labels = {key(RelativaClient.WORMHOLE), key(RelativaClient.PHOTON), key(mc, "key.shazammod.form", "K"),
                key(mc, "key.shazammod.hood", "H")};
        for (int k = 0; k < 4; k++) {
            int bx = lx0 - 2 * (BOX + GAP) + k * (BOX + GAP);
            boolean lit = on[k];
            g.fill(bx - 1, rowY - 1, bx + BOX + 1, rowY + BOX + 1, lit ? 0xFFFFFFFF : EDGE);
            g.fill(bx, rowY, bx + BOX, rowY + BOX, lit || cds[k] <= 0 ? SPACE_ON[k] : SPACE_OFF[k]);
            if (!lit && cds[k] > 0) {
                g.fill(bx, rowY, bx + BOX, rowY + BOX, 0x90000000);
            } else if (!lit && (k == 1 || k == 3)) {   // nyala / mati: redup saat mati
                g.fill(bx, rowY, bx + BOX, rowY + BOX, 0x70000000);
            }
            String lab = k == 2 && RelativaClientState.clones > 0 ? String.valueOf(RelativaClientState.clones) : labels[k];
            g.drawString(font, lab, bx + 3, rowY + 2, lit ? 0xFF101018 : 0xFFB0B8C8, false);
        }

        // medan yang menyala
        StringBuilder status = new StringBuilder();
        if (lightOn) {   // 0.67 v mendekati c, faktor Lorentz γ, sisa waktu berhenti
            float beta = RelativaFx.lightBeta();
            status.append("⚡ v=").append(String.format(java.util.Locale.ROOT, "%.3f", beta)).append("c γ=")
                    .append(String.format(java.util.Locale.ROOT, beta > 0.9999f ? "%.0f" : "%.1f", RelativaFx.lightGamma()))
                    .append(' ').append(seconds(RelativaClientState.lightTicks)).append("  ");
        }
        if (phase) {
            status.append("Ψ  ");
        }
        if (RelativaClientState.wormholeTicks > 0) {   // 0.70
            status.append("◯ ").append(seconds(RelativaClientState.wormholeTicks)).append("  ");
        }
        if (RelativaClientState.clones > 0) {
            status.append("ψ×").append(RelativaClientState.clones).append("  ");
        }
        if (RelativaClientState.cloak) {
            status.append("θE  ");
        }
        if (RelativaClientState.photon) {
            status.append("γ  ");
        }
        if (RelativaClientState.holeTicks > 0) {
            status.append("● ").append(seconds(RelativaClientState.holeTicks)).append("  ");
        }
        if (RelativaClientState.dilationTicks > 0) {
            status.append("⌛ ").append(seconds(RelativaClientState.dilationTicks)).append("  ");
        }
        if (RelativaClientState.entangleTicks > 0) {
            status.append("ψψ ").append(seconds(RelativaClientState.entangleTicks)).append("  ");
        }
        if (RelativaClientState.tokamakTicks > 0) {
            status.append("◎ ").append(seconds(RelativaClientState.tokamakTicks));
        }
        if (!status.isEmpty()) {
            g.drawString(font, status.toString().trim(), x, rowY - 11, 0xFFB8E8FF);
        }

        // energi
        int barY = bottom - 8;
        float energy = RelativaClientState.energy;
        g.fill(x - 1, barY - 1, x + width + 1, barY + 4, SHADE);
        g.fill(x, barY, x + Math.round(width * energy / RelativaData.MAX_ENERGY), barY + 3,
                energy >= RelativaData.MAX_ENERGY ? ENERGY_FULL : ENERGY);
        String label = "E " + Math.round(energy);
        int lx = x - font.width(label) - 4;
        g.drawString(font, label, lx >= 2 ? lx : x + width + 4, barY - 3, 0xFFB8E8FF);
    }

    /** 0.68 Pengganti baris hati (di tempat yang sama): bar darah sinar biru, garis emas = perisai E=mc². */
    private static void renderHealth(GuiGraphics g, Minecraft mc, LocalPlayer player) {
        if (mc.gameMode == null || !mc.gameMode.canHurtPlayer()) {
            return;
        }
        int x = g.guiWidth() / 2 - 91, y = g.guiHeight() - 39, w = 81, h = 9;
        float health = player.getHealth(), max = Math.max(1f, player.getMaxHealth()), shield = player.getAbsorptionAmount();
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, HP_EDGE);
        g.fill(x, y, x + w, y + h, HP_BACK);
        int filled = Math.round(Mth.clamp(health / max, 0f, 1f) * w);
        g.fill(x, y, x + filled, y + h, HP_FILL);
        g.fill(x, y, x + filled, y + 3, HP_SHINE);
        if (shield > 0f) {
            float maxShield = (float) player.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.MAX_ABSORPTION);
            int extra = Math.round(Mth.clamp(shield / Math.max(1f, maxShield), 0f, 1f) * w);
            g.fill(x, y + h - 3, x + extra, y + h, HP_SHIELD);
        }
        String text = "\u2764 " + Math.round(health) + " / " + Math.round(max) + (shield > 0f ? " +" + Math.round(shield) : "");
        g.pose().pushPose();
        g.pose().translate(x + w / 2f, y + 2f, 0f);
        g.pose().scale(0.7f, 0.7f, 1f);
        g.drawCenteredString(mc.font, text, 0, 0, 0xFFFFFFFF);
        g.pose().popPose();
    }

    /** 0.70 Huruf tombol juara yang dipakai RELATIVA (K & H), dicari dari namanya di Kontrol. */
    private static String key(Minecraft mc, String name, String fallback) {
        for (net.minecraft.client.KeyMapping k : mc.options.keyMappings) {
            if (k.getName().equals(name)) {
                return key(k);
            }
        }
        return fallback;
    }

    /** Huruf tombol yang dipasang (bisa diganti di Kontrol): satu-dua huruf pertama. */
    private static String key(net.minecraft.client.KeyMapping mapping) {
        String k = mapping.getTranslatedKeyMessage().getString();
        return k.length() <= 1 ? k : k.substring(0, 1).toUpperCase(java.util.Locale.ROOT);
    }

    private static String seconds(int ticks) {
        int s = (ticks + 19) / 20;
        return s >= 60 ? (s / 60) + ":" + String.format("%02d", s % 60) : s + "s";
    }
}
