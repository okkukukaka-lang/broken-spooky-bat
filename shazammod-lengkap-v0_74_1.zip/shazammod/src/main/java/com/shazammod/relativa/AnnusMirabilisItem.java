package com.shazammod.relativa;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * 0.66 Jurnal Annus Mirabilis ("tahun keajaiban" 1905). Dibawa di inventori = makalah ditulis begitu kamu mengalami
 * fenomenanya (RelativaAbilities.tickPapers). Keempatnya tertulis = klik kanan untuk Eksperimen Pikiran (RelativaRite).
 * Sesudah RELATIVA terbuka jurnalnya cuma kenang-kenangan: kekuatannya ada di pikiranmu, bukan di bukunya.
 */
public class AnnusMirabilisItem extends Item {
    public AnnusMirabilisItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player instanceof ServerPlayer serverPlayer) {
            RelativaRite.tryBegin(serverPlayer);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return RelativaClientState.unlocked || RelativaClientState.papers == RelativaData.PAPERS_ALL;   // cuma dipakai client
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shazammod.relativa.journal").withStyle(ChatFormatting.AQUA,
                ChatFormatting.ITALIC));
        if (RelativaClientState.unlocked) {
            tooltip.add(Component.translatable("tooltip.shazammod.relativa.journal_done").withStyle(ChatFormatting.GOLD));
            return;
        }
        for (int i = 0; i < RelativaData.PAPERS; i++) {
            boolean has = (RelativaClientState.papers & (1 << i)) != 0;
            tooltip.add(Component.literal(has ? "◆ " : "◇ ").append(Component.translatable("paper.shazammod.relativa." + i))
                    .withStyle(has ? ChatFormatting.GREEN : ChatFormatting.DARK_GRAY));
            if (!has) {
                tooltip.add(Component.literal("   ").append(Component.translatable("message.shazammod.relativa.paper_hint." + i))
                        .withStyle(ChatFormatting.GRAY));
            }
        }
        tooltip.add(Component.translatable("tooltip.shazammod.relativa.journal_use").withStyle(ChatFormatting.GRAY));
    }
}
