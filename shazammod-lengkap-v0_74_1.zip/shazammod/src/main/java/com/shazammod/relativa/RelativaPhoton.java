package com.shazammod.relativa;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;

import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.phys.Vec3;

/**
 * 0.70 FOTON TANPA MASSA (tombol F, nyala / mati, tanpa batas waktu): massa diam badan RELATIVA dijadikan nol. Partikel tak
 * bermassa nggak punya kelembaman, jadi terbangnya langsung menurut: melesat ke mana pun mata memandang, berhenti seketika
 * (tanpa meluncur), Sprint = mendekati kecepatan cahaya (garis cahaya, aberasi & Doppler di layar sendiri, lihat
 * client.RelativaPhotonFlight). Double-tap spasi tetap bisa mendarat / terbang lagi seperti biasa. Tanpa damage jatuh.
 * Gerak terbangnya dihitung di client pemain itu sendiri (sama seperti terbang juara); di server cukup izin terbangnya.
 * Padam saat kembali jadi manusia / tumbang.
 */
public final class RelativaPhoton {
    private RelativaPhoton() {}

    private static final int TOGGLE_GAP = 10;
    private static final double LAUNCH = 0.9;   // dorongan ke atas saat dinyalakan di tanah

    public static boolean on(ServerPlayer p) {
        RelativaData d = RelativaAbilities.data(p);
        return d.transformed && d.photon;
    }

    public static void toggle(ServerPlayer p, RelativaData d) {
        if (!d.transformed || d.morphing > 0 || !p.isAlive() || p.isSpectator()) {
            return;
        }
        long now = p.level().getGameTime();
        if (d.lastPhotonToggle != 0L && now >= d.lastPhotonToggle && now - d.lastPhotonToggle < TOGGLE_GAP) {
            return;
        }
        d.lastPhotonToggle = now;
        d.photon = !d.photon;
        if (d.photon) {
            apply(p, true);
            ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_PHOTON_ON);
            RelativaSkills.sound(p, p.position(), ShazamSounds.RELATIVA_PHOTON_ON.get(), 1.6f);
            RelativaAbilities.msg(p, "photon_on", ChatFormatting.YELLOW);
        } else {
            remove(p);
            ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_PHOTON_OFF);
            RelativaSkills.sound(p, p.position(), ShazamSounds.RELATIVA_PHOTON_OFF.get(), 1.4f);
            RelativaAbilities.msg(p, "photon_off", ChatFormatting.GRAY);
        }
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    /** Izin terbang dipasang; launch = langsung lepas landas (dari tombol). */
    static void apply(ServerPlayer p, boolean launch) {
        Abilities a = p.getAbilities();
        a.mayfly = true;
        if (launch) {
            a.flying = true;
            if (p.onGround()) {
                Vec3 v = p.getDeltaMovement();
                p.setDeltaMovement(v.x, LAUNCH, v.z);
                p.hurtMarked = true;
            }
        }
        p.onUpdateAbilities();
        p.resetFallDistance();
    }

    /** Izin terbang dilepas (kecuali mode kreatif / penonton yang memang bisa terbang). */
    static void remove(ServerPlayer p) {
        if (!p.isCreative() && !p.isSpectator()) {
            Abilities a = p.getAbilities();
            a.mayfly = false;
            a.flying = false;
            p.onUpdateAbilities();
        }
        p.resetFallDistance();
    }

    /** Kembali jadi manusia / tumbang / hidup lagi: padam tanpa animasi. */
    static void off(ServerPlayer p, RelativaData d) {
        if (d.photon) {
            d.photon = false;
            remove(p);
        }
    }

    /** Tiap tick: izin terbang dipasang lagi kalau sempat hilang (misalnya habis ganti gamemode), tanpa damage jatuh. */
    static void tick(ServerPlayer p, RelativaData d) {
        if (!d.photon || !d.transformed) {
            return;
        }
        if (!p.getAbilities().mayfly && !p.isSpectator()) {
            p.getAbilities().mayfly = true;
            p.onUpdateAbilities();
        }
        p.resetFallDistance();
    }
}
