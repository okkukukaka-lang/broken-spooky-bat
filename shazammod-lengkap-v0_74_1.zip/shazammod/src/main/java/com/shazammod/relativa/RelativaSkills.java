package com.shazammod.relativa;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;
import com.shazammod.infinity.InfinityWorld;
import com.shazammod.thanos.entity.ThrownDoubleBlade;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.ThrownTrident;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;

/**
 * 0.66 Kuasa RELATIVA: 18 skill, semuanya fisika Einstein (dan yang lahir dari teorinya). Tick puncak tiap skill =
 * konstanta ShazamAnim.REL_* (klip RelativaClips, efek RelativaFx, dan SFX relativa_* dikunci ke angka yang sama).
 *
 *   Z  Relativitas Khusus  Lesat Cahaya (melesat 22 blok, menghantam yang dilewati)  | Shift: Dilatasi Waktu (medan 9 blok:
 *                          waktu musuh & proyektil melambat, waktumu normal)
 *   X  Relativitas Umum    Lengkung Ruang-Waktu (sumur gravitasi, lalu dihempas)     | Shift: LUBANG HITAM (menyedot makhluk,
 *                          proyektil & blok; menguap jadi ledakan radiasi Hawking)
 *   C  Kuantum             Terowongan Kuantum (menembus dinding)                     | Shift: Keterikatan Kuantum (8 musuh
 *                          terikat: damage ke satu mengalir ke semuanya)
 *   V  Fisi Nuklir         Fisi Berantai (neutron membelah inti, reaksi berantai)    | Shift: Massa Kritis (ledakan fisi +
 *                          awan jamur, kawah, radiasi sisa)
 *   B  Fusi Nuklir         Fusi Bintang (dua proton jadi bintang mini, dilempar)     | Shift: Tokamak (cincin plasma 10 dtk)
 *   N  E = mc²             Konversi massa sasaran jadi energi (damage ikut massanya) | Shift: Anihilasi (dua sinar gamma
 *                          berlawanan arah, menembus semua)
 *   R  Teori Medan Terpadu (keempat gaya menyatu, radius 22)                         | Shift: Kondensat Bose-Einstein
 *                          (nol mutlak: semua membeku 6 dtk, air jadi es)
 *   M  Efek Fotolistrik (rentetan foton, elektron terlepas melompat)                 | Shift: Laser (emisi terstimulasi)
 *   J  Gelombang Gravitasi (riak ruang-waktu meregang & memampat)                    | Shift: Gerak Brown (melompat acak)
 *
 * Perubahan blok (Lubang Hitam, kawah Massa Kritis, air beku) ikut /gamerule mobGriefing.
 *
 * 0.68 TINGKAT DEWA (RelativaTier): damage x3, radius & jangkauan x2, hempasan x1,6, medan lebih lama, sasaran lebih banyak,
 * cooldown tinggal 35%, energi separuh, suara terdengar lebih jauh. Dampak baru: ledakan sonik di ujung Lesat Cahaya, kawah
 * di hentakan Lengkung Ruang-Waktu, ledakan Hawking, Fusi Bintang, & Massa Kritis (kawah 12), Laser yang melelehkan blok,
 * dan energi E=mc² yang meledak ke musuh di sekitar sasaran (semua perubahan blok tetap ikut mobGriefing).
 *
 * 0.71 SEBESAR GUNUNG: Massa Kritis = bola api 30 blok, gelombang kejut yang benar-benar merambat sampai 100 blok
 * (menggunduli hutan yang dilewatinya), kawah 40, awan jamur 130 blok. Lubang Hitam = cakrawala 14 blok, melayang 26 blok
 * di atas tanah, menarik dari 100 blok, mencabut tanah di bawahnya jadi mangkuk raksasa, ledakan Hawking 64 blok + kawah 26.
 * Keduanya muncul minimal 48 blok dari pemain. Gravitasi (X, J), nuklir (V, B, Shift+B), dan E=mc² (N, Shift+N) jauh lebih
 * sakit (angka dasarnya di blok "LEBIH SAKIT" di bawah).
 */
public final class RelativaSkills {
    private RelativaSkills() {}

    // ======= Angka yang gampang diutak-atik =======
    /** Pengali semua damage skill RELATIVA (0.68 tingkat dewa: RelativaTier.DAMAGE). */
    public static final float SKILL_DAMAGE = RelativaTier.DAMAGE;
    private static final double A = RelativaTier.AREA, K = RelativaTier.PUSH;
    // energi & cooldown (detik) 0.67: {normal, shift} untuk Z..N; 0.68 dikali RelativaTier.COST & RelativaTier.COOLDOWN
    private static final float[][] COST = {{12, 30}, {20, 45}, {14, 25}, {18, 50}, {16, 35}, {28, 26}};
    private static final int[][] COOLDOWN = {{3, 22}, {9, 35}, {5, 18}, {7, 40}, {5, 26}, {12, 14}};
    private static final float UNIFIED_COST = 80f, BEC_COST = 45f, PHOTO_COST = 10f, LASER_COST = 30f, GWAVE_COST = 18f,
            BROWN_COST = 15f;
    private static final int UNIFIED_CD = 75, BEC_CD = 40, PHOTO_CD = 4, LASER_CD = 16, GWAVE_CD = 8, BROWN_CD = 10;
    private static final double DASH_RANGE = 22.0 * A;
    private static final double DASH_BOOM = 4.5;            // 0.68 ledakan sonik saat tiba
    private static final double DILATION_RADIUS = 9.0 * A;
    // 0.71 Lubang Hitam SEBESAR GUNUNG (ukurannya di RelativaTier, sama dengan yang digambar client)
    private static final double HOLE_RANGE = 130.0, HOLE_FAR = 84.0;
    private static final int HOLE_EAT_PER_TICK = 260;       // tanah yang dicabut tiap tick (±5000 blok per detik)
    private static final int HOLE_EAT_TRIES = 700;
    private static final double TUNNEL_RANGE = 24.0 * A;
    private static final int ENTANGLE_MAX = 24;
    private static final float ENTANGLE_SHARE = 1.0f;      // 0.68 damage mengalir 100% ke semua pasangannya
    // 0.71 Massa Kritis SEBESAR GUNUNG (ukurannya di RelativaTier)
    private static final double NUKE_RANGE = 140.0, NUKE_FAR = 90.0;
    private static final double TOKAMAK_RADIUS = 4.5 * A;
    private static final double TOKAMAK_TUBE = 1.5;         // 0.68 tabung plasma ikut menebal
    private static final int WARP_CRATER = 6, FUSION_CRATER = 6;   // 0.68 kawah (mobGriefing), 0.71 dua kali lebih besar
    // ======= 0.71 LEBIH SAKIT: damage dasar (sebelum dikali SKILL_DAMAGE x3) & jangkauannya =======
    private static final float WARP_DMG = 32f;              // X hentakan Lengkung Ruang-Waktu (0.70: 14)
    private static final float HOLE_HORIZON_DMG = 16f;      // Shift+X di cakrawala peristiwa, tiap 4 tick (0.70: 7)
    private static final float HOLE_TIDAL_DMG = 6f;         //   gaya pasang (spagetifikasi) di dekat cakrawala, tiap 4 tick
    private static final float HAWKING_DMG = 85f;           //   ledakan Hawking (0.70: 20)
    private static final float FISSION_DMG = 26f;           // V tiap inti yang membelah (0.70: 12)
    private static final float NUKE_FIREBALL_DMG = 150f;    // Shift+V di dalam bola api (0.70: 38)
    private static final float NUKE_WAVE_DMG = 100f;        //   gelombang kejut (menurun ke 30% di ujungnya)
    private static final float NUKE_RAD_DMG = 5f;           //   radiasi sisa tiap detik (0.70: 1,5)
    private static final float FUSION_DMG = 42f;            // B bintang mini (0.70: 18)
    private static final float TOKAMAK_DMG = 9f;            // Shift+B cincin plasma tiap 0,5 dtk (0.70: 4)
    private static final float DISRUPT_DMG = 38f;           //   plasma lepas kendali di akhir (0.70: 14)
    private static final float EMC_BASE = 16f, EMC_PER_HP = 0.5f, EMC_CAP = 450f;   // N (0.70: 6 + 22% darah, maks 200)
    private static final float EMC_BLAST = 0.5f;            //   energi yang terlepas ke musuh di sekitar sasaran (0.70: 35%)
    private static final float ANNIHILATE_DMG = 46f;        // Shift+N tiap sinar gamma (0.70: 20)
    private static final float GWAVE_DMG = 26f;             // J (0.70: 10)
    private static final double WARP_REACH = 12.0 * A, WARP_SLAM = 7.0 * A, FISSION_HOP = 11.0 * A, FUSION_RADIUS = 6.5 * A,
            DISRUPT_RADIUS = 10.0 * A, EMC_RADIUS = 7.0 * A, ANNIHILATE_RANGE = 36.0 * A, ANNIHILATE_WIDTH = 3.4,
            GWAVE_RADIUS = 12.0 * A;
    private static final int FISSION_BUDGET = 60, FISSION_GENS = 5;   // 0.71 enam generasi neutron
    private static final int LASER_DRILL_EVERY = 4;         // 0.68 Laser melelehkan blok yang disorotnya (mobGriefing)
    private static final int FREEZE_MAX = 1500;             // pengaman lag: air yang dibekukan Kondensat sekaligus

    // ---------------------------------------------------------------- keadaan tiap pemain (nggak disimpan)

    private static final class Task {
        int delay;
        final Consumer<ServerPlayer> action;

        Task(int delay, Consumer<ServerPlayer> action) {
            this.delay = delay;
            this.action = action;
        }
    }

    private static final class Held {
        final LivingEntity entity;
        int ticks;

        Held(LivingEntity entity, int ticks) {
            this.entity = entity;
            this.ticks = ticks;
        }
    }

    private static final class State {
        int busy;
        final List<Task> tasks = new ArrayList<>();
        Vec3 lastPos;
        double speed;
        int dilation;
        final Set<Projectile> slowed = new HashSet<>();
        Vec3 warpAt;
        int warp;
        Vec3 holeAt;
        int hole, holeAge;
        double holeGround = Double.NaN;   // 0.71 tinggi tanah di bawah lubang hitam saat terbentuk (NaN = di langit)
        Vec3 blastAt;                     // 0.71 gelombang kejut Massa Kritis yang sedang merambat
        double blastR;
        int blast;
        final Set<Integer> blasted = new HashSet<>();
        final List<LivingEntity> entangled = new ArrayList<>();
        int entangle;
        int tokamak;
        int laser;
        final List<Held> frozen = new ArrayList<>();
        Vec3 radAt;
        int rad;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();
    private static boolean sharing;

    private static State state(ServerPlayer p) {
        return STATES.computeIfAbsent(p.getUUID(), id -> new State());
    }

    public static void clear(ServerPlayer p) {
        State s = STATES.remove(p.getUUID());
        if (s != null) {
            releaseSlowed(s);
        }
    }

    public static boolean free(ServerPlayer p) {
        State s = STATES.get(p.getUUID());
        return s == null || s.busy <= 0;
    }

    public static void busy(ServerPlayer p, int ticks) {
        State s = state(p);
        s.busy = Math.max(s.busy, ticks);
    }

    /** Jalankan action delay tick lagi (dibatalkan kalau pemainnya mati / keluar / kembali jadi manusia). */
    public static void later(ServerPlayer p, int delay, Consumer<ServerPlayer> action) {
        state(p).tasks.add(new Task(Math.max(1, delay), action));
    }

    /** Kecepatan gerak pemain (blok/tick, dihaluskan), dari perpindahan posisinya di server. */
    public static double trackMotion(ServerPlayer p) {
        State s = state(p);
        Vec3 now = p.position();
        if (s.lastPos != null) {
            double v = now.distanceTo(s.lastPos);
            s.speed = s.speed * 0.6 + (v > 12.0 ? 0.0 : v) * 0.4;   // teleport / ganti dimensi = bukan kecepatan
        }
        s.lastPos = now;
        return s.speed;
    }

    public static double speed(ServerPlayer p) {
        State s = STATES.get(p.getUUID());
        return s == null ? 0.0 : s.speed;
    }

    /** Kembali jadi manusia / mati: semua medan & kuasa yang sedang berjalan padam. Es & radiasi yang sudah ada tetap. */
    public static void endAll(ServerPlayer p, RelativaData d) {
        d.dilationTicks = 0;
        d.tokamakTicks = 0;
        d.entangleTicks = 0;
        d.holeTicks = 0;
        State s = STATES.get(p.getUUID());
        if (s == null) {
            return;
        }
        s.tasks.clear();
        s.busy = 0;
        s.dilation = 0;
        releaseSlowed(s);
        s.warp = 0;
        s.warpAt = null;
        s.hole = 0;
        s.holeAt = null;
        s.entangle = 0;
        s.entangled.clear();
        s.tokamak = 0;
        s.laser = 0;
    }

    // ---------------------------------------------------------------- tiap tick

    public static void tick(ServerPlayer p, RelativaData d) {
        State s = STATES.get(p.getUUID());
        if (s == null) {
            return;
        }
        if (s.busy > 0) {
            s.busy--;
        }
        if (!s.tasks.isEmpty()) {
            List<Task> due = new ArrayList<>();
            Iterator<Task> it = s.tasks.iterator();
            while (it.hasNext()) {
                Task t = it.next();
                if (--t.delay <= 0) {
                    due.add(t);
                    it.remove();
                }
            }
            for (Task t : due) {
                if (p.isAlive() && !p.isRemoved()) {
                    t.action.accept(p);
                }
            }
        }
        tickDilation(p, s, d);
        tickWarp(p, s);
        tickHole(p, s, d);
        tickBlast(p, s);   // 0.71 gelombang kejut Massa Kritis
        tickEntangle(s, d);
        tickTokamak(p, s, d);
        tickLaser(p, s);
        tickFrozen(p, s);
        tickRadiation(p, s);
    }

    // ---------------------------------------------------------------- syarat

    static boolean ready(ServerPlayer p, RelativaData d, int slot, float cost) {
        if (!free(p) || d.morphing > 0) {
            return false;
        }
        if (d.cooldowns[slot] > 0) {
            RelativaAbilities.msg(p, "cooldown", ChatFormatting.RED, (d.cooldowns[slot] + 19) / 20);
            return false;
        }
        float need = cost * RelativaTier.COST;
        if (!p.getAbilities().instabuild && d.energy < need) {
            RelativaAbilities.msg(p, "no_energy", ChatFormatting.RED, Math.round(d.energy), Math.round(need));
            return false;
        }
        return true;
    }

    static void spend(ServerPlayer p, RelativaData d, int slot, float cost, int cooldownSec) {
        if (!p.getAbilities().instabuild) {
            d.energy = Math.max(0f, d.energy - cost * RelativaTier.COST);
        }
        d.cooldowns[slot] = RelativaTier.cooldown(cooldownSec) * 20;
    }

    // ---------------------------------------------------------------- tombol

    /** Z..N (index 0-5), shift = kuasa kedua. */
    public static void key(ServerPlayer p, RelativaData d, int index, boolean shift) {
        if (index < 0 || index > 5) {
            return;
        }
        int slot = index + (shift ? RelativaData.SLOT_SHIFT : 0);
        float cost = COST[index][shift ? 1 : 0];
        if (!ready(p, d, slot, cost)) {
            return;
        }
        boolean ok = switch (index) {
            case 0 -> shift ? dilation(p) : dash(p);
            case 1 -> shift ? blackHole(p) : warp(p);
            case 2 -> shift ? entangle(p) : tunnel(p);
            case 3 -> shift ? critical(p) : fission(p);
            case 4 -> shift ? tokamak(p) : fusion(p);
            default -> shift ? annihilate(p) : emc(p);
        };
        if (ok) {
            spend(p, d, slot, cost, COOLDOWN[index][shift ? 1 : 0]);
        } else {
            RelativaAbilities.msg(p, "no_target", ChatFormatting.GRAY);
        }
    }

    /** R Teori Medan Terpadu / Shift+R Kondensat Bose-Einstein. */
    public static void ultimate(ServerPlayer p, RelativaData d, boolean shift) {
        if (shift) {
            if (ready(p, d, RelativaData.SLOT_R_SHIFT, BEC_COST)) {
                spend(p, d, RelativaData.SLOT_R_SHIFT, BEC_COST, BEC_CD);
                condensate(p);
            }
        } else if (ready(p, d, RelativaData.SLOT_R, UNIFIED_COST)) {
            spend(p, d, RelativaData.SLOT_R, UNIFIED_COST, UNIFIED_CD);
            unified(p);
        }
    }

    /** M Efek Fotolistrik / Shift+M Laser. */
    public static void light(ServerPlayer p, RelativaData d, boolean shift) {
        if (shift) {
            if (ready(p, d, RelativaData.SLOT_M_SHIFT, LASER_COST)) {
                spend(p, d, RelativaData.SLOT_M_SHIFT, LASER_COST, LASER_CD);
                laser(p);
            }
        } else if (ready(p, d, RelativaData.SLOT_M, PHOTO_COST)) {
            spend(p, d, RelativaData.SLOT_M, PHOTO_COST, PHOTO_CD);
            photo(p);
        }
    }

    /** J Gelombang Gravitasi / Shift+J Gerak Brown. */
    public static void wave(ServerPlayer p, RelativaData d, boolean shift) {
        if (shift) {
            if (ready(p, d, RelativaData.SLOT_J_SHIFT, BROWN_COST)) {
                spend(p, d, RelativaData.SLOT_J_SHIFT, BROWN_COST, BROWN_CD);
                brownian(p);
            }
        } else if (ready(p, d, RelativaData.SLOT_J, GWAVE_COST)) {
            spend(p, d, RelativaData.SLOT_J, GWAVE_COST, GWAVE_CD);
            gravityWave(p);
        }
    }

    // ================================================================ Z  Relativitas Khusus

    // Z  Lesat Cahaya: secepat cahaya, perjalanannya nyaris nol waktu; semua yang dilewati tersambar foton
    private static boolean dash(ServerPlayer p) {
        Vec3 dest = safeAim(p, DASH_RANGE);
        if (dest == null || dest.distanceTo(p.position()) < 2.0) {
            return false;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_DASH, dest);
        sound(p, p.position(), ShazamSounds.RELATIVA_DASH.get(), 1.6f);
        busy(p, ShazamAnim.REL_DASH_AT + 2);
        later(p, ShazamAnim.REL_DASH_AT, sp -> {
            if (!sp.level().noCollision(sp, sp.getBoundingBox().move(dest.subtract(sp.position())))) {
                return;
            }
            Vec3 from = sp.position();
            Vec3 dir = flat(dest.subtract(from));
            for (LivingEntity e : along(sp, from.add(0, 1.0, 0), dest.add(0, 1.0, 0), 2.9)) {
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 10f));
                e.push(dir.x * 1.1 * K, 0.45, dir.z * 1.1 * K);
                e.hurtMarked = true;
            }
            sp.teleportTo(dest.x, dest.y, dest.z);
            sp.resetFallDistance();
            for (LivingEntity e : around(sp, dest.add(0, 1.0, 0), DASH_BOOM)) {   // 0.68 ledakan sonik saat tiba
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 8f));
                Vec3 away = flat(e.position().subtract(dest));
                e.push(away.x * 1.2 * K, 0.5, away.z * 1.2 * K);
                e.hurtMarked = true;
            }
        });
        return true;
    }

    // Shift+Z  Dilatasi Waktu: t' = γt. Di dalam medan, waktu musuh & proyektil berjalan sangat lambat dilihat dari luar
    private static boolean dilation(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_DILATION);
        sound(p, p.position(), ShazamSounds.RELATIVA_DILATION.get(), 2.0f);
        busy(p, ShazamAnim.REL_DILATION_HIT + 4);
        later(p, ShazamAnim.REL_DILATION_HIT, sp -> {
            State s = state(sp);
            releaseSlowed(s);
            s.dilation = ShazamAnim.REL_DILATION_TICKS;
            RelativaAbilities.data(sp).dilationTicks = s.dilation;
            RelativaNetwork.broadcastState(sp);
        });
        return true;
    }

    private static void tickDilation(ServerPlayer p, State s, RelativaData d) {
        if (s.dilation <= 0) {
            return;
        }
        s.dilation--;
        d.dilationTicks = s.dilation;
        ServerLevel level = p.serverLevel();
        Vec3 c = p.position();
        AABB box = new AABB(c, c).inflate(DILATION_RADIUS);
        if (s.dilation % 5 == 0) {
            for (LivingEntity e : around(p, c, DILATION_RADIUS)) {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 12, 6, false, true), p);
                e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 12, 4, false, true), p);
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 12, 2, false, true), p);
            }
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 14, 2, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 14, 2, false, false));
        }
        for (Projectile pr : level.getEntitiesOfClass(Projectile.class, box, x -> x.getOwner() != p)) {
            if (pr.position().distanceTo(c) > DILATION_RADIUS) {
                continue;
            }
            if (s.slowed.add(pr)) {
                pr.setNoGravity(true);
            }
            Vec3 v = pr.getDeltaMovement();
            if (v.lengthSqr() > 0.0004) {
                pr.setDeltaMovement(v.scale(0.5));   // waktunya melambat: gerakannya merayap
                pr.hurtMarked = true;
            }
        }
        s.slowed.removeIf(pr -> {
            if (!pr.isAlive()) {
                return true;
            }
            if (pr.position().distanceTo(c) > DILATION_RADIUS + 1.0) {
                pr.setNoGravity(false);
                return true;
            }
            return false;
        });
        if (s.dilation == 0) {
            releaseSlowed(s);
            RelativaNetwork.broadcastState(p);
        }
    }

    private static void releaseSlowed(State s) {
        for (Projectile pr : s.slowed) {
            if (pr.isAlive()) {
                pr.setNoGravity(false);
            }
        }
        s.slowed.clear();
    }

    // ================================================================ X  Relativitas Umum

    // X  Lengkung Ruang-Waktu: massa melengkungkan ruang-waktu; semua di sekitarnya "jatuh" ke dasar lengkungan
    private static boolean warp(ServerPlayer p) {
        Vec3 c = aimPoint(p, 48.0, 20.0);
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_WARP, c);
        sound(p, c, ShazamSounds.RELATIVA_WARP.get(), 2.4f);
        busy(p, ShazamAnim.REL_WARP_HIT + 4);
        later(p, ShazamAnim.REL_WARP_HIT, sp -> {
            State s = state(sp);
            s.warpAt = c;
            s.warp = ShazamAnim.REL_WARP_SLAM - ShazamAnim.REL_WARP_HIT;
        });
        return true;
    }

    private static void tickWarp(ServerPlayer p, State s) {
        if (s.warp <= 0 || s.warpAt == null) {
            return;
        }
        Vec3 c = s.warpAt;
        double reach = WARP_REACH;   // 0.71 sumurnya lebih lebar
        for (LivingEntity e : around(p, c, reach)) {
            Vec3 to = c.subtract(e.position());
            double dist = Math.sqrt(to.x * to.x + to.z * to.z);
            if (dist < 0.6 * A) {
                Vec3 v = e.getDeltaMovement();
                e.setDeltaMovement(v.x * 0.5, v.y, v.z * 0.5);
                continue;
            }
            double f = (0.08 + 0.3 * A / Math.max(1.0, dist)) * Math.min(1.0, reach / Math.max(1.0, dist));
            e.push(to.x / dist * f, -0.03, to.z / dist * f);
            e.hurtMarked = true;
        }
        if (--s.warp == 0) {
            for (LivingEntity e : around(p, c, WARP_SLAM)) {
                double dist = e.position().distanceTo(c);
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, WARP_DMG * (float) Math.max(0.4, 1.0 - dist / (WARP_SLAM * 1.5))));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 3), p);
                Vec3 v = e.getDeltaMovement();
                e.setDeltaMovement(v.x * 0.2, -1.2, v.z * 0.2);
                e.hurtMarked = true;
            }
            if (griefing(p.serverLevel())) {   // 0.68 ruang-waktu yang dihentak meninggalkan kawah
                InfinityWorld.crater(p.serverLevel(), c, WARP_CRATER);
            }
            s.warpAt = null;
        }
    }

    // Shift+X  LUBANG HITAM: massa dipadatkan sampai cahaya pun nggak bisa lolos. 0.71 SEBESAR GUNUNG: muncul jauh di depan
    // (minimal 48 blok), melayang 26 blok di atas tanah, cakrawalanya 14 blok, menarik dari 100 blok, mencabut tanah di
    // bawahnya jadi mangkuk raksasa, lalu menguap jadi ledakan Hawking 64 blok yang meninggalkan kawah di dasar mangkuknya.
    private static boolean blackHole(ServerPlayer p) {
        Vec3 ground = farGround(p, HOLE_RANGE, HOLE_FAR, RelativaTier.MOUNTAIN_MIN, true);
        final Vec3 center = ground != null ? ground.add(0, RelativaTier.HOLE_LIFT, 0)
                : p.getEyePosition().add(p.getLookAngle().scale(HOLE_FAR));   // di atas void: melayang di udara
        final double groundY = ground != null ? ground.y : Double.NaN;
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_BLACKHOLE, center);
        sound(p, center, ShazamSounds.RELATIVA_BLACKHOLE.get(), 6.0f);
        busy(p, ShazamAnim.REL_BH_FORM + 4);
        later(p, ShazamAnim.REL_BH_FORM, sp -> {
            State s = state(sp);
            s.holeAt = center;
            s.holeGround = groundY;
            s.hole = ShazamAnim.REL_BH_TICKS;
            s.holeAge = 0;
            RelativaAbilities.data(sp).holeTicks = s.hole;
            sound(sp, center, ShazamSounds.RELATIVA_BLACKHOLE_HUM.get(), 7.0f);
            if (!Double.isNaN(groundY)) {   // 0.71 gemuruh tanah yang tercabut
                sound(sp, new Vec3(center.x, groundY, center.z), ShazamSounds.RELATIVA_HOLE_QUAKE.get(), 6.0f);
            }
            RelativaNetwork.broadcastState(sp);
        });
        return true;
    }

    private static void tickHole(ServerPlayer p, State s, RelativaData d) {
        if (s.hole <= 0 || s.holeAt == null) {
            return;
        }
        ServerLevel level = p.serverLevel();
        Vec3 c = s.holeAt;
        s.hole--;
        s.holeAge++;
        d.holeTicks = s.hole;
        double grow = Math.min(1.0, s.holeAge / 30.0);
        double horizon = RelativaTier.HOLE_HORIZON * (0.42 + 0.58 * grow);
        double reach = RelativaTier.HOLE_PULL;
        AABB box = new AABB(c, c).inflate(reach);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> valid(p, e))) {
            Vec3 to = c.subtract(e.getBoundingBox().getCenter());
            double dist = to.length();
            if (dist > reach || dist < 1.0E-3) {
                continue;
            }
            double f = Math.min(0.75, 0.045 + 4.0 * horizon * horizon / (dist * dist)) * grow;   // 0.71 dari 100 blok
            double lift = (0.02 + 0.06 * (1.0 - dist / reach)) * grow;   // yang jauh terseret di tanah, yang dekat terangkat
            e.push(to.x / dist * f, to.y / dist * f + lift, to.z / dist * f);
            e.hurtMarked = true;
            e.resetFallDistance();
            double w = e.getBbWidth() * 0.5;
            if (dist < horizon * 1.7 + w && s.holeAge % 4 == 0) {   // spagetifikasi: gaya pasang di dekat cakrawala peristiwa
                boolean inside = dist < horizon + w;
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, inside ? HOLE_HORIZON_DMG : HOLE_TIDAL_DMG));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 3), p);
                if (inside) {
                    e.addEffect(new MobEffectInstance(MobEffects.WITHER, 40, 1), p);
                }
            }
        }
        for (Projectile pr : level.getEntitiesOfClass(Projectile.class, box, x -> x.getOwner() != p)) {
            Vec3 to = c.subtract(pr.position());
            double dist = to.length();
            if (dist > reach * 0.5) {
                continue;
            }
            if (dist < horizon) {
                if (pr instanceof ThrownTrident || pr instanceof ThrownDoubleBlade) {
                    pr.setDeltaMovement(Vec3.ZERO);   // barang milik orang: cuma tertahan
                } else {
                    pr.discard();
                }
                continue;
            }
            pr.setDeltaMovement(pr.getDeltaMovement().scale(0.85).add(to.scale(0.12 / dist)));
            pr.hurtMarked = true;
        }
        if (s.holeAge % 2 == 0) {
            for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, box.deflate(reach * 0.4))) {
                Vec3 to = c.subtract(item.position());
                double dist = Math.max(1.0, to.length());
                item.setDeltaMovement(item.getDeltaMovement().add(to.scale(0.06 / dist)));
            }
        }
        if (griefing(level) && s.holeAge > 6 && !Double.isNaN(s.holeGround)) {   // ruang-waktu menelan tanah di bawahnya
            eatGround(level, c, s.holeGround, grow);
        }
        if (s.hole == 0) {   // radiasi Hawking: lubang hitam menguap habis, lalu meledak (0.71 sebesar gunung)
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_BH_END, c);
            sound(p, c, ShazamSounds.RELATIVA_HAWKING.get(), 5.0f);
            sound(p, c, ShazamSounds.RELATIVA_HAWKING_MEGA.get(), 12.0f);
            double r = RelativaTier.HAWKING_RADIUS;
            for (LivingEntity e : around(p, c, r)) {
                Vec3 at = e.getBoundingBox().getCenter();
                double dist = at.distanceTo(c);
                double k = Math.max(0.3, 1.0 - dist / (r * 1.15));
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, HAWKING_DMG * (float) k));
                e.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 1), p);
                Vec3 away = at.subtract(c);
                away = away.lengthSqr() < 1.0E-4 ? new Vec3(0, 1, 0) : away.normalize();
                double push = (1.2 + 2.4 * k) * K;
                e.push(away.x * push, 0.6 + 0.4 * Math.max(0.0, away.y) + 0.8 * k, away.z * push);
                e.hurtMarked = true;
            }
            if (griefing(level) && !Double.isNaN(s.holeGround)) {   // kawah di dasar mangkuk yang sudah dicabut
                int x = Mth.floor(c.x), z = Mth.floor(c.z);
                int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                if (c.y - top < RelativaTier.HOLE_LIFT + RelativaTier.HOLE_DIG + 16) {
                    InfinityWorld.crater(level, new Vec3(c.x, top, c.z), RelativaTier.HAWKING_CRATER);
                }
            }
            s.holeAt = null;
            s.holeGround = Double.NaN;
            d.holeTicks = 0;
            RelativaNetwork.broadcastState(p);
        }
    }

    /**
     * 0.71 Tanah di bawah lubang hitam dicabut lapis demi lapis dari atas, makin ke tengah makin dalam (mangkuk raksasa
     * sedalam HOLE_DIG). Bukit & tebing di sekitarnya ikut termakan sampai sedikit di atas lubangnya. Blok berisi
     * (peti dll.) & yang nggak bisa dihancurkan dibiarkan.
     */
    private static void eatGround(ServerLevel level, Vec3 c, double ground, double grow) {
        RandomSource rnd = level.random;
        double reachR = RelativaTier.HOLE_EAT * (0.35 + 0.65 * grow);
        int ceiling = Mth.floor(c.y + RelativaTier.HOLE_EAT * 0.5);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int eaten = 0;
        for (int i = 0; i < HOLE_EAT_TRIES && eaten < HOLE_EAT_PER_TICK; i++) {
            double rr = reachR * Math.pow(rnd.nextDouble(), 0.7);   // agak condong ke tengah
            double ang = rnd.nextDouble() * Math.PI * 2.0;
            int x = Mth.floor(c.x + Math.cos(ang) * rr), z = Mth.floor(c.z + Math.sin(ang) * rr);
            if (!level.isLoaded(pos.set(x, Mth.floor(ground), z))) {   // chunk yang belum termuat nggak disentuh
                continue;
            }
            double k = rr / RelativaTier.HOLE_EAT;
            int floor = Mth.floor(ground - RelativaTier.HOLE_DIG * (1.0 - k * k));
            int y = Math.min(level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1, ceiling);
            for (int steps = 0; y >= floor && steps < 48; y--, steps++) {   // blok teratas yang belum termakan
                pos.set(x, y, z);
                BlockState state = level.getBlockState(pos);
                if (state.isAir()) {
                    continue;
                }
                if (eatable(level, pos, state)) {
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                    eaten++;
                }
                break;
            }
        }
    }

    private static boolean eatable(ServerLevel level, BlockPos pos, BlockState state) {
        return !state.isAir() && level.isLoaded(pos) && state.getDestroySpeed(level, pos) >= 0f
                && level.getBlockEntity(pos) == null;
    }

    // ================================================================ C  Kuantum

    // C  Terowongan Kuantum: peluang partikel ada di balik penghalang nggak pernah nol. Kamu muncul di sana.
    private static boolean tunnel(ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double eyeHeight = p.getEyeHeight();
        Vec3 dest = null;
        for (double dist = TUNNEL_RANGE; dist >= 2.5; dist -= 0.5) {   // titik aman terjauh, walau ada dinding di depannya
            Vec3 feet = eye.add(look.scale(dist)).subtract(0, eyeHeight, 0);
            if (feet.y < p.level().getMinBuildHeight() + 1 || !p.level().isLoaded(BlockPos.containing(feet))) {
                continue;
            }
            if (p.level().noCollision(p, p.getBoundingBox().move(feet.subtract(p.position())))) {
                dest = feet;
                break;
            }
        }
        if (dest == null) {
            return false;
        }
        final Vec3 to = dest;
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_TUNNEL, to);
        sound(p, p.position(), ShazamSounds.RELATIVA_TUNNEL.get(), 1.6f);
        busy(p, ShazamAnim.REL_TUNNEL_AT + 2);
        later(p, ShazamAnim.REL_TUNNEL_AT, sp -> {
            if (!sp.level().noCollision(sp, sp.getBoundingBox().move(to.subtract(sp.position())))) {
                return;
            }
            sp.teleportTo(to.x, to.y, to.z);
            sp.resetFallDistance();
            sound(sp, to, ShazamSounds.RELATIVA_TUNNEL.get(), 1.2f);
            for (LivingEntity e : around(sp, to, 3.2 * A)) {   // gelombang peluang runtuh: yang di dekatnya terhentak
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 6f));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 2), sp);
                Vec3 away = flat(e.position().subtract(to));
                e.push(away.x * 0.8 * K, 0.3, away.z * 0.8 * K);
                e.hurtMarked = true;
            }
        });
        return true;
    }

    // Shift+C  Keterikatan Kuantum ("aksi seram dari jauh"): yang terjadi pada satu langsung terjadi pada pasangannya
    private static boolean entangle(ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        List<LivingEntity> list = new ArrayList<>();
        for (LivingEntity e : enemies(p, 16.0 * A)) {
            Vec3 to = chest(e).subtract(eye);
            double dist = to.length();
            if (dist > 16.0 * A || (dist > 3.0 && to.normalize().dot(look) < 0.25)) {
                continue;
            }
            list.add(e);
        }
        if (list.isEmpty()) {
            return false;
        }
        list.sort(Comparator.comparingDouble(e -> e.distanceToSqr(p)));
        List<LivingEntity> targets = new ArrayList<>(list.subList(0, Math.min(ENTANGLE_MAX, list.size())));
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_ENTANGLE);
        sound(p, p.position(), ShazamSounds.RELATIVA_ENTANGLE.get(), 1.8f);
        busy(p, ShazamAnim.REL_ENTANGLE_HIT + 4);
        later(p, ShazamAnim.REL_ENTANGLE_HIT, sp -> {
            State s = state(sp);
            s.entangled.clear();
            for (LivingEntity e : targets) {
                if (!e.isAlive() || e.level() != sp.level()) {
                    continue;
                }
                s.entangled.add(e);
                ShazamNetwork.playAnim(sp, ShazamAnim.PHYS_ENTANGLE, chest(e));
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 4f));
                e.addEffect(new MobEffectInstance(MobEffects.GLOWING, ShazamAnim.REL_ENTANGLE_TICKS, 0), sp);
            }
            s.entangle = s.entangled.isEmpty() ? 0 : ShazamAnim.REL_ENTANGLE_TICKS;
            RelativaAbilities.data(sp).entangleTicks = s.entangle;
        });
        return true;
    }

    private static void tickEntangle(State s, RelativaData d) {
        if (s.entangle <= 0) {
            return;
        }
        s.entangled.removeIf(e -> !e.isAlive());
        if (--s.entangle <= 0 || s.entangled.isEmpty()) {
            s.entangle = 0;
            s.entangled.clear();
        }
        d.entangleTicks = s.entangle;
    }

    /** Damage yang benar-benar masuk ke satu makhluk terikat mengalir ke semua pasangannya. */
    public static void onDamagePost(LivingDamageEvent.Post event) {
        LivingEntity victim = event.getEntity();
        float dealt = event.getNewDamage();
        if (sharing || STATES.isEmpty() || dealt <= 0f || victim.level().isClientSide() || victim.getServer() == null) {
            return;
        }
        for (Map.Entry<UUID, State> en : new ArrayList<>(STATES.entrySet())) {
            State s = en.getValue();
            if (s.entangle <= 0 || !s.entangled.contains(victim)) {
                continue;
            }
            ServerPlayer owner = victim.getServer().getPlayerList().getPlayer(en.getKey());
            if (owner == null) {
                continue;
            }
            sharing = true;
            try {
                for (LivingEntity e : new ArrayList<>(s.entangled)) {
                    if (e == victim || !e.isAlive() || e.level() != victim.level()) {
                        continue;
                    }
                    e.invulnerableTime = 0;
                    e.hurt(magic(owner), dealt * ENTANGLE_SHARE);
                    ShazamNetwork.playAnim(owner, ShazamAnim.PHYS_ENTANGLE_PULSE, chest(e));
                }
            } finally {
                sharing = false;
            }
        }
    }

    // ================================================================ V  Fisi Nuklir

    // V  Fisi Berantai: satu neutron membelah inti, tiap belahan melepas dua neutron lagi, dan seterusnya
    private static boolean fission(ServerPlayer p) {
        LivingEntity first = aimed(p, 40.0);
        if (first == null) {
            first = nearestInFront(p, 24.0);
        }
        if (first == null) {
            return false;
        }
        final LivingEntity target = first;
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_FISSION, chest(target));
        sound(p, p.position(), ShazamSounds.RELATIVA_NEUTRON.get(), 1.4f);
        busy(p, ShazamAnim.REL_FISSION_HIT + 2);
        Set<LivingEntity> reserved = new HashSet<>();
        reserved.add(target);
        int[] budget = {FISSION_BUDGET};
        later(p, ShazamAnim.REL_FISSION_HIT, sp -> split(sp, target, 0, reserved, budget));
        return true;
    }

    private static void split(ServerPlayer p, LivingEntity t, int gen, Set<LivingEntity> reserved, int[] budget) {
        if (!t.isAlive() || budget[0] <= 0 || t.level() != p.level()) {
            return;
        }
        budget[0]--;
        Vec3 at = chest(t);
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_FISSION, at);
        sound(p, at, ShazamSounds.RELATIVA_FISSION.get(), 1.5f);
        t.invulnerableTime = 0;
        t.hurt(magic(p), dmg(p, FISSION_DMG * (float) Math.pow(0.88, gen)));   // 0.71 jauh lebih sakit
        RandomSource r = p.getRandom();
        t.push((r.nextDouble() - 0.5) * 0.6 * K, 0.25, (r.nextDouble() - 0.5) * 0.6 * K);
        t.hurtMarked = true;
        if (gen >= FISSION_GENS) {   // 0.68 lima generasi, 0.71 enam
            return;
        }
        List<LivingEntity> next = new ArrayList<>();
        for (LivingEntity e : around(p, at, FISSION_HOP)) {
            if (!reserved.contains(e)) {
                next.add(e);
            }
        }
        next.sort(Comparator.comparingDouble(e -> e.position().distanceToSqr(at)));
        for (int k = 0; k < Math.min(3, next.size()); k++) {   // 0.68 tiap inti melepas tiga neutron
            LivingEntity n = next.get(k);
            reserved.add(n);
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_FROM, at);
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_NEUTRON, chest(n));
            later(p, ShazamAnim.REL_FISSION_GAP, sp -> split(sp, n, gen + 1, reserved, budget));
        }
    }

    // Shift+V  Massa Kritis: inti uranium dimampatkan sampai superkritis. 0.71 SEBESAR GUNUNG: dilempar jauh (minimal 48 blok),
    // bola api 30 blok, gelombang kejut yang merambat sampai 100 blok, kawah 40, awan jamur 130 blok, zona radiasi 44 blok.
    private static boolean critical(ServerPlayer p) {
        Vec3 ground = farGround(p, NUKE_RANGE, NUKE_FAR, RelativaTier.MOUNTAIN_MIN, false);
        Vec3 c = (ground != null ? ground : p.getEyePosition().add(p.getLookAngle().scale(NUKE_FAR))).add(0, 0.6, 0);
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_CRITICAL, c);
        sound(p, p.position(), ShazamSounds.RELATIVA_CRITICAL.get(), 3.0f);   // 0.71 titik nolnya jauh: ancang-ancang di pelempar
        busy(p, ShazamAnim.REL_CRIT_CORE + 4);
        later(p, ShazamAnim.REL_CRIT_BOOM, sp -> nuke(sp, c));
        return true;
    }

    private static void nuke(ServerPlayer p, Vec3 c) {
        ServerLevel level = p.serverLevel();
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_CRIT_BOOM, c);
        level.playSound(null, c.x, c.y, c.z, ShazamSounds.RELATIVA_NUKE.get(), SoundSource.PLAYERS, 8.0f * RelativaTier.SOUND,
                1f);
        level.playSound(null, c.x, c.y, c.z, ShazamSounds.RELATIVA_NUKE_MEGA.get(), SoundSource.PLAYERS,
                16.0f * RelativaTier.SOUND, 1f);   // 0.71 gemuruh sebesar gunung, terdengar ±400 blok
        State s = state(p);
        s.blasted.clear();
        double fb = RelativaTier.NUKE_FIREBALL;
        for (LivingEntity e : around(p, c, fb)) {   // bola api: semua yang di dalamnya kena penuh seketika
            s.blasted.add(e.getId());
            e.invulnerableTime = 0;
            e.hurt(p.damageSources().explosion(p, p), dmg(p, NUKE_FIREBALL_DMG));
            e.igniteForSeconds(15);
            Vec3 away = e.getBoundingBox().getCenter().subtract(c);
            away = away.lengthSqr() < 1.0E-4 ? new Vec3(0, 1, 0) : away.normalize();
            e.push(away.x * 3.2 * K, 1.2 + Math.max(0.0, away.y), away.z * 3.2 * K);
            e.hurtMarked = true;
        }
        if (griefing(level)) {
            InfinityWorld.crater(level, c, RelativaTier.NUKE_CRATER);
        }
        s.blastAt = c;   // gelombang kejut mulai merambat dari tepi bola api (lihat tickBlast)
        s.blastR = fb;
        s.blast = (int) Math.ceil((RelativaTier.NUKE_RADIUS - fb) / RelativaTier.NUKE_WAVE_SPEED);
        s.radAt = c;
        s.rad = RelativaTier.NUKE_RAD_TICKS;
    }

    /**
     * 0.71 Gelombang kejut Massa Kritis: tiap tick merambat NUKE_WAVE_SPEED blok (client menggambar muka gelombangnya di
     * jarak yang sama), menghantam tiap makhluk sekali saat lewat, dan (mobGriefing) menggunduli hutan & menghanguskan
     * rumput yang dilewatinya.
     */
    private static void tickBlast(ServerPlayer p, State s) {
        if (s.blast <= 0 || s.blastAt == null) {
            return;
        }
        s.blast--;
        ServerLevel level = p.serverLevel();
        Vec3 c = s.blastAt;
        double fb = RelativaTier.NUKE_FIREBALL, max = RelativaTier.NUKE_RADIUS;
        double r0 = s.blastR, r1 = Math.min(max, r0 + RelativaTier.NUKE_WAVE_SPEED);
        s.blastR = r1;
        for (LivingEntity e : around(p, c, r1)) {
            double dist = e.getBoundingBox().getCenter().distanceTo(c);
            if (dist < r0 - 2.0 || s.blasted.contains(e.getId())) {
                continue;
            }
            s.blasted.add(e.getId());
            double k = Mth.clamp(1.0 - (dist - fb) / (max - fb), 0.0, 1.0);   // 1 di tepi bola api, 0 di ujung gelombang
            e.invulnerableTime = 0;
            e.hurt(p.damageSources().explosion(p, p), dmg(p, NUKE_WAVE_DMG * (float) Math.max(0.3, k)));
            if (k > 0.35) {
                e.igniteForSeconds(8);
            }
            Vec3 away = flat(e.position().subtract(c));
            double push = (0.9 + 2.3 * k) * K;
            e.push(away.x * push, 0.35 + 0.75 * k, away.z * push);
            e.hurtMarked = true;
        }
        if (griefing(level) && r1 > RelativaTier.NUKE_CRATER) {
            scorch(level, c, Math.max(r0, RelativaTier.NUKE_CRATER), r1);
        }
        if (s.blast <= 0) {
            s.blastAt = null;
            s.blasted.clear();
        }
    }

    /** 0.71 Muka gelombang kejut menyapu cincin r0..r1: daun tersapu (pohon tinggal batang hangus), rumput & salju hangus. */
    private static void scorch(ServerLevel level, Vec3 c, double r0, double r1) {
        RandomSource rnd = level.random;
        int samples = (int) Math.min(260, Math.PI * (r1 * r1 - r0 * r0) * 0.22);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        double near = RelativaTier.NUKE_CRATER * 1.5;
        for (int i = 0; i < samples; i++) {
            double rr = Math.sqrt(r0 * r0 + rnd.nextDouble() * (r1 * r1 - r0 * r0));
            double ang = rnd.nextDouble() * Math.PI * 2.0;
            int x = Mth.floor(c.x + Math.cos(ang) * rr), z = Mth.floor(c.z + Math.sin(ang) * rr);
            if (!level.isLoaded(pos.set(x, Mth.floor(c.y), z))) {
                continue;
            }
            int y = level.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1;
            for (int n = 0; n < 12; n++, y--) {   // daun & tanaman dari atas ke bawah
                pos.set(x, y, z);
                BlockState state = level.getBlockState(pos);
                if (state.isAir()) {
                    continue;
                }
                if (state.is(BlockTags.LEAVES) || state.is(BlockTags.FLOWERS) || state.is(Blocks.SHORT_GRASS)
                        || state.is(Blocks.TALL_GRASS) || state.is(Blocks.FERN) || state.is(Blocks.LARGE_FERN)
                        || state.is(Blocks.SNOW) || state.is(Blocks.DEAD_BUSH) || state.is(Blocks.SWEET_BERRY_BUSH)) {
                    if (level.getBlockEntity(pos) == null) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), Block.UPDATE_CLIENTS);
                    }
                    continue;
                }
                if (state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.PODZOL) || state.is(Blocks.MYCELIUM)) {   // tanah hangus
                    float f = rnd.nextFloat();
                    if (f < 0.75f) {
                        level.setBlock(pos, (f < 0.45f ? Blocks.COARSE_DIRT : f < 0.65f ? Blocks.DIRT : Blocks.ROOTED_DIRT)
                                .defaultBlockState(), Block.UPDATE_CLIENTS);
                    }
                    if (rr < near && f > 0.97f && level.getBlockState(pos.above()).isAir()) {   // api di dekat titik nol
                        level.setBlock(pos.above(), Blocks.FIRE.defaultBlockState(), Block.UPDATE_ALL);
                    }
                }
                break;   // permukaan padat lain (batu, kayu, bangunan) dibiarkan
            }
        }
    }

    private static void tickRadiation(ServerPlayer p, State s) {
        if (s.rad <= 0 || s.radAt == null) {
            return;
        }
        if (--s.rad % 20 == 0) {   // radiasi sisa: sakit radiasi untuk yang masuk zona (0.71 zona 44 blok, lebih sakit)
            for (LivingEntity e : around(p, s.radAt, RelativaTier.NUKE_RAD)) {
                e.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 2), p);
                e.addEffect(new MobEffectInstance(MobEffects.HUNGER, 60, 2), p);
                e.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 1), p);
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1), p);
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, NUKE_RAD_DMG));
            }
            sound(p, s.radAt, ShazamSounds.RELATIVA_GEIGER.get(), 2.0f);
        }
        if (s.rad <= 0) {
            s.radAt = null;
        }
    }

    // ================================================================ B  Fusi Nuklir

    // B  Fusi Bintang: dua inti hidrogen dipaksa bersatu jadi helium, selisih massanya jadi bintang mini
    private static boolean fusion(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_FUSION);
        sound(p, p.position(), ShazamSounds.RELATIVA_FUSION.get(), 1.8f);
        busy(p, ShazamAnim.REL_FUSION_THROW + 2);
        later(p, ShazamAnim.REL_FUSION_THROW, sp -> {
            Vec3 from = sp.getEyePosition().add(0, -0.3, 0);
            Vec3 impact = rayImpact(sp, from, sp.getLookAngle(), 60.0);
            ShazamNetwork.playAnim(sp, ShazamAnim.PHYS_FUSION_SHOT, impact);
            int travel = Math.max(1, (int) Math.ceil(from.distanceTo(impact) / RelativaData.FUSION_SPEED));
            later(sp, travel, sp2 -> fusionBoom(sp2, impact));
        });
        return true;
    }

    private static void fusionBoom(ServerPlayer p, Vec3 at) {
        sound(p, at, ShazamSounds.RELATIVA_FUSION_BOOM.get(), 3.6f);
        for (LivingEntity e : around(p, at, FUSION_RADIUS)) {   // 0.71 lebih luas & jauh lebih sakit
            double dist = e.position().distanceTo(at);
            e.invulnerableTime = 0;
            e.hurt(magic(p), dmg(p, FUSION_DMG * (float) Math.max(0.4, 1.0 - dist / (FUSION_RADIUS * 1.5))));
            e.igniteForSeconds(10);
            Vec3 away = flat(e.position().subtract(at));
            e.push(away.x * 1.4 * K, 0.6, away.z * 1.4 * K);
            e.hurtMarked = true;
        }
        if (griefing(p.serverLevel())) {   // 0.68 bintang mini yang meledak meninggalkan kawah
            InfinityWorld.crater(p.serverLevel(), at, FUSION_CRATER);
        }
    }

    // Shift+B  Tokamak: plasma bersuhu jutaan derajat dikurung medan magnet berbentuk donat di sekelilingmu
    private static boolean tokamak(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_TOKAMAK);
        sound(p, p.position(), ShazamSounds.RELATIVA_TOKAMAK.get(), 2.0f);
        busy(p, ShazamAnim.REL_TOKAMAK_HIT + 4);
        later(p, ShazamAnim.REL_TOKAMAK_HIT, sp -> {
            State s = state(sp);
            s.tokamak = ShazamAnim.REL_TOKAMAK_TICKS;
            RelativaAbilities.data(sp).tokamakTicks = s.tokamak;
            RelativaNetwork.broadcastState(sp);
        });
        return true;
    }

    private static void tickTokamak(ServerPlayer p, State s, RelativaData d) {
        if (s.tokamak <= 0) {
            return;
        }
        s.tokamak--;
        d.tokamakTicks = s.tokamak;
        Vec3 c = p.position().add(0, 1.0, 0);
        if (s.tokamak % 10 == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 14, 0, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 14, 0, false, false));
            for (LivingEntity e : around(p, c, TOKAMAK_RADIUS + 2.2 * TOKAMAK_TUBE)) {
                double dx = e.getX() - c.x, dz = e.getZ() - c.z;
                double rho = Math.sqrt(dx * dx + dz * dz);
                double dy = e.getY() + e.getBbHeight() * 0.5 - c.y;
                if (Math.abs(rho - TOKAMAK_RADIUS) > 1.7 * TOKAMAK_TUBE || Math.abs(dy) > 1.9 * TOKAMAK_TUBE) {
                    continue;
                }
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, TOKAMAK_DMG));
                e.igniteForSeconds(5);
                Vec3 out = rho < 0.01 ? new Vec3(1, 0, 0) : new Vec3(dx / rho, 0, dz / rho);
                e.push(out.x * 0.7 * K, 0.25, out.z * 0.7 * K);
                e.hurtMarked = true;
            }
        }
        for (Projectile pr : p.serverLevel().getEntitiesOfClass(Projectile.class,
                new AABB(c, c).inflate(TOKAMAK_RADIUS + 1.5 * TOKAMAK_TUBE), x -> x.getOwner() != p)) {
            double dx = pr.getX() - c.x, dz = pr.getZ() - c.z;
            double rho = Math.sqrt(dx * dx + dz * dz);
            if (Math.abs(rho - TOKAMAK_RADIUS) > 1.3 * TOKAMAK_TUBE || Math.abs(pr.getY() - c.y) > 1.3 * TOKAMAK_TUBE) {
                continue;
            }
            if (pr instanceof ThrownTrident || pr instanceof ThrownDoubleBlade) {
                pr.setDeltaMovement(Vec3.ZERO);
            } else {
                pr.discard();   // menguap di plasma
            }
        }
        if (s.tokamak == 0) {   // plasma lepas kendali: cincinnya pecah ke luar
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_DISRUPT, c);
            sound(p, c, ShazamSounds.RELATIVA_DISRUPT.get(), 3.2f);
            for (LivingEntity e : around(p, c, DISRUPT_RADIUS)) {   // 0.71 lebih luas & jauh lebih sakit
                double dist = e.position().distanceTo(c);
                e.invulnerableTime = 0;
                e.hurt(magic(p), dmg(p, DISRUPT_DMG * (float) Math.max(0.35, 1.0 - dist / (DISRUPT_RADIUS * 1.35))));
                e.igniteForSeconds(8);
                Vec3 away = flat(e.position().subtract(c));
                e.push(away.x * 1.7 * K, 0.6, away.z * 1.7 * K);
                e.hurtMarked = true;
            }
            RelativaNetwork.broadcastState(p);
        }
    }

    // ================================================================ N  E = mc²

    // N  E = mc²: sebagian massa sasaran dikonversi jadi energi. Makin besar massanya (darah maksimal), makin dahsyat.
    private static boolean emc(ServerPlayer p) {
        LivingEntity target = aimed(p, 48.0);
        if (target == null) {
            return false;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_EMC, chest(target));
        sound(p, p.position(), ShazamSounds.RELATIVA_EMC.get(), 1.8f);
        busy(p, ShazamAnim.REL_EMC_HIT + 4);
        later(p, ShazamAnim.REL_EMC_HIT, sp -> {
            if (!target.isAlive() || target.level() != sp.level() || target.distanceTo(sp) > 56.0) {
                return;
            }
            float base = Math.min(EMC_CAP, EMC_BASE + target.getMaxHealth() * EMC_PER_HP);   // 0.71 jauh lebih sakit
            float dealt = dmg(sp, base);
            Vec3 at = chest(target);
            target.invulnerableTime = 0;
            target.hurt(magic(sp), dealt);
            sound(sp, at, ShazamSounds.RELATIVA_EMC_BOOM.get(), 3.4f);
            for (LivingEntity e : around(sp, at, EMC_RADIUS)) {   // 0.68 energi yang terlepas menyambar musuh di sekitarnya
                if (e == target) {
                    continue;
                }
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dealt * EMC_BLAST);
                Vec3 away = flat(e.position().subtract(target.position()));
                e.push(away.x * 1.3 * K, 0.5, away.z * 1.3 * K);
                e.hurtMarked = true;
            }
            RelativaData data = RelativaAbilities.data(sp);
            data.energy = Math.min(RelativaData.MAX_ENERGY, data.energy + 20f);   // energinya dipanen
            sp.setAbsorptionAmount(Math.max(sp.getAbsorptionAmount(), Math.min((float) RelativaPowers.SHIELD, dealt * 0.25f)));
            target.push(0.0, 0.5, 0.0);
            target.hurtMarked = true;
        });
        return true;
    }

    // Shift+N  Anihilasi: elektron bertemu positron, massanya lenyap 100% jadi dua foton gamma yang berlawanan arah
    private static boolean annihilate(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_ANNIHILATE);
        sound(p, p.position(), ShazamSounds.RELATIVA_ANNIHILATE.get(), 2.2f);
        busy(p, ShazamAnim.REL_ANNIHILATE_AT + ShazamAnim.REL_ANNIHILATE_TICKS);
        later(p, ShazamAnim.REL_ANNIHILATE_AT, sp -> {
            Vec3 from = sp.getEyePosition().add(0, -0.35, 0);
            Vec3 look = sp.getLookAngle();
            Set<LivingEntity> hit = new HashSet<>();
            for (int k = 0; k < 2; k++) {
                Vec3 dir = k == 0 ? look : look.scale(-1.0);
                Vec3 end = blockEnd(sp, from, dir, ANNIHILATE_RANGE);
                for (LivingEntity e : along(sp, from, end, ANNIHILATE_WIDTH)) {
                    if (!hit.add(e)) {
                        continue;
                    }
                    e.invulnerableTime = 0;
                    e.hurt(magic(sp), dmg(sp, ANNIHILATE_DMG));   // 0.71 jauh lebih sakit
                    e.push(dir.x * 0.8 * K, 0.3, dir.z * 0.8 * K);
                    e.hurtMarked = true;
                }
            }
        });
        return true;
    }

    // ================================================================ R

    // R  Teori Medan Terpadu: gravitasi, elektromagnet, gaya kuat, gaya lemah jadi satu (mimpi terakhir Einstein)
    private static void unified(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_UNIFIED);
        sound(p, p.position(), ShazamSounds.RELATIVA_UNIFIED.get(), 3.2f);
        busy(p, ShazamAnim.REL_UNIFIED_TICKS);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, ShazamAnim.REL_UNIFIED_HIT + 6, 2, false, false));
        later(p, ShazamAnim.REL_UNIFIED_HIT, sp -> {
            Vec3 c = sp.position().add(0, 1.0, 0);
            int n = 0;
            for (LivingEntity e : around(sp, c, 22.0 * A)) {
                double dist = e.position().distanceTo(c);
                if (n++ < 48) {
                    ShazamNetwork.playAnim(sp, ShazamAnim.PHYS_UNIFIED_HIT, chest(e));
                }
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 30f * (float) Math.max(0.6, 1.0 - dist / (44.0 * A))));
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 5), sp);  // gaya kuat: terkunci
                e.addEffect(new MobEffectInstance(MobEffects.WITHER, 200, 2), sp);             // gaya lemah: meluruh
                e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 140, 0), sp);
                Vec3 away = flat(e.position().subtract(c));
                e.push(away.x * 1.4 * K, 0.9, away.z * 1.4 * K);                             // elektromagnet: tolakan
                e.hurtMarked = true;
            }
        });
    }

    // Shift+R  Kondensat Bose-Einstein: didinginkan sampai nyaris nol mutlak, semua atomnya berhenti & menyatu
    private static void condensate(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_BEC);
        sound(p, p.position(), ShazamSounds.RELATIVA_BEC.get(), 2.4f);
        busy(p, ShazamAnim.REL_BEC_HIT + 6);
        later(p, ShazamAnim.REL_BEC_HIT, sp -> {
            State s = state(sp);
            Vec3 c = sp.position();
            for (LivingEntity e : around(sp, c, 12.0 * A)) {
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, 8f));
                s.frozen.removeIf(h -> h.entity == e);
                s.frozen.add(new Held(e, ShazamAnim.REL_BEC_TICKS));
                ShazamNetwork.playAnim(sp, ShazamAnim.PHYS_FROZEN, chest(e));
            }
            if (griefing(sp.serverLevel())) {
                freezeWater(sp.serverLevel(), c, (int) Math.round(10 * A));
            }
        });
    }

    private static void tickFrozen(ServerPlayer p, State s) {
        if (s.frozen.isEmpty()) {
            return;
        }
        Iterator<Held> it = s.frozen.iterator();
        while (it.hasNext()) {
            Held h = it.next();
            LivingEntity e = h.entity;
            if (!e.isAlive() || e.level() != p.level() || --h.ticks <= 0) {
                if (e.isAlive()) {
                    e.setTicksFrozen(Math.min(e.getTicksFrozen(), e.getTicksRequiredToFreeze()));   // mencair pelan
                }
                it.remove();
                continue;
            }
            e.setTicksFrozen(Math.max(e.getTicksFrozen(), e.getTicksRequiredToFreeze() + 20));
            if (h.ticks % 5 == 0) {
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 6, false, false), p);
                e.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 10, 4, false, false), p);
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 10, 2, false, false), p);
            }
            Vec3 v = e.getDeltaMovement();
            e.setDeltaMovement(0.0, Math.min(0.0, v.y), 0.0);
            if (e instanceof Mob mob) {
                mob.getNavigation().stop();
            }
        }
    }

    private static void freezeWater(ServerLevel level, Vec3 c, int radius) {
        BlockPos center = BlockPos.containing(c);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int frozen = 0;
        for (int dx = -radius; dx <= radius && frozen < FREEZE_MAX; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz > radius * radius) {
                    continue;
                }
                for (int dy = -3; dy <= 2; dy++) {
                    pos.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    if (!level.isLoaded(pos)) {
                        continue;
                    }
                    BlockState state = level.getBlockState(pos);
                    if (state.is(Blocks.WATER) && level.getFluidState(pos).isSource() && level.getBlockState(pos.above()).isAir()) {
                        level.setBlockAndUpdate(pos.immutable(), Blocks.FROSTED_ICE.defaultBlockState());
                        frozen++;
                    }
                }
            }
        }
    }

    // ================================================================ M  Cahaya

    // M  Efek Fotolistrik: tiap foton membawa E = hν; begitu kena, elektronnya terlepas dan melompat ke yang terdekat
    private static void photo(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_PHOTO);
        sound(p, p.position(), ShazamSounds.RELATIVA_PHOTON.get(), 1.6f);
        busy(p, ShazamAnim.REL_PHOTO_FIRST + ShazamAnim.REL_PHOTO_COUNT * ShazamAnim.REL_PHOTO_GAP);
        for (int k = 0; k < ShazamAnim.REL_PHOTO_COUNT; k++) {
            final int shot = k;
            later(p, ShazamAnim.REL_PHOTO_FIRST + k * ShazamAnim.REL_PHOTO_GAP, sp -> photon(sp, shot));
        }
    }

    private static void photon(ServerPlayer p, int shot) {
        Vec3 from = p.getEyePosition().add(0, -0.2, 0);
        RandomSource r = p.getRandom();
        double spread = shot == 0 ? 0.0 : 0.035;
        Vec3 dir = p.getLookAngle().add((r.nextDouble() - 0.5) * spread, (r.nextDouble() - 0.5) * spread,
                (r.nextDouble() - 0.5) * spread).normalize();
        Vec3 end = blockEnd(p, from, dir, 50.0);
        EntityHitResult hit = rayEntity(p, from, end);
        Vec3 at = hit != null ? hit.getLocation() : end;
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_PHOTON, at);
        if (hit == null || !(hit.getEntity() instanceof LivingEntity target)) {
            return;
        }
        target.invulnerableTime = 0;
        target.hurt(magic(p), dmg(p, 4f));
        List<LivingEntity> near = new ArrayList<>();
        for (LivingEntity e : around(p, chest(target), 6.0 * A)) {
            if (e != target) {
                near.add(e);
            }
        }
        near.sort(Comparator.comparingDouble(e -> e.distanceToSqr(target)));
        for (int k = 0; k < Math.min(4, near.size()); k++) {   // fotoelektron melompat
            LivingEntity o = near.get(k);
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_FROM, chest(target));
            ShazamNetwork.playAnim(p, ShazamAnim.PHYS_ARC, chest(o));
            o.invulnerableTime = 0;
            o.hurt(magic(p), dmg(p, 3f));
        }
        if (!near.isEmpty()) {
            sound(p, chest(target), ShazamSounds.RELATIVA_ARC.get(), 1.0f);
        }
    }

    // Shift+M  Laser: emisi terstimulasi (Einstein 1917): satu foton memancing foton kembar, semuanya sefase
    private static void laser(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_LASER);
        sound(p, p.position(), ShazamSounds.RELATIVA_LASER.get(), 1.8f);
        busy(p, ShazamAnim.REL_LASER_CHARGE + ShazamAnim.REL_LASER_TICKS);
        later(p, ShazamAnim.REL_LASER_CHARGE, sp -> state(sp).laser = ShazamAnim.REL_LASER_TICKS);
    }

    private static void tickLaser(ServerPlayer p, State s) {
        if (s.laser <= 0) {
            return;
        }
        if (--s.laser % 2 != 0) {
            return;
        }
        Vec3 from = p.getEyePosition().add(0, -0.2, 0);
        Vec3 look = p.getLookAngle();
        Vec3 end = blockEnd(p, from, look, 40.0 * A);
        for (LivingEntity e : along(p, from, end, 1.6)) {
            e.invulnerableTime = 0;
            e.hurt(magic(p), dmg(p, 3f));
            e.igniteForSeconds(4);
        }
        ServerLevel level = p.serverLevel();
        if (s.laser % LASER_DRILL_EVERY == 0 && griefing(level) && end.distanceToSqr(from) < 40.0 * A * 40.0 * A - 1.0) {
            // 0.68 sinar koheren melelehkan blok yang disorotnya (lubang selebar tiga blok, tanpa barang jatuh)
            BlockPos hitPos = BlockPos.containing(end.add(look.scale(0.15)));
            drill(level, p, hitPos);
            for (net.minecraft.core.Direction side : net.minecraft.core.Direction.values()) {
                drill(level, p, hitPos.relative(side));
            }
        }
    }

    private static void drill(ServerLevel level, ServerPlayer p, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (eatable(level, pos, state) && state.getDestroySpeed(level, pos) <= 50f) {
            level.destroyBlock(pos, false, p);
        }
    }

    // ================================================================ J

    // J  Gelombang Gravitasi: ruang-waktu sendiri yang beriak, meregang ke satu arah sambil memampat ke arah lainnya
    private static void gravityWave(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_GWAVE);
        sound(p, p.position(), ShazamSounds.RELATIVA_GWAVE.get(), 2.2f);
        busy(p, ShazamAnim.REL_GWAVE_HIT + 6);
        later(p, ShazamAnim.REL_GWAVE_HIT, sp -> {
            Vec3 c = sp.position();
            for (LivingEntity e : around(sp, c, GWAVE_RADIUS)) {   // 0.71 lebih luas & jauh lebih sakit
                double dx = e.getX() - c.x, dz = e.getZ() - c.z;
                double dist = Math.sqrt(dx * dx + dz * dz);
                double ang = Math.atan2(dz, dx);
                double stretch = (0.6 + 0.5 * Math.cos(2.0 * ang)) * K;   // polarisasi "+": meregang di satu sumbu
                e.invulnerableTime = 0;
                e.hurt(magic(sp), dmg(sp, GWAVE_DMG * (float) Math.max(0.4, 1.0 - dist / (GWAVE_RADIUS * 1.5))));
                Vec3 out = dist < 0.01 ? new Vec3(1, 0, 0) : new Vec3(dx / dist, 0, dz / dist);
                e.push(out.x * stretch, 0.75, out.z * stretch);
                e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1), sp);
                e.hurtMarked = true;
            }
            sp.resetFallDistance();
        });
    }

    // Shift+J  Gerak Brown: ditabrak miliaran molekul dari segala arah, badanmu melompat-lompat acak
    private static void brownian(ServerPlayer p) {
        ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_BROWN);
        sound(p, p.position(), ShazamSounds.RELATIVA_BROWN.get(), 1.4f);
        busy(p, 2 + ShazamAnim.REL_BROWN_COUNT * ShazamAnim.REL_BROWN_GAP);
        for (int k = 0; k < ShazamAnim.REL_BROWN_COUNT; k++) {
            later(p, 2 + k * ShazamAnim.REL_BROWN_GAP, RelativaSkills::hop);
        }
    }

    private static void hop(ServerPlayer p) {
        RandomSource r = p.getRandom();
        Vec3 from = p.position();
        Vec3 to = null;
        for (int tries = 0; tries < 8 && to == null; tries++) {
            double a = r.nextDouble() * Math.PI * 2.0, dist = 3.0 + r.nextDouble() * 4.0;
            for (int dy = 0; dy <= 2 && to == null; dy++) {
                Vec3 c = from.add(Math.cos(a) * dist, dy == 2 ? -1 : dy, Math.sin(a) * dist);
                AABB box = p.getBoundingBox().move(c.subtract(from));
                if (!p.level().noCollision(p, box) || p.level().noCollision(p, box.move(0, -0.6, 0))) {
                    continue;   // sesak, atau nggak ada pijakan
                }
                BlockPos at = BlockPos.containing(c);
                if (p.level().getFluidState(at).is(FluidTags.LAVA) || p.level().getFluidState(at.below()).is(FluidTags.LAVA)) {
                    continue;
                }
                to = c;
            }
        }
        if (to == null) {
            return;
        }
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_FROM, from);
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_BROWN, to);
        p.teleportTo(to.x, to.y, to.z);
        p.resetFallDistance();
        p.invulnerableTime = Math.max(p.invulnerableTime, 6);
        for (LivingEntity e : around(p, to.add(0, 1.0, 0), 4.0)) {   // tabrakan molekul
            e.invulnerableTime = 0;
            e.hurt(magic(p), dmg(p, 4f));
            e.push((r.nextDouble() - 0.5) * 1.2 * K, 0.3, (r.nextDouble() - 0.5) * 1.2 * K);
            e.hurtMarked = true;
        }
    }

    // ---------------------------------------------------------------- bantuan

    static float dmg(ServerPlayer p, float base) {
        return Math.max(0f, base) * SKILL_DAMAGE;
    }

    static DamageSource magic(ServerPlayer p) {
        return p.damageSources().indirectMagic(p, p);
    }

    static void sound(ServerPlayer p, Vec3 at, SoundEvent sound, float volume) {   // 0.68 terdengar lebih jauh
        p.serverLevel().playSound(null, at.x, at.y, at.z, sound, SoundSource.PLAYERS, volume * RelativaTier.SOUND, 1f);
    }

    static Vec3 chest(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.62, 0);
    }

    static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : f.normalize();
    }

    static boolean griefing(ServerLevel level) {
        return level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
    }

    /** Sasaran kuasa: bukan diri sendiri, kawan, peliharaan sendiri; pemain cuma kalau PvP nyala. */
    static boolean valid(ServerPlayer p, LivingEntity e) {
        if (e == p || !e.isAlive() || e instanceof ArmorStand || p.isAlliedTo(e)) {
            return false;
        }
        if (e instanceof TamableAnimal pet && pet.isOwnedBy(p)) {
            return false;
        }
        if (e instanceof RelativaClone clone) {   // 0.70 salinan Kucing Schrödinger: milik sendiri kawan, milik orang lain = PvP
            return !clone.ownedBy(p) && p.server.isPvpAllowed();
        }
        return !(e instanceof Player) || p.server.isPvpAllowed();
    }

    static List<LivingEntity> enemies(ServerPlayer p, double radius) {
        return p.serverLevel().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(radius), e -> valid(p, e));
    }

    /** Sasaran yang pusat badannya dalam radius r dari titik c. */
    static List<LivingEntity> around(ServerPlayer p, Vec3 c, double r) {
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : p.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r + 2.0),
                e -> valid(p, e))) {
            if (e.getBoundingBox().getCenter().distanceTo(c) <= r + e.getBbWidth() * 0.5) {
                out.add(e);
            }
        }
        return out;
    }

    /** Sasaran yang badannya dekat ruas garis a-b (dalam radius r). */
    static List<LivingEntity> along(ServerPlayer p, Vec3 a, Vec3 b, double r) {
        List<LivingEntity> out = new ArrayList<>();
        Vec3 ab = b.subtract(a);
        double len2 = Math.max(1.0E-6, ab.lengthSqr());
        for (LivingEntity e : p.serverLevel().getEntitiesOfClass(LivingEntity.class, new AABB(a, b).inflate(r + 1.0),
                e -> valid(p, e))) {
            Vec3 c = e.getBoundingBox().getCenter();
            double t = Math.max(0.0, Math.min(1.0, c.subtract(a).dot(ab) / len2));
            Vec3 closest = a.add(ab.scale(t));
            if (c.distanceTo(closest) <= r + e.getBbWidth() * 0.5 + e.getBbHeight() * 0.25) {
                out.add(e);
            }
        }
        return out;
    }

    /** Musuh yang dibidik (paling dekat ke garis pandang, terlihat langsung), atau null. */
    static LivingEntity aimed(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bestScore = -1.0;
        for (LivingEntity e : enemies(p, range)) {
            Vec3 to = chest(e).subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.01) {
                continue;
            }
            double dot = to.normalize().dot(look);
            double need = Math.max(0.9, 0.995 - 0.6 / dist);   // makin dekat makin longgar
            if (dot < need || !p.hasLineOfSight(e)) {
                continue;
            }
            double score = dot - dist * 0.002;
            if (score > bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    /** Musuh terdekat di kerucut depan (buat sasaran pertama Fisi Berantai kalau nggak ada yang dibidik). */
    static LivingEntity nearestInFront(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity e : enemies(p, range)) {
            Vec3 to = chest(e).subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.01 || to.normalize().dot(look) < 0.6 || !p.hasLineOfSight(e)) {
                continue;
            }
            if (dist < bd) {
                bd = dist;
                best = e;
            }
        }
        return best;
    }

    /** Titik tujuan aman sejauh range di arah bidikan (mundur sampai 4 blok kalau tujuannya sesak), atau null. */
    static Vec3 safeAim(ServerPlayer p, double range) {
        HitResult hit = p.pick(range, 1.0f, false);
        Vec3 to = hit.getLocation();
        if (hit.getType() == HitResult.Type.BLOCK && hit instanceof BlockHitResult block) {
            BlockPos above = block.getBlockPos().relative(block.getDirection());
            to = Vec3.atBottomCenterOf(above);
        }
        Vec3 back = flat(p.getLookAngle()).scale(-1.0);
        for (int i = 0; i <= 4; i++) {
            Vec3 c = to.add(back.scale(i));
            if (p.level().noCollision(p, p.getBoundingBox().move(c.subtract(p.position())))) {
                return c;
            }
        }
        return null;
    }

    /** Titik di tanah yang dibidik (sejauh range), atau tanah fallback blok di depan kalau bidikannya ke langit. */
    static Vec3 aimPoint(ServerPlayer p, double range, double fallback) {
        HitResult hit = p.pick(range, 1.0f, false);
        if (hit.getType() == HitResult.Type.BLOCK) {
            return hit.getLocation();
        }
        Vec3 ahead = p.position().add(flat(p.getLookAngle()).scale(fallback));
        return new Vec3(ahead.x, p.serverLevel().getHeight(Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(ahead.x),
                (int) Math.floor(ahead.z)), ahead.z);
    }

    /**
     * 0.71 Titik tanah jauh di arah bidikan buat skill SEBESAR GUNUNG: blok yang dibidik (sejauh range), atau far blok di
     * depan kalau bidikannya ke langit; selalu minimal min blok (mendatar) dari pemain, dan mundur kalau chunk-nya belum
     * termuat. surface = true: tingginya selalu permukaan tanah (bukan daun, bukan langit-langit gua). null = di bawahnya
     * nggak ada tanah sama sekali (void).
     */
    static Vec3 farGround(ServerPlayer p, double range, double far, double min, boolean surface) {
        ServerLevel level = p.serverLevel();
        HitResult hit = p.pick(range, 1.0f, false);
        Vec3 look = flat(p.getLookAngle());
        boolean onBlock = hit.getType() == HitResult.Type.BLOCK;
        Vec3 at = onBlock ? hit.getLocation() : p.position().add(look.scale(far));
        double dx = at.x - p.getX(), dz = at.z - p.getZ();
        if (dx * dx + dz * dz < min * min) {   // terlalu dekat: didorong ke depan sampai jarak aman
            at = p.position().add(look.scale(min));
            onBlock = false;
        }
        for (int i = 0; i < 8 && !level.isLoaded(BlockPos.containing(at.x, p.getY(), at.z)); i++) {   // belum termuat: mundur
            at = at.add(look.scale(-16.0));
            onBlock = false;
        }
        if (onBlock && !surface) {
            return at;
        }
        int top = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(at.x), Mth.floor(at.z));
        return top <= level.getMinBuildHeight() ? null : new Vec3(at.x, top, at.z);
    }

    /** Titik pertama yang kena blok di arah dir (sejauh range), atau ujungnya. */
    static Vec3 blockEnd(ServerPlayer p, Vec3 from, Vec3 dir, double range) {
        Vec3 end = from.add(dir.scale(range));
        BlockHitResult hit = p.level().clip(new ClipContext(from, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return hit.getType() == HitResult.Type.MISS ? end : hit.getLocation();
    }

    /** Sasaran pertama yang dilewati garis from-to, atau null. */
    static EntityHitResult rayEntity(ServerPlayer p, Vec3 from, Vec3 to) {
        AABB box = new AABB(from, to).inflate(1.0);
        return ProjectileUtil.getEntityHitResult(p, from, to, box, e -> e instanceof LivingEntity le && valid(p, le),
                from.distanceToSqr(to));
    }

    /** Titik hantam bola yang dilempar lurus: blok atau sasaran pertama. */
    static Vec3 rayImpact(ServerPlayer p, Vec3 from, Vec3 dir, double range) {
        Vec3 end = blockEnd(p, from, dir, range);
        EntityHitResult hit = rayEntity(p, from, end);
        return hit != null ? hit.getLocation() : end;
    }
}
