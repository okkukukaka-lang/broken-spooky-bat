package com.shazammod.relativa;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;

import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 0.70 CINCIN EINSTEIN (tombol H, nyala / mati, tanpa batas waktu): massa RELATIVA melengkungkan ruang-waktu tepat di
 * sekeliling badannya sehingga cahaya dari belakang dibelokkan mengitarinya, seperti lensa gravitasi yang membuat galaksi
 * jauh tampak jadi cincin. Yang terlihat cuma lengkungan cahaya (lensa di shader RelativaLensShader), badannya sendiri nggak:
 *
 *   pemain lain     badan, baju zirah, barang di tangan, papan nama, atom di dada: nggak digambar sama sekali
 *   makhluk         kehilangan sasarannya dan nggak bisa mengincar RELATIVA (LivingChangeTargetEvent dibatalkan), juga
 *                   makhluk ber-"otak" (piglin, warden, hoglin) dan yang sedang marah
 *   menyerang       membuat lensanya goyah: terlihat REVEAL_TICKS (1,5 dtk), dan serangan PERTAMA dari balik lensa
 *                   damage-nya x STRIKE
 *
 * Tak terlihatnya memakai efek Invisibility tanpa partikel & tanpa ikon (dipasang ulang terus), jadi juga berlaku untuk mod
 * lain. Padam otomatis saat kembali jadi manusia / tumbang.
 */
public final class RelativaCloak {
    private RelativaCloak() {}

    // ======= Angka yang gampang diutak-atik =======
    private static final int TOGGLE_GAP = 10;
    public static final int REVEAL_TICKS = 30;          // terlihat sesudah menyerang
    public static final float STRIKE = 2.0f;            // serangan pertama dari balik lensa
    private static final double LOSE_RADIUS = 64.0;     // makhluk sejauh ini kehilangan sasarannya
    private static final int EFFECT_TICKS = 100;        // efek Invisibility (dipasang ulang sebelum habis)
    // ===============================================

    /** Sedang benar-benar tak terlihat (nyala, bukan sedang goyah sesudah menyerang). */
    public static boolean hidden(Player p) {
        RelativaData d = RelativaAbilities.data(p);
        return d.transformed && d.cloak && d.cloakReveal <= 0;
    }

    public static void toggle(ServerPlayer p, RelativaData d) {
        if (!d.transformed || d.morphing > 0 || !p.isAlive() || p.isSpectator()) {
            return;
        }
        long now = p.level().getGameTime();
        if (d.lastCloakToggle != 0L && now >= d.lastCloakToggle && now - d.lastCloakToggle < TOGGLE_GAP) {
            return;
        }
        d.lastCloakToggle = now;
        d.cloak = !d.cloak;
        if (d.cloak) {
            d.cloakReveal = ShazamAnim.REL_CLOAK_AT;   // cahaya mulai dibelokkan, hilang di REL_CLOAK_AT
            ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_CLOAK_ON);
            RelativaSkills.sound(p, p.position(), ShazamSounds.RELATIVA_CLOAK_ON.get(), 1.4f);
            RelativaAbilities.msg(p, "cloak_on", ChatFormatting.LIGHT_PURPLE);
        } else {
            d.cloakReveal = 0;
            removeEffect(p);
            ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_CLOAK_OFF);
            RelativaSkills.sound(p, p.position(), ShazamSounds.RELATIVA_CLOAK_OFF.get(), 1.3f);
            RelativaAbilities.msg(p, "cloak_off", ChatFormatting.GRAY);
        }
        update(p, d);
        RelativaNetwork.sync(p);
    }

    /** Tiap tick: efeknya dijaga, makhluk di sekitar kehilangan sasaran, dan status terlihat / nggak dikabarkan. */
    static void tick(ServerPlayer p, RelativaData d) {
        if (!d.transformed || !d.cloak) {
            if (d.cloakShown) {
                update(p, d);
            }
            return;
        }
        if (d.cloakReveal > 0) {
            d.cloakReveal--;
        }
        if (d.cloakReveal <= 0) {
            MobEffectInstance cur = p.getEffect(MobEffects.INVISIBILITY);
            if (cur == null || (ours(cur) && cur.getDuration() < EFFECT_TICKS - 20)) {
                p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, EFFECT_TICKS, 0, false, false, false));
            }
            if (p.tickCount % 5 == 0) {
                loseTargets(p);
            }
        } else {
            removeEffect(p);
        }
        update(p, d);
    }

    /** Kirim status ke semua yang melihat kalau berubah (badan digambar / nggak). */
    private static void update(ServerPlayer p, RelativaData d) {
        boolean hide = hidden(p);
        if (hide != d.cloakShown) {
            d.cloakShown = hide;
            RelativaNetwork.broadcastState(p);
        }
    }

    /** Kembali jadi manusia / tumbang / hidup lagi: padam tanpa animasi. */
    static void off(ServerPlayer p, RelativaData d) {
        boolean was = d.cloak || d.cloakShown;
        d.cloak = false;
        d.cloakReveal = 0;
        if (was) {
            removeEffect(p);
        }
        d.cloakShown = false;
    }

    private static boolean ours(MobEffectInstance e) {
        return !e.isVisible() && !e.showIcon() && e.getAmplifier() == 0 && e.getDuration() <= EFFECT_TICKS;
    }

    private static void removeEffect(ServerPlayer p) {
        MobEffectInstance cur = p.getEffect(MobEffects.INVISIBILITY);
        if (cur != null && ours(cur)) {
            p.removeEffect(MobEffects.INVISIBILITY);
        }
    }

    /** Makhluk yang sedang mengincar RELATIVA kehilangan jejaknya (termasuk yang memakai "otak" & yang sedang marah). */
    private static void loseTargets(ServerPlayer p) {
        for (Mob mob : p.serverLevel().getEntitiesOfClass(Mob.class, p.getBoundingBox().inflate(LOSE_RADIUS),
                m -> m.getTarget() == p)) {
            mob.setTarget(null);
            mob.getBrain().eraseMemory(MemoryModuleType.ATTACK_TARGET);
            mob.getBrain().eraseMemory(MemoryModuleType.ANGRY_AT);
            if (mob instanceof NeutralMob neutral) {
                neutral.stopBeingAngry();
            }
        }
    }

    /** Makhluk mencoba mengincar RELATIVA yang tak terlihat: dibatalkan. */
    public static void onChangeTarget(LivingChangeTargetEvent event) {
        if (event.getNewAboutToBeSetTarget() instanceof ServerPlayer p && hidden(p)) {
            event.setCanceled(true);
        }
    }

    /**
     * Semua damage yang dibuat RELATIVA ini (pukulan, skill, salinan): dari balik lensa = x STRIKE sekali, lalu lensanya
     * goyah (terlihat REVEAL_TICKS). Dipanggil RelativaAbilities.guard.
     */
    static void onAttack(LivingIncomingDamageEvent event, ServerPlayer attacker, LivingEntity victim) {
        RelativaData d = RelativaAbilities.data(attacker);
        if (!d.transformed || !d.cloak || victim == attacker) {
            return;
        }
        if (d.cloakReveal <= 0) {
            event.setAmount(event.getAmount() * STRIKE);
            ShazamNetwork.playAnim(attacker, ShazamAnim.PHYS_CLOAK_STRIKE, RelativaAbilities.chest(victim));
            RelativaSkills.sound(attacker, RelativaAbilities.chest(victim), ShazamSounds.RELATIVA_CLOAK_STRIKE.get(), 1.2f);
        }
        d.cloakReveal = REVEAL_TICKS;
        removeEffect(attacker);
        update(attacker, d);
    }
}
