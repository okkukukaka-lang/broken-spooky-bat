package com.shazammod.relativa;

import java.util.ArrayList;
import java.util.List;

import com.shazammod.ShazamMod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * 0.66 Paket RELATIVA. Tombol Z X C V B N R M J G memakai paket juara yang sudah ada (ShazamNetwork.handleAction ->
 * RelativaAbilities.handleSharedKey; 0.70 juga K Kucing Schrödinger & H Cincin Einstein); di sini: tombol Y, data HUD
 * pemain sendiri, dan status RELATIVA yang dilihat pemain lain (atom di dada, medan dilatasi, tokamak). 0.70: tombol F
 * (Foton Tanpa Massa), Jembatan Einstein-Rosen (layar koordinat / Shift+L), dan mulut-mulut lubang cacing di tiap dimensi.
 */
@EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class RelativaNetwork {
    private RelativaNetwork() {}

    public static final int ACTION_TRANSFORM = 0, ACTION_LIGHT = 1, ACTION_PHASE = 2, ACTION_PHOTON = 3;

    public static final int FLAG_DILATION = 1, FLAG_TOKAMAK = 2, FLAG_HOLE = 4, FLAG_PHASE = 8, FLAG_LIGHT = 16,
            FLAG_PHOTON = 32, FLAG_CLOAK = 64;   // 0.70 Foton Tanpa Massa (terbang), Cincin Einstein (sedang tak terlihat)

    /** 0.70 Paket Jembatan Einstein-Rosen dari client: bit mode. */
    public static final int WORM_AUTO_Y = 1, WORM_QUICK = 2, WORM_CLOSE = 4;
    /** 0.70 Status satu mulut lubang cacing yang dikirim ke client. */
    public static final int WORM_OPEN = 0, WORM_PASS = 1, WORM_SHUT = 2;

    /** Client -> server: tombol Y (berubah), O (Kecepatan Cahaya), I (pasif Terowongan Kuantum), 0.70 F (Foton). */
    public record ActionPayload(int action) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<ActionPayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("relativa_action"));

        public static final StreamCodec<ByteBuf, ActionPayload> STREAM_CODEC =
                ByteBufCodecs.VAR_INT.map(ActionPayload::new, ActionPayload::action);

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> client: data HUD pemain itu sendiri. */
    public record SyncPayload(boolean unlocked, boolean transformed, float energy, int papers, int dilationTicks,
                              int tokamakTicks, int entangleTicks, int holeTicks, boolean phase, int lightState,
                              int lightTicks, List<Integer> cooldowns, boolean photon, boolean cloak, int wormholeTicks,
                              int clones)
            implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<SyncPayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("relativa_sync"));

        public static final StreamCodec<ByteBuf, SyncPayload> STREAM_CODEC = StreamCodec.of(
                (buf, p) -> {
                    ByteBufCodecs.BOOL.encode(buf, p.unlocked());
                    ByteBufCodecs.BOOL.encode(buf, p.transformed());
                    ByteBufCodecs.FLOAT.encode(buf, p.energy());
                    ByteBufCodecs.VAR_INT.encode(buf, p.papers());
                    ByteBufCodecs.VAR_INT.encode(buf, p.dilationTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.tokamakTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.entangleTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.holeTicks());
                    ByteBufCodecs.BOOL.encode(buf, p.phase());
                    ByteBufCodecs.VAR_INT.encode(buf, p.lightState());
                    ByteBufCodecs.VAR_INT.encode(buf, p.lightTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.cooldowns().size());
                    for (int c : p.cooldowns()) {
                        ByteBufCodecs.VAR_INT.encode(buf, c);
                    }
                    ByteBufCodecs.BOOL.encode(buf, p.photon());
                    ByteBufCodecs.BOOL.encode(buf, p.cloak());
                    ByteBufCodecs.VAR_INT.encode(buf, p.wormholeTicks());
                    ByteBufCodecs.VAR_INT.encode(buf, p.clones());
                },
                buf -> {
                    boolean unlocked = ByteBufCodecs.BOOL.decode(buf);
                    boolean transformed = ByteBufCodecs.BOOL.decode(buf);
                    float energy = ByteBufCodecs.FLOAT.decode(buf);
                    int papers = ByteBufCodecs.VAR_INT.decode(buf);
                    int dilation = ByteBufCodecs.VAR_INT.decode(buf);
                    int tokamak = ByteBufCodecs.VAR_INT.decode(buf);
                    int entangle = ByteBufCodecs.VAR_INT.decode(buf);
                    int hole = ByteBufCodecs.VAR_INT.decode(buf);
                    boolean phase = ByteBufCodecs.BOOL.decode(buf);
                    int lightState = ByteBufCodecs.VAR_INT.decode(buf);
                    int lightTicks = ByteBufCodecs.VAR_INT.decode(buf);
                    int n = Math.min(ByteBufCodecs.VAR_INT.decode(buf), 64);
                    List<Integer> cooldowns = new ArrayList<>(n);
                    for (int i = 0; i < n; i++) {
                        cooldowns.add(ByteBufCodecs.VAR_INT.decode(buf));
                    }
                    boolean photon = ByteBufCodecs.BOOL.decode(buf);
                    boolean cloak = ByteBufCodecs.BOOL.decode(buf);
                    int worm = ByteBufCodecs.VAR_INT.decode(buf);
                    int clones = ByteBufCodecs.VAR_INT.decode(buf);
                    return new SyncPayload(unlocked, transformed, energy, papers, dilation, tokamak, entangle, hole, phase,
                            lightState, lightTicks, cooldowns, photon, cloak, worm, clones);
                });

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> pemain di sekitar: siapa yang sedang jadi RELATIVA (atom di dada) dan medan apa yang menyala. */
    public record StatePayload(int entityId, boolean transformed, int flags) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<StatePayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("relativa_state"));

        public static final StreamCodec<ByteBuf, StatePayload> STREAM_CODEC = StreamCodec.of(
                (buf, p) -> {
                    ByteBufCodecs.VAR_INT.encode(buf, p.entityId());
                    ByteBufCodecs.BOOL.encode(buf, p.transformed());
                    ByteBufCodecs.VAR_INT.encode(buf, p.flags());
                },
                buf -> new StatePayload(ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.BOOL.decode(buf),
                        ByteBufCodecs.VAR_INT.decode(buf)));

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** 0.67 Server -> SEMUA pemain: waktu dunia dihentikan RELATIVA (state 1) / berjalan lagi (0), walau RELATIVA-nya jauh. */
    public record WorldPayload(int ownerId, int state) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<WorldPayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("relativa_world"));

        public static final StreamCodec<ByteBuf, WorldPayload> STREAM_CODEC = StreamCodec.of(
                (buf, p) -> {
                    ByteBufCodecs.VAR_INT.encode(buf, p.ownerId());
                    ByteBufCodecs.VAR_INT.encode(buf, p.state());
                },
                buf -> new WorldPayload(ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.VAR_INT.decode(buf)));

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /**
     * 0.70 Client -> server: buka Jembatan Einstein-Rosen ke koordinat (x, y, z) di dimensi dim (layar koordinat / Shift+L
     * cepat ke titik yang dilihat), atau tutup yang sedang terbuka. mode = WORM_* (Y kosong = cari permukaan aman sendiri).
     */
    public record WormholeOpenPayload(String dim, double x, double y, double z, int mode) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<WormholeOpenPayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("relativa_wormhole_open"));

        public static final StreamCodec<ByteBuf, WormholeOpenPayload> STREAM_CODEC = StreamCodec.of(
                (buf, p) -> {
                    ByteBufCodecs.STRING_UTF8.encode(buf, p.dim());
                    ByteBufCodecs.DOUBLE.encode(buf, p.x());
                    ByteBufCodecs.DOUBLE.encode(buf, p.y());
                    ByteBufCodecs.DOUBLE.encode(buf, p.z());
                    ByteBufCodecs.VAR_INT.encode(buf, p.mode());
                },
                buf -> new WormholeOpenPayload(ByteBufCodecs.STRING_UTF8.decode(buf), ByteBufCodecs.DOUBLE.decode(buf),
                        ByteBufCodecs.DOUBLE.decode(buf), ByteBufCodecs.DOUBLE.decode(buf), ByteBufCodecs.VAR_INT.decode(buf)));

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /**
     * 0.70 Server -> pemain di dimensi satu mulut lubang cacing: mulut ke-side (0 / 1) milik lubang id terbuka / dilewati /
     * menutup di (x, y, z), sisi seberangnya di dimensi partner (warnanya), umurnya age dari life tick.
     */
    public record WormholePayload(int id, int side, int state, String partner, double x, double y, double z, float radius,
                                  int age, int life) implements CustomPacketPayload {
        public static final CustomPacketPayload.Type<WormholePayload> TYPE =
                new CustomPacketPayload.Type<>(ShazamMod.id("relativa_wormhole"));

        public static final StreamCodec<ByteBuf, WormholePayload> STREAM_CODEC = StreamCodec.of(
                (buf, p) -> {
                    ByteBufCodecs.VAR_INT.encode(buf, p.id());
                    ByteBufCodecs.VAR_INT.encode(buf, p.side());
                    ByteBufCodecs.VAR_INT.encode(buf, p.state());
                    ByteBufCodecs.STRING_UTF8.encode(buf, p.partner());
                    ByteBufCodecs.DOUBLE.encode(buf, p.x());
                    ByteBufCodecs.DOUBLE.encode(buf, p.y());
                    ByteBufCodecs.DOUBLE.encode(buf, p.z());
                    ByteBufCodecs.FLOAT.encode(buf, p.radius());
                    ByteBufCodecs.VAR_INT.encode(buf, p.age());
                    ByteBufCodecs.VAR_INT.encode(buf, p.life());
                },
                buf -> new WormholePayload(ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.VAR_INT.decode(buf),
                        ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.STRING_UTF8.decode(buf), ByteBufCodecs.DOUBLE.decode(buf),
                        ByteBufCodecs.DOUBLE.decode(buf), ByteBufCodecs.DOUBLE.decode(buf), ByteBufCodecs.FLOAT.decode(buf),
                        ByteBufCodecs.VAR_INT.decode(buf), ByteBufCodecs.VAR_INT.decode(buf)));

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("3");   // 0.67 / 0.70: isi SyncPayload bertambah
        registrar.playToServer(ActionPayload.TYPE, ActionPayload.STREAM_CODEC, RelativaNetwork::handleAction);
        registrar.playToClient(SyncPayload.TYPE, SyncPayload.STREAM_CODEC, RelativaNetwork::handleSync);
        registrar.playToClient(StatePayload.TYPE, StatePayload.STREAM_CODEC, RelativaNetwork::handleState);
        registrar.playToClient(WorldPayload.TYPE, WorldPayload.STREAM_CODEC, RelativaNetwork::handleWorld);
        registrar.playToServer(WormholeOpenPayload.TYPE, WormholeOpenPayload.STREAM_CODEC, RelativaNetwork::handleWormholeOpen);
        registrar.playToClient(WormholePayload.TYPE, WormholePayload.STREAM_CODEC, RelativaNetwork::handleWormhole);
    }

    private static void handleAction(ActionPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (!(context.player() instanceof ServerPlayer player)) {
                return;
            }
            switch (payload.action()) {
                case ACTION_TRANSFORM -> RelativaAbilities.toggleTransform(player);
                case ACTION_LIGHT -> RelativaLight.toggle(player, RelativaAbilities.data(player));
                case ACTION_PHASE -> RelativaPhase.toggle(player, RelativaAbilities.data(player));
                case ACTION_PHOTON -> RelativaPhoton.toggle(player, RelativaAbilities.data(player));
                default -> { }
            }
        });
    }

    private static void handleSync(SyncPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> RelativaClientState.update(payload));
    }

    private static void handleState(StatePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> RelativaClientState.onState(payload));
    }

    private static void handleWorld(WorldPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> RelativaClientState.onWorld(payload));
    }

    private static void handleWormholeOpen(WormholeOpenPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                RelativaWormhole.request(player, payload);
            }
        });
    }

    private static void handleWormhole(WormholePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> RelativaClientState.onWormhole(payload));
    }

    public static void sync(ServerPlayer player) {
        RelativaData d = RelativaAbilities.data(player);
        List<Integer> cooldowns = new ArrayList<>(RelativaData.SLOTS);
        for (int c : d.cooldowns) {
            cooldowns.add(c);
        }
        PacketDistributor.sendToPlayer(player, new SyncPayload(d.unlocked, d.transformed, d.energy, d.papers,
                d.dilationTicks, d.tokamakTicks, d.entangleTicks, d.holeTicks, d.phase && d.transformed, d.lightState,
                d.lightTicks, cooldowns, d.photon && d.transformed, d.cloak && d.transformed,
                RelativaWormhole.ticksLeft(player), RelativaClone.count(player)));
    }

    private static StatePayload state(ServerPlayer player) {
        RelativaData d = RelativaAbilities.data(player);
        int flags = (d.dilationTicks > 0 ? FLAG_DILATION : 0) | (d.tokamakTicks > 0 ? FLAG_TOKAMAK : 0)
                | (d.holeTicks > 0 ? FLAG_HOLE : 0) | (d.phase && d.transformed ? FLAG_PHASE : 0)
                | (d.lightState != RelativaLight.NONE ? FLAG_LIGHT : 0)
                | (d.photon && d.transformed ? FLAG_PHOTON : 0) | (RelativaCloak.hidden(player) ? FLAG_CLOAK : 0);
        return new StatePayload(player.getId(), d.transformed, flags);
    }

    /** Status RELATIVA pemain ini ke dirinya sendiri & semua yang melihatnya. */
    public static void broadcastState(ServerPlayer player) {
        PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, state(player));
    }

    /** 0.67 Waktu dunia berhenti / jalan lagi: semua pemain di server dikabari. */
    public static void broadcastWorld(int ownerId, int state) {
        PacketDistributor.sendToAllPlayers(new WorldPayload(ownerId, state));
    }

    public static void sendWorld(ServerPlayer player, int ownerId, int state) {
        PacketDistributor.sendToPlayer(player, new WorldPayload(ownerId, state));
    }

    /** Pemain baru melihat pemain ini (masuk jangkauan): kirim statusnya. */
    public static void sendStateTo(ServerPlayer relativa, ServerPlayer viewer) {
        PacketDistributor.sendToPlayer(viewer, state(relativa));
    }
}
