package com.shazammod.relativa;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamNetwork;
import com.shazammod.ShazamSounds;
import com.shazammod.thanos.ThanosSnap;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;

/**
 * 0.67 Pasif TEROWONGAN KUANTUM (tombol I, nyala / mati, tanpa batas waktu): seluruh atom badan RELATIVA berubah jadi
 * gelombang materi (panjang gelombang de Broglie λ = h/p). Peluang menembus penghalang nggak pernah nol, dan badan yang
 * "tersebar" jadi fungsi gelombang membiarkan segalanya lewat:
 *
 *   serangan apa pun (pukulan, ledakan, api, jatuh, sihir, sinar)   damage dibatalkan, tanpa dorongan / knockback
 *   proyektil (panah, trisula, bola api, ramuan, peluru rival)      menembus badan dan terus melaju (ProjectileImpactEvent)
 *   makhluk & pemain lain                                           menembus badan, nggak mendorongnya (noPhysics di sela tick)
 *   api, beku, tenggelam, efek buruk                                padam / dibuang tiap tick
 *   0.69 tembok, pintu, kaca, pagar, pohon, perahu, blok apa pun     jalan menembusnya (mixin Entity.collide -> tunnel)
 *        lantai & langit-langit                                     Shift + lihat ke bawah = tenggelam, lompat = naik
 *
 * Tembus blok: gerak mendatar yang ketahan blok / benda dibiarkan lewat, undakan rendah tetap dinaiki seperti biasa, lantai
 * tetap menahan (nggak jatuh ke void) kecuali sedang tenggelam. Bedrock, barrier, blok lain yang nggak bisa dihancurkan,
 * dan batas dunia tetap menahan. Di dalam blok: nggak sesak (damage-nya dibatalkan), nggak didorong keluar
 * (mixin LocalPlayer.moveTowardsClosestSpace), pose tetap berdiri (mixin Player.canPlayerFitWithinBlocksAndEntitiesWhen),
 * dan pandangan nggak tertutup tekstur blok. Server menerima posisinya karena noPhysics menyala di sela tick (paket gerak
 * diproses di situ); karena itu portal dicek sendiri (portals) supaya tetap bisa dipakai. Nggak bisa memadat di dalam blok;
 * kalau dipadatkan paksa (kembali jadi manusia / tumbang) di dalam blok, badan dipindah ke ruang kosong di atasnya.
 *
 * Tetap bisa menyerang, memakai skill, dan memungut barang. Yang tetap kena: /kill dan jatuh ke void (supaya nggak terjebak
 * selamanya); Jentikan Thanos sejak 0.68 nggak menyasar RELATIVA sama sekali (juara dewa, ThanosSnap.isGod). Padam
 * otomatis saat kembali jadi manusia.
 */
public final class RelativaPhase {
    private RelativaPhase() {}

    private static final int TOGGLE_GAP = 10;
    private static final int PASS_FX_GAP = 4;
    private static final Map<UUID, Long> LAST_PASS = new HashMap<>();
    /** 0.69 Kecepatan tenggelam / naik menembus lantai & langit-langit (blok per tick). */
    public static final double TUNNEL_SPEED = 0.32;
    /** 0.69 Diisi client tiap tick untuk pemain lokal (RelativaClient): Shift + lihat bawah / tombol lompat. */
    public static volatile boolean clientSink, clientRise;

    public static boolean phasing(Player p) {
        RelativaData d = RelativaAbilities.data(p);
        return d.transformed && d.phase;
    }

    /** 0.69 Sedang menembus, di server (data pemain) maupun di client (state yang disinkron). Dipakai mixin. */
    public static boolean tunnels(Player p) {
        if (p.isSpectator() || p.isPassenger()) {
            return false;
        }
        if (p.level().isClientSide()) {
            return p.isLocalPlayer() ? RelativaClientState.transformed && RelativaClientState.phase
                    : (RelativaClientState.flags(p.getId()) & RelativaNetwork.FLAG_PHASE) != 0;
        }
        return phasing(p);
    }

    // ---------------------------------------------------------------- tombol I

    public static void toggle(ServerPlayer p, RelativaData d) {
        if (!d.transformed || d.morphing > 0 || !p.isAlive()) {
            return;
        }
        long now = p.level().getGameTime();
        if (d.lastPhaseToggle != 0L && now >= d.lastPhaseToggle && now - d.lastPhaseToggle < TOGGLE_GAP) {
            return;
        }
        if (d.phase && inside(p)) {   // 0.69 memadat di dalam blok = terkubur: keluar dulu
            RelativaAbilities.msg(p, "phase_inside", ChatFormatting.RED);
            return;
        }
        d.lastPhaseToggle = now;
        d.phase = !d.phase;
        if (d.phase) {
            apply(p);
            ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_PHASE_ON);
            p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.RELATIVA_PHASE_ON.get(),
                    SoundSource.PLAYERS, 1.8f, 1f);
            RelativaAbilities.msg(p, "phase_on", ChatFormatting.LIGHT_PURPLE);
        } else {
            remove(p);
            ShazamNetwork.playAnim(p, ShazamAnim.RELATIVA_PHASE_OFF);
            p.serverLevel().playSound(null, p.getX(), p.getY(), p.getZ(), ShazamSounds.RELATIVA_PHASE_OFF.get(),
                    SoundSource.PLAYERS, 1.6f, 1f);
            RelativaAbilities.msg(p, "phase_off", ChatFormatting.GRAY);
        }
        RelativaNetwork.sync(p);
        RelativaNetwork.broadcastState(p);
    }

    /** Ledakan & pukulan nggak lagi mendorong badan (gelombang nggak punya titik untuk didorong). */
    static void apply(Player p) {
        AttributeModifier.Operation add = AttributeModifier.Operation.ADD_VALUE;
        RelativaPowers.set(p, Attributes.KNOCKBACK_RESISTANCE, "phase_knockback", 1.0, add);
        RelativaPowers.set(p, Attributes.EXPLOSION_KNOCKBACK_RESISTANCE, "phase_blast", 1.0, add);
    }

    static void remove(Player p) {
        RelativaPowers.clear(p, Attributes.KNOCKBACK_RESISTANCE, "phase_knockback");
        RelativaPowers.clear(p, Attributes.EXPLOSION_KNOCKBACK_RESISTANCE, "phase_blast");
    }

    /** Kembali jadi manusia / mati: pasifnya padam. */
    static void off(ServerPlayer p, RelativaData d) {
        if (d.phase) {
            d.phase = false;
            remove(p);
            if (inside(p)) {   // 0.69 dipadatkan paksa di dalam blok: pindah ke ruang kosong di atasnya
                eject(p);
            }
        }
        LAST_PASS.remove(p.getUUID());
    }

    // ---------------------------------------------------------------- tiap tick

    public static void tick(ServerPlayer p, RelativaData d) {
        if (!d.phase || !d.transformed) {
            return;
        }
        p.clearFire();
        p.setTicksFrozen(0);
        if (p.getAirSupply() < p.getMaxAirSupply()) {
            p.setAirSupply(p.getMaxAirSupply());
        }
        portals(p);
        if (p.tickCount % 5 == 0) {
            List<MobEffectInstance> bad = new ArrayList<>();
            for (MobEffectInstance effect : p.getActiveEffects()) {
                if (effect.getEffect().value().getCategory() == MobEffectCategory.HARMFUL) {
                    bad.add(effect);
                }
            }
            for (MobEffectInstance effect : bad) {
                p.removeEffect(effect.getEffect());
            }
        }
    }

    /**
     * Sesudah tick pemain (server & client): selama menembus noPhysics menyala sampai tick berikutnya, jadi makhluk nggak
     * mendorong badan, tekstur blok nggak menutupi pandangan, dan server menerima posisi di dalam blok (paket gerak diproses
     * di sela tick). Player.tick meresetnya ke isSpectator() sebelum bergerak, jadi gerak pemain sendiri tetap lewat
     * Entity.collide (lantai tetap menahan, lihat tunnel).
     */
    public static void afterTick(Player p, boolean phasing) {
        if (phasing && !p.isSpectator()) {
            p.noPhysics = true;
        }
    }

    // ---------------------------------------------------------------- 0.69 tembus blok

    /**
     * Dari mixin Entity.collide (hasil tabrakan biasa = collided): gerak mendatar yang ketahan blok / benda dibiarkan lewat
     * (undakan rendah tetap dinaiki, karena kalau undakannya bisa dinaiki geraknya nggak ketahan). Lantai & langit-langit
     * tetap menahan, kecuali pemain lokal sedang tenggelam (Shift + lihat bawah) atau naik (lompat). Blok yang nggak bisa
     * dihancurkan (bedrock, barrier, ...) dan batas dunia tetap menahan.
     */
    public static Vec3 tunnel(Player p, Vec3 wanted, Vec3 collided) {
        boolean local = p.level().isClientSide() && p.isLocalPlayer();
        double y = collided.y;
        if (local && p.getAbilities().flying && wanted.y != 0.0) {
            y = wanted.y;   // terbang (kreatif): naik / turun juga menembus
        } else if (local && clientSink && wanted.y < 0.0) {
            y = wanted.y;
        } else if (local && clientRise && wanted.y > 0.0) {
            y = wanted.y;
        }
        boolean blocked = Math.abs(collided.x - wanted.x) > 1.0E-7 || Math.abs(collided.z - wanted.z) > 1.0E-7;
        if (!blocked && y == collided.y) {
            return collided;
        }
        Vec3 out = blocked ? new Vec3(wanted.x, y, wanted.z) : new Vec3(collided.x, y, collided.z);
        AABB box = p.getBoundingBox().move(out);
        Level level = p.level();
        if (locked(level, box) || !level.getWorldBorder().isWithinBounds(BlockPos.containing(box.getCenter()))) {
            return collided;
        }
        return out;
    }

    /** Ada blok padat di dalam badan, atau dalam jarak above di atas kepala / below di bawah kaki. */
    public static boolean covered(Player p, double above, double below) {
        AABB box = p.getBoundingBox();
        AABB probe = new AABB(box.minX, box.minY - below, box.minZ, box.maxX, box.maxY + above, box.maxZ).deflate(1.0E-3);
        return p.level().getBlockCollisions(p, probe).iterator().hasNext();
    }

    /** Badan sedang berada di dalam blok padat. */
    public static boolean inside(Player p) {
        return covered(p, 0.0, 0.0);
    }

    /** Bedrock, barrier, bingkai portal End, blok perintah: semua yang nggak bisa dihancurkan nggak bisa ditembus. */
    private static boolean locked(Level level, AABB box) {
        BlockPos min = BlockPos.containing(box.minX + 1.0E-7, box.minY + 1.0E-7, box.minZ + 1.0E-7);
        BlockPos max = BlockPos.containing(box.maxX - 1.0E-7, box.maxY - 1.0E-7, box.maxZ - 1.0E-7);
        if (min.getY() < level.getMinBuildHeight()) {
            return true;   // jangan sampai tenggelam keluar dari dasar dunia
        }
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            BlockState state = level.getBlockState(pos);
            if (!state.isAir() && state.getDestroySpeed(level, pos) < 0f) {
                return true;
            }
        }
        return false;
    }

    /**
     * Selama menembus, gerak di server nggak mengecek blok di dalam badan (noPhysics), jadi portal dicek di sini supaya
     * portal Nether, portal End, dan gerbang End tetap bisa dipakai. Pelat tekan & tali jebakan sengaja nggak terinjak.
     */
    private static void portals(ServerPlayer p) {
        AABB box = p.getBoundingBox();
        BlockPos min = BlockPos.containing(box.minX + 1.0E-7, box.minY + 1.0E-7, box.minZ + 1.0E-7);
        BlockPos max = BlockPos.containing(box.maxX - 1.0E-7, box.maxY - 1.0E-7, box.maxZ - 1.0E-7);
        ServerLevel level = p.serverLevel();
        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            BlockState state = level.getBlockState(pos);
            if (state.is(Blocks.NETHER_PORTAL) || state.is(Blocks.END_PORTAL) || state.is(Blocks.END_GATEWAY)) {
                state.entityInside(level, pos, p);
                return;
            }
        }
    }

    /** Dipadatkan paksa di dalam blok: pindah ke tempat kosong terdekat lurus di atasnya (supaya nggak terkubur). */
    private static void eject(ServerPlayer p) {
        Level level = p.level();
        AABB box = p.getBoundingBox();
        for (double y = Math.floor(p.getY()); y <= level.getMaxBuildHeight(); y += 1.0) {
            if (level.noCollision(p, box.move(0.0, y - p.getY(), 0.0))) {
                p.teleportTo(p.getX(), y, p.getZ());
                p.resetFallDistance();
                return;
            }
        }
    }

    // ---------------------------------------------------------------- serangan & benda menembus

    /** Dari RelativaAbilities.guard. true = damage dibatalkan (menembus). */
    static boolean guard(LivingIncomingDamageEvent event, ServerPlayer p, RelativaData d) {
        DamageSource source = event.getSource();
        if (!d.transformed || !d.phase || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || ThanosSnap.isSnap(source)) {
            return false;
        }
        event.setCanceled(true);
        Entity from = source.getDirectEntity() != null ? source.getDirectEntity() : source.getEntity();
        if (from != null && from != p) {
            pass(p, from.position().add(0, from.getBbHeight() * 0.5, 0));
        } else if (source.getSourcePosition() != null) {
            pass(p, source.getSourcePosition());
        }
        return true;
    }

    /** Proyektil menembus badan dan terus melaju (tumbukannya diabaikan). */
    public static void onImpact(ProjectileImpactEvent event) {
        Projectile pr = event.getProjectile();
        if (pr.level().isClientSide() || !(event.getRayTraceResult() instanceof EntityHitResult hit)
                || !(hit.getEntity() instanceof ServerPlayer p) || !phasing(p)) {
            return;
        }
        event.setCanceled(true);
        pass(p, hit.getLocation());
    }

    /** Efek "lewat" di titik masuknya (paket gelombang menembus badan), dibatasi supaya nggak berisik. */
    private static void pass(ServerPlayer p, Vec3 from) {
        long now = p.level().getGameTime();
        Long last = LAST_PASS.get(p.getUUID());
        if (last != null && now >= last && now - last < PASS_FX_GAP) {
            return;
        }
        LAST_PASS.put(p.getUUID(), now);
        Vec3 c = RelativaAbilities.chest(p);
        Vec3 dir = from.subtract(c);
        Vec3 at = dir.lengthSqr() < 1.0E-4 ? c : c.add(dir.normalize().scale(0.45));
        ShazamNetwork.playAnim(p, ShazamAnim.PHYS_PHASE_PASS, at);
        p.serverLevel().playSound(null, at.x, at.y, at.z, ShazamSounds.RELATIVA_PHASE_PASS.get(), SoundSource.PLAYERS, 0.9f,
                0.9f + p.getRandom().nextFloat() * 0.25f);
    }
}
