package com.shazammod.relativa;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 0.66 Status RELATIVA di sisi client: data HUD pemain ini sendiri, dan siapa saja di sekitar yang sedang jadi RELATIVA
 * (buat atom di dada & medan-medannya). Cuma field biasa tanpa kelas client, jadi aman ikut termuat di server dedicated.
 */
public final class RelativaClientState {
    private RelativaClientState() {}

    public static boolean unlocked;
    public static boolean transformed;
    public static float energy = RelativaData.MAX_ENERGY;
    public static int papers;
    public static int dilationTicks;
    public static int tokamakTicks;
    public static int entangleTicks;
    public static int holeTicks;
    public static boolean phase;          // 0.67 pasif Terowongan Kuantum menyala
    public static int lightState;         // 0.67 Kecepatan Cahaya (RelativaLight.NONE / WINDUP / ACTIVE / RESUME)
    public static int lightTicks;
    public static boolean photon;         // 0.70 Foton Tanpa Massa (mode terbang)
    public static boolean cloak;          // 0.70 Cincin Einstein nyala
    public static int wormholeTicks;      // 0.70 sisa tick Jembatan Einstein-Rosen milik sendiri (0 = nggak ada)
    public static int clones;             // 0.70 salinan Kucing Schrödinger yang masih hidup
    /** 0.67 Waktu dunia sedang dihentikan RELATIVA (berlaku buat semua pemain, termasuk yang ikut membeku). */
    public static boolean worldStopped;
    public static int worldOwner = -1;
    private static List<Integer> cooldowns = List.of();

    /** Pemain yang sedang jadi RELATIVA (termasuk diri sendiri): id entity -> bendera medan (RelativaNetwork.FLAG_*). */
    private static final Map<Integer, Integer> OTHERS = new HashMap<>();
    /** 0.70 Kabar mulut lubang cacing dari server, diambil efek client tiap tick (RelativaFx). */
    private static final ArrayDeque<RelativaNetwork.WormholePayload> WORMHOLES = new ArrayDeque<>();

    public static void update(RelativaNetwork.SyncPayload p) {
        unlocked = p.unlocked();
        transformed = p.transformed();
        energy = p.energy();
        papers = p.papers();
        dilationTicks = p.dilationTicks();
        tokamakTicks = p.tokamakTicks();
        entangleTicks = p.entangleTicks();
        holeTicks = p.holeTicks();
        phase = p.phase();
        lightState = p.lightState();
        lightTicks = p.lightTicks();
        cooldowns = p.cooldowns();
        photon = p.photon();
        cloak = p.cloak();
        wormholeTicks = p.wormholeTicks();
        clones = p.clones();
    }

    public static void onWormhole(RelativaNetwork.WormholePayload p) {
        if (WORMHOLES.size() < 256) {
            WORMHOLES.add(p);
        }
    }

    public static RelativaNetwork.WormholePayload pollWormhole() {
        return WORMHOLES.poll();
    }

    /** 0.70 Boneka salinan Kucing Schrödinger digambar dengan atom & efek RELATIVA seperti pemain sungguhan. */
    public static void putPuppet(int id) {
        OTHERS.put(id, 0);
    }

    public static void removePuppet(int id) {
        OTHERS.remove(id);
    }

    public static void onWorld(RelativaNetwork.WorldPayload p) {
        worldStopped = p.state() != 0;
        worldOwner = p.ownerId();
    }

    public static void onState(RelativaNetwork.StatePayload p) {
        if (p.transformed()) {
            OTHERS.put(p.entityId(), p.flags());
        } else {
            OTHERS.remove(p.entityId());
        }
    }

    public static boolean isRelativa(int entityId) {
        return OTHERS.containsKey(entityId);
    }

    public static int flags(int entityId) {
        Integer f = OTHERS.get(entityId);
        return f == null ? 0 : f;
    }

    public static Map<Integer, Integer> all() {
        return OTHERS;
    }

    public static int cooldown(int slot) {
        return slot >= 0 && slot < cooldowns.size() ? cooldowns.get(slot) : 0;
    }

    public static void reset() {
        unlocked = false;
        transformed = false;
        energy = RelativaData.MAX_ENERGY;
        papers = 0;
        dilationTicks = 0;
        tokamakTicks = 0;
        entangleTicks = 0;
        holeTicks = 0;
        phase = false;
        lightState = 0;
        lightTicks = 0;
        photon = false;
        cloak = false;
        wormholeTicks = 0;
        clones = 0;
        WORMHOLES.clear();
        worldStopped = false;
        worldOwner = -1;
        cooldowns = List.of();
        OTHERS.clear();
    }
}
