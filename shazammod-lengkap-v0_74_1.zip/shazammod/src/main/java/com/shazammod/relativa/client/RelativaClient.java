package com.shazammod.relativa.client;

import org.lwjgl.glfw.GLFW;

import com.shazammod.ShazamMod;
import com.shazammod.client.RelativaClonePuppets;
import com.shazammod.client.fx.RelativaFx;
import com.shazammod.client.fx.RelativaLensShader;
import com.shazammod.relativa.RelativaClientState;
import com.shazammod.relativa.RelativaNetwork;
import com.shazammod.relativa.RelativaPhase;
import com.shazammod.relativa.RelativaRegistry;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 0.66 Khusus client: tombol Y (Wujud RELATIVA), 0.67 O (Kecepatan Cahaya) & I (Terowongan Kuantum), HUD, tick efek
 * RelativaFx, dan shader lensa gravitasi / optik relativistik. Tombol lain
 * (G Z X C V B N R M J) memakai tombol juara yang sudah ada di ShazamClient.
 *
 * 0.69 Terowongan Kuantum tembus blok: Shift + lihat ke bawah = tenggelam menembus lantai, lompat = naik menembus
 * langit-langit (RelativaPhase.tunnel), dan pandangan di dalam blok padat nggak hilang (smart culling dimatikan seperti
 * mode penonton).
 *
 * 0.70: L = layar koordinat Jembatan Einstein-Rosen (Shift+L = langsung ke titik yang dilihat), F = Foton Tanpa Massa
 * (terbang, RelativaPhotonFlight). Selama berwujud RELATIVA, L & F menggantikan menu Kemajuan & tukar tangan bawaan (kalau
 * tombolnya sama); sebagai manusia keduanya normal lagi. K & H (Kucing Schrödinger, Cincin Einstein) memakai tombol juara.
 * Pemain yang memakai Cincin Einstein nggak digambar sama sekali (cuma lensanya, RelativaFx), begitu juga salinan Kucing
 * Schrödinger yang sedang runtuh.
 */
public final class RelativaClient {
    private RelativaClient() {}

    public static final KeyMapping TRANSFORM = new KeyMapping("key.shazammod.relativa", GLFW.GLFW_KEY_Y,
            "key.categories.shazammod");
    /** 0.67 Kecepatan Cahaya: waktu dunia berhenti. */
    public static final KeyMapping LIGHT = new KeyMapping("key.shazammod.relativa_light", GLFW.GLFW_KEY_O,
            "key.categories.shazammod");
    /** 0.67 pasif Terowongan Kuantum nyala / mati. */
    public static final KeyMapping PHASE = new KeyMapping("key.shazammod.relativa_phase", GLFW.GLFW_KEY_I,
            "key.categories.shazammod");
    /** 0.70 Jembatan Einstein-Rosen: layar koordinat (Shift = langsung ke titik yang dilihat). */
    public static final KeyMapping WORMHOLE = new KeyMapping("key.shazammod.relativa_wormhole", GLFW.GLFW_KEY_L,
            "key.categories.shazammod");
    /** 0.70 Foton Tanpa Massa: terbang nyala / mati. */
    public static final KeyMapping PHOTON = new KeyMapping("key.shazammod.relativa_photon", GLFW.GLFW_KEY_F,
            "key.categories.shazammod");

    @EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModEvents {
        private ModEvents() {}

        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(TRANSFORM);
            event.register(LIGHT);
            event.register(PHASE);
            event.register(WORMHOLE);   // 0.70
            event.register(PHOTON);
        }

        /** 0.70 Salinan Kucing Schrödinger nggak digambar sendiri: bonekanya (RelativaClonePuppets) yang digambar. */
        @SubscribeEvent
        public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(RelativaRegistry.CLONE.get(), NoopRenderer::new);
        }

        @SubscribeEvent
        public static void registerHud(RegisterGuiLayersEvent event) {
            event.registerAbove(VanillaGuiLayers.HOTBAR, ShazamMod.id("relativa_hud"), RelativaHud::render);
        }
    }

    @EventBusSubscriber(modid = ShazamMod.MODID, value = Dist.CLIENT)
    public static final class GameEvents {
        private GameEvents() {}

        private static boolean cullOff, cullBefore = true;

        /**
         * 0.69 Sebelum pemain lokal bergerak: tenggelam (Shift + lihat lebih dari 50° ke bawah, ada blok di bawah kaki) atau
         * naik (tombol lompat, ada blok di dalam badan / di atas kepala) dengan kecepatan tetap, lalu RelativaPhase.tunnel
         * membiarkan lantai / langit-langitnya lewat.
         */
        @SubscribeEvent
        public static void onClientTickPre(ClientTickEvent.Pre event) {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p != null && RelativaClientState.transformed) {
                // 0.70 L & F milik RELATIVA: menu Kemajuan / tukar tangan bawaan di tombol yang sama nggak ikut jalan
                steal(WORMHOLE, mc.options.keyAdvancements);
                steal(PHOTON, mc.options.keySwapOffhand);
            }
            boolean tunnel = p != null && mc.level != null && !mc.isPaused() && RelativaPhase.tunnels(p)
                    && !p.getAbilities().flying;
            boolean sink = tunnel && mc.options.keyShift.isDown() && p.getXRot() > 50f && RelativaPhase.covered(p, 0.0, 0.3);
            boolean rise = tunnel && !sink && mc.options.keyJump.isDown() && RelativaPhase.covered(p, 0.6, 0.0);
            RelativaPhase.clientSink = sink;
            RelativaPhase.clientRise = rise;
            if (sink || rise) {
                Vec3 v = p.getDeltaMovement();
                p.setDeltaMovement(v.x, sink ? -RelativaPhase.TUNNEL_SPEED : RelativaPhase.TUNNEL_SPEED, v.z);
                p.resetFallDistance();
            }
            // mata di dalam blok padat: matikan smart culling (seperti mode penonton) supaya dunia di sekitar tetap terlihat
            boolean blind = tunnel && eyeInSolid(mc, p);
            if (blind != cullOff) {
                if (blind) {
                    cullBefore = mc.smartCull;
                    mc.smartCull = false;
                } else {
                    mc.smartCull = cullBefore;
                }
                cullOff = blind;
                mc.levelRenderer.needsUpdate();
            }
        }

        private static void steal(KeyMapping ours, KeyMapping vanilla) {
            if (ours.same(vanilla)) {
                while (vanilla.consumeClick()) {
                    // ditelan: tombolnya sedang dipakai RELATIVA
                }
            }
        }

        private static boolean eyeInSolid(Minecraft mc, LocalPlayer p) {
            BlockPos eye = BlockPos.containing(p.getEyePosition());
            return mc.level.getBlockState(eye).isSolidRender(mc.level, eye);
        }

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) {
                return;
            }
            while (TRANSFORM.consumeClick()) {
                PacketDistributor.sendToServer(new RelativaNetwork.ActionPayload(RelativaNetwork.ACTION_TRANSFORM));
            }
            while (LIGHT.consumeClick()) {
                if (RelativaClientState.transformed) {
                    PacketDistributor.sendToServer(new RelativaNetwork.ActionPayload(RelativaNetwork.ACTION_LIGHT));
                }
            }
            while (PHASE.consumeClick()) {
                if (RelativaClientState.transformed) {
                    PacketDistributor.sendToServer(new RelativaNetwork.ActionPayload(RelativaNetwork.ACTION_PHASE));
                }
            }
            while (WORMHOLE.consumeClick()) {   // 0.70 Jembatan Einstein-Rosen
                if (RelativaClientState.transformed && mc.screen == null) {
                    if (mc.options.keyShift.isDown()) {
                        PacketDistributor.sendToServer(new RelativaNetwork.WormholeOpenPayload("", 0, 0, 0,
                                RelativaNetwork.WORM_QUICK));
                    } else {
                        mc.setScreen(new RelativaWormholeScreen());
                    }
                }
            }
            while (PHOTON.consumeClick()) {     // 0.70 Foton Tanpa Massa
                if (RelativaClientState.transformed) {
                    PacketDistributor.sendToServer(new RelativaNetwork.ActionPayload(RelativaNetwork.ACTION_PHOTON));
                }
            }
            RelativaNetwork.WormholePayload worm;
            while ((worm = RelativaClientState.pollWormhole()) != null) {
                RelativaFx.wormhole(mc.level, worm);   // 0.70 mulut lubang cacing terbuka / dilewati / menutup
            }
            if (!mc.isPaused()) {
                RelativaFx.tick(mc.level);   // atom di dada, kisi ruang-waktu, medan-medan yang menempel di badan
            }
        }

        /**
         * Lensa gravitasi lubang hitam, optik relativistik (Lesat Cahaya & Kecepatan Cahaya), waktu beku, kilau Terowongan
         * Kuantum: paling akhir, sesudah semua yang digambar di dunia.
         */
        @SubscribeEvent(priority = EventPriority.LOWEST)
        public static void onRenderLevelLast(RenderLevelStageEvent event) {
            RelativaLensShader.render(event);
        }

        /** 0.68 Darah 1024 nggak muat di baris hati: selama berwujud RELATIVA diganti bar darah (RelativaHud), sama seperti juara. */
        @SubscribeEvent
        public static void onGuiLayer(RenderGuiLayerEvent.Pre event) {
            if (RelativaClientState.transformed && event.getName().equals(VanillaGuiLayers.PLAYER_HEALTH)) {
                event.setCanceled(true);
            }
        }

        /** 0.70 Terbang Foton Tanpa Massa: kecepatan diatur sebelum pemain bergerak. */
        @SubscribeEvent
        public static void onPlayerTickPre(PlayerTickEvent.Pre event) {
            if (event.getEntity() instanceof LocalPlayer player) {
                RelativaPhotonFlight.preTick(player);
            }
        }

        /**
         * 0.70 Cincin Einstein: badan, baju zirah, barang di tangan & papan nama pemain lain yang tak terlihat nggak digambar
         * (yang terlihat cuma lensanya). Salinan Kucing Schrödinger yang sedang runtuh juga.
         */
        @SubscribeEvent(priority = EventPriority.HIGHEST)
        public static void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
            Player player = event.getEntity();
            Minecraft mc = Minecraft.getInstance();
            if (player != mc.player && (RelativaClientState.flags(player.getId()) & RelativaNetwork.FLAG_CLOAK) != 0) {
                event.setCanceled(true);
            } else if (player instanceof RelativaClonePuppets.Puppet puppet && puppet.hidden()) {
                event.setCanceled(true);
            }
        }

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
            RelativaPhotonFlight.reset(Minecraft.getInstance().player);   // 0.70
            RelativaClonePuppets.clear();
            RelativaClientState.reset();
            RelativaFx.clear();
            RelativaLensShader.close();
            RelativaPhase.clientSink = false;
            RelativaPhase.clientRise = false;
            if (cullOff) {   // 0.69 kembalikan smart culling kalau keluar saat masih di dalam blok
                cullOff = false;
                Minecraft.getInstance().smartCull = cullBefore;
            }
        }
    }
}
