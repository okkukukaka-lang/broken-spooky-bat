package com.shazammod;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * 0.72 Pengaturan sisi client (config/shazammod-client.toml, juga bisa diubah dari menu Mods -> Shazam -> Config):
 * SHADER SHAZAM, efek layar untuk semua skill mod ini (lihat client/fx/ShazamShaders). Semuanya otomatis mati kalau
 * shader pack Iris/Oculus sedang dipakai.
 */
public final class ShazamClientConfig {
    private static final String KEY = "shazammod.configuration.";

    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.BooleanValue SHADERS;
    public static final ModConfigSpec.DoubleValue BLOOM;
    public static final ModConfigSpec.DoubleValue GOD_RAYS;
    public static final ModConfigSpec.BooleanValue DISTORTION;
    public static final ModConfigSpec.BooleanValue HEAT_HAZE;
    public static final ModConfigSpec.BooleanValue IMPACT;
    public static final ModConfigSpec.EnumValue<Quality> QUALITY;

    /** Resolusi & jumlah tingkat bloom. */
    public enum Quality {
        LOW, MEDIUM, HIGH
    }

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        b.comment("Shader Shazam: efek layar untuk semua skill mod ini (bloom, sinar dewa, pembiasan, hantaman).",
                "Otomatis mati kalau shader pack Iris/Oculus sedang dipakai.").translation(KEY + "shaders").push("shaders");
        SHADERS = b.comment("Nyalakan Shader Shazam (bisa juga lewat tombol \"Shader Shazam\" di pengaturan kontrol).")
                .translation(KEY + "enabled").define("enabled", true);
        BLOOM = b.comment("Kuat pendar (bloom) semua efek cahaya skill. 0 = mati, 1 = normal, 2 = sangat berpendar.")
                .translation(KEY + "bloom").defineInRange("bloom", 1.0, 0.0, 2.0);
        GOD_RAYS = b.comment("Kuat sinar dewa (berkas cahaya) dari ledakan, bola api, & sambaran petir. 0 = mati.")
                .translation(KEY + "godRays").defineInRange("godRays", 1.0, 0.0, 2.0);
        DISTORTION = b.comment("Gelombang tekanan ledakan membengkokkan gambar di belakangnya (pembiasan).")
                .translation(KEY + "distortion").define("distortion", true);
        HEAT_HAZE = b.comment("Udara panas di atas bola api & plasma beriak.")
                .translation(KEY + "heatHaze").define("heatHaze", true);
        IMPACT = b.comment("Hantaman besar: zoom kabur, pecahan warna, & vinyet sesaat.")
                .translation(KEY + "impact").define("impact", true);
        QUALITY = b.comment("Kualitas bloom: LOW (paling ringan), MEDIUM, HIGH (paling halus & lebar).")
                .translation(KEY + "quality").defineEnum("quality", Quality.HIGH);
        b.pop();
        SPEC = b.build();
    }

    private ShazamClientConfig() {}
}
