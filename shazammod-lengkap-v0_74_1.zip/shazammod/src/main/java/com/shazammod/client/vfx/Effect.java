package com.shazammod.client.vfx;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;

/** Satu efek visual yang hidup beberapa tick. Turunannya cukup menggambar lapisan yang dibutuhkan. */
public abstract class Effect {
    protected int age;
    protected final int life;
    /** 0.33: penguat sinematik yang aktif saat efek ini dibuat (Lintang & Sabbac 1.5, juara lain 1 = biasa). */
    public final float boost = Vfx.boost();

    protected Effect(int life) {
        this.life = Math.max(1, life);
    }

    /** Dipanggil tiap tick client. false = efek selesai dan dibuang. */
    public boolean tick(ClientLevel level) {
        return ++age < life;
    }

    /** 0..1 sepanjang umur efek (dengan interpolasi antar-tick). */
    protected float progress(float partialTick) {
        return Math.min(1f, (age + partialTick) / life);
    }

    protected float time(float partialTick) {
        return age + partialTick;
    }

    /** Benda padat (pecahan blok), digambar paling dulu. */
    public void renderSolid(PoseStack poseStack, MultiBufferSource buffers, double camX, double camY, double camZ,
                            float partialTick) {
    }

    /** Lapisan tembus pandang lembut (debu, bekas hangus, retakan gelap). */
    public void renderSoft(Draw draw) {
    }

    /** Lapisan cahaya (aditif). */
    public void renderGlow(Draw draw) {
    }

    /**
     * 0.72 Shader Shazam: daftarkan sumber untuk shader layar di frame ini (ShazamShaders.light / bubble / ring / heat),
     * misalnya kilatan = sumber sinar dewa, gelombang kejut = pembiasan. Cuma dipanggil kalau shader-nya menyala.
     */
    public void shade(float partialTick) {
    }
}
