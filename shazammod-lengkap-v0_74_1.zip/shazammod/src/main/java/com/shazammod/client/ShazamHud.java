package com.shazammod.client;

import com.mojang.math.Axis;
import com.shazammod.AksaraSkills;
import com.shazammod.LintangSkills;
import com.shazammod.HelionSkills;
import com.shazammod.Helion3Skills;
import com.shazammod.PassiveConditions;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamFavor;
import com.shazammod.ShazamPowers;
import com.shazammod.client.flight.MercuryMode;
import com.shazammod.client.fx.AdamFx;
import com.shazammod.client.fx.AksaraFx;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;

/**
 * HUD Shazam / Black Adam: Energi Petir, juara yang dipilih, dan skill di kiri atas; bar darah di atas hotbar saat
 * berubah wujud. Warna mengikuti juara (emas Shazam / emas membara Black Adam).
 */
public final class ShazamHud {
    private ShazamHud() {}

    private static final int X = 6;
    private static final int Y = 6;
    private static final int BAR_WIDTH = 130;
    private static final String LETTERS = "SHAZAM\u26A1";   // kotak terakhir: Zeus Rage
    private static final String ADAM_LETTERS = "SHAZAM\u2625"; // Black Adam: Shu Heru Amon Zehuti Aton Mehen + ankh (Murka Kahndaq)
    private static final int ADAM_GOLD = 0xFFFFB13D;           // emas membara
    private static final int ADAM_BAR = 0xFFE89A2C;
    private static final int ADAM_SHADE = 0xB0140A06;          // kotak gelap kecokelatan, seperti batu Kahndaq
    private static final int MEHEN_ON = 0xFF5FE6CF;            // lilitan Mehen aktif: pirus
    private static final int MEHEN_BG = 0xB0102A26;
    private static final int GOLD = 0xFFFFD34D;
    private static final int GRAY = 0xFF9E9E9E;
    private static final int STORM_BLUE = 0xFF55FFFF;
    private static final int SHADE = 0xA0000000;
    private static final int MERCURY_ON = 0xFF86F0FF;
    private static final int MERCURY_BG = 0xA0103848;
    private static final int MERCURY_RUN = 0xFFFFE28A;   // auto-hit dimatikan: cuma lari
    private static final int RECOVERING = 0xFFFF7A6B;    // habis terlempar balik jadi manusia: belum bisa SHAZAM
    private static final int SUN_GOLD = 0xFFFFC94A;      // Berkah Aton (Black Adam di bawah matahari)
    private static final int CHARGE_FILL = 0xB0B88A1E;   // Muatan Petir terisi
    private static final int CHARGE_FULL = 0xFFFFD34D;   // penuh: Pukulan Guntur siap
    private static final int CHARGE_FLASH = 0xFFFFF6C8;
    private static final int FAMILY_BG = 0xB0402A08;     // 0.26 Kekuatan Keluarga siap
    private static final String CALL_LETTER = "\u03DF";  // Panggil Petir Kahndaq (tombol M Black Adam): petir
    private static final String HAND_LETTER = "\u270B";  // 0.27 Tangan Kahndaq (tombol J Black Adam): telapak terbuka
    private static final String BLOCK_LETTER = "\u26E8"; // 0.28 Tangkisan Kahndaq (Black Adam): perisai
    // ======= 0.30 Sabbac: enam iblis S-A-B-B-A-C, warna api neraka =======
    private static final String SABBAC_LETTERS = "SABBAC\u2620"; // Setan Aym Belial Beelzebub Asmodeus Crateis + Gerbang Neraka
    private static final int SABBAC_RED = 0xFFFF6A3A;          // huruf & judul: merah bara
    private static final int SABBAC_BAR = 0xFFD8341A;
    private static final int SABBAC_SHADE = 0xB0220806;        // kotak gelap kemerahan, seperti batu neraka
    private static final int SABBAC_READY = 0xC0380A04;
    private static final String HELL_CALL_LETTER = "\u03DF";  // Panggil Petir Neraka (M)
    private static final String LEGION_LETTER = "\u2694";     // Pasukan Iblis (J)
    private static final String HELL_CHARGE_LETTER = "\u2739"; // Muatan Neraka (penuh = Tinju Neraka)
    private static final String ENGULF_LETTER = "\u2668";     // Kulit Bara
    // ======= 0.31 Restu Para Dewa (scaling Shazam) =======
    private static final int FAVOR_FILL = 0xFFC9A93A;          // restu naik, masih di bawah angka mentah Black Adam
    private static final int FAVOR_ABOVE = 0xFFFFE066;         // sudah melampaui Black Adam
    private static final int FAVOR_FULL = 0xFFFFFFFF;          // penuh: berkedip putih <-> kuning
    private static final int FAVOR_TEXT = 0xFFE8D8A0;
    private static final int FAVOR_TEXT_ABOVE = 0xFFFFF2B0;
    // ======= 0.32 Lintang: L-I-N-T-A-N-G, cahaya putih keemasan di atas biru toska tua =======
    private static final String LINTANG_LETTERS = "LINTANG";
    private static final int LINTANG_GOLD = 0xFFFFE6A0;
    private static final int LINTANG_BAR = 0xFFFFD45E;
    private static final int LINTANG_TEAL = 0xFF5FE0D2;
    private static final int LINTANG_SHADE = 0xB0082A2E;
    private static final int LINTANG_READY = 0xC0124A50;
    private static final int STARLIGHT_BLUE = 0xFFBFE4FF;
    private static final int KELAM_VIOLET = 0xFFC08AF0;

    public static void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null) {
            return;
        }
        if (AksaraFx.worldStopped()) {   // 0.56 Henti Waktu Dunia PRALAYA: semua pemain melihatnya
            renderWorldStop(graphics, mc);
        }
        if (!ShazamClientState.unlocked) {   // 0.55 belum punya juara tapi membawa inti: baris inti tetap tampil
            renderHumanCores(graphics, mc, Y);
            return;
        }
        if (ShazamClientState.transformed) {
            renderHealth(graphics, mc, mc.player);
        }
        renderEnergy(graphics, mc);
        if (!ShazamClientState.transformed) {   // 0.55 inti PRALAYA yang dibawa tanpa armor (tombol Z-N)
            boolean energyShown = ShazamClientState.energy < ShazamPowers.MAX_ENERGY || ShazamClientState.recovery() > 0;
            int y = energyShown ? Y + 32 : Y;
            y = renderHumanCores(graphics, mc, y);
            renderSignalIfHolding(graphics, mc, y);
        }
        if (LintangCharge.active()) {
            renderIrisCharge(graphics, mc, deltaTracker.getGameTimeDeltaPartialTick(true));
        }
    }

    /**
     * 0.44 meteran charge sinar mata gaya video: cincin di bawah bidikan yang terisi searah jarum jam dari atas (merah ->
     * jingga -> putih keemasan) dengan persennya di tengah; saat penuh cincinnya berpendar dan tulisannya berkedip "MAKS".
     */
    private static void renderIrisCharge(GuiGraphics graphics, Minecraft mc, float partialTick) {
        float k = LintangCharge.level(partialTick);
        float cx = graphics.guiWidth() / 2f, cy = graphics.guiHeight() / 2f + 30f;
        float rOut = 11f, rIn = 8.4f;
        int segs = 60;
        for (int i = 0; i < segs; i++) {   // alur cincin gelap
            ringSegment(graphics, cx, cy, i, segs, rIn - 0.7f, rOut + 0.7f, 0xB0180604);
        }
        int lit = Math.min(segs, (int) Math.floor(segs * k + 0.0001f));
        for (int i = 0; i < lit; i++) {
            float u = (i + 0.5f) / segs;
            int c = u < 0.5f ? mixArgb(0xFFFF3A18, 0xFFFF9A40, u / 0.5f) : mixArgb(0xFFFF9A40, 0xFFFFF4D8, (u - 0.5f) / 0.5f);
            ringSegment(graphics, cx, cy, i, segs, rIn, rOut, c);
        }
        if (lit > 0 && lit < segs) {   // kepala isian: titik terang yang berdenyut
            int glow = (int) (150 + 105 * Mth.sin((mc.player.tickCount + partialTick) * 0.9f)) << 24 | 0xFFF8E8;
            ringSegment(graphics, cx, cy, lit - 1, segs, rIn - 0.4f, rOut + 0.4f, glow);
        }
        boolean full = k >= 1f;
        if (full) {   // penuh: cincin luar berpendar putih keemasan
            int a = (int) (90 + 60 * Mth.sin((mc.player.tickCount + partialTick) * 0.6f));
            for (int i = 0; i < segs; i++) {
                ringSegment(graphics, cx, cy, i, segs, rOut + 0.8f, rOut + 2.2f, (a << 24) | 0xFFE6B0);
            }
        }
        String text = full ? "MAKS" : Math.round(k * 100f) + "%";
        int color = full ? ((mc.player.tickCount / 4) % 2 == 0 ? 0xFFFFF4D8 : 0xFFFFB060) : 0xFFFFEBD0;
        graphics.pose().pushPose();
        graphics.pose().translate(cx, cy, 0f);
        float sc = full ? 0.6f : 0.68f;
        graphics.pose().scale(sc, sc, 1f);
        graphics.drawCenteredString(mc.font, text, 0, -mc.font.lineHeight / 2 + 1, color);
        graphics.pose().popPose();
    }

    /** Satu ruas cincin (i dari segs, mulai dari atas searah jarum jam) antara jari-jari r0 & r1. */
    private static void ringSegment(GuiGraphics g, float cx, float cy, int i, int segs, float r0, float r1, int argb) {
        float ang = (i + 0.5f) / segs * 360f;
        float hw = (float) (Math.PI * r1 / segs) + 0.3f, hh = (r1 - r0) / 2f;
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0f);
        g.pose().mulPose(Axis.ZP.rotationDegrees(ang));
        g.pose().translate(0f, -(r0 + r1) / 2f, 0f);
        g.pose().scale(hw, hh, 1f);
        g.fill(-1, -1, 1, 1, argb);
        g.pose().popPose();
    }

    private static int mixArgb(int a, int b, float t) {
        t = Mth.clamp(t, 0f, 1f);
        int aa = (a >>> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int ba = (b >>> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8)
                | (int) (ab + (bb - ab) * t);
    }

    /** Pengganti baris hati: 100 darah nggak muat dalam hati biasa. */
    private static void renderHealth(GuiGraphics graphics, Minecraft mc, LocalPlayer player) {
        if (mc.gameMode == null || !mc.gameMode.canHurtPlayer()) {
            return;
        }
        int x = graphics.guiWidth() / 2 - 91;
        int y = graphics.guiHeight() - 39;
        int width = 81;
        int height = 9;
        float health = player.getHealth();
        float max = Math.max(1f, player.getMaxHealth());
        float absorption = player.getAbsorptionAmount();
        graphics.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xFF6B4E12);
        graphics.fill(x, y, x + width, y + height, 0xFF1A0E0E);
        int filled = Math.round(Mth.clamp(health / max, 0f, 1f) * width);
        graphics.fill(x, y, x + filled, y + height, 0xFFC62828);
        graphics.fill(x, y, x + filled, y + 3, 0xFFE57373);
        if (absorption > 0f) {
            // 0.25: Perisai Petir (hati emas dari Penangkal Petir Hidup) diukur terhadap perisai penuh (20), bukan darah 300,
            // jadi kelihatan jelas habis kena serangan lalu terisi lagi tiap petir menyambar (baris armor vanila di atasnya
            // nggak ketutup)
            int extra = Math.round(Mth.clamp(absorption / Math.max(20f, absorption), 0f, 1f) * width);
            graphics.fill(x, y + height - 3, x + extra, y + height, GOLD);
        }
        String text = "\u2764 " + Math.round(health) + " / " + Math.round(max)
                + (absorption > 0f ? " +" + Math.round(absorption) : "");
        graphics.pose().pushPose();
        graphics.pose().translate(x + width / 2f, y + 2f, 0f);
        graphics.pose().scale(0.7f, 0.7f, 1f);
        graphics.drawCenteredString(mc.font, text, 0, 0, 0xFFFFFFFF);
        graphics.pose().popPose();
    }

    private static void renderEnergy(GuiGraphics graphics, Minecraft mc) {
        boolean transformed = ShazamClientState.transformed;
        float energy = ShazamClientState.energy;
        int recovery = transformed ? 0 : ShazamClientState.recovery();
        if (!transformed && energy >= ShazamPowers.MAX_ENERGY && recovery <= 0) {
            return; // wujud manusia, energi penuh, dan nggak sedang pulih: disembunyikan
        }
        Font font = mc.font;
        if (ShazamClientState.isSabbac()) {
            renderSabbac(graphics, mc, font, transformed, energy, recovery);
            return;
        }
        if (ShazamClientState.isLintang()) {
            renderLintang(graphics, mc, font, transformed, energy, recovery);
            return;
        }
        if (ShazamClientState.isHelion()) {
            renderHelion(graphics, mc, font, transformed, energy, recovery);
            return;
        }
        if (ShazamClientState.isHelion3()) {   // 0.49
            renderHelion3(graphics, mc, font, transformed, energy, recovery);
            return;
        }
        if (ShazamClientState.isAksara()) {    // 0.50
            renderAksara(graphics, mc, font, transformed, energy, recovery);
            return;
        }
        boolean adam = ShazamClientState.isAdam();
        int color = transformed ? (adam ? ADAM_GOLD : GOLD) : GRAY;

        Component title = Component.literal("\u26A1 ")
                .append(Component.translatable("hud.shazammod.energy"))
                .append(" " + Math.round(energy) + "/" + Math.round(ShazamPowers.MAX_ENERGY));
        graphics.drawString(font, title, X, Y, color, true);
        // juara yang dipilih, kecil di samping judul
        Component champion = Component.translatable(adam ? "champion.shazammod.black_adam" : "champion.shazammod.shazam");
        int titleWidth = font.width(title);
        graphics.pose().pushPose();
        graphics.pose().translate(X + titleWidth + 6, Y + 1.5f, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, champion, 0, 0, adam ? 0xFFE0A050 : 0xFFE8D8A0, true);
        graphics.pose().popPose();

        int barY = Y + 12;
        graphics.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + 5, adam ? ADAM_SHADE : SHADE);
        int filled = Math.round(energy / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(X, barY, X + filled, barY + 4, transformed && adam ? ADAM_BAR : color);
        if (adam ? ShazamClientState.sun : ShazamClientState.storm) {   // Shazam: badai petir. Black Adam: matahari Kahndaq.
            graphics.drawString(font, Component.translatable(adam ? "hud.shazammod.sun" : "hud.shazammod.storm"),
                    X + BAR_WIDTH + 6, barY - 2, adam ? SUN_GOLD : STORM_BLUE, true);
        }
        if (!transformed) {
            if (recovery > 0) {   // habis kena serangan mematikan: sisa waktu sampai bisa SHAZAM lagi
                graphics.drawString(font, Component.translatable("hud.shazammod.recovering", (recovery + 19) / 20),
                        X, barY + 9, RECOVERING, true);
            }
            return;
        }

        // Kotak skill S-H-A-Z-A-M dan amarah: huruf dewa di atas, tombol (atau sisa detik cooldown) di bawah.
        // Black Adam: huruf yang sama, dewa yang beda (Shu, Heru, Amon, Zehuti, Aton, Mehen) + ankh untuk Murka Kahndaq.
        int boxY = barY + 9;
        boolean mercury = !adam && mc.player != null && ShazamClientState.isMercury(mc.player.getId());
        boolean mehen = adam && mc.player != null && AdamFx.mehenStrength(mc.player, 0f) > 0.05f;
        String letters = adam ? ADAM_LETTERS : LETTERS;
        int letterGold = adam ? ADAM_GOLD : GOLD;
        for (int i = 0; i < ShazamClient.SKILL_KEYS.length; i++) {
            int boxX = X + i * 22;
            int cooldown = ShazamClientState.cooldown(i);
            boolean ready = cooldown <= 0;
            boolean on = i == 5 && mercury;   // M: Mode Kilat menyala
            boolean coiled = i == 5 && mehen; // M: ular Mehen sedang melilit
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, on ? MERCURY_BG : coiled ? MEHEN_BG : adam ? ADAM_SHADE : SHADE);
            graphics.drawCenteredString(font, String.valueOf(letters.charAt(i)), boxX + 10, boxY + 2,
                    on ? MERCURY_ON : coiled ? MEHEN_ON : (ready ? letterGold : GRAY));
            String sub;
            int subColor = ready ? 0xFFFFFFFF : GRAY;
            if (on) {
                boolean auto = MercuryMode.isAuto();
                sub = Component.translatable(auto ? "hud.shazammod.mercury_auto" : "hud.shazammod.mercury_run").getString();
                subColor = auto ? 0xFFFFFFFF : MERCURY_RUN;
            } else if (ready) {
                sub = ShazamClient.SKILL_KEYS[i].getTranslatedKeyMessage().getString();
                if (sub.length() > 4) {
                    sub = sub.substring(0, 4);
                }
            } else {
                sub = (cooldown + 19) / 20 + "s";
            }
            graphics.pose().pushPose();
            graphics.pose().translate(boxX + 10, boxY + 13, 0);
            graphics.pose().scale(0.7f, 0.7f, 1f);
            graphics.drawCenteredString(font, sub, 0, 0, subColor);
            graphics.pose().popPose();
        }
        if (!adam) {   // Shazam: kotak Muatan Petir & Refleks Mercury, sedikit terpisah
            renderPassives(graphics, font, X + ShazamClient.SKILL_KEYS.length * 22 + 4, boxY);
            renderFavor(graphics, mc, font, boxY + 25);   // 0.31 Restu Para Dewa, di bawah kotak skill
        }
        if (adam) {   // kotak ke-8: Panggil Petir Kahndaq (tombol M), sedikit terpisah
            int boxX = X + ShazamClient.SKILL_KEYS.length * 22 + 4;
            int cooldown = ShazamClientState.callCooldown();
            boolean ready = cooldown <= 0;
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, ready ? 0xC0301206 : ADAM_SHADE);
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY, ready ? ADAM_BAR : 0xFF5A3A1A);
            graphics.drawCenteredString(font, CALL_LETTER, boxX + 10, boxY + 2, ready ? ADAM_GOLD : GRAY);
            String sub = ready ? ShazamClient.MERCURY_AUTO.getTranslatedKeyMessage().getString() : (cooldown + 19) / 20 + "s";
            if (sub.length() > 4) {
                sub = sub.substring(0, 4);
            }
            graphics.pose().pushPose();
            graphics.pose().translate(boxX + 10, boxY + 13, 0);
            graphics.pose().scale(0.7f, 0.7f, 1f);
            graphics.drawCenteredString(font, sub, 0, 0, ready ? 0xFFFFFFFF : GRAY);
            graphics.pose().popPose();
            // 0.27 kotak ke-9: Tangan Kahndaq (tombol J) - jumlah proyektil yang sedang melayang tertahan
            int handX = boxX + 22;
            int held = ShazamClientState.heldCount();
            boolean any = held > 0;
            graphics.fill(handX - 1, boxY - 1, handX + 20, boxY + 21, any ? 0xC0301206 : ADAM_SHADE);
            if (any) {
                graphics.fill(handX - 1, boxY - 1, handX + 20, boxY, ADAM_BAR);
            }
            graphics.drawCenteredString(font, HAND_LETTER, handX + 10, boxY + 2, any ? ADAM_GOLD : GRAY);
            String handSub = any ? "x" + held : ShazamClient.FAMILY.getTranslatedKeyMessage().getString();
            if (handSub.length() > 4) {
                handSub = handSub.substring(0, 4);
            }
            small(graphics, font, handSub, handX + 10, boxY + 13, any ? 0xFFFFFFFF : GRAY);
            // 0.28 kotak ke-10 & ke-11: Muatan Petir (Tinju Kahndaq) & Tangkisan Kahndaq, padanan pasif Shazam
            renderAdamPassives(graphics, font, handX + 22, boxY);
        }
    }

    /** 0.30 HUD Sabbac: energi, enam iblis + Gerbang Neraka, Petir Neraka (M), Pasukan Iblis (J), dan dua pasif. */
    private static void renderSabbac(GuiGraphics graphics, Minecraft mc, Font font, boolean transformed, float energy,
                                     int recovery) {
        int color = transformed ? SABBAC_RED : GRAY;
        Component title = Component.literal("\u2668 ")
                .append(Component.translatable("hud.shazammod.energy_sabbac"))
                .append(" " + Math.round(energy) + "/" + Math.round(ShazamPowers.MAX_ENERGY));
        graphics.drawString(font, title, X, Y, color, true);
        int titleWidth = font.width(title);
        graphics.pose().pushPose();
        graphics.pose().translate(X + titleWidth + 6, Y + 1.5f, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, Component.translatable("champion.shazammod.sabbac"), 0, 0, 0xFFE0705A, true);
        graphics.pose().popPose();

        int barY = Y + 12;
        graphics.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + 5, SABBAC_SHADE);
        int filled = Math.round(energy / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(X, barY, X + filled, barY + 4, transformed ? SABBAC_BAR : color);
        if (ShazamClientState.dark) {   // kegelapan neraka: Muatan Neraka 2x, energi terisi
            graphics.drawString(font, Component.translatable("hud.shazammod.dark"), X + BAR_WIDTH + 6, barY - 2, SABBAC_RED, true);
        }
        if (!transformed) {
            if (recovery > 0) {
                graphics.drawString(font, Component.translatable("hud.shazammod.recovering_sabbac", (recovery + 19) / 20),
                        X, barY + 9, RECOVERING, true);
            }
            return;
        }
        int boxY = barY + 9;
        for (int i = 0; i < ShazamClient.SKILL_KEYS.length; i++) {
            int boxX = X + i * 22;
            int cooldown = ShazamClientState.cooldown(i);
            boolean ready = cooldown <= 0;
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, ready ? SABBAC_READY : SABBAC_SHADE);
            graphics.drawCenteredString(font, String.valueOf(SABBAC_LETTERS.charAt(i)), boxX + 10, boxY + 2,
                    ready ? SABBAC_RED : GRAY);
            String sub;
            if (ready) {
                sub = ShazamClient.SKILL_KEYS[i].getTranslatedKeyMessage().getString();
                if (sub.length() > 4) {
                    sub = sub.substring(0, 4);
                }
            } else {
                sub = (cooldown + 19) / 20 + "s";
            }
            small(graphics, font, sub, boxX + 10, boxY + 13, ready ? 0xFFFFFFFF : GRAY);
        }
        // kotak ke-8: Panggil Petir Neraka (tombol M)
        int callX = X + ShazamClient.SKILL_KEYS.length * 22 + 4;
        int call = ShazamClientState.callCooldown();
        boolean callReady = call <= 0;
        graphics.fill(callX - 1, boxY - 1, callX + 20, boxY + 21, callReady ? SABBAC_READY : SABBAC_SHADE);
        graphics.fill(callX - 1, boxY - 1, callX + 20, boxY, callReady ? SABBAC_BAR : 0xFF4A1A12);
        graphics.drawCenteredString(font, HELL_CALL_LETTER, callX + 10, boxY + 2, callReady ? SABBAC_RED : GRAY);
        small(graphics, font, callReady ? key(ShazamClient.MERCURY_AUTO) : (call + 19) / 20 + "s", callX + 10, boxY + 13,
                callReady ? 0xFFFFFFFF : GRAY);
        // kotak ke-9: Pasukan Iblis (tombol J) - jumlah prajurit yang masih bertarung, atau sisa cooldown
        int legionX = callX + 22;
        int alive = ShazamClientState.legionCount();
        int legion = ShazamClientState.legionCooldown();
        boolean legionReady = legion <= 0;
        boolean fighting = alive > 0;
        graphics.fill(legionX - 1, boxY - 1, legionX + 20, boxY + 21, fighting || legionReady ? SABBAC_READY : SABBAC_SHADE);
        if (fighting || legionReady) {
            graphics.fill(legionX - 1, boxY - 1, legionX + 20, boxY, SABBAC_BAR);
        }
        graphics.drawCenteredString(font, LEGION_LETTER, legionX + 10, boxY + 2, fighting || legionReady ? SABBAC_RED : GRAY);
        String legionSub = fighting ? "x" + alive : legionReady ? key(ShazamClient.FAMILY) : (legion + 19) / 20 + "s";
        small(graphics, font, legionSub, legionX + 10, boxY + 13, fighting || legionReady ? 0xFFFFFFFF : GRAY);
        // kotak ke-10 & ke-11: Muatan Neraka (penuh = Tinju Neraka) & Kulit Bara, padanan pasif Shazam / Black Adam
        int x = legionX + 22;
        int charge = Mth.clamp(ShazamClientState.charge(), 0, 100);
        boolean full = charge >= 100;
        boolean blink = full && mc.level != null && (mc.level.getGameTime() / 4L) % 2L == 0L;
        // abu-abu = Api Neraka padam (di bawah matahari / di dalam air)
        boolean off = mc.level != null && mc.player != null && PassiveConditions.hellfireBlock(mc.level,
                mc.player.blockPosition(), mc.player.isUnderWater()) != PassiveConditions.Hellfire.NONE;
        graphics.fill(x - 1, boxY - 1, x + 20, boxY + 21, full && !off ? SABBAC_READY : SABBAC_SHADE);
        int height = Math.round(charge / 100f * 20f);
        graphics.fill(x, boxY + 20 - height, x + 19, boxY + 20,
                off ? 0x80505050 : full ? (blink ? 0xFFFFC890 : SABBAC_RED) : 0xB0902010);
        graphics.drawCenteredString(font, HELL_CHARGE_LETTER, x + 10, boxY + 2, off ? GRAY : full ? 0xFFFFFFFF : SABBAC_RED);
        small(graphics, font, full ? Component.translatable("hud.shazammod.charge_ready").getString() : charge + "%",
                x + 10, boxY + 13, 0xFFFFFFFF);
        int ex = x + 22;
        int engulf = ShazamClientState.dodgeCooldown();   // Kulit Bara memakai jeda yang sama dengan Refleks Mercury
        boolean engulfReady = engulf <= 0;
        graphics.fill(ex - 1, boxY - 1, ex + 20, boxY + 21, engulfReady ? SABBAC_READY : SABBAC_SHADE);
        if (engulfReady) {
            graphics.fill(ex - 1, boxY - 1, ex + 20, boxY, SABBAC_BAR);
        }
        graphics.drawCenteredString(font, ENGULF_LETTER, ex + 10, boxY + 2, engulfReady ? SABBAC_RED : GRAY);
        small(graphics, font, engulfReady ? Component.translatable("hud.shazammod.dodge_ready").getString()
                        : String.format(java.util.Locale.ROOT, "%.1fs", engulf / 20f),
                ex + 10, boxY + 13, engulfReady ? 0xFFFFFFFF : GRAY);
    }

    /**
     * 0.32 HUD Lintang: Cahaya Tersimpan (garis toska = batas Daya Surya penuh), sumber cahaya sekarang, tujuh skill
     * L-I-N-T-A-N-G, Serap Surya (M), Selamatkan (J), Muatan Cahaya, Tepisan Beku, dan baris Daya Surya di bawahnya.
     */
    private static void renderLintang(GuiGraphics graphics, Minecraft mc, Font font, boolean transformed, float energy,
                                      int recovery) {
        boolean kelam = ShazamClientState.kelam;
        int color = transformed ? LINTANG_GOLD : GRAY;
        Component title = Component.literal("\u2600 ").append(Component.translatable("hud.shazammod.energy_lintang"))
                .append(" " + Math.round(energy) + "/" + Math.round(ShazamPowers.MAX_ENERGY));
        graphics.drawString(font, title, X, Y, color, true);
        int titleWidth = font.width(title);
        graphics.pose().pushPose();
        graphics.pose().translate(X + titleWidth + 6, Y + 1.5f, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, Component.translatable("champion.shazammod.lintang"), 0, 0, LINTANG_TEAL, true);
        graphics.pose().popPose();

        int barY = Y + 12;
        graphics.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + 5, LINTANG_SHADE);
        int filled = Math.round(energy / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(X, barY, X + filled, barY + 4, transformed ? (kelam ? KELAM_VIOLET : LINTANG_BAR) : color);
        int full = X + Math.round(LintangSkills.FULL_POWER_ENERGY / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(full, barY - 2, full + 1, barY + 6, LINTANG_TEAL);   // di bawah garis ini kekuatan mulai menyusut
        Component status = kelam ? Component.translatable("hud.shazammod.kelam")
                : ShazamClientState.sun ? Component.translatable("hud.shazammod.sunlight")
                : ShazamClientState.starlight ? Component.translatable("hud.shazammod.starlight") : null;
        if (status != null) {
            graphics.drawString(font, status, X + BAR_WIDTH + 6, barY - 2,
                    kelam ? KELAM_VIOLET : ShazamClientState.sun ? LINTANG_BAR : STARLIGHT_BLUE, true);
        }
        if (!transformed) {
            if (recovery > 0) {
                graphics.drawString(font, Component.translatable("hud.shazammod.recovering_lintang", (recovery + 19) / 20),
                        X, barY + 9, RECOVERING, true);
            }
            return;
        }
        int boxY = barY + 9;
        for (int i = 0; i < ShazamClient.SKILL_KEYS.length; i++) {
            int boxX = X + i * 22;
            int cooldown = ShazamClientState.cooldown(i);
            boolean ready = cooldown <= 0;
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, ready ? LINTANG_READY : LINTANG_SHADE);
            graphics.drawCenteredString(font, String.valueOf(LINTANG_LETTERS.charAt(i)), boxX + 10, boxY + 2,
                    ready ? LINTANG_GOLD : GRAY);
            small(graphics, font, ready ? key(ShazamClient.SKILL_KEYS[i]) : (cooldown + 19) / 20 + "s", boxX + 10, boxY + 13,
                    ready ? 0xFFFFFFFF : GRAY);
        }
        // kotak ke-8: Serap Surya (M)
        int callX = X + ShazamClient.SKILL_KEYS.length * 22 + 4;
        int call = ShazamClientState.callCooldown();
        boolean callReady = call <= 0;
        graphics.fill(callX - 1, boxY - 1, callX + 20, boxY + 21, callReady ? LINTANG_READY : LINTANG_SHADE);
        if (callReady) {
            graphics.fill(callX - 1, boxY - 1, callX + 20, boxY, LINTANG_BAR);
        }
        graphics.drawCenteredString(font, "\u263C", callX + 10, boxY + 2, callReady ? LINTANG_GOLD : GRAY);
        small(graphics, font, callReady ? key(ShazamClient.MERCURY_AUTO) : (call + 19) / 20 + "s", callX + 10, boxY + 13,
                callReady ? 0xFFFFFFFF : GRAY);
        // kotak ke-9: Selamatkan (J)
        int saveX = callX + 22;
        int save = ShazamClientState.familyCooldown();
        boolean saveReady = save <= 0;
        graphics.fill(saveX - 1, boxY - 1, saveX + 20, boxY + 21, saveReady ? LINTANG_READY : LINTANG_SHADE);
        graphics.drawCenteredString(font, "\u271A", saveX + 10, boxY + 2, saveReady ? LINTANG_TEAL : GRAY);
        small(graphics, font, saveReady ? key(ShazamClient.FAMILY) : (save + 19) / 20 + "s", saveX + 10, boxY + 13,
                saveReady ? 0xFFFFFFFF : GRAY);
        // kotak ke-10: Muatan Cahaya (penuh = Tinju Fajar); abu-abu = Serapan Cahaya padam (tanpa langit / Batu Kelam)
        int cx = saveX + 22;
        int charge = Mth.clamp(ShazamClientState.charge(), 0, 100);
        boolean chargeFull = charge >= 100;
        boolean off = kelam || (mc.level != null && mc.player != null
                && !PassiveConditions.skyLight(mc.level, mc.player.blockPosition()));
        boolean blink = chargeFull && mc.level != null && (mc.level.getGameTime() / 4L) % 2L == 0L;
        graphics.fill(cx - 1, boxY - 1, cx + 20, boxY + 21, chargeFull && !off ? LINTANG_READY : LINTANG_SHADE);
        int height = Math.round(charge / 100f * 20f);
        graphics.fill(cx, boxY + 20 - height, cx + 19, boxY + 20,
                off ? 0x80505050 : chargeFull ? (blink ? 0xFFFFFFFF : LINTANG_BAR) : 0xB0A08A30);
        graphics.drawCenteredString(font, "\u2600", cx + 10, boxY + 2, off ? GRAY : chargeFull ? 0xFFFFFFFF : LINTANG_GOLD);
        small(graphics, font, chargeFull ? Component.translatable("hud.shazammod.charge_ready").getString() : charge + "%",
                cx + 10, boxY + 13, 0xFFFFFFFF);
        // kotak ke-11: Tepisan Beku (jedanya sama dengan Refleks Mercury)
        int px = cx + 22;
        int parry = ShazamClientState.dodgeCooldown();
        boolean parryReady = parry <= 0 && !kelam;
        graphics.fill(px - 1, boxY - 1, px + 20, boxY + 21, parryReady ? LINTANG_READY : LINTANG_SHADE);
        if (parryReady) {
            graphics.fill(px - 1, boxY - 1, px + 20, boxY, LINTANG_TEAL);
        }
        graphics.drawCenteredString(font, "\u2744", px + 10, boxY + 2, parryReady ? 0xFFCFF4FF : GRAY);
        small(graphics, font, parryReady ? Component.translatable("hud.shazammod.dodge_ready").getString()
                        : String.format(java.util.Locale.ROOT, "%.1fs", parry / 20f), px + 10, boxY + 13,
                parryReady ? 0xFFFFFFFF : GRAY);
        renderLintangPower(graphics, mc, font, boxY + 25);
    }

    /** 0.32 Daya Surya: bar kekuatan Lintang sekarang, lalu darah maksimal, damage yang diterima, dan tinju pada daya itu. */
    private static void renderLintangPower(GuiGraphics graphics, Minecraft mc, Font font, int y) {
        int power = Mth.clamp(ShazamClientState.lintangPower(), 0, 100);
        float k = power / 100f;
        boolean kelam = ShazamClientState.kelam;
        boolean blink = kelam && mc.level != null && (mc.level.getGameTime() / 6L) % 2L == 0L;
        graphics.fill(X - 1, y - 1, X + BAR_WIDTH + 1, y + 4, LINTANG_SHADE);
        graphics.fill(X, y, X + Math.round(k * BAR_WIDTH), y + 3,
                kelam ? (blink ? 0xFF6A2A9A : KELAM_VIOLET) : power >= 100 ? LINTANG_BAR : LINTANG_TEAL);
        MutableComponent line = Component.literal(kelam ? "\u2620 " : "\u2600 ")
                .append(Component.translatable("hud.shazammod.power_lintang", power))
                .append("  \u2764 " + Math.round(20 + ShazamPowers.LINTANG_BONUS_HEALTH)
                        + "  \u26E8 " + ShazamFavor.percent(LintangSkills.takenAt(k))
                        + "  \u270A " + ShazamFavor.number(LintangSkills.punchAt(k)));
        graphics.pose().pushPose();
        graphics.pose().translate(X, y + 6, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, line, 0, 0, kelam ? KELAM_VIOLET : power >= 100 ? LINTANG_GOLD : STARLIGHT_BLUE, true);
        graphics.pose().popPose();
    }

    // ======= 0.43 Projek Helion-6: H-E-L-I-O-N-6, radiasi hijau di atas hitam =======
    private static final String HELION_LETTERS = "HELION6";
    private static final int HELION_GREEN = 0xFF6CFF9E;
    private static final int HELION_BAR = 0xFF3CE07A;
    private static final int HELION_SHADE = 0xB0061A0E;
    private static final int HELION_READY = 0xC00C3A1E;
    private static final int HELION_SOON = 0x80202020;
    private static final int HELION_SUN = 0xFFFFB04A;

    /**
     * 0.43 HUD Helion-6: Radiasi Cryon (garis hijau = batas Daya Cryon penuh), status matahari / Cryon, tujuh kotak
     * H-E-L-I-O-N-6 (strip = menyusul), Hirup Cryon (M, dengan jumlah Pecahan Cryon), Muatan Cryon, Kulit Cryon, dan baris
     * Daya Cryon. Di bawah matahari bar & status berkedip jingga.
     */
    private static void renderHelion(GuiGraphics graphics, Minecraft mc, Font font, boolean transformed, float energy,
                                     int recovery) {
        boolean sun = ShazamClientState.sun && !ShazamClientState.kelam;
        boolean cryon = ShazamClientState.kelam;
        boolean blink = mc.level != null && (mc.level.getGameTime() / 5L) % 2L == 0L;
        int color = transformed ? HELION_GREEN : GRAY;
        Component title = Component.literal("\u2622 ").append(Component.translatable("hud.shazammod.energy_helion"))
                .append(" " + Math.round(energy) + "/" + Math.round(ShazamPowers.MAX_ENERGY));
        graphics.drawString(font, title, X, Y, color, true);
        int titleWidth = font.width(title);
        graphics.pose().pushPose();
        graphics.pose().translate(X + titleWidth + 6, Y + 1.5f, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, Component.translatable("champion.shazammod.helion"), 0, 0, 0xFF9CFFC0, true);
        graphics.pose().popPose();

        int barY = Y + 12;
        graphics.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + 5, HELION_SHADE);
        int filled = Math.round(energy / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(X, barY, X + filled, barY + 4, transformed ? (sun ? (blink ? HELION_SUN : 0xFFB06A2A) : HELION_BAR) : color);
        int full = X + Math.round(HelionSkills.FULL_POWER_ENERGY / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(full, barY - 2, full + 1, barY + 6, HELION_GREEN);   // di bawah garis ini kekuatan mulai menyusut
        Component status = sun ? Component.translatable("hud.shazammod.helion_sun")
                : ShazamClientState.helionEclipseLeft() > 0 ? Component.translatable("hud.shazammod.helion_eclipse")
                : cryon ? Component.translatable("hud.shazammod.helion_cryon") : Component.translatable("hud.shazammod.helion_dark");
        graphics.drawString(font, status, X + BAR_WIDTH + 6, barY - 2, sun ? (blink ? HELION_SUN : 0xFFFF7A3A) : HELION_GREEN, true);
        if (!transformed) {
            if (recovery > 0) {
                graphics.drawString(font, Component.translatable("hud.shazammod.recovering_helion", (recovery + 19) / 20),
                        X, barY + 9, RECOVERING, true);
            }
            return;
        }
        int boxY = barY + 9;
        for (int i = 0; i < ShazamClient.SKILL_KEYS.length; i++) {
            int boxX = X + i * 22;
            boolean soon = i < HelionSkills.Skill.values().length && !HelionSkills.Skill.values()[i].ready;
            int cooldown = ShazamClientState.cooldown(i);
            boolean ready = cooldown <= 0 && !soon;
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, soon ? HELION_SOON : ready ? HELION_READY : HELION_SHADE);
            graphics.drawCenteredString(font, String.valueOf(HELION_LETTERS.charAt(i)), boxX + 10, boxY + 2,
                    soon ? 0xFF505050 : ready ? HELION_GREEN : GRAY);
            small(graphics, font, soon ? "\u2014" : ready ? key(ShazamClient.SKILL_KEYS[i]) : (cooldown + 19) / 20 + "s",
                    boxX + 10, boxY + 13, soon ? 0xFF606060 : ready ? 0xFFFFFFFF : GRAY);
        }
        // kotak ke-8: Hirup Cryon (M) + jumlah Pecahan Cryon di inventori
        int callX = X + ShazamClient.SKILL_KEYS.length * 22 + 4;
        int call = ShazamClientState.callCooldown();
        int shards = countCryon(mc);
        boolean callReady = call <= 0 && (shards > 0 || (mc.player != null && mc.player.isCreative()));
        graphics.fill(callX - 1, boxY - 1, callX + 20, boxY + 21, callReady ? HELION_READY : HELION_SHADE);
        if (callReady) {
            graphics.fill(callX - 1, boxY - 1, callX + 20, boxY, HELION_BAR);
        }
        graphics.drawCenteredString(font, "\u2622", callX + 10, boxY + 2, callReady ? HELION_GREEN : GRAY);
        small(graphics, font, call > 0 ? (call + 19) / 20 + "s" : "x" + shards, callX + 10, boxY + 13,
                callReady ? 0xFFFFFFFF : GRAY);
        // kotak ke-9 (0.45): Gerhana Buatan (J) - sisa waktu gerhana di atasmu, sisa jeda, atau tombolnya
        int ex = callX + 22;
        int eclipseLeft = ShazamClientState.helionEclipseLeft();
        int eclipseCd = ShazamClientState.helionEclipseCooldown();
        boolean eclipseOn = eclipseLeft > 0;
        boolean eclipseReady = eclipseCd <= 0 && energy >= HelionSkills.ECLIPSE_COST;
        graphics.fill(ex - 1, boxY - 1, ex + 20, boxY + 21, eclipseOn || eclipseReady ? HELION_READY : HELION_SHADE);
        if (eclipseOn || eclipseReady) {
            graphics.fill(ex - 1, boxY - 1, ex + 20, boxY, eclipseOn ? 0xFF9CFFC0 : HELION_BAR);
        }
        graphics.drawCenteredString(font, "\u25D0", ex + 10, boxY + 2, eclipseOn ? 0xFFFFFFFF : eclipseReady ? HELION_GREEN : GRAY);
        small(graphics, font, eclipseOn ? (eclipseLeft + 19) / 20 + "s" : eclipseCd > 0 ? (eclipseCd + 19) / 20 + "s"
                : key(ShazamClient.FAMILY), ex + 10, boxY + 13, eclipseOn || eclipseReady ? 0xFFFFFFFF : GRAY);
        // kotak ke-10: Muatan Cryon (penuh = Tinju Cryon); abu-abu = Denyut Cryon padam (matahari)
        int cx = ex + 22;
        int charge = Mth.clamp(ShazamClientState.charge(), 0, 100);
        boolean chargeFull = charge >= 100;
        graphics.fill(cx - 1, boxY - 1, cx + 20, boxY + 21, chargeFull && !sun ? HELION_READY : HELION_SHADE);
        int height = Math.round(charge / 100f * 20f);
        graphics.fill(cx, boxY + 20 - height, cx + 19, boxY + 20,
                sun ? 0x80505050 : chargeFull ? (blink ? 0xFFFFFFFF : HELION_BAR) : 0xB0208A48);
        graphics.drawCenteredString(font, "\u270A", cx + 10, boxY + 2, sun ? GRAY : chargeFull ? 0xFFFFFFFF : HELION_GREEN);
        small(graphics, font, chargeFull ? Component.translatable("hud.shazammod.charge_ready").getString() : charge + "%",
                cx + 10, boxY + 13, 0xFFFFFFFF);
        // kotak ke-10: Kulit Cryon (serangan lemah memantul; mati di bawah matahari)
        int sx = cx + 22;
        graphics.fill(sx - 1, boxY - 1, sx + 20, boxY + 21, sun ? HELION_SHADE : HELION_READY);
        if (!sun) {
            graphics.fill(sx - 1, boxY - 1, sx + 20, boxY, HELION_BAR);
        }
        graphics.drawCenteredString(font, "\u26E8", sx + 10, boxY + 2, sun ? GRAY : HELION_GREEN);
        small(graphics, font, Component.translatable(sun ? "hud.shazammod.helion_skin_off" : "hud.shazammod.dodge_ready").getString(),
                sx + 10, boxY + 13, sun ? GRAY : 0xFFFFFFFF);
        renderHelionPower(graphics, mc, font, boxY + 25, sun);
    }

    // ------------------------------------------------------------------ 0.49 Subjek Tiga (Helion-3)
    private static final String SUBJEK_LETTERS = "HELION3";
    private static final int SUBJEK_RED = 0xFFF0705E;
    private static final int SUBJEK_BAR = 0xFFC8362E;
    private static final int SUBJEK_RAGE = 0xFFFF9A4A;
    private static final int SUBJEK_SHADE = 0xB01A0808;
    private static final int SUBJEK_READY = 0xC03A100C;
    private static final int SUBJEK_BONE = 0xFFE6DCC8;

    /**
     * 0.49 HUD Subjek Tiga: energi sel mati, status tubuhnya (Evolusi Ketiga / kebal / adaptasi terakhir), tujuh skill
     * H-E-L-I-O-N-3, Serap Cryon (M), Terobos Tanah (J), muatan Cakar Maut, nyawa cadangan, dan cakar Cryon.
     */
    private static void renderHelion3(GuiGraphics graphics, Minecraft mc, Font font, boolean transformed, float energy,
                                      int recovery) {
        boolean blink = mc.level != null && (mc.level.getGameTime() / 5L) % 2L == 0L;
        int rage = ShazamClientState.subjekRageTicks();
        int immune = ShazamClientState.subjekImmuneTicks();
        int kindId = ShazamClientState.subjekAdaptKind();
        com.shazammod.helion3.Helion3.Kind[] kinds = com.shazammod.helion3.Helion3.Kind.values();
        com.shazammod.helion3.Helion3.Kind kind = kindId >= 1 && kindId <= kinds.length ? kinds[kindId - 1] : null;
        int color = transformed ? (rage > 0 ? SUBJEK_RAGE : SUBJEK_RED) : GRAY;
        Component title = Component.literal("\u2620 ").append(Component.translatable("hud.shazammod.energy_helion3"))
                .append(" " + Math.round(energy) + "/" + Math.round(ShazamPowers.MAX_ENERGY));
        graphics.drawString(font, title, X, Y, color, true);
        int titleWidth = font.width(title);
        graphics.pose().pushPose();
        graphics.pose().translate(X + titleWidth + 6, Y + 1.5f, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, Component.translatable("champion.shazammod.helion3"), 0, 0, SUBJEK_BONE, true);
        graphics.pose().popPose();

        int barY = Y + 12;
        graphics.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + 5, SUBJEK_SHADE);
        int filled = Math.round(energy / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(X, barY, X + filled, barY + 4, transformed ? (rage > 0 ? (blink ? SUBJEK_RAGE : SUBJEK_BAR) : SUBJEK_BAR) : color);
        if (transformed) {
            Component status;
            int statusColor;
            if (rage > 0) {
                status = Component.translatable("hud.shazammod.subjek_rage", (rage + 19) / 20);
                statusColor = blink ? 0xFFFFFFFF : SUBJEK_RAGE;
            } else if (immune > 0 && kind != null) {
                status = Component.translatable("hud.shazammod.subjek_immune", com.shazammod.helion3.Helion3.kindName(kind),
                        (immune + 19) / 20);
                statusColor = 0xFF000000 | kind.rgb;
            } else if (kind != null) {
                status = Component.translatable("hud.shazammod.subjek_adapt", com.shazammod.helion3.Helion3.kindName(kind),
                        ShazamClientState.subjekAdaptPercent());
                statusColor = 0xFF000000 | kind.rgb;
            } else {
                status = Component.translatable("hud.shazammod.subjek_hungry");
                statusColor = SUBJEK_RED;
            }
            graphics.drawString(font, status, X + BAR_WIDTH + 6, barY - 2, statusColor, true);
        }
        if (!transformed) {
            if (recovery > 0) {
                graphics.drawString(font, Component.translatable("hud.shazammod.recovering_helion3", (recovery + 19) / 20),
                        X, barY + 9, RECOVERING, true);
            }
            return;
        }
        int boxY = barY + 9;
        for (int i = 0; i < ShazamClient.SKILL_KEYS.length; i++) {
            int boxX = X + i * 22;
            int cooldown = ShazamClientState.cooldown(i);
            boolean ready = cooldown <= 0;
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, ready ? SUBJEK_READY : SUBJEK_SHADE);
            graphics.drawCenteredString(font, String.valueOf(SUBJEK_LETTERS.charAt(i)), boxX + 10, boxY + 2,
                    ready ? (i == 6 && rage > 0 ? SUBJEK_RAGE : SUBJEK_RED) : GRAY);
            small(graphics, font, ready ? key(ShazamClient.SKILL_KEYS[i]) : (cooldown + 19) / 20 + "s",
                    boxX + 10, boxY + 13, ready ? 0xFFFFFFFF : GRAY);
        }
        // kotak ke-8: Serap Cryon (M) + jumlah Pecahan Cryon di inventori
        int callX = X + ShazamClient.SKILL_KEYS.length * 22 + 4;
        int call = ShazamClientState.subjekAbsorbCooldown();
        int shards = countCryon(mc);
        boolean callReady = call <= 0 && (shards > 0 || (mc.player != null && mc.player.isCreative()));
        graphics.fill(callX - 1, boxY - 1, callX + 20, boxY + 21, callReady ? 0xC00C3A1E : SUBJEK_SHADE);
        if (callReady) {
            graphics.fill(callX - 1, boxY - 1, callX + 20, boxY, HELION_BAR);
        }
        graphics.drawCenteredString(font, "\u2622", callX + 10, boxY + 2, callReady ? HELION_GREEN : GRAY);
        small(graphics, font, call > 0 ? (call + 19) / 20 + "s" : "x" + shards, callX + 10, boxY + 13,
                callReady ? 0xFFFFFFFF : GRAY);
        // kotak ke-9: Terobos Tanah (J)
        int bx = callX + 22;
        int burrow = ShazamClientState.subjekBurrowCooldown();
        boolean burrowReady = burrow <= 0;
        graphics.fill(bx - 1, boxY - 1, bx + 20, boxY + 21, burrowReady ? SUBJEK_READY : SUBJEK_SHADE);
        if (burrowReady) {
            graphics.fill(bx - 1, boxY - 1, bx + 20, boxY, SUBJEK_BAR);
        }
        graphics.drawCenteredString(font, "\u25BC", bx + 10, boxY + 2, burrowReady ? SUBJEK_RED : GRAY);
        small(graphics, font, burrowReady ? key(ShazamClient.FAMILY) : (burrow + 19) / 20 + "s", bx + 10, boxY + 13,
                burrowReady ? 0xFFFFFFFF : GRAY);
        // kotak ke-10: muatan (penuh = Cakar Maut)
        int cx = bx + 22;
        int charge = Mth.clamp(ShazamClientState.charge(), 0, 100);
        boolean chargeFull = charge >= 100;
        graphics.fill(cx - 1, boxY - 1, cx + 20, boxY + 21, chargeFull ? SUBJEK_READY : SUBJEK_SHADE);
        int height = Math.round(charge / 100f * 20f);
        graphics.fill(cx, boxY + 20 - height, cx + 19, boxY + 20, chargeFull ? (blink ? 0xFFFFFFFF : SUBJEK_BAR) : 0xB08A2A22);
        graphics.drawCenteredString(font, "\u270A", cx + 10, boxY + 2, chargeFull ? 0xFFFFFFFF : SUBJEK_RED);
        small(graphics, font, chargeFull ? Component.translatable("hud.shazammod.charge_ready").getString() : charge + "%",
                cx + 10, boxY + 13, 0xFFFFFFFF);
        // kotak ke-11: nyawa cadangan (Bangkit Lagi)
        int lx = cx + 22;
        int lives = Mth.clamp(ShazamClientState.subjekLives(), 0, Helion3Skills.LIVES);
        graphics.fill(lx - 1, boxY - 1, lx + 20, boxY + 21, lives > 0 ? SUBJEK_READY : SUBJEK_SHADE);
        if (lives > 0) {
            graphics.fill(lx - 1, boxY - 1, lx + 20, boxY, SUBJEK_BONE);
        }
        graphics.drawCenteredString(font, "\u2764", lx + 10, boxY + 2, lives > 0 ? SUBJEK_RED : GRAY);
        small(graphics, font, lives + "/" + Helion3Skills.LIVES, lx + 10, boxY + 13, lives > 0 ? 0xFFFFFFFF : GRAY);
        // kotak ke-12: cakar Cryon (tiap tumpukan: damage naik)
        int kx = lx + 22;
        int claws = Mth.clamp(ShazamClientState.subjekClaws(), 0, Helion3Skills.CLAW_MAX);
        graphics.fill(kx - 1, boxY - 1, kx + 20, boxY + 21, claws > 0 ? 0xC00C3A1E : SUBJEK_SHADE);
        int clawHeight = Math.round(claws / (float) Helion3Skills.CLAW_MAX * 20f);
        graphics.fill(kx, boxY + 20 - clawHeight, kx + 19, boxY + 20, 0xB0208A48);
        graphics.drawCenteredString(font, "\u2191", kx + 10, boxY + 2, claws > 0 ? HELION_GREEN : GRAY);
        small(graphics, font, claws + "/" + Helion3Skills.CLAW_MAX, kx + 10, boxY + 13, claws > 0 ? 0xFFFFFFFF : GRAY);
        // baris angka: darah maksimal, damage yang diterima (sebelum adaptasi), dan cakaran sekarang
        float power = (1f + Helion3Skills.CLAW_STEP * claws) * (1f + Helion3Skills.REVIVE_BUFF * (Helion3Skills.LIVES - lives))
                * (rage > 0 ? Helion3Skills.RAGE_DAMAGE : 1f);
        float taken = ShazamPowers.HELION3_DAMAGE_TAKEN_MULTIPLIER * (rage > 0 ? Helion3Skills.RAGE_TAKEN : 1f);
        MutableComponent line = Component.literal("\u2764 " + Math.round(20 + ShazamPowers.HELION3_BONUS_HEALTH)
                + "  \u26E8 " + ShazamFavor.percent(taken)
                + "  \u270A " + ShazamFavor.number(ShazamPowers.HELION3_PUNCH_MULTIPLIER * power) + "  ")
                .append(Component.translatable("hud.shazammod.subjek_noflight"));
        graphics.pose().pushPose();
        graphics.pose().translate(X, boxY + 25, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, line, 0, 0, rage > 0 ? SUBJEK_RAGE : SUBJEK_BONE, true);
        graphics.pose().popPose();
    }

    // ------------------------------------------------------------------ 0.51 PRALAYA, Sang Mesin Kiamat (0.52: kristal inti di kotak)
    private static final String AKSARA_LETTERS = "KRPLWJ\u03A9";   // Kekuatan Ruang Pikiran reaLitas Waktu Jiwa + Singularitas
    private static final int AKSARA_GOLD = 0xFFFFD27A;
    private static final int AKSARA_BAR = 0xFFE0A840;
    private static final int AKSARA_SHADE = 0xB0120E22;
    private static final int AKSARA_READY = 0xC02A2250;
    private static final int AKSARA_IVORY = 0xFFF4ECDC;

    /**
     * 0.50 HUD Aksara: energi sabda, keadaan (Sabda Purna / Henti Kala / Cermin Maya / Perisai / Tirai / sabda tertulis),
     * tujuh kotak ranah (warna ranahnya; garis di atas kotak = sabda itu sudah tertulis), Lontar Cakram (M), Langkah Ruang
     * (J), Tinju Enam Sabda, Tangkal Ruang, lalu baris angka. Shift + tombol = sabda kedua di kotak yang sama.
     */
    private static void renderAksara(GuiGraphics graphics, Minecraft mc, Font font, boolean transformed, float energy,
                                     int recovery) {
        boolean blink = mc.level != null && (mc.level.getGameTime() / 5L) % 2L == 0L;
        int purna = ShazamClientState.aksaraPurnaTicks();
        int mask = ShazamClientState.aksaraInscribed();
        int color = transformed ? (purna > 0 ? AKSARA_IVORY : AKSARA_GOLD) : GRAY;
        Component title = Component.literal("\u2B21 ").append(Component.translatable("hud.shazammod.energy_aksara"))
                .append(" " + Math.round(energy) + "/" + Math.round(ShazamPowers.MAX_ENERGY));
        graphics.drawString(font, title, X, Y, color, true);
        int titleWidth = font.width(title);
        graphics.pose().pushPose();
        graphics.pose().translate(X + titleWidth + 6, Y + 1.5f, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        int armorPhase = Mth.clamp(ShazamClientState.pralayaPhase(), 0, 3);   // 0.55
        MutableComponent champ = Component.translatable("champion.shazammod.aksara");
        if (armorPhase > 0) {
            champ = champ.append(" ").append(Component.translatable("hud.shazammod.pralaya_phase" + armorPhase));
        }
        graphics.drawString(font, champ, 0, 0, armorPhase >= 3 ? 0xFFFFE6B8 : AKSARA_IVORY, true);
        graphics.pose().popPose();

        int barY = Y + 12;
        graphics.fill(X - 1, barY - 1, X + BAR_WIDTH + 1, barY + 5, AKSARA_SHADE);
        int filled = Math.round(energy / ShazamPowers.MAX_ENERGY * BAR_WIDTH);
        graphics.fill(X, barY, X + filled, barY + 4, transformed ? (purna > 0 && blink ? 0xFFFFF6E0 : AKSARA_BAR) : color);
        if (transformed) {
            Component status;
            int statusColor;
            int stop = ShazamClientState.aksaraTimeStopTicks();
            int veil = ShazamClientState.aksaraVeilTicks();
            int shield = ShazamClientState.aksaraShieldTicks();
            int ward = ShazamClientState.aksaraWardTicks();
            if (purna > 0) {
                status = Component.translatable("hud.shazammod.aksara_purna", secs(purna));
                statusColor = blink ? 0xFFFFFFFF : AKSARA_IVORY;
            } else if (stop > 0) {
                status = Component.translatable("hud.shazammod.aksara_timestop", secs(stop));
                statusColor = 0xFF000000 | AksaraSkills.RGB[4];
            } else if (veil > 0) {
                status = Component.translatable("hud.shazammod.aksara_veil", secs(veil));
                statusColor = 0xFF000000 | AksaraSkills.RGB[3];
            } else if (shield > 0) {
                status = Component.translatable("hud.shazammod.aksara_shield", secs(shield));
                statusColor = 0xFF000000 | AksaraSkills.RGB[1];
            } else if (ward > 0) {
                status = Component.translatable("hud.shazammod.aksara_ward", secs(ward));
                statusColor = 0xFF000000 | AksaraSkills.RGB[5];
            } else {
                int count = Integer.bitCount(mask & AksaraSkills.ALL_SIX);
                status = Component.translatable(count >= 6 ? "hud.shazammod.aksara_complete" : "hud.shazammod.aksara_inscribed",
                        count);
                statusColor = count >= 6 ? (blink ? 0xFFFFFFFF : AKSARA_GOLD) : AKSARA_GOLD;
            }
            graphics.drawString(font, status, X + BAR_WIDTH + 6, barY - 2, statusColor, true);
        }
        if (!transformed) {
            if (recovery > 0) {
                graphics.drawString(font, Component.translatable("hud.shazammod.recovering_aksara", (recovery + 19) / 20),
                        X, barY + 9, RECOVERING, true);
            }
            return;
        }
        int boxY = barY + 9;
        float pt = mc.getTimer().getGameTimeDeltaPartialTick(true);
        long now = AksaraFx.clock();   // 0.59 jam efek PRALAYA (tetap jalan saat Henti Waktu Dunia; game time ikut berhenti)
        LocalPlayer self = mc.player;
        int cores = armorPhase > 0 ? ShazamClientState.pralayaCores() : AksaraSkills.ALL_SIX;   // 0.55 inti terpasang
        boolean space = (cores & 2) != 0;
        for (int i = 0; i < ShazamClient.SKILL_KEYS.length; i++) {
            int boxX = X + i * 22;
            int cooldown = ShazamClientState.cooldown(i);
            boolean ready = cooldown <= 0;
            int rgb = 0xFF000000 | AksaraSkills.RGB[Math.min(i, AksaraSkills.RGB.length - 1)];
            // 0.52 kotaknya berkilat warna intinya tiap protokolnya dipakai (cooldown baru mulai / intinya baru menyala)
            float used = aksaraUsed(i, cooldown, now, pt);
            if (i < 6 && self != null) {
                used = Math.max(used, AksaraFx.ignition(self, i, pt));
            }
            graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY + 21, ready ? AKSARA_READY : AKSARA_SHADE);
            aksaraFlashFill(graphics, boxX, boxY, rgb, used);
            if (i < 6 && (mask & (1 << i)) != 0) {
                graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY, rgb);   // subsistem ini sudah daring
            } else if (i == 6 && Integer.bitCount(mask & AksaraSkills.ALL_SIX) >= 6) {
                graphics.fill(boxX - 1, boxY - 1, boxX + 20, boxY, blink ? 0xFFFFFFFF : AKSARA_GOLD);
            }
            boolean locked = (i >= 1 && i <= 5 && (cores & (1 << i)) == 0)
                    || (i == 6 && armorPhase > 0 && armorPhase < 3);   // 0.55 inti belum ditemukan / belum Fase Dewa
            if (locked) {
                lockIcon(graphics, boxX + 9, boxY + 2, i < 6 ? hudMix(0x50545C, AksaraSkills.RGB[i], 0.35f) : 0x6A6E76);
            } else if (i < 6) {   // 0.52 kristal inti daya subsistemnya: terangnya sama persis dengan kristal di drone
                float glow = self != null ? AksaraFx.discGlow(self, i, pt) : ready ? 0.45f : 0.25f;
                aksaraGem(graphics, boxX + 9, boxY + 1, rgb & 0xFFFFFF, glow);
            } else {
                graphics.drawCenteredString(font, String.valueOf(AKSARA_LETTERS.charAt(i)), boxX + 10, boxY + 2,
                        ready ? (purna > 0 ? 0xFFFFFFFF : rgb) : GRAY);
            }
            boolean altSet = i < 6 && net.minecraft.client.gui.screens.Screen.hasAltDown();   // 0.60 protokol ketiga
            small(graphics, font, ready ? (altSet ? "A" : "") + key(ShazamClient.SKILL_KEYS[i]) : (cooldown + 19) / 20 + "s",
                    boxX + 10, boxY + 13, ready ? (altSet ? 0xFFFFE6A0 : 0xFFFFFFFF) : GRAY);
            if (altSet) {
                graphics.fill(boxX - 1, boxY + 20, boxX + 20, boxY + 21, 0xFFFFE6A0);
            }
            aksaraFlashFrame(graphics, boxX, boxY, rgb, used);
        }
        // kotak ke-8: Lontar Cakram / Perisai Sabda (M)
        int mx = X + ShazamClient.SKILL_KEYS.length * 22 + 4;
        int disc = ShazamClientState.aksaraDiscCooldown();
        boolean discReady = disc <= 0;
        float usedM = aksaraUsed(7, disc, now, pt);
        graphics.fill(mx - 1, boxY - 1, mx + 20, boxY + 21, discReady ? AKSARA_READY : AKSARA_SHADE);
        aksaraFlashFill(graphics, mx, boxY, AksaraSkills.RGB[6], usedM);
        if (discReady) {
            graphics.fill(mx - 1, boxY - 1, mx + 20, boxY, AKSARA_GOLD);
        }
        if (armorPhase >= 3 || armorPhase == 0) {
            // 0.52 rombongan drone: enam titik inti melingkar, masing-masing warna & terang intinya
            for (int i = 0; i < 6; i++) {
                float a = i * Mth.TWO_PI / 6f - Mth.HALF_PI;
                int dx = mx + 9 + Math.round(Mth.cos(a) * 4.5f), dy = boxY + 6 + Math.round(Mth.sin(a) * 4.5f);
                float glow = self != null ? AksaraFx.discGlow(self, i, pt) : 0.45f;
                graphics.fill(dx - 1, dy - 1, dx + 1, dy + 1, 0xFF000000 | hudMix(0x262A33, AksaraSkills.RGB[i],
                        discReady ? 0.35f + 0.65f * glow : 0.25f));
            }
            graphics.fill(mx + 9, boxY + 6, mx + 10, boxY + 7, discReady ? 0xFFFFFFFF : GRAY);
        } else {   // 0.55 belum Fase Dewa: drone belum ada, M cuma perisai (Shift)
            graphics.drawCenteredString(font, "\u26E8", mx + 10, boxY + 2, discReady ? (0xFF000000 | AksaraSkills.RGB[1]) : GRAY);
        }
        small(graphics, font, discReady ? key(ShazamClient.MERCURY_AUTO) : (disc + 19) / 20 + "s", mx + 10, boxY + 13,
                discReady ? 0xFFFFFFFF : GRAY);
        aksaraFlashFrame(graphics, mx, boxY, AksaraSkills.RGB[6], usedM);
        // kotak ke-9: Langkah Ruang / Tulis Ulang Diri (J)
        int jx = mx + 22;
        int step = ShazamClientState.aksaraStepCooldown();
        boolean stepReady = step <= 0;
        float usedJ = aksaraUsed(8, step, now, pt);
        graphics.fill(jx - 1, boxY - 1, jx + 20, boxY + 21, stepReady ? AKSARA_READY : AKSARA_SHADE);
        aksaraFlashFill(graphics, jx, boxY, AksaraSkills.RGB[1], usedJ);
        if (stepReady) {
            graphics.fill(jx - 1, boxY - 1, jx + 20, boxY, 0xFF000000 | AksaraSkills.RGB[1]);
        }
        graphics.drawCenteredString(font, space ? "\u21E2" : "\u00BB", jx + 10, boxY + 2,
                stepReady ? (0xFF000000 | (space ? AksaraSkills.RGB[1] : 0x8FE4FF)) : GRAY);   // 0.55 tanpa Inti Ruang: dorongan
        small(graphics, font, stepReady ? key(ShazamClient.FAMILY) : (step + 19) / 20 + "s", jx + 10, boxY + 13,
                stepReady ? 0xFFFFFFFF : GRAY);
        aksaraFlashFrame(graphics, jx, boxY, AksaraSkills.RGB[1], usedJ);
        // kotak ke-10: muatan (penuh = Tinju Enam Sabda)
        int cx = jx + 22;
        int charge = Mth.clamp(ShazamClientState.charge(), 0, 100);
        boolean chargeFull = charge >= 100;
        graphics.fill(cx - 1, boxY - 1, cx + 20, boxY + 21, chargeFull ? AKSARA_READY : AKSARA_SHADE);
        int height = Math.round(charge / 100f * 20f);
        graphics.fill(cx, boxY + 20 - height, cx + 19, boxY + 20, chargeFull ? (blink ? 0xFFFFFFFF : AKSARA_BAR) : 0xB07A5A20);
        graphics.drawCenteredString(font, "\u270A", cx + 10, boxY + 2, chargeFull ? 0xFFFFFFFF : AKSARA_GOLD);
        small(graphics, font, chargeFull ? Component.translatable("hud.shazammod.charge_ready").getString() : charge + "%",
                cx + 10, boxY + 13, 0xFFFFFFFF);
        // kotak ke-11: Tangkal Ruang (pasif)
        int px = cx + 22;
        int phase = ShazamClientState.aksaraPhaseCooldown();
        boolean phaseReady = phase <= 0;
        graphics.fill(px - 1, boxY - 1, px + 20, boxY + 21, phaseReady && space ? AKSARA_READY : AKSARA_SHADE);
        if (space) {
            graphics.drawCenteredString(font, "\u27F2", px + 10, boxY + 2, phaseReady ? (0xFF000000 | AksaraSkills.RGB[1]) : GRAY);
            small(graphics, font, phaseReady ? Component.translatable("hud.shazammod.dodge_ready").getString()
                    : (phase + 19) / 20 + "s", px + 10, boxY + 13, phaseReady ? 0xFFFFFFFF : GRAY);
        } else {   // 0.55 Lipat Darurat butuh Inti Ruang
            lockIcon(graphics, px + 9, boxY + 2, 0x6A6E76);
        }
        // baris angka: darah maksimal, damage yang diterima, tinju (dengan Sabda Purna & Sabda Lengkap), petunjuk Shift
        boolean complete = Integer.bitCount(mask & AksaraSkills.ALL_SIX) >= 6;
        float power = (complete ? AksaraSkills.COMPLETE_DAMAGE : 1f) * (purna > 0 ? AksaraSkills.PURNA_DAMAGE : 1f)
                * AksaraSkills.PHASE_POWER[armorPhase];   // 0.55 fase armor
        float taken = ShazamPowers.AKSARA_DAMAGE_TAKEN_MULTIPLIER * (purna > 0 ? AksaraSkills.PURNA_TAKEN : 1f)
                * (ShazamClientState.aksaraWardTicks() > 0 ? AksaraSkills.WARD_TAKEN : 1f) * AksaraSkills.PHASE_TAKEN[armorPhase];
        MutableComponent line = Component.literal("\u2764 " + Math.round(20 + AksaraSkills.healthBonusFor(armorPhase))
                + "  \u26E8 " + ShazamFavor.percent(taken)
                + "  \u270A " + ShazamFavor.number(ShazamPowers.AKSARA_PUNCH_MULTIPLIER * power) + "  ")
                .append(Component.translatable("hud.shazammod.aksara_shift"));
        graphics.pose().pushPose();
        graphics.pose().translate(X, boxY + 25, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, line, 0, 0, purna > 0 ? AKSARA_IVORY : AKSARA_GOLD, true);
        graphics.pose().popPose();
        renderSignal(graphics, mc, boxY + 34);   // 0.55 sinyal inti terdekat
    }

    // ------------------------------------------------------------------ 0.56 Fase Dewa

    /** Sisa detik, atau tak hingga untuk kuasa Fase Dewa yang tanpa batas (dimatikan dengan menekan lagi). */
    private static String secs(int ticks) {
        return ticks >= com.shazammod.PralayaGod.FOREVER / 2 ? "\u221E" : String.valueOf((ticks + 19) / 20);
    }

    /** Henti Waktu Dunia: tulisan di tengah atas layar (pemegang waktu: cara melanjutkan; yang lain: membeku). */
    private static void renderWorldStop(GuiGraphics graphics, Minecraft mc) {
        boolean owner = AksaraFx.ownsWorldStop();
        boolean blink = mc.level != null && (mc.level.getGameTime() / 10L + mc.player.tickCount / 10) % 2L == 0L;
        Component text = Component.translatable(owner ? "hud.shazammod.world_stop_owner" : "hud.shazammod.world_stop");
        int color = owner ? 0xFF000000 | AksaraSkills.RGB[4] : blink ? 0xFFFFFFFF : 0xFF000000 | AksaraSkills.RGB[4];
        graphics.pose().pushPose();
        graphics.pose().translate(graphics.guiWidth() / 2f, 22f, 0f);
        float sc = owner ? 0.9f : 1.4f;
        graphics.pose().scale(sc, sc, 1f);
        graphics.drawCenteredString(mc.font, text, 0, 0, color);
        graphics.pose().popPose();
    }

    // ------------------------------------------------------------------ 0.55 armor PRALAYA: sinyal & inti tanpa armor

    private static final String[] PRALAYA_ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190",
            "\u2196"};

    /** Baris sinyal benteng meteor terdekat (jarak & panah relatif arah pandang). Mengembalikan y sesudahnya. */
    private static int renderSignal(GuiGraphics graphics, Minecraft mc, int y) {
        int core = ShazamClientState.pralayaTracked();
        if (core < 0 || core > 5 || mc.player == null || mc.level == null || ShazamClientState.pralayaPhase() <= 0) {
            return y;
        }
        int rgb = 0xFF000000 | AksaraSkills.RGB[core];
        Component name = Component.translatable("sabda.shazammod." + AksaraSkills.SABDA_IDS[core]);
        Component text;
        if (mc.level.dimension() != net.minecraft.world.level.Level.OVERWORLD) {
            text = Component.translatable("hud.shazammod.pralaya_signal_far", name);
        } else {
            double dx = ShazamClientState.pralayaTrackedX() + 0.5 - mc.player.getX();
            double dz = ShazamClientState.pralayaTrackedZ() + 0.5 - mc.player.getZ();
            int dist = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
            float rel = Mth.wrapDegrees((float) Math.toDegrees(Math.atan2(-dx, dz)) - mc.player.getYRot());
            String arrow = PRALAYA_ARROWS[Math.floorMod(Math.round(rel / 45f), 8)];
            text = Component.translatable("hud.shazammod.pralaya_signal", name, dist, arrow);
        }
        boolean blink = (mc.level.getGameTime() / 10L) % 2L == 0L;
        graphics.pose().pushPose();
        graphics.pose().translate(X, y, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(mc.font, Component.literal(blink ? "\u25C9 " : "\u25CE ").append(text), 0, 0, rgb, true);
        graphics.pose().popPose();
        return y + 9;
    }

    /** Wujud manusia: baris sinyal cuma tampil kalau Inti Armor sedang dipegang (seperti kompas). */
    private static void renderSignalIfHolding(GuiGraphics graphics, Minecraft mc, int y) {
        if (mc.player != null && (mc.player.getMainHandItem().is(com.shazammod.AksaraItems.LONTAR.get())
                || mc.player.getOffhandItem().is(com.shazammod.AksaraItems.LONTAR.get()))) {
            renderSignal(graphics, mc, y + 2);
        }
    }

    /**
     * Inti PRALAYA yang DIBAWA tanpa armor: enam kotak kecil Z-N (yang intinya dibawa menyala, sisanya kosong), cooldown
     * dan pengingat bahwa kuasanya lebih lemah. Mengembalikan y sesudahnya (tetap y kalau nggak membawa inti).
     */
    private static int renderHumanCores(GuiGraphics graphics, Minecraft mc, int y) {
        int carried = ShazamClientState.pralayaCarried() & AksaraSkills.ALL_SIX;
        if (carried == 0 || ShazamClientState.transformed) {
            return y;
        }
        Font font = mc.font;
        float pt = mc.getTimer().getGameTimeDeltaPartialTick(true);
        long now = AksaraFx.clock();   // 0.59 jam efek PRALAYA (tetap jalan saat Henti Waktu Dunia; game time ikut berhenti)
        graphics.pose().pushPose();
        graphics.pose().translate(X, y, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, Component.literal("\u2B21 ").append(Component.translatable("hud.shazammod.pralaya_human")),
                0, 0, AKSARA_GOLD, true);
        graphics.pose().popPose();
        int boxY = y + 9;
        for (int i = 0; i < 6; i++) {
            int bx = X + i * 18;
            boolean has = (carried & (1 << i)) != 0;
            int cooldown = ShazamClientState.pralayaCoreCooldown(i);
            boolean ready = has && cooldown <= 0;
            int rgb = AksaraSkills.RGB[i];
            graphics.fill(bx - 1, boxY - 1, bx + 16, boxY + 17, ready ? AKSARA_READY : AKSARA_SHADE);
            if (has) {
                float used = aksaraUsed(i, cooldown, now, pt);
                aksaraFlashFill16(graphics, bx, boxY, rgb, used);
                aksaraGem(graphics, bx + 7, boxY + 1, rgb, ready ? 0.75f : 0.3f);
                small(graphics, font, ready ? key(ShazamClient.SKILL_KEYS[i]) : (cooldown + 19) / 20 + "s", bx + 8, boxY + 12,
                        ready ? 0xFFFFFFFF : GRAY);
            } else {
                graphics.fill(bx + 6, boxY + 5, bx + 10, boxY + 9, 0xFF2A2D34);   // dudukan kosong
            }
        }
        return boxY + 20;
    }

    private static void aksaraFlashFill16(GuiGraphics g, int x, int y, int rgb, float k) {
        if (k > 0.01f) {
            g.fill(x - 1, y - 1, x + 16, y + 17, ((int) (k * 120f) << 24) | (rgb & 0xFFFFFF));
        }
    }

    /** Gembok kecil 7 x 9 piksel: skill yang belum terbuka (inti belum ditemukan / butuh Fase Dewa). */
    private static void lockIcon(GuiGraphics g, int cx, int top, int rgb) {
        int c = 0xFF000000 | rgb, dark = 0xFF000000 | hudMix(rgb, 0x000000, 0.45f);
        g.fill(cx - 2, top, cx + 3, top + 1, c);           // lengkung gembok
        g.fill(cx - 2, top, cx - 1, top + 4, c);
        g.fill(cx + 2, top, cx + 3, top + 4, c);
        g.fill(cx - 3, top + 4, cx + 4, top + 9, c);       // badan gembok
        g.fill(cx, top + 5, cx + 1, top + 8, dark);         // lubang kunci
    }

    // 0.52 kilatan kotak sesudah protokolnya dipakai: Z X C V B N R, M, J
    private static final int[] AKSARA_PREV_CD = new int[9];
    private static final long[] AKSARA_USED_AT = new long[9];

    /** 0.52 0..1 kilatan kotak HUD sesudah protokolnya dipakai (cooldown-nya baru saja melonjak), turun dalam 14 tick. */
    private static float aksaraUsed(int slot, int cooldown, long now, float pt) {
        if (cooldown > AKSARA_PREV_CD[slot] + 4) {
            AKSARA_USED_AT[slot] = now;
        }
        AKSARA_PREV_CD[slot] = cooldown;
        float t = now - AKSARA_USED_AT[slot] + pt;
        return AKSARA_USED_AT[slot] == 0L || t < 0f || t >= 14f ? 0f : 1f - t / 14f;
    }

    /** 0.52 Isi kotak berkilat warna intinya (digambar di bawah ikon & teks). */
    private static void aksaraFlashFill(GuiGraphics g, int x, int y, int rgb, float k) {
        if (k > 0.01f) {
            g.fill(x - 1, y - 1, x + 20, y + 21, ((int) (k * 120f) << 24) | (rgb & 0xFFFFFF));
        }
    }

    /** 0.52 Bingkai menyala yang memuai keluar dari kotak (digambar paling atas). */
    private static void aksaraFlashFrame(GuiGraphics g, int x, int y, int rgb, float k) {
        if (k <= 0.01f) {
            return;
        }
        int c = ((int) (k * 230f) << 24) | (rgb & 0xFFFFFF);
        int e = Math.round((1f - k) * 3f) + 1;   // memuai 1..4 px
        int x0 = x - 1 - e, y0 = y - 1 - e, x1 = x + 20 + e, y1 = y + 21 + e;
        g.fill(x0, y0, x1, y0 + 1, c);
        g.fill(x0, y1 - 1, x1, y1, c);
        g.fill(x0, y0 + 1, x0 + 1, y1 - 1, c);
        g.fill(x1 - 1, y0 + 1, x1, y1 - 1, c);
    }

    /** 0.52 Kristal inti daya di kotak HUD (7 x 11 piksel): sisi kiri terang, kanan gelap, kilau putih saat menyala. */
    private static void aksaraGem(GuiGraphics g, int cx, int top, int rgb, float k) {
        int[] widths = {1, 3, 5, 7, 7, 7, 7, 7, 5, 3, 1};
        k = Mth.clamp(k, 0f, 1f);
        int body = hudMix(0x262A33, rgb, 0.3f + 0.7f * k);
        int light = hudMix(body, 0xFFFFFF, 0.2f + 0.4f * k);
        int dark = hudMix(body, 0x000000, 0.4f);
        if (k > 0.7f) {   // pendar di belakang kristal yang menyala
            int a = (int) ((k - 0.7f) / 0.3f * 110f);
            g.fill(cx - 5, top - 1, cx + 6, top + 12, (a << 24) | rgb);
        }
        for (int row = 0; row < widths.length; row++) {
            int half = widths[row] / 2, y = top + row;
            g.fill(cx - half, y, cx + half + 1, y + 1, 0xFF000000 | body);
            if (half > 0) {
                g.fill(cx - half, y, cx - half + 1, y + 1, 0xFF000000 | light);
                g.fill(cx + half, y, cx + half + 1, y + 1, 0xFF000000 | dark);
            }
        }
        g.fill(cx - 1, top + 2, cx, top + 9, 0xFF000000 | hudMix(light, 0xFFFFFF, 0.3f));   // tepi sisi terang
        if (k > 0.85f) {
            g.fill(cx - 2, top + 3, cx - 1, top + 4, 0xFFFFFFFF);   // titik kilau
            g.fill(cx, top, cx + 1, top + 2, 0xFFFFFFFF);
        }
    }

    private static int hudMix(int a, int b, float t) {
        t = Mth.clamp(t, 0f, 1f);
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int gg = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (gg << 8) | bl;
    }

    /** 0.43 Daya Cryon: bar kekuatan Helion-6 sekarang, lalu darah maksimal, damage yang diterima, dan tinju pada daya itu. */
    private static void renderHelionPower(GuiGraphics graphics, Minecraft mc, Font font, int y, boolean sun) {
        int power = Mth.clamp(ShazamClientState.helionPower(), 0, 150);
        float k = power / 100f;
        boolean blink = sun && mc.level != null && (mc.level.getGameTime() / 6L) % 2L == 0L;
        graphics.fill(X - 1, y - 1, X + BAR_WIDTH + 1, y + 4, HELION_SHADE);
        graphics.fill(X, y, X + Math.round(Math.min(1f, k) * BAR_WIDTH), y + 3,
                sun ? (blink ? 0xFF8A4A1A : HELION_SUN) : power > 100 ? 0xFFFFFFFF : HELION_BAR);
        MutableComponent line = Component.literal(sun ? "\u2600 " : "\u2622 ")
                .append(Component.translatable("hud.shazammod.power_helion", power))
                .append("  \u2764 " + Math.round(20 + ShazamPowers.HELION_BONUS_HEALTH)
                        + "  \u26E8 " + ShazamFavor.percent(HelionSkills.takenAt(Math.min(1f, k)))
                        + "  \u270A " + ShazamFavor.number(HelionSkills.punchAt(k)));
        graphics.pose().pushPose();
        graphics.pose().translate(X, y + 6, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, line, 0, 0, sun ? HELION_SUN : HELION_GREEN, true);
        graphics.pose().popPose();
    }

    /** Jumlah Pecahan & Bijih Cryon di inventori pemain sendiri (bahan Hirup Cryon). */
    private static int countCryon(Minecraft mc) {
        if (mc.player == null) {
            return 0;
        }
        int n = 0;
        var inventory = mc.player.getInventory();
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            var stack = inventory.getItem(i);
            if (LintangSkills.isKelam(stack)) {
                n += stack.getCount();
            }
        }
        return n;
    }

    /** Nama tombol, paling panjang 4 huruf. */
    private static String key(net.minecraft.client.KeyMapping mapping) {
        String name = mapping.getTranslatedKeyMessage().getString();
        return name.length() > 4 ? name.substring(0, 4) : name;
    }

    /** 0.28 Black Adam: Muatan Surya (penuh = Tinju Aton) dan Tangkisan Kahndaq (jeda 1,8 detik), warna Kahndaq. */
    private static void renderAdamPassives(GuiGraphics graphics, Font font, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        int charge = Mth.clamp(ShazamClientState.charge(), 0, 100);
        boolean full = charge >= 100;
        boolean blink = full && mc.level != null && (mc.level.getGameTime() / 4L) % 2L == 0L;
        boolean night = mc.level != null && !PassiveConditions.sunUp(mc.level);   // 0.29: abu-abu = Cakram Aton padam
        graphics.fill(x - 1, y - 1, x + 20, y + 21, full && !night ? 0xC0301206 : ADAM_SHADE);
        int height = Math.round(charge / 100f * 20f);
        graphics.fill(x, y + 20 - height, x + 19, y + 20, night ? 0x80505050 : full ? (blink ? 0xFFFFE2A8 : ADAM_GOLD) : 0xB0A0561A);
        graphics.drawCenteredString(font, "\u2600", x + 10, y + 2, night ? GRAY : full ? 0xFFFFFFFF : ADAM_GOLD);   // Muatan Surya
        small(graphics, font, full ? Component.translatable("hud.shazammod.charge_ready").getString() : charge + "%",
                x + 10, y + 13, 0xFFFFFFFF);
        int bx = x + 22;
        int block = ShazamClientState.dodgeCooldown();   // Tangkisan Kahndaq memakai jeda yang sama dengan Refleks Mercury
        boolean ready = block <= 0;
        graphics.fill(bx - 1, y - 1, bx + 20, y + 21, ready ? 0xC0301206 : ADAM_SHADE);
        if (ready) {
            graphics.fill(bx - 1, y - 1, bx + 20, y, ADAM_BAR);
        }
        graphics.drawCenteredString(font, BLOCK_LETTER, bx + 10, y + 2, ready ? ADAM_GOLD : GRAY);
        small(graphics, font, ready ? Component.translatable("hud.shazammod.dodge_ready").getString()
                        : String.format(java.util.Locale.ROOT, "%.1fs", block / 20f),
                bx + 10, y + 13, ready ? 0xFFFFFFFF : GRAY);
    }

    /** Shazam 0.23: kotak Muatan Petir (terisi dari bawah; penuh = Pukulan Guntur siap) dan Refleks Mercury. */
    private static void renderPassives(GuiGraphics graphics, Font font, int x, int y) {
        Minecraft mc = Minecraft.getInstance();
        int charge = Mth.clamp(ShazamClientState.charge(), 0, 100);
        boolean full = charge >= 100;
        boolean blink = full && mc.level != null && (mc.level.getGameTime() / 4L) % 2L == 0L;
        // 0.29: abu-abu = petir tiap 2 detik sedang padam (gurun / es & salju / Nether)
        boolean off = mc.level != null && mc.player != null
                && PassiveConditions.lightningBlock(mc.level, mc.player.blockPosition()) != PassiveConditions.Block.NONE;
        graphics.fill(x - 1, y - 1, x + 20, y + 21, full && !off ? 0xC0302408 : SHADE);
        int height = Math.round(charge / 100f * 20f);
        graphics.fill(x, y + 20 - height, x + 19, y + 20, off ? 0x80505050 : full ? (blink ? CHARGE_FLASH : CHARGE_FULL) : CHARGE_FILL);
        graphics.drawCenteredString(font, "\u26A1", x + 10, y + 2, off ? GRAY : full ? 0xFFFFFFFF : GOLD);
        small(graphics, font, full ? Component.translatable("hud.shazammod.charge_ready").getString() : charge + "%",
                x + 10, y + 13, 0xFFFFFFFF);
        // Refleks Mercury: biru = siap mengelak
        int dx = x + 22;
        int dodge = ShazamClientState.dodgeCooldown();
        boolean ready = dodge <= 0;
        graphics.fill(dx - 1, y - 1, dx + 20, y + 21, ready ? MERCURY_BG : SHADE);
        graphics.drawCenteredString(font, "\u00BB", dx + 10, y + 2, ready ? MERCURY_ON : GRAY);
        // jedanya cuma 1,8 detik (0.25): tampilkan satu angka di belakang koma
        small(graphics, font, ready ? Component.translatable("hud.shazammod.dodge_ready").getString()
                        : String.format(java.util.Locale.ROOT, "%.1fs", dodge / 20f),
                dx + 10, y + 13, ready ? 0xFFFFFFFF : GRAY);
        // 0.26 Kekuatan Keluarga (tombol J): emas = siap, abu-abu = sisa cooldown
        int fx = dx + 22;
        int family = ShazamClientState.familyCooldown();
        boolean famReady = family <= 0;
        graphics.fill(fx - 1, y - 1, fx + 20, y + 21, famReady ? FAMILY_BG : SHADE);
        graphics.drawCenteredString(font, "\u2665", fx + 10, y + 2, famReady ? GOLD : GRAY);
        String famSub = famReady ? ShazamClient.FAMILY.getTranslatedKeyMessage().getString() : (family + 19) / 20 + "s";
        if (famSub.length() > 4) {
            famSub = famSub.substring(0, 4);
        }
        small(graphics, font, famSub, fx + 10, y + 13, famReady ? 0xFFFFFFFF : GRAY);
    }

    /**
     * 0.31 Restu Para Dewa (scaling Shazam): bar tumpukan di bawah kotak skill. Garis jingga di bar = mulai tumpukan itu
     * Shazam melampaui angka mentah Black Adam. Di bawahnya angka Shazam sekarang: darah maksimal, damage yang diterima,
     * tinju tangan kosong.
     */
    private static void renderFavor(GuiGraphics graphics, Minecraft mc, Font font, int y) {
        int max = Math.max(1, ShazamPowers.FAVOR_MAX_STACKS);
        int stacks = Mth.clamp(ShazamClientState.favor(), 0, max);
        int threshold = ShazamFavor.adamThreshold();
        boolean above = threshold >= 0 && stacks >= threshold;
        boolean full = stacks >= max;
        boolean blink = full && mc.level != null && (mc.level.getGameTime() / 4L) % 2L == 0L;
        graphics.fill(X - 1, y - 1, X + BAR_WIDTH + 1, y + 4, SHADE);
        int filled = Math.round(stacks / (float) max * BAR_WIDTH);
        graphics.fill(X, y, X + filled, y + 3, full ? (blink ? FAVOR_FULL : FAVOR_ABOVE) : above ? FAVOR_ABOVE : FAVOR_FILL);
        if (threshold > 0 && threshold <= max) {   // titik Shazam melampaui Black Adam (warna Black Adam)
            int mark = X + Math.round(threshold / (float) max * BAR_WIDTH);
            graphics.fill(mark, y - 2, mark + 1, y + 5, ADAM_GOLD);
        }
        MutableComponent line = Component.literal("\u2B21 ")
                .append(Component.translatable("hud.shazammod.favor", stacks, max))
                .append("  \u2764 " + Math.round(ShazamFavor.maxHealthAt(stacks))
                        + "  \u26E8 " + ShazamFavor.percent(ShazamFavor.damageTakenAt(stacks))
                        + "  \u270A " + ShazamFavor.number(ShazamFavor.punchAt(stacks)));
        if (above) {
            line = line.append(Component.translatable("hud.shazammod.favor_above"));
        }
        graphics.pose().pushPose();
        graphics.pose().translate(X, y + 6, 0);
        graphics.pose().scale(0.75f, 0.75f, 1f);
        graphics.drawString(font, line, 0, 0, full ? 0xFFFFFFFF : above ? FAVOR_TEXT_ABOVE : FAVOR_TEXT, true);
        graphics.pose().popPose();
    }

    private static void small(GuiGraphics graphics, Font font, String text, int x, int y, int color) {
        graphics.pose().pushPose();
        graphics.pose().translate(x, y, 0);
        graphics.pose().scale(0.7f, 0.7f, 1f);
        graphics.drawCenteredString(font, text, 0, 0, color);
        graphics.pose().popPose();
    }
}
