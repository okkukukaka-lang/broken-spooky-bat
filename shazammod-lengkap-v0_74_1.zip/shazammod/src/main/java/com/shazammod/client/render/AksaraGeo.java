package com.shazammod.client.render;

import com.shazammod.AksaraSkills;
import com.shazammod.ShazamMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.client.vfx.Draw;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import org.joml.Vector3f;

/**
 * 0.51 Bentuk 3D PRALAYA (orisinal, robot/android — bukan magis), menempel pada bagian badan model pemain (ikut gerak &
 * putarannya), memakai alat gambar titik Helion3Geo.Out. Angka dalam piksel model (1/16 blok).
 *
 *   kepala  : pita optik tunggal menyilang wajah, brow/visor bersudut, pelat rahang, dan ANTENA (deret spike komunikasi
 *             naik dari tengkuk) + dua pod sensor di pelipis
 *   badan   : kolar bahu bersudut, housing REAKTOR INTI di dada, rig drone di punggung, pelat pinggang, dan
 *             ROMBONGAN DRONE yang mengorbit di punggung
 *   lengan  : pauldron bahu bersudut, pelindung siku, housing ventilasi lengan bawah
 *   kaki    : pelindung lutut, pelat tulang kering
 *
 * 0.53 ENAM INTI DAYA DI BADAN: kristal inti heksagonal berwarna subsistemnya terpasang di sendi-sendi
 *   bahu (Ruang kanan, Pikiran kiri)              : berdiri di atas pauldron, dijepit kerah baja
 *   lengan bawah (Kekuatan kanan, Realitas kiri)  : rebah di pojok depan-luar lengan, dijepit dua tutup baja (juga POV)
 *   lutut (Waktu kanan, Jiwa kiri)                : menembus pojok depan pelindung lutut, dijepit dua tutup baja
 * Tiap kristal padat (permata yang kena cahaya dunia) dengan lapis cahaya bergradasi yang kilaunya beredar; redup saat
 * siaga, terang saat subsistemnya daring, dan BERKOBAR (membesar & berdenyut) tiap protokolnya dipakai. Jalur sirkuit
 * tipis menghubungkan tiap inti ke REAKTOR DADA (pusatnya, lebih besar & terang), dan jalurnya ikut warna inti yang
 * menyala. Drone tinggal lensa warna subsistemnya (bukan batu). Titik inti, reaktor & drone yang benar-benar digambar
 * dicatat (Look.points) buat aliran daya & pendar di AksaraFx, supaya pas di pose apa pun.
 *
 * 0.55 FASE ARMOR (Look.phase / Look.cores, dari PralayaProgress lewat status pemain):
 *   Mk-I       rangka & pelat dasar, sirkuit redup; dudukan inti yang intinya belum ditemukan KOSONG (sumbat gelap)
 *   Enhanced   + pelat dada & paha tambahan, paket pendorong ganda di punggung, pendorong di telapak kaki (menyala
 *              saat terbang, berdenyut pelan saat diam), sirkuit penuh
 *   Fase Dewa  + trim baja-sampanye, ROMBONGAN DRONE (cuma di fase ini), sirkuit paling terang
 */
public final class AksaraGeo {
    public static final ResourceLocation GOLD = ShazamMod.id("textures/entity/aksara/gold.png");   // logam trim (baja sikat)
    public static final ResourceLocation PLATE = ShazamMod.id("textures/entity/aksara/plate.png");
    /**
     * Titik yang dicatat tiap frame: 0-5 inti daya, 6 reaktor dada, 7 tengah badan, 8-13 drone, 14-15 mulut pendorong
     * punggung, 16-17 telapak kaki (0.55, pendorong).
     */
    public static final int POINTS = 18;
    private static final int FULLBRIGHT = 15728880;
    private static final int STEEL = 0x3C424C, DARK = 0x20222A, DRONE = 0x2A2D36;
    private static final int RED_GLOW = 0xFF2A32, WHITE_GLOW = 0xFFF0EC;

    private AksaraGeo() {}

    /** Keadaan cahaya yang dihitung AksaraLayer dari AksaraFx (per pemain, per frame). */
    public static final class Look {
        public float age;          // waktu (tick + pt)
        public float spin;         // putaran tambahan rombongan drone (dijumlahkan AksaraFx, mulus saat Singularitas)
        public float purna;        // 0..1 Protokol Singularitas
        public float flare;        // 0..1 kilatan sesudah skill
        public float discsOut;     // 0..1 drone sedang dilempar (rig kosong)
        public final float[] disc = new float[6];   // 0..1 terang tiap inti daya
        public int active = -1;    // inti yang sedang dipakai skill (-1 = tidak ada)
        public float activeK;      // 0..1 kuatnya warna inti itu di reaktor, optik & sirkuit
        /** Diisi render(): titik inti, reaktor, tengah badan & drone relatif ke kamera (blok); NaN = tidak digambar. */
        public final float[] points = new float[POINTS * 3];
        public boolean pointsValid;
        /** 0.55 fase armor 1-3 (Mk-I, Enhanced, Fase Dewa) & inti yang sudah terpasang (bit 0-5). */
        public int phase = 3;
        public int cores = 0b111111;
        public float thrust;       // 0..1 pendorong menyala (terbang)

        public boolean hasCore(int i) {
            return (cores & (1 << i)) != 0;
        }
    }

    private static final int CHAMPAGNE = 0xFFE6B8;   // 0.55 trim Fase Dewa
    private static final int THRUST = 0x8FE4FF;      // 0.55 nyala pendorong

    /** 0.55 Enhanced: pelat dada bersudut, rusuk perut, dan paket pendorong ganda di punggung. */
    private static void enhancedFrame(Helion3Geo.Out o) {
        for (int s = -1; s <= 1; s += 2) {
            o.slab(2.3f * s, 2.7f, -2.42f, 1.45f, 0.25f * s, 0f, 0f, 1.05f, 0f, 0f, 0f, 0.16f);   // pelat dada
            o.slab(1.35f * s, 8.6f, -2.4f, 0.95f, 0f, 0f, 0f, 0.28f, 0f, 0f, 0f, 0.12f);           // rusuk perut
            o.slab(1.35f * s, 9.5f, -2.4f, 0.9f, 0f, 0f, 0f, 0.24f, 0f, 0f, 0f, 0.12f);
            o.prism(1.75f * s, 4.0f, 2.45f, 2.0f * s, 8.4f, 3.7f, 0.72f, 0.55f, 0.72f, 0.62f, true); // tabung pendorong
        }
    }

    /** 0.55 Enhanced: pelat paha & rumah pendorong telapak kaki. */
    private static void enhancedLeg(Helion3Geo.Out o) {
        o.slab(0f, 3.4f, -2.2f, 1.7f, 0f, 0f, 0f, 1.6f, 0f, 0f, 0f, 0.22f);    // pelat paha
        o.slab(0f, 11.75f, 0f, 1.9f, 0f, 0f, 0f, 0.32f, 0f, 0f, 0f, 1.9f);      // rumah pendorong telapak
    }

    /** 0.55 Nyala pendorong: mulut tabung punggung & telapak kaki (cahaya). */
    private static void thrusterGlow(Helion3Geo.Out o, boolean body) {
        if (body) {
            for (int s = -1; s <= 1; s += 2) {
                o.gem(2.0f * s, 8.55f, 3.72f, 0.46f, 0.46f, 0.12f);
            }
        } else {
            o.slab(0f, 12.1f, 0f, 1.15f, 0f, 0f, 0f, 0.05f, 0f, 0f, 0f, 1.15f);
        }
    }

    // ------------------------------------------------------------------ bentuk (rangka logam)

    /** Brow/visor bersudut, pelat rahang, pod sensor pelipis. */
    private static void helm(Helion3Geo.Out o) {
        o.slab(0f, -5.35f, -4.2f, 3.7f, 0f, 0f, 0f, 0.5f, 0.1f, 0f, -0.1f, 0.3f);    // brow visor
        o.slab(0f, -1.1f, -4.15f, 3.0f, 0f, 0f, 0f, 0.9f, 0.08f, 0f, -0.08f, 0.28f);  // pelat rahang
        for (int s = -1; s <= 1; s += 2) {
            o.slab(4.1f * s, -4.2f, 0f, 0.3f, 0f, 0f, 0f, 1.3f, 0f, 0f, 0f, 1.5f);     // pod sensor pelipis
            o.slab(4.3f * s, -4.2f, -1.2f, 0.18f, 0f, 0f, 0f, 0.5f, 0f, 0f, 0f, 0.4f);
        }
    }

    /** Antena komunikasi: tiga spike naik dari tengkuk + fin kecil (mengganti mahkota). */
    private static void antenna(Helion3Geo.Out o) {
        o.prism(0f, -8.0f, 2.6f, 0.2f, -13.6f, 3.6f, 0.26f, 0.06f, 0.26f, 0.06f, true);      // antena utama
        for (int s = -1; s <= 1; s += 2) {
            o.prism(2.0f * s, -7.8f, 2.4f, 2.9f * s, -11.6f, 3.4f, 0.2f, 0.05f, 0.2f, 0.05f, true);
        }
        o.slab(0f, -8.1f, 1.4f, 0.14f, 0f, 0f, 0f, 1.0f, 0f, 0.3f, 0f, 1.6f);                // fin punggung kepala
        o.slab(0f, -7.7f, -4.2f, 1.4f, 0f, 0f, 0f, 0.3f, 0f, 0f, 0f, 0.2f);                  // visor atas dahi
    }

    /** Kolar bahu, housing reaktor, rig drone punggung, pelat pinggang. */
    private static void frame(Helion3Geo.Out o) {
        for (int s = -1; s <= 1; s += 2) {                                                   // kolar bahu bersudut
            o.slab(2.8f * s, 1.2f, -1.4f, 1.5f, 0f, 0f, 0f, 0.7f, 0.2f, 0f, -0.2f, 1.3f);
        }
        o.slab(0f, 1.0f, -2.35f, 1.6f, 0f, 0f, 0f, 0.6f, 0f, 0f, 0f, 0.25f);                 // pelat dada atas
        // housing reaktor inti (bingkai di sekeliling inti)
        for (int s = -1; s <= 1; s += 2) {
            o.slab(1.9f * s, 6.0f, -2.35f, 0.4f, 0f, 0f, 0f, 1.7f, 0f, 0f, 0f, 0.3f);
            o.slab(0f, 4.2f + 1.8f * (s + 1) / 2f, -2.35f, 1.9f, 0f, 0f, 0f, 0.35f, 0f, 0f, 0f, 0.3f);
        }
        o.slab(0f, 11.2f, 0f, 4.2f, 0f, 0f, 0f, 0.6f, 0f, 0f, 0f, 2.25f);                    // pelat pinggang
        o.slab(0f, 11.2f, -2.35f, 1.4f, 0f, 0f, 0f, 1.0f, 0f, 0f, 0f, 0.25f);                // gesper depan
        // rig drone di punggung
        o.slab(0f, 3.2f, 2.35f, 1.7f, 0f, 0f, 0f, 2.0f, 0f, 0f, 0f, 0.35f);
        for (int s = -1; s <= 1; s += 2) {
            o.prism(1.3f * s, 2.0f, 2.5f, 2.2f * s, 1.2f, 3.4f, 0.2f, 0.12f, 0.9f, 0.4f, true);   // rel peluncur
        }
    }

    /** Pauldron bahu bersudut + housing ventilasi lengan bawah. */
    private static void armPlate(Helion3Geo.Out o) {
        o.slab(-1.4f, -2.55f, 0f, 2.5f, -0.6f, 0f, 0.2f, 0.75f, 0f, 0f, 0f, 2.45f);          // pauldron
        o.slab(-1.0f, 7.4f, -1.1f, 1.7f, 0f, 0f, 0f, 1.6f, 0f, 0f, 0f, 0.5f);                // housing ventilasi depan
    }

    /** Trim baja: tepi pauldron, pelindung siku, gelang. */
    private static void armTrim(Helion3Geo.Out o) {
        o.slab(-1.45f, -3.1f, 0f, 2.55f, -0.6f, 0f, 0.2f, 0.18f, 0f, 0f, 0f, 2.55f);         // tepi pauldron
        o.slab(-1.0f, 4.6f, 0f, 2.3f, 0f, 0f, 0f, 0.6f, 0f, 0f, 0f, 2.3f);                   // pelindung siku
        o.slab(-1.0f, 9.4f, 0f, 2.25f, 0f, 0f, 0f, 0.4f, 0f, 0f, 0f, 2.25f);                 // gelang
    }

    /** Pelindung lutut + pelat tulang kering (baja). */
    private static void legTrim(Helion3Geo.Out o) {
        o.slab(0f, 6.2f, -1.0f, 2.2f, 0f, 0f, 0f, 0.7f, 0f, 0f, 0f, 1.4f);                   // lutut
        o.slab(0f, 9.0f, -2.1f, 1.5f, 0f, 0f, 0f, 1.8f, 0f, 0f, 0f, 0.4f);                   // tulang kering
        o.slab(0f, 10.9f, 0f, 2.18f, 0f, 0f, 0f, 0.4f, 0f, 0f, 0f, 2.18f);                   // gelang kaki
    }

    // ------------------------------------------------------------------ enam inti daya di badan

    private static final int FACETS = 6;       // kristal inti heksagonal
    private static final float LIGHT = 0.9f;   // arah awal kilau yang beredar mengelilingi kristal (radian)
    private static final int ARM_R = 0, ARM_L = 1, LEG_R = 2, LEG_L = 3;

    /**
     * Dudukan kristal (koordinat bagian sisi kanan; sisi kiri dicerminkan): titik tengah, sumbu panjang, jari-jari,
     * setengah panjang, setengah pinggang; standing = berdiri dengan kerah di pangkal, kalau tidak dijepit dua tutup.
     */
    private record Mount(float x, float y, float z, float ax, float ay, float az, float w, float h, float band,
                         boolean standing) {}

    private static final Mount SHOULDER = new Mount(-2.71f, -4.16f, 0f, -0.33f, -0.944f, 0f, 0.8f, 1.7f, 0.5f, true);
    private static final Mount FOREARM = new Mount(-2.9f, 7.0f, -1.9f, 0f, 1f, 0f, 0.8f, 1.85f, 0.55f, false);
    private static final Mount KNEE = new Mount(-1.55f, 6.3f, -2.25f, 0f, 1f, 0f, 0.75f, 1.45f, 0.45f, false);
    /** Inti ke-i: bagian badan & dudukannya (Kekuatan lengan kanan, Ruang bahu kanan, Pikiran bahu kiri, ...). */
    private static final int[] CORE_PART = {ARM_R, ARM_R, ARM_L, ARM_L, LEG_R, LEG_L};
    private static final Mount[] CORE_MOUNT = {FOREARM, SHOULDER, SHOULDER, FOREARM, KNEE, KNEE};

    /** Kerah baja di pangkal kristal yang berdiri / dua tutup di ujung kristal yang rebah. */
    private static void mountSteel(Helion3Geo.Out o, Mount m) {
        float[] b = basis(m.ax(), m.ay(), m.az());
        if (m.standing()) {
            float bx = m.x() - m.ax() * (m.h() - 0.8f), by = m.y() - m.ay() * (m.h() - 0.8f), bz = m.z() - m.az() * (m.h() - 0.8f);
            o.slab(bx, by, bz, b[0] * 0.95f, b[1] * 0.95f, b[2] * 0.95f, m.ax() * 0.28f, m.ay() * 0.28f, m.az() * 0.28f,
                    b[3] * 0.95f, b[4] * 0.95f, b[5] * 0.95f);
            return;
        }
        for (int s = -1; s <= 1; s += 2) {
            float cx = m.x() + s * m.ax() * m.h(), cy = m.y() + s * m.ay() * m.h(), cz = m.z() + s * m.az() * m.h();
            o.slab(cx, cy, cz, b[0] * m.w() * 0.7f, b[1] * m.w() * 0.7f, b[2] * m.w() * 0.7f, m.ax() * 0.28f,
                    m.ay() * 0.28f, m.az() * 0.28f, b[3] * m.w() * 0.75f, b[4] * m.w() * 0.75f, b[5] * m.w() * 0.75f);
        }
    }

    /** Dua sumbu tegak lurus sumbu kristal {p1x,p1y,p1z, p2x,p2y,p2z}. */
    private static float[] basis(float ax, float ay, float az) {
        float rx = 0f, ry = 0f, rz = 1f;
        if (Math.abs(az) > 0.9f) {
            rx = 1f;
            rz = 0f;
        }
        float px = ay * rz - az * ry, py = az * rx - ax * rz, pz = ax * ry - ay * rx;
        float pl = Mth.sqrt(px * px + py * py + pz * pz);
        px /= pl;
        py /= pl;
        pz /= pl;
        return new float[] {px, py, pz, ay * pz - az * py, az * px - ax * pz, ax * py - ay * px};
    }

    /** Membesar saat menyala (sampai +18%), berdenyut saat protokolnya sedang dipakai. */
    private static float grow(int i, Look look) {
        float g = 1f + 0.18f * Mth.clamp((look.disc[i] - 0.55f) / 0.45f, 0f, 1f);
        if (i == look.active) {
            g += 0.07f * look.activeK * Mth.sin(look.age * 0.9f);
        }
        return g;
    }

    /** Badan permata kristal (padat, kena cahaya dunia): prisma heksagonal pendek bermata dua di sepanjang sumbunya. */
    private static void crystalBody(Helion3Geo.Out o, Mount m, float scale) {
        float[] b = basis(m.ax(), m.ay(), m.az());
        float w = m.w() * scale, h = m.h() * scale, band = m.band() * scale;
        for (int f = 0; f < FACETS; f++) {
            float a0 = 0.3f + f * Mth.TWO_PI / FACETS, a1 = 0.3f + (f + 1) * Mth.TWO_PI / FACETS;
            float[] p0 = ring(m, b, a0, w), p1 = ring(m, b, a1, w);
            float tx = m.x() + m.ax() * h, ty = m.y() + m.ay() * h, tz = m.z() + m.az() * h;
            float ux = m.ax() * band, uy = m.ay() * band, uz = m.az() * band;
            float bx = m.x() - m.ax() * h, by = m.y() - m.ay() * h, bz = m.z() - m.az() * h;
            o.quad(p0[0] + ux, p0[1] + uy, p0[2] + uz, p1[0] + ux, p1[1] + uy, p1[2] + uz, tx, ty, tz, tx, ty, tz,
                    m.x(), m.y(), m.z(), 0f, 0f, 1f, 1f);
            o.quad(p1[0] - ux, p1[1] - uy, p1[2] - uz, p0[0] - ux, p0[1] - uy, p0[2] - uz, bx, by, bz, bx, by, bz,
                    m.x(), m.y(), m.z(), 0f, 0f, 1f, 1f);
            o.quad(p0[0] + ux, p0[1] + uy, p0[2] + uz, p1[0] + ux, p1[1] + uy, p1[2] + uz, p1[0] - ux, p1[1] - uy,
                    p1[2] - uz, p0[0] - ux, p0[1] - uy, p0[2] - uz, m.x(), m.y(), m.z(), 0f, 0f, 1f, 1f);
        }
    }

    /**
     * Lapis cahaya kristal (bentuk sama, sedikit lebih besar): ujung-ujungnya lebih putih (inti panas), pinggangnya warna
     * subsistem, dan tiap sisi digradasi menurut arahnya terhadap kilau yang beredar mengelilingi kristal.
     */
    private static void crystalGlow(Helion3Geo.Out o, Mount m, float scale, int rgb, float k, float shimmer) {
        float[] b = basis(m.ax(), m.ay(), m.az());
        float w = m.w() * scale * 1.08f, h = m.h() * scale * 1.06f, band = m.band() * scale * 1.07f;
        int hot = Draw.mix(rgb, 0xFFFFFF, 0.55);
        for (int f = 0; f < FACETS; f++) {
            float a0 = 0.3f + f * Mth.TWO_PI / FACETS, a1 = 0.3f + (f + 1) * Mth.TWO_PI / FACETS;
            float sh = 0.62f + 0.38f * Mth.cos((a0 + a1) * 0.5f - LIGHT - shimmer);
            int tip = scale(hot, k * (0.8f + 0.2f * sh)), mid = scale(rgb, k * sh), low = scale(rgb, k * sh * 0.7f);
            float[] p0 = ring(m, b, a0, w), p1 = ring(m, b, a1, w);
            float tx = m.x() + m.ax() * h, ty = m.y() + m.ay() * h, tz = m.z() + m.az() * h;
            float bx = m.x() - m.ax() * h, by = m.y() - m.ay() * h, bz = m.z() - m.az() * h;
            float ux = m.ax() * band, uy = m.ay() * band, uz = m.az() * band;
            float cx = m.x(), cy = m.y(), cz = m.z();
            tri(o, tx, ty, tz, tip, p0[0] + ux, p0[1] + uy, p0[2] + uz, mid, p1[0] + ux, p1[1] + uy, p1[2] + uz, mid, cx, cy, cz);
            tri(o, bx, by, bz, tip, p1[0] - ux, p1[1] - uy, p1[2] - uz, low, p0[0] - ux, p0[1] - uy, p0[2] - uz, low, cx, cy, cz);
            tri(o, p0[0] + ux, p0[1] + uy, p0[2] + uz, mid, p1[0] + ux, p1[1] + uy, p1[2] + uz, mid, p1[0] - ux, p1[1] - uy,
                    p1[2] - uz, low, cx, cy, cz);
            tri(o, p0[0] + ux, p0[1] + uy, p0[2] + uz, mid, p1[0] - ux, p1[1] - uy, p1[2] - uz, low, p0[0] - ux, p0[1] - uy,
                    p0[2] - uz, low, cx, cy, cz);
        }
    }

    /** Titik di lingkar pinggang kristal (sudut a, jari-jari w) di sekitar sumbunya. */
    private static float[] ring(Mount m, float[] b, float a, float w) {
        float c = Mth.cos(a) * w, s = Mth.sin(a) * w;
        return new float[] {m.x() + b[0] * c + b[3] * s, m.y() + b[1] * c + b[4] * s, m.z() + b[2] * c + b[5] * s};
    }

    /** Segitiga a-b-c (c dobel) dengan warna per titik, diurutkan berlawanan jarum jam dilihat dari luar (mx,my,mz). */
    private static void tri(Helion3Geo.Out o, float ax, float ay, float az, int ca, float bx, float by, float bz, int cb,
                            float cx, float cy, float cz, int cc, float mx, float my, float mz) {
        float e1x = bx - ax, e1y = by - ay, e1z = bz - az;
        float e2x = cx - ax, e2y = cy - ay, e2z = cz - az;
        float nx = e1y * e2z - e1z * e2y, ny = e1z * e2x - e1x * e2z, nz = e1x * e2y - e1y * e2x;
        float nl = Mth.sqrt(nx * nx + ny * ny + nz * nz);
        if (nl < 1.0E-7f) {
            return;
        }
        nx /= nl;
        ny /= nl;
        nz /= nl;
        float fx = (ax + bx + cx) / 3f - mx, fy = (ay + by + cy) / 3f - my, fz = (az + bz + cz) / 3f - mz;
        boolean inward = nx * fx + ny * fy + nz * fz < 0f;
        if (inward) {
            nx = -nx;
            ny = -ny;
            nz = -nz;
        }
        // lapisan cahaya (RenderType.eyes) membuang sisi belakang: sama seperti Out.quad, cermin membalik putarannya
        if (inward != (o.sx < 0f)) {
            vert(o, ax, ay, az, ca, 0f, 1f, nx, ny, nz);
            vert(o, cx, cy, cz, cc, 1f, 0f, nx, ny, nz);
            vert(o, cx, cy, cz, cc, 1f, 0f, nx, ny, nz);
            vert(o, bx, by, bz, cb, 1f, 1f, nx, ny, nz);
        } else {
            vert(o, ax, ay, az, ca, 0f, 1f, nx, ny, nz);
            vert(o, bx, by, bz, cb, 1f, 1f, nx, ny, nz);
            vert(o, cx, cy, cz, cc, 1f, 0f, nx, ny, nz);
            vert(o, cx, cy, cz, cc, 1f, 0f, nx, ny, nz);
        }
    }

    private static void vert(Helion3Geo.Out o, float x, float y, float z, int rgb, float u, float v, float nx, float ny,
                             float nz) {
        o.r = (rgb >> 16) & 255;
        o.g = (rgb >> 8) & 255;
        o.b = rgb & 255;
        o.v(x, y, z, u, v, nx, ny, nz);
    }

    /** Warna x kekuatan 0..1 (cahaya aditif: makin kecil makin redup). */
    private static int scale(int rgb, float k) {
        k = Mth.clamp(k, 0f, 1f);
        return ((int) (((rgb >> 16) & 255) * k) << 16) | ((int) (((rgb >> 8) & 255) * k) << 8) | (int) ((rgb & 255) * k);
    }

    /** Garis sirkuit tipis dari (ax,ay) ke (bx,by) di bidang z (permukaan depan armor). */
    private static void trace(Helion3Geo.Out o, float ax, float ay, float bx, float by, float z, float half) {
        float ux = (bx - ax) * 0.5f, uy = (by - ay) * 0.5f;
        float len = Mth.sqrt(ux * ux + uy * uy);
        if (len < 1.0E-4f) {
            return;
        }
        o.slab((ax + bx) * 0.5f, (ay + by) * 0.5f, z, ux, uy, 0f, -uy / len * half, ux / len * half, 0f, 0f, 0f, 0.04f);
    }

    /** Warna & kuat jalur sirkuit sebuah anggota badan: ikut inti paling terang di situ (merah redup saat siaga). */
    private static void limbTint(Helion3Geo.Out o, Look look, int a, int b, float fade) {
        int i = b >= 0 && look.disc[b] > look.disc[a] ? b : a;
        float lit = Mth.clamp((look.disc[i] - 0.45f) / 0.55f, 0f, 1f);
        Helion3Geo.tint(o, Draw.mix(RED_GLOW, AksaraSkills.RGB[i], 0.35 + 0.65 * lit), (0.3f + 0.7f * lit) * fade);
    }

    /** Inti ke-i (kristal padat) di bagiannya; dipanggil per bagian badan dengan sx bagiannya. */
    private static void coreBodies(Helion3Geo.Out o, Look look, int part) {
        for (int i = 0; i < 6; i++) {
            if (CORE_PART[i] != part) {
                continue;
            }
            if (!look.hasCore(i)) {   // 0.55 intinya belum ditemukan: dudukan kosong bersumbat gelap
                Helion3Geo.tint(o, 0x16181E, 1f);
                crystalBody(o, CORE_MOUNT[i], 0.5f);
                continue;
            }
            Helion3Geo.tint(o, AksaraSkills.RGB[i], 0.42f + 0.25f * look.disc[i]);
            crystalBody(o, CORE_MOUNT[i], grow(i, look));
        }
    }

    private static void coreSteel(Helion3Geo.Out o, int part) {
        for (int i = 0; i < 6; i++) {
            if (CORE_PART[i] == part) {
                mountSteel(o, CORE_MOUNT[i]);
            }
        }
    }

    /** Lapis cahaya inti di bagiannya + jalur sirkuit anggota badan itu; titik intinya dicatat. */
    private static void coreGlows(Helion3Geo.Out o, Look look, int part, boolean record) {
        for (int i = 0; i < 6; i++) {
            if (CORE_PART[i] != part) {
                continue;
            }
            Mount m = CORE_MOUNT[i];
            float lit = look.disc[i];
            float k = Mth.clamp(0.15f + 0.85f * (float) Math.pow(lit, 1.3), 0f, 1f);
            if (look.hasCore(i)) {   // 0.55 dudukan kosong nggak bercahaya (titiknya tetap dicatat buat efek)
                crystalGlow(o, m, grow(i, look), AksaraSkills.RGB[i], k, look.age * 0.06f + i);
            }
            if (record) {
                store(o, look, i, m.x(), m.y(), m.z());
            }
        }
        if (part == ARM_R || part == ARM_L) {   // sisi luar lengan atas: dari pauldron turun ke inti lengan bawah
            limbTint(o, look, part == ARM_R ? 0 : 3, part == ARM_R ? 1 : 2, 1f);
            o.slab(-3.32f, 1.75f, -1.0f, 0.04f, 0f, 0f, 0f, 3.0f, 0f, 0f, 0f, 0.14f);
        } else {                                // depan paha: dari pinggul turun ke inti lutut
            limbTint(o, look, part == LEG_R ? 4 : 5, -1, 1f);
            o.slab(-1.55f, 2.35f, -2.33f, 0.14f, 0f, 0f, 0f, 2.1f, 0f, 0f, 0f, 0.04f);
        }
    }

    // ------------------------------------------------------------------ rombongan drone (lensa warna, bukan batu)

    private static final int SIDES = 8;        // cincin drone oktagon: terlihat mekanis

    /** Cincin luar drone (baja) di tepi oktagon: muka depan, belakang, dan dinding luar. */
    private static void rim(Helion3Geo.Out o, float cx, float cy, float cz, float r, float width, float thick, float spin) {
        float z0 = cz - thick * 0.5f, z1 = cz + thick * 0.5f;
        float ri = r - width;
        for (int i = 0; i < SIDES; i++) {
            float a0 = spin + i * Mth.TWO_PI / SIDES, a1 = spin + (i + 1) * Mth.TWO_PI / SIDES;
            float c0 = Mth.cos(a0), s0 = Mth.sin(a0), c1 = Mth.cos(a1), s1 = Mth.sin(a1);
            o.quad(cx + c0 * ri, cy + s0 * ri, z1, cx + c0 * r, cy + s0 * r, z1, cx + c1 * r, cy + s1 * r, z1,
                    cx + c1 * ri, cy + s1 * ri, z1, cx, cy, cz, 0f, 0f, 1f, 1f);
            o.quad(cx + c1 * ri, cy + s1 * ri, z0, cx + c1 * r, cy + s1 * r, z0, cx + c0 * r, cy + s0 * r, z0,
                    cx + c0 * ri, cy + s0 * ri, z0, cx, cy, cz, 0f, 0f, 1f, 1f);
            o.quad(cx + c0 * r, cy + s0 * r, z0, cx + c1 * r, cy + s1 * r, z0, cx + c1 * r, cy + s1 * r, z1,
                    cx + c0 * r, cy + s0 * r, z1, cx, cy, cz, 0f, 0f, 1f, 1f);
        }
    }

    /** Muka oktagon datar di bidang z (badan drone / lensa), menghadap menjauhi pusat drone; r0 > 0 = berlubang. */
    private static void ringFace(Helion3Geo.Out o, float cx, float cy, float cz, float r0, float r1, float z, float spin) {
        for (int i = 0; i < SIDES; i++) {
            float a0 = spin + i * Mth.TWO_PI / SIDES, a1 = spin + (i + 1) * Mth.TWO_PI / SIDES;
            float c0 = Mth.cos(a0), s0 = Mth.sin(a0), c1 = Mth.cos(a1), s1 = Mth.sin(a1);
            o.quad(cx + c0 * r0, cy + s0 * r0, z, cx + c0 * r1, cy + s0 * r1, z, cx + c1 * r1, cy + s1 * r1, z,
                    cx + c1 * r0, cy + s1 * r0, z, cx, cy, cz, 0f, 0f, 1f, 1f);
        }
    }

    /** Titik pusat drone ke-i di ruang badan (harus sama dengan AksaraFx.orbitPoint); pusatnya di tengah punggung
     *  supaya drone nggak menutupi inti bahu dari belakang. */
    private static float[] discCenter(int i, Look look) {
        float orbit = 9.0f + 1.6f * look.purna;
        float a = look.age * 0.012f + look.spin + i * Mth.TWO_PI / 6f + Mth.HALF_PI;
        float bob = Mth.sin(look.age * 0.09f + i) * 0.35f;
        return new float[] {Mth.cos(a) * orbit, 5.0f - Mth.sin(a) * orbit + bob, 6.6f + 0.6f * look.purna};
    }

    private static float discRadius(Look look) {
        return 2.0f + 0.6f * look.purna;
    }

    /** Catat titik (piksel model di ruang bagian yang sedang digambar) sebagai posisi relatif kamera dalam blok. */
    private static void store(Helion3Geo.Out o, Look look, int i, float x, float y, float z) {
        Vector3f v = o.pose.pose().transformPosition(new Vector3f(x * o.sx / 16f, y / 16f, z / 16f));
        look.points[i * 3] = v.x;
        look.points[i * 3 + 1] = v.y;
        look.points[i * 3 + 2] = v.z;
    }

    // ------------------------------------------------------------------ gambar

    /** Semua bagian 3D di badan (sesudah kulit & cahaya kulit digambar AksaraLayer). */
    public static void render(ModelPart head, ModelPart body, ModelPart rightArm, ModelPart leftArm, ModelPart rightLeg,
                              ModelPart leftLeg, PoseStack ps, MultiBufferSource buffers, int light, int overlay, Look look) {
        Helion3Geo.Out o = new Helion3Geo.Out();
        o.light = light;
        o.overlay = overlay;
        java.util.Arrays.fill(look.points, Float.NaN);
        boolean rig = look.discsOut < 0.5f && look.phase >= 3;   // 0.55 drone cuma ada di Fase Dewa
        boolean enhanced = look.phase >= 2;
        float r = discRadius(look);
        // 1) trim baja (antena, kolar, housing, pauldron edge, siku/lutut, dudukan inti, cincin drone)
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GOLD));
        Helion3Geo.tint(o, look.phase >= 3 ? CHAMPAGNE : 0xFFFFFF, 1f);
        Helion3Geo.part(head, ps, o, 1f, AksaraGeo::antenna);
        Helion3Geo.part(body, ps, o, 1f, AksaraGeo::frame);
        Helion3Geo.part(rightArm, ps, o, 1f, out -> {
            armTrim(out);
            coreSteel(out, ARM_R);
        });
        Helion3Geo.part(leftArm, ps, o, -1f, out -> {
            armTrim(out);
            coreSteel(out, ARM_L);
        });
        Helion3Geo.part(rightLeg, ps, o, 1f, out -> {
            legTrim(out);
            coreSteel(out, LEG_R);
        });
        Helion3Geo.part(leftLeg, ps, o, -1f, out -> {
            legTrim(out);
            coreSteel(out, LEG_L);
        });
        if (rig) {
            Helion3Geo.part(body, ps, o, 1f, out -> {
                for (int i = 0; i < 6; i++) {
                    float[] c = discCenter(i, look);
                    rim(out, c[0], c[1], c[2], r, 0.4f, 0.75f, look.age * 0.05f + i);
                }
            });
        }
        // 2) pelat gelap: helm/visor (baja), pauldron & housing lengan (grafit), badan drone (logam gelap)
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(PLATE));
        Helion3Geo.tint(o, STEEL, 1f);
        Helion3Geo.part(head, ps, o, 1f, AksaraGeo::helm);
        Helion3Geo.tint(o, DARK, 1f);
        Helion3Geo.part(rightArm, ps, o, 1f, AksaraGeo::armPlate);
        Helion3Geo.part(leftArm, ps, o, -1f, AksaraGeo::armPlate);
        if (enhanced) {   // 0.55 Enhanced: pelat tambahan & pendorong
            Helion3Geo.part(body, ps, o, 1f, AksaraGeo::enhancedFrame);
            Helion3Geo.part(rightLeg, ps, o, 1f, AksaraGeo::enhancedLeg);
            Helion3Geo.part(leftLeg, ps, o, -1f, AksaraGeo::enhancedLeg);
        }
        if (rig) {
            Helion3Geo.tint(o, DRONE, 1f);
            Helion3Geo.part(body, ps, o, 1f, out -> {
                for (int i = 0; i < 6; i++) {
                    float[] c = discCenter(i, look);
                    float spin = look.age * 0.05f + i;
                    ringFace(out, c[0], c[1], c[2], 0f, r - 0.3f, c[2] + 0.275f, spin);
                    ringFace(out, c[0], c[1], c[2], 0f, r - 0.3f, c[2] - 0.275f, spin);
                }
            });
        }
        // 2b) badan permata keenam kristal inti: warna subsistem yang dalam, kena cahaya dunia
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(Draw.WHITE));
        Helion3Geo.part(rightArm, ps, o, 1f, out -> coreBodies(out, look, ARM_R));
        Helion3Geo.part(leftArm, ps, o, -1f, out -> coreBodies(out, look, ARM_L));
        Helion3Geo.part(rightLeg, ps, o, 1f, out -> coreBodies(out, look, LEG_R));
        Helion3Geo.part(leftLeg, ps, o, -1f, out -> coreBodies(out, look, LEG_L));
        // 3) cahaya: pita optik, REAKTOR PUSAT (warna inti yang dipakai), jalur sirkuit, kristal inti, lensa drone
        o.vc = buffers.getBuffer(RenderType.eyes(Draw.WHITE));
        o.light = FULLBRIGHT;
        o.overlay = OverlayTexture.NO_OVERLAY;
        float hot = Mth.clamp((0.75f + 0.4f * look.purna + 0.5f * look.flare + 0.3f * look.activeK)
                * (look.phase <= 1 ? 0.72f : 1f), 0f, 1f);   // 0.55 Mk-I: optik & reaktor lebih redup
        int base = look.purna > 0.3f ? WHITE_GLOW : RED_GLOW;
        int tone = look.active >= 0 && look.active < 6 ? Draw.mix(base, AksaraSkills.RGB[look.active], 0.85 * look.activeK) : base;
        Helion3Geo.tint(o, Draw.mix(base, tone, 0.6), hot);
        Helion3Geo.part(head, ps, o, 1f, out -> {
            out.slab(0f, -4.5f, -4.46f, 2.85f, 0f, 0f, 0f, 0.3f, 0f, 0f, 0f, 0.05f);         // pita optik tunggal
            out.slab(0f, -7.55f, -4.46f, 0.35f, 0f, 0f, 0f, 0.18f, 0f, 0f, 0f, 0.04f);       // sensor dahi
        });
        Helion3Geo.part(body, ps, o, 1f, out -> {
            // reaktor pusat: inti + halo, lebih besar & terang sejak 0.53
            Helion3Geo.tint(out, tone, hot);
            out.gem(0f, 6.0f, -2.55f, 1.3f, 1.4f, 0.45f);
            out.slab(0f, 6.0f, -2.55f, 0.12f, 0f, 0f, 0f, 1.75f, 0f, 0f, 0f, 0.05f);         // garis inti vertikal
            out.slab(0f, 6.0f, -2.55f, 1.75f, 0f, 0f, 0f, 0.12f, 0f, 0f, 0f, 0.05f);
            Helion3Geo.tint(out, tone, 0.3f * hot);
            out.gem(0f, 6.0f, -2.6f, 1.85f, 2.0f, 0.5f);
            // jalur sirkuit dari reaktor ke kedua bahu & kedua pinggul (warna inti yang menyala di anggota badan itu)
            for (int s = -1; s <= 1; s += 2) {
                limbTint(out, look, s < 0 ? 0 : 3, s < 0 ? 1 : 2, 1f);
                trace(out, 1.1f * s, 4.8f, 3.6f * s, 0.9f, -2.36f, 0.12f);
                limbTint(out, look, s < 0 ? 4 : 5, -1, 1f);
                trace(out, 0.95f * s, 7.25f, 2.4f * s, 10.6f, -2.36f, 0.12f);
            }
            // titik yang benar-benar digambar frame ini, buat aliran daya & pendar AksaraFx
            store(out, look, 6, 0f, 6.0f, -2.55f);
            store(out, look, 7, 0f, 6.0f, 0f);
            if (rig) {
                for (int i = 0; i < 6; i++) {
                    float[] c = discCenter(i, look);
                    store(out, look, 8 + i, c[0], c[1], c[2]);
                }
            }
        });
        Helion3Geo.part(rightArm, ps, o, 1f, out -> coreGlows(out, look, ARM_R, true));
        Helion3Geo.part(leftArm, ps, o, -1f, out -> coreGlows(out, look, ARM_L, true));
        Helion3Geo.part(rightLeg, ps, o, 1f, out -> coreGlows(out, look, LEG_R, true));
        Helion3Geo.part(leftLeg, ps, o, -1f, out -> coreGlows(out, look, LEG_L, true));
        if (enhanced) {   // 0.55 nyala pendorong: berdenyut pelan saat diam, menyala penuh saat terbang
            float idle = 0.22f + 0.08f * Mth.sin(look.age * 0.3f);
            float k = Mth.clamp(idle + (0.75f + 0.1f * Mth.sin(look.age * 2.7f)) * look.thrust, 0f, 1f);
            Helion3Geo.tint(o, THRUST, k);
            Helion3Geo.part(body, ps, o, 1f, out -> {
                thrusterGlow(out, true);
                store(out, look, 14, 2.0f, 8.6f, 3.9f);
                store(out, look, 15, -2.0f, 8.6f, 3.9f);
            });
            Helion3Geo.part(rightLeg, ps, o, 1f, out -> {
                thrusterGlow(out, false);
                store(out, look, 16, 0f, 12.2f, 0f);
            });
            Helion3Geo.part(leftLeg, ps, o, -1f, out -> {
                thrusterGlow(out, false);
                store(out, look, 17, 0f, 12.2f, 0f);
            });
        }
        look.pointsValid = true;
        if (!rig) {
            return;
        }
        float fade = Mth.clamp(1f - look.discsOut * 2f, 0f, 1f);
        Helion3Geo.part(body, ps, o, 1f, out -> {
            for (int i = 0; i < 6; i++) {   // lensa drone: warna subsistemnya, redup (batunya ada di badan)
                float[] c = discCenter(i, look);
                float spin = look.age * 0.05f + i;
                Helion3Geo.tint(out, AksaraSkills.RGB[i], (0.25f + 0.35f * look.disc[i]) * fade);
                ringFace(out, c[0], c[1], c[2], 0f, 0.85f, c[2] + 0.3f, spin);
                ringFace(out, c[0], c[1], c[2], 0f, 0.85f, c[2] - 0.3f, spin);
            }
        });
        if (look.purna > 0.05f) {   // Singularitas: tali daya putih-panas menghubungkan keenam drone
            Helion3Geo.tint(o, WHITE_GLOW, look.purna * 0.8f);
            Helion3Geo.part(body, ps, o, 1f, out -> {
                for (int i = 0; i < 6; i++) {
                    float[] a = discCenter(i, look), b = discCenter((i + 1) % 6, look);
                    out.prism(a[0], a[1], a[2], b[0], b[1], b[2], 0.12f, 0.12f, 0f, 1f, false);
                }
            });
        }
    }

    /** Lengan orang pertama: trim, pelat, dan inti lengan bawahnya (Kekuatan kanan / Realitas kiri) yang ikut menyala. */
    public static void renderArm(ModelPart arm, boolean left, PoseStack ps, MultiBufferSource buffers, int light, Look look) {
        Helion3Geo.Out o = new Helion3Geo.Out();
        o.light = light;
        o.overlay = OverlayTexture.NO_OVERLAY;
        float sx = left ? -1f : 1f;
        int part = left ? ARM_L : ARM_R;
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(GOLD));
        Helion3Geo.tint(o, look.phase >= 3 ? CHAMPAGNE : 0xFFFFFF, 1f);
        Helion3Geo.part(arm, ps, o, sx, out -> {
            armTrim(out);
            coreSteel(out, part);
        });
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(PLATE));
        Helion3Geo.tint(o, DARK, 1f);
        Helion3Geo.part(arm, ps, o, sx, AksaraGeo::armPlate);
        o.vc = buffers.getBuffer(RenderType.entityCutoutNoCull(Draw.WHITE));
        Helion3Geo.part(arm, ps, o, sx, out -> coreBodies(out, look, part));
        o.vc = buffers.getBuffer(RenderType.eyes(Draw.WHITE));
        o.light = FULLBRIGHT;
        Helion3Geo.part(arm, ps, o, sx, out -> coreGlows(out, look, part, false));
    }
}
