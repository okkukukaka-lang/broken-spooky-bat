package com.shazammod.client.fx;

import java.io.IOException;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;
import org.slf4j.Logger;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import com.shazammod.ShazamClientConfig;
import com.shazammod.client.vfx.Draw;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EffectInstance;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * 0.72 SHADER SHAZAM: efek layar (post-processing) untuk semua skill mod ini, otomatis, tanpa shader pack.
 *
 * <ol>
 * <li><b>Bloom</b>: semua cahaya efek (petir, aura, sinar, ledakan, cincin, dari semua karakter) digambar sekali lagi ke
 * target setengah layar yang memakai kedalaman dunia (jadi yang tertutup tanah nggak ikut berpendar), lalu diperkecil
 * 4-5 tingkat & diperbesar lagi dengan filter Kawase ganda: pendar sempit sampai sangat lebar seperti di film. Cuma cahaya
 * efek yang berpendar; langit, salju, & blok terang dunia nggak berubah.</li>
 * <li><b>Sinar dewa</b>: dari (maksimal) dua sumber cahaya terkuat di layar (kilatan ledakan, bola api, sambaran petir yang
 * didaftarkan efeknya lewat {@link #light}), pendar efek diburamkan memancar keluar; yang menghalangi jadi bayangan berkas.</li>
 * <li><b>Pembiasan</b>: tepi gelombang tekanan ({@link #bubble}, {@link #ring}) membengkokkan gambar di belakangnya dengan
 * sedikit pecahan warna, udara panas ({@link #heat}) beriak. Yang lebih dekat ke kamera dari gelombangnya nggak ikut bengkok.</li>
 * <li><b>Hantaman</b>: guncangan kamera besar ({@link #punch}) = zoom kabur ke tengah, aberasi kromatik, vinyet sesaat.</li>
 * </ol>
 *
 * Program shader-nya di assets/shazammod/shaders/program/shazam_*.json (dijalankan dengan PostPass vanilla). Kalau gagal
 * dimuat (driver / mod lain), Shader Shazam mati sendiri dan semua efek tetap digambar seperti sebelumnya. Mati juga kalau
 * shader pack Iris/Oculus sedang dipakai. Pengaturannya di {@link ShazamClientConfig} (menu Mods -> Shazam -> Config).
 */
public final class ShazamShaders {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int GL_LINEAR = 9729, GL_NEAREST = 9728;
    private static final int GL_READ_FRAMEBUFFER = 36008, GL_DRAW_FRAMEBUFFER = 36009, GL_FRAMEBUFFER = 36160;
    private static final int GL_COLOR_BUFFER_BIT = 16384, GL_DEPTH_BUFFER_BIT = 256;

    // ======= Angka yang gampang diutak-atik =======
    /** Kuat bloom di gabungan akhir (dikali pengaturan "bloom"). */
    private static final float BLOOM = 1.7f;
    /** Bobot pendar lebar dibanding pendar sempit (makin besar makin lebar & lembut). */
    private static final float WIDE = 1.6f;
    /** Kuat sinar dewa (dikali pengaturan "godRays"). */
    private static final float RAYS = 1.4f;
    /** Geseran pembiasan terbesar (satuan tinggi layar) untuk gelombang sekuat 1. */
    private static final float BEND = 0.008f;
    /** Pengali pecahan warna di tepi gelombang. */
    private static final float CHROMA = 0.4f;

    private static final int MAX = 48;   // sumber yang dicatat per frame (yang terkuat dipakai)
    private static final int SLOTS = 6;  // sumber pembiasan di shader (S0..S5)
    private static final int BUBBLE = 0, RING = 1, HEAT = 2;
    private static final int SRC = 11;   // jenis, x, y, z, nx, ny, nz, jari-jari, tebal, kuat, (cadangan)

    // ---- sumber yang didaftarkan efek di frame ini (Effect.shade, dipanggil Vfx.render)
    private static final double[] lights = new double[MAX * 5];
    private static final double[] sources = new double[MAX * SRC];
    private static int lightCount, sourceCount;
    private static boolean collecting, glowDrawn;

    // ---- hantaman
    private static float impact, impactO;

    // ---- target & tahap
    private static TextureTarget glow, rays, swap;
    private static TextureTarget[] down = new TextureTarget[0], up = new TextureTarget[0];
    private static PostPass[] downPass = new PostPass[0], upPass = new PostPass[0];
    private static PostPass raysPass;
    private static EffectInstance composite;   // gabungan akhir: digambar langsung ke layar (lihat fullscreen)
    private static int builtW = -1, builtH = -1, builtQ = -1;
    private static boolean failed;

    // ---- pengaturan (dibaca paling sering tiap 0,5 detik)
    private static long cfgAt;
    private static boolean cfgOn = true, cfgDistort = true, cfgHeat = true, cfgImpact = true;
    private static float cfgBloom = 1f, cfgRays = 1f;
    private static int cfgQuality = 2;
    private static long packAt;
    private static boolean pack;

    private ShazamShaders() {}

    // ================================================================== dipakai efek

    /** Sumber cahaya untuk sinar dewa (kilatan ledakan, bola api, ujung sambaran petir). Dipanggil dari Effect.shade. */
    public static void light(double x, double y, double z, double radius, float strength) {
        if (!collecting || strength <= 0.02f || lightCount >= MAX) {
            return;
        }
        int o = lightCount++ * 5;
        lights[o] = x;
        lights[o + 1] = y;
        lights[o + 2] = z;
        lights[o + 3] = radius;
        lights[o + 4] = strength;
    }

    /** Gelembung tekanan (bola) yang membiaskan layar di tepinya; width = tebal tepinya (blok). */
    public static void bubble(double x, double y, double z, double radius, double width, float strength) {
        add(BUBBLE, x, y, z, 0, 1, 0, radius, width, strength);
    }

    /** Cincin gelombang kejut di sebuah bidang (biasanya tanah) yang membiaskan layar di sekitar cincinnya. */
    public static void ring(double x, double y, double z, double nx, double ny, double nz, double radius, double width,
                            float strength) {
        add(RING, x, y, z, nx, ny, nz, radius, width, strength);
    }

    /** Udara panas yang beriak di dalam bola ini (di atas bola api, plasma, lava). */
    public static void heat(double x, double y, double z, double radius, float strength) {
        if (cfgHeat) {
            add(HEAT, x, y, z, 0, 1, 0, radius, 0, strength);
        }
    }

    private static void add(int kind, double x, double y, double z, double nx, double ny, double nz, double radius, double width,
                            float strength) {
        if (!collecting || strength <= 0.01f || radius <= 0.05 || sourceCount >= MAX || kind != HEAT && !cfgDistort) {
            return;
        }
        int o = sourceCount++ * SRC;
        sources[o] = kind;
        sources[o + 1] = x;
        sources[o + 2] = y;
        sources[o + 3] = z;
        sources[o + 4] = nx;
        sources[o + 5] = ny;
        sources[o + 6] = nz;
        sources[o + 7] = radius;
        sources[o + 8] = width;
        sources[o + 9] = strength;
    }

    /** Hantaman besar (dipanggil CameraShake.add): zoom kabur, pecahan warna, & vinyet sesaat. */
    public static void punch(float amount) {
        impact = Math.min(1f, impact + Math.max(0f, amount));
    }

    /** Tiap tick client. */
    public static void tick() {
        impactO = impact;
        impact *= 0.8f;
        if (impact < 0.002f) {
            impact = 0f;
        }
    }

    /** Lapisan bloom buatan (efek Lintang & Sabbac) dikurangi kalau bloom sungguhan sedang menyala. */
    public static float fakeBloom() {
        return bloomOn() ? 0.55f : 1f;
    }

    /** Matikan / nyalakan dari tombol "Shader Shazam" (disimpan ke pengaturan). */
    public static void toggle() {
        boolean on;
        try {
            on = !ShazamClientConfig.SHADERS.get();
            ShazamClientConfig.SHADERS.set(on);
            ShazamClientConfig.SHADERS.save();
        } catch (RuntimeException e) {
            on = !cfgOn;
        }
        cfgOn = on;
        cfgAt = 0L;
        if (on) {
            failed = false;   // dicoba lagi
        } else {
            close();
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            String key = !on ? "message.shazammod.shaders.off"
                    : packInUse() ? "message.shazammod.shaders.pack" : "message.shazammod.shaders.on";
            mc.player.displayClientMessage(Component.translatable(key), true);
        }
    }

    // ================================================================== dipanggil Vfx.render (AFTER_ENTITIES)

    /** Awal frame efek: sumber-sumber lama dibuang; true = efek boleh mendaftarkan sumber (Effect.shade). */
    public static boolean beginFrame() {
        lightCount = 0;
        sourceCount = 0;
        glowDrawn = false;
        collecting = active();
        return collecting;
    }

    /**
     * true = pendar efek boleh digambar sekali lagi SEKARANG (target bloom sudah dipasang, kedalaman dunia sudah disalin).
     * Sesudah menggambar wajib {@link #endGlow()}.
     */
    public static boolean beginGlow() {
        if (!collecting || !bloomOn()) {
            return false;
        }
        RenderTarget main = Minecraft.getInstance().getMainRenderTarget();
        try {
            ensure(main);
            glow.setClearColor(0f, 0f, 0f, 0f);
            glow.clear(Minecraft.ON_OSX);
            glow.copyDepthFrom(main);
            glow.bindWrite(true);
            return true;
        } catch (Exception e) {
            fail(e);
            main.bindWrite(true);
            return false;
        }
    }

    public static void endGlow() {
        Minecraft.getInstance().getMainRenderTarget().bindWrite(true);
        glowDrawn = true;
    }

    // ================================================================== dipanggil di RenderLevelStageEvent (AFTER_LEVEL)

    public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL) {
            return;
        }
        try {
            draw(event);
        } finally {
            collecting = false;
            glowDrawn = false;
            lightCount = 0;
            sourceCount = 0;
        }
    }

    private static void draw(RenderLevelStageEvent event) {
        if (!active()) {   // dimatikan / shader pack dipakai: target & program dilepas
            if (composite != null) {
                close();
            }
            return;
        }
        float pt = event.getPartialTick().getGameTimeDeltaPartialTick(true);
        float hit = cfgImpact ? impactCurve(Mth.lerp(pt, impactO, impact)) : 0f;
        boolean bloom = glowDrawn && bloomOn();
        if (!bloom && sourceCount == 0 && hit <= 0.001f) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        RenderTarget main = mc.getMainRenderTarget();
        try {
            ensure(main);
            Camera camera = event.getCamera();
            Vec3 cam = camera.getPosition();
            Matrix4f proj = event.getProjectionMatrix();
            Matrix4f view = new Matrix4f(proj).mul(new Matrix4f().rotation(camera.rotation().conjugate(new Quaternionf())));
            float aspect = main.width / (float) Math.max(1, main.height);
            float scale = Math.abs(proj.m11()) * 0.5f;
            if (bloom) {
                for (int k = 0; k < downPass.length; k++) {
                    EffectInstance fx = downPass[k].getEffect();
                    fx.safeGetUniform("Spread").set(1.0f);
                    fx.safeGetUniform("Floor").set(k == 0 ? 0.03f : 0f);
                    fx.safeGetUniform("Gain").set(k == 0 ? 1.4f : 1f);
                    downPass[k].process(pt);
                }
                for (int k = upPass.length - 1; k >= 0; k--) {
                    EffectInstance fx = upPass[k].getEffect();
                    fx.safeGetUniform("Spread").set(1.0f);
                    fx.safeGetUniform("Wide").set(WIDE);
                    upPass[k].process(pt);
                }
            }
            boolean shafts = bloom && cfgRays > 0.001f && lightCount > 0
                    && pickLights(cam, view, scale, aspect, raysPass.getEffect());
            if (shafts) {
                raysPass.getEffect().safeGetUniform("Aspect").set(aspect);
                raysPass.process(pt);
            }
            EffectInstance fx = composite;
            pickSources(cam, view, scale, aspect, fx);
            fx.safeGetUniform("Clock").set((float) ((System.nanoTime() / 1.0E9) % 3600.0));
            fx.safeGetUniform("Bloom").set(bloom ? BLOOM * cfgBloom : 0f);
            fx.safeGetUniform("Rays").set(shafts ? RAYS * cfgRays : 0f);
            fx.safeGetUniform("Impact").set(hit);
            fx.safeGetUniform("Chroma").set(CHROMA);
            fx.safeGetUniform("Proj").set(proj.m22(), proj.m32());
            // gambar & kedalaman dunia disalin dulu, lalu gabungan akhirnya digambar LANGSUNG ke layar dari salinan itu: nggak
            // ada yang dihapus (kedalaman dunia tetap utuh untuk mod lain), nggak ada tekstur yang dibaca sambil ditulis, dan
            // kalau programnya gagal di driver tertentu gambar dunia tetap seperti semula (nggak pernah layar hitam)
            GlStateManager._glBindFramebuffer(GL_READ_FRAMEBUFFER, main.frameBufferId);
            GlStateManager._glBindFramebuffer(GL_DRAW_FRAMEBUFFER, swap.frameBufferId);
            GlStateManager._glBlitFrameBuffer(0, 0, main.width, main.height, 0, 0, swap.width, swap.height, GL_COLOR_BUFFER_BIT,
                    GL_NEAREST);
            // kedalaman terpisah: kalau formatnya beda (mod lain), cuma pengecekan "lebih dekat dari gelombang" yang hilang
            GlStateManager._glBlitFrameBuffer(0, 0, main.width, main.height, 0, 0, swap.width, swap.height, GL_DEPTH_BUFFER_BIT,
                    GL_NEAREST);
            GlStateManager._glBindFramebuffer(GL_FRAMEBUFFER, 0);
            fullscreen(fx, main);
        } catch (Exception e) {
            fail(e);
        } finally {
            main.bindWrite(true);
            RenderSystem.enableDepthTest();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
        }
    }

    /** Guncangan kamera -> kuat hantaman: guncangan kecil nggak terasa, yang besar makin kuat. */
    private static float impactCurve(float k) {
        float x = Mth.clamp((k - 0.3f) / 0.7f, 0f, 1f);
        return (float) Math.pow(x, 1.3);
    }

    // ================================================================== sumber -> layar

    /** Titik dunia -> {x, y layar 0..1, w}; null kalau di belakang kamera. */
    private static float[] project(Matrix4f view, Vec3 cam, double x, double y, double z) {
        Vector4f v = new Vector4f((float) (x - cam.x), (float) (y - cam.y), (float) (z - cam.z), 1f);
        v.mul(view);
        if (v.w < 0.1f) {
            return null;
        }
        return new float[] {v.x / v.w * 0.5f + 0.5f, v.y / v.w * 0.5f + 0.5f, v.w};
    }

    /** Dua sumber cahaya terkuat di layar -> LightA & LightB shader sinar dewa. false = nggak ada yang terlihat. */
    private static boolean pickLights(Vec3 cam, Matrix4f view, float scale, float aspect, EffectInstance fx) {
        float[] a = null, b = null;
        float wa = 0f, wb = 0f;
        for (int i = 0; i < lightCount; i++) {
            int o = i * 5;
            float[] s = project(view, cam, lights[o], lights[o + 1], lights[o + 2]);
            if (s == null) {
                continue;
            }
            float rs = (float) lights[o + 3] * scale / s[2];
            float out = Math.max(0f, Math.max(-s[0], s[0] - 1f)) + Math.max(0f, Math.max(-s[1], s[1] - 1f));
            float w = (float) lights[o + 4] * Mth.clamp(1f - out * 2.5f, 0f, 1f) * Mth.clamp(rs * 4f, 0.25f, 1f);
            if (w <= 0.01f) {
                continue;
            }
            float[] l = {s[0], s[1], Math.min(1.6f, w), 0.85f};
            if (w > wa) {
                b = a;
                wb = wa;
                a = l;
                wa = w;
            } else if (w > wb) {
                b = l;
                wb = w;
            }
        }
        if (a == null) {
            return false;
        }
        fx.safeGetUniform("LightA").set(a[0], a[1], a[2], a[3]);
        if (b != null) {
            fx.safeGetUniform("LightB").set(b[0], b[1], b[2], b[3]);
        } else {
            fx.safeGetUniform("LightB").set(0f, 0f, 0f, 0f);
        }
        return true;
    }

    /** Enam sumber pembiasan terkuat di layar -> S0..S5 shader akhir (sisanya dimatikan). */
    private static void pickSources(Vec3 cam, Matrix4f view, float scale, float aspect, EffectInstance fx) {
        float[][] best = new float[SLOTS][];
        float[] weight = new float[SLOTS];
        double[] e = new double[6];
        for (int i = 0; i < sourceCount; i++) {
            int o = i * SRC;
            int kind = (int) sources[o];
            double x = sources[o + 1], y = sources[o + 2], z = sources[o + 3], r = sources[o + 7];
            float s = (float) sources[o + 9];
            double dist = Math.sqrt((x - cam.x) * (x - cam.x) + (y - cam.y) * (y - cam.y) + (z - cam.z) * (z - cam.z));
            if (dist < r * 0.9) {   // kamera di dalam gelombangnya: tepinya ada di sekeliling layar, dilewati
                continue;
            }
            float[] slot;
            float size;
            if (kind == RING) {
                Draw.plane(sources[o + 4], sources[o + 5], sources[o + 6], e);
                float[] p1 = project(view, cam, x + e[0] * r, y + e[1] * r, z + e[2] * r);
                float[] p2 = project(view, cam, x + e[3] * r, y + e[4] * r, z + e[5] * r);
                float[] p3 = project(view, cam, x - e[0] * r, y - e[1] * r, z - e[2] * r);
                float[] p4 = project(view, cam, x - e[3] * r, y - e[4] * r, z - e[5] * r);
                if (p1 == null || p2 == null || p3 == null || p4 == null) {
                    continue;
                }
                float cx = (p1[0] + p2[0] + p3[0] + p4[0]) * 0.25f, cy = (p1[1] + p2[1] + p3[1] + p4[1]) * 0.25f;
                float a1x = (p1[0] - p3[0]) * 0.5f * aspect, a1y = (p1[1] - p3[1]) * 0.5f;
                float a2x = (p2[0] - p4[0]) * 0.5f * aspect, a2y = (p2[1] - p4[1]) * 0.5f;
                float det = a1x * a2y - a2x * a1y;
                size = Math.max((float) Math.sqrt(a1x * a1x + a1y * a1y), (float) Math.sqrt(a2x * a2x + a2y * a2y));
                if (Math.abs(det) < 1.0E-6f || size < 0.004f || !onScreen(cx, cy, size, aspect)) {
                    continue;
                }
                slot = new float[] {cx, cy, a2y / det, -a2x / det, -a1y / det, a1x / det, 0f, 0f, 0f, 0f, 0f, 0f};
            } else {
                float[] c = project(view, cam, x, y, z);
                if (c == null) {
                    continue;
                }
                size = (float) r * scale / c[2];
                if (size < 0.004f || size > 4f || !onScreen(c[0], c[1], size, aspect)) {
                    continue;
                }
                slot = new float[] {c[0], c[1], 1f / size, 0f, 0f, 1f / size, 0f, 0f, 0f, 0f, 0f, 0f};
            }
            float bend = (kind == HEAT ? 0.7f : 1f) * BEND * s * Mth.clamp(size * 3f, 0.3f, 1f);
            slot[6] = kind == HEAT ? 0f : (float) Mth.clamp(sources[o + 8] / r, 0.04, 0.6);
            slot[7] = bend;
            slot[8] = (float) Math.max(0.0, dist - r);
            slot[9] = kind == HEAT ? 1f : 0f;
            float w = s * Math.min(1f, size * 2f);
            int worst = 0;
            for (int k = 1; k < SLOTS; k++) {
                if (weight[k] < weight[worst]) {
                    worst = k;
                }
            }
            if (w > weight[worst]) {
                weight[worst] = w;
                best[worst] = slot;
            }
        }
        for (int k = 0; k < SLOTS; k++) {
            float[] v = best[k];
            String n = "S" + k;
            if (v == null) {
                fx.safeGetUniform(n + "B").set(0f, 0f, 0f, 0f);
                continue;
            }
            fx.safeGetUniform(n + "A").set(v[0], v[1], v[2], v[3]);
            fx.safeGetUniform(n + "B").set(v[4], v[5], v[6], v[7]);
            fx.safeGetUniform(n + "C").set(v[8], v[9], 0f, 0f);
        }
    }

    private static boolean onScreen(float x, float y, float size, float aspect) {
        float rx = size / aspect;
        return x + rx > -0.05f && x - rx < 1.05f && y + size > -0.05f && y - size < 1.05f;
    }

    // ================================================================== target & tahap

    private static void ensure(RenderTarget main) throws IOException {
        if (main.width == builtW && main.height == builtH && cfgQuality == builtQ && composite != null) {
            return;
        }
        close();
        int w = main.width, h = main.height;
        int div = cfgQuality == 0 ? 4 : 2;
        int levels = cfgQuality == 2 ? 5 : cfgQuality == 1 ? 4 : 3;
        glow = target(w / div, h / div, true);
        matchStencil(main, glow);
        down = new TextureTarget[levels];
        int lw = glow.width, lh = glow.height;
        for (int k = 0; k < levels; k++) {
            lw = Math.max(1, lw / 2);
            lh = Math.max(1, lh / 2);
            down[k] = target(lw, lh, false);
        }
        up = new TextureTarget[levels - 1];
        for (int k = 0; k < levels - 1; k++) {
            up[k] = target(down[k].width, down[k].height, false);
        }
        rays = target(down[0].width, down[0].height, false);
        swap = target(w, h, true);   // salinan warna + kedalaman dunia untuk gabungan akhir
        matchStencil(main, swap);
        builtW = w;
        builtH = h;
        builtQ = cfgQuality;
        downPass = new PostPass[levels];
        for (int k = 0; k < levels; k++) {
            downPass[k] = pass("shazammod:shazam_bloom_down", k == 0 ? glow : down[k - 1], down[k]);
        }
        upPass = new PostPass[levels - 1];
        for (int k = levels - 2; k >= 0; k--) {
            TextureTarget level = down[k];
            upPass[k] = pass("shazammod:shazam_bloom_up", k == levels - 2 ? down[levels - 1] : up[k + 1], up[k]);
            upPass[k].addAuxAsset("LevelSampler", level::getColorTextureId, level.width, level.height);
        }
        raysPass = pass("shazammod:shazam_rays", down[0], rays);
        composite = new EffectInstance(Minecraft.getInstance().getResourceManager(), "shazammod:shazam_final");
        TextureTarget bloom = up.length > 0 ? up[0] : down[0];
        TextureTarget copy = swap, shaft = rays;
        composite.setSampler("DiffuseSampler", copy::getColorTextureId);
        composite.setSampler("BloomSampler", bloom::getColorTextureId);
        composite.setSampler("RaysSampler", shaft::getColorTextureId);
        composite.setSampler("DepthSampler", copy::getDepthTextureId);
        LOGGER.debug("Shader Shazam siap: {}x{}, bloom {} tingkat dari 1/{} layar", w, h, levels, div);
    }

    /**
     * Mod lain bisa menyalakan stencil di layar utama (NeoForge RenderTarget#enableStencil): kedalaman target pendar harus
     * berformat sama supaya bisa disalin. Lewat refleksi supaya tetap jalan walau API-nya berubah.
     */
    private static void matchStencil(RenderTarget main, RenderTarget t) {
        try {
            if (Boolean.TRUE.equals(RenderTarget.class.getMethod("isStencilEnabled").invoke(main))) {
                RenderTarget.class.getMethod("enableStencil").invoke(t);
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // tanpa stencil: tetap jalan
        }
    }

    private static TextureTarget target(int w, int h, boolean depth) {
        TextureTarget t = new TextureTarget(Math.max(1, w), Math.max(1, h), depth, Minecraft.ON_OSX);
        t.setClearColor(0f, 0f, 0f, 0f);
        t.setFilterMode(GL_LINEAR);
        return t;
    }

    /** Gabungan akhir: segi empat selayar langsung ke out, tanpa menghapus & tanpa menyentuh kedalamannya. */
    private static void fullscreen(EffectInstance fx, RenderTarget out) {
        float w = out.width, h = out.height;
        fx.safeGetUniform("ProjMat").set(new Matrix4f().setOrtho(0f, w, 0f, h, 0.1f, 1000f));
        fx.safeGetUniform("InSize").set(w, h);
        fx.safeGetUniform("OutSize").set(w, h);
        out.bindWrite(true);
        fx.apply();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        BufferBuilder b = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION);
        b.addVertex(0f, 0f, 500f);
        b.addVertex(w, 0f, 500f);
        b.addVertex(w, h, 500f);
        b.addVertex(0f, h, 500f);
        BufferUploader.draw(b.buildOrThrow());
        RenderSystem.depthMask(true);
        fx.clear();
    }

    private static PostPass pass(String program, RenderTarget in, RenderTarget out) throws IOException {
        PostPass p = new PostPass(Minecraft.getInstance().getResourceManager(), program, in, out, true);
        p.setOrthoMatrix(new Matrix4f().setOrtho(0f, out.width, 0f, out.height, 0.1f, 1000f));
        return p;
    }

    /** Lepas semua target & program (dibuat lagi waktu dipakai lagi): keluar world, layar diubah, shader dimatikan. */
    public static void close() {
        for (PostPass p : downPass) {
            closeQuietly(p);
        }
        for (PostPass p : upPass) {
            closeQuietly(p);
        }
        closeQuietly(raysPass);
        if (composite != null) {
            try {
                composite.close();
            } catch (RuntimeException ignored) {
                // melepas shader nggak boleh bikin game crash
            }
        }
        downPass = new PostPass[0];
        upPass = new PostPass[0];
        raysPass = null;
        composite = null;
        destroy(glow);
        destroy(rays);
        destroy(swap);
        for (TextureTarget t : down) {
            destroy(t);
        }
        for (TextureTarget t : up) {
            destroy(t);
        }
        glow = null;
        rays = null;
        swap = null;
        down = new TextureTarget[0];
        up = new TextureTarget[0];
        builtW = -1;
        builtH = -1;
        builtQ = -1;
    }

    private static void closeQuietly(PostPass p) {
        if (p != null) {
            try {
                p.close();
            } catch (RuntimeException ignored) {
                // melepas shader nggak boleh bikin game crash
            }
        }
    }

    private static void destroy(RenderTarget t) {
        if (t != null) {
            try {
                t.destroyBuffers();
            } catch (RuntimeException ignored) {
                // sama
            }
        }
    }

    private static void fail(Exception e) {
        failed = true;
        LOGGER.warn("Shader Shazam gagal dipakai, efek digambar biasa tanpa shader layar", e);
        close();
    }

    // ================================================================== keadaan

    /** Shader Shazam menyala & bisa dipakai di frame ini. */
    public static boolean active() {
        config();
        return cfgOn && !failed && !packInUse();
    }

    private static boolean bloomOn() {
        return cfgBloom > 0.001f && active();
    }

    private static void config() {
        long now = System.nanoTime();
        if (now - cfgAt < 500_000_000L && cfgAt != 0L) {
            return;
        }
        cfgAt = now;
        try {
            cfgOn = ShazamClientConfig.SHADERS.get();
            cfgBloom = (float) (double) ShazamClientConfig.BLOOM.get();
            cfgRays = (float) (double) ShazamClientConfig.GOD_RAYS.get();
            cfgDistort = ShazamClientConfig.DISTORTION.get();
            cfgHeat = ShazamClientConfig.HEAT_HAZE.get();
            cfgImpact = ShazamClientConfig.IMPACT.get();
            cfgQuality = ShazamClientConfig.QUALITY.get().ordinal();
        } catch (RuntimeException notLoaded) {
            // pengaturan belum dimuat: pakai bawaan
        }
    }

    private static boolean packInUse() {
        long now = System.nanoTime();
        if (now - packAt < 2_000_000_000L && packAt != 0L) {
            return pack;
        }
        packAt = now;
        try {
            Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Object instance = api.getMethod("getInstance").invoke(null);
            pack = Boolean.TRUE.equals(api.getMethod("isShaderPackInUse").invoke(instance));
        } catch (Throwable notInstalled) {
            pack = false;
        }
        return pack;
    }
}
