package com.shazammod.client.fx;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.shazammod.AksaraSkills;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamClientState;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;
import com.shazammod.thanos.ThanosClientState;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * 0.64 Efek KUASA INFINITY (Thanos & PRALAYA). Warnanya ikut pemakainya: warna batu untuk Thanos, warna subsistem untuk
 * PRALAYA (Plasma merah, Graviton ungu, Nanite magenta, Reaktor hijau); ukuran kawah & zona ikut tingkatannya.
 *
 *   Daya Tak Terbatas  tenaga terkumpul di dada, lalu meledak: gelombang, tiang cahaya, dan selama buff: nyala aura,
 *                      lengkung plasma mengitari badan, petir kecil menari di sekujur badan
 *   Ledakan Kawah      bola daya dari kepalan terbang ke titik bidik; ledakan bervolume, kilatan menyilaukan, tiga
 *                      gelombang kejut, awan jamur, puing & retakan, getaran sampai jauh
 *   Gerbang Kosmik     gerbang berputar dilukis di depan badan, bayangan tertinggal, gerbang tujuan terbuka di sana
 *   Tulis Ulang Dunia  gelombang warna tema menyapu zona (kotak glitch di depannya), langit di dalam zona berubah warna
 *                      selama dunia berubah, lalu runtuh ke pusat saat dunia kembali; monster jadi hewan dalam letupan
 *   Bangkitkan Undead  cincin api jiwa di tanah, tiap undead keluar dari semburan api jiwa & retakan tanah; hancur jadi
 *                      tulang & debu jiwa
 */
public final class InfinityFx {
    private InfinityFx() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);
    private static final int[] THEME = {0xB07CFF, 0xD0302A, 0xC9A8FF, 0x9FE0FF, 0xFFD24A};
    private static final int[] THEME_TINT = {0x2A1A40, 0x401010, 0x2A2038, 0x183040, 0x403010};
    private static final Set<Integer> SURGING = new HashSet<>();
    private static final List<Zone> ZONES = new ArrayList<>();

    // ------------------------------------------------------------------ pintu masuk

    public static void onAnim(AbstractClientPlayer p, ShazamAnim anim, Vec3 pos) {
        if (!(p.level() instanceof ClientLevel level)) {
            return;
        }
        boolean self = p == Minecraft.getInstance().player;
        switch (anim) {
            case INFINITY_SURGE -> surge(p, self);
            case INF_SURGE_END -> {
                SURGING.remove(p.getId());
                CineKit.motesOut(chest(p), 24, color(p, 0), 0.07, 0.06f, 18);
            }
            case INFINITY_CRATER -> crater(p, pos);
            case INF_CRATER_HIT -> craterHit(level, p, pos, self);
            case INFINITY_PORTAL -> portal(p, self);
            case INF_PORTAL_EXIT -> portalExit(level, p, pos, self);
            case INFINITY_REWRITE -> rewrite(p, self);
            case INF_REWRITE_WAVE -> rewriteWave(p, pos);
            case INF_REWRITE_END -> rewriteEnd(level, pos);
            case INF_TRANSMUTE -> transmute(p, pos);
            case INFINITY_RAISE -> raise(level, p);
            case INF_RISE -> rise(level, p, pos);
            case INF_CRUMBLE -> crumble(p, pos);
            default -> { }
        }
    }

    /** Tiap tick client: petir kecil di badan yang sedang Daya Tak Terbatas, warna langit di zona tulis ulang. */
    public static void tick(ClientLevel level) {
        if (Minecraft.getInstance().isPaused()) {
            return;
        }
        RandomSource r = level.random;
        if (!SURGING.isEmpty() && level.getGameTime() % 4 == 0) {
            for (Integer id : new ArrayList<>(SURGING)) {
                if (!(level.getEntity(id) instanceof AbstractClientPlayer p) || !p.isAlive()) {
                    SURGING.remove(id);
                    continue;
                }
                int c = color(p, 0);
                double h = p.getBbHeight();
                Vec3 a = new Vec3((r.nextDouble() - 0.5) * 1.0, r.nextDouble() * h, (r.nextDouble() - 0.5) * 1.0);
                Vec3 b = a.add((r.nextDouble() - 0.5) * 0.9, (r.nextDouble() - 0.5) * 0.9, (r.nextDouble() - 0.5) * 0.9);
                Vfx.add(new Lightning.Arc(Lightning.Anchor.on(p, a.x, a.y, a.z), Lightning.Anchor.on(p, b.x, b.y, b.z), c, 0.04f, 4, 1, 1, 0.35));
            }
        }
        LocalPlayer me = Minecraft.getInstance().player;
        for (Zone z : new ArrayList<>(ZONES)) {
            if (level.getGameTime() > z.until || z.ended) {
                ZONES.remove(z);
                continue;
            }
            if (me != null && me.position().distanceTo(z.center) < z.radius) {
                Vfx.worldTint(THEME_TINT[z.theme], 0.16f);
            }
        }
    }

    // ------------------------------------------------------------------ Power

    private static void surge(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.INF_SURGE_HIT;
        int c = color(p, 0);
        Lightning.Anchor chest = CineKit.chestAnchor(p);
        CineFx.gather(p, 0, hit, chest, c, 1.8, 2.6f, true);
        schedule(hit, 1, (lvl, t) -> {
            SURGING.add(p.getId());
            Vec3 ch = chest.at(1f);
            CineKit.burst(ch, 2.2f, c, 0xFFFFFF, 16, 1f);
            Vfx.add(new Hd.Pressure(ch, UP, 8.0, Math.PI, c, 16, 0.85f, true));
            CineKit.shock(lvl, feet(p), UP, 7.0, c, hot(c), 20, 0.9f, true);
            CineFx.godRays(chest, c, 16.0, 1.8, 9, 0.8f, 36);
            Vfx.add(new Fx.Pillar(feet(p), 12.0, 1.2f, c, 20));
            Vfx.add(new Fx.Aura(p, c, 1400, () -> SURGING.contains(p.getId()) ? 1f : 0f));
            Vfx.add(new Hd.Plasma(chest, 0.9, 4, c, hot(c), 1400, 0.7f, () -> SURGING.contains(p.getId()) ? 1f : 0f));
            CineKit.camera(p, ch, 0.8f, 24);
            if (self) {
                ScreenFlash.flash(0.4f, Draw.mix(c, 0xFFFFFF, 0.6));
                ScreenFx.vignette(0.3f, c, 30);
                FovKick.punch(-0.1f);
            }
        });
    }

    private static void crater(AbstractClientPlayer p, Vec3 target) {
        int th = ShazamAnim.INF_CRATER_THROW;
        int c = color(p, 0);
        Lightning.Anchor hand = pt -> ShazamPoses.handPos(p, true, pt);
        CineFx.gather(p, 0, th, hand, c, 1.4, 2.4f, true);
        schedule(th, 1, (lvl, t) -> Vfx.add(new Orb(hand.at(1f), target, c, ShazamAnim.INF_CRATER_TRAVEL)));
    }

    private static void craterHit(ClientLevel level, AbstractClientPlayer p, Vec3 at, boolean self) {
        boolean pralaya = isPralaya(p);
        double r = pralaya ? 24 : 14;
        int c = color(p, 0);
        Vfx.add(new Hd.Nova(at.add(0, 1.0, 0), r * 0.8, 0xFFFFFF, c, Draw.mix(c, 0x200010, 0.6), 0x3A3030, 46, 1f, false));
        Vfx.add(new Fx.Flash(at.add(0, 2, 0), (float) (r * 0.7), 0xFFFFFF, 10, 1f));
        Vfx.add(new Fx.Flash(at.add(0, 2, 0), (float) (r * 1.2), c, 18, 0.8f));
        CineFx.flare(at.add(0, 2, 0), hot(c), (float) (r * 3.0), 0.6f, 1f, 30);
        CineKit.shock(level, at, UP, r * 1.6, c, 0xFFFFFF, 26, 1f, true);
        schedule(5, 1, (lvl, t) -> CineKit.shock(lvl, at, UP, r * 2.4, Draw.mix(c, 0xFFE0B0, 0.5), 0xFFFFFF, 32, 0.8f, true));
        schedule(10, 1, (lvl, t) -> CineKit.shock(lvl, at, UP, r * 3.2, 0xB09070, 0xFFFFFF, 40, 0.6f, true, true));
        Vfx.add(new Fx.Pillar(at, r * 3.0, (float) (r * 0.18), c, 30));
        CineKit.crater(level, at, r * 0.9, hot(c), 0x5A4A3A, 80);
        HdKit.shards(at.add(0, 1, 0), 40 + r * 2, 0.9, 0x5A4E48, 0.22f, 50, at.y - r * 0.5);
        // awan jamur: batang asap yang naik, lalu tudung yang mengembang
        Vfx.add(new Hd.Vortex(Lightning.Anchor.fixed(at), r * 0.35, r * 0.2, r * 2.2, 6, 1.2, (float) (r * 0.05), 0x6A5A50, hot(c), 0x3A3230,
                0.05f, 90, 0.7f));
        schedule(8, 60, (lvl, t) -> {
            RandomSource rnd = lvl.random;
            double top = at.y + r * (0.4 + 1.8 * Math.min(1.0, t / 30.0));
            for (int i = 0; i < 4; i++) {
                double a = rnd.nextDouble() * Math.PI * 2.0, rr = rnd.nextDouble() * r * (0.25 + 0.5 * t / 60.0);
                Vfx.smoke(at.x + Math.cos(a) * rr, top + (rnd.nextDouble() - 0.5) * r * 0.3, at.z + Math.sin(a) * rr,
                        Math.cos(a) * 0.05, 0.02, Math.sin(a) * 0.05, rnd.nextBoolean() ? 0x4A4038 : 0x2E2824, (float) (r * 0.12), 90);
            }
        });
        schedule(30, 1, (lvl, t) -> Vfx.add(new Hd.DustBurst(at.add(0, r * 2.2, 0), r * 0.9, 0x4A4038, 120, 0.7f, false)));
        ShazamFx.shakeAround(at, 2.5f, r * 8);
        LocalPlayer me = Minecraft.getInstance().player;
        if (me != null) {
            double d = me.position().distanceTo(at);
            if (d < r * 6) {
                ScreenFlash.flash((float) (0.85 * (1.0 - d / (r * 6))), 0xFFF6E8);
            }
        }
        if (self) {
            FovKick.punch(-0.12f);
        }
    }

    // ------------------------------------------------------------------ Space

    private static void portal(AbstractClientPlayer p, boolean self) {
        int open = ShazamAnim.INF_PORTAL_OPEN, step = ShazamAnim.INF_PORTAL_STEP;
        int c = color(p, 1);
        schedule(open, 1, (lvl, t) -> {
            Vec3 look = flat(p.getViewVector(1f));
            Vec3 at = chest(p).add(look.scale(1.4));
            Vfx.add(new Gate(at, look, c, isPralaya(p) ? 1.9 : 1.6, step - open + 14));
            Vfx.add(new Fx.Flash(at, 1.2f, c, 8, 0.9f));
        });
        schedule(step, 1, (lvl, t) -> {
            Vfx.add(new Hd.Ghost(feet(p), p.yBodyRot, p.getScale(), 1, c, hot(c), 14, 0.8f));
            CineKit.motesOut(chest(p), 24, hot(c), 0.1, 0.07f, 14);
            if (self) {
                FovKick.kick(0.15f);
                ScreenFlash.flash(0.25f, Draw.mix(c, 0xFFFFFF, 0.6));
            }
        });
    }

    private static void portalExit(ClientLevel level, AbstractClientPlayer p, Vec3 at, boolean self) {
        int c = color(p, 1);
        Vec3 look = flat(p.getViewVector(1f));
        Vfx.add(new Gate(at.add(0, 1.1, 0).subtract(look.scale(0.6)), look, c, isPralaya(p) ? 1.9 : 1.6, 26));
        Vfx.add(new Fx.Flash(at.add(0, 1, 0), 1.6f, c, 10, 1f));
        CineKit.shock(level, at, UP, 5.0, c, hot(c), 16, 0.8f, true);
        CineKit.motesOut(at.add(0, 1, 0), 30, hot(c), 0.12, 0.07f, 16);
    }

    // ------------------------------------------------------------------ Reality

    private static void rewrite(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.INF_REWRITE_HIT;
        int c = color(p, 3);
        CineFx.gather(p, 0, hit, CineKit.chestAnchor(p), c, 1.6, 2.0f, true);
        schedule(hit, 1, (lvl, t) -> {
            Vfx.add(new Hd.Pressure(chest(p), UP, 10.0, Math.PI, c, 18, 0.8f, true));
            if (self) {
                ScreenFlash.flash(0.3f, Draw.mix(c, 0xFFFFFF, 0.5));
            }
        });
    }

    private static void rewriteWave(AbstractClientPlayer p, Vec3 encoded) {
        int theme = Mth.clamp((int) Math.round(encoded.y / 2000.0) - 1, 0, THEME.length - 1);
        Vec3 c = new Vec3(encoded.x, encoded.y - (theme + 1) * 2000.0, encoded.z);
        double radius = isPralaya(p) ? 40 : 24;
        int life = isPralaya(p) ? 2440 : 1240;
        Vfx.add(new RewriteFront(c, radius, THEME[theme], ShazamAnim.INF_REWRITE_SPREAD + 6));
        ZONES.add(new Zone(c, radius, theme, p.level().getGameTime() + life));
    }

    private static void rewriteEnd(ClientLevel level, Vec3 at) {
        Zone best = null;
        double bd = 9.0;
        for (Zone z : ZONES) {
            double d = z.center.distanceToSqr(at);
            if (d < bd) {
                bd = d;
                best = z;
            }
        }
        int c = best == null ? THEME[0] : THEME[best.theme];
        double radius = best == null ? 24 : best.radius;
        if (best != null) {
            best.ended = true;
        }
        Vfx.add(new Fx.Wave(at.add(0, 0.3, 0), UP, radius, 0.6, c, 20, 0.8f, 0.05f, null));
        Vfx.add(new Fx.Flash(at.add(0, 1, 0), 3f, c, 14, 0.8f));
        ShazamFx.shakeAround(at, 0.5f, radius * 2);
    }

    private static void transmute(AbstractClientPlayer p, Vec3 at) {
        int c = color(p, 3);
        Vfx.add(new Fx.Flash(at, 0.9f, c, 8, 0.9f));
        Vfx.add(new Fx.Bubble(at, 1.0, c, 10, 0.7f, 1.0, 2.0, true));
        CineKit.motesOut(at, 16, hot(c), 0.08, 0.06f, 14);
        Vfx.glint(at.x, at.y, at.z, 0xFFFFFF, 0.5f, 10);
    }

    // ------------------------------------------------------------------ Soul

    private static int soul(AbstractClientPlayer p) {
        return color(p, 5);
    }

    private static void raise(ClientLevel level, AbstractClientPlayer p) {
        int hit = ShazamAnim.INF_RAISE_HIT;
        int c = soul(p);
        CineFx.gather(p, 0, hit, CineKit.chestAnchor(p), c, 1.2, 1.6f, false);
        schedule(hit, 1, (lvl, t) -> {
            Vec3 f = feet(p);
            Vfx.add(new Fx.Wave(f.add(0, 0.1, 0), UP, isPralaya(p) ? 9.0 : 7.0, 0.5, c, 30, 0.85f, 0.1f, null));
            Vfx.add(new Hd.Vortex(Lightning.Anchor.fixed(f), 1.2, 3.0, 2.4, 5, 1.0, 0.16f, c, hot(c), 0x102018, 0.1f, 40, 0.7f));
            CineKit.shock(lvl, f, UP, 6.0, c, hot(c), 18, 0.7f, true);
        });
    }

    private static void rise(ClientLevel level, AbstractClientPlayer p, Vec3 at) {
        int c = soul(p);
        Vfx.add(new Fx.Pillar(at, 3.5, 0.5f, c, 16));
        Vfx.add(new Fx.Flash(at.add(0, 0.6, 0), 1.0f, c, 8, 0.9f));
        CineKit.crater(level, at, 1.2, hot(c), 0x4A3E36, 30);
        schedule(0, 14, (lvl, t) -> {
            RandomSource r = lvl.random;
            for (int i = 0; i < 3; i++) {
                Vfx.flame(at.x + (r.nextDouble() - 0.5) * 0.8, at.y + 0.1, at.z + (r.nextDouble() - 0.5) * 0.8, 0, 0.08 + r.nextDouble() * 0.06,
                        0, c, 0.35f, 14);
            }
            Vfx.dust(at.x + (r.nextDouble() - 0.5), at.y + 0.1, at.z + (r.nextDouble() - 0.5), 0, 0.03, 0, 0x6A5A4A, 0.3f, 30);
        });
    }

    private static void crumble(AbstractClientPlayer p, Vec3 at) {
        int c = soul(p);
        RandomSource r = Vfx.random();
        for (int i = 0, n = Vfx.count(22); i < n; i++) {
            Vfx.dust(at.x + (r.nextDouble() - 0.5) * 0.7, at.y + (r.nextDouble() - 0.5) * 1.4, at.z + (r.nextDouble() - 0.5) * 0.7,
                    (r.nextDouble() - 0.5) * 0.04, -0.01, (r.nextDouble() - 0.5) * 0.04, 0xD8D0C0, 0.18f, 30 + r.nextInt(20));
        }
        CineKit.motesOut(at, 14, c, 0.05, 0.06f, 20);
        Vfx.add(new Fx.Flash(at, 0.6f, c, 6, 0.6f));
    }

    // ------------------------------------------------------------------ alat bantu

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    /** PRALAYA (berarmor) kalau bukan Thanos. */
    private static boolean isPralaya(AbstractClientPlayer p) {
        boolean thanos = p == Minecraft.getInstance().player ? ThanosClientState.transformed : ThanosClientState.thanos(p.getId()) != null;
        return !thanos && ShazamClientState.isAksara(p.getId());
    }

    /** Warna batu / inti ke-k sesuai pemakainya. */
    private static int color(AbstractClientPlayer p, int k) {
        return isPralaya(p) ? AksaraSkills.RGB[k] : ThanosFx.STONE[k];
    }

    private static int hot(int rgb) {
        return Draw.mix(rgb, 0xFFFFFF, 0.65);
    }

    private static Vec3 chest(Entity e) {
        return e.position().add(0, e.getBbHeight() * 0.62, 0);
    }

    private static Vec3 feet(Entity e) {
        return e.position().add(0, 0.05, 0);
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : f.normalize();
    }

    private static final class Zone {
        final Vec3 center;
        final double radius;
        final int theme;
        final long until;
        boolean ended;

        Zone(Vec3 center, double radius, int theme, long until) {
            this.center = center;
            this.radius = radius;
            this.theme = theme;
            this.until = until;
        }
    }

    // ================================================================== efek khusus

    /** Bola daya yang terbang dari kepalan ke titik hantam: inti putih menyala, pendar warna, ekor & percikan. */
    static final class Orb extends Effect {
        private final Vec3 a, b;
        private final int rgb;

        Orb(Vec3 a, Vec3 b, int rgb, int life) {
            super(life);
            this.a = a;
            this.b = b;
            this.rgb = rgb;
        }

        private Vec3 at(float time) {
            float t = Mth.clamp(time / life, 0f, 1f);
            return a.lerp(b, t * t * (3f - 2f * t));
        }

        @Override
        public boolean tick(ClientLevel level) {
            Vec3 p = at(age + 1f);
            Vfx.spark(p.x, p.y, p.z, (level.random.nextDouble() - 0.5) * 0.2, (level.random.nextDouble() - 0.5) * 0.2,
                    (level.random.nextDouble() - 0.5) * 0.2, hot(rgb), 0.08f, 8, Double.NaN);
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            Vec3 p = at(time), tail = at(Math.max(0f, time - life * 0.4f));
            d.beam(tail.x, tail.y, tail.z, p.x, p.y, p.z, 0.8f, rgb, 0xFFFFFF, 0.1f, 1f);
            d.flare(p.x, p.y, p.z, 1.8f, rgb, 1f);
            d.glow(p.x, p.y, p.z, 0.8f, 0xFFFFFF, 0.9f);
        }
    }

    /** Gerbang kosmik tegak menghadap arah pandang: cincin bercahaya, lengan spiral berputar, inti kehampaan. */
    static final class Gate extends Effect {
        private final Vec3 c, n;
        private final int rgb;
        private final double r;

        Gate(Vec3 c, Vec3 normal, int rgb, double r, int life) {
            super(life);
            this.c = c;
            this.n = normal;
            this.rgb = rgb;
            this.r = r;
        }

        private float open(float pt) {
            float time = time(pt);
            return Mth.clamp(time / 6f, 0f, 1f) * Mth.clamp((life - time) / 6f, 0f, 1f);
        }

        @Override
        public void renderGlow(Draw d) {
            float o = open(d.partialTick);
            float time = time(d.partialTick);
            double rr = r * (0.3 + 0.7 * o);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, rr, 0.16, rgb, o, 0.08f, null);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, rr * 0.86, 0.05, 0xFFFFFF, o * 0.8f, 0f, null);
            Vec3 u = UP, s = n.cross(UP);
            s = s.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : s.normalize();
            int pts = 10;
            for (int k = 0; k < 4; k++) {
                float[] arr = new float[pts * 3];
                for (int i = 0; i < pts; i++) {
                    double f = i / (double) (pts - 1);
                    double ang = k * Math.PI / 2.0 + f * 2.6 + time * 0.25;
                    double rad = rr * (0.95 - 0.8 * f);
                    Vec3 q = c.add(s.scale(Math.cos(ang) * rad)).add(u.scale(Math.sin(ang) * rad));
                    arr[i * 3] = (float) q.x;
                    arr[i * 3 + 1] = (float) q.y;
                    arr[i * 3 + 2] = (float) q.z;
                }
                d.polyline(arr, pts, 0.1f, 0.03f, rgb, hot(rgb), o * 0.8f, o * 0.3f);
            }
            d.glow(c.x, c.y, c.z, (float) (rr * 1.3), rgb, 0.35f * o);
        }

        @Override
        public void renderSoft(Draw d) {
            float o = open(d.partialTick);
            d.disc(c.x, c.y, c.z, n.x, n.y, n.z, r * (0.3 + 0.7 * o) * 0.8, 0x05040A, 0.85f * o, 0.3f * o, null);
        }
    }

    /** Muka gelombang Tulis Ulang Dunia: cincin warna tema yang menyebar, kotak glitch berkedip di sepanjangnya. */
    static final class RewriteFront extends Effect {
        private final Vec3 c;
        private final double r;
        private final int rgb;

        RewriteFront(Vec3 c, double r, int rgb, int life) {
            super(life);
            this.c = c;
            this.r = r;
            this.rgb = rgb;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            double f = r * Math.min(1.0, t * 1.1);
            float a = 1f - t * 0.6f;
            d.ring(c.x, c.y + 0.3, c.z, 0, 1, 0, f, 0.8, rgb, a, 0.05f, null);
            d.ring(c.x, c.y + 1.2, c.z, 0, 1, 0, f * 0.98, 0.25, 0xFFFFFF, a * 0.7f, 0f, null);
            RandomSource g = RandomSource.create((long) (time(d.partialTick) / 2f) * 31L + 7L);
            for (int i = 0; i < 16; i++) {
                double ang = g.nextDouble() * Math.PI * 2.0;
                double x = c.x + Math.cos(ang) * f, z = c.z + Math.sin(ang) * f, y = c.y + 0.4 + g.nextDouble() * 3.0;
                double s = 0.3 + g.nextDouble() * 0.6;
                d.quad(x - s, y - s, z, x + s, y - s, z, x + s, y + s, z, x - s, y + s, z, g.nextBoolean() ? rgb : 0xFFFFFF,
                        a * 0.6f, a * 0.6f, a * 0.6f, a * 0.6f);
            }
        }
    }
}
