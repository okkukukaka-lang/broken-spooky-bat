package com.shazammod.client.anim;

import java.util.Map;

import com.shazammod.ShazamAnim;

/**
 * 0.63 Gerakan badan THANOS (fan-made), didaftarkan ke Clips.CLIPS (dipakai pemain apa pun yang jadi Thanos). Lengan
 * kanan = tangan Gauntlet (kuasa batu keluar dari sini, lihat ThanosFx), jadi yang membidik pakai aim(). Gaya geraknya
 * berat & bertenaga: kuda-kuda rendah, pinggang ikut memutar, hentakan OUT_BACK di tick puncak (sama dengan server).
 */
final class ThanosClips {
    private ThanosClips() {}

    static void register(Map<ShazamAnim, Clip> clips) {
        // Sumpah Titan (wujud manusia): Gauntlet diangkat pelan ke langit, badan menahan energi kosmik yang makin deras
        // (gemetar naik), lalu di TITAN_BIND_BURST menyatu: lengan kiri terhentak terbuka, kepala mendongak.
        int bb = ShazamAnim.TITAN_BIND_BURST;
        clips.put(ShazamAnim.THANOS_BIND, Clip.builder(ShazamAnim.TITAN_BIND_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-96, 0, 12).leftArm(-14, 0, -16).head(4, 0, 0).tilt(2).drop(0f)
                .key(22, Ease.IN_OUT_SINE).rightArm(-150, 0, 10).leftArm(-22, 0, -24).head(-26, 0, 0).tilt(-3).shake(0.4f)
                .key(60, Ease.IN_OUT_SINE).rightArm(-168, 0, 6).leftArm(-30, 0, -34).head(-38, 0, 0).tilt(-7).drop(0.04f)
                        .legs(5).shake(1.4f)
                .key(bb - 4, Ease.IN_QUAD).rightArm(-174, 0, 4).leftArm(-46, 0, -40).head(-42, 0, 0).tilt(-9).drop(0.1f)
                        .legs(7).shake(3.2f)
                .key(bb, Ease.OUT_BACK).rightArm(-180, 0, 2).leftArm(-28, 0, -86).head(-48, 0, 0).tilt(-13).drop(0f)
                        .legs(11).shake(2.4f)
                .key(bb + 10, Ease.IN_OUT_SINE).rightArm(-128, 0, 12).leftArm(-18, 0, -40).head(-12, 0, 0).tilt(-2)
                        .shake(0.6f)
                .key(ShazamAnim.TITAN_BIND_TICKS, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0)
                        .tilt(0).legs(2).shake(0f)
                .fade(3, 10).build());

        // Berubah: kepalan ditarik ke dada sambil merendah mengumpulkan tenaga, lalu di TITAN_MORPH_BURST dihentak ke
        // langit (kuda-kuda lebar, kepala mendongak), lalu berdiri tegak dengan bahu terbuka.
        int mb = ShazamAnim.TITAN_MORPH_BURST;
        clips.put(ShazamAnim.THANOS_TRANSFORM, Clip.builder(ShazamAnim.TITAN_MORPH_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-42, 0, 12).leftArm(-20, 0, -20).head(10, 0, 0).tilt(6).drop(0.08f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-72, -42, 0).leftArm(-30, 20, -10).head(22, 0, 0).tilt(12).drop(0.18f)
                        .legs(6).shake(1.2f)
                .key(mb - 2, Ease.IN_QUAD).rightArm(-78, -48, 0).head(26, 0, 0).tilt(15).drop(0.22f).shake(2.8f)
                .key(mb, Ease.OUT_BACK).rightArm(-178, 0, 4).leftArm(-24, 0, -62).head(-38, 0, 0).tilt(-10).drop(0f)
                        .legs(9).shake(2.2f)
                .key(mb + 6, Ease.LINEAR).shake(0.8f)
                .key(ShazamAnim.TITAN_MORPH_TICKS, Ease.IN_OUT_SINE).rightArm(-8, 0, 10).leftArm(-6, 0, -10).head(0, 0, 0)
                        .tilt(0).legs(3).shake(0f)
                .fade(2, 8).build());

        // Kembali: kepalan Gauntlet diturunkan pelan, kepala menunduk, energi padam.
        clips.put(ShazamAnim.THANOS_REVERT, Clip.builder(ShazamAnim.TITAN_REVERT_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-64, -20, 0).head(12, 0, 0).tilt(4)
                .key(6, Ease.IN_OUT_SINE).rightArm(-40, -10, 6).head(18, 0, 0).shake(0.6f)
                .key(ShazamAnim.TITAN_REVERT_TICKS, Ease.IN_OUT_SINE).rightArm(0, 0, 5).head(0, 0, 0).tilt(0).shake(0f)
                .fade(1, 6).build());

        // Z Tinju Daya: kepalan Gauntlet ditarik jauh ke belakang (pinggang memutar), lalu dihantamkan lurus ke depan.
        int ph = ShazamAnim.TITAN_PUNCH_HIT;
        clips.put(ShazamAnim.THANOS_PUNCH, Clip.builder(ph + 15)
                .key(0, Ease.OUT_CUBIC).rightArm(28, 0, 22).leftArm(-44, 22, -8).head(6, 0, 0).twist(-30).tilt(6)
                        .rightLeg(10, 0, 3).leftLeg(-14, 0, -3)
                .key(ph - 1, Ease.IN_QUAD).rightArm(42, 0, 26).twist(-38).shake(1.0f)
                .key(ph, Ease.OUT_BACK).rightArm(-92, 0, 0).leftArm(12, 0, -12).head(0, 0, 0).twist(26).tilt(10)
                        .rightLeg(-18, 0, 3).leftLeg(16, 0, -3).shake(0.6f).aim(1f)
                .key(ph + 5, Ease.LINEAR).shake(0f)
                .key(ph + 15, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).twist(0).tilt(0).rightLeg(0, 0, 2)
                        .leftLeg(0, 0, -2).aim(0f)
                .fade(1, 6).build());

        // Shift+Z Ledakan Daya: kepalan diangkat sambil merendah, lompat kecil, lalu dihantamkan ke tanah di TITAN_NOVA_HIT.
        int nh = ShazamAnim.TITAN_NOVA_HIT;
        clips.put(ShazamAnim.THANOS_NOVA, Clip.builder(nh + 18)
                .key(0, Ease.OUT_CUBIC).rightArm(-148, 0, 20).leftArm(-30, 0, -30).head(-18, 0, 0).tilt(-4).drop(0.1f)
                .key(nh - 4, Ease.OUT_QUAD).rightArm(-178, 0, 6).leftArm(-50, 0, -40).head(-24, 0, 0).tilt(-6).drop(-0.34f)
                        .rightLeg(-30, 0, 4).leftLeg(-24, 0, -4).shake(1.4f)
                .key(nh, Ease.OUT_BACK).rightArm(-18, 0, 10).leftArm(-28, 0, -52).head(22, 0, 0).tilt(28).drop(0.46f)
                        .rightLeg(-40, 0, 12).leftLeg(20, 0, -12).shake(3.0f)
                .key(nh + 8, Ease.LINEAR).shake(1.0f)
                .key(nh + 18, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f)
                        .rightLeg(0, 0, 2).leftLeg(0, 0, -2).shake(0f)
                .fade(1, 6).build());

        // X Langkah Kosmik: tangan merobek ruang di depan (sapuan menyamping), lalu melangkah masuk ke robekannya.
        int sa = ShazamAnim.TITAN_STEP_AT;
        clips.put(ShazamAnim.THANOS_STEP, Clip.builder(sa + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-104, 34, 0).head(2, 0, 0).twist(14)
                .key(sa - 1, Ease.IN_QUAD).rightArm(-92, -44, 10).twist(-8).shake(0.6f)
                .key(sa, Ease.OUT_BACK).rightArm(-40, 0, 32).leftArm(-24, 0, -24).tilt(14).rightLeg(-30, 0, 2)
                        .leftLeg(12, 0, -2).shake(0f)
                .key(sa + 12, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).twist(0).tilt(0)
                        .rightLeg(0, 0, 2).leftLeg(0, 0, -2)
                .fade(1, 5).build());

        // Shift+X Hujan Bulan: kepalan diangkat tinggi (langit robek di TITAN_MOON_OPEN), lalu ditarik turun sekuat tenaga
        // seakan menyeret bulan, badan menahan selama batu berjatuhan.
        int mo = ShazamAnim.TITAN_MOON_OPEN;
        clips.put(ShazamAnim.THANOS_MOON, Clip.builder(mo + 34)
                .key(0, Ease.OUT_CUBIC).rightArm(-124, 0, 20).leftArm(-20, 0, -24).head(-20, 0, 0).tilt(-2)
                .key(mo - 2, Ease.IN_QUAD).rightArm(-176, 0, 8).head(-40, 0, 0).tilt(-8).shake(1.2f)
                .key(mo, Ease.OUT_BACK).rightArm(-178, 0, 2).leftArm(-40, 0, -56).head(-44, 0, 0).legs(8).shake(1.6f)
                .key(mo + 8, Ease.IN_QUAD).rightArm(-62, 0, 22).head(-14, 0, 0).tilt(12).drop(0.14f).shake(2.4f)
                .key(mo + 24, Ease.LINEAR).rightArm(-56, 0, 24).head(-20, 0, 0).tilt(10).drop(0.12f).shake(1.4f)
                .key(mo + 34, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f)
                        .legs(2).shake(0f)
                .fade(2, 8).build());

        // C Belenggu Pikiran: tangan kiri di pelipis, Gauntlet diarahkan ke sasaran (ikut bidikan), lalu sinar dilepas.
        int mh = ShazamAnim.TITAN_MIND_HIT;
        clips.put(ShazamAnim.THANOS_MIND, Clip.builder(mh + 14)
                .key(0, Ease.OUT_CUBIC).rightArm(-84, 0, 8).leftArm(-150, 40, -38).head(8, -6, 0).tilt(2).aim(0.6f)
                .key(mh - 1, Ease.IN_QUAD).rightArm(-88, 0, 4).head(12, -8, 0).shake(1.2f).aim(0.9f)
                .key(mh, Ease.OUT_BACK).rightArm(-94, 0, 0).head(-2, 0, 0).tilt(-4).twist(10).shake(0.4f).aim(1f)
                .key(mh + 14, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).twist(0)
                        .shake(0f).aim(0f)
                .fade(1, 6).build());

        // Shift+C Badai Pikiran: kedua tangan di pelipis, kepala mendongak menahan, lalu lengan dihentak terbuka.
        int sh = ShazamAnim.TITAN_MINDSTORM_HIT;
        clips.put(ShazamAnim.THANOS_MINDSTORM, Clip.builder(sh + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, -40, 38).leftArm(-150, 40, -38).head(-10, 0, 0).tilt(-2)
                .key(sh - 2, Ease.IN_QUAD).rightArm(-158, -46, 44).leftArm(-158, 46, -44).head(-30, 0, 0).tilt(-8)
                        .drop(0.06f).shake(2.2f)
                .key(sh, Ease.OUT_BACK).rightArm(-82, 0, 78).leftArm(-82, 0, -78).head(10, 0, 0).tilt(8).drop(0.1f)
                        .shake(1.0f)
                .key(sh + 16, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f)
                        .shake(0f)
                .fade(2, 6).build());

        // V Kenyataan Palsu: Gauntlet diarahkan sambil pergelangan diputar (memelintir kenyataan), lalu dikepal.
        int wh = ShazamAnim.TITAN_WRAP_HIT;
        clips.put(ShazamAnim.THANOS_WRAP, Clip.builder(wh + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-82, 22, 0).head(4, 0, 0).twist(10).aim(0.7f)
                .key(wh / 2f, Ease.IN_OUT_SINE).rightArm(-86, -22, 12).twist(-6).shake(0.6f).aim(0.9f)
                .key(wh, Ease.OUT_BACK).rightArm(-96, 0, -10).tilt(4).twist(8).shake(1.4f).aim(1f)
                .key(wh + 6, Ease.LINEAR).shake(0.4f)
                .key(wh + 16, Ease.IN_OUT_SINE).rightArm(0, 0, 5).head(0, 0, 0).tilt(0).twist(0).shake(0f).aim(0f)
                .fade(1, 6).build());

        // Shift+V Badai Realitas: lengan menyapu lebar dari kiri ke kanan, kenyataan di sekeliling ikut terkoyak.
        int rh = ShazamAnim.TITAN_REALITY_HIT;
        clips.put(ShazamAnim.THANOS_REALITY, Clip.builder(rh + 18)
                .key(0, Ease.OUT_CUBIC).rightArm(-90, 62, 0).leftArm(-20, 0, -20).head(4, 0, 0).twist(30)
                .key(rh - 2, Ease.IN_QUAD).rightArm(-94, 54, 0).twist(34).shake(0.8f)
                .key(rh, Ease.OUT_BACK).rightArm(-88, -72, 30).twist(-32).tilt(4).shake(0.6f)
                .key(rh + 8, Ease.IN_OUT_SINE).rightArm(-60, -40, 40).twist(-14).shake(0f)
                .key(rh + 18, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).twist(0).tilt(0)
                .fade(1, 6).build());

        // B Putar Balik: Gauntlet memutar lingkaran jam di depan badan (berlawanan arah jarum), lalu waktu berbalik.
        int ra = ShazamAnim.TITAN_REWIND_AT;
        clips.put(ShazamAnim.THANOS_REWIND, Clip.builder(ra + 14)
                .key(0, Ease.LINEAR).rightArm(-90, 0, 0).head(0, 0, 0)
                .key(ra * 0.3f, Ease.LINEAR).rightArm(-168, 0, 10)
                .key(ra * 0.6f, Ease.LINEAR).rightArm(-92, 0, 82)
                .key(ra * 0.9f, Ease.LINEAR).rightArm(-14, 0, 22).shake(0.6f)
                .key(ra, Ease.OUT_BACK).rightArm(-100, 0, 6).tilt(-4).shake(1.2f)
                .key(ra + 14, Ease.IN_OUT_SINE).rightArm(0, 0, 5).tilt(0).shake(0f)
                .fade(1, 6).build());

        // Shift+B Henti Waktu: kepalan diangkat ke atas kepala lalu digenggam kuat: waktu berhenti di TITAN_TIMESTOP_HIT.
        int th = ShazamAnim.TITAN_TIMESTOP_HIT;
        clips.put(ShazamAnim.THANOS_TIMESTOP, Clip.builder(th + 18)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, 0, 20).head(-20, 0, 0).tilt(-2)
                .key(th - 2, Ease.IN_QUAD).rightArm(-176, 0, 6).head(-30, 0, 0).drop(0.06f).shake(1.6f)
                .key(th, Ease.OUT_BACK).rightArm(-180, 0, 0).leftArm(-30, 0, -60).head(-34, 0, 0).tilt(-6).legs(7)
                        .shake(2.0f)
                .key(th + 8, Ease.LINEAR).shake(0.4f)
                .key(th + 18, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f)
                        .legs(2).shake(0f)
                .fade(1, 6).build());

        // N Panen Jiwa: cakar Gauntlet terbuka ke depan menahan jiwa-jiwa yang ditarik (gemetar makin kuat), lalu
        // ditarik ke dada saat jiwanya tercabut.
        int hh = ShazamAnim.TITAN_HARVEST_HIT, ht = ShazamAnim.TITAN_HARVEST_TICKS;
        clips.put(ShazamAnim.THANOS_HARVEST, Clip.builder(hh + ht + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(-88, 0, 18).head(4, 0, 0).tilt(2).aim(0.6f)
                .key(hh - 1, Ease.IN_QUAD).rightArm(-92, 0, 10).shake(0.8f).aim(0.9f)
                .key(hh, Ease.OUT_BACK).rightArm(-96, 0, 0).tilt(-3).shake(1.6f).aim(1f)
                .key(hh + ht - 4, Ease.LINEAR).rightArm(-92, 0, 0).tilt(-5).shake(2.4f).aim(1f)
                .key(hh + ht, Ease.OUT_BACK).rightArm(-44, -32, 0).tilt(-8).twist(-14).shake(0.6f).aim(0f)
                .key(hh + ht + 10, Ease.IN_OUT_SINE).rightArm(0, 0, 5).head(0, 0, 0).tilt(0).twist(0).shake(0f)
                .fade(1, 6).build());

        // Shift+N Perisai Jiwa: kepalan Gauntlet di dada, kepala menunduk, lalu lengan terbuka: perisai menyala.
        int sd = ShazamAnim.TITAN_SHIELD_HIT;
        clips.put(ShazamAnim.THANOS_SHIELD, Clip.builder(sd + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-70, -40, 0).leftArm(-20, 10, -10).head(14, 0, 0).tilt(6)
                .key(sd - 1, Ease.IN_QUAD).rightArm(-74, -46, 0).shake(1.2f)
                .key(sd, Ease.OUT_BACK).rightArm(-32, 0, 70).leftArm(-32, 0, -70).head(-10, 0, 0).tilt(-6).shake(0.4f)
                .key(sd + 16, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).shake(0f)
                .fade(1, 6).build());

        // R JENTIKAN: Gauntlet diangkat ke depan-atas, keenam batu menyala satu per satu (badan makin bergetar menahan),
        // lalu di TITAN_SNAP_AT jari dijentikkan: semua getaran berhenti seketika (hening), lalu lengan turun pelan.
        int sn = ShazamAnim.TITAN_SNAP_AT;
        clips.put(ShazamAnim.THANOS_SNAP, Clip.builder(sn + 24)
                .key(0, Ease.OUT_CUBIC).rightArm(-104, 0, 10).leftArm(-12, 0, -14).head(-8, 0, 0)
                .key(12, Ease.IN_OUT_SINE).rightArm(-150, 0, 10).head(-22, 0, 0).tilt(-2).shake(0.4f)
                .key(40, Ease.IN_OUT_SINE).rightArm(-158, 0, 8).head(-26, 0, 0).tilt(-3).drop(0.04f).legs(5).shake(1.6f)
                .key(sn - 3, Ease.IN_QUAD).rightArm(-162, 0, 8).head(-28, 0, 0).drop(0.06f).shake(3.0f)
                .key(sn, Ease.OUT_BACK).rightArm(-170, 0, 0).head(-32, 0, 0).tilt(-5).drop(0f).shake(0f)
                .key(sn + 8, Ease.LINEAR).rightArm(-166, 0, 2).shake(0.2f)
                .key(sn + 24, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).legs(2)
                        .shake(0f)
                .fade(2, 10).build());

        // Shift+R Murka Titan: membungkuk menahan amarah, lalu meraung ke langit dengan kedua lengan terhentak terbuka.
        int gh = ShazamAnim.TITAN_RAGE_HIT;
        clips.put(ShazamAnim.THANOS_RAGE, Clip.builder(gh + 22)
                .key(0, Ease.OUT_CUBIC).rightArm(-22, 0, 30).leftArm(-22, 0, -30).head(24, 0, 0).tilt(18).drop(0.12f)
                        .shake(1.0f)
                .key(gh - 2, Ease.IN_QUAD).rightArm(-30, 0, 24).leftArm(-30, 0, -24).head(30, 0, 0).tilt(22).drop(0.16f)
                        .shake(2.6f)
                .key(gh, Ease.OUT_BACK).rightArm(-42, 0, 72).leftArm(-42, 0, -72).head(-42, 0, 0).tilt(-12).drop(0f)
                        .legs(10).shake(2.2f)
                .key(gh + 12, Ease.LINEAR).shake(1.0f)
                .key(gh + 22, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).legs(2)
                        .shake(0f)
                .fade(2, 8).build());

        // M Putaran Pedang: pedang ditarik ke belakang, lalu badan berputar penuh dengan pedang terentang.
        int ps = ShazamAnim.TITAN_SPIN_HIT;
        clips.put(ShazamAnim.THANOS_SPIN, Clip.builder(ps + 14)
                .key(0, Ease.OUT_CUBIC).rightArm(-64, 44, 30).leftArm(-30, 0, -20).twist(40).drop(0.06f).spin(0)
                .key(ps - 2, Ease.IN_QUAD).rightArm(-70, 48, 34).twist(46).shake(0.4f)
                .key(ps, Ease.OUT_CUBIC).rightArm(-86, -10, 70).leftArm(-60, 0, -70).twist(-10).shake(0f).spin(180)
                .key(ps + 6, Ease.OUT_QUAD).rightArm(-80, -20, 64).spin(360)
                .key(ps + 14, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).twist(0).drop(0f).spin(360)
                .fade(1, 5).build());

        // Shift+M / Shift + klik kanan: pedang ditarik ke belakang kepala, lalu dilempar berputar ke depan.
        int ta = ShazamAnim.TITAN_THROW_AT;
        clips.put(ShazamAnim.THANOS_THROW, Clip.builder(ta + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(-160, 20, 20).leftArm(-40, 0, -20).twist(-24).tilt(-4)
                .key(ta - 1, Ease.IN_QUAD).rightArm(-176, 30, 24).twist(-30).shake(0.6f)
                .key(ta, Ease.OUT_BACK).rightArm(-80, -10, 0).leftArm(10, 0, -10).twist(22).tilt(10).shake(0f).aim(1f)
                .key(ta + 10, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).twist(0).tilt(0).aim(0f)
                .fade(1, 5).build());

        // J Hantaman Titan: merunduk dalam, lalu melompat dengan kedua lengan di atas kepala; sisa gerakannya di udara.
        int lj = ShazamAnim.TITAN_LEAP_JUMP;
        clips.put(ShazamAnim.THANOS_LEAP, Clip.builder(lj + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(30, 0, 20).leftArm(30, 0, -20).head(16, 0, 0).tilt(20).drop(0.26f)
                        .rightLeg(-30, 0, 6).leftLeg(-30, 0, -6)
                .key(lj, Ease.OUT_BACK).rightArm(-168, 0, 12).leftArm(-168, 0, -12).head(-20, 0, 0).tilt(-6).drop(-0.1f)
                        .rightLeg(-44, 0, 4).leftLeg(-20, 0, -4)
                .key(lj + 8, Ease.IN_OUT_SINE).rightArm(-150, 0, 10).leftArm(-150, 0, -10).head(10, 0, 0).tilt(14)
                .key(lj + 16, Ease.IN_QUAD).rightArm(-40, 0, 14).leftArm(-40, 0, -14).head(20, 0, 0).tilt(24).drop(0.2f)
                        .rightLeg(-20, 0, 8).leftLeg(10, 0, -8)
                .fade(1, 8).build());

        // ======= 0.64 Kuasa Infinity (dipakai Thanos & PRALAYA) =======

        // Daya Tak Terbatas: kedua kepalan digenggam di depan dada, badan merendah menahan tenaga yang makin deras
        // (gemetar naik), lalu di INF_SURGE_HIT meledak: lengan terhentak ke samping-bawah, kepala mendongak.
        int us = ShazamAnim.INF_SURGE_HIT;
        clips.put(ShazamAnim.INFINITY_SURGE, Clip.builder(us + 20)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, -30, 0).leftArm(-60, 30, 0).head(10, 0, 0).tilt(6).drop(0.06f)
                .key(us - 2, Ease.IN_QUAD).rightArm(-66, -40, 0).leftArm(-66, 40, 0).head(18, 0, 0).tilt(10).drop(0.14f)
                        .shake(3.0f)
                .key(us, Ease.OUT_BACK).rightArm(-20, 0, 60).leftArm(-20, 0, -60).head(-30, 0, 0).tilt(-10).drop(0f).legs(10)
                        .shake(2.0f)
                .key(us + 8, Ease.LINEAR).shake(0.8f)
                .key(us + 20, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).legs(2).shake(0f)
                .fade(2, 8).build());

        // Ledakan Kawah: kepalan diangkat tinggi mengumpulkan bola daya, lalu dilontarkan ke depan-bawah (ikut bidikan).
        int ct = ShazamAnim.INF_CRATER_THROW;
        clips.put(ShazamAnim.INFINITY_CRATER, Clip.builder(ct + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, 0, 20).leftArm(-30, 0, -20).head(-14, 0, 0).tilt(-4).twist(-10)
                .key(ct - 2, Ease.IN_QUAD).rightArm(-176, 10, 10).head(-20, 0, 0).tilt(-8).twist(-18).shake(2.4f)
                .key(ct, Ease.OUT_BACK).rightArm(-70, 0, 0).leftArm(10, 0, -14).head(6, 0, 0).tilt(14).twist(16).shake(1.0f)
                        .aim(1f)
                .key(ct + 6, Ease.LINEAR).shake(0.2f)
                .key(ct + 16, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).twist(0).shake(0f)
                        .aim(0f)
                .fade(1, 6).build());

        // Gerbang Kosmik: tangan melukis lingkaran gerbang di depan badan, gerbang terbuka (INF_PORTAL_OPEN), lalu
        // melangkah masuk (INF_PORTAL_STEP).
        int po = ShazamAnim.INF_PORTAL_OPEN, ps2 = ShazamAnim.INF_PORTAL_STEP;
        clips.put(ShazamAnim.INFINITY_PORTAL, Clip.builder(ps2 + 10)
                .key(0, Ease.LINEAR).rightArm(-90, 0, 10).head(0, 0, 0)
                .key(po * 0.33f, Ease.LINEAR).rightArm(-150, 0, 30)
                .key(po * 0.66f, Ease.LINEAR).rightArm(-90, 0, 80)
                .key(po, Ease.OUT_BACK).rightArm(-40, 0, 30).leftArm(-20, 0, -20).shake(0.6f)
                .key(ps2 - 2, Ease.IN_QUAD).tilt(10).rightLeg(-24, 0, 2).leftLeg(10, 0, -2).shake(0f)
                .key(ps2, Ease.OUT_QUAD).tilt(14).rightLeg(-36, 0, 2).leftLeg(16, 0, -2)
                .key(ps2 + 10, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).tilt(0).rightLeg(0, 0, 2).leftLeg(0, 0, -2)
                .fade(1, 6).build());

        // Tulis Ulang Dunia: kedua tangan dikatupkan di dada, lalu disapu terbuka lebar sementara dunia berubah.
        int rw = ShazamAnim.INF_REWRITE_HIT;
        clips.put(ShazamAnim.INFINITY_REWRITE, Clip.builder(rw + 24)
                .key(0, Ease.OUT_CUBIC).rightArm(-80, -30, 0).leftArm(-80, 30, 0).head(10, 0, 0).tilt(4)
                .key(rw - 2, Ease.IN_QUAD).rightArm(-90, -44, 0).leftArm(-90, 44, 0).head(16, 0, 0).shake(1.6f)
                .key(rw, Ease.OUT_BACK).rightArm(-100, 0, 90).leftArm(-100, 0, -90).head(-26, 0, 0).tilt(-8).legs(8).shake(1.2f)
                .key(rw + 16, Ease.LINEAR).rightArm(-96, 0, 86).leftArm(-96, 0, -86).shake(0.6f)
                .key(rw + 24, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).legs(2).shake(0f)
                .fade(2, 8).build());

        // Bangkitkan Undead: merunduk, kedua telapak ke tanah memanggil, lalu diangkat tinggi: yang mati bangkit.
        int rh2 = ShazamAnim.INF_RAISE_HIT;
        clips.put(ShazamAnim.INFINITY_RAISE, Clip.builder(rh2 + 22)
                .key(0, Ease.OUT_CUBIC).rightArm(-40, 0, 40).leftArm(-40, 0, -40).head(24, 0, 0).tilt(18).drop(0.2f)
                .key(rh2 - 2, Ease.IN_QUAD).rightArm(-30, 0, 50).leftArm(-30, 0, -50).head(30, 0, 0).tilt(22).drop(0.24f)
                        .shake(1.8f)
                .key(rh2, Ease.OUT_BACK).rightArm(-150, 0, 30).leftArm(-150, 0, -30).head(-24, 0, 0).tilt(-6).drop(0f)
                        .shake(1.2f)
                .key(rh2 + 14, Ease.LINEAR).rightArm(-140, 0, 34).leftArm(-140, 0, -34).shake(0.6f)
                .key(rh2 + 22, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).shake(0f)
                .fade(2, 8).build());
    }
}
