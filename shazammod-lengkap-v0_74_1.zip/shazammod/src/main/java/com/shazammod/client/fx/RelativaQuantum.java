package com.shazammod.client.fx;

import java.util.Random;

import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Vfx;
import com.shazammod.relativa.RelativaClientState;
import com.shazammod.relativa.RelativaNetwork;
import com.shazammod.relativa.RelativaTier;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * 0.67 Efek RELATIVA: pasif Terowongan Kuantum (seluruh atom badan berubah jadi gelombang materi) dan Kecepatan Cahaya
 * (kerucut cahaya Minkowski, jejak foton yang bergeser Doppler, cincin yang mengerut Lorentz, jam-jam yang berhenti, pukulan
 * yang membeku di udara lalu lepas sekaligus saat waktu berjalan lagi).
 */
final class RelativaQuantum {
    /** 0.68 tingkat dewa: muka gelombang waktu berhenti ikut membesar (RelativaTier), kerucut & jejak cahaya lebih tebal. */
    private static final double S = RelativaTier.AREA, F = RelativaTier.FX;
    private RelativaQuantum() {}

    // ================================================================== awan atom badan

    /** Atom-atom badan (koordinat lokal: x kanan, y naik, z depan; tinggi badan 1,8 blok). */
    static final int ATOMS = 84;
    private static final float[] BX = new float[ATOMS], BY = new float[ATOMS], BZ = new float[ATOMS], SEED = new float[ATOMS];
    private static final boolean[] HEAD = new boolean[ATOMS];
    /** Kotak bagian badan: pusat x, y, z, setengah ukuran x, y, z, jumlah atom. */
    private static final float[][] PARTS = {
            {0f, 1.62f, 0f, 0.25f, 0.25f, 0.25f, 14},       // kepala
            {0f, 1.12f, 0f, 0.25f, 0.37f, 0.13f, 22},       // badan
            {-0.37f, 1.1f, 0f, 0.12f, 0.35f, 0.12f, 12},    // lengan kanan
            {0.37f, 1.1f, 0f, 0.12f, 0.35f, 0.12f, 12},     // lengan kiri
            {-0.12f, 0.37f, 0f, 0.12f, 0.37f, 0.12f, 12},   // kaki kanan
            {0.12f, 0.37f, 0f, 0.12f, 0.37f, 0.12f, 12},    // kaki kiri
    };

    static {
        Random r = new Random(1905L);   // annus mirabilis: posisi atomnya selalu sama
        int i = 0;
        for (int part = 0; part < PARTS.length; part++) {
            float[] b = PARTS[part];
            for (int k = 0; k < (int) b[6] && i < ATOMS; k++, i++) {
                // condong ke permukaan supaya siluetnya terbaca
                float u = r.nextFloat() * 2f - 1f, v = r.nextFloat() * 2f - 1f, w = r.nextFloat() * 2f - 1f;
                int face = r.nextInt(3);
                if (face == 0) {
                    u = Math.signum(u) * (0.75f + 0.25f * Math.abs(u));
                } else if (face == 1) {
                    w = Math.signum(w) * (0.75f + 0.25f * Math.abs(w));
                }
                BX[i] = b[0] + u * b[3];
                BY[i] = b[1] + v * b[4];
                BZ[i] = b[2] + w * b[5];
                SEED[i] = r.nextFloat();
                HEAD[i] = part == 0;
            }
        }
    }

    /** Posisi atom ke-i di dunia (dengan ketidakpastian posisi Heisenberg sebesar jitter). */
    static Vec3 atom(int i, Vec3 feet, double bodyYaw, double headYaw, double scale, float time, double jitter) {
        double yaw = (HEAD[i] ? headYaw : bodyYaw) * Mth.DEG_TO_RAD;
        double s = Math.sin(yaw), c = Math.cos(yaw);
        double lx = BX[i], ly = BY[i], lz = BZ[i];
        if (jitter > 0) {
            float f = 1f + SEED[i];
            lx += Math.sin(time * 0.37 * f + i) * jitter;
            ly += Math.sin(time * 0.29 * f + i * 1.7) * jitter;
            lz += Math.cos(time * 0.33 * f + i * 2.9) * jitter;
        }
        double wx = -c * lx - s * lz, wz = -s * lx + c * lz;   // kanan = (-cos, 0, -sin), depan = (-sin, 0, cos)
        return new Vec3(feet.x + wx * scale, feet.y + ly * scale, feet.z + wz * scale);
    }

    /** Fase fungsi gelombang (e^iφ) sebagai warna: sian, biru, ungu, magenta, lalu kembali. */
    static int phaseColor(double phi) {
        int[] wheel = {0x5CFFE1, 0x7FA8FF, 0x9A6BFF, 0xFF7AD9};
        double t = ((phi % 1.0) + 1.0) % 1.0 * wheel.length;
        int k = (int) t;
        return lerp(wheel[k % wheel.length], wheel[(k + 1) % wheel.length], (float) (t - k));
    }

    static int lerp(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static boolean nearCamera(Draw d, Vec3 q, double r) {
        double dx = q.x - d.camX, dy = q.y - d.camY, dz = q.z - d.camZ;
        return dx * dx + dy * dy + dz * dz < r * r;
    }

    private static Vec3 orbitNormal(int i) {
        double a = SEED[i] * Math.PI * 2.0, b = 0.4 + SEED[(i * 7 + 3) % ATOMS] * 1.1;
        return new Vec3(Math.cos(a) * Math.sin(b), Math.cos(b), Math.sin(a) * Math.sin(b));
    }

    /** Badan sebagai awan atom yang bergetar (dipakai pasif & transisinya). */
    private static void drawAtoms(Draw d, AbstractClientPlayer p, float time, float a, boolean quantum, double plane,
                                  boolean below) {
        float pt = d.partialTick;
        Vec3 feet = p.getPosition(pt);
        double by = Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot), hy = Mth.rotLerp(pt, p.yHeadRotO, p.yHeadRot);
        double sc = p.getBbHeight() / 1.8;
        boolean self = p == Minecraft.getInstance().player;
        for (int i = 0; i < ATOMS; i++) {
            double h = BY[i] * sc;
            boolean wave = quantum && (plane < 0 || (below ? h < plane : h > plane));
            Vec3 q = atom(i, feet, by, hy, sc, time, wave ? 0.05 : 0.0);
            if (self && nearCamera(d, q, 0.75)) {
                continue;   // orang pertama: atom di sekitar mata nggak menutupi pandangan
            }
            if (wave) {
                int rgb = phaseColor(time * 0.035 + SEED[i] * 3.0);
                float flick = 0.55f + 0.45f * (float) Math.sin(time * 0.8 + i * 2.3);   // |ψ|² berdenyut
                d.glow(q.x, q.y, q.z, (float) (0.055 * sc), rgb, a * 0.5f * flick);
                d.glow(q.x, q.y, q.z, (float) (0.018 * sc), 0xFFFFFF, a * 0.75f * flick);
                if (i % 4 == 0) {
                    Vec3 n = orbitNormal(i);
                    d.ring(q.x, q.y, q.z, n.x, n.y, n.z, 0.065 * sc, 0.008, rgb, a * 0.45f, 0f, null);
                }
            } else {
                d.glow(q.x, q.y, q.z, (float) (0.022 * sc), 0xFFF4D0, a * 0.55f);   // atom padat: titik kecil diam
            }
            if (plane >= 0 && Math.abs(h - plane) < 0.07 * sc) {   // atom yang sedang diukur menyala
                d.flare(q.x, q.y, q.z, (float) (0.08 * sc), 0xFFFFFF, a);
            }
        }
    }

    // ================================================================== pasif Terowongan Kuantum

    /** Badan RELATIVA yang sedang menembus: awan atom berwarna fase, kulit probabilitas, pinggiran interferensi. */
    static final class PhaseCloud extends Effect {
        final AbstractClientPlayer p;
        private Vec3 lastEcho;

        PhaseCloud(AbstractClientPlayer p) {
            super(Integer.MAX_VALUE / 4);   // tanpa batas: selesai hanya saat pasifnya dimatikan
            this.p = p;
        }

        boolean dead() {
            return p.isRemoved() || (RelativaClientState.flags(p.getId()) & RelativaNetwork.FLAG_PHASE) == 0;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (dead()) {
                return false;
            }
            // gema superposisi: siluet tipis tertinggal saat bergerak (badan "ada" di beberapa tempat sekaligus)
            Vec3 feet = p.position();
            if (age % 5 == 0) {
                if (lastEcho != null && lastEcho.distanceToSqr(feet) > 0.04 && !p.isInvisible()) {
                    Vfx.add(new Hd.Ghost(lastEcho, p.yBodyRot, p.getBbHeight() / 1.8, 0, RelativaFx.GRAVITY, 0xE0C8FF,
                            12, 0.45f));
                }
                lastEcho = feet;
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            if (p.isInvisible()) {
                return;
            }
            float time = time(d.partialTick);
            float a = Mth.clamp((time - 16f) / 12f, 0f, 1f);   // sesudah sapuan PhaseSweep selesai
            if (a <= 0.01f) {
                return;
            }
            drawAtoms(d, p, time, a, true, -1, true);
            Vec3 feet = p.getPosition(d.partialTick);
            double sc = p.getBbHeight() / 1.8;
            boolean self = p == Minecraft.getInstance().player && Minecraft.getInstance().options.getCameraType().isFirstPerson();
            if (!self) {   // kulit probabilitas
                d.glow(feet.x, feet.y + 1.62 * sc, feet.z, (float) (0.5 * sc), RelativaFx.GRAVITY, a * 0.07f);
                d.glow(feet.x, feet.y + 1.1 * sc, feet.z, (float) (0.75 * sc), RelativaFx.GRAVITY, a * 0.06f);
                d.glow(feet.x, feet.y + 0.4 * sc, feet.z, (float) (0.6 * sc), RelativaFx.QUANTUM, a * 0.05f);
            }
            for (int k = 0; k < 2; k++) {   // pinggiran interferensi naik turun di badan
                double f = (time * 0.018 + k * 0.5) % 1.0;
                double h = f * 1.95 * sc;
                float al = a * 0.35f * (float) Math.sin(Math.PI * f);
                d.ring(feet.x, feet.y + h, feet.z, 0, 1, 0, 0.44 * sc, 0.012, 0xB07CFF, al, 0f, null);
            }
        }
    }

    /**
     * Transisi: bidang ukur menyapu badan. on: dari kaki ke kepala, atom di bawah bidang berubah jadi gelombang. off: dari
     * kepala ke kaki, fungsi gelombang runtuh dan atom kembali padat.
     */
    static final class PhaseSweep extends Effect {
        private final AbstractClientPlayer p;
        private final boolean on;
        private final int dur;

        PhaseSweep(AbstractClientPlayer p, boolean on, int dur) {
            super(dur + 14);
            this.p = p;
            this.on = on;
            this.dur = Math.max(1, dur);
        }

        @Override
        public boolean tick(ClientLevel level) {
            return !p.isRemoved() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float k = Mth.clamp(time / dur, 0f, 1f);
            float a = fade(time, life, 1f, 8f);
            Vec3 feet = p.getPosition(d.partialTick);
            double sc = p.getBbHeight() / 1.8;
            double plane = (on ? k : 1f - k) * 1.95 * sc;
            if (time <= dur) {
                double y = feet.y + plane;
                d.ring(feet.x, y, feet.z, 0, 1, 0, 0.62 * sc, 0.035, 0xE8FBFF, a * 0.9f, 0f, null);
                d.ring(feet.x, y, feet.z, 0, 1, 0, 0.8 * sc, 0.014, on ? RelativaFx.GRAVITY : RelativaFx.RELATIV, a * 0.6f,
                        0f, null);
                d.disc(feet.x, y, feet.z, 0, 1, 0, 0.62 * sc, on ? 0xB07CFF : 0xCFEFFF, a * 0.2f, a * 0.02f, null);
                for (int j = 0; j < 12; j++) {   // garis skala bidang ukur
                    double ang = j * Math.PI / 6.0 + time * 0.05;
                    double r0 = 0.66 * sc, r1 = 0.78 * sc;
                    d.line(feet.x + Math.cos(ang) * r0, y, feet.z + Math.sin(ang) * r0, feet.x + Math.cos(ang) * r1, y,
                            feet.z + Math.sin(ang) * r1, 0.02f, 0.01f, 0xFFFFFF, a * 0.7f, a * 0.2f);
                }
                drawAtoms(d, p, time, a, true, plane, on);
            } else {
                float b = 1f - (time - dur) / 14f;
                if (on) {
                    drawAtoms(d, p, time, a * b, true, -1, true);
                }
                Vec3 c = feet.add(0, 1.1 * sc, 0);
                d.flare(c.x, c.y, c.z, (float) (1.1 * sc) * b, on ? 0xB07CFF : 0xFFFFFF, b * 0.9f);
                d.glow(c.x, c.y, c.z, (float) (1.8 * sc) * b, on ? RelativaFx.GRAVITY : RelativaFx.RELATIV, b * 0.4f);
            }
        }
    }

    /** Serangan / benda menembus: riak di titik masuk dan paket gelombang yang lewat menembus badan. */
    static final class PhasePass extends Effect {
        private final Vec3 at, dir, up, side;

        PhasePass(Vec3 at, Vec3 through) {
            super(16);
            this.at = at;
            Vec3 dd = through.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : through.normalize();
            this.dir = dd;
            Vec3 u = Math.abs(dd.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
            this.side = dd.cross(u).normalize();
            this.up = side.cross(dd).normalize();
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float k = time / life;
            float a = 1f - k;
            for (int j = 0; j < 3; j++) {
                double r = 0.12 + k * 0.9 + j * 0.16;
                d.ring(at.x, at.y, at.z, dir.x, dir.y, dir.z, r, 0.02, j == 1 ? RelativaFx.QUANTUM : 0xB07CFF,
                        a * (1f - j * 0.28f), 0f, null);
            }
            int n = 26;
            float[] pts = new float[n * 3];
            double center = k * 1.5 - 0.25;   // paket gelombang menembus badan
            for (int i = 0; i < n; i++) {
                double s = center + (i / (double) (n - 1) - 0.5) * 0.8;
                double env = Math.exp(-((s - center) * (s - center)) / 0.03) * 0.13;
                Vec3 q = at.add(dir.scale(s)).add(up.scale(env * Math.cos(s * 38.0 - time * 1.4)))
                        .add(side.scale(env * Math.sin(s * 38.0 - time * 1.4) * 0.6));
                pts[i * 3] = (float) q.x;
                pts[i * 3 + 1] = (float) q.y;
                pts[i * 3 + 2] = (float) q.z;
            }
            d.polyline(pts, n, 0.035f, 0.035f, RelativaFx.QUANTUM, 0xFFFFFF, a, a);
            if (time < 4f) {
                float f = 1f - time / 4f;
                d.flare(at.x, at.y, at.z, 0.4f * f, 0xFFFFFF, f);
            }
        }
    }

    // ================================================================== Kecepatan Cahaya

    /**
     * Ancang-ancang: kerucut cahaya Minkowski (masa depan di atas, masa lalu di bawah, garis dunia tegak di tengahnya)
     * terbuka di sekitar RELATIVA; saat waktu berhenti, muka gelombang "waktu berhenti" menyebar dari badannya.
     */
    static final class LightCone extends Effect {
        private final AbstractClientPlayer p;
        private final int windup;

        LightCone(AbstractClientPlayer p, int windup) {
            super(windup + 16);
            this.p = p;
            this.windup = Math.max(1, windup);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float k = Mth.clamp(time / windup, 0f, 1f);
            float a = fade(time, life, 2f, 8f);
            Vec3 f = p.getPosition(d.partialTick);
            Vec3 apex = f.add(0, 1.0, 0);
            double big = (0.5 + k * 2.6) * F;
            for (int j = 1; j <= 5; j++) {
                double h = big * j / 5.0;
                float al = a * (0.3f + 0.13f * j);
                d.ring(apex.x, apex.y + h, apex.z, 0, 1, 0, h, 0.035, RelativaFx.LIGHT, al, 0f, null);    // kerucut masa depan
                d.ring(apex.x, apex.y - h, apex.z, 0, 1, 0, h, 0.035, RelativaFx.RELATIV, al, 0f, null);  // kerucut masa lalu
            }
            for (int j = 0; j < 12; j++) {   // garis cahaya (45°: x = ct)
                double ang = j * Math.PI / 6.0 + time * 0.03;
                double cx = Math.cos(ang) * big, cz = Math.sin(ang) * big;
                d.line(apex.x, apex.y, apex.z, apex.x + cx, apex.y + big, apex.z + cz, 0.03f, 0.045f, RelativaFx.LIGHT, a * 0.6f,
                        a * 0.2f);
                d.line(apex.x, apex.y, apex.z, apex.x + cx, apex.y - big, apex.z + cz, 0.03f, 0.045f, RelativaFx.RELATIV,
                        a * 0.6f, a * 0.2f);
            }
            d.line(apex.x, apex.y - big - 0.6, apex.z, apex.x, apex.y + big + 0.6, apex.z, 0.05f, 0.05f, 0xFFFFFF, a * 0.8f,
                    a * 0.8f);   // garis dunia RELATIVA
            d.flare(apex.x, apex.y, apex.z, (float) ((0.25f + k * 0.6f) * F), 0xE8FBFF, a * k);
            if (time >= windup) {   // muka gelombang: waktu berhenti
                float w = (time - windup) / 16f;
                double r = 0.5 + w * 14.0 * S;
                d.shell(apex.x, apex.y, apex.z, r, 0xCFEFFF, (1f - w) * 0.35f, 2.5, 1.0);
                d.ring(apex.x, f.y + 0.1, apex.z, 0, 1, 0, r, 0.2, 0xFFFFFF, (1f - w) * 0.8f, 0f, null);
                d.flare(apex.x, apex.y, apex.z, (float) (3.0 * F * (1f - w)), 0xFFFFFF, (1f - w));
            }
        }
    }

    /**
     * Selama waktu berhenti (dilihat semua pemain): jejak foton (biru di depan, memerah ke belakang = Doppler), cincin
     * pinggang yang mengerut searah gerak (kontraksi Lorentz L = L₀/γ), haluan cahaya di depan saat melesat, siluet sisa.
     */
    static final class LightTrail extends Effect {
        private static final int N = 26;
        private final AbstractClientPlayer p;
        private final double[] hx = new double[N], hy = new double[N], hz = new double[N];
        private int count;
        private Vec3 last, vel = Vec3.ZERO;
        private double speed;

        LightTrail(AbstractClientPlayer p) {
            super(Integer.MAX_VALUE / 4);   // selesai saat waktu berjalan lagi
            this.p = p;
        }

        boolean dead() {
            return p.isRemoved() || (RelativaClientState.flags(p.getId()) & RelativaNetwork.FLAG_LIGHT) == 0;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (dead()) {
                return false;
            }
            Vec3 c = p.position().add(0, p.getBbHeight() * 0.55, 0);
            if (last != null) {
                vel = c.subtract(last);
                speed = speed * 0.6 + vel.length() * 0.4;
            }
            last = c;
            System.arraycopy(hx, 0, hx, 1, N - 1);
            System.arraycopy(hy, 0, hy, 1, N - 1);
            System.arraycopy(hz, 0, hz, 1, N - 1);
            hx[0] = c.x;
            hy[0] = c.y;
            hz[0] = c.z;
            count = Math.min(N, count + 1);
            if (speed > 0.22 && age % 2 == 0 && !p.isInvisible()) {
                Vfx.add(new Hd.Ghost(p.position(), p.yBodyRot, p.getBbHeight() / 1.8, 0, RelativaFx.RELATIV, 0xFFFFFF, 9,
                        Math.min(0.75f, (float) speed)));
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float a = Mth.clamp(time(d.partialTick) / 6f, 0f, 1f);
            Vec3 c = p.getPosition(d.partialTick).add(0, p.getBbHeight() * 0.55, 0);
            if (count >= 3 && speed > 0.05) {
                int n = count;
                float[] pts = new float[n * 3];
                float[] w = new float[n], al = new float[n];
                pts[0] = (float) c.x;
                pts[1] = (float) c.y;
                pts[2] = (float) c.z;
                for (int i = 1; i < n; i++) {
                    pts[i * 3] = (float) hx[i];
                    pts[i * 3 + 1] = (float) hy[i];
                    pts[i * 3 + 2] = (float) hz[i];
                }
                for (int i = 0; i < n; i++) {
                    float f = i / (float) (n - 1);
                    w[i] = 0.48f * (1f - f) + 0.03f;
                    al[i] = a * Math.min(1f, (float) speed * 2.5f) * (1f - f);
                }
                d.polyline(pts, n, w, al, RelativaFx.RELATIV, 0xFFFFFF);
                float[] tail = new float[n];   // ekor memerah (pergeseran merah: menjauh)
                for (int i = 0; i < n; i++) {
                    float f = i / (float) (n - 1);
                    tail[i] = al[i] * f * 1.6f;
                }
                d.polyline(pts, n, w, tail, 0xFF5A3A, 0xFFB08A);
            }
            double beta = 1.0 - 0.5 * Math.exp(-4.0 * speed);
            double gamma = 1.0 / Math.sqrt(Math.max(1.0E-6, 1.0 - beta * beta));
            Vec3 dir = vel.lengthSqr() > 1.0E-5 ? new Vec3(vel.x, 0, vel.z) : Vec3.ZERO;
            Vec3 fwd = dir.lengthSqr() > 1.0E-6 ? dir.normalize() : new Vec3(-Math.sin(p.yBodyRot * Mth.DEG_TO_RAD), 0,
                    Math.cos(p.yBodyRot * Mth.DEG_TO_RAD));
            Vec3 side = new Vec3(-fwd.z, 0, fwd.x);
            double contract = 1.0 / Math.min(gamma, 6.0);
            int m = 36;
            float[] ring = new float[(m + 1) * 3];
            for (int i = 0; i <= m; i++) {   // cincin pinggang yang mengerut searah gerak
                double ang = i * Math.PI * 2.0 / m;
                Vec3 q = c.add(fwd.scale(Math.cos(ang) * 1.0 * contract)).add(side.scale(Math.sin(ang) * 1.0));
                ring[i * 3] = (float) q.x;
                ring[i * 3 + 1] = (float) q.y;
                ring[i * 3 + 2] = (float) q.z;
            }
            d.polyline(ring, m + 1, 0.07f, 0.07f, RelativaFx.LIGHT, 0xFFFFFF, a * 0.7f, a * 0.7f);
            if (speed > 0.15) {   // haluan cahaya di depan badan
                Vec3 bow = c.add(fwd.scale(0.55));
                d.cone(bow.x, bow.y, bow.z, -fwd.x, 0, -fwd.z, 2.0, 0.8, 0xE8FBFF, a * Math.min(0.5f, (float) speed * 0.6f),
                        2.0);
                d.flare(bow.x, bow.y, bow.z, 0.5f, 0xFFFFFF, a * Math.min(0.8f, (float) speed));
            }
            float time = time(d.partialTick);
            for (int k = 0; k < 2; k++) {   // kulit cahaya yang terus memancar dari badan (selalu c, bagi siapa pun)
                double f = (time * 0.06 + k * 0.5) % 1.0;
                d.ring(c.x, p.getPosition(d.partialTick).y + 0.05, c.z, 0, 1, 0, 0.4 + f * 3.0 * S, 0.05, RelativaFx.RELATIV,
                        a * 0.5f * (float) (1.0 - f), 0f, null);
            }
        }
    }

    /** Jam yang berhenti di atas makhluk / pemain yang membeku, sampai waktu berjalan lagi. */
    static final class FrozenMark extends Effect {
        final Entity e;
        private final double hand;

        FrozenMark(Entity e) {
            super(20 * 60 * 2);
            this.e = e;
            this.hand = (e.getId() * 0.618) % 1.0 * Math.PI * 2.0;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return RelativaClientState.worldStopped && e.isAlive() && !e.isRemoved() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = Mth.clamp(time / 6f, 0f, 1f) * 0.85f;
            Vec3 c = e.getPosition(d.partialTick).add(0, e.getBbHeight() + 0.45, 0);
            Vec3 n = RelativaEffects.toCam(d, c);
            d.ring(c.x, c.y, c.z, n.x, n.y, n.z, 0.2, 0.025, RelativaFx.COLD, a, 0.08f, null);
            Vec3[] b = RelativaGlyphs.facing(d, c);
            for (int j = 0; j < 12; j++) {   // dua belas garis jam
                double ang = j * Math.PI / 6.0;
                Vec3 o = b[0].scale(Math.sin(ang)).add(b[1].scale(Math.cos(ang)));
                Vec3 p0 = c.add(o.scale(0.15)), p1 = c.add(o.scale(j % 3 == 0 ? 0.11 : 0.13));
                d.line(p0.x, p0.y, p0.z, p1.x, p1.y, p1.z, 0.015f, 0.015f, 0xFFFFFF, a * 0.8f, a * 0.8f);
            }
            Vec3 big = c.add(b[0].scale(Math.sin(hand) * 0.13)).add(b[1].scale(Math.cos(hand) * 0.13));
            Vec3 small = c.add(b[0].scale(Math.sin(hand * 7.0) * 0.08)).add(b[1].scale(Math.cos(hand * 7.0) * 0.08));
            d.line(c.x, c.y, c.z, big.x, big.y, big.z, 0.025f, 0.015f, 0xFFFFFF, a, a);
            d.line(c.x, c.y, c.z, small.x, small.y, small.z, 0.03f, 0.02f, RelativaFx.COLD, a, a);
            d.glow(c.x, c.y, c.z, 0.32f, RelativaFx.COLD, a * 0.18f);
        }
    }

    /**
     * Pukulan ke makhluk yang membeku: gelombang kejutnya ikut membeku di udara (cincin diam, duri cahaya diam); saat waktu
     * berjalan lagi semuanya lepas sekaligus.
     */
    static final class TimeHit extends Effect {
        private final Vec3 at, n;
        private final float spin;
        private int released = -1;

        TimeHit(Vec3 at, Vec3 n, float spin) {
            super(20 * 30);
            this.at = at;
            this.n = n.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : n.normalize();
            this.spin = spin;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (released < 0 && !RelativaClientState.worldStopped && age > 1) {
                released = age;
                CineKit.burst(at, 0.9f, RelativaFx.RELATIV, 0xFFFFFF, 10, 1.2f);
            }
            if (released >= 0 && age - released > 12) {
                return false;
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            Vec3 side = Math.abs(n.y) > 0.9 ? new Vec3(1, 0, 0) : n.cross(new Vec3(0, 1, 0)).normalize();
            Vec3 up = side.cross(n).normalize();
            if (released < 0) {
                float a = Mth.clamp(time / 3f, 0f, 1f);
                float pulse = 0.85f + 0.15f * (float) Math.sin(time * 0.25);
                for (int j = 0; j < 3; j++) {   // cincin gelombang kejut yang membeku
                    d.ring(at.x, at.y, at.z, n.x, n.y, n.z, 0.22 + j * 0.17, 0.03 - j * 0.006,
                            j == 0 ? 0xFFFFFF : RelativaFx.RELATIV, a * pulse * (0.9f - j * 0.22f), 0f, null);
                }
                for (int j = 0; j < 8; j++) {   // duri cahaya yang diam
                    double ang = j * Math.PI / 4.0 + spin;
                    double len = 0.3 + ((j * 37) % 5) * 0.06;
                    Vec3 o = side.scale(Math.cos(ang)).add(up.scale(Math.sin(ang)));
                    Vec3 tip = at.add(o.scale(len));
                    d.line(at.x, at.y, at.z, tip.x, tip.y, tip.z, 0.04f, 0.005f, 0xE8FBFF, a * 0.9f, 0f);
                }
                d.flare(at.x, at.y, at.z, 0.22f * pulse, 0xFFFFFF, a * 0.8f);
                d.glow(at.x, at.y, at.z, 0.5f, RelativaFx.COLD, a * 0.25f);
            } else {
                float k = (age - released + d.partialTick) / 12f;
                float a = Math.max(0f, 1f - k);
                for (int j = 0; j < 3; j++) {
                    d.ring(at.x, at.y, at.z, n.x, n.y, n.z, (0.22 + j * 0.17) * (1.0 + k * 5.0), 0.05, RelativaFx.RELATIV,
                            a * (0.9f - j * 0.22f), 0f, null);
                }
                d.flare(at.x, at.y, at.z, 1.2f * a, 0xFFFFFF, a);
            }
        }
    }

    private static float fade(float time, float life, float in, float out) {
        return RelativaEffects.fade(time, life, in, out);
    }
}
