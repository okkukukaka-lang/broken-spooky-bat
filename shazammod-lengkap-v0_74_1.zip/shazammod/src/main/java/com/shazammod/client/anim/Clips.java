package com.shazammod.client.anim;

import java.util.EnumMap;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.ShazamForm;
import com.shazammod.client.fx.GodShow;

/**
 * Semua gerakan Shazam. Tiap skill punya ancang-ancang (badan menegang, gemetar mengumpulkan tenaga),
 * gerakan utama yang cepat dengan sedikit kebablasan (OUT_BACK), lalu kembali pelan.
 * Waktunya pas dengan saat damage di server (ShazamAnim.*_WINDUP).
 *
 * Panduan angka (derajat):
 * - Lengan xRot: 0 = turun, -90 = lurus ke depan, -180 = lurus ke atas, positif = ke belakang.
 * - Lengan zRot (lengan turun): kanan positif / kiri negatif = membuka ke samping.
 *   (lengan ke atas: kanan positif / kiri negatif = ke arah tengah).
 * - Lengan yRot (saat lurus ke depan): kanan negatif / kiri positif = ke arah tengah.
 * - Kaki xRot: negatif = ke depan. Kepala xRot: negatif = mendongak.
 * - tilt: positif = seluruh badan condong ke depan. drop: badan turun (blok), negatif = terangkat.
 * - twist: pinggang berputar, positif = bahu kanan ke belakang. lean: condong ke samping. shake: gemetar.
 */
public final class Clips {
    private Clips() {}

    private static final Map<ShazamAnim, Clip> CLIPS = new EnumMap<>(ShazamAnim.class);
    /** Gerakan khusus Black Adam (pemanggilan dewa & berubah ala firaun); yang nggak ada di sini memakai CLIPS. */
    private static final Map<ShazamAnim, Clip> ADAM = new EnumMap<>(ShazamAnim.class);
    /** 0.30 Gerakan khusus Sabbac (memanggil enam iblis & berubah dari bawah tanah); yang nggak ada memakai CLIPS. */
    private static final Map<ShazamAnim, Clip> SABBAC = new EnumMap<>(ShazamAnim.class);
    /** 0.32 Gerakan khusus Lintang (menerima cahaya langit & berubah); yang nggak ada memakai CLIPS. */
    private static final Map<ShazamAnim, Clip> LINTANG = new EnumMap<>(ShazamAnim.class);
    /** 0.43 Gerakan khusus Helion-6 (berubah wujud dengan radiasi, kembali); yang nggak ada memakai CLIPS. */
    private static final Map<ShazamAnim, Clip> HELION = new EnumMap<>(ShazamAnim.class);
    /** 0.49 Gerakan khusus Subjek Tiga (keluar dari kepompong sel mati, kembali); yang nggak ada memakai CLIPS. */
    private static final Map<ShazamAnim, Clip> HELION3 = new EnumMap<>(ShazamAnim.class);
    /** 0.50 Gerakan khusus Aksara (cakram datang & mengunci, kembali); skill-nya (AKSARA_*) ada di CLIPS. */
    private static final Map<ShazamAnim, Clip> AKSARA = new EnumMap<>(ShazamAnim.class);

    public static Clip get(ShazamAnim anim) {
        return CLIPS.get(anim);
    }

    public static Clip get(ShazamAnim anim, ShazamForm form) {
        if (form == ShazamForm.AKSARA) {
            Clip clip = AKSARA.get(anim);
            if (clip != null) {
                return clip;
            }
        }
        if (form == ShazamForm.HELION3) {
            Clip clip = HELION3.get(anim);
            if (clip != null) {
                return clip;
            }
        }
        if (form == ShazamForm.HELION) {
            Clip clip = HELION.get(anim);
            if (clip != null) {
                return clip;
            }
        }
        if (form == ShazamForm.LINTANG) {
            Clip clip = LINTANG.get(anim);
            if (clip != null) {
                return clip;
            }
        }
        if (form == ShazamForm.SABBAC) {
            Clip clip = SABBAC.get(anim);
            if (clip != null) {
                return clip;
            }
        }
        if (form == ShazamForm.BLACK_ADAM) {
            Clip clip = ADAM.get(anim);
            if (clip != null) {
                return clip;
            }
        }
        return CLIPS.get(anim);
    }

    static {
        // Transformasi: membungkuk, kepalan ke langit (tick 7), lalu ditahan menegang dan gemetar selama petir turun
        // pelan (tick 8-18, slow motion). Tick 18 petir mengenai: tersentak, terangkat dengan lengan terbuka, berdiri gagah.
        CLIPS.put(ShazamAnim.TRANSFORM, Clip.builder(54)
                .key(0, Ease.LINEAR).rightArm(-20, 0, -4).leftArm(4, 0, -6).head(-5, 0, 0).legs(3).tilt(0)
                .key(3, Ease.OUT_CUBIC).rightArm(18, 0, 14).leftArm(18, 0, -14).head(12, 0, 0).legs(9).tilt(12).drop(0.16f)
                .key(7, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(25, 0, -14).head(-42, 0, 0).legs(6).tilt(-10).drop(-0.06f).shake(0.8f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-183, 0, -4).leftArm(28, 0, -16).head(-48, 0, 0).tilt(-12).drop(-0.08f).shake(1.8f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-177, 0, -7).leftArm(24, 0, -13).head(-44, 0, 0).tilt(-10).drop(-0.05f).shake(2.6f)
                .key(19, Ease.OUT_QUAD).head(-18, 0, 0).tilt(-3).drop(0.12f).shake(0f)
                .key(24, Ease.OUT_CUBIC).rightArm(-152, 0, -34).leftArm(-152, 0, 34).head(-32, 0, 0).legs(10).tilt(-12).drop(-0.35f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-158, 0, -38).leftArm(-158, 0, 38).head(-36, 0, 0).tilt(-8).drop(-0.42f)
                .key(43, Ease.IN_OUT_SINE).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(6, 0, 0).legs(10).tilt(7).drop(0.14f)
                .key(50, Ease.OUT_CUBIC).rightArm(10, 0, 24).leftArm(10, 0, -24).head(-10, 0, 0).legs(8).tilt(-3).drop(0f)
                .fade(2, 5).build());

        // Memakai hood: kedua tangan meraih ke belakang kepala (tick 5), memegang tepi hood (6),
        // menariknya ke depan lewat atas kepala sampai dahi (16), lalu turun lagi.
        CLIPS.put(ShazamAnim.HOOD_UP, Clip.builder(ShazamAnim.HOOD_TICKS)
                .key(0, Ease.LINEAR).rightArm(-20, 0, 6).leftArm(-20, 0, -6)
                .key(5, Ease.IN_OUT_SINE).rightArm(-196, 0, -12).leftArm(-196, 0, 12).head(12, 0, 0)
                .key(6, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-140, 0, -14).leftArm(-140, 0, 14).head(6, 0, 0)
                .key(18, Ease.LINEAR)
                .key(24, Ease.OUT_CUBIC).rightArm(-5, 0, 4).leftArm(-5, 0, -4).head(0, 0, 0)
                .fade(2, 4).build());

        // Melepas hood: tangan memegang tepi hood di dahi (tick 5-6), mendorongnya ke belakang lewat atas kepala
        // sambil sedikit mendongak (16), lalu turun lagi.
        CLIPS.put(ShazamAnim.HOOD_DOWN, Clip.builder(ShazamAnim.HOOD_TICKS)
                .key(0, Ease.LINEAR).rightArm(-20, 0, 6).leftArm(-20, 0, -6)
                .key(5, Ease.IN_OUT_SINE).rightArm(-145, 0, -14).leftArm(-145, 0, 14).head(8, 0, 0)
                .key(6, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-200, 0, -10).leftArm(-200, 0, 10).head(-14, 0, 0)
                .key(18, Ease.LINEAR)
                .key(24, Ease.OUT_CUBIC).rightArm(-5, 0, 4).leftArm(-5, 0, -4).head(0, 0, 0)
                .fade(2, 4).build());

        // Memanggil enam dewa: kepala tertunduk dan lengan terbuka menerima. Dewa datang satu per satu
        // (GodShow.ARRIVE): tiap kedatangan badan sedikit tersentak, lengan makin terbuka, kepala makin terangkat
        // menatap mereka. Menjelang akhir gemetar menahan kekuatan, lalu dilanjutkan TRANSFORM (kepalan ke langit).
        Clip.Builder summon = Clip.builder(ShazamAnim.SUMMON_TICKS)
                .key(0, Ease.LINEAR).rightArm(-8, 0, 10).leftArm(-8, 0, -10).head(10, 0, 0).tilt(2)
                .key(8, Ease.OUT_CUBIC).rightArm(-22, 0, 40).leftArm(-22, 0, -40).head(18, 0, 0).legs(3).tilt(4).drop(0.04f);
        for (int i = 0; i < GodShow.ARRIVE.length; i++) {
            float u = i / (float) (GodShow.ARRIVE.length - 1);
            float at = GodShow.ARRIVE[i];
            float head = 14f - 40f * u;      // makin mendongak
            float open = 42f + 16f * u;      // lengan makin terbuka
            float fwd = -24f - 10f * u;
            summon.key(at - 1.5f, Ease.IN_OUT_SINE).rightArm(fwd, 0, open).leftArm(fwd, 0, -open).head(head + 3, 0, 0)
                    .legs(3).tilt(3 - 9 * u).drop(0.03f - 0.12f * u).shake(0f)
                    .key(at + 1, Ease.OUT_BACK).rightArm(fwd - 7, 0, open + 6).leftArm(fwd - 7, 0, -open - 6).head(head - 7, 0, 0)
                    .tilt(-2 - 9 * u).drop(-0.03f - 0.12f * u).shake(0.7f)
                    .key(at + 6, Ease.IN_OUT_SINE).rightArm(fwd - 2, 0, open + 2).leftArm(fwd - 2, 0, -open - 2).head(head - 2, 0, 0)
                    .tilt(1 - 9 * u).drop(0.01f - 0.12f * u).shake(0.15f);
        }
        float end = ShazamAnim.SUMMON_TICKS;
        float settled = GodShow.ARRIVE[GodShow.ARRIVE.length - 1] + 6;
        summon.key(Math.min(end - 0.5f, Math.max(settled + 1, end - 4)), Ease.IN_OUT_SINE)
                .rightArm(-36, 0, 60).leftArm(-36, 0, -60).head(-30, 0, 0).legs(2).tilt(-9).drop(-0.15f).shake(0.9f)
                .key(end, Ease.IN_OUT_SINE)
                .rightArm(-36, 0, 58).leftArm(-36, 0, -58).head(-30, 0, 0).tilt(-9).drop(-0.15f).shake(1.3f);
        CLIPS.put(ShazamAnim.SUMMON, summon.fade(4, 3).build());

        // Zeus Rage: membungkuk, kepalan mengepal, badan gemetar makin hebat, lalu meraung ke langit dengan lengan
        // menghentak ke bawah-samping (tick 9: mata menyala, petir menyambar) dan tetap bergetar menahan amarah.
        CLIPS.put(ShazamAnim.ZEUS_RAGE, Clip.builder(26)
                .key(0, Ease.OUT_CUBIC).rightArm(14, 0, 8).leftArm(14, 0, -8).head(20, 0, 0).tilt(8).drop(0.08f).shake(1f)
                .key(6, Ease.IN_QUAD).rightArm(28, 0, 18).leftArm(28, 0, -18).head(28, 0, 0).rightLeg(-18, 0, 6).leftLeg(-18, 0, -6)
                        .tilt(15).drop(0.18f).shake(3.5f)
                .key(8.5f, Ease.IN_QUAD).rightArm(34, 0, 10).leftArm(34, 0, -10).tilt(18).drop(0.22f).shake(4.5f)
                .key(9, Ease.OUT_BACK).rightArm(32, 0, 50).leftArm(32, 0, -50).head(-55, 0, 0).rightLeg(0, 0, 9).leftLeg(0, 0, -9)
                        .tilt(-18).drop(-0.06f).shake(2f)
                .key(19, Ease.LINEAR).shake(1.4f)
                .key(26, Ease.IN_OUT_SINE).rightArm(8, 0, 16).leftArm(8, 0, -16).head(-8, 0, 0).rightLeg(0, 0, 3).leftLeg(0, 0, -3)
                        .tilt(-2).drop(0f).shake(0f)
                .fade(2, 5).build());

        // Kembali jadi manusia: kepalan ke atas lagi (gemetar), petir (tick 6), badan lunglai
        CLIPS.put(ShazamAnim.REVERT, Clip.builder(22)
                .key(0, Ease.LINEAR).rightArm(-20, 0, -4).leftArm(4, 0, -6).head(-5, 0, 0)
                .key(5, Ease.OUT_CUBIC).rightArm(-178, 0, -6).leftArm(10, 0, -8).head(-35, 0, 0).shake(1.5f)
                .key(8, Ease.OUT_QUAD).rightArm(-120, 0, 0).head(-8, 0, 0).drop(0.14f).shake(0f)
                .key(16, Ease.IN_OUT_SINE).rightArm(0, 0, 4).leftArm(0, 0, -4).head(10, 0, 0).drop(0.04f)
                .fade(2, 5).build());

        // Terlempar balik jadi manusia (serangan mematikan saat jadi Shazam): badan terhentak ke belakang dengan lengan
        // terlempar ke depan, lalu (tick 3) kekuatan tercabut dari dada: lengan terentang ke belakang, kepala mendongak,
        // gemetar hebat. Lalu lunglai membungkuk dengan lutut goyah dan badan oleng, dan pelan-pelan tegak lagi.
        // Kaki cuma sedikit melangkah, supaya tetap wajar kalau langsung lari menjauh.
        CLIPS.put(ShazamAnim.KNOCKOUT, Clip.builder(30)
                .key(0, Ease.OUT_QUAD).rightArm(-62, 0, 34).leftArm(-62, 0, -34).head(-30, 0, 0)
                        .rightLeg(-22, 0, 6).leftLeg(12, 0, -6).tilt(-24).drop(0.04f).twist(10).shake(3f)
                .key(ShazamAnim.KNOCKOUT_BURST, Ease.OUT_CUBIC).rightArm(24, 0, 66).leftArm(24, 0, -66).head(-48, 0, 0)
                        .rightLeg(-8, 0, 8).leftLeg(6, 0, -8).tilt(-14).drop(-0.05f).twist(0).shake(5f)
                .key(6, Ease.LINEAR).shake(4f)
                .key(10, Ease.IN_QUAD).rightArm(10, 0, 12).leftArm(12, 0, -10).head(30, 0, 0)
                        .rightLeg(-26, 0, 6).leftLeg(16, 0, -6).tilt(24).drop(0.3f).shake(0.8f)
                .key(15, Ease.OUT_QUAD).head(36, 0, 0).tilt(28).drop(0.36f).lean(4).shake(0.4f)
                .key(20, Ease.IN_OUT_SINE).head(26, 0, 0).tilt(22).drop(0.28f).lean(-2).shake(0.2f)
                .key(30, Ease.IN_OUT_SINE).rightArm(4, 0, 8).leftArm(4, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f).lean(0).shake(0f)
                .fade(1, 6).build());

        // S - Mata Solomon: tangan menyapu di depan mata, dua jari ke pelipis sambil menunduk berkonsentrasi,
        // lalu (tick 5) kepala terangkat dan tangan terbuka saat mata menyala dan gelombang pemindai menyebar.
        CLIPS.put(ShazamAnim.SOLOMON_SIGHT, Clip.builder(18)
                .key(0, Ease.LINEAR).rightArm(-30, -10, 0).leftArm(3, 0, -5).head(3, 0, 0)
                .key(2.5f, Ease.OUT_CUBIC).rightArm(-118, -42, 0).head(10, 0, 0).twist(-8)
                .key(4, Ease.IN_OUT_SINE).rightArm(-145, -34, 0).leftArm(8, 0, -10).head(16, 0, 0).tilt(4).drop(0.04f).shake(0.8f)
                .key(5, Ease.OUT_BACK).rightArm(-132, -10, 18).leftArm(14, 0, -24).head(-12, 0, 0).tilt(-6).drop(-0.03f)
                        .twist(6).shake(0f)
                .key(12, Ease.LINEAR)
                .key(18, Ease.IN_OUT_SINE).rightArm(-10, 0, 6).leftArm(3, 0, -5).head(0, 0, 0).tilt(0).drop(0f).twist(0)
                .fade(3, 5).build());

        // H - Tepukan Hercules: kedua tangan dibentang lebar ke belakang sambil menjinjit dan menegang,
        // lalu (tick 5) ditepuk keras di depan sambil melangkah maju, badan terhentak, lalu kembali.
        CLIPS.put(ShazamAnim.HERCULES_CLAP, Clip.builder(14)
                .key(0, Ease.LINEAR).rightArm(-35, 25, 0).leftArm(-35, -25, 0).head(-2, 0, 0).tilt(-2)
                .key(3, Ease.OUT_CUBIC).rightArm(-82, 95, 8).leftArm(-82, -95, -8).head(-10, 0, 0).tilt(-12).drop(-0.06f)
                        .rightLeg(12, 0, 4).leftLeg(-14, 0, -4).shake(1.5f)
                .key(4.2f, Ease.LINEAR).rightArm(-84, 100, 8).leftArm(-84, -100, -8).shake(2.5f)
                .key(5, Ease.OUT_BACK).rightArm(-92, -20, 0).leftArm(-92, 20, 0).head(4, 0, 0).tilt(14).drop(0.1f)
                        .rightLeg(30, 0, 6).leftLeg(-40, 0, -6).shake(0f)
                .key(8, Ease.OUT_QUAD).rightArm(-84, -12, 0).leftArm(-84, 12, 0).tilt(9).drop(0.08f)
                .key(14, Ease.IN_OUT_SINE).rightArm(-20, 0, 6).leftArm(-20, 0, -6).head(0, 0, 0).tilt(0).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(2, 4).build());

        // A - Beban Langit Atlas di tanah: jongkok (tick 2), kedua kepalan diangkat menyangga langit (5), gemetar menahan beban
        // langit sementara bola langit jatuh dan musuh tersedot (5-12), menghentak ke atas (12), lalu (tick 13) dihantamkan ke
        // tanah (dilanjutkan ATLAS_IMPACT).
        CLIPS.put(ShazamAnim.ATLAS_GROUND, Clip.builder(17)
                .key(0, Ease.LINEAR).rightArm(-30, 0, 6).leftArm(-30, 0, -6).head(-5, 0, 0).tilt(-2)
                .key(2, Ease.OUT_QUAD).rightArm(10, 0, 20).leftArm(10, 0, -20).head(10, 0, 0).rightLeg(-30, 0, 4)
                        .leftLeg(-30, 0, -4).tilt(12).drop(0.18f)
                .key(5, Ease.OUT_CUBIC).rightArm(-170, 0, 16).leftArm(-170, 0, -16).head(-30, 0, 0).rightLeg(8, 0, 7)
                        .leftLeg(-8, 0, -7).tilt(-6).drop(0.04f).shake(1.2f)
                .key(9, Ease.IN_OUT_SINE).rightArm(-164, 0, 20).leftArm(-164, 0, -20).head(-22, 0, 0).tilt(-2).drop(0.17f)
                        .shake(2.8f)
                .key(12, Ease.OUT_QUAD).rightArm(-184, 0, 8).leftArm(-184, 0, -8).head(-34, 0, 0).tilt(-14).drop(-0.2f)
                        .shake(1.6f)
                .key(13.2f, Ease.IN_QUAD).rightArm(-118, 0, 10).leftArm(-118, 0, -10).head(-10, 0, 0).tilt(12).drop(0.12f)
                        .shake(0f)
                .fade(1, 3).build());

        // A - Atlas dari udara: menukik dengan kedua kepalan di atas kepala, makin rebah dan bergetar diterpa angin
        CLIPS.put(ShazamAnim.ATLAS_DIVE, Clip.builder(60)
                .key(0, Ease.OUT_CUBIC).rightArm(-168, 0, 12).leftArm(-168, 0, -12).head(-35, 0, 0)
                        .rightLeg(18, 0, 3).leftLeg(28, 0, -3).tilt(30)
                .key(6, Ease.IN_OUT_SINE).tilt(42).shake(1f)
                .fade(2, 6).build());

        // A - Atlas mendarat: kepalan menghantam tanah, satu lutut turun, badan terbenam lalu bangkit pelan
        CLIPS.put(ShazamAnim.ATLAS_IMPACT, Clip.builder(18)
                .key(0, Ease.OUT_QUAD).rightArm(-40, -14, 0).leftArm(-40, 14, 0).head(-28, 0, 0)
                        .rightLeg(-64, 0, 8).leftLeg(44, 0, -8).tilt(32).drop(0.48f).shake(1.6f)
                .key(2, Ease.OUT_CUBIC).rightArm(-34, -14, 0).leftArm(-34, 14, 0).tilt(36).drop(0.54f).shake(1f)
                .key(9, Ease.LINEAR).shake(0.3f)
                .key(13, Ease.IN_OUT_SINE).rightArm(-10, 0, 18).leftArm(-10, 0, -18).head(-10, 0, 0)
                        .rightLeg(-30, 0, 6).leftLeg(20, 0, -6).tilt(14).drop(0.22f).shake(0f)
                .key(18, Ease.IN_OUT_SINE).rightArm(6, 0, 18).leftArm(6, 0, -18).head(-5, 0, 0)
                        .rightLeg(0, 0, 6).leftLeg(0, 0, -6).tilt(0).drop(0f)
                .fade(1, 5).build());

        // H - Lemparan Hercules (Shift + X): meraih musuh di depan (tick 2), mengangkatnya ke atas kepala (6), menarik ke
        // belakang sambil gemetar menahan beratnya (8), lalu (tick 9) melemparnya sekuat tenaga sambil melangkah.
        CLIPS.put(ShazamAnim.HERCULES_THROW, Clip.builder(20)
                .key(0, Ease.LINEAR).rightArm(-60, -12, 0).leftArm(-60, 12, 0).head(4, 0, 0).tilt(6)
                .key(2, Ease.OUT_QUAD).rightArm(-96, -16, 0).leftArm(-96, 16, 0).head(12, 0, 0).tilt(18).drop(0.16f)
                        .rightLeg(-22, 0, 4).leftLeg(18, 0, -4).shake(1f)
                .key(6, Ease.OUT_CUBIC).rightArm(-176, 0, -14).leftArm(-176, 0, 14).head(-26, 0, 0).tilt(-8).drop(-0.04f)
                        .rightLeg(0, 0, 8).leftLeg(0, 0, -8).shake(2.2f)
                .key(8.2f, Ease.IN_QUAD).rightArm(-198, 0, -8).leftArm(-198, 0, 8).head(-16, 0, 0).tilt(-16).twist(10)
                        .shake(2.8f)
                .key(9.5f, Ease.OUT_BACK).rightArm(-58, 0, 0).leftArm(-58, 0, 0).head(6, 0, 0).tilt(22).drop(0.1f).twist(-12)
                        .rightLeg(-32, 0, 4).leftLeg(30, 0, -4).shake(0f)
                .key(13, Ease.LINEAR)
                .key(20, Ease.IN_OUT_SINE).rightArm(-12, 0, 6).leftArm(-12, 0, -6).head(0, 0, 0).tilt(0).drop(0f).twist(0)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(2, 5).build());

        // Ledakan Keberanian (akhir Perisai Achilles): mengepal menahan (tick 0-2), lalu kedua lengan menghentak ke samping
        // dan dada membusung saat damage yang ditahan perisai dilepas.
        CLIPS.put(ShazamAnim.ACHILLES_NOVA, Clip.builder(16)
                .key(0, Ease.OUT_CUBIC).rightArm(18, 0, 24).leftArm(18, 0, -24).head(16, 0, 0).tilt(10).drop(0.12f)
                        .rightLeg(-16, 0, 5).leftLeg(-16, 0, -5).shake(2.6f)
                .key(2, Ease.OUT_BACK).rightArm(-34, 0, 96).leftArm(-34, 0, -96).head(-30, 0, 0).tilt(-12).drop(-0.04f)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).shake(1f)
                .key(9, Ease.LINEAR).shake(0.4f)
                .key(16, Ease.IN_OUT_SINE).rightArm(4, 0, 12).leftArm(4, 0, -12).head(0, 0, 0).tilt(0).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0).shake(0f)
                .fade(1, 5).build());

        // Z - Petir Zeus: tangan menyapu ke atas sambil pinggang berputar, menggapai langit (listrik berkumpul,
        // gemetar), sentakan kecil, lalu (tick 5, tepat saat petir pertama menyambar) mencambuk menunjuk sasaran sambil melangkah.
        CLIPS.put(ShazamAnim.ZEUS_CALL, Clip.builder(16)
                .key(0, Ease.LINEAR).rightArm(-30, 0, -6).leftArm(4, 0, -6).head(-5, 0, 0)
                .key(1.5f, Ease.OUT_QUAD).rightArm(-110, 30, 0).leftArm(15, 0, -14).head(-18, 0, 0).twist(18).tilt(-4)
                .key(3.2f, Ease.OUT_CUBIC).rightArm(-178, 0, -8).leftArm(22, 0, -18).head(-40, 0, 0).twist(10).tilt(-8)
                        .drop(-0.05f).shake(1.5f)
                .key(4.3f, Ease.IN_QUAD).rightArm(-165, 0, -6).shake(2.5f)
                .key(5, Ease.OUT_BACK).rightArm(-90, 0, 0).aim(1f).leftArm(35, 0, -22).head(0, 0, 0).twist(-14).tilt(8)
                        .drop(0.04f).rightLeg(-18, 0, 3).leftLeg(14, 0, -3).shake(0f)
                .key(10, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-60, 0, 0).aim(0.6f).twist(0).tilt(2).drop(0f).rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(2, 5).build());

        // 0.27 Tangan Kahndaq (Black Adam): telapak kanan terangkat ke depan menahan proyektil (gemetar menahan tenaga).
        // Server mengulang klip ini tiap 15 tick selama masih ada yang tertahan, jadi klipnya MULAI dari pose terangkat
        // (perpindahan dari pose sebelumnya dihaluskan fade-in) dan baru turun kalau nggak diulang lagi.
        CLIPS.put(ShazamAnim.ADAM_HOLD, Clip.builder(22)
                .key(0, Ease.LINEAR).rightArm(-92, 0, 4).aim(1f).leftArm(12, 0, -14).head(6, 0, 0).twist(-10).shake(0.6f)
                .key(9, Ease.IN_OUT_SINE).rightArm(-88, 0, 2).aim(1f).shake(0.9f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-92, 0, 4).aim(1f).shake(0.6f)
                .key(22, Ease.IN_OUT_SINE).rightArm(-30, 0, 0).aim(0f).leftArm(4, 0, -6).head(0, 0, 0).twist(0).shake(0f)
                .fade(3, 5).build());
        // ... lalu (tombol J) ditarik sedikit ke dalam dan dikibaskan keluar: semua proyektil melesat balik
        CLIPS.put(ShazamAnim.ADAM_RELEASE, Clip.builder(14)
                .key(0, Ease.LINEAR).rightArm(-90, 0, 4).aim(1f).leftArm(12, 0, -14).twist(-10)
                .key(1.5f, Ease.IN_QUAD).rightArm(-100, 0, -30).aim(0.6f).twist(-22).head(4, 0, 0)
                .key(3, Ease.OUT_BACK).rightArm(-85, 0, 80).aim(0f).twist(24).head(-6, 0, 0).shake(1.2f)
                .key(8, Ease.LINEAR).rightArm(-70, 0, 70).twist(16).shake(0f)
                .key(14, Ease.IN_OUT_SINE).rightArm(-20, 0, 8).leftArm(4, 0, -6).twist(0).head(0, 0, 0)
                .fade(1, 5).build());

        // 0.26 Kekuatan Keluarga: menghimpun tenaga (tick 3), kepalan kanan ke langit (tick 7) sambil tautan petir menyambung
        // ke keluarga, tick 10 petir menyambar semuanya: tersentak, lalu kedua lengan terbuka lebar menyambut keluarga.
        CLIPS.put(ShazamAnim.FAMILY_CALL, Clip.builder(30)
                .key(0, Ease.LINEAR).rightArm(-20, 0, -4).leftArm(4, 0, -6).head(-5, 0, 0).legs(3).tilt(0)
                .key(3, Ease.OUT_CUBIC).rightArm(18, 0, 14).leftArm(18, 0, -14).head(12, 0, 0).legs(9).tilt(12).drop(0.14f)
                .key(7, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(25, 0, -14).head(-42, 0, 0).legs(6).tilt(-10).drop(-0.06f)
                        .shake(1.2f)
                .key(10, Ease.IN_OUT_SINE).rightArm(-183, 0, -4).leftArm(28, 0, -16).head(-48, 0, 0).tilt(-12).drop(-0.08f)
                        .shake(2.4f)
                .key(12, Ease.OUT_QUAD).head(-20, 0, 0).tilt(-3).drop(0.1f).shake(0f)
                .key(16, Ease.OUT_CUBIC).rightArm(-140, 0, -48).leftArm(-140, 0, 48).head(-28, 0, 0).legs(10).tilt(-10).drop(-0.2f)
                .key(23, Ease.IN_OUT_SINE).rightArm(-145, 0, -50).leftArm(-145, 0, 50).head(-30, 0, 0).tilt(-8).drop(-0.22f)
                .key(29, Ease.IN_OUT_SINE).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(4, 0, 0).legs(8).tilt(4).drop(0.06f)
                .fade(2, 5).build());

        // A - Kulit Achilles: membungkuk dalam dengan kepalan mengepal, gemetar makin hebat, lalu (tick 4) meraung
        // dengan dada membusung dan lengan menghentak ke samping, tetap bergetar.
        CLIPS.put(ShazamAnim.ACHILLES_ROAR, Clip.builder(22)
                .key(0, Ease.OUT_CUBIC).rightArm(20, 0, 22).leftArm(20, 0, -22).head(22, 0, 0).tilt(14).drop(0.16f)
                        .rightLeg(-24, 0, 6).leftLeg(-24, 0, -6).shake(1.5f)
                .key(3.5f, Ease.IN_QUAD).rightArm(32, 0, 28).leftArm(32, 0, -28).head(26, 0, 0).tilt(18).drop(0.24f).shake(3f)
                .key(4, Ease.OUT_BACK).rightArm(22, 0, 64).leftArm(22, 0, -64).head(-42, 0, 0).tilt(-16).drop(-0.04f)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).shake(1.2f)
                .key(16, Ease.LINEAR).shake(0.8f)
                .key(22, Ease.IN_OUT_SINE).rightArm(4, 0, 14).leftArm(4, 0, -14).head(-5, 0, 0).tilt(-2).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0).shake(0f)
                .fade(2, 5).build());

        // M - Kilat Mercury: menerjang dengan tinju di depan, badan rebah rendah, lalu tergelincir berhenti dengan
        // kaki depan menahan dan lengan terbuka menjaga keseimbangan.
        CLIPS.put(ShazamAnim.MERCURY_BLITZ, Clip.builder(12)
                .key(0, Ease.OUT_CUBIC).rightArm(-82, -8, 0).leftArm(62, 0, -14).rightLeg(-40, 0, 0).leftLeg(46, 0, 0)
                        .head(-30, 0, 0).tilt(36).twist(-10).drop(0.08f)
                .key(6, Ease.LINEAR).shake(1f)
                .key(8, Ease.OUT_QUAD).rightArm(-40, 0, 30).leftArm(-30, 0, -36).rightLeg(-34, 0, 6).leftLeg(20, 0, -6)
                        .head(-6, 0, 0).tilt(-12).twist(8).drop(0.12f).shake(0f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-10, 0, 5).leftArm(10, 0, -5).rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                        .head(-5, 0, 0).tilt(2).twist(0).drop(0f)
                .fade(1, 4).build());

        // ---- Mode Kilat Mercury. Pukulan-pukulannya pendek (pukulan berikutnya bisa datang 2-3 tick kemudian):
        // klip lama memudar ke klip baru (ShazamPoses), jadi rangkaian pukulan menyambung seperti satu kombo.

        // Menyala: kuda-kuda rendah, kepalan mengepal dan badan gemetar menahan listrik, lalu (tick 6) menghentak
        // tegak dengan lengan terbuka saat listrik meledak dari badan.
        CLIPS.put(ShazamAnim.MERCURY_ON, Clip.builder(16)
                .key(0, Ease.OUT_CUBIC).rightArm(15, 0, 15).leftArm(15, 0, -15).head(18, 0, 0).tilt(12).drop(0.14f)
                        .rightLeg(-20, 0, 5).leftLeg(-20, 0, -5).shake(1.5f)
                .key(5, Ease.IN_QUAD).rightArm(28, 0, 20).leftArm(28, 0, -20).head(24, 0, 0).tilt(16).drop(0.2f).shake(3.5f)
                .key(6, Ease.OUT_BACK).rightArm(30, 0, 55).leftArm(30, 0, -55).head(-25, 0, 0).tilt(-8).drop(-0.04f)
                        .rightLeg(0, 0, 9).leftLeg(0, 0, -9).shake(1.2f)
                .key(11, Ease.LINEAR).shake(0.6f)
                .key(16, Ease.IN_OUT_SINE).rightArm(-25, 0, 12).leftArm(-25, 0, -12).head(0, 0, 0).tilt(6).drop(0.02f)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).shake(0f)
                .fade(2, 4).build());

        // Mati: lengan dikibaskan melepas sisa listrik.
        CLIPS.put(ShazamAnim.MERCURY_OFF, Clip.builder(10)
                .key(0, Ease.OUT_QUAD).rightArm(-10, 0, 22).leftArm(-10, 0, -22).head(6, 0, 0).shake(2.2f)
                .key(4, Ease.LINEAR).shake(0.6f)
                .key(10, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).shake(0f)
                .fade(1, 4).build());

        // Jab kanan: kepalan ditarik, lalu (tick 1) dilontarkan lurus sambil pinggang berputar dan kaki melangkah.
        CLIPS.put(ShazamAnim.MERCURY_JAB, Clip.builder(9)
                .key(0, Ease.LINEAR).rightArm(-55, 0, 12).leftArm(-50, 15, -10).head(0, 0, 0).twist(10).tilt(12)
                .key(1.2f, Ease.OUT_BACK).rightArm(-93, -6, 0).leftArm(-35, 20, -14).twist(-16).tilt(18).drop(0.04f)
                        .rightLeg(-12, 0, 2).leftLeg(16, 0, -2)
                .key(3, Ease.LINEAR)
                .key(9, Ease.IN_OUT_SINE).rightArm(-35, 0, 8).leftArm(-35, 0, -8).twist(0).tilt(8).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(0.6f, 3).build());

        // Cross kiri: kebalikan jab.
        CLIPS.put(ShazamAnim.MERCURY_CROSS, Clip.builder(9)
                .key(0, Ease.LINEAR).leftArm(-55, 0, -12).rightArm(-50, -15, 10).head(0, 0, 0).twist(-10).tilt(12)
                .key(1.2f, Ease.OUT_BACK).leftArm(-93, 6, 0).rightArm(-35, -20, 14).twist(16).tilt(18).drop(0.04f)
                        .leftLeg(-12, 0, -2).rightLeg(16, 0, 2)
                .key(3, Ease.LINEAR)
                .key(9, Ease.IN_OUT_SINE).rightArm(-35, 0, 8).leftArm(-35, 0, -8).twist(0).tilt(8).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(0.6f, 3).build());

        // Hook kanan: lengan dari samping menyapu mendatar ke depan dengan putaran pinggang yang lebar.
        CLIPS.put(ShazamAnim.MERCURY_HOOK, Clip.builder(9)
                .key(0, Ease.LINEAR).rightArm(-80, 55, 10).leftArm(-45, 15, -10).head(0, 0, 0).twist(22).tilt(10)
                .key(1.3f, Ease.OUT_BACK).rightArm(-88, -35, 0).leftArm(-40, 20, -14).twist(-28).tilt(14).lean(-6)
                        .rightLeg(-8, 0, 4).leftLeg(10, 0, -4)
                .key(3, Ease.LINEAR)
                .key(9, Ease.IN_OUT_SINE).rightArm(-35, 0, 8).leftArm(-35, 0, -8).twist(0).tilt(8).lean(0)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(0.6f, 3).build());

        // Tendangan kanan: kaki diangkat lurus ke depan, badan condong ke belakang, lengan terbuka menjaga keseimbangan.
        CLIPS.put(ShazamAnim.MERCURY_KICK, Clip.builder(10)
                .key(0, Ease.LINEAR).rightLeg(-30, 0, 6).rightArm(-20, 0, 25).leftArm(-50, 0, -20).head(0, 0, 0).tilt(-4)
                .key(1.4f, Ease.OUT_BACK).rightLeg(-100, 0, 10).leftLeg(6, 0, -3).rightArm(25, 0, 35).leftArm(-60, 0, -30)
                        .tilt(-14).lean(-8).drop(0.05f)
                .key(3.2f, Ease.LINEAR)
                .key(10, Ease.IN_OUT_SINE).rightLeg(0, 0, 0).leftLeg(0, 0, 0).rightArm(-30, 0, 8).leftArm(-30, 0, -8)
                        .tilt(6).lean(0).drop(0f)
                .fade(0.6f, 3).build());

        // Lepas landas: jongkok mengumpulkan tenaga, lalu melesat dengan kepalan ke atas
        CLIPS.put(ShazamAnim.LAUNCH, Clip.builder(16)
                .key(0, Ease.OUT_QUAD).rightArm(22, 0, 12).leftArm(22, 0, -12).head(12, 0, 0)
                        .rightLeg(-35, 0, 4).leftLeg(-20, 0, -4).tilt(14).drop(0.28f).shake(1f)
                .key(4, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(15, 0, -12).head(-30, 0, 0)
                        .rightLeg(8, 0, 2).leftLeg(16, 0, -2).tilt(-4).drop(-0.1f).shake(0f)
                .key(10, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(-60, 0, 10).leftArm(10, 0, -10).head(-10, 0, 0)
                        .rightLeg(5, 0, 2).leftLeg(10, 0, -2).tilt(0).drop(0f)
                .fade(1, 6).build());

        // Mendarat pelan: lutut menekuk sedikit
        CLIPS.put(ShazamAnim.LAND_SOFT, Clip.builder(10)
                .key(0, Ease.OUT_QUAD).rightArm(-25, 0, 22).leftArm(-25, 0, -22).head(5, 0, 0)
                        .rightLeg(-25, 0, 6).leftLeg(-12, 0, -6).tilt(10).drop(0.2f)
                .key(10, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f)
                .fade(1, 4).build());

        // Hero landing: satu lutut turun, kepalan menghantam tanah, lengan lain ke belakang, badan bergetar sesaat
        CLIPS.put(ShazamAnim.LAND_HERO, Clip.builder(28)
                .key(0, Ease.OUT_QUAD).rightArm(-28, -10, 8).leftArm(48, 0, -38).head(-38, 0, 0)
                        .rightLeg(-78, 0, 10).leftLeg(58, 0, -10).tilt(34).drop(0.58f).shake(1.5f)
                .key(6, Ease.LINEAR).shake(0f)
                .key(14, Ease.LINEAR)
                .key(28, Ease.IN_OUT_SINE).rightArm(10, 0, 24).leftArm(10, 0, -24).head(-8, 0, 0)
                        .rightLeg(0, 0, 8).leftLeg(0, 0, -8).tilt(-3).drop(0f)
                .fade(1, 6).build());

        // Menabrak: lengan menahan di depan muka, badan terpental ke belakang dan sedikit terpelintir
        CLIPS.put(ShazamAnim.CRASH, Clip.builder(18)
                .key(0, Ease.OUT_QUAD).rightArm(-115, -28, 0).leftArm(-115, 28, 0).head(18, 0, 0)
                        .rightLeg(-20, 0, 6).leftLeg(10, 0, -6).tilt(-22).drop(0.08f).twist(12).shake(2f)
                .key(6, Ease.OUT_CUBIC).tilt(-12).twist(4).shake(0f)
                .key(18, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f).twist(0)
                .fade(1, 5).build());
    }

    // ================================================================== Black Adam

    static {
        // Memanggil dewa-dewa Mesir: berdiri tegak seperti patung firaun, kedua lengan menyilang di dada (pose Osiris),
        // kepala sedikit tertunduk. Tiap dewa yang tiba membuat badan tersentak kecil. Mulai dewa ketiga lengan pelan-pelan
        // terbuka menerima kekuatan, telapak menghadap ke atas, kepala makin terangkat; menjelang akhir gemetar.
        Clip.Builder summon = Clip.builder(ShazamAnim.SUMMON_TICKS)
                .key(0, Ease.LINEAR).rightArm(-10, 0, 8).leftArm(-10, 0, -8).head(6, 0, 0).tilt(0)
                .key(7, Ease.OUT_CUBIC).rightArm(-68, -40, 0).leftArm(-68, 40, 0).head(14, 0, 0).legs(2).tilt(1).drop(0.02f);
        for (int i = 0; i < GodShow.ARRIVE.length; i++) {
            float u = i / (float) (GodShow.ARRIVE.length - 1);
            float at = GodShow.ARRIVE[i];
            if (i < 2) {   // dua dewa pertama: lengan tetap menyilang, cuma tersentak
                summon.key(at - 1.5f, Ease.IN_OUT_SINE).rightArm(-68, -40, 0).leftArm(-68, 40, 0).head(14 - 4 * i, 0, 0).shake(0f)
                        .key(at + 1, Ease.OUT_BACK).rightArm(-74, -42, 0).leftArm(-74, 42, 0).head(8 - 4 * i, 0, 0).tilt(-2)
                        .drop(-0.02f).shake(0.6f)
                        .key(at + 6, Ease.IN_OUT_SINE).rightArm(-70, -40, 0).leftArm(-70, 40, 0).head(11 - 4 * i, 0, 0).tilt(0)
                        .drop(0f).shake(0.12f);
                continue;
            }
            float w = (i - 2) / (float) (GodShow.ARRIVE.length - 3);   // 0..1 dari dewa ketiga sampai keenam
            float head = 4f - 34f * w;
            float open = 30f + 40f * w;
            float fwd = -40f + 14f * w;
            summon.key(at - 1.5f, Ease.IN_OUT_SINE).rightArm(fwd, 0, open).leftArm(fwd, 0, -open).head(head + 3, 0, 0)
                    .legs(3).tilt(2 - 8 * u).drop(0.02f - 0.14f * u).shake(0f)
                    .key(at + 1, Ease.OUT_BACK).rightArm(fwd - 8, 0, open + 8).leftArm(fwd - 8, 0, -open - 8).head(head - 7, 0, 0)
                    .tilt(-3 - 8 * u).drop(-0.04f - 0.14f * u).shake(0.8f)
                    .key(at + 6, Ease.IN_OUT_SINE).rightArm(fwd - 3, 0, open + 3).leftArm(fwd - 3, 0, -open - 3).head(head - 2, 0, 0)
                    .tilt(-8 * u).drop(-0.14f * u).shake(0.15f);
        }
        float end = ShazamAnim.SUMMON_TICKS;
        float settled = GodShow.ARRIVE[GodShow.ARRIVE.length - 1] + 6;
        summon.key(Math.min(end - 0.5f, Math.max(settled + 1, end - 4)), Ease.IN_OUT_SINE)
                .rightArm(-28, 0, 74).leftArm(-28, 0, -74).head(-32, 0, 0).legs(3).tilt(-9).drop(-0.18f).shake(1.0f)
                .key(end, Ease.IN_OUT_SINE)
                .rightArm(-28, 0, 72).leftArm(-28, 0, -72).head(-32, 0, 0).tilt(-9).drop(-0.18f).shake(1.4f);
        ADAM.put(ShazamAnim.SUMMON, summon.fade(4, 3).build());

        // Berubah: lengan kembali menyilang di dada sambil merunduk mengumpulkan tenaga, lalu kepalan kanan ke langit
        // (tick 7) sementara tangan kiri tetap di dada, gemetar menahan petir yang turun (8-18). Petir mengenai:
        // terangkat dengan lengan terentang, lalu turun dan berdiri buas: kepalan mengepal di samping, kepala sedikit
        // tertunduk menatap tajam, kaki terbuka lebar.
        ADAM.put(ShazamAnim.TRANSFORM, Clip.builder(54)
                .key(0, Ease.LINEAR).rightArm(-28, 0, 70).leftArm(-28, 0, -70).head(-30, 0, 0).legs(3).tilt(-8).drop(-0.15f)
                .key(3, Ease.OUT_CUBIC).rightArm(-64, -40, 0).leftArm(-64, 40, 0).head(16, 0, 0).legs(9).tilt(14).drop(0.18f)
                        .shake(0.6f)
                .key(7, Ease.OUT_QUAD).rightArm(-178, 0, -6).leftArm(-72, 36, 0).head(-42, 0, 0).legs(6).tilt(-10).drop(-0.06f)
                        .shake(0.9f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-183, 0, -4).leftArm(-76, 38, 0).head(-48, 0, 0).tilt(-12).drop(-0.08f)
                        .shake(1.9f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-177, 0, -7).leftArm(-72, 36, 0).head(-44, 0, 0).tilt(-10).drop(-0.05f)
                        .shake(2.8f)
                .key(19, Ease.OUT_QUAD).head(-18, 0, 0).tilt(-3).drop(0.12f).shake(0f)
                .key(24, Ease.OUT_CUBIC).rightArm(-100, 0, -78).leftArm(-100, 0, 78).head(-34, 0, 0).legs(10).tilt(-14).drop(-0.38f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-104, 0, -82).leftArm(-104, 0, 82).head(-38, 0, 0).tilt(-9).drop(-0.44f)
                .key(43, Ease.IN_OUT_SINE).rightArm(14, 0, 22).leftArm(14, 0, -22).head(14, 0, 0).legs(12).tilt(9).drop(0.16f)
                        .shake(0.3f)
                .key(50, Ease.OUT_CUBIC).rightArm(6, 0, 16).leftArm(6, 0, -16).head(8, 0, 0).legs(11).tilt(4).drop(0.04f).shake(0f)
                .fade(2, 6).build());

        // ===== Skill Black Adam (0.22: gerakan lebih tebal & sinematik, ancang-ancang besar, hantaman, tahanan) =====

        // S - Badai Shu: menarik napas dewa udara (lengan menyilang rendah, badan merunduk), lalu (tick 5) lengan
        // menghentak terbentang dan terangkat menyangga langit; badan terangkat dan berayun pelan dihantam badai; di akhir
        // kedua lengan menghempas ke bawah-samping saat badai meledak ke luar.
        float shuEnd = ShazamAnim.CAST_WINDUP + ShazamAnim.SHU_TICKS;
        putSkill(ShazamAnim.ADAM_SHU, Clip.builder(shuEnd + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-10, 0, 14).leftArm(-10, 0, -14).head(8, 0, 0).tilt(4).drop(0.06f)
                .key(3, Ease.IN_QUAD).rightArm(-44, -34, 0).leftArm(-44, 34, 0).head(18, 0, 0).legs(6).tilt(14).drop(0.2f)
                        .shake(1.1f)
                .key(ShazamAnim.CAST_WINDUP, Ease.OUT_BACK).rightArm(-4, 0, 98).leftArm(-4, 0, -98).head(-16, 0, 0).legs(11)
                        .tilt(-8).drop(-0.06f).shake(0.4f)
                .key(13, Ease.IN_OUT_SINE).rightArm(0, 0, 152).leftArm(0, 0, -152).head(-32, 0, 0).legs(9).tilt(-9)
                        .drop(-0.3f).lean(4).spin(14).shake(0.6f)
                .key(26, Ease.IN_OUT_SINE).rightArm(0, 0, 156).leftArm(0, 0, -150).head(-34, 0, 0).lean(-5).spin(-12)
                        .drop(-0.38f).shake(0.9f)
                .key(40, Ease.IN_OUT_SINE).rightArm(0, 0, 150).leftArm(0, 0, -156).head(-30, 0, 0).lean(4).spin(10)
                        .drop(-0.42f).shake(1.3f)
                .key(shuEnd - 3, Ease.IN_QUAD).rightArm(-6, 0, 160).leftArm(-6, 0, -160).head(-38, 0, 0).lean(0).spin(0)
                        .drop(-0.46f).shake(2.2f)
                .key(shuEnd, Ease.OUT_QUAD).rightArm(-24, 0, 58).leftArm(-24, 0, -58).head(14, 0, 0).legs(14).tilt(16)
                        .drop(0.24f).shake(3.0f)
                .key(shuEnd + 5, Ease.LINEAR).shake(0.8f)
                .key(shuEnd + 12, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0).legs(2).tilt(0)
                        .drop(0f).shake(0f)
                .fade(2, 5).build());

        // H - Sambaran Heru: merunduk rendah dengan lengan terlipat ke belakang seperti sayap elang (gemetar menahan
        // tenaga), lalu (tick 3) melesat: badan nyaris mendatar, lengan tersapu ke belakang di sisi badan, kaki lurus
        // ke belakang, kepala menatap ke depan. Di ujung sayap (lengan) terbentang lebar mengerem, badan menegak, lalu
        // mendarat merunduk.
        float heruEnd = ShazamAnim.HERU_WINDUP + ShazamAnim.HERU_TICKS;
        putSkill(ShazamAnim.ADAM_HERU, Clip.builder(heruEnd + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(36, 0, 26).leftArm(36, 0, -26).head(4, 0, 0).legs(10).tilt(28).drop(0.34f)
                        .shake(1.6f)
                .key(ShazamAnim.HERU_WINDUP, Ease.OUT_QUAD).rightArm(72, 0, 16).leftArm(72, 0, -16).head(-62, 0, 0)
                        .rightLeg(14, 0, 3).leftLeg(22, 0, -3).tilt(76).drop(-0.08f).shake(0f)
                .key(heruEnd - 1, Ease.LINEAR).rightArm(76, 0, 14).leftArm(76, 0, -14).head(-64, 0, 0).tilt(78)
                .key(heruEnd + 1, Ease.OUT_BACK).rightArm(-26, 0, 96).leftArm(-26, 0, -96).head(-8, 0, 0)
                        .rightLeg(-34, 0, 8).leftLeg(10, 0, -8).tilt(-20).drop(0.02f).shake(1.2f)
                .key(heruEnd + 4, Ease.OUT_QUAD).rightArm(6, 0, 40).leftArm(6, 0, -40).head(12, 0, 0)
                        .rightLeg(-30, 0, 8).leftLeg(20, 0, -8).tilt(14).drop(0.3f).shake(0.4f)
                .key(heruEnd + 12, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 2).leftLeg(0, 0, -2).tilt(0).drop(0f).shake(0f)
                .fade(1, 5).build());

        // A - Tinju Amon: merunduk menarik kedua kepalan ke belakang, melonjak tinggi dengan kepalan menyatu di atas
        // kepala dan badan melengkung ke belakang (tick 3), menukik (tick 6), lalu (tick 7) menghantam tanah: berlutut,
        // badan membungkuk dalam, gemetar hebat menahan getaran; bangkit pelan saat tanah terbelah merambat.
        putSkill(ShazamAnim.ADAM_AMON, Clip.builder(32)
                .key(0, Ease.OUT_CUBIC).rightArm(32, 0, 22).leftArm(32, 0, -22).head(10, 0, 0).legs(8).tilt(14).drop(0.2f)
                        .shake(1.0f)
                .key(3, Ease.OUT_CUBIC).rightArm(-178, 0, -12).leftArm(-178, 0, 12).head(-20, 0, 0)
                        .rightLeg(-34, 0, 4).leftLeg(16, 0, -4).tilt(-16).drop(-0.62f).shake(0.4f)
                .key(6, Ease.IN_QUAD).rightArm(-150, 0, -10).leftArm(-150, 0, 10).head(6, 0, 0).tilt(22).drop(-0.24f)
                        .shake(0.8f)
                .key(ShazamAnim.AMON_WINDUP, Ease.OUT_QUAD).rightArm(-28, 0, -10).leftArm(-28, 0, 10).head(26, 0, 0)
                        .rightLeg(-62, 0, 6).leftLeg(42, 0, -6).tilt(62).drop(0.86f).shake(3.4f)
                .key(10, Ease.LINEAR).shake(1.6f)
                .key(17, Ease.LINEAR).rightArm(-26, 0, -8).leftArm(-26, 0, 8).head(22, 0, 0).tilt(58).drop(0.82f).shake(0.9f)
                .key(26, Ease.IN_OUT_SINE).rightArm(6, 0, 18).leftArm(6, 0, -18).head(4, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(4).drop(0.04f).shake(0f)
                .key(32, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0).tilt(0).drop(0f)
                .fade(1, 5).build());

        // Z - Segel Zehuti: dua jari ke pelipis sambil menunduk, mata mulai menyala; tangan kiri terangkat setengah
        // dengan telapak terbuka seperti membaca gulungan. Lalu (tick 5) melangkah maju, tangan kanan menunjuk lurus
        // (mengikuti pandangan) dan tangan kiri terlempar ke belakang, pinggang berputar.
        putSkill(ShazamAnim.ADAM_ZEHUTI, Clip.builder(26)
                .key(0, Ease.OUT_CUBIC).rightArm(-142, -46, 0).leftArm(-38, 20, -12).head(12, 0, 0).tilt(4).shake(0.4f)
                .key(4, Ease.IN_OUT_SINE).rightArm(-148, -50, 0).leftArm(-52, 26, -10).head(18, 0, 0).drop(0.06f)
                        .shake(1.2f)
                .key(ShazamAnim.CAST_WINDUP, Ease.OUT_BACK).rightArm(-92, 0, 0).aim(1f).leftArm(26, 0, -52).head(-6, 0, 0)
                        .rightLeg(-24, 0, 4).leftLeg(16, 0, -4).twist(-22).tilt(8).drop(0.08f).shake(0f)
                .key(15, Ease.LINEAR).rightArm(-90, 0, 0).aim(1f).twist(-18)
                .key(26, Ease.IN_OUT_SINE).rightArm(-10, 0, 6).aim(0f).leftArm(-4, 0, -6).head(0, 0, 0)
                        .rightLeg(0, 0, 2).leftLeg(0, 0, -2).twist(0).tilt(0).drop(0f)
                .fade(2, 5).build());

        // A - Sinar Aton: kedua telapak mengumpulkan cahaya di depan dada, lalu telapak kanan menghentak ke langit
        // tempat cakram matahari terbentuk; tangan kiri terbuka ke samping, kepala mendongak menatap cakram, badan
        // berjinjit. Tiap sinar melesat, badan tersentak (gemetar berdenyut).
        float atonEnd = ShazamAnim.ATON_WINDUP + ShazamAnim.ATON_GAP * 6;
        putSkill(ShazamAnim.ADAM_ATON, Clip.builder(atonEnd + 16)
                .key(0, Ease.LINEAR).rightArm(-20, 0, 6).leftArm(-10, 0, -8).head(0, 0, 0)
                .key(4, Ease.OUT_CUBIC).rightArm(-58, -24, 0).leftArm(-58, 24, 0).head(10, 0, 0).tilt(6).drop(0.1f)
                        .shake(1.0f)
                .key(7, Ease.OUT_BACK).rightArm(-182, 0, -6).leftArm(-18, 0, -48).head(-40, 0, 0).legs(8).tilt(-10)
                        .drop(-0.1f).shake(1.4f)
                .key(ShazamAnim.ATON_WINDUP, Ease.LINEAR).shake(2.2f)
                .key(ShazamAnim.ATON_WINDUP + 3, Ease.LINEAR).tilt(-12).shake(1.6f)
                .key(ShazamAnim.ATON_WINDUP + 6, Ease.LINEAR).tilt(-9).shake(2.0f)
                .key(atonEnd, Ease.LINEAR).tilt(-11).shake(1.6f)
                .key(atonEnd + 6, Ease.IN_OUT_SINE).rightArm(-176, 0, -6).head(-34, 0, 0).tilt(-6).shake(0.6f)
                .key(atonEnd + 16, Ease.IN_OUT_SINE).rightArm(-10, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0).legs(2).tilt(0)
                        .drop(0f).shake(0f)
                .fade(2, 5).build());

        // M - Lilitan Mehen: lengan menyilang di dada (pose Osiris), pinggang berpilin dan badan merunduk saat ular
        // naik membelit, lalu (tick 6) kedua lengan menghentak terbuka ke bawah-samping, dada membusung, kepala mendongak.
        putSkill(ShazamAnim.ADAM_MEHEN, Clip.builder(28)
                .key(0, Ease.OUT_CUBIC).rightArm(-66, -40, 0).leftArm(-66, 40, 0).head(14, 0, 0).tilt(4).drop(0.08f)
                .key(5, Ease.IN_OUT_SINE).rightArm(-72, -44, 0).leftArm(-72, 44, 0).head(18, 0, 0).twist(20).drop(0.14f)
                        .shake(1.4f)
                .key(ShazamAnim.MEHEN_WINDUP, Ease.OUT_BACK).rightArm(-8, 0, 74).leftArm(-8, 0, -74).head(-26, 0, 0)
                        .legs(11).twist(0).tilt(-10).drop(-0.08f).shake(0.8f)
                .key(16, Ease.LINEAR).rightArm(-6, 0, 66).leftArm(-6, 0, -66).head(-20, 0, 0).shake(0.2f)
                .key(28, Ease.IN_OUT_SINE).rightArm(2, 0, 12).leftArm(2, 0, -12).head(0, 0, 0).legs(3).tilt(0).drop(0f)
                        .shake(0f)
                .fade(2, 5).build());

        // Murka Kahndaq: membungkuk, kepalan mengepal di samping, gemetar makin hebat sementara petir dari langit
        // terhisap ke badan; lalu (tick 10) meraung: lengan terlempar ke bawah-samping, dada membusung, kepala terlempar
        // ke belakang, badan terangkat dari tanah.
        putSkill(ShazamAnim.ADAM_RAGE, Clip.builder(34)
                .key(0, Ease.OUT_CUBIC).rightArm(12, 0, 16).leftArm(12, 0, -16).head(18, 0, 0).tilt(8).drop(0.06f).shake(1.4f)
                .key(6, Ease.IN_QUAD).rightArm(24, 0, 22).leftArm(24, 0, -22).head(28, 0, 0).legs(8).tilt(16).drop(0.22f)
                        .shake(4.2f)
                .key(9.5f, Ease.IN_QUAD).rightArm(28, 0, 18).leftArm(28, 0, -18).tilt(18).drop(0.26f).shake(5.6f)
                .key(ShazamAnim.ADAM_RAGE_WINDUP, Ease.OUT_BACK).rightArm(30, 0, 64).leftArm(30, 0, -64).head(-58, 0, 0)
                        .legs(12).tilt(-20).drop(-0.34f).shake(2.6f)
                .key(20, Ease.LINEAR).drop(-0.3f).shake(1.6f)
                .key(34, Ease.IN_OUT_SINE).rightArm(8, 0, 16).leftArm(8, 0, -16).head(-6, 0, 0).legs(3).tilt(-2).drop(0f)
                        .shake(0f)
                .fade(2, 5).build());

        // M (Black Adam) - Panggil Petir Kahndaq: menatap langit, kepalan kanan terangkat lurus ke langit sementara
        // kepalan kiri mengepal di samping, gemetar menunggu petir (sampai tick 12). Petir menyambar: badan tersentak
        // terangkat, lalu kedua lengan terbentang menyerap petir, dan kembali berdiri buas.
        putSkill(ShazamAnim.ADAM_CALL, Clip.builder(36)
                .key(0, Ease.OUT_CUBIC).rightArm(-96, 0, 12).leftArm(8, 0, -16).head(-18, 0, 0).tilt(2)
                .key(6, Ease.OUT_BACK).rightArm(-180, 0, -4).leftArm(14, 0, -22).head(-42, 0, 0).legs(7).tilt(-6)
                        .drop(-0.04f).shake(1.0f)
                .key(ShazamAnim.ADAM_CALL_WINDUP - 1, Ease.IN_QUAD).rightArm(-184, 0, -4).head(-46, 0, 0).shake(2.8f)
                .key(ShazamAnim.ADAM_CALL_WINDUP, Ease.OUT_QUAD).rightArm(-178, 0, -2).head(-30, 0, 0).tilt(-14).drop(-0.22f)
                        .shake(3.6f)
                .key(ShazamAnim.ADAM_CALL_WINDUP + 4, Ease.OUT_CUBIC).rightArm(-24, 0, 88).leftArm(-24, 0, -88)
                        .head(-26, 0, 0).legs(12).tilt(-12).drop(-0.3f).shake(1.8f)
                .key(ShazamAnim.ADAM_CALL_WINDUP + 14, Ease.IN_OUT_SINE).rightArm(-18, 0, 80).leftArm(-18, 0, -80)
                        .drop(-0.2f).shake(0.8f)
                .key(36, Ease.IN_OUT_SINE).rightArm(6, 0, 16).leftArm(6, 0, -16).head(4, 0, 0).legs(8).tilt(2).drop(0f)
                        .shake(0f)
                .fade(2, 6).build());

        // Lepas landas Black Adam: merunduk dalam dengan kepalan bergetar di sisi badan, lalu melesat ke atas dengan
        // kedua lengan lurus di sisi badan (bukan kepalan ke langit seperti Shazam), kepala menatap ke atas.
        ADAM.put(ShazamAnim.LAUNCH, Clip.builder(16)
                .key(0, Ease.OUT_QUAD).rightArm(18, 0, 18).leftArm(18, 0, -18).head(16, 0, 0).legs(10)
                        .rightLeg(-30, 0, 6).leftLeg(-30, 0, -6).tilt(16).drop(0.34f).shake(2f)
                .key(4, Ease.OUT_QUAD).rightArm(10, 0, 9).leftArm(10, 0, -9).head(-24, 0, 0)
                        .rightLeg(4, 0, 1).leftLeg(8, 0, -1).tilt(-3).drop(-0.12f).shake(0f)
                .key(10, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(6, 0, 12).leftArm(6, 0, -12).head(-8, 0, 0)
                        .rightLeg(4, 0, 2).leftLeg(8, 0, -2).tilt(0).drop(0f)
                .fade(1, 6).build());

        // Pendaratan Black Adam: menghantam tanah dengan dua kaki terbuka lebar, merunduk dalam (lengan terbuka ke
        // bawah-samping menahan keseimbangan, kepala tertunduk), lalu bangkit pelan sampai berdiri tegak dan dagu
        // terangkat: mengancam, bukan pose pahlawan.
        ADAM.put(ShazamAnim.LAND_HERO, Clip.builder(30)
                .key(0, Ease.OUT_QUAD).rightArm(16, 0, 42).leftArm(16, 0, -42).head(24, 0, 0).legs(15)
                        .rightLeg(-34, 0, 15).leftLeg(-34, 0, -15).tilt(22).drop(0.46f).shake(2.4f)
                .key(6, Ease.LINEAR).shake(0.4f)
                .key(16, Ease.IN_OUT_SINE).rightArm(8, 0, 22).leftArm(8, 0, -22).head(6, 0, 0).legs(12)
                        .rightLeg(-6, 0, 12).leftLeg(-6, 0, -12).tilt(4).drop(0.06f).shake(0f)
                .key(23, Ease.IN_OUT_SINE).head(-8, 0, 0).tilt(-2).drop(0f)
                .key(30, Ease.IN_OUT_SINE).rightArm(4, 0, 14).leftArm(4, 0, -14).head(0, 0, 0).legs(5)
                        .rightLeg(0, 0, 5).leftLeg(0, 0, -5).tilt(0)
                .fade(0.6f, 5).build());

        // ===== Jalan mendapatkan juara (wujud manusia) =====

        // Ujian Kahndaq: Skarabe Teth-Adam disodorkan ke depan, lalu diangkat tinggi ke langit sementara badai pasir
        // bangkit; tangan bergetar karena skarabenya berdenyut.
        CLIPS.put(ShazamAnim.KAHNDAQ_TRIAL, Clip.builder(70)
                .key(0, Ease.OUT_CUBIC).rightArm(-84, -6, 0).leftArm(-10, 0, -10).head(14, 0, 0)
                .key(16, Ease.IN_OUT_SINE).rightArm(-96, -4, 0).head(6, 0, 0).shake(0.4f)
                .key(30, Ease.OUT_BACK).rightArm(-176, 0, -4).leftArm(-6, 0, -28).head(-34, 0, 0).legs(6).tilt(-5)
                        .shake(0.8f)
                .key(56, Ease.LINEAR).shake(1.4f)
                .key(70, Ease.IN_OUT_SINE).rightArm(-10, 0, 6).leftArm(-4, 0, -6).head(0, 0, 0).legs(2).tilt(0).shake(0f)
                .fade(4, 8).build());

        // Skarabe bangkit: badan terangkat dari tanah dengan lengan terbentang dan kepala mendongak (diangkat dewa-dewa
        // Mesir), gemetar makin hebat; petir Kahndaq menyambar (tick 52): tersentak, lalu turun pelan.
        CLIPS.put(ShazamAnim.KAHNDAQ_AWAKEN, Clip.builder(ShazamAnim.KAHNDAQ_AWAKEN_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-40, 0, 40).leftArm(-40, 0, -40).head(-10, 0, 0).drop(0f)
                .key(20, Ease.IN_OUT_SINE).rightArm(-14, 0, 82).leftArm(-14, 0, -82).head(-34, 0, 0).legs(5).tilt(-8)
                        .drop(-0.5f).shake(0.6f)
                .key(ShazamAnim.KAHNDAQ_AWAKEN_STRIKE - 1, Ease.IN_QUAD).rightArm(-10, 0, 90).leftArm(-10, 0, -90)
                        .head(-46, 0, 0).tilt(-12).drop(-0.9f).shake(2.6f)
                .key(ShazamAnim.KAHNDAQ_AWAKEN_STRIKE + 1, Ease.OUT_QUAD).rightArm(-30, 0, 70).leftArm(-30, 0, -70)
                        .head(-20, 0, 0).tilt(-18).drop(-1.0f).shake(4f)
                .key(ShazamAnim.KAHNDAQ_AWAKEN_TICKS, Ease.IN_OUT_SINE).rightArm(6, 0, 16).leftArm(6, 0, -16).head(4, 0, 0)
                        .legs(9).tilt(4).drop(0f).shake(0f)
                .fade(4, 6).build());

        // Enam totem menyatu: kedua lengan terbuka menyambut totem-totem yang berputar, kepala mendongak; petir
        // Penyihir menyambar (tick 48): tersentak, lengan terbentang lebar.
        CLIPS.put(ShazamAnim.SHAZAM_CHOSEN, Clip.builder(ShazamAnim.SHAZAM_CHOSEN_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, 0, 30).leftArm(-60, 0, -30).head(-6, 0, 0)
                .key(20, Ease.IN_OUT_SINE).rightArm(-40, 0, 60).leftArm(-40, 0, -60).head(-28, 0, 0).legs(5).tilt(-6)
                        .drop(-0.2f).shake(0.4f)
                .key(ShazamAnim.SHAZAM_CHOSEN_STRIKE - 1, Ease.IN_QUAD).rightArm(-30, 0, 76).leftArm(-30, 0, -76)
                        .head(-40, 0, 0).tilt(-10).drop(-0.4f).shake(2f)
                .key(ShazamAnim.SHAZAM_CHOSEN_STRIKE + 1, Ease.OUT_QUAD).rightArm(-24, 0, 92).leftArm(-24, 0, -92)
                        .head(-24, 0, 0).tilt(-16).drop(-0.5f).shake(3.4f)
                .key(ShazamAnim.SHAZAM_CHOSEN_TICKS, Ease.IN_OUT_SINE).rightArm(0, 0, 10).leftArm(0, 0, -10).head(0, 0, 0)
                        .legs(4).tilt(0).drop(0f).shake(0f)
                .fade(4, 6).build());
    }

    // ================================================================== 0.32 Lintang

    static {
        // 0.33 Pengisian Sel Surya (sains, bukan cahaya dari langit): kaki dibuka, badan merendah, kepalan mengeras di sisi
        // badan; tenaga menumpuk di dalam tubuh sampai gemetar hebat. Kaki tetap menapak, nggak melayang.
        LINTANG.put(ShazamAnim.SUMMON, Clip.builder(ShazamAnim.SUMMON_TICKS)
                .key(0, Ease.LINEAR).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(6, 0, 0)
                .key(10, Ease.IN_OUT_SINE).rightArm(14, 0, 18).leftArm(14, 0, -18).head(12, 0, 0).legs(9).tilt(5).drop(0.08f)
                .key(30, Ease.IN_OUT_SINE).rightArm(-22, -8, 28).leftArm(-22, 8, -28).head(16, 0, 0).legs(13).tilt(10)
                        .drop(0.2f).shake(0.7f)
                .key(60, Ease.IN_OUT_SINE).rightArm(-34, -12, 34).leftArm(-34, 12, -34).head(20, 0, 0).legs(15).tilt(14)
                        .drop(0.3f).shake(1.8f)
                .key(ShazamAnim.SUMMON_TICKS, Ease.IN_QUAD).rightArm(-40, -14, 36).leftArm(-40, 14, -36).head(24, 0, 0)
                        .legs(16).tilt(17).drop(0.35f).shake(3.2f)
                .fade(4, 3).build());

        // 0.35 Ganti kostum ala Superman (tanpa sihir, LINTANG_SUIT_TICKS): kedua tangan mencengkeram kerah lalu merobek
        // kemeja ke samping (tick 6, lambang di dada terlihat), lengan dirapatkan dan badan berputar dua kali secepat
        // kilat (kostum & jubah terpasang di tick 12), lalu mendarat di pose pahlawan: tangan di pinggang, dada membusung.
        int rip = ShazamAnim.LINTANG_RIP, suit = ShazamAnim.LINTANG_SUITUP, len = ShazamAnim.LINTANG_SUIT_TICKS;
        LINTANG.put(ShazamAnim.TRANSFORM, Clip.builder(len)
                .key(0, Ease.LINEAR).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).legs(3).tilt(0).drop(0f).spin(0)
                .key(3, Ease.OUT_CUBIC).rightArm(-76, -38, 0).leftArm(-76, 38, 0).head(12, 0, 0).legs(5).tilt(5)
                .key(rip - 1, Ease.IN_QUAD).rightArm(-79, -30, 0).leftArm(-79, 30, 0).head(10, 0, 0).tilt(6).shake(1.2f)
                .key(rip, Ease.OUT_BACK).rightArm(-58, 56, 18).leftArm(-58, -56, -18).head(-12, 0, 0).legs(7).tilt(-9)
                        .shake(0f)
                .key(rip + 2, Ease.OUT_CUBIC).rightArm(-8, 0, 10).leftArm(-8, 0, -10).head(-4, 0, 0).legs(2).tilt(0).spin(0)
                .key(suit, Ease.IN_OUT_SINE).rightArm(-4, 0, 8).leftArm(-4, 0, -8).head(-2, 0, 0).legs(2).drop(-0.12f)
                        .spin(720)
                .key(suit + 3, Ease.OUT_BACK).rightArm(8, 0, 30).leftArm(8, 0, -30).head(-9, 0, 0).legs(8).tilt(-6)
                        .drop(0.04f).spin(720)
                .key(suit + 6, Ease.OUT_CUBIC).rightArm(6, 0, 27).leftArm(6, 0, -27).head(-7, 0, 0).tilt(-5).drop(0f)
                .key(len - 6, Ease.IN_OUT_SINE).rightArm(4, 0, 25).leftArm(4, 0, -25).head(-6, 0, 0).legs(8).tilt(-4)
                .key(len, Ease.OUT_CUBIC).rightArm(0, 0, 8).leftArm(0, 0, -8).head(-2, 0, 0).legs(4).tilt(0).drop(0f)
                .fade(1, 6).build());

        // 0.35 Kembali jadi manusia: berputar dua kali secepat kilat (kostum & jubah lepas di tick REVERT_WINDUP).
        int back = ShazamAnim.REVERT_WINDUP;
        LINTANG.put(ShazamAnim.REVERT, Clip.builder(back + 12)
                .key(0, Ease.LINEAR).rightArm(0, 0, 6).leftArm(0, 0, -6).head(0, 0, 0).legs(4).spin(0)
                .key(1, Ease.OUT_CUBIC).rightArm(-6, 0, 9).leftArm(-6, 0, -9).legs(2).spin(0)
                .key(back + 1, Ease.IN_OUT_SINE).rightArm(-4, 0, 8).leftArm(-4, 0, -8).drop(-0.08f).spin(720)
                .key(back + 4, Ease.OUT_CUBIC).rightArm(2, 0, 7).leftArm(2, 0, -7).head(4, 0, 0).legs(4).drop(0f).spin(720)
                .key(back + 12, Ease.OUT_CUBIC).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).legs(3).spin(720)
                .fade(1, 5).build());

        // 0.36 Angkat & Lempar (Shift + X), ala DLC Superman: beda dengan Hercules yang gemetar menahan beban, buat Lintang
        // musuhnya ringan. Meraih (tick 2), mengangkat lurus ke atas kepala tanpa gemetar (6), menahan sebentar dengan dada
        // membusung, lalu (tick 9) melempar dengan satu langkah ke depan.
        LINTANG.put(ShazamAnim.HERCULES_THROW, Clip.builder(20)
                .key(0, Ease.LINEAR).rightArm(-50, -10, 0).leftArm(-50, 10, 0).head(4, 0, 0).tilt(4)
                .key(2, Ease.OUT_QUAD).rightArm(-90, -14, 0).leftArm(-90, 14, 0).head(8, 0, 0).tilt(10).drop(0.08f)
                        .rightLeg(-12, 0, 4).leftLeg(10, 0, -4)
                .key(6, Ease.OUT_CUBIC).rightArm(-172, 0, -12).leftArm(-172, 0, 12).head(-18, 0, 0).tilt(-6).drop(0f)
                        .rightLeg(0, 0, 6).leftLeg(0, 0, -6)
                .key(8.2f, Ease.IN_QUAD).rightArm(-190, 0, -8).leftArm(-190, 0, 8).head(-14, 0, 0).tilt(-12).twist(8)
                .key(9.5f, Ease.OUT_BACK).rightArm(-50, 0, 0).leftArm(-50, 0, 0).head(4, 0, 0).tilt(18).drop(0.06f).twist(-10)
                        .rightLeg(-30, 0, 4).leftLeg(28, 0, -4)
                .key(13, Ease.LINEAR)
                .key(20, Ease.IN_OUT_SINE).rightArm(-10, 0, 6).leftArm(-10, 0, -6).head(0, 0, 0).tilt(0).drop(0f).twist(0)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(2, 5).build());

        // ===== Skill Lintang (cuma dikirim untuk Lintang, jadi cukup di daftar biasa) =====

        // L - Lesatan Bintang: merunduk mengumpulkan tenaga, lalu badan nyaris mendatar dengan kepalan kanan di depan.
        float dashEnd = ShazamAnim.LESAT_WINDUP + ShazamAnim.LESAT_TICKS;
        CLIPS.put(ShazamAnim.LINTANG_DASH, Clip.builder(dashEnd + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(20, 0, 10).leftArm(20, 0, -10).head(14, 0, 0).legs(6).tilt(14).drop(0.18f)
                        .shake(0.6f)
                .key(ShazamAnim.LESAT_WINDUP, Ease.OUT_BACK).rightArm(-170, 0, 0).leftArm(30, 0, -10).head(-60, 0, 0)
                        .rightLeg(20, 0, 2).leftLeg(30, 0, -2).tilt(70).drop(-0.1f).shake(0f)
                .key(dashEnd, Ease.LINEAR)
                .key(dashEnd + 8, Ease.OUT_CUBIC).rightArm(-10, 0, 8).leftArm(-10, 0, -8).head(0, 0, 0).legs(4).tilt(0)
                        .drop(0f)
                .fade(1, 4).build());

        // I - Iris Surya: kepalan mengepal di samping, badan sedikit condong & menegang, gemetar menahan panas di mata.
        float eyesEnd = ShazamAnim.IRIS_WINDUP + ShazamAnim.IRIS_TICKS;
        CLIPS.put(ShazamAnim.LINTANG_EYES, Clip.builder(eyesEnd + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(10, 0, 14).leftArm(10, 0, -14).head(10, 0, 0).legs(5).tilt(4).drop(0.04f)
                .key(ShazamAnim.IRIS_WINDUP, Ease.OUT_BACK).rightArm(18, 0, 22).leftArm(18, 0, -22).head(-4, 0, 0).legs(7)
                        .tilt(8).drop(0.08f).shake(1.2f)
                .key(eyesEnd, Ease.LINEAR).shake(1.6f)
                .key(eyesEnd + 8, Ease.OUT_CUBIC).rightArm(0, 0, 6).leftArm(0, 0, -6).head(0, 0, 0).legs(3).tilt(0).drop(0f)
                        .shake(0f)
                .fade(2, 5).build());

        // 0.42 I - Iris Surya di-charge: kepalan mengepal di samping, bahu menegang, kepala menunduk lalu menatap tajam ke depan,
        // badan makin bergetar menahan panas yang terkumpul di mata (ditahan sampai X dilepas)
        CLIPS.put(ShazamAnim.LINTANG_IRIS_CHARGE, Clip.builder(200)
                .key(0, Ease.OUT_CUBIC).rightArm(14, 0, 16).leftArm(14, 0, -16).head(14, 0, 0).legs(6).tilt(6).drop(0.06f)
                .key(ShazamAnim.IRIS_CHARGE_TICKS, Ease.IN_OUT_SINE).rightArm(22, 0, 24).leftArm(22, 0, -24).head(-2, 0, 0)
                        .legs(9).tilt(10).drop(0.1f).shake(1.6f)
                .key(200, Ease.LINEAR).shake(2.0f)
                .fade(3, 4).build());

        // 0.42 sinar dilepas: kepala tersentak ke depan, badan sedikit terdorong mundur oleh semburannya, lalu tenang lagi
        // (sinarnya sendiri tetap mengikuti arah pandang sampai habis)
        CLIPS.put(ShazamAnim.LINTANG_IRIS_FIRE, Clip.builder(18)
                .key(0, Ease.OUT_QUAD).rightArm(28, 0, 26).leftArm(28, 0, -26).head(-8, 0, 0).legs(9).tilt(-4).drop(0.08f)
                        .shake(1.4f)
                .key(4, Ease.LINEAR).shake(0.8f)
                .key(18, Ease.IN_OUT_SINE).rightArm(6, 0, 10).leftArm(6, 0, -10).head(0, 0, 0).legs(4).tilt(0).drop(0f)
                        .shake(0f)
                .fade(1, 6).build());

        // 0.42 L - Lintas Detik: merunduk sekejap, lalu (di mata dunia) sudah berdiri lagi dengan kepalan kanan baru saja
        // menghunjam, badan terpelintir, seperti baru selesai memukul semuanya
        float blitzEnd = ShazamAnim.BLITZ_WINDUP + 8 * ShazamAnim.BLITZ_STEP + ShazamAnim.BLITZ_RESUME;
        CLIPS.put(ShazamAnim.LINTANG_BLITZ, Clip.builder(blitzEnd + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(30, 0, 12).leftArm(30, 0, -12).head(16, 0, 0).rightLeg(-40, 0, 6)
                        .leftLeg(-30, 0, -6).tilt(18).drop(0.3f).shake(1.2f)
                .key(ShazamAnim.BLITZ_WINDUP, Ease.OUT_BACK).rightArm(-80, 0, 0).leftArm(20, 0, -20).head(-6, 0, 0)
                        .rightLeg(-20, 0, 4).leftLeg(18, 0, -4).tilt(10).drop(0.1f).twist(14).shake(0f)
                .key(blitzEnd, Ease.LINEAR)
                .key(blitzEnd + 10, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0).rightLeg(0, 0, 4)
                        .leftLeg(0, 0, -4).tilt(0).drop(0f).twist(0)
                .fade(1, 5).build());

        // 0.42 N - Nyala Mentari: kedua tangan menangkup di depan dada mengumpulkan cahaya (badan sedikit merunduk & bergetar),
        // lalu didorong lurus ke depan dengan kaki menahan
        float sunEnd = ShazamAnim.SUN_WINDUP + ShazamAnim.SUN_TRAVEL;
        CLIPS.put(ShazamAnim.LINTANG_SUN, Clip.builder(sunEnd + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(-50, -20, 0).leftArm(-50, 20, 0).head(10, 0, 0).legs(8).tilt(4).drop(0.08f)
                .key(ShazamAnim.SUN_WINDUP - 2, Ease.IN_OUT_SINE).rightArm(-60, -28, 0).leftArm(-60, 28, 0).head(14, 0, 0)
                        .tilt(8).drop(0.14f).shake(1.0f)
                .key(ShazamAnim.SUN_WINDUP + 2, Ease.OUT_BACK).rightArm(-95, -8, 0).leftArm(-95, 8, 0).head(-4, 0, 0)
                        .rightLeg(-20, 0, 6).leftLeg(16, 0, -6).tilt(-2).drop(0.06f).shake(0f)
                .key(sunEnd, Ease.LINEAR)
                .key(sunEnd + 10, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0).rightLeg(0, 0, 4)
                        .leftLeg(0, 0, -4).tilt(0).drop(0f)
                .fade(2, 6).build());

        // 0.42 tinju udara ke matahari mini: kepalan kanan ditarik, lalu menghunjam lurus dengan pinggang terpelintir
        CLIPS.put(ShazamAnim.LINTANG_SUN_PUNCH, Clip.builder(16)
                .key(0, Ease.OUT_QUAD).rightArm(30, 0, 10).leftArm(-20, 0, -20).head(4, 0, 0).tilt(6).twist(-14).drop(0.08f)
                .key(ShazamAnim.SUN_PUNCH_WINDUP, Ease.OUT_BACK).rightArm(-95, -10, 0).leftArm(-14, 0, -22)
                        .rightLeg(-14, 0, 6).leftLeg(14, 0, -6).tilt(10).twist(18).shake(1.4f)
                .key(8, Ease.LINEAR).shake(0f)
                .key(16, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0).rightLeg(0, 0, 4)
                        .leftLeg(0, 0, -4).tilt(0).twist(0).drop(0f)
                .fade(1, 4).build());

        // N - Napas Salju: menarik napas dalam (dada membusung, kepala ke belakang), lalu condong ke depan menghembus
        // dengan lengan tertarik ke belakang dan kaki menahan dorongan.
        float frostEnd = ShazamAnim.FROST_WINDUP + ShazamAnim.FROST_TICKS;
        CLIPS.put(ShazamAnim.LINTANG_BREATH, Clip.builder(frostEnd + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(-10, 0, 12).leftArm(-10, 0, -12).head(4, 0, 0).legs(5)
                .key(ShazamAnim.FROST_WINDUP - 1, Ease.IN_OUT_SINE).rightArm(-24, 0, 26).leftArm(-24, 0, -26).head(-30, 0, 0)
                        .tilt(-8).drop(-0.04f)
                .key(ShazamAnim.FROST_WINDUP + 2, Ease.OUT_BACK).rightArm(32, 0, 18).leftArm(32, 0, -18).head(8, 0, 0)
                        .rightLeg(-12, 0, 6).leftLeg(14, 0, -6).tilt(10).drop(0.1f).shake(0.8f)
                .key(frostEnd, Ease.LINEAR).shake(1.2f)
                .key(frostEnd + 8, Ease.OUT_CUBIC).rightArm(0, 0, 6).leftArm(0, 0, -6).head(0, 0, 0).legs(3).tilt(0).drop(0f)
                        .shake(0f)
                .fade(2, 5).build());

        // 0.37 Napas Topan (Shift + C): gerak badannya sama dengan Napas Salju (menarik napas, lalu menghembus)
        CLIPS.put(ShazamAnim.LINTANG_GUST, CLIPS.get(ShazamAnim.LINTANG_BREATH));

        // 0.37 Kombo Langit (Shift + Z) 1: merunduk, melesat dengan kepalan kanan ditarik ke belakang, lalu uppercut
        // dari bawah ke atas kepala dengan badan ikut terangkat.
        int up = ShazamAnim.COMBO_UPPERCUT;
        CLIPS.put(ShazamAnim.LINTANG_COMBO, Clip.builder(up + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(20, 0, 14).leftArm(-20, 0, -14).head(10, 0, 0).legs(7).tilt(18).drop(0.18f)
                .key(ShazamAnim.COMBO_DASH_WINDUP, Ease.OUT_QUAD).rightArm(40, 20, 10).leftArm(-60, -10, -10).head(-6, 0, 0)
                        .tilt(34).drop(0.06f).twist(-14)
                .key(up - 1, Ease.IN_QUAD).rightArm(46, 24, 10).leftArm(-64, -12, -10).tilt(30).twist(-20).drop(0.1f)
                .key(up + 1, Ease.OUT_BACK).rightArm(-168, -8, -6).leftArm(10, 0, -18).head(-28, 0, 0).tilt(-14).twist(18)
                        .drop(-0.12f).rightLeg(-24, 0, 4).leftLeg(16, 0, -4)
                .key(up + 8, Ease.IN_OUT_SINE).rightArm(-150, -6, -6).leftArm(6, 0, -14).head(-30, 0, 0).tilt(-10).twist(10)
                .fade(1, 3).build());

        // Kombo Langit 2: melesat naik ke atas sasaran yang melayang: lengan kanan menjulang, lengan kiri merapat ke badan.
        CLIPS.put(ShazamAnim.LINTANG_COMBO_RISE, Clip.builder(ShazamAnim.COMBO_RISE_TICKS + 4)
                .key(0, Ease.OUT_CUBIC).rightArm(-176, 0, -4).leftArm(8, 0, -8).head(-34, 0, 0).tilt(-4).rightLeg(4, 0, 2)
                        .leftLeg(-4, 0, -2)
                .key(ShazamAnim.COMBO_RISE_TICKS, Ease.OUT_BACK).rightArm(-150, 0, 20).leftArm(-150, 0, -20).head(30, 0, 0)
                        .tilt(16).rightLeg(-30, 0, 6).leftLeg(-30, 0, -6)
                .key(ShazamAnim.COMBO_RISE_TICKS + 4, Ease.IN_QUAD).rightArm(-172, 0, -6).leftArm(-172, 0, 6).head(36, 0, 0)
                        .tilt(22).shake(0.6f)
                .fade(1, 2).build());

        // Kombo Langit 3: dua kepalan dipadukan di atas kepala lalu dihantamkan ke bawah, badan ikut menukik ke tanah.
        int smash = ShazamAnim.COMBO_SMASH_TICKS;
        CLIPS.put(ShazamAnim.LINTANG_COMBO_SMASH, Clip.builder(smash + 14)
                .key(0, Ease.OUT_BACK).rightArm(-20, 0, -12).leftArm(-20, 0, 12).head(40, 0, 0).tilt(44).drop(0.1f)
                        .rightLeg(-40, 0, 6).leftLeg(-30, 0, -6).shake(0.8f)
                .key(smash, Ease.IN_QUAD).rightArm(-40, 0, -8).leftArm(-40, 0, 8).head(36, 0, 0).tilt(30).drop(0.2f)
                        .rightLeg(-60, 0, 8).leftLeg(40, 0, -8)
                .key(smash + 4, Ease.OUT_CUBIC).rightArm(20, 0, 30).leftArm(20, 0, -30).head(-6, 0, 0).tilt(10).drop(0.32f)
                        .rightLeg(-50, 0, 8).leftLeg(30, 0, -8).shake(0f)
                .key(smash + 14, Ease.IN_OUT_SINE).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0).tilt(0).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0)
                .fade(1, 4).build());

        // 0.37 Ledakan Surya (Shift + R): meringkuk mengumpulkan panas matahari (lengan menyilang di dada, kepala tertunduk,
        // lutut tertekuk, gemetar makin hebat selama 3 detik), lalu meledak: tubuh terbuka lebar dengan lengan
        // terentang ke langit dan kepala mendongak.
        int nova = ShazamAnim.SOLAR_NOVA_WINDUP;
        CLIPS.put(ShazamAnim.LINTANG_NOVA, Clip.builder(nova + 30)
                .key(0, Ease.OUT_CUBIC).rightArm(-40, -30, 0).leftArm(-40, 30, 0).head(20, 0, 0).legs(6).tilt(10).drop(0.1f)
                .key(10, Ease.IN_OUT_SINE).rightArm(-80, -62, 0).leftArm(-80, 62, 0).head(42, 0, 0).tilt(28).drop(0.3f)
                        .rightLeg(-50, 0, 6).leftLeg(-50, 0, -6).shake(0.6f)
                .key(nova - 12, Ease.IN_OUT_SINE).rightArm(-86, -66, 0).leftArm(-86, 66, 0).head(46, 0, 0).tilt(32).drop(0.36f)
                        .rightLeg(-60, 0, 6).leftLeg(-60, 0, -6).shake(2.4f)
                .key(nova - 1, Ease.IN_QUAD).rightArm(-90, -70, 0).leftArm(-90, 70, 0).head(48, 0, 0).tilt(34).drop(0.4f)
                        .rightLeg(-64, 0, 6).leftLeg(-64, 0, -6).shake(4.5f)
                .key(nova + 1, Ease.OUT_BACK).rightArm(-160, 0, -60).leftArm(-160, 0, 60).head(-46, 0, 0).tilt(-18).drop(-0.3f)
                        .rightLeg(-10, 0, 18).leftLeg(-10, 0, -18).shake(2.5f)
                .key(nova + 16, Ease.IN_OUT_SINE).rightArm(-150, 0, -50).leftArm(-150, 0, 50).head(-38, 0, 0).tilt(-12)
                        .drop(-0.2f).shake(0.6f)
                .key(nova + 30, Ease.OUT_CUBIC).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0).legs(4).tilt(0).drop(0f)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0).shake(0f)
                .fade(2, 5).build());

        // T - Tepukan Guruh: kedua lengan terentang lebar ke belakang (gemetar), lalu ditepukkan di depan dada.
        CLIPS.put(ShazamAnim.LINTANG_CLAP, Clip.builder(ShazamAnim.SONIC_WINDUP + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-70, 60, 0).leftArm(-70, -60, 0).head(-6, 0, 0).legs(6).tilt(-6).drop(0.06f)
                .key(ShazamAnim.SONIC_WINDUP - 1, Ease.IN_QUAD).rightArm(-82, 88, 0).leftArm(-82, -88, 0).head(-10, 0, 0)
                        .legs(8).tilt(-10).drop(0.1f).shake(1.5f)
                .key(ShazamAnim.SONIC_WINDUP, Ease.OUT_BACK).rightArm(-92, -16, 0).leftArm(-92, 16, 0).head(6, 0, 0).legs(10)
                        .tilt(10).drop(0.14f).shake(0.4f)
                .key(ShazamAnim.SONIC_WINDUP + 8, Ease.LINEAR).shake(0f)
                .key(ShazamAnim.SONIC_WINDUP + 16, Ease.OUT_CUBIC).rightArm(-6, 0, 6).leftArm(-6, 0, -6).head(0, 0, 0).legs(4)
                        .tilt(0).drop(0f)
                .fade(1, 4).build());

        // A - Amukan Kilat: kuda-kuda, lalu pukulan kiri-kanan bergantian tiap 2 tick (sedikit menyebar), ditutup uppercut.
        float barrageEnd = ShazamAnim.BARRAGE_WINDUP + ShazamAnim.BARRAGE_TICKS;
        Clip.Builder barrage = Clip.builder(barrageEnd + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(10, 0, 12).leftArm(10, 0, -12).head(6, 0, 0).legs(7).tilt(8).drop(0.08f);
        for (int i = 0; i < ShazamAnim.BARRAGE_TICKS / 2; i++) {
            boolean right = i % 2 == 0;
            float spread = (i % 3 - 1) * 8f;
            barrage.key(ShazamAnim.BARRAGE_WINDUP + i * 2, Ease.OUT_QUAD)
                    .rightArm(right ? -92 : -30, right ? -8 + spread : 10, 0)
                    .leftArm(right ? -30 : -92, right ? -10 : 8 + spread, 0)
                    .twist(right ? 16 : -16).tilt(12).drop(0.1f).shake(0.8f);
        }
        barrage.key(barrageEnd, Ease.OUT_BACK).rightArm(-150, -10, 0).leftArm(20, 0, -20).twist(24).tilt(-6).head(-20, 0, 0)
                        .drop(-0.05f).shake(0f)
                .key(barrageEnd + 8, Ease.OUT_CUBIC).rightArm(-6, 0, 6).leftArm(-6, 0, -6).twist(0).tilt(0).head(0, 0, 0)
                        .drop(0f);
        CLIPS.put(ShazamAnim.LINTANG_BARRAGE, barrage.fade(1, 4).build());

        // N - Napak Langit: merunduk, melompat dengan lengan ke atas, meringkuk di puncak, lalu menukik kepalan duluan.
        CLIPS.put(ShazamAnim.LINTANG_LEAP, Clip.builder(34)
                .key(0, Ease.OUT_CUBIC).rightArm(30, 0, 14).leftArm(30, 0, -14).head(14, 0, 0).legs(8).tilt(20).drop(0.3f)
                .key(ShazamAnim.LEAP_WINDUP, Ease.OUT_BACK).rightArm(-170, 0, -10).leftArm(-170, 0, 10).head(-20, 0, 0)
                        .tilt(-10).drop(-0.2f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-120, 0, 10).leftArm(-120, 0, -10).rightLeg(-60, 0, 4).leftLeg(-60, 0, -4)
                        .head(10, 0, 0).tilt(20)
                .key(18, Ease.OUT_BACK).rightArm(-176, 0, -4).leftArm(-176, 0, 4).rightLeg(0, 0, 2).leftLeg(0, 0, -2)
                        .head(-40, 0, 0).tilt(80).shake(0.6f)
                .key(34, Ease.LINEAR).shake(0.8f)
                .fade(1, 4).build());

        // G - Gelegar Surya: lengan menyilang di dada mengumpulkan cahaya (gemetar makin hebat), lalu terlempar terbuka
        // ke atas membentuk V dengan kepala terdongak saat cahaya meledak.
        CLIPS.put(ShazamAnim.LINTANG_FLARE, Clip.builder(ShazamAnim.FLARE_WINDUP + 26)
                .key(0, Ease.OUT_CUBIC).rightArm(-70, -50, 0).leftArm(-70, 50, 0).head(16, 0, 0).legs(7).tilt(10).drop(0.12f)
                        .shake(0.6f)
                .key(ShazamAnim.FLARE_WINDUP - 1, Ease.IN_QUAD).rightArm(-80, -58, 0).leftArm(-80, 58, 0).head(24, 0, 0).legs(9)
                        .tilt(16).drop(0.22f).shake(3.2f)
                .key(ShazamAnim.FLARE_WINDUP, Ease.OUT_BACK).rightArm(-150, 0, -35).leftArm(-150, 0, 35).head(-40, 0, 0)
                        .legs(12).tilt(-16).drop(-0.3f).shake(2f)
                .key(ShazamAnim.FLARE_WINDUP + 14, Ease.IN_OUT_SINE).rightArm(-146, 0, -32).leftArm(-146, 0, 32).head(-34, 0, 0)
                        .tilt(-12).drop(-0.25f).shake(0.6f)
                .key(ShazamAnim.FLARE_WINDUP + 26, Ease.OUT_CUBIC).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0).legs(4)
                        .tilt(0).drop(0f).shake(0f)
                .fade(2, 5).build());

        // M - Serap Surya: kedua lengan terangkat ke langit dengan telapak terbuka, lalu tersentak saat cahaya menghunjam.
        CLIPS.put(ShazamAnim.LINTANG_CALL, Clip.builder(ShazamAnim.SUNCALL_WINDUP + 22)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, 0, 20).leftArm(-60, 0, -20).head(-10, 0, 0).legs(5)
                .key(ShazamAnim.SUNCALL_WINDUP - 1, Ease.IN_OUT_SINE).rightArm(-165, 0, 22).leftArm(-165, 0, -22)
                        .head(-38, 0, 0).tilt(-6).drop(-0.05f).shake(1.0f)
                .key(ShazamAnim.SUNCALL_WINDUP, Ease.OUT_BACK).rightArm(-150, 0, 40).leftArm(-150, 0, -40).head(-30, 0, 0)
                        .tilt(-10).drop(-0.15f).shake(2.2f)
                .key(ShazamAnim.SUNCALL_WINDUP + 22, Ease.OUT_CUBIC).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0)
                        .legs(4).tilt(0).drop(0f).shake(0f)
                .fade(2, 5).build());

        // J - Selamatkan: merunduk sesaat lalu condong ke depan secepat kilat (badannya digerakkan oleh jejak cahaya).
        CLIPS.put(ShazamAnim.LINTANG_RESCUE, Clip.builder(ShazamAnim.RESCUE_WINDUP + 18)
                .key(0, Ease.OUT_CUBIC).rightArm(18, 0, 10).leftArm(18, 0, -10).head(12, 0, 0).legs(6).tilt(14).drop(0.16f)
                .key(ShazamAnim.RESCUE_WINDUP, Ease.OUT_BACK).rightArm(-40, 0, 40).leftArm(-40, 0, -40).head(-20, 0, 0)
                        .tilt(30).drop(0.05f).shake(0.5f)
                .key(ShazamAnim.RESCUE_WINDUP + 18, Ease.OUT_CUBIC).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0)
                        .legs(4).tilt(0).drop(0f).shake(0f)
                .fade(1, 4).build());

        // 0.33 Eksperimen Evolusi Surya (wujud manusia, 136 tick = LintangRite.LENGTH): menyuntik serum di lengan kiri,
        // lengan terbuka menyerap foton dengan kepala mendongak ke matahari, kejang saat DNA bermutasi, jatuh berlutut
        // menahan sakit, lalu tick 104 tubuh meledakkan cahaya dari dalam dan bangkit berdiri.
        CLIPS.put(ShazamAnim.LINTANG_RITE, Clip.builder(136)
                .key(0, Ease.OUT_CUBIC).head(24, -12, 0).leftArm(-82, 30, 0).rightArm(-66, -52, 0).tilt(4)
                .key(14, Ease.IN_OUT_SINE).head(26, -14, 0).leftArm(-84, 32, 0).rightArm(-70, -56, 0).shake(0.6f)
                .key(24, Ease.OUT_CUBIC).head(-34, 0, 0).rightArm(-38, 0, 62).leftArm(-38, 0, -62).tilt(-5).shake(0.4f)
                .key(64, Ease.IN_OUT_SINE).head(-44, 0, 0).rightArm(-28, 0, 78).leftArm(-28, 0, -78).tilt(-9).drop(-0.04f)
                        .shake(1.6f)
                .key(74, Ease.OUT_QUAD).head(30, 0, 0).rightArm(-80, -42, 0).leftArm(-76, 40, 0).tilt(26).drop(0.16f)
                        .shake(5f)
                .key(82, Ease.IN_QUAD).head(38, 0, 0).rightArm(-42, 0, 20).leftArm(-62, 0, -28).rightLeg(-80, 0, 8)
                        .leftLeg(60, 0, -8).tilt(32).drop(0.58f).shake(4f)
                .key(100, Ease.IN_OUT_SINE).head(42, 0, 0).rightArm(-22, 0, 40).leftArm(-22, 0, -40).tilt(38).drop(0.6f)
                        .shake(6f)
                .key(106, Ease.OUT_BACK).head(-50, 0, 0).rightArm(-30, 0, 98).leftArm(-30, 0, -98).rightLeg(-18, 0, 10)
                        .leftLeg(14, 0, -10).tilt(-14).drop(0.18f).shake(2f)
                .key(122, Ease.IN_OUT_SINE).head(-6, 0, 0).rightArm(6, 0, 14).leftArm(6, 0, -14).rightLeg(0, 0, 4)
                        .leftLeg(0, 0, -4).tilt(0).drop(0f).shake(0.3f)
                .key(136, Ease.IN_OUT_SINE).head(0, 0, 0).rightArm(0, 0, 8).leftArm(0, 0, -8).shake(0f)
                .fade(3, 10).build());
    }

    // ================================================================== 0.43 Projek Helion-6

    static {
        // Berubah wujud (HELION_SUIT_TICKS): kaki dibuka, kepalan mengeras, badan merunduk & bergetar makin hebat selama
        // radiasi Cryon menjalar (kepala tertunduk), lalu di HELION_SUITUP radiasinya meledak keluar: lengan terlempar
        // terbuka ke bawah-samping, dada membusung, kepala mendongak. Ditutup sikap angkuh dengan lengan bersilang di dada.
        int hs = ShazamAnim.HELION_SUITUP, hl = ShazamAnim.HELION_SUIT_TICKS;
        HELION.put(ShazamAnim.TRANSFORM, Clip.builder(hl)
                .key(0, Ease.LINEAR).rightArm(0, 0, 6).leftArm(0, 0, -6).head(0, 0, 0).legs(3).tilt(0).drop(0f)
                .key(4, Ease.OUT_CUBIC).rightArm(12, 0, 22).leftArm(12, 0, -22).head(18, 0, 0).legs(8).tilt(10).drop(0.12f)
                        .shake(0.8f)
                .key(hs - 3, Ease.IN_QUAD).rightArm(26, -10, 30).leftArm(26, 10, -30).head(30, 0, 0).legs(11).tilt(18)
                        .drop(0.26f).shake(3.2f)
                .key(hs, Ease.OUT_BACK).rightArm(-20, 0, 70).leftArm(-20, 0, -70).head(-38, 0, 0).legs(14).tilt(-14)
                        .drop(-0.08f).shake(2.0f)
                .key(hs + 6, Ease.IN_OUT_SINE).rightArm(-14, 0, 62).leftArm(-14, 0, -62).head(-30, 0, 0).tilt(-10)
                        .drop(-0.04f).shake(0.8f)
                .key(hs + 16, Ease.IN_OUT_SINE).rightArm(-58, -36, 5).leftArm(-64, 34, -5).head(-6, 0, 0).legs(9).tilt(-2)
                        .drop(0f).shake(0f)
                .key(hl, Ease.OUT_CUBIC).rightArm(-60, -38, 5).leftArm(-66, 36, -5).head(-8, 0, 0).legs(8).tilt(-2)
                .fade(1, 8).build());

        // Kembali jadi manusia: radiasi padam - bahu turun, kepala tertunduk, tubuh sedikit goyah, lalu tegak lagi.
        int rb = ShazamAnim.REVERT_WINDUP;
        HELION.put(ShazamAnim.REVERT, Clip.builder(rb + 16)
                .key(0, Ease.LINEAR).rightArm(0, 0, 6).leftArm(0, 0, -6).head(0, 0, 0).legs(4)
                .key(rb, Ease.OUT_CUBIC).rightArm(10, 0, 18).leftArm(10, 0, -18).head(22, 0, 0).tilt(10).drop(0.1f).shake(1.2f)
                .key(rb + 8, Ease.IN_OUT_SINE).rightArm(4, 0, 10).leftArm(4, 0, -10).head(12, 0, 0).tilt(4).drop(0.04f)
                        .shake(0.3f)
                .key(rb + 16, Ease.OUT_CUBIC).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f).shake(0f)
                .fade(1, 5).build());

        // ===== Skill Helion-6 (cuma dikirim untuk Helion-6, jadi cukup di daftar biasa) =====

        // H - Hempasan Lesat: merunduk dengan bahu kanan di depan (lengan menyilang dada), lalu menerjang bahu duluan.
        float hd = ShazamAnim.HELION_DASH_WINDUP + ShazamAnim.HELION_DASH_TICKS;
        CLIPS.put(ShazamAnim.HELION_DASH, Clip.builder(hd + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, -40, 0).leftArm(20, 0, -14).head(16, 0, 0).rightLeg(-30, 0, 4)
                        .leftLeg(16, 0, -4).tilt(24).drop(0.22f).shake(1.0f)
                .key(ShazamAnim.HELION_DASH_WINDUP, Ease.OUT_BACK).rightArm(-82, -52, 0).leftArm(36, 0, -10).head(-40, 0, 0)
                        .rightLeg(16, 0, 2).leftLeg(34, 0, -2).tilt(62).drop(-0.05f).shake(0f)
                .key(hd, Ease.LINEAR)
                .key(hd + 8, Ease.OUT_CUBIC).rightArm(-6, 0, 8).leftArm(-6, 0, -8).head(0, 0, 0).rightLeg(0, 0, 2)
                        .leftLeg(0, 0, -2).tilt(0).drop(0f)
                .fade(1, 4).build());

        // E - Emisi Cryon: kepalan mengepal di samping, bahu menegang, badan bergetar makin hebat saat radiasi terkumpul di
        // mata, lalu sedikit terdorong mundur oleh semburan sinar. Kepala nggak diatur: tetap mengikuti arah pandang.
        float he = ShazamAnim.HELION_EYES_WINDUP + ShazamAnim.HELION_EYES_TICKS;
        CLIPS.put(ShazamAnim.HELION_EYES, Clip.builder(he + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(16, 0, 18).leftArm(16, 0, -18).legs(7).tilt(8).drop(0.08f).shake(0.6f)
                .key(ShazamAnim.HELION_EYES_WINDUP - 1, Ease.IN_QUAD).rightArm(24, 0, 26).leftArm(24, 0, -26).tilt(12)
                        .drop(0.12f).shake(2.4f)
                .key(ShazamAnim.HELION_EYES_WINDUP + 1, Ease.OUT_BACK).rightArm(30, 0, 30).leftArm(30, 0, -30).legs(10)
                        .tilt(-6).drop(0.06f).shake(1.6f)
                .key(he, Ease.LINEAR).shake(2.0f)
                .key(he + 10, Ease.OUT_CUBIC).rightArm(0, 0, 6).leftArm(0, 0, -6).legs(4).tilt(0).drop(0f).shake(0f)
                .fade(2, 6).build());

        // I - Injakan Cryon: merunduk, melompat dengan kedua kepalan terangkat tinggi, lalu (HELION_QUAKE_WINDUP) jatuh
        // berlutut dengan kedua kepalan menghantam tanah, ditahan sebentar, lalu bangkit bersilang tangan.
        int hq = ShazamAnim.HELION_QUAKE_WINDUP;
        CLIPS.put(ShazamAnim.HELION_QUAKE, Clip.builder(hq + 22)
                .key(0, Ease.OUT_CUBIC).rightArm(20, 0, 16).leftArm(20, 0, -16).head(10, 0, 0).legs(8).tilt(12).drop(0.2f)
                .key(5, Ease.OUT_QUAD).rightArm(-176, 0, -14).leftArm(-176, 0, 14).head(-26, 0, 0).legs(4).tilt(-10)
                        .drop(-0.45f)
                .key(hq - 2, Ease.IN_QUAD).rightArm(-190, 0, -8).leftArm(-190, 0, 8).head(-10, 0, 0).tilt(-4).drop(-0.3f)
                        .shake(1.2f)
                .key(hq, Ease.OUT_BACK).rightArm(-70, 0, -6).leftArm(-70, 0, 6).head(34, 0, 0).rightLeg(-80, 0, 8)
                        .leftLeg(50, 0, -6).tilt(46).drop(0.72f).shake(2.4f)
                .key(hq + 10, Ease.IN_OUT_SINE).rightArm(-66, 0, -4).leftArm(-66, 0, 4).head(26, 0, 0).tilt(40).drop(0.68f)
                        .shake(0.6f)
                .key(hq + 22, Ease.OUT_CUBIC).rightArm(-58, -36, 5).leftArm(-64, 34, -5).head(-6, 0, 0).rightLeg(0, 0, 4)
                        .leftLeg(0, 0, -4).tilt(0).drop(0f).shake(0f)
                .fade(1, 6).build());

        // 6 - Supernova-6: meringkuk menyerap radiasi (lengan menyilang di dada, kepala tertunduk, lutut ditekuk, gemetar
        // makin hebat selama 3 detik), lalu tubuh terbuka lebar dengan lengan terentang dan kepala mendongak saat meledak.
        int hn = ShazamAnim.HELION_NOVA_WINDUP;
        CLIPS.put(ShazamAnim.HELION_NOVA, Clip.builder(hn + 34)
                .key(0, Ease.OUT_CUBIC).rightArm(-40, -30, 0).leftArm(-40, 30, 0).head(20, 0, 0).legs(6).tilt(10).drop(0.1f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-84, -64, 0).leftArm(-84, 64, 0).head(44, 0, 0).tilt(30).drop(0.32f)
                        .rightLeg(-54, 0, 6).leftLeg(-54, 0, -6).shake(0.8f)
                .key(hn - 10, Ease.IN_OUT_SINE).rightArm(-88, -68, 0).leftArm(-88, 68, 0).head(48, 0, 0).tilt(34).drop(0.38f)
                        .rightLeg(-62, 0, 6).leftLeg(-62, 0, -6).shake(3.0f)
                .key(hn - 1, Ease.IN_QUAD).rightArm(-92, -72, 0).leftArm(-92, 72, 0).head(50, 0, 0).tilt(36).drop(0.42f)
                        .rightLeg(-66, 0, 6).leftLeg(-66, 0, -6).shake(5.5f)
                .key(hn + 1, Ease.OUT_BACK).rightArm(-150, 0, -78).leftArm(-150, 0, 78).head(-50, 0, 0).tilt(-20).drop(-0.35f)
                        .rightLeg(-8, 0, 20).leftLeg(-8, 0, -20).shake(3.0f)
                .key(hn + 18, Ease.IN_OUT_SINE).rightArm(-140, 0, -64).leftArm(-140, 0, 64).head(-40, 0, 0).tilt(-14)
                        .drop(-0.25f).shake(0.8f)
                .key(hn + 34, Ease.OUT_CUBIC).rightArm(-58, -36, 5).leftArm(-64, 34, -5).head(0, 0, 0).tilt(0).drop(0f)
                        .rightLeg(0, 0, 3).leftLeg(0, 0, -3).shake(0f)
                .fade(2, 6).build());

        // M - Hirup Cryon: pecahan Cryon dibawa ke depan wajah, diremukkan di genggaman (gemetar), dihirup dalam-dalam
        // (kepala mendongak, dada membusung), lalu radiasinya meledak ke seluruh tubuh: lengan terbuka, kepalan mengepal.
        int hi = ShazamAnim.HELION_INHALE_WINDUP;
        CLIPS.put(ShazamAnim.HELION_INHALE, Clip.builder(hi + 26)
                .key(0, Ease.OUT_CUBIC).rightArm(-70, -20, 0).leftArm(6, 0, -10).head(10, 0, 0).tilt(4)
                .key(4, Ease.OUT_QUAD).rightArm(-112, -40, 0).head(16, 0, 0)
                .key(6, Ease.OUT_BACK).rightArm(-116, -44, 0).shake(2.2f)
                .key(9, Ease.IN_OUT_SINE).rightArm(-128, -38, 0).head(-6, 0, 0).shake(0.6f)
                .key(hi - 1, Ease.IN_QUAD).rightArm(-120, -30, 0).leftArm(10, 0, -16).head(-34, 0, 0).tilt(-10).drop(-0.05f)
                        .shake(1.2f)
                .key(hi + 1, Ease.OUT_BACK).rightArm(-26, 0, 64).leftArm(-26, 0, -64).head(-24, 0, 0).legs(12).tilt(-6)
                        .drop(0.06f).shake(3.0f)
                .key(hi + 12, Ease.IN_OUT_SINE).rightArm(-18, 0, 52).leftArm(-18, 0, -52).head(-14, 0, 0).tilt(-3).shake(1.0f)
                .key(hi + 26, Ease.OUT_CUBIC).rightArm(-58, -36, 5).leftArm(-64, 34, -5).head(0, 0, 0).legs(5).tilt(0)
                        .drop(0f).shake(0f)
                .fade(2, 6).build());

        // Radiasi habis di bawah matahari: tersentak memegang dada, jatuh satu lutut, terengah, lalu bangkit pelan.
        CLIPS.put(ShazamAnim.HELION_COLLAPSE, Clip.builder(ShazamAnim.HELION_COLLAPSE_TICKS)
                .key(0, Ease.OUT_QUAD).rightArm(-60, -30, 0).leftArm(-30, 0, -20).head(30, 0, 0).tilt(18).drop(0.1f).shake(2.0f)
                .key(8, Ease.IN_QUAD).rightArm(-50, -40, 0).leftArm(-70, 0, -10).head(38, 0, 0).rightLeg(-80, 0, 8)
                        .leftLeg(50, 0, -6).tilt(34).drop(0.6f).shake(3.0f)
                .key(28, Ease.IN_OUT_SINE).head(30, 0, 0).tilt(30).drop(0.58f).shake(1.0f)
                .key(ShazamAnim.HELION_COLLAPSE_TICKS, Ease.OUT_CUBIC).rightArm(0, 0, 6).leftArm(0, 0, -6).head(0, 0, 0)
                        .rightLeg(0, 0, 0).leftLeg(0, 0, 0).tilt(0).drop(0f).shake(0f)
                .fade(1, 8).build());

        // 0.45 L - Lahap Radiasi: lengan terentang lebar, telapak terbuka, kepala mendongak menghisap, badan bergetar.
        int lt = ShazamAnim.HELION_LAHAP_TICKS;
        CLIPS.put(ShazamAnim.HELION_LAHAP, Clip.builder(lt + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(-6, 0, 0).legs(8).tilt(-4)
                .key(6, Ease.OUT_BACK).rightArm(-70, 0, 70).leftArm(-70, 0, -70).head(-30, 0, 0).legs(12).tilt(-10).drop(0.04f)
                        .shake(0.8f)
                .key(lt - 6, Ease.IN_OUT_SINE).rightArm(-78, 0, 76).leftArm(-78, 0, -76).head(-36, 0, 0).tilt(-12).shake(1.6f)
                .key(lt, Ease.OUT_CUBIC).rightArm(-40, 0, 40).leftArm(-40, 0, -40).head(-10, 0, 0).tilt(-4).shake(0.4f)
                .key(lt + 12, Ease.OUT_CUBIC).rightArm(-58, -36, 5).leftArm(-64, 34, -5).head(0, 0, 0).legs(5).tilt(0).drop(0f)
                        .shake(0f)
                .fade(2, 6).build());

        // 0.45 O - Orbit Cryon: lengan bersilang lalu dihentak terbuka (kristal terbentuk), lalu lengan kanan menunjuk ke
        // depan selama kristal dilepas satu per satu. Kepala tetap mengikuti arah pandang.
        int ot = ShazamAnim.HELION_ORBIT_TICKS;
        CLIPS.put(ShazamAnim.HELION_ORBIT, Clip.builder(ot + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(-58, -36, 5).leftArm(-64, 34, -5).legs(6).tilt(4).drop(0.06f).shake(1.0f)
                .key(9, Ease.OUT_BACK).rightArm(-40, 0, 80).leftArm(-40, 0, -80).legs(10).tilt(-6).drop(0f).shake(0.6f)
                .key(18, Ease.IN_OUT_SINE).rightArm(-88, -10, 0).leftArm(-10, 0, -20).legs(8).tilt(4)
                .key(ot - 6, Ease.LINEAR).rightArm(-90, -14, 0).leftArm(-12, 0, -22).shake(0.4f)
                .key(ot + 10, Ease.OUT_CUBIC).rightArm(-58, -36, 5).leftArm(-64, 34, -5).legs(5).tilt(0).shake(0f)
                .fade(2, 6).build());

        // 0.45 N - Nisan Kristal: telapak kanan diangkat tinggi, lalu dihantamkan ke tanah sambil berlutut (kristal mulai
        // meletus), ditahan sebentar, lalu bangkit bersilang tangan.
        int nw = ShazamAnim.HELION_NISAN_WINDUP;
        CLIPS.put(ShazamAnim.HELION_NISAN, Clip.builder(nw + 22)
                .key(0, Ease.OUT_CUBIC).rightArm(-160, 0, -10).leftArm(10, 0, -12).head(-10, 0, 0).legs(6).tilt(-6).drop(-0.05f)
                .key(nw, Ease.OUT_BACK).rightArm(-50, 0, -6).leftArm(30, 0, -20).head(30, 0, 0).rightLeg(-70, 0, 8)
                        .leftLeg(40, 0, -6).tilt(50).drop(0.66f).shake(2.2f)
                .key(nw + 12, Ease.IN_OUT_SINE).rightArm(-48, 0, -4).head(24, 0, 0).tilt(44).drop(0.62f).shake(0.6f)
                .key(nw + 22, Ease.OUT_CUBIC).rightArm(-58, -36, 5).leftArm(-64, 34, -5).head(0, 0, 0).rightLeg(0, 0, 4)
                        .leftLeg(0, 0, -4).tilt(0).drop(0f).shake(0f)
                .fade(1, 6).build());

        // 0.45 Gerhana Buatan: kepalan kanan diangkat lurus ke matahari, kepala mendongak, badan bergetar mengirim radiasi
        // ke langit; saat gerhana menutup kepalan tetap di atas sebentar, lalu turun ke sikap bersilang tangan.
        int ew = ShazamAnim.HELION_ECLIPSE_WINDUP;
        CLIPS.put(ShazamAnim.HELION_ECLIPSE, Clip.builder(ew + 26)
                .key(0, Ease.OUT_CUBIC).rightArm(-20, 0, 10).leftArm(6, 0, -10).head(-10, 0, 0).legs(8)
                .key(6, Ease.OUT_BACK).rightArm(-172, 0, 8).leftArm(14, 0, -18).head(-42, 0, 0).legs(12).tilt(-8).shake(0.6f)
                .key(ew - 2, Ease.IN_OUT_SINE).rightArm(-176, 0, 6).leftArm(18, 0, -22).head(-46, 0, 0).tilt(-10).shake(2.4f)
                .key(ew + 2, Ease.OUT_BACK).rightArm(-168, 0, 14).leftArm(10, 0, -14).head(-40, 0, 0).tilt(-6).shake(1.0f)
                .key(ew + 26, Ease.OUT_CUBIC).rightArm(-58, -36, 5).leftArm(-64, 34, -5).head(-4, 0, 0).legs(6).tilt(0).shake(0f)
                .fade(2, 8).build());

        // Eksperimen Proyek Helion-6 (wujud manusia, HELION_RITE_TICKS): menyuntik leher, memeluk dada saat radiasi
        // menjalar, kejang & jatuh berlutut, lalu (HELION_RITE_STRIKE) radiasinya meledak keluar dan bangkit bersilang tangan.
        int rs = ShazamAnim.HELION_RITE_STRIKE, rl = ShazamAnim.HELION_RITE_TICKS;
        CLIPS.put(ShazamAnim.HELION_RITE, Clip.builder(rl)
                .key(0, Ease.OUT_CUBIC).head(-20, 30, 0).rightArm(-150, -40, 0).leftArm(10, 0, -8).tilt(2)
                .key(8, Ease.OUT_BACK).head(-26, 34, 0).rightArm(-156, -44, 0).shake(1.4f)
                .key(14, Ease.IN_OUT_SINE).head(10, 0, 0).rightArm(-20, 0, 14).leftArm(-20, 0, -14).shake(0.4f)
                .key(40, Ease.IN_OUT_SINE).head(24, 0, 0).rightArm(-60, -30, 0).leftArm(-60, 30, 0).tilt(12).drop(0.06f)
                        .shake(1.6f)
                .key(80, Ease.IN_OUT_SINE).head(40, 0, 0).rightArm(-70, -40, 0).leftArm(-70, 40, 0).tilt(26).drop(0.2f)
                        .shake(3.5f)
                .key(90, Ease.IN_QUAD).head(42, 0, 0).rightArm(-40, 0, 24).leftArm(-60, 0, -30).rightLeg(-80, 0, 8)
                        .leftLeg(60, 0, -8).tilt(32).drop(0.58f).shake(5f)
                .key(rs - 2, Ease.IN_OUT_SINE).head(46, 0, 0).rightArm(-30, 0, 40).leftArm(-30, 0, -40).tilt(38).drop(0.6f)
                        .shake(6.5f)
                .key(rs + 1, Ease.OUT_BACK).head(-52, 0, 0).rightArm(-30, 0, 100).leftArm(-30, 0, -100).rightLeg(-18, 0, 10)
                        .leftLeg(14, 0, -10).tilt(-16).drop(0.16f).shake(2.4f)
                .key(rs + 22, Ease.IN_OUT_SINE).head(-8, 0, 0).rightArm(-58, -36, 5).leftArm(-64, 34, -5).rightLeg(0, 0, 4)
                        .leftLeg(0, 0, -4).tilt(0).drop(0f).shake(0.3f)
                .key(rl, Ease.IN_OUT_SINE).head(0, 0, 0).rightArm(0, 0, 8).leftArm(0, 0, -8).shake(0f)
                .fade(3, 10).build());
    }
    // ================================================================== 0.30 Sabbac

    static {
        // Memanggil enam iblis: kebalikan doa Shazam. Kepala tertunduk, lengan terbuka ke bawah dengan telapak menghadap
        // tanah seperti menarik sesuatu dari dalam bumi, badan merunduk. Tiap iblis yang menyeruak membuat badan tersentak
        // dan makin membungkuk; menjelang akhir gemetar hebat dengan cakar mencengkeram udara.
        Clip.Builder summon = Clip.builder(ShazamAnim.SUMMON_TICKS)
                .key(0, Ease.LINEAR).rightArm(-6, 0, 10).leftArm(-6, 0, -10).head(10, 0, 0).tilt(2)
                .key(8, Ease.OUT_CUBIC).rightArm(-14, 0, 34).leftArm(-14, 0, -34).head(26, 0, 0).legs(6).tilt(8).drop(0.08f);
        for (int i = 0; i < GodShow.ARRIVE.length; i++) {
            float u = i / (float) (GodShow.ARRIVE.length - 1);
            float at = GodShow.ARRIVE[i];
            float open = 36f + 22f * u;      // lengan makin terbuka ke bawah-samping
            float fwd = -18f - 16f * u;
            float bow = 8f + 12f * u;        // makin membungkuk
            summon.key(at - 1.5f, Ease.IN_OUT_SINE).rightArm(fwd, 0, open).leftArm(fwd, 0, -open).head(24 + 6 * u, 0, 0)
                    .legs(6 + 4 * u).tilt(bow).drop(0.08f + 0.1f * u).shake(0f)
                    .key(at + 1, Ease.OUT_BACK).rightArm(fwd - 10, 0, open + 8).leftArm(fwd - 10, 0, -open - 8)
                    .head(10 + 4 * u, 0, 0).tilt(bow - 6).drop(0.04f + 0.08f * u).shake(1.0f)
                    .key(at + 6, Ease.IN_OUT_SINE).rightArm(fwd - 4, 0, open + 3).leftArm(fwd - 4, 0, -open - 3)
                    .head(20 + 6 * u, 0, 0).tilt(bow).drop(0.08f + 0.1f * u).shake(0.3f);
        }
        float end = ShazamAnim.SUMMON_TICKS;
        float settled = GodShow.ARRIVE[GodShow.ARRIVE.length - 1] + 6;
        summon.key(Math.min(end - 0.5f, Math.max(settled + 1, end - 4)), Ease.IN_OUT_SINE)
                .rightArm(-40, 0, 62).leftArm(-40, 0, -62).head(30, 0, 0).legs(11).tilt(22).drop(0.22f).shake(1.6f)
                .key(end, Ease.IN_OUT_SINE)
                .rightArm(-42, 0, 60).leftArm(-42, 0, -60).head(32, 0, 0).tilt(24).drop(0.24f).shake(2.2f);
        SABBAC.put(ShazamAnim.SUMMON, summon.fade(4, 3).build());

        // Berubah: berlutut, kedua kepalan menghantam tanah (tick 7) dan ditahan gemetar selama petir neraka merambat naik
        // dari bawah (8-18). Petir menembus badan: terlempar tegak dengan lengan terentang ke bawah-samping & kepala
        // terlempar ke belakang (meraung), lalu turun dan berdiri membungkuk siap menerkam.
        SABBAC.put(ShazamAnim.TRANSFORM, Clip.builder(54)
                .key(0, Ease.LINEAR).rightArm(-42, 0, 60).leftArm(-42, 0, -60).head(32, 0, 0).legs(11).tilt(24).drop(0.24f)
                .key(4, Ease.OUT_CUBIC).rightArm(-150, 0, -8).leftArm(-150, 0, 8).head(-10, 0, 0).legs(8).tilt(-6)
                        .drop(-0.04f).shake(0.6f)
                .key(7, Ease.IN_QUAD).rightArm(-52, 0, 12).leftArm(-52, 0, -12).head(30, 0, 0)
                        .rightLeg(-64, 0, 8).leftLeg(40, 0, -6).tilt(56).drop(0.82f).shake(2.4f)
                .key(12, Ease.IN_OUT_SINE).rightArm(-50, 0, 14).leftArm(-50, 0, -14).head(26, 0, 0).tilt(54).drop(0.8f)
                        .shake(2.8f)
                .key(17, Ease.IN_OUT_SINE).rightArm(-48, 0, 12).leftArm(-48, 0, -12).head(22, 0, 0).tilt(52).drop(0.78f)
                        .shake(3.6f)
                .key(19, Ease.OUT_QUAD).rightArm(-20, 0, 70).leftArm(-20, 0, -70).head(-50, 0, 0)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).tilt(-20).drop(-0.3f).shake(1.2f)
                .key(26, Ease.OUT_CUBIC).rightArm(-14, 0, 82).leftArm(-14, 0, -82).head(-56, 0, 0).tilt(-18).drop(-0.46f)
                        .shake(2.0f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-10, 0, 78).leftArm(-10, 0, -78).head(-50, 0, 0).tilt(-12).drop(-0.4f)
                        .shake(1.2f)
                .key(43, Ease.IN_OUT_SINE).rightArm(-30, 0, 26).leftArm(-30, 0, -26).head(18, 0, 0).legs(13).tilt(14)
                        .drop(0.16f).shake(0.3f)
                .key(50, Ease.OUT_CUBIC).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(14, 0, 0).legs(12).tilt(9)
                        .drop(0.06f).shake(0f)
                .fade(2, 6).build());

        // Sabbac terbang & mendarat berat seperti Black Adam
        SABBAC.put(ShazamAnim.LAUNCH, ADAM.get(ShazamAnim.LAUNCH));
        SABBAC.put(ShazamAnim.LAND_HERO, ADAM.get(ShazamAnim.LAND_HERO));

        // ===== Skill Sabbac (cuma dikirim untuk Sabbac, jadi cukup di daftar biasa) =====

        // S - Tanduk Setan: menunduk dalam, kaki kanan menggaruk tanah dua kali seperti banteng (0-6), lalu menyeruduk:
        // badan nyaris mendatar, kepala (tanduk) di depan, lengan tersapu ke belakang. Di ujung kepala menghentak naik
        // melempar mangsa, lengan terbuka, lalu berdiri lagi.
        float hornEnd = ShazamAnim.HORN_WINDUP + ShazamAnim.HORN_TICKS;
        putSkill(ShazamAnim.SABBAC_HORNS, Clip.builder(hornEnd + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(30, 0, 22).leftArm(30, 0, -22).head(36, 0, 0).rightLeg(26, 0, 4)
                        .leftLeg(-10, 0, -4).tilt(30).drop(0.26f).shake(0.8f)
                .key(2, Ease.IN_OUT_SINE).rightLeg(-18, 0, 4)
                .key(4, Ease.IN_OUT_SINE).rightLeg(30, 0, 4).shake(1.4f)
                .key(ShazamAnim.HORN_WINDUP, Ease.OUT_QUAD).rightArm(64, 0, 18).leftArm(64, 0, -18).head(58, 0, 0)
                        .rightLeg(28, 0, 3).leftLeg(-30, 0, -3).tilt(62).drop(0.1f).shake(0.4f)
                .key(hornEnd - 1, Ease.LINEAR).rightLeg(-26, 0, 3).leftLeg(30, 0, -3).tilt(64)
                .key(hornEnd + 1, Ease.OUT_BACK).rightArm(-60, 0, 60).leftArm(-60, 0, -60).head(-46, 0, 0)
                        .rightLeg(-20, 0, 8).leftLeg(14, 0, -8).tilt(-14).drop(0.04f).shake(1.6f)
                .key(hornEnd + 5, Ease.OUT_QUAD).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(8, 0, 0).tilt(10)
                        .drop(0.12f).shake(0.4f)
                .key(hornEnd + 12, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).tilt(8).drop(0.04f).shake(0f)
                .fade(1, 5).build());

        // A - Tubuh Aym: lengan menyilang di depan wajah, badan meringkuk dan gemetar selagi kulit membatu (0-5), lalu
        // menghentak terbuka: dada membusung, kedua lengan terentang ke bawah-samping mengepal, kepala mendongak.
        putSkill(ShazamAnim.SABBAC_AYM, Clip.builder(28)
                .key(0, Ease.OUT_CUBIC).rightArm(-110, -40, 0).leftArm(-110, 40, 0).head(20, 0, 0).tilt(14).drop(0.16f)
                        .shake(1.0f)
                .key(4, Ease.IN_QUAD).rightArm(-118, -46, 0).leftArm(-118, 46, 0).head(26, 0, 0).tilt(20).drop(0.24f)
                        .shake(3.0f)
                .key(ShazamAnim.AYM_WINDUP, Ease.OUT_BACK).rightArm(-16, 0, 64).leftArm(-16, 0, -64).head(-30, 0, 0)
                        .legs(12).tilt(-12).drop(-0.04f).shake(1.4f)
                .key(14, Ease.LINEAR).rightArm(-12, 0, 58).leftArm(-12, 0, -58).head(-22, 0, 0).shake(0.4f)
                .key(28, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(2, 5).build());

        // Letusan Aym: cangkang magma pecah - lengan menghentak ke luar, badan tersentak.
        putSkill(ShazamAnim.SABBAC_AYM_BURST, Clip.builder(16)
                .key(0, Ease.OUT_QUAD).rightArm(-70, -30, 0).leftArm(-70, 30, 0).head(16, 0, 0).tilt(12).drop(0.12f)
                        .shake(2.4f)
                .key(ShazamAnim.NOVA_WINDUP, Ease.OUT_BACK).rightArm(-30, 0, 96).leftArm(-30, 0, -96).head(-34, 0, 0)
                        .legs(13).tilt(-14).drop(-0.1f).shake(2.0f)
                .key(9, Ease.LINEAR).shake(0.6f)
                .key(16, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(1, 4).build());

        // C - Rantai Belial: berlutut, cakar kanan mencakar tanah (0-6) - rantai menyeruak. Kedua tangan mencengkeram
        // rantai di depan dada selama musuh terikat, lalu (tick 26) menyentaknya ke belakang sambil memutar pinggang.
        float pull = ShazamAnim.CHAIN_WINDUP + ShazamAnim.CHAIN_PULL;
        putSkill(ShazamAnim.SABBAC_CHAINS, Clip.builder(pull + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, 0, -10).leftArm(-20, 0, -30).head(-10, 0, 0).tilt(-4).shake(0.5f)
                .key(ShazamAnim.CHAIN_WINDUP - 1, Ease.IN_QUAD).rightArm(-40, 0, 8).leftArm(-10, 0, -36).head(30, 0, 0)
                        .rightLeg(-58, 0, 8).leftLeg(36, 0, -6).tilt(48).drop(0.7f).shake(1.6f)
                .key(ShazamAnim.CHAIN_WINDUP + 2, Ease.OUT_BACK).rightArm(-96, -18, 0).leftArm(-96, 18, 0).head(-8, 0, 0)
                        .rightLeg(-20, 0, 8).leftLeg(16, 0, -8).tilt(6).drop(0.12f).shake(1.2f)
                .key(pull - 2, Ease.LINEAR).rightArm(-90, -14, 0).leftArm(-90, 14, 0).head(-4, 0, 0).tilt(4).shake(2.2f)
                .key(pull + 1, Ease.OUT_BACK).rightArm(24, 0, 30).leftArm(24, 0, -30).head(-24, 0, 0).twist(18).tilt(-16)
                        .drop(0.06f).shake(1.0f)
                .key(pull + 12, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).twist(0).tilt(8).drop(0.04f).shake(0f)
                .fade(2, 5).build());

        // V - Napas Beelzebub: menarik napas dalam (kepala & dada terangkat ke belakang, lengan terbuka), lalu (tick 8)
        // condong ke depan menyemburkan api neraka: cakar terbuka ke depan-samping, gemetar menahan semburan 2 detik.
        float breathEnd = ShazamAnim.BREATH_WINDUP + ShazamAnim.BREATH_TICKS;
        putSkill(ShazamAnim.SABBAC_BREATH, Clip.builder(breathEnd + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(-20, 0, 40).leftArm(-20, 0, -40).head(-30, 0, 0).tilt(-10).drop(-0.02f)
                .key(ShazamAnim.BREATH_WINDUP - 1, Ease.IN_OUT_SINE).rightArm(-10, 0, 56).leftArm(-10, 0, -56).head(-42, 0, 0)
                        .tilt(-14).drop(-0.06f).shake(0.8f)
                .key(ShazamAnim.BREATH_WINDUP + 1, Ease.OUT_BACK).rightArm(-70, -10, 30).leftArm(-70, 10, -30).head(6, 0, 0)
                        .rightLeg(-22, 0, 8).leftLeg(16, 0, -8).tilt(18).drop(0.12f).shake(1.4f)
                .key(breathEnd - 2, Ease.LINEAR).rightArm(-66, -10, 34).leftArm(-66, 10, -34).tilt(16).shake(1.8f)
                .key(breathEnd + 10, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).tilt(8).drop(0.04f).shake(0f)
                .fade(2, 6).build());

        // B - Teror Asmodeus: membungkuk mengumpulkan amarah, kepalan bergetar di samping (0-7), lalu meraung: kepala
        // terlempar ke belakang, lengan terlempar ke bawah-samping, dada membusung, badan sedikit terangkat.
        putSkill(ShazamAnim.SABBAC_ROAR, Clip.builder(32)
                .key(0, Ease.OUT_CUBIC).rightArm(16, 0, 18).leftArm(16, 0, -18).head(26, 0, 0).tilt(14).drop(0.12f)
                        .shake(1.6f)
                .key(ShazamAnim.TERROR_WINDUP - 1, Ease.IN_QUAD).rightArm(26, 0, 14).leftArm(26, 0, -14).head(34, 0, 0)
                        .legs(10).tilt(22).drop(0.26f).shake(4.4f)
                .key(ShazamAnim.TERROR_WINDUP, Ease.OUT_BACK).rightArm(24, 0, 70).leftArm(24, 0, -70).head(-62, 0, 0)
                        .legs(13).tilt(-22).drop(-0.2f).shake(3.0f)
                .key(18, Ease.LINEAR).head(-56, 0, 0).drop(-0.16f).shake(1.8f)
                .key(32, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(2, 5).build());

        // N - Kepakan Crateis: meringkuk dengan lengan menyilang (sayap terlipat), lalu (tick 6) menghentak tegak dengan
        // lengan terentang lebar ke atas seperti sayap terbuka dan badan terangkat, lalu terbang.
        putSkill(ShazamAnim.SABBAC_WINGS, Clip.builder(26)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, -40, 0).leftArm(-60, 40, 0).head(24, 0, 0).legs(10).tilt(24)
                        .drop(0.34f).shake(1.2f)
                .key(ShazamAnim.WINGS_WINDUP - 1, Ease.IN_QUAD).rightArm(-66, -44, 0).leftArm(-66, 44, 0).head(30, 0, 0)
                        .tilt(30).drop(0.42f).shake(2.6f)
                .key(ShazamAnim.WINGS_WINDUP + 1, Ease.OUT_BACK).rightArm(-140, 0, -40).leftArm(-140, 0, 40).head(-36, 0, 0)
                        .rightLeg(10, 0, 4).leftLeg(16, 0, -4).tilt(-12).drop(-0.3f).shake(1.0f)
                .key(16, Ease.IN_OUT_SINE).rightArm(-110, 0, -60).leftArm(-110, 0, 60).head(-20, 0, 0).tilt(-6).drop(-0.2f)
                        .shake(0.3f)
                .key(26, Ease.IN_OUT_SINE).rightArm(-20, 0, 30).leftArm(-20, 0, -30).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f).shake(0f)
                .fade(1, 5).build());

        // R - Gerbang Neraka: membungkuk dalam, kepalan mengepal di samping, gemetar makin hebat saat tanah membara
        // (0-12), lalu bangkit membesar: lengan terlempar terbuka ke atas, kepala mendongak meraung, badan terangkat.
        putSkill(ShazamAnim.SABBAC_HELLGATE, Clip.builder(38)
                .key(0, Ease.OUT_CUBIC).rightArm(18, 0, 14).leftArm(18, 0, -14).head(24, 0, 0).tilt(12).drop(0.1f).shake(1.4f)
                .key(7, Ease.IN_QUAD).rightArm(26, 0, 20).leftArm(26, 0, -20).head(32, 0, 0).legs(9).tilt(20).drop(0.28f)
                        .shake(4.0f)
                .key(ShazamAnim.HELLGATE_WINDUP - 0.5f, Ease.IN_QUAD).rightArm(30, 0, 16).leftArm(30, 0, -16).tilt(24)
                        .drop(0.32f).shake(5.6f)
                .key(ShazamAnim.HELLGATE_WINDUP, Ease.OUT_BACK).rightArm(-150, 0, -44).leftArm(-150, 0, 44).head(-60, 0, 0)
                        .legs(14).tilt(-18).drop(-0.36f).shake(2.8f)
                .key(24, Ease.LINEAR).drop(-0.3f).shake(1.6f)
                .key(38, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(2, 5).build());

        // M - Panggil Petir Neraka: berlutut satu kaki, telapak kanan menekan tanah memanggil dari bawah, gemetar
        // (0-12). Petir neraka menyembur naik menembus badan: tersentak tegak, lengan terentang ke bawah-samping menyerap.
        putSkill(ShazamAnim.SABBAC_CALL, Clip.builder(36)
                .key(0, Ease.OUT_CUBIC).rightArm(-36, 0, 6).leftArm(10, 0, -24).head(26, 0, 0)
                        .rightLeg(-50, 0, 6).leftLeg(30, 0, -6).tilt(40).drop(0.5f).shake(0.6f)
                .key(ShazamAnim.SABBAC_CALL_WINDUP - 1, Ease.IN_QUAD).rightArm(-40, 0, 4).head(30, 0, 0).tilt(44).drop(0.58f)
                        .shake(3.2f)
                .key(ShazamAnim.SABBAC_CALL_WINDUP, Ease.OUT_QUAD).rightArm(-10, 0, 80).leftArm(-10, 0, -80).head(-54, 0, 0)
                        .rightLeg(0, 0, 10).leftLeg(0, 0, -10).tilt(-18).drop(-0.3f).shake(3.6f)
                .key(ShazamAnim.SABBAC_CALL_WINDUP + 12, Ease.IN_OUT_SINE).rightArm(-14, 0, 74).leftArm(-14, 0, -74)
                        .head(-40, 0, 0).tilt(-10).drop(-0.2f).shake(1.0f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(2, 6).build());

        // J - Pasukan Iblis: kedua lengan diangkat tinggi (0-4), lalu dihantamkan ke bawah memerintah tanah terbuka
        // (tick 10), lalu telapak terbuka ke atas, perlahan diangkat: "bangkitlah".
        putSkill(ShazamAnim.SABBAC_LEGION, Clip.builder(36)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, 0, 10).leftArm(-60, 0, -10).head(-6, 0, 0)
                .key(4, Ease.OUT_BACK).rightArm(-176, 0, -10).leftArm(-176, 0, 10).head(-30, 0, 0).tilt(-8).drop(-0.06f)
                        .shake(0.8f)
                .key(ShazamAnim.LEGION_WINDUP - 1, Ease.IN_QUAD).rightArm(-160, 0, -8).leftArm(-160, 0, 8).shake(1.8f)
                .key(ShazamAnim.LEGION_WINDUP, Ease.OUT_QUAD).rightArm(-20, 0, 24).leftArm(-20, 0, -24).head(30, 0, 0)
                        .legs(12).tilt(34).drop(0.4f).shake(2.6f)
                .key(20, Ease.IN_OUT_SINE).rightArm(-54, 0, 40).leftArm(-54, 0, -40).head(6, 0, 0).tilt(12).drop(0.12f)
                        .shake(0.8f)
                .key(28, Ease.IN_OUT_SINE).rightArm(-74, 0, 46).leftArm(-74, 0, -46).head(-12, 0, 0).tilt(0).drop(0f)
                        .shake(0.4f)
                .key(36, Ease.IN_OUT_SINE).rightArm(-24, 0, 20).leftArm(-24, 0, -20).head(12, 0, 0).legs(11).tilt(8)
                        .drop(0.04f).shake(0f)
                .fade(2, 6).build());

        // Perjanjian Enam Iblis (wujud manusia): Mahkota Sabbac disodorkan, lalu diangkat tinggi dengan dua tangan selagi
        // nama-nama iblis bergema; badan gemetar makin hebat; petir neraka menyembur (tick 60): tersentak, lalu turun.
        putSkill(ShazamAnim.SABBAC_PACT, Clip.builder(ShazamAnim.PACT_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-84, -8, 0).leftArm(-84, 8, 0).head(16, 0, 0)
                .key(18, Ease.IN_OUT_SINE).rightArm(-92, -10, 0).leftArm(-92, 10, 0).head(8, 0, 0).shake(0.4f)
                .key(32, Ease.OUT_BACK).rightArm(-174, 0, 4).leftArm(-174, 0, -4).head(-36, 0, 0).legs(6).tilt(-5)
                        .shake(0.8f)
                .key(ShazamAnim.PACT_STRIKE - 1, Ease.IN_QUAD).rightArm(-178, 0, 6).leftArm(-178, 0, -6).head(-44, 0, 0)
                        .tilt(-8).drop(-0.06f).shake(2.4f)
                .key(ShazamAnim.PACT_STRIKE + 1, Ease.OUT_QUAD).rightArm(-30, 0, 70).leftArm(-30, 0, -70).head(-24, 0, 0)
                        .tilt(-16).drop(-0.3f).shake(3.6f)
                .key(ShazamAnim.PACT_TICKS, Ease.IN_OUT_SINE).rightArm(6, 0, 16).leftArm(6, 0, -16).head(4, 0, 0)
                        .legs(8).tilt(4).drop(0f).shake(0f)
                .fade(4, 8).build());
    }

    private static void putSkill(ShazamAnim anim, Clip clip) {
        CLIPS.put(anim, clip);   // skill khusus Black Adam: cuma dikirim untuk Black Adam, jadi cukup di daftar biasa
    }

    // ================================================================== 0.38 Lintang: gerak sinematik

    /**
     * 0.38 Gerakan badan singkat Lintang untuk animasi penanda (Tinju Baja, tangkisan): cuma diputar kalau nggak ada klip
     * lain yang sedang jalan (lihat ShazamPoses.start), jadi skill & terbang nggak terpotong.
     */
    private static final Map<ShazamAnim, Clip> LINTANG_ACCENT = new EnumMap<>(ShazamAnim.class);

    public static Clip lintangAccent(ShazamAnim anim) {
        return LINTANG_ACCENT.get(anim);
    }

    static {
        // Lepas landas: merunduk dalam-dalam (tanah ditolak), lalu melesat dengan kepalan kanan ke atas, badan sedikit
        // terpelintir, dan pelan-pelan masuk ke pose terbang (kepalan kanan di depan)
        LINTANG.put(ShazamAnim.LAUNCH, Clip.builder(18)
                .key(0, Ease.OUT_QUAD).rightArm(34, 0, 18).leftArm(34, 0, -18).head(16, 0, 0)
                        .rightLeg(-52, 0, 6).leftLeg(-38, 0, -6).tilt(22).drop(0.42f).shake(1.4f)
                .key(3, Ease.OUT_BACK).rightArm(-176, 0, -4).leftArm(18, 0, -16).head(-34, 0, 0)
                        .rightLeg(6, 0, 2).leftLeg(22, 0, -3).tilt(-6).drop(-0.12f).twist(8).shake(0f)
                .key(10, Ease.LINEAR).twist(4)
                .key(18, Ease.IN_OUT_SINE).rightArm(-70, 0, 10).leftArm(12, 0, -10).head(-12, 0, 0)
                        .rightLeg(5, 0, 2).leftLeg(12, 0, -2).tilt(0).drop(0f).twist(0)
                .fade(1, 6).build());

        // Mendarat gaya pahlawan: satu lutut turun & kepalan kanan menancap ke tanah, lengan kiri terentang ke belakang,
        // kepala tertunduk, badan bergetar menahan hantaman; lalu mendongak dan berdiri pelan
        LINTANG.put(ShazamAnim.LAND_HERO, Clip.builder(32)
                .key(0, Ease.OUT_QUAD).rightArm(-14, -6, 6).leftArm(44, 12, -58).head(14, 0, 0)
                        .rightLeg(-96, 0, 9).leftLeg(72, 0, -8).tilt(42).drop(0.72f).shake(1.8f)
                .key(5, Ease.LINEAR).shake(0f)
                .key(13, Ease.IN_OUT_SINE).head(-22, 0, 0)
                .key(18, Ease.LINEAR)
                .key(32, Ease.IN_OUT_SINE).rightArm(12, 0, 34).leftArm(12, 0, -34).head(-8, 0, 0)
                        .rightLeg(0, 0, 9).leftLeg(0, 0, -9).tilt(-3).drop(0f)
                .fade(1, 6).build());

        // Tinju Baja: sesudah pukulan masuk, lengan kanan tetap lurus menghunjam, bahu & pinggang ikut terpelintir,
        // badan bergetar sesaat, lalu kembali
        LINTANG_ACCENT.put(ShazamAnim.LINTANG_DAWNPUNCH, Clip.builder(14)
                .key(0, Ease.OUT_QUAD).rightArm(-95, -10, 0).leftArm(-14, 0, -22).head(4, 0, 0)
                        .rightLeg(-12, 0, 6).leftLeg(12, 0, -6).tilt(10).drop(0.08f).twist(18).shake(1.4f)
                .key(4, Ease.LINEAR).shake(0f)
                .key(14, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0)
                        .rightLeg(0, 0, 4).leftLeg(0, 0, -4).tilt(0).drop(0f).twist(0)
                .fade(1, 4).build());

        // Refleks Kilat: serangan ditepis secepat kilat dengan lengan kiri di depan muka
        LINTANG_ACCENT.put(ShazamAnim.LINTANG_PARRY, Clip.builder(9)
                .key(0, Ease.OUT_QUAD).rightArm(-24, 0, 14).leftArm(-112, 32, 0).head(6, 0, 0)
                        .tilt(-6).twist(-10).shake(1.0f)
                .key(3, Ease.LINEAR).shake(0f)
                .key(9, Ease.IN_OUT_SINE).rightArm(0, 0, 8).leftArm(0, 0, -8).head(0, 0, 0).tilt(0).twist(0)
                .fade(1, 3).build());
    }

    // ================================================================== 0.49 Subjek Tiga (Helion-3) yang bisa dimainkan
    // Sikap dasarnya (lengan menggantung ke depan, kaki terbuka) dipakai sebagai kunci penutup tiap klip. Bungkuk dari
    // pinggulnya ditambahkan HeroMotion di atas klip: hilang saat klip mendongak (tilt negatif), berkurang saat klip
    // sudah menunduk dalam.

    static {
        // Berubah wujud: mencengkeram dada, meringkuk makin rapat selama sel mati membungkus badan (gemetar makin hebat),
        // lalu di SUBJEK_MORPH_BURST kepompongnya pecah: lengan terlempar terbuka, dada membusung, kepala mendongak
        // meraung. Ditutup sikap binatang buas.
        int mb = ShazamAnim.SUBJEK_MORPH_BURST, ml = ShazamAnim.SUBJEK_MORPH_TICKS;
        HELION3.put(ShazamAnim.TRANSFORM, Clip.builder(ml)
                .key(0, Ease.LINEAR).rightArm(0, 0, 6).leftArm(0, 0, -6).head(0, 0, 0).legs(3).tilt(0).drop(0f)
                .key(4, Ease.OUT_CUBIC).rightArm(-52, -42, 0).leftArm(-52, 42, 0).head(30, 0, 0).legs(6).tilt(14).drop(0.2f)
                        .shake(1.0f)
                .key(mb - 8, Ease.IN_OUT_SINE).rightArm(-96, -52, 0).leftArm(-96, 52, 0).head(42, 0, 0).rightLeg(-52, 0, 8)
                        .leftLeg(30, 0, -8).tilt(28).drop(0.46f).shake(2.4f)
                .key(mb - 1, Ease.LINEAR).shake(4.6f)
                .key(mb, Ease.OUT_BACK).rightArm(-30, 0, 96).leftArm(-30, 0, -96).head(-46, 0, 0).rightLeg(0, 0, 14)
                        .leftLeg(0, 0, -14).tilt(-16).drop(-0.05f).shake(3.2f)
                .key(mb + 12, Ease.IN_OUT_SINE).rightArm(-40, 0, 80).leftArm(-40, 0, -80).head(-40, 0, 0).tilt(-12).shake(2.0f)
                .key(mb + 22, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0).rightLeg(-4, 0, 11)
                        .leftLeg(4, 0, -11).tilt(0).drop(0f).shake(0f)
                .key(ml, Ease.OUT_CUBIC).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0)
                .fade(1, 8).build());

        // Kembali jadi manusia: sel mati luruh - memeluk badan sendiri, gemetar, lalu tegak lagi dengan lemas.
        int rb = ShazamAnim.REVERT_WINDUP;
        HELION3.put(ShazamAnim.REVERT, Clip.builder(rb + 18)
                .key(0, Ease.LINEAR).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0).legs(8)
                .key(rb, Ease.OUT_CUBIC).rightArm(-60, -40, 0).leftArm(-60, 40, 0).head(30, 0, 0).tilt(16).drop(0.16f).shake(2.2f)
                .key(rb + 9, Ease.IN_OUT_SINE).rightArm(8, 0, 12).leftArm(8, 0, -12).head(16, 0, 0).tilt(6).drop(0.06f)
                        .shake(0.5f)
                .key(rb + 18, Ease.OUT_CUBIC).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f).shake(0f)
                .fade(1, 5).build());

        // H - Hantam: kepalan kanan dari atas menyilang (pinggang ikut terpelintir), kepalan kiri, lalu kedua kepalan
        // diangkat tinggi dan dihantamkan ke tanah.
        int h1 = ShazamAnim.SUBJEK_SMASH_HIT1, h2 = ShazamAnim.SUBJEK_SMASH_HIT2, pd = ShazamAnim.SUBJEK_SMASH_POUND;
        CLIPS.put(ShazamAnim.SUBJEK_SMASH, Clip.builder(ShazamAnim.SUBJEK_SMASH_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-158, 0, 12).leftArm(-30, 0, -22).head(-10, 0, 0).legs(10).tilt(-6).twist(22)
                        .drop(0f)
                .key(h1, Ease.OUT_BACK).rightArm(-42, 26, -10).leftArm(18, 0, -26).head(14, 0, 0).tilt(22).twist(-26).shake(1.2f)
                .key(h1 + 3, Ease.OUT_CUBIC).rightArm(8, 0, 22).leftArm(-162, 0, -12).head(-8, 0, 0).tilt(-4).twist(-22)
                        .shake(0f)
                .key(h2, Ease.OUT_BACK).rightArm(18, 0, 26).leftArm(-42, -26, 10).head(14, 0, 0).tilt(22).twist(26).shake(1.2f)
                .key(h2 + 5, Ease.OUT_CUBIC).rightArm(-176, 0, 8).leftArm(-176, 0, -8).head(-30, 0, 0).legs(8).tilt(-18)
                        .twist(0).drop(-0.1f).shake(0f)
                .key(pd, Ease.IN_QUAD).rightArm(-56, 10, 6).leftArm(-56, -10, -6).head(20, 0, 0).legs(16).tilt(48).drop(0.36f)
                        .shake(2.6f)
                .key(pd + 5, Ease.LINEAR).shake(0.6f)
                .key(ShazamAnim.SUBJEK_SMASH_TICKS, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0)
                        .legs(11).tilt(0).drop(0f).shake(0f)
                .fade(1, 5).build());

        // E - Erangan: menarik napas sambil merunduk, lalu dada membusung, lengan terbuka ke belakang, kepala mendongak
        // meraung dengan seluruh badan bergetar.
        int rh = ShazamAnim.SUBJEK_ROAR_HIT;
        CLIPS.put(ShazamAnim.SUBJEK_ROAR, Clip.builder(ShazamAnim.SUBJEK_ROAR_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(10, 0, 20).leftArm(10, 0, -20).head(24, 0, 0).legs(10).tilt(16).drop(0.1f)
                .key(rh - 2, Ease.IN_OUT_SINE).rightArm(16, 0, 26).leftArm(16, 0, -26).head(32, 0, 0).tilt(24).drop(0.2f)
                        .shake(0.8f)
                .key(rh + 1, Ease.OUT_BACK).rightArm(-26, 0, 86).leftArm(-26, 0, -86).head(-48, 0, 0).legs(15).tilt(-18)
                        .drop(-0.04f).shake(3.6f)
                .key(22, Ease.LINEAR).head(-44, 0, 0).shake(2.8f)
                .key(ShazamAnim.SUBJEK_ROAR_TICKS, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0)
                        .legs(11).tilt(0).drop(0f).shake(0f)
                .fade(1, 6).build());

        // L - Lompat: jongkok dalam, melesat dengan lengan terjulur, kedua kepalan terangkat di puncak lompatan, lalu
        // mendarat menghantam tanah.
        int lw = ShazamAnim.SUBJEK_LEAP_WINDUP, ll = lw + ShazamAnim.SUBJEK_LEAP_TICKS;
        CLIPS.put(ShazamAnim.SUBJEK_LEAP, Clip.builder(ll + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(40, 0, 14).leftArm(40, 0, -14).head(-12, 0, 0).rightLeg(-38, 0, 6)
                        .leftLeg(-38, 0, -6).tilt(30).drop(0.42f)
                .key(lw, Ease.OUT_CUBIC).rightArm(-150, 0, 12).leftArm(-150, 0, -12).head(-34, 0, 0).rightLeg(26, 0, 4)
                        .leftLeg(40, 0, -4).tilt(24).drop(0f)
                .key(lw + 7, Ease.IN_OUT_SINE).rightArm(-178, 0, 6).leftArm(-178, 0, -6).head(-18, 0, 0).rightLeg(-42, 0, 5)
                        .leftLeg(-12, 0, -5).tilt(4)
                .key(ll, Ease.IN_QUAD).rightArm(-52, 10, 6).leftArm(-52, -10, -6).head(22, 0, 0).rightLeg(0, 0, 18)
                        .leftLeg(0, 0, -18).tilt(50).drop(0.4f).shake(3.0f)
                .key(ll + 4, Ease.LINEAR).shake(0.6f)
                .key(ll + 10, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0).rightLeg(-4, 0, 11)
                        .leftLeg(4, 0, -11).tilt(0).drop(0f).shake(0f)
                .fade(1, 5).build());

        // I - Inkubasi: meringkuk rapat di dalam kepompong (gemetar makin hebat menjelang pecah), lalu berdiri dengan
        // lengan terlempar terbuka.
        int ct = ShazamAnim.SUBJEK_COCOON_TICKS;
        CLIPS.put(ShazamAnim.SUBJEK_COCOON, Clip.builder(ct + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-40, -20, 4).leftArm(-40, 20, -4).head(16, 0, 0).tilt(10).drop(0.1f)
                .key(8, Ease.IN_OUT_SINE).rightArm(-100, -56, 0).leftArm(-100, 56, 0).head(45, 0, 0).rightLeg(-56, 0, 8)
                        .leftLeg(-56, 0, -8).tilt(34).drop(0.56f).shake(0.6f)
                .key(ct - 8, Ease.LINEAR).shake(2.2f)
                .key(ct - 1, Ease.LINEAR).shake(4.2f)
                .key(ct, Ease.OUT_BACK).rightArm(-30, 0, 96).leftArm(-30, 0, -96).head(-42, 0, 0).rightLeg(0, 0, 14)
                        .leftLeg(0, 0, -14).tilt(-16).drop(-0.05f).shake(3.0f)
                .key(ct + 6, Ease.LINEAR).shake(1.2f)
                .key(ct + 12, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0).rightLeg(-4, 0, 11)
                        .leftLeg(4, 0, -11).tilt(0).drop(0f).shake(0f)
                .fade(2, 6).build());

        // O - Onak Tulang: kedua cakar diangkat tinggi, lalu ditancapkan ke tanah sambil berlutut.
        int sw = ShazamAnim.SUBJEK_SPIKES_WINDUP;
        CLIPS.put(ShazamAnim.SUBJEK_SPIKES, Clip.builder(ShazamAnim.SUBJEK_SPIKES_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, 0, 20).leftArm(-150, 0, -20).head(-16, 0, 0).legs(10).tilt(-10).drop(0f)
                .key(sw - 3, Ease.OUT_QUAD).rightArm(-174, 0, 12).leftArm(-174, 0, -12).head(-26, 0, 0).tilt(-14).drop(-0.06f)
                .key(sw, Ease.IN_QUAD).rightArm(-36, 12, 4).leftArm(-36, -12, -4).head(28, 0, 0).rightLeg(-52, 0, 8)
                        .leftLeg(40, 0, -8).tilt(54).drop(0.5f).shake(2.6f)
                .key(sw + 10, Ease.LINEAR).shake(1.4f)
                .key(ShazamAnim.SUBJEK_SPIKES_TICKS, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0)
                        .rightLeg(-4, 0, 11).leftLeg(4, 0, -11).tilt(0).drop(0f).shake(0f)
                .fade(1, 5).build());

        // N - Nyeruduk: mengais tanah bergantian, lalu menyeruduk dengan badan rebah, kepala mendongak menatap sasaran,
        // dan kaki berderap; berhenti dengan mengerem lebar.
        int cw = ShazamAnim.SUBJEK_CHARGE_WINDUP, ce = cw + ShazamAnim.SUBJEK_CHARGE_TICKS;
        CLIPS.put(ShazamAnim.SUBJEK_CHARGE, Clip.builder(ce + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(30, 0, 18).leftArm(30, 0, -18).head(-20, 0, 0).rightLeg(-30, 0, 4)
                        .leftLeg(20, 0, -4).tilt(30).drop(0.2f)
                .key(cw * 0.4f, Ease.IN_OUT_SINE).rightLeg(26, 0, 4).leftLeg(-22, 0, -4)
                .key(cw * 0.8f, Ease.IN_OUT_SINE).rightLeg(-30, 0, 4).leftLeg(20, 0, -4).shake(1.0f)
                .key(cw, Ease.OUT_BACK).rightArm(52, 0, 22).leftArm(52, 0, -22).head(-48, 0, 0).rightLeg(-46, 0, 3)
                        .leftLeg(46, 0, -3).tilt(58).drop(0.1f).shake(0.6f)
                .key(cw + 3.5f, Ease.IN_OUT_SINE).rightLeg(46, 0, 3).leftLeg(-46, 0, -3)
                .key(cw + 7, Ease.IN_OUT_SINE).rightLeg(-46, 0, 3).leftLeg(46, 0, -3)
                .key(cw + 10.5f, Ease.IN_OUT_SINE).rightLeg(46, 0, 3).leftLeg(-46, 0, -3)
                .key(ce, Ease.OUT_CUBIC).rightArm(-30, 0, 40).leftArm(-30, 0, -40).head(-6, 0, 0).rightLeg(-10, 0, 16)
                        .leftLeg(10, 0, -16).tilt(10).drop(0.14f).shake(0f)
                .key(ce + 8, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0).rightLeg(-4, 0, 11)
                        .leftLeg(4, 0, -11).tilt(0).drop(0f)
                .fade(1, 5).build());

        // 3 - Evolusi Ketiga: mencengkeram dada & gemetar hebat selama tubuhnya membengkak, lalu meledak: lengan terentang
        // tinggi, kepala mendongak meraung panjang.
        int rw = ShazamAnim.SUBJEK_RAGE_WINDUP;
        CLIPS.put(ShazamAnim.SUBJEK_RAGE, Clip.builder(ShazamAnim.SUBJEK_RAGE_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-70, -50, 0).leftArm(-70, 50, 0).head(34, 0, 0).legs(8).tilt(24).drop(0.26f)
                        .shake(1.0f)
                .key(rw - 4, Ease.IN_QUAD).rightArm(-82, -56, 0).leftArm(-82, 56, 0).head(40, 0, 0).tilt(30).drop(0.34f)
                        .shake(4.6f)
                .key(rw, Ease.OUT_BACK).rightArm(-60, 0, 106).leftArm(-60, 0, -106).head(-52, 0, 0).legs(18).tilt(-22)
                        .drop(-0.12f).shake(4.0f)
                .key(rw + 16, Ease.LINEAR).head(-46, 0, 0).shake(3.0f)
                .key(ShazamAnim.SUBJEK_RAGE_TICKS, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0)
                        .legs(11).tilt(0).drop(0f).shake(0f)
                .fade(1, 6).build());

        // M - Serap Cryon: pecahan diremukkan di depan dada dengan tangan kanan, lalu dada membusung menyerap radiasinya.
        int aw = ShazamAnim.SUBJEK_ABSORB_WINDUP;
        CLIPS.put(ShazamAnim.SUBJEK_ABSORB, Clip.builder(aw + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-76, -56, 0).leftArm(-16, 0, -22).head(22, 0, 0).tilt(8)
                .key(aw * 0.5f, Ease.IN_OUT_SINE).rightArm(-88, -64, 0).head(26, 0, 0).tilt(12).shake(1.6f)
                .key(aw, Ease.OUT_BACK).rightArm(16, 0, 46).leftArm(16, 0, -46).head(-30, 0, 0).tilt(-12).shake(2.2f)
                .key(aw + 6, Ease.LINEAR).shake(0.8f)
                .key(aw + 12, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0).tilt(0).shake(0f)
                .fade(1, 5).build());

        // J - Terobos Tanah: menukik ke tanah dengan kedua cakar di depan, tenggelam seluruhnya, lalu meletus keluar di
        // titik bidik dengan lengan terentang.
        int dv = ShazamAnim.SUBJEK_BURROW_DIVE, bo = dv + ShazamAnim.SUBJEK_BURROW_TICKS;
        CLIPS.put(ShazamAnim.SUBJEK_BURROW, Clip.builder(bo + 10)
                .key(0, Ease.OUT_CUBIC).rightArm(-160, 0, 10).leftArm(-160, 0, -10).head(-10, 0, 0).tilt(-6).drop(0f)
                .key(dv * 0.5f, Ease.IN_QUAD).rightArm(-140, 0, 8).leftArm(-140, 0, -8).head(30, 0, 0).tilt(60).drop(0.6f)
                        .shake(1.5f)
                .key(dv, Ease.IN_QUAD).tilt(80).drop(2.7f).shake(0f)
                .key(bo, Ease.LINEAR).rightArm(-172, 0, 14).leftArm(-172, 0, -14).head(-34, 0, 0).tilt(-8).drop(2.7f)
                .key(bo + 4, Ease.OUT_BACK).rightArm(-60, 0, 96).leftArm(-60, 0, -96).head(-40, 0, 0).tilt(-14).drop(-0.25f)
                        .shake(2.4f)
                .key(bo + 10, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0).tilt(0).drop(0f)
                        .shake(0f)
                .fade(1, 5).build());

        // Tumbang (satu nyawa habis): tersentak ke belakang, jatuh berlutut, lalu rebah ke depan.
        CLIPS.put(ShazamAnim.SUBJEK_FALL, Clip.builder(ShazamAnim.SUBJEK_FALL_TICKS + 6)
                .key(0, Ease.OUT_QUAD).rightArm(-40, 0, 52).leftArm(-40, 0, -52).head(-26, 0, 0).legs(8).tilt(-12).drop(0f)
                        .shake(3.2f)
                .key(8, Ease.IN_QUAD).rightArm(10, 0, 12).leftArm(10, 0, -12).head(30, 0, 0).rightLeg(-70, 0, 6)
                        .leftLeg(50, 0, -6).tilt(20).drop(0.46f).shake(1.2f)
                .key(18, Ease.OUT_CUBIC).rightArm(-30, -20, 0).leftArm(-30, 20, 0).head(40, 0, 0).tilt(55).drop(0.62f).shake(0.5f)
                .key(ShazamAnim.SUBJEK_FALL_TICKS + 6, Ease.LINEAR).shake(0.3f)
                .fade(1, 4).build());

        // Bangkit Lagi: meringkuk di dalam kepompong (gemetar makin hebat), lalu di SUBJEK_REVIVE_BURST berdiri meraung.
        int vb = ShazamAnim.SUBJEK_REVIVE_BURST;
        CLIPS.put(ShazamAnim.SUBJEK_REVIVE, Clip.builder(ShazamAnim.SUBJEK_REVIVE_TICKS)
                .key(0, Ease.LINEAR).rightArm(-96, -55, 0).leftArm(-96, 55, 0).head(42, 0, 0).rightLeg(-60, 0, 8)
                        .leftLeg(-60, 0, -8).tilt(55).drop(0.62f).shake(0.4f)
                .key(vb - 6, Ease.LINEAR).shake(2.6f)
                .key(vb - 1, Ease.LINEAR).shake(4.6f)
                .key(vb, Ease.OUT_BACK).rightArm(-30, 0, 96).leftArm(-30, 0, -96).head(-48, 0, 0).rightLeg(0, 0, 15)
                        .leftLeg(0, 0, -15).tilt(-18).drop(-0.06f).shake(3.6f)
                .key(vb + 10, Ease.LINEAR).shake(2.0f)
                .key(ShazamAnim.SUBJEK_REVIVE_TICKS, Ease.IN_OUT_SINE).rightArm(-24, 8, 21).leftArm(-26, -8, -21).head(8, 0, 0)
                        .rightLeg(-4, 0, 11).leftLeg(4, 0, -11).tilt(0).drop(0f).shake(0f)
                .fade(3, 6).build());

        // Inkubasi Subjek Tiga (wujud manusia): menatap sel di telapak tangan, lengannya kejang saat sel itu merayap masuk
        // (tangan kiri mencengkeram pergelangan), terhuyung, jatuh berlutut memeluk badan (tick 40), meringkuk di dalam
        // kepompong (tick 80), lalu di SUBJEK_RITE_STRIKE kepompongnya pecah: berdiri, lengan terbuka, kepala mendongak.
        int rs = ShazamAnim.SUBJEK_RITE_STRIKE;
        CLIPS.put(ShazamAnim.SUBJEK_RITE, Clip.builder(ShazamAnim.SUBJEK_RITE_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-70, -25, 0).leftArm(0, 0, -6).head(20, 0, 0).tilt(0).drop(0f)
                .key(10, Ease.IN_OUT_SINE).rightArm(-74, -30, 0).leftArm(-66, 46, 0).head(26, 0, 0).tilt(4).shake(1.5f)
                .key(30, Ease.IN_OUT_SINE).rightArm(-80, -40, 0).leftArm(-74, 48, 0).head(32, 0, 0).tilt(10).drop(0.1f)
                        .shake(2.4f)
                .key(40, Ease.IN_QUAD).rightArm(-92, -55, 0).leftArm(-92, 55, 0).head(40, 0, 0).rightLeg(-70, 0, 6)
                        .leftLeg(50, 0, -6).tilt(26).drop(0.5f).shake(1.2f)
                .key(80, Ease.IN_OUT_SINE).rightArm(-100, -58, 0).leftArm(-100, 58, 0).head(46, 0, 0).tilt(40).drop(0.6f)
                        .shake(1.6f)
                .key(rs - 4, Ease.LINEAR).shake(4.2f)
                .key(rs, Ease.OUT_BACK).rightArm(-30, 0, 96).leftArm(-30, 0, -96).head(-45, 0, 0).rightLeg(0, 0, 12)
                        .leftLeg(0, 0, -12).tilt(-14).drop(-0.05f).shake(3.0f)
                .key(rs + 16, Ease.LINEAR).head(-36, 0, 0).shake(1.5f)
                .key(ShazamAnim.SUBJEK_RITE_TICKS, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0)
                        .rightLeg(0, 0, 2).leftLeg(0, 0, -2).tilt(0).drop(0f).shake(0f)
                .fade(2, 10).build());
    }

    // ======================================================================== 0.50 Aksara, Sang Penulis Ulang
    // Gerakannya tenang & berwibawa seperti dalang: telapak terbuka, jari menulis di udara, badan melayang sedikit.
    // Waktu kuncinya sama dengan ShazamAnim.AKSARA_* (server memberi damage di tick yang sama).
    static {
        // Berubah: menengadah, kedua lengan terangkat pelan ke samping menyambut enam cakram (badan ikut terangkat),
        // gemetar saat garis prada menggurat badan, lalu di AKSARA_MORPH_BURST cakram mengunci: lengan terhentak terbuka.
        int mb = ShazamAnim.AKSARA_MORPH_BURST;
        AKSARA.put(ShazamAnim.TRANSFORM, Clip.builder(ShazamAnim.AKSARA_MORPH_TICKS)
                .key(0, Ease.LINEAR).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).legs(2).tilt(0).drop(0f)
                .key(10, Ease.IN_OUT_SINE).rightArm(-10, 0, 34).leftArm(-10, 0, -34).head(-14, 0, 0).tilt(-2).drop(-0.04f)
                .key(30, Ease.IN_OUT_SINE).rightArm(-22, 0, 72).leftArm(-22, 0, -72).head(-30, 0, 0).legs(1).tilt(-6)
                        .drop(-0.22f).shake(0.6f)
                .key(mb - 4, Ease.IN_QUAD).rightArm(-48, 26, 30).leftArm(-48, -26, -30).head(12, 0, 0).tilt(10).drop(-0.12f)
                        .shake(2.4f)
                .key(mb, Ease.OUT_BACK).rightArm(-35, 0, 104).leftArm(-35, 0, -104).head(-38, 0, 0).rightLeg(-6, 0, 9)
                        .leftLeg(4, 0, -9).tilt(-14).drop(-0.38f).shake(2.0f)
                .key(mb + 6, Ease.IN_OUT_SINE).rightArm(-30, 0, 88).leftArm(-30, 0, -88).head(-30, 0, 0).shake(0.6f)
                .key(ShazamAnim.AKSARA_MORPH_TICKS, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18)
                        .head(0, 0, 0).rightLeg(0, 0, 3).leftLeg(0, 0, -3).tilt(0).drop(-0.14f).shake(0f)
                .fade(2, 8).build());

        // 0.61 Lepas landas PRALAYA ("terangkat", bukan melompat): pendorong menyala (lengan sedikit terbuka, telapak ke
        // bawah, kepala menunduk), lalu badan terangkat lurus dengan lengan tersapu ke belakang dan kepala mendongak.
        AKSARA.put(ShazamAnim.LAUNCH, Clip.builder(16)
                .key(0, Ease.OUT_QUAD).rightArm(14, 0, 30).leftArm(14, 0, -30).head(10, 0, 0).rightLeg(4, 0, 2)
                        .leftLeg(8, 0, -2).tilt(3).drop(-0.02f).shake(0.8f)
                .key(4, Ease.OUT_BACK).rightArm(34, 0, 16).leftArm(34, 0, -16).head(-22, 0, 0).rightLeg(10, 0, 1)
                        .leftLeg(16, 0, -1).tilt(-5).drop(-0.34f).shake(0f)
                .key(10, Ease.LINEAR)
                .key(16, Ease.IN_OUT_SINE).rightArm(18, 0, 26).leftArm(18, 0, -26).head(-6, 0, 0).rightLeg(6, 0, 2)
                        .leftLeg(10, 0, -2).tilt(0).drop(-0.14f)
                .fade(1, 6).build());

        // 0.61 Turun pelan: lengan terbuka dengan telapak ke bawah menahan laju, lalu kembali melayang rendah.
        AKSARA.put(ShazamAnim.LAND_SOFT, Clip.builder(10)
                .key(0, Ease.OUT_QUAD).rightArm(-14, 0, 44).leftArm(-14, 0, -44).head(8, 0, 0).rightLeg(-8, 0, 3)
                        .leftLeg(4, 0, -3).tilt(4).drop(0.02f)
                .key(10, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).rightLeg(0, 0, 3)
                        .leftLeg(0, 0, -3).tilt(0).drop(-0.14f)
                .fade(1, 4).build());

        // 0.61 Turun keras ("kedatangan"): PRALAYA nggak berlutut; ia berhenti sejengkal di atas tanah dengan lengan
        // terbentang ke bawah-belakang & kepala menunduk saat gelombang kejutnya lewat, lalu terangkat lagi pelan.
        AKSARA.put(ShazamAnim.LAND_HERO, Clip.builder(28)
                .key(0, Ease.OUT_QUAD).rightArm(16, 0, 58).leftArm(16, 0, -58).head(26, 0, 0).rightLeg(-10, 0, 7)
                        .leftLeg(6, 0, -7).tilt(8).drop(0.1f).shake(1.5f)
                .key(6, Ease.LINEAR).shake(0f)
                .key(14, Ease.IN_OUT_SINE).rightArm(2, 0, 40).leftArm(2, 0, -40).head(8, 0, 0).tilt(2).drop(-0.02f)
                .key(28, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(-4, 0, 0).rightLeg(0, 0, 3)
                        .leftLeg(0, 0, -3).tilt(0).drop(-0.14f)
                .fade(1, 6).build());

        // Kembali jadi manusia: kedua tangan dikatupkan di dada, kepala menunduk, cakram terlepas, turun ke tanah.
        int rw = ShazamAnim.REVERT_WINDUP;
        AKSARA.put(ShazamAnim.REVERT, Clip.builder(rw + 18)
                .key(0, Ease.LINEAR).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).drop(-0.14f)
                .key(rw, Ease.OUT_CUBIC).rightArm(-62, -38, 0).leftArm(-62, 38, 0).head(24, 0, 0).tilt(8).drop(-0.06f)
                        .shake(0.8f)
                .key(rw + 18, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0).tilt(0).drop(0f).shake(0f)
                .fade(1, 6).build());

        // Penulisan Ulang (wujud manusia): membaca lontar di tangan kanan, badan melengkung ke belakang saat aksara
        // menggurat, lengan bersilang di dada saat menyatu, lalu di AKSARA_RITE_BURST terhentak terbuka.
        int rr = ShazamAnim.AKSARA_RITE_READ, re = ShazamAnim.AKSARA_RITE_ETCH, rb = ShazamAnim.AKSARA_RITE_BURST;
        CLIPS.put(ShazamAnim.AKSARA_RITE, Clip.builder(ShazamAnim.AKSARA_RITE_TICKS)
                .key(0, Ease.OUT_CUBIC).rightArm(-62, -22, 0).leftArm(-40, 30, 0).head(26, 0, 0).tilt(2).drop(0f)
                .key(rr - 8, Ease.IN_OUT_SINE).rightArm(-70, -26, 0).leftArm(-48, 34, 0).head(30, 0, 0).shake(0.4f)
                .key(rr, Ease.OUT_BACK).rightArm(-150, 0, 20).leftArm(-150, 0, -20).head(-34, 0, 0).tilt(-8).drop(-0.06f)
                        .shake(0.8f)
                .key(re - 10, Ease.IN_OUT_SINE).rightArm(-30, 0, 70).leftArm(-30, 0, -70).head(-40, 0, 0).tilt(-14)
                        .drop(-0.22f).shake(2.2f)
                .key(re, Ease.OUT_CUBIC).rightArm(-70, -50, 0).leftArm(-70, 50, 0).head(28, 0, 0).tilt(14).drop(-0.12f)
                        .shake(1.6f)
                .key(rb - 3, Ease.LINEAR).shake(3.6f)
                .key(rb, Ease.OUT_BACK).rightArm(-35, 0, 104).leftArm(-35, 0, -104).head(-42, 0, 0).rightLeg(-6, 0, 10)
                        .leftLeg(4, 0, -10).tilt(-14).drop(-0.4f).shake(2.4f)
                .key(ShazamAnim.AKSARA_RITE_TICKS, Ease.IN_OUT_SINE).rightArm(0, 0, 5).leftArm(0, 0, -5).head(0, 0, 0)
                        .rightLeg(0, 0, 2).leftLeg(0, 0, -2).tilt(0).drop(0f).shake(0f)
                .fade(3, 10).build());

        // Z Sinar Daya: telapak kanan didorong ke depan (ikut bidikan), tangan kiri mencengkeram pergelangan kanan,
        // badan tertahan dorongan sinar.
        int bw = ShazamAnim.AKSARA_BEAM_WINDUP, bt = ShazamAnim.AKSARA_BEAM_TICKS;
        CLIPS.put(ShazamAnim.AKSARA_BEAM, Clip.builder(bw + bt + 8)
                .key(0, Ease.OUT_CUBIC).rightArm(-60, 0, 20).leftArm(-30, 20, -10).head(4, 0, 0).tilt(4).twist(16).aim(0.4f)
                .key(bw - 1, Ease.IN_QUAD).rightArm(-72, 0, 14).leftArm(-48, 32, 0).twist(22).shake(1.2f).aim(0.8f)
                .key(bw + 2, Ease.OUT_BACK).rightArm(-90, 0, 0).leftArm(-80, 46, 0).head(0, 0, 0).tilt(-6).twist(8)
                        .rightLeg(-14, 0, 4).leftLeg(16, 0, -4).shake(1.6f).aim(1f)
                .key(bw + bt - 2, Ease.LINEAR).rightArm(-90, 0, 0).leftArm(-80, 46, 0).tilt(-8).shake(2.2f).aim(1f)
                .key(bw + bt + 8, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).tilt(0).twist(0)
                        .rightLeg(0, 0, 3).leftLeg(0, 0, -3).shake(0f).aim(0f)
                .fade(2, 6).build());

        // Shift+Z Ledak Daya: lengan bersilang di depan dada, badan meringkuk & naik sambil mengumpulkan, lalu terhentak
        // terbuka ke bawah di AKSARA_NOVA_WINDUP.
        int nw = ShazamAnim.AKSARA_NOVA_WINDUP;
        CLIPS.put(ShazamAnim.AKSARA_NOVA, Clip.builder(nw + 18)
                .key(0, Ease.OUT_CUBIC).rightArm(-58, -42, 0).leftArm(-58, 42, 0).head(22, 0, 0).legs(1).tilt(12).drop(-0.05f)
                .key(nw - 2, Ease.IN_QUAD).rightArm(-74, -58, 0).leftArm(-74, 58, 0).head(34, 0, 0).rightLeg(-40, 0, 4)
                        .leftLeg(-28, 0, -4).tilt(24).drop(-0.3f).shake(3.4f)
                .key(nw, Ease.OUT_BACK).rightArm(-20, 0, 112).leftArm(-20, 0, -112).head(-36, 0, 0).rightLeg(0, 0, 12)
                        .leftLeg(0, 0, -12).tilt(-16).drop(-0.42f).shake(2.6f)
                .key(nw + 18, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).rightLeg(0, 0, 3)
                        .leftLeg(0, 0, -3).tilt(0).drop(-0.14f).shake(0f)
                .fade(2, 6).build());

        // X Lipat Ruang: jentikan jari kanan di depan wajah, lalu lenyap (AKSARA_FOLD_SNAP).
        int fs = ShazamAnim.AKSARA_FOLD_SNAP;
        CLIPS.put(ShazamAnim.AKSARA_FOLD, Clip.builder(fs + 11)
                .key(0, Ease.OUT_CUBIC).rightArm(-118, -24, 0).head(-4, 0, 0).tilt(-2)
                .key(fs - 1, Ease.IN_QUAD).rightArm(-126, -30, 0).shake(0.6f)
                .key(fs, Ease.OUT_BACK).rightArm(-104, 10, 12).tilt(6).shake(0f)
                .key(fs + 11, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).head(0, 0, 0).tilt(0)
                .fade(1, 5).build());

        // Shift+X Gerbang Ruang: kedua tangan melukis lingkaran besar, lalu kedua telapak mendorong gerbangnya terbuka.
        int go = ShazamAnim.AKSARA_GATE_OPEN, gs = ShazamAnim.AKSARA_GATE_SWALLOW;
        CLIPS.put(ShazamAnim.AKSARA_GATE, Clip.builder(gs + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-170, 0, -8).leftArm(-170, 0, 8).head(-16, 0, 0).tilt(-4)
                .key(go / 2f, Ease.IN_OUT_SINE).rightArm(-90, 0, 80).leftArm(-90, 0, -80).head(-6, 0, 0)
                .key(go, Ease.OUT_BACK).rightArm(-92, -18, 0).leftArm(-92, 18, 0).head(0, 0, 0).tilt(6).rightLeg(-16, 0, 4)
                        .leftLeg(14, 0, -4).shake(0.8f)
                .key(gs - 2, Ease.LINEAR).rightArm(-96, -22, 0).leftArm(-96, 22, 0).tilt(10).shake(2.4f)
                .key(gs, Ease.OUT_BACK).rightArm(-60, 0, 60).leftArm(-60, 0, -60).tilt(-6).shake(0.6f)
                .key(gs + 12, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).tilt(0).rightLeg(0, 0, 3)
                        .leftLeg(0, 0, -3).shake(0f)
                .fade(2, 6).build());

        // C Tusuk Benak: dua jari ke pelipis, lalu menunjuk sasaran (ikut bidikan).
        int lh = ShazamAnim.AKSARA_LANCE_HIT;
        CLIPS.put(ShazamAnim.AKSARA_LANCE, Clip.builder(lh + 15)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, -40, 38).head(10, -8, 0).tilt(2)
                .key(lh - 2, Ease.IN_QUAD).rightArm(-156, -44, 42).head(16, -10, 0).shake(1.0f)
                .key(lh, Ease.OUT_BACK).rightArm(-94, 0, 0).head(-2, 0, 0).tilt(-4).twist(14).shake(0.2f).aim(1f)
                .key(lh + 15, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).head(0, 0, 0).tilt(0).twist(0).shake(0f).aim(0f)
                .fade(1, 6).build());

        // Shift+C Kuasa Benak: kedua tangan di pelipis, kepala terdongak, lalu lengan terhentak terbuka ke depan-samping.
        // 0.59 lanjutannya: kedua tangan terangkat tinggi (musuh terangkat), lalu dihentak ke bawah tepat saat mereka
        // dibanting (AKSARA_DOMINION_HIT + 12 = AksaraSkills.DOMINION_SLAM_DELAY).
        int dh = ShazamAnim.AKSARA_DOMINION_HIT;
        CLIPS.put(ShazamAnim.AKSARA_DOMINION, Clip.builder(dh + 30)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, -40, 38).leftArm(-150, 40, -38).head(-12, 0, 0).tilt(-2)
                .key(dh - 3, Ease.IN_QUAD).rightArm(-158, -46, 44).leftArm(-158, 46, -44).head(-30, 0, 0).tilt(-8)
                        .drop(-0.12f).shake(2.4f)
                .key(dh, Ease.OUT_BACK).rightArm(-88, 0, 70).leftArm(-88, 0, -70).head(8, 0, 0).tilt(8).drop(-0.2f)
                        .shake(1.0f)
                .key(dh + 9, Ease.OUT_CUBIC).rightArm(-172, 0, 24).leftArm(-172, 0, -24).head(-24, 0, 0).tilt(-10)
                        .drop(-0.04f).shake(1.6f)
                .key(dh + 12, Ease.IN_QUAD).rightArm(-34, 0, 12).leftArm(-34, 0, -12).head(22, 0, 0).tilt(16).drop(-0.3f)
                        .shake(0.6f)
                .key(dh + 30, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).tilt(0)
                        .drop(-0.14f).shake(0f)
                .fade(2, 6).build());

        // 0.60 Alt+Z Tombak Langit: lengan kanan menunjuk langit (kepala mendongak), lalu dihentak ke sasaran saat tombak jatuh.
        int ss = ShazamAnim.AKSARA_SKYSPEAR_STRIKE;
        CLIPS.put(ShazamAnim.AKSARA_SKYSPEAR, Clip.builder(ss + 14)
                .key(0, Ease.OUT_CUBIC).rightArm(-176, 0, 6).leftArm(-20, 0, -14).head(-28, 0, 0).tilt(-6)
                .key(ss - 3, Ease.IN_QUAD).rightArm(-180, 0, 4).head(-32, 0, 0).tilt(-8).shake(1.6f)
                .key(ss, Ease.OUT_BACK).rightArm(-70, 0, 0).head(10, 0, 0).tilt(10).drop(-0.1f).aim(1f).shake(0.8f)
                .key(ss + 14, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).tilt(0).drop(0f)
                        .aim(0f).shake(0f)
                .fade(2, 6).build());

        // 0.60 Alt+X Sumur Graviton: telapak kanan terbuka ke depan (sumur terbentuk), lalu digenggam & ditarik ke dada.
        int gc = ShazamAnim.AKSARA_GRAVITY_CAST;
        CLIPS.put(ShazamAnim.AKSARA_GRAVITY, Clip.builder(gc + 18)
                .key(0, Ease.OUT_CUBIC).rightArm(-84, 0, 0).leftArm(-30, 0, -10).head(4, 0, 0).aim(1f)
                .key(gc, Ease.OUT_BACK).rightArm(-92, 0, 0).tilt(-4).shake(1.2f).aim(1f)
                .key(gc + 6, Ease.IN_QUAD).rightArm(-70, -10, 0).tilt(4).shake(0.4f).aim(0.8f)
                .key(gc + 18, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).tilt(0).shake(0f)
                        .aim(0f)
                .fade(1, 6).build());

        // 0.60 Alt+C Jaring Saraf: dua jari di pelipis, lalu tangan kanan terentang dengan jemari terbuka.
        int nh = ShazamAnim.AKSARA_NEURAL_HIT;
        CLIPS.put(ShazamAnim.AKSARA_NEURAL, Clip.builder(nh + 14)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, -40, 38).head(8, -8, 0).tilt(2)
                .key(nh - 2, Ease.IN_QUAD).rightArm(-156, -44, 42).head(14, -10, 0).shake(1.0f)
                .key(nh, Ease.OUT_BACK).rightArm(-96, 30, 40).head(-4, 10, 0).tilt(-4).twist(-12).shake(0.3f)
                .key(nh + 14, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).head(0, 0, 0).tilt(0).twist(0).shake(0f)
                .fade(1, 6).build());

        // 0.60 Alt+V Duri Maya: badan merunduk, telapak kanan menyapu rendah ke tanah ke depan.
        int sh = ShazamAnim.AKSARA_SPIKES_HIT;
        CLIPS.put(ShazamAnim.AKSARA_SPIKES, Clip.builder(sh + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, 0, 20).leftArm(-40, 0, -20).head(-6, 0, 0).tilt(-6)
                .key(sh, Ease.OUT_BACK).rightArm(-30, 0, 10).leftArm(-60, 0, -30).head(18, 0, 0).tilt(22).drop(-0.35f)
                        .shake(1.0f)
                .key(sh + 16, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).tilt(0).drop(0f)
                        .shake(0f)
                .fade(1, 6).build());

        // 0.60 Alt+B Gema Kala: lengan kanan memutar satu lingkaran jam di depan dada, lalu kedua telapak terbuka.
        int ec = ShazamAnim.AKSARA_ECHO_CAST;
        CLIPS.put(ShazamAnim.AKSARA_ECHO, Clip.builder(ec + 14)
                .key(0, Ease.IN_OUT_SINE).rightArm(-90, -40, 0)
                .key(2, Ease.IN_OUT_SINE).rightArm(-130, 0, 0)
                .key(4, Ease.IN_OUT_SINE).rightArm(-90, 40, 0)
                .key(ec, Ease.OUT_BACK).rightArm(-60, 0, 0).leftArm(-60, 0, 0).head(6, 0, 0).shake(0.6f)
                .key(ec + 14, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).shake(0f)
                .fade(1, 6).build());

        // 0.60 Alt+N Tambatan Atma: tangan kanan terulur mencengkeram, lalu ditarik ke dada saat rantai jiwa terpasang.
        int tetherHit = ShazamAnim.AKSARA_TETHER_HIT;
        CLIPS.put(ShazamAnim.AKSARA_TETHER, Clip.builder(tetherHit + 14)
                .key(0, Ease.OUT_CUBIC).rightArm(-90, 0, 0).head(4, 0, 0).aim(1f)
                .key(tetherHit, Ease.OUT_BACK).rightArm(-40, -30, 20).tilt(-6).shake(1.0f).aim(0.6f)
                .key(tetherHit + 14, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).head(0, 0, 0).tilt(0).shake(0f).aim(0f)
                .fade(1, 6).build());

        // V Ubah Maya: tangan kiri terangkat seperti memegang kitab, jari kanan menulis di udara (kiri-kanan-kiri),
        // lalu dihentakkan ke bawah di AKSARA_REWRITE_HIT.
        int wh = ShazamAnim.AKSARA_REWRITE_HIT;
        CLIPS.put(ShazamAnim.AKSARA_REWRITE, Clip.builder(wh + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-84, -20, 0).leftArm(-110, 30, 0).head(8, 0, 0).tilt(2)
                .key(4, Ease.IN_OUT_SINE).rightArm(-92, 18, 0)
                .key(7, Ease.IN_OUT_SINE).rightArm(-80, -22, 0)
                .key(10, Ease.IN_OUT_SINE).rightArm(-96, 14, 0)
                .key(13, Ease.IN_OUT_SINE).rightArm(-104, -10, 6).shake(0.8f)
                .key(wh, Ease.OUT_BACK).rightArm(-38, 0, 10).leftArm(-70, 20, 0).head(18, 0, 0).tilt(12).shake(0.2f)
                .key(wh + 16, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).tilt(0).shake(0f)
                .fade(1, 6).build());

        // Shift+V Cermin Maya: kibasan lengan kanan menyilang badan, badan berputar setengah dan memudar.
        int vh = ShazamAnim.AKSARA_VEIL_HIT;
        CLIPS.put(ShazamAnim.AKSARA_VEIL, Clip.builder(vh + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-70, 30, 30).leftArm(-20, 0, -30).twist(-20)
                .key(vh, Ease.OUT_BACK).rightArm(-64, -70, 0).leftArm(-30, 30, 0).twist(28).lean(-4)
                .key(vh + 12, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).twist(0).lean(0)
                .fade(1, 6).build());

        // B Henti Kala: lengan kanan diangkat lurus, telapak terbuka, lalu digenggam: waktu berhenti.
        int th = ShazamAnim.AKSARA_TIMESTOP_HIT;
        CLIPS.put(ShazamAnim.AKSARA_TIMESTOP, Clip.builder(th + 18)
                .key(0, Ease.OUT_CUBIC).rightArm(-150, 0, 14).leftArm(-14, 0, -24).head(-18, 0, 0).tilt(-4)
                .key(th - 2, Ease.IN_QUAD).rightArm(-176, 0, 4).head(-26, 0, 0).tilt(-6).drop(-0.1f).shake(1.4f)
                .key(th, Ease.OUT_BACK).rightArm(-170, 0, 8).head(-20, 0, 0).shake(0f)
                .key(th + 10, Ease.LINEAR).rightArm(-168, 0, 8)
                .key(th + 18, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).tilt(0)
                        .drop(-0.14f)
                .fade(2, 6).build());

        // Shift+B Putar Kala: lengan bersilang di dada, lalu terbuka sambil berputar balik (seperti jarum jam mundur).
        int kh = ShazamAnim.AKSARA_REWIND_HIT;
        CLIPS.put(ShazamAnim.AKSARA_REWIND, Clip.builder(kh + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-70, -50, 0).leftArm(-70, 50, 0).head(16, 0, 0).tilt(6)
                .key(kh - 1, Ease.IN_QUAD).rightArm(-76, -56, 0).leftArm(-76, 56, 0).twist(-24).shake(1.4f)
                .key(kh, Ease.OUT_BACK).rightArm(-40, 0, 90).leftArm(-40, 0, -90).head(-18, 0, 0).twist(30).tilt(-8)
                        .shake(0.4f)
                .key(kh + 16, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).twist(0).tilt(0)
                        .shake(0f)
                .fade(1, 6).build());

        // N Rampas Atma: kedua tangan mencakar ke depan, menarik jiwa pelan-pelan (gemetar), lalu dicabut ke belakang.
        int sw = ShazamAnim.AKSARA_SOUL_WINDUP, sr = ShazamAnim.AKSARA_SOUL_RIP;
        CLIPS.put(ShazamAnim.AKSARA_SOUL, Clip.builder(sr + 12)
                .key(0, Ease.OUT_CUBIC).rightArm(-80, -10, 20).leftArm(-80, 10, -20).head(6, 0, 0).tilt(6)
                .key(sw, Ease.OUT_BACK).rightArm(-96, -16, 10).leftArm(-96, 16, -10).head(10, 0, 0).tilt(10)
                        .rightLeg(-14, 0, 4).leftLeg(14, 0, -4).shake(1.0f)
                .key(sr - 4, Ease.IN_OUT_SINE).rightArm(-70, -6, 22).leftArm(-70, 6, -22).head(0, 0, 0).tilt(-4).shake(2.6f)
                .key(sr, Ease.OUT_BACK).rightArm(28, 0, 30).leftArm(28, 0, -30).head(-20, 0, 0).tilt(-14).twist(0).shake(1.2f)
                .key(sr + 12, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).tilt(0)
                        .rightLeg(0, 0, 3).leftLeg(0, 0, -3).shake(0f)
                .fade(2, 6).build());

        // Shift+N Tirai Atma: kedua telapak dikatupkan di depan dada, lalu dibentangkan pelan.
        int ah = ShazamAnim.AKSARA_WARD_HIT;
        CLIPS.put(ShazamAnim.AKSARA_WARD, Clip.builder(ah + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-72, -46, 0).leftArm(-72, 46, 0).head(14, 0, 0).tilt(4)
                .key(ah - 2, Ease.IN_OUT_SINE).rightArm(-80, -50, 0).leftArm(-80, 50, 0).head(20, 0, 0).shake(0.6f)
                .key(ah, Ease.OUT_CUBIC).rightArm(-46, 0, 74).leftArm(-46, 0, -74).head(-10, 0, 0).tilt(-4).shake(0f)
                .key(ah + 16, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).tilt(0)
                .fade(2, 6).build());

        // R Sabda Purna: naik tinggi, lengan terbuka makin lebar, menengadah, lalu terhentak ke atas di AKSARA_PURNA_HIT.
        int ph = ShazamAnim.AKSARA_PURNA_HIT;
        CLIPS.put(ShazamAnim.AKSARA_PURNA, Clip.builder(ph + 18)
                .key(0, Ease.OUT_CUBIC).rightArm(-20, 0, 40).leftArm(-20, 0, -40).head(-10, 0, 0).tilt(0).drop(-0.14f)
                .key(ph - 6, Ease.IN_OUT_SINE).rightArm(-30, 0, 96).leftArm(-30, 0, -96).head(-34, 0, 0).tilt(-8)
                        .drop(-0.62f).shake(2.0f)
                .key(ph - 1, Ease.IN_QUAD).rightArm(-60, 20, 50).leftArm(-60, -20, -50).head(14, 0, 0).tilt(12)
                        .drop(-0.5f).shake(3.4f)
                .key(ph, Ease.OUT_BACK).rightArm(-160, 0, -36).leftArm(-160, 0, 36).head(-44, 0, 0).rightLeg(-4, 0, 10)
                        .leftLeg(4, 0, -10).tilt(-14).drop(-0.8f).shake(2.6f)
                .key(ph + 18, Ease.IN_OUT_SINE).rightArm(-14, 0, 24).leftArm(-14, 0, -24).head(-4, 0, 0).rightLeg(0, 0, 3)
                        .leftLeg(0, 0, -3).tilt(0).drop(-0.2f).shake(0f)
                .fade(2, 8).build());

        // Shift+R Penghapusan: naik tinggi dengan lengan terentang lurus (heksagram terbentuk), gemetar makin hebat, lalu
        // kedua telapak didorong ke depan di AKSARA_ERASE_HIT dan turun pelan.
        int eh = ShazamAnim.AKSARA_ERASE_HIT;
        CLIPS.put(ShazamAnim.AKSARA_ERASE, Clip.builder(eh + 26)
                .key(0, Ease.OUT_CUBIC).rightArm(-30, 0, 50).leftArm(-30, 0, -50).head(-16, 0, 0).drop(-0.2f)
                .key(26, Ease.IN_OUT_SINE).rightArm(-10, 0, 92).leftArm(-10, 0, -92).head(-26, 0, 0).tilt(-6).drop(-1.3f)
                        .rightLeg(6, 0, 4).leftLeg(10, 0, -4).shake(1.0f)
                .key(eh - 6, Ease.IN_OUT_SINE).rightArm(-14, 0, 96).leftArm(-14, 0, -96).head(-36, 0, 0).tilt(-10)
                        .drop(-1.45f).shake(3.6f)
                .key(eh - 1, Ease.IN_QUAD).rightArm(-70, -30, 20).leftArm(-70, 30, -20).head(10, 0, 0).tilt(14).drop(-1.3f)
                        .shake(4.4f)
                .key(eh, Ease.OUT_BACK).rightArm(-100, 0, 40).leftArm(-100, 0, -40).head(-6, 0, 0).tilt(8).drop(-1.4f)
                        .shake(3.0f)
                .key(eh + 26, Ease.IN_OUT_SINE).rightArm(-14, 0, 22).leftArm(-14, 0, -22).head(0, 0, 0).tilt(0)
                        .rightLeg(0, 0, 3).leftLeg(0, 0, -3).drop(-0.14f).shake(0f)
                .fade(3, 10).build());

        // M Lontar Cakram: lengan kanan menarik ke kiri badan, lalu menyapu lebar ke kanan melepas enam cakram.
        int dt = ShazamAnim.AKSARA_DISCS_THROW;
        CLIPS.put(ShazamAnim.AKSARA_DISCS, Clip.builder(dt + 16)
                .key(0, Ease.OUT_CUBIC).rightArm(-84, 52, 0).leftArm(-20, 0, -20).head(4, 0, 0).twist(-26)
                .key(dt - 1, Ease.IN_QUAD).rightArm(-90, 60, 0).twist(-32).shake(0.8f)
                .key(dt, Ease.OUT_BACK).rightArm(-92, -42, 40).twist(30).tilt(4).shake(0f)
                .key(dt + 16, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).twist(0).tilt(0)
                .fade(1, 6).build());

        // Shift+M Perisai Sabda: lengan kiri terangkat menyilang di depan wajah, cakram berputar jadi perisai.
        CLIPS.put(ShazamAnim.AKSARA_SHIELD, Clip.builder(16)
                .key(0, Ease.OUT_BACK).leftArm(-100, 34, 0).rightArm(-30, 0, 30).head(6, 0, 0).tilt(4)
                .key(10, Ease.LINEAR).leftArm(-98, 32, 0)
                .key(16, Ease.IN_OUT_SINE).leftArm(-12, 0, -18).rightArm(-12, 0, 18).head(0, 0, 0).tilt(0)
                .fade(1, 5).build());

        // J Langkah Ruang: condong sekejap ke arah tujuan.
        CLIPS.put(ShazamAnim.AKSARA_STEP, Clip.builder(10)
                .key(0, Ease.OUT_CUBIC).rightArm(-30, 0, 40).leftArm(-30, 0, -40).tilt(20)
                .key(10, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).tilt(0)
                .fade(1, 4).build());

        // Shift+J Tulis Ulang Diri: telapak kanan di dada, garis prada menyala (gemetar), lalu kedua lengan terbuka.
        int fh = ShazamAnim.AKSARA_SELF_HIT;
        CLIPS.put(ShazamAnim.AKSARA_SELF, Clip.builder(fh + 14)
                .key(0, Ease.OUT_CUBIC).rightArm(-64, -36, 0).leftArm(-14, 0, -24).head(18, 0, 0).tilt(6)
                .key(fh - 2, Ease.IN_OUT_SINE).rightArm(-70, -40, 0).head(24, 0, 0).shake(1.8f)
                .key(fh, Ease.OUT_BACK).rightArm(-40, 0, 60).leftArm(-40, 0, -60).head(-22, 0, 0).tilt(-8).shake(0.2f)
                .key(fh + 14, Ease.IN_OUT_SINE).rightArm(-12, 0, 18).leftArm(-12, 0, -18).head(0, 0, 0).tilt(0).shake(0f)
                .fade(1, 6).build());
    }

    static {
        ThanosClips.register(CLIPS);   // 0.63 Thanos
        RelativaClips.register(CLIPS); // 0.66 RELATIVA
    }
}
