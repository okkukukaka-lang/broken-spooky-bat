package com.shazammod.client;

import java.lang.reflect.Method;

import com.shazammod.kaldera.Kaldera;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 0.74 Kamera orang ketiga saat menunggangi KALDERA: ditarik jauh ke belakang & sedikit ke atas supaya seluruh tubuh
 * titannya kelihatan (kamera biasa cuma 4 blok, jadi terjebak di dalam kepalanya). Kalau terhalang bukit, kamera berhenti
 * sedikit sebelum bloknya. Orang pertama tetap duduk di dahinya. Tarikannya mulus saat naik & turun.
 */
public final class KalderaRideCam {
    private KalderaRideCam() {}

    private static final double BACK = 44.0;   // jarak di belakang mata penunggang
    private static final double UP = 7.0;
    private static float level, levelO;
    private static Method setPosition;
    private static boolean broken;

    /** Tiap tick client: naik / turun dari KALDERA = kamera menjauh / mendekat pelan. */
    public static void tick(Minecraft mc) {
        levelO = level;
        boolean riding = mc.player != null && mc.player.getVehicle() instanceof Kaldera;
        level = Mth.clamp(level + (riding ? 0.08f : -0.15f), 0f, 1f);
    }

    public static void clear() {
        level = levelO = 0f;
    }

    public static void apply(Camera cam, float partialTick) {
        if (broken || (level <= 0f && levelO <= 0f) || !cam.isDetached()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || cam.getEntity() != p || mc.level == null) {
            return;
        }
        float k = Mth.lerp(partialTick, levelO, level);
        k = k * k * (3f - 2f * k);
        if (k <= 0.001f) {
            return;
        }
        double yaw = cam.getYRot() * Mth.DEG_TO_RAD, pitch = cam.getXRot() * Mth.DEG_TO_RAD;
        Vec3 fwd = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
        Vec3 eye = p.getEyePosition(partialTick);
        Vec3 from = cam.getPosition();
        // dari posisi kamera biasa, mundur lagi sepanjang arah pandangnya (kamera depan/cermin: tetap menjauhi penunggang)
        Vec3 to = from.add(fwd.scale(-(BACK - 4.0) * k)).add(0, UP * k, 0);
        BlockHitResult hit = mc.level.clip(new ClipContext(eye, to, ClipContext.Block.VISUAL, ClipContext.Fluid.NONE, p));
        if (hit.getType() != HitResult.Type.MISS) {   // terhalang bukit / bangunan: berhenti sedikit sebelum bloknya
            Vec3 d = to.subtract(eye);
            double len = d.length();
            double keep = Math.max(0.0, hit.getLocation().distanceTo(eye) - 0.4);
            to = len < 1.0E-4 ? from : eye.add(d.scale(keep / len));
        }
        move(cam, to);
    }

    /** Camera.setPosition(Vec3) dilindungi (protected): dipanggil lewat refleksi; kalau gagal, fitur ini mati sendiri. */
    private static void move(Camera cam, Vec3 to) {
        try {
            if (setPosition == null) {
                setPosition = Camera.class.getDeclaredMethod("setPosition", Vec3.class);
                setPosition.setAccessible(true);
            }
            setPosition.invoke(cam, to);
        } catch (Throwable t) {
            broken = true;
        }
    }
}
