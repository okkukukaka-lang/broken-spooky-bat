package com.shazammod.client;

import com.shazammod.kaldera.Kaldera;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * 0.74 Panel penunggang KALDERA (kiri bawah): darah titannya, tujuh jurus di tombol skill (terang = siap, kelabu = masih
 * jeda, redup semua = jurus lain sedang berjalan), penghancuran nyala/mati, dan cara mengendalikannya. Tombolnya ikut
 * pengaturan Kontrol pemain.
 */
public final class KalderaHud {
    private KalderaHud() {}

    private static final int MIN_W = 150, LINE = 11;
    private static final int BG = 0xA0081208, EDGE = 0xFF2E9A12, TITLE = 0xFF9CFF6A, READY = 0xFFE8FFE0, WAIT = 0xFF6E7A6A;
    private static final int KEY_READY = 0xFF2E9A12, KEY_WAIT = 0xFF2A3328, BAR = 0xFF7CFF3A, BAR_BG = 0xFF1A2618, HOT = 0xFFFFE066;
    /** Urutan baris: jurus (bit siap), tombol skill (indeks SKILL_KEYS), nama di bahasa. */
    private static final int[][] ROWS = {{0, 0}, {1, 1}, {2, 2}, {3, 3}, {4, 4}, {5, 6}};
    private static final String[] NAMES = {"stomp", "erupt", "vent", "roar", "fall", "crit"};

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || !(mc.player.getVehicle() instanceof Kaldera k)) {
            return;
        }
        Font font = mc.font;
        Component hint = Component.translatable("hud.shazammod.kaldera.hint");
        int W = Math.max(MIN_W, font.width(hint) + 8);
        int rows = ROWS.length + 1;
        int h = 26 + rows * LINE + 12;
        int x = 6, y = g.guiHeight() - h - 30;
        g.fill(x - 1, y - 1, x + W + 1, y + h + 1, EDGE);
        g.fill(x, y, x + W, y + h, BG);
        int bits = k.readyBits();
        boolean busy = (bits & Kaldera.READY_BUSY) != 0, crit = k.isRaging();
        g.drawString(font, Component.literal("☢ ").append(Component.translatable("hud.shazammod.kaldera.title")),
                x + 4, y + 4, crit ? HOT : TITLE, true);
        // darahnya
        float hp = Mth.clamp(k.getHealth() / k.getMaxHealth(), 0f, 1f);
        int bx = x + 4, by = y + 16, bw = W - 8;
        g.fill(bx, by, bx + bw, by + 4, BAR_BG);
        g.fill(bx, by, bx + Math.round(bw * hp), by + 4, crit ? HOT : BAR);
        String num = (int) Math.ceil(k.getHealth()) + "/" + (int) k.getMaxHealth();
        g.drawString(font, num, x + W - 4 - font.width(num), y + 4, WAIT, false);
        int ty = y + 25;
        for (int i = 0; i < ROWS.length; i++) {
            boolean ready = !busy && (bits & (1 << ROWS[i][0])) != 0;
            row(g, font, x, ty, ShazamClient.SKILL_KEYS[ROWS[i][1]].getTranslatedKeyMessage(),
                    Component.translatable("hud.shazammod.kaldera." + NAMES[i]), ready);
            ty += LINE;
        }
        boolean smash = (bits & Kaldera.READY_SMASH) != 0;
        row(g, font, x, ty, ShazamClient.SKILL_KEYS[5].getTranslatedKeyMessage(), Component.translatable("hud.shazammod.kaldera.smash")
                .append(" ").append(Component.translatable(smash ? "hud.shazammod.kaldera.on" : "hud.shazammod.kaldera.off")), true);
        ty += LINE + 2;
        g.drawString(font, hint, x + 4, ty, WAIT, false);
    }

    private static void row(GuiGraphics g, Font font, int x, int y, Component key, Component name, boolean ready) {
        String k = key.getString();
        if (k.length() > 3) {
            k = k.substring(0, 3);
        }
        int kw = Math.max(11, font.width(k) + 4);
        g.fill(x + 4, y - 1, x + 4 + kw, y + 9, ready ? KEY_READY : KEY_WAIT);
        g.drawString(font, k, x + 4 + (kw - font.width(k)) / 2, y, ready ? READY : WAIT, false);
        g.drawString(font, name, x + 8 + kw, y, ready ? READY : WAIT, ready);
    }
}
