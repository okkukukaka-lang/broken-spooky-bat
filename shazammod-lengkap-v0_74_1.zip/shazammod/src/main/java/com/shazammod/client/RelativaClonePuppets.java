package com.shazammod.client;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.mojang.authlib.GameProfile;
import com.shazammod.client.fx.RelativaFx;
import com.shazammod.relativa.RelativaClientState;
import com.shazammod.relativa.RelativaClone;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;

/**
 * 0.70 Salinan Kucing Schrödinger digambar sebagai pemain boneka (cara yang sama dengan RivalPuppets): tiap RelativaClone
 * yang kelihatan punya satu RemotePlayer palsu (id negatif, nggak bisa dipukul / didorong) yang mengikuti posisi, arah,
 * ayunan tangan, ukuran, baju zirah, dan barang di tangannya tiap tick. Kulitnya kulit RELATIVA aslinya (dari daftar
 * pemain), namanya juga, dan bonekanya didaftarkan sebagai RELATIVA di RelativaClientState, jadi atom di dada, orbit,
 * lingkaran cahaya, klip gerakan (Lesat Cahaya, tinju) dan semua efek RELATIVA berlaku sama persis: salinan yang asli
 * nggak bisa dibedakan.
 *
 * Yang dipukul pemain tetap entity salinannya (kotak tabraknya sama besar, tapi entity-nya sendiri nggak digambar).
 */
public final class RelativaClonePuppets {
    private RelativaClonePuppets() {}

    /** Id boneka = PUPPET_BASE - id salinan (selalu negatif, nggak bentrok dengan boneka rival). */
    private static final int PUPPET_BASE = -1_000_000_000;

    private static final Map<Integer, Puppet> PUPPETS = new HashMap<>();

    /** Boneka untuk entity ini: salinan -> bonekanya (dibuat kalau belum ada), selain itu null. */
    public static Puppet puppetOf(Entity entity) {
        if (!(entity instanceof RelativaClone clone) || !(clone.level() instanceof ClientLevel level) || clone.isRemoved()) {
            return null;
        }
        Puppet puppet = PUPPETS.get(clone.getId());
        if (puppet == null || puppet.isRemoved()) {
            puppet = spawn(level, clone);
        }
        return puppet;
    }

    /** Tiap tick client (sesudah entity bergerak, sebelum animasi baru diputar). */
    public static void tick(ClientLevel level) {
        Iterator<Map.Entry<Integer, Puppet>> it = PUPPETS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Puppet> e = it.next();
            Puppet puppet = e.getValue();
            Entity clone = level.getEntity(e.getKey());
            if (!(clone instanceof RelativaClone) || clone.isRemoved() || puppet.level() != level || puppet.isRemoved()) {
                despawn(puppet);
                it.remove();
            }
        }
        List<RelativaClone> clones = new ArrayList<>();
        for (Entity entity : level.entitiesForRendering()) {
            if (entity instanceof RelativaClone clone && !clone.isRemoved()) {
                clones.add(clone);
            }
        }
        for (RelativaClone clone : clones) {
            Puppet puppet = PUPPETS.get(clone.getId());
            if (puppet == null) {
                puppet = spawn(level, clone);
            }
            puppet.follow(clone, false);
            if (level.tickRateManager().isEntityFrozen(clone)) {
                puppet.tickCount = Math.max(0, puppet.tickCount - 1);   // waktu beku: bonekanya ikut diam
            }
        }
    }

    public static void clear() {
        for (Puppet puppet : PUPPETS.values()) {
            despawn(puppet);
        }
        PUPPETS.clear();
    }

    private static Puppet spawn(ClientLevel level, RelativaClone clone) {
        Puppet puppet = new Puppet(level, clone);
        puppet.follow(clone, true);
        level.addEntity(puppet);
        PUPPETS.put(clone.getId(), puppet);
        RelativaClientState.putPuppet(puppet.getId());
        RelativaFx.cloneBorn(puppet, clone.owner());
        return puppet;
    }

    private static void despawn(Puppet puppet) {
        RelativaClientState.removePuppet(puppet.getId());
        if (puppet.level() instanceof ClientLevel level && level.getEntity(puppet.getId()) == puppet) {
            level.removeEntity(puppet.getId(), Entity.RemovalReason.DISCARDED);
        }
    }

    private static PlayerInfo info(UUID owner) {
        ClientPacketListener connection = Minecraft.getInstance().getConnection();
        return owner == null || connection == null ? null : connection.getPlayerInfo(owner);
    }

    private static String ownerName(RelativaClone clone) {
        PlayerInfo info = info(clone.owner());
        return info != null ? info.getProfile().getName() : "RELATIVA";
    }

    /** Pemain boneka yang mengikuti satu salinan. Nggak berpikir & nggak bergerak sendiri. */
    public static final class Puppet extends RemotePlayer {
        private final UUID owner;
        private boolean collapsing;

        Puppet(ClientLevel level, RelativaClone clone) {
            super(level, new GameProfile(UUID.nameUUIDFromBytes(("shazammod:relativa_clone/" + clone.getUUID())
                    .getBytes(StandardCharsets.UTF_8)), ownerName(clone)));
            this.owner = clone.owner();
            this.setId(PUPPET_BASE - clone.getId());
            this.noCulling = true;
            this.entityData.set(DATA_PLAYER_MODE_CUSTOMISATION, (byte) 0x7F);   // semua lapisan kulit terlihat
        }

        /** Sedang runtuh: badannya nggak digambar lagi (tinggal partikelnya). */
        public boolean hidden() {
            return collapsing;
        }

        public UUID owner() {
            return owner;
        }

        void follow(RelativaClone c, boolean first) {
            if (first) {
                this.moveTo(c.getX(), c.getY(), c.getZ(), c.getYRot(), c.getXRot());
                this.setOldPosAndRot();
                this.yBodyRot = c.yBodyRot;
                this.yHeadRot = c.yHeadRot;
            }
            this.setOldPosAndRot();
            this.yBodyRotO = this.yBodyRot;
            this.yHeadRotO = this.yHeadRot;
            this.oAttackAnim = this.attackAnim;
            this.setPos(c.getX(), c.getY(), c.getZ());
            this.setYRot(c.getYRot());
            this.setXRot(c.getXRot());
            this.yBodyRot = c.yBodyRot;
            this.yHeadRot = c.yHeadRot;
            this.setOnGround(c.onGround());
            this.setDeltaMovement(this.getX() - this.xo, this.getY() - this.yo, this.getZ() - this.zo);
            this.calculateEntityAnimation(false);
            this.attackAnim = c.attackAnim;
            this.swinging = c.swinging;
            this.swingTime = c.swingTime;
            this.swingingArm = c.swingingArm;
            this.hurtTime = c.hurtTime;
            this.hurtDuration = c.hurtDuration;
            this.setInvisible(c.isInvisible());
            this.setPose(c.getPose());
            this.collapsing = c.collapsing();
            AttributeInstance scale = this.getAttribute(Attributes.SCALE);
            double want = c.getScale();
            if (scale != null && Math.abs(scale.getBaseValue() - want) > 1.0E-4) {
                scale.setBaseValue(want);
                this.refreshDimensions();
            }
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                if (slot == EquipmentSlot.BODY) {
                    continue;
                }
                ItemStack want2 = c.getItemBySlot(slot);
                if (!ItemStack.matches(this.getItemBySlot(slot), want2)) {
                    this.setItemSlot(slot, want2.copy());
                }
            }
        }

        @Override
        public void tick() {
            // digerakkan RelativaClonePuppets.tick, bukan oleh dunia
        }

        @Override
        public void aiStep() {
        }

        @Override
        public boolean isPickable() {
            return false;
        }

        @Override
        public boolean isPushable() {
            return false;
        }

        @Override
        public boolean canBeCollidedWith() {
            return false;
        }

        @Override
        public boolean isSpectator() {
            return false;
        }

        @Override
        public boolean isCreative() {
            return false;
        }

        @Override
        public PlayerSkin getSkin() {
            PlayerInfo info = info(owner);
            return info != null ? info.getSkin() : DefaultPlayerSkin.get(owner != null ? owner : this.getUUID());
        }
    }
}
