package com.shazammod.client.fx;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shazammod.ShazamAnim;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;
import com.shazammod.thanos.StoneType;
import com.shazammod.thanos.ThanosClientState;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

/**
 * 0.63 Efek THANOS (fan-made, desain orisinal). Bahasa visualnya: energi kosmik ungu-violet dengan inti putih, enam warna
 * batu (Power ungu, Space biru, Mind kuning, Reality merah, Time hijau, Soul jingga) yang keluar dari TANGAN KANAN
 * (tangan Gauntlet, sama dengan ThanosClips), debu cokelat keemasan untuk Jentikan. Semua dibangun dari mesin efek mod ini
 * (Fx, Hd, CineFx, CineKit, ScreenFx), tick puncaknya = ShazamAnim.TITAN_*.
 *
 *   Sumpah Titan   pusaran kosmik dari kaki, butir enam warna berputar masuk ke kepalan, lalu ledakan + tiang cahaya
 *   berubah        tenaga terkumpul di kepalan, batu yang dimiliki menyala satu per satu, ledakan kosmik, kawah kecil
 *   Tinju/Ledakan  kerucut gelombang ungu ke depan | nova ungu, kawah, tiang cahaya
 *   Langkah/Bulan  robekan ruang biru di depan tangan & di tujuan, bayangan tertinggal | pusaran gelap di langit, batu
 *                  bulan menyala jatuh berekor api, kawah tiap hantaman
 *   Belenggu/Badai sinar kuning ke sasaran, lingkaran mahkota di kepala budak | gelombang pikiran berlapis
 *   Palsu/Badai    pita merah membelit sasaran lalu pecah jadi pecahan kaca | kubah realitas merah yang berkedip glitch
 *   Putar/Henti    cincin jam berputar mundur, bayangan sepanjang jalan pulang | kubah waktu hijau, jam raksasa di tanah
 *   Panen/Perisai  tali jiwa jingga bergelombang dari tiap makhluk ke tangan | perisai heksagon jingga
 *   JENTIKAN       keenam batu menyala satu per satu, dunia menggelap, kilatan putih menyilaukan, gelombang emas yang
 *                  menyapu 48 blok, makhluk yang lenyap terurai jadi debu yang terbawa angin
 *   selalu         butiran warna batu di sekitar tangan Gauntlet; Murka Titan: nyala merah di sekeliling badan
 */
public final class ThanosFx {
    private ThanosFx() {}

    static final int[] STONE = {0x9B45E0, 0x3F7BFF, 0xFFD23A, 0xE5262E, 0x35D654, 0xFF8A1C};
    static final int COSMIC = 0x8A5CFF, COSMIC_HOT = 0xE6D8FF, GOLD = 0xFFC861, VOID = 0x0B0716;
    static final int[] DUST = {0x8A6A52, 0x6E5644, 0xB09070, 0x5A463A};
    private static final Vec3 UP = new Vec3(0, 1, 0);
    private static final Map<Integer, Integer> SNAP_TOKEN = new HashMap<>();

    // ------------------------------------------------------------------ pintu masuk

    public static void onAnim(AbstractClientPlayer p, ShazamAnim anim, Vec3 pos) {
        if (!(p.level() instanceof ClientLevel level)) {
            return;
        }
        boolean self = p == Minecraft.getInstance().player;
        switch (anim) {
            case THANOS_BIND -> bind(level, p, self);
            case THANOS_TRANSFORM -> transform(level, p, self);
            case THANOS_REVERT -> revert(level, p);
            case THANOS_PUNCH -> punch(p, self);
            case THANOS_NOVA -> nova(p, self);
            case THANOS_STEP -> step(p, pos, self);
            case THANOS_MOON -> moon(p, pos, self);
            case TITAN_METEOR -> meteor(level, pos);
            case THANOS_MIND -> mind(p, pos, self);
            case TITAN_THRALL -> thrall(level, pos);
            case THANOS_MINDSTORM -> mindstorm(p, self);
            case THANOS_WRAP -> wrap(p, pos);
            case TITAN_WRAP_BURST -> wrapBurst(pos);
            case THANOS_REALITY -> reality(p, self);
            case THANOS_REWIND -> rewind(p, pos, self);
            case THANOS_TIMESTOP -> timestop(p, self);
            case THANOS_HARVEST -> harvest(level, p, self);
            case THANOS_SHIELD -> shield(p);
            case THANOS_SNAP -> snap(p, self);
            case TITAN_SNAP_CANCEL -> snapCancel(p);
            case TITAN_SNAP_WAVE -> snapWave(pos);
            case TITAN_DUST -> dust(p, pos);
            case TITAN_SLAM -> slam(level, p, pos, self);
            case THANOS_RAGE -> rage(p, self);
            case TITAN_RAGE_END -> CineKit.motesOut(chest(p), 18, 0xFF5030, 0.06, 0.06f, 16);
            case THANOS_SPIN -> spin(p);
            case THANOS_THROW -> schedule(ShazamAnim.TITAN_THROW_AT, 1,
                    (lvl, t) -> Vfx.add(new Fx.Flash(handNow(p), 0.5f, 0xD8E0F0, 6, 0.8f)));
            case THANOS_LEAP -> schedule(ShazamAnim.TITAN_LEAP_JUMP, 1, (lvl, t) -> {
                Vfx.add(new Hd.DustBurst(feet(p), 1.6, 0x8A7A6A, 22, 0.6f, true));
                CineKit.shock(lvl, feet(p), UP, 3.0, 0xC8B8A8, 0xFFFFFF, 12, 0.5f, true, true);
            });
            case TITAN_PARRY -> parry(pos);
            case TITAN_STONE_FOUND -> stoneFound(level, p, pos, self);
            case TITAN_SIGNAL -> Vfx.add(new SignalArrow(chest(p), flat(new Vec3(pos.x - p.getX(), 0, pos.z - p.getZ())),
                    STONE[Mth.clamp((int) Math.round(pos.y), 0, 5)], 50));
            default -> { }
        }
    }

    /** Tiap tick client: butiran warna batu di tangan Gauntlet setiap Thanos yang terlihat. */
    public static void tick(ClientLevel level) {
        if (Minecraft.getInstance().isPaused()) {
            return;
        }
        long time = level.getGameTime();
        RandomSource r = level.random;
        for (Map.Entry<Integer, ThanosClientState.Other> en : ThanosClientState.all().entrySet()) {
            if (!(level.getEntity(en.getKey()) instanceof AbstractClientPlayer p) || !p.isAlive() || p.isInvisible()) {
                continue;
            }
            int mask = en.getValue().stones();
            if (time % 3 == 0) {
                Vec3 h = ShazamPoses.handPos(p, true, 1f);
                Vfx.mote(h.x + (r.nextDouble() - 0.5) * 0.25, h.y + (r.nextDouble() - 0.5) * 0.25, h.z + (r.nextDouble() - 0.5) * 0.25,
                        0, 0.015, 0, colorOf(mask, r), 0.05f, 12);
            }
            if (time % 9 == 0) {
                double a = r.nextDouble() * Math.PI * 2.0;
                Vfx.mote(p.getX() + Math.cos(a) * 0.5, p.getY() + r.nextDouble() * p.getBbHeight(), p.getZ() + Math.sin(a) * 0.5,
                        0, 0.02, 0, COSMIC, 0.04f, 18);
            }
        }
        if (time % 200 == 0) {
            ThanosClientState.all().keySet().removeIf(id -> !(level.getEntity(id) instanceof AbstractClientPlayer));
        }
    }

    // ------------------------------------------------------------------ Sumpah Titan & berubah

    private static void bind(ClientLevel level, AbstractClientPlayer p, boolean self) {
        int burst = ShazamAnim.TITAN_BIND_BURST;
        Lightning.Anchor hand = hand(p);
        if (self) {
            ScreenFx.cinema(ShazamAnim.TITAN_BIND_TICKS + 10);
            ScreenFx.titleKey("title.shazammod.thanos.bind", 0xC9A0FF, 60, burst);
        }
        CineFx.gather(p, 10, burst - 10, hand, COSMIC, 2.8, 2.4f, true);
        Vfx.add(new Hd.Vortex(feetAnchor(p), 2.6, 0.7, 3.4, 5, 1.6, 0.12f, COSMIC, COSMIC_HOT, VOID, 0.12f, burst, 0.75f));
        schedule(0, burst, (lvl, t) -> {
            if (t % 3 != 0) {
                return;
            }
            Vec3 h = hand.at(1f);
            double a = t * 0.35, rr = 2.6 - 1.8 * t / (double) burst;
            Vfx.mote(h.x + Math.cos(a) * rr, h.y - 0.6 + lvl.random.nextDouble() * 1.2, h.z + Math.sin(a) * rr,
                    -Math.cos(a) * 0.08, 0.02, -Math.sin(a) * 0.08, STONE[(t / 3) % 6], 0.09f, 14);
        });
        schedule(0, burst, (lvl, t) -> {
            if (t % 20 == 0) {
                CineKit.shock(lvl, feet(p), UP, 3.0 + t / 20.0, COSMIC, COSMIC_HOT, 16, 0.4f, true);
            }
        });
        schedule(burst, 1, (lvl, t) -> {
            Vec3 h = hand.at(1f);
            CineKit.burst(h, 2.4f, COSMIC, 0xFFFFFF, 18, 1f);
            CineKit.shock(lvl, feet(p), UP, 8.0, COSMIC, GOLD, 24, 0.9f, true);
            CineFx.godRays(hand, COSMIC, 18.0, 2.4, 10, 0.9f, 44);
            Vfx.add(new Fx.Pillar(feet(p), 14.0, 1.4f, COSMIC, 22));
            Vfx.add(new Fx.Aura(p, COSMIC, 50, () -> 1f));
            CineKit.camera(p, h, 0.9f, 24);
            if (self) {
                ScreenFlash.flash(0.55f, 0xE8D8FF);
                FovKick.punch(-0.08f);
            }
        });
    }

    private static void transform(ClientLevel level, AbstractClientPlayer p, boolean self) {
        int burst = ShazamAnim.TITAN_MORPH_BURST;
        Lightning.Anchor hand = hand(p);
        int mask = stones(p);
        if (self) {
            ScreenFx.cinema(ShazamAnim.TITAN_MORPH_TICKS + 6);
            ScreenFx.titleKey("title.shazammod.thanos.transform", 0xC9A0FF, 46, burst);
        }
        CineFx.gather(p, 0, burst, hand, COSMIC, 1.8, 2.2f, true);
        int k = 0;
        for (StoneType stone : StoneType.values()) {
            if ((mask & stone.bit()) == 0) {
                continue;
            }
            final int c = stone.rgb;
            schedule(4 + k * 3, 1, (lvl, t) -> {
                Vec3 h = hand.at(1f);
                Vfx.add(new Fx.Flash(h, 0.5f, c, 8, 0.9f));
                Vfx.glint(h.x, h.y, h.z, c, 0.35f, 10);
                Vfx.add(new Fx.Ripple(h, UP, 0.0, 0.1, 0.9, 0.06, c, 10, 0.8f, false));
            });
            k++;
        }
        schedule(burst, 1, (lvl, t) -> {
            Vec3 h = hand.at(1f);
            CineKit.burst(h, 2.0f, COSMIC, 0xFFFFFF, 16, 1f);
            Vfx.add(new Hd.Pressure(chest(p), UP, 6.0, Math.PI, COSMIC, 14, 0.8f, true));
            CineKit.shock(lvl, feet(p), UP, 7.0, COSMIC, COSMIC_HOT, 22, 0.9f, true);
            CineKit.crater(lvl, feet(p), 2.6, 0xE0C8FF, 0x6A5A4A, 20);
            CineFx.godRays(hand, COSMIC, 14.0, 1.6, 8, 0.7f, 30);
            Vfx.add(new Fx.Aura(p, COSMIC, 40, () -> 0.9f));
            CineKit.camera(p, h, 0.8f, 22);
            if (self) {
                ScreenFlash.flash(0.45f, 0xE8D8FF);
                FovKick.punch(-0.07f);
            }
        });
    }

    private static void revert(ClientLevel level, AbstractClientPlayer p) {
        Vec3 c = chest(p);
        CineKit.motesOut(c, 34, COSMIC, 0.09, 0.07f, 22);
        Vfx.add(new Fx.Flash(c, 0.9f, COSMIC, 8, 0.6f));
        ShazamFx.smokeCloud(level, feet(p), 0x40304A, 4, 0.8);
    }

    // ------------------------------------------------------------------ Power

    private static void punch(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.TITAN_PUNCH_HIT;
        Lightning.Anchor hand = hand(p);
        int c = STONE[0];
        CineFx.gather(p, 0, hit, hand, c, 0.9, 1.6f, true);
        schedule(hit, 1, (lvl, t) -> {
            Vec3 h = hand.at(1f);
            Vec3 look = p.getViewVector(1f);
            CineKit.burst(h, 0.9f, c, 0xFFFFFF, 10, 1f);
            Vfx.add(new Fx.Cone(h, look, 7.5, 0.42, c, 12, 0.95f, 2.0, false));
            Vfx.add(new Hd.Pressure(h, look, 7.0, 0.7, c, 12, 0.9f, true));
            for (int i = 0; i < 3; i++) {
                Vfx.add(new Fx.Ripple(h, look, 6.0 + i, 0.3, 2.2 + i * 0.4, 0.22, i == 0 ? hot(c) : c, 10 + i * 2, 0.9f, false));
            }
            RandomSource r = lvl.random;
            for (int i = 0, n = Vfx.count(26); i < n; i++) {
                Vec3 d = look.add((r.nextDouble() - 0.5) * 0.7, (r.nextDouble() - 0.5) * 0.5, (r.nextDouble() - 0.5) * 0.7)
                        .normalize().scale(0.6 + r.nextDouble() * 0.8);
                Vfx.spark(h.x, h.y, h.z, d.x, d.y, d.z, hot(c), 0.08f, 8 + r.nextInt(6), Double.NaN);
            }
            CineKit.camera(p, h, 0.45f, 16);
            if (self) {
                FovKick.punch(-0.05f);
            }
        });
    }

    private static void nova(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.TITAN_NOVA_HIT;
        int c = STONE[0];
        CineFx.gather(p, 0, hit, hand(p), c, 1.6, 2.2f, true);
        schedule(hit, 1, (lvl, t) -> {
            Vec3 f = feet(p);
            Vfx.add(new Hd.Nova(f.add(0, 0.4, 0), 6.5, 0xFFFFFF, c, 0x3A1060, 0x2A2030, 26, 1f, true));
            CineKit.crater(lvl, f, 4.5, hot(c), 0x6A5A4A, 30);
            CineKit.shock(lvl, f, UP, 9.0, c, hot(c), 20, 1f, true);
            Vfx.add(new Fx.Pillar(f, 9.0, 1.3f, c, 16));
            CineFx.flare(f.add(0, 1, 0), hot(c), 9f, 0.3f, 1f, 14);
            CineKit.camera(p, f, 1.0f, 26);
            if (self) {
                ScreenFlash.flash(0.3f, 0xE0B0FF);
                FovKick.punch(-0.08f);
            }
        });
    }

    // ------------------------------------------------------------------ Space

    private static void step(AbstractClientPlayer p, Vec3 dest, boolean self) {
        int at = ShazamAnim.TITAN_STEP_AT;
        int c = STONE[1];
        Vec3 look = p.getViewVector(1f);
        Vfx.add(new Rift(handNow(p).add(look.scale(0.5)), look, c, at + 10, 1.3));
        schedule(at, 1, (lvl, t) -> {
            Vec3 from = feet(p);
            Vfx.add(new Hd.Ghost(from, p.yBodyRot, p.getScale(), 1, c, hot(c), 14, 0.8f));
            Vfx.add(new Fx.Flash(from.add(0, 1, 0), 1.2f, c, 8, 0.9f));
            Vfx.add(new Rift(dest.add(0, 1.0, 0), look, c, 16, 1.6));
            Vfx.add(new Fx.Flash(dest.add(0, 1, 0), 1.4f, c, 10, 1f));
            CineKit.shock(lvl, dest, UP, 4.0, c, hot(c), 14, 0.8f, true);
            CineKit.motesOut(dest.add(0, 1, 0), 30, hot(c), 0.12, 0.07f, 14);
            if (self) {
                FovKick.kick(0.1f);
            }
        });
    }

    private static void moon(AbstractClientPlayer p, Vec3 center, boolean self) {
        int open = ShazamAnim.TITAN_MOON_OPEN;
        int life = ShazamAnim.TITAN_MOON_FIRST + ShazamAnim.TITAN_MOON_COUNT * ShazamAnim.TITAN_MOON_GAP
                + ShazamAnim.TITAN_METEOR_FALL + 14 - open;
        int c = STONE[1];
        CineFx.gather(p, 0, open, hand(p), c, 1.4, 1.8f, true);
        schedule(open, 1, (lvl, t) -> {
            Vec3 sky = center.add(0, 24, 0);
            Vfx.add(new SkyRift(sky, 7.0, life));
            CineFx.godRays(Lightning.Anchor.fixed(sky), c, 24.0, 3.5, 9, 0.6f, life);
            Vfx.add(new Fx.Flash(sky, 6f, c, 12, 0.8f));
            CineKit.camera(p, center, 0.4f, 40);
            if (self) {
                ScreenFx.vignette(0.25f, 0x1A2A60, life);
            }
        });
    }

    private static void meteor(ClientLevel level, Vec3 at) {
        RandomSource r = level.random;
        Vec3 start = at.add((r.nextDouble() - 0.5) * 8, 26 + r.nextDouble() * 6, (r.nextDouble() - 0.5) * 8);
        int fall = ShazamAnim.TITAN_METEOR_FALL;
        Vfx.add(new Meteor(start, at, fall));
        schedule(fall, 1, (lvl, t) -> {
            Vfx.add(new Hd.Nova(at.add(0, 0.6, 0), 3.0, 0xFFF0C0, 0xFF7A30, 0x602010, 0x302820, 22, 1f, true));
            CineKit.crater(lvl, at, 2.4, 0xFF8A40, 0x5A4A3A, 30);
            CineKit.shock(lvl, at, UP, 5.0, 0xFF9050, 0xFFE0B0, 14, 0.8f, true);
            HdKit.shards(at.add(0, 0.5, 0), 14, 0.5, 0x6A5A6A, 0.12f, 30, at.y);
            ShazamFx.shakeAround(at, 0.6f, 30);
        });
    }

    // ------------------------------------------------------------------ Mind

    private static void mind(AbstractClientPlayer p, Vec3 target, boolean self) {
        int hit = ShazamAnim.TITAN_MIND_HIT;
        int c = STONE[2];
        Lightning.Anchor hand = hand(p);
        CineFx.gather(p, 0, hit, hand, c, 0.8, 1.4f, false);
        schedule(hit, 1, (lvl, t) -> {
            Vfx.add(new Hd.Lance(hand.at(1f), target, 0.24f, c, 0xFFFFFF, 3, 14));
            Vfx.add(new Fx.Flash(target, 1.0f, c, 10, 1f));
            CineFx.flare(target, hot(c), 3f, 0.12f, 0.9f, 10);
            if (self) {
                FovKick.punch(-0.03f);
            }
        });
    }

    private static void thrall(ClientLevel level, Vec3 pos) {
        LivingEntity e = near(level, pos, 2.5);
        if (e != null) {
            Vfx.add(new Halo(e, STONE[2], ShazamAnim.TITAN_THRALL_TICKS));
        }
    }

    private static void mindstorm(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.TITAN_MINDSTORM_HIT;
        int c = STONE[2];
        Lightning.Anchor head = CineKit.headAnchor(p);
        CineFx.gather(p, 0, hit, head, c, 1.2, 1.6f, false);
        schedule(hit, 1, (lvl, t) -> {
            Vec3 h = head.at(1f);
            for (int i = 0; i < 3; i++) {
                final int k = i;
                schedule(i * 4, 1, (l2, t2) -> Vfx.add(new Fx.Wave(h.add(0, -0.3, 0), UP, 14.0, 0.35,
                        k == 0 ? hot(c) : c, 22, 0.8f, 0.04f, null)));
            }
            Vfx.add(new Hd.Pressure(h, UP, 9.0, Math.PI, c, 16, 0.7f, true));
            for (LivingEntity e : lvl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(14.0),
                    e -> e != p && e.isAlive() && !(e instanceof ArmorStand))) {
                Vfx.add(new Fx.Flash(e.position().add(0, e.getBbHeight() + 0.3, 0), 0.5f, c, 10, 0.8f));
                Vfx.add(new Halo(e, c, ShazamAnim.TITAN_MINDSTORM_TICKS / 2));
            }
            if (self) {
                ScreenFx.vignette(0.25f, c, 20);
            }
        });
    }

    // ------------------------------------------------------------------ Reality

    private static void wrap(AbstractClientPlayer p, Vec3 target) {
        int hit = ShazamAnim.TITAN_WRAP_HIT;
        int c = STONE[3];
        Lightning.Anchor hand = hand(p);
        schedule(0, hit, (lvl, t) -> {
            Vec3 h = hand.at(1f);
            for (int i = 0; i < 2; i++) {
                double a = t * 0.9 + i * Math.PI;
                Vfx.mote(h.x + Math.cos(a) * 0.35, h.y + Math.sin(a) * 0.35, h.z + Math.sin(a) * 0.2, 0, 0, 0, c, 0.07f, 8);
            }
        });
        schedule(hit, 1, (lvl, t) -> {
            Vfx.add(new Hd.Lance(hand.at(1f), target, 0.16f, c, 0xFFD0D0, 3, 10));
            Vfx.add(new Fx.Flash(target, 0.9f, c, 8, 0.9f));
            LivingEntity e = near(lvl, target, 2.5);
            if (e != null) {
                Vfx.add(new Ribbons(e, c, ShazamAnim.TITAN_WRAP_HOLD));
            }
        });
    }

    private static void wrapBurst(Vec3 at) {
        int c = STONE[3];
        CineKit.burst(at, 1.2f, c, 0xFFFFFF, 12, 1f);
        HdKit.shards(at, 18, 0.35, 0xC01828, 0.1f, 26, at.y - 1.0);
        CineKit.sparks(at, 20, hot(c), 0.4, 0.07f, 12, at.y - 1.0);
        ShazamFx.shakeAround(at, 0.3f, 16);
    }

    private static void reality(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.TITAN_REALITY_HIT;
        int c = STONE[3];
        schedule(hit, 1, (lvl, t) -> {
            Vec3 f = feet(p);
            Vfx.add(new RealityStorm(f, 9.0, ShazamAnim.TITAN_REALITY_TICKS));
            CineKit.shock(lvl, f, UP, 9.0, c, hot(c), 18, 0.8f, true);
            Vfx.add(new Fx.Flash(f.add(0, 1, 0), 2f, c, 10, 0.8f));
            if (self) {
                FovKick.kick(-0.06f);
            }
        });
    }

    // ------------------------------------------------------------------ Time

    private static void rewind(AbstractClientPlayer p, Vec3 back, boolean self) {
        int at = ShazamAnim.TITAN_REWIND_AT;
        int c = STONE[4];
        Vfx.add(new ClockRing(p, c, at + 8));
        schedule(at, 1, (lvl, t) -> {
            Vec3 from = feet(p);
            for (int i = 0; i <= 4; i++) {
                Vfx.add(new Hd.Ghost(from.lerp(back, i / 4.0), p.yBodyRot, p.getScale(), 0, c, hot(c), 10 + i * 3, 0.6f));
            }
            Vfx.add(new Fx.Flash(back.add(0, 1, 0), 1.2f, c, 10, 0.9f));
            CineKit.shock(lvl, back, UP, 3.5, c, hot(c), 14, 0.7f, true);
            HdKit.streaksIn(back.add(0, 1, 0), 20, 2.5, c, 0.08f, 10);
            if (self) {
                ScreenFx.vignette(0.3f, c, 10);
                FovKick.kick(-0.1f);
            }
        });
    }

    private static void timestop(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.TITAN_TIMESTOP_HIT;
        int c = STONE[4];
        Lightning.Anchor hand = hand(p);
        CineFx.gather(p, 0, hit, hand, c, 1.0, 1.4f, false);
        schedule(hit, 1, (lvl, t) -> {
            Vec3 f = feet(p);
            Vfx.add(new TimeDome(f, 10.0, ShazamAnim.TITAN_TIMESTOP_TICKS));
            Vfx.add(new Fx.Flash(hand.at(1f), 1.6f, c, 10, 1f));
            CineKit.shock(lvl, f, UP, 10.0, c, hot(c), 16, 0.9f, true);
            if (self) {
                ScreenFlash.flash(0.25f, 0xC8FFD0);
            }
        });
    }

    // ------------------------------------------------------------------ Soul

    private static void harvest(ClientLevel level, AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.TITAN_HARVEST_HIT, len = ShazamAnim.TITAN_HARVEST_TICKS;
        int c = STONE[5];
        Lightning.Anchor hand = hand(p);
        CineFx.gather(p, 0, hit, hand, c, 0.8, 1.2f, false);
        List<LivingEntity> victims = level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(10.0),
                e -> e != p && e.isAlive() && !(e instanceof ArmorStand) && e.distanceTo(p) <= 10.0);
        for (LivingEntity e : victims) {
            Vfx.add(new SoulStream(e, hand, c, hit, len));
        }
        schedule(hit + len, 1, (lvl, t) -> {
            Vec3 h = hand.at(1f);
            CineKit.burst(h, 1.0f, c, 0xFFFFFF, 10, 1f);
            CineKit.motesOut(h, 20, hot(c), 0.08, 0.06f, 14);
        });
        if (self) {
            schedule(hit, len, (lvl, t) -> {
                if (t % 10 == 0) {
                    ScreenFx.vignette(0.15f, c, 8);
                }
            });
        }
    }

    private static void shield(AbstractClientPlayer p) {
        int hit = ShazamAnim.TITAN_SHIELD_HIT;
        int c = STONE[5];
        schedule(hit, 1, (lvl, t) -> {
            Vfx.add(new Hd.Shield(CineKit.chestAnchor(p), 1.7, c, hot(c), ShazamAnim.TITAN_SHIELD_TICKS, 0.75f));
            CineKit.burst(chest(p), 1.0f, c, 0xFFFFFF, 10, 0.8f);
            Vfx.add(new Fx.Wave(chest(p), UP, 3.0, 0.2, c, 12, 0.8f, 0.05f, null));
        });
    }

    // ------------------------------------------------------------------ JENTIKAN

    private static boolean cancelled(AbstractClientPlayer p, int token) {
        return SNAP_TOKEN.getOrDefault(p.getId(), 0) != token;
    }

    private static void snap(AbstractClientPlayer p, boolean self) {
        int snapAt = ShazamAnim.TITAN_SNAP_AT;
        int token = SNAP_TOKEN.merge(p.getId(), 1, Integer::sum);
        Lightning.Anchor hand = hand(p);
        if (self) {
            ScreenFx.cinema(snapAt + 30);
            ScreenFx.titleKey("title.shazammod.thanos.snap", 0xFFE6A8, 50, snapAt);
        }
        CineFx.gather(p, 4, snapAt - 4, hand, COSMIC, 2.4, 2.6f, true);
        for (int k = 0; k < 6; k++) {
            final int c = STONE[k];
            final int when = k * ShazamAnim.TITAN_SNAP_STAGGER;
            schedule(when, 1, (lvl, t) -> {
                if (cancelled(p, token)) {
                    return;
                }
                Vec3 h = hand.at(1f);
                Vfx.add(new Fx.Flash(h, 0.7f, c, 10, 1f));
                Vfx.add(new Fx.Ripple(h, UP, 0.0, 0.1, 1.4, 0.07, c, 12, 0.9f, false));
                Vfx.add(new Fx.Glow(p, pt -> hand.at(pt).add(0, 0.05 * (when / 8 - 2.5), 0), 0.45f, c, snapAt - when, 3));
                Vfx.glint(h.x, h.y, h.z, c, 0.4f, 12);
                if (self) {
                    ScreenFx.vignette(0.12f, c, 6);
                }
            });
        }
        schedule(40, snapAt - 40, (lvl, t) -> {
            if (cancelled(p, token)) {
                return;
            }
            LocalPlayer me = Minecraft.getInstance().player;
            if (me != null && me.distanceToSqr(p) < 64.0 * 64.0) {
                Vfx.worldTint(0x2A1A3A, 0.15f + 0.02f * t);
            }
        });
        schedule(snapAt, 1, (lvl, t) -> {
            if (cancelled(p, token)) {
                return;
            }
            Vec3 h = hand.at(1f);
            CineKit.burst(h, 3.0f, 0xFFFFFF, GOLD, 20, 1f);
            CineFx.flare(h, 0xFFF0C8, 18f, 0.4f, 1f, 24);
            Vfx.add(new Fx.Flash(h, 6f, 0xFFF4E0, 10, 0.9f));
            ShazamFx.shakeAround(h, 1.2f, 64);
            LocalPlayer me = Minecraft.getInstance().player;
            if (me != null && me.distanceToSqr(p) < 64.0 * 64.0) {
                ScreenFlash.flash(0.7f, 0xFFF4E0);
            }
            if (self) {
                FovKick.punch(-0.12f);
            }
        });
    }

    private static void snapCancel(AbstractClientPlayer p) {
        SNAP_TOKEN.merge(p.getId(), 1, Integer::sum);
        ShazamPoses.start(p, ShazamAnim.THANOS_REVERT);   // lengan turun, cahaya batu padam
        CineKit.motesOut(handNow(p), 16, COSMIC, 0.05, 0.05f, 12);
    }

    private static void snapWave(Vec3 at) {
        Vfx.add(new SnapWave(at.add(0, 0.2, 0), 48.0, 70));
        schedule(0, 60, (lvl, t) -> {
            LocalPlayer me = Minecraft.getInstance().player;
            if (me != null && me.distanceToSqr(at) < 58.0 * 58.0) {
                Vfx.worldTint(0x6A5A48, 0.35f * (1f - t / 60f));
            }
        });
    }

    private static void dust(AbstractClientPlayer p, Vec3 at) {
        Vec3 away = flat(at.subtract(p.position()));
        Vfx.add(new Hd.DustBurst(at, 0.9, DUST[0], 30, 0.6f, false));
        schedule(0, 24, (lvl, t) -> {
            RandomSource r = lvl.random;
            int n = t < 12 ? 6 : 3;
            for (int i = 0; i < n; i++) {
                Vfx.dust(at.x + (r.nextDouble() - 0.5) * 0.8, at.y + (r.nextDouble() - 0.5) * 1.4, at.z + (r.nextDouble() - 0.5) * 0.8,
                        away.x * 0.04 + (r.nextDouble() - 0.5) * 0.02, 0.01 + r.nextDouble() * 0.02,
                        away.z * 0.04 + (r.nextDouble() - 0.5) * 0.02, DUST[r.nextInt(DUST.length)], 0.22f + r.nextFloat() * 0.2f,
                        40 + r.nextInt(20));
            }
            if (t % 2 == 0) {
                Vfx.cinder(at.x + (r.nextDouble() - 0.5) * 0.6, at.y + (r.nextDouble() - 0.5) * 1.2, at.z + (r.nextDouble() - 0.5) * 0.6,
                        away.x * 0.03, 0.02, away.z * 0.03, 0x3A2A22, 0.06f, 50, -0.002f);
            }
        });
    }

    // ------------------------------------------------------------------ Murka Titan, pedang, lain-lain

    private static void rage(AbstractClientPlayer p, boolean self) {
        int hit = ShazamAnim.TITAN_RAGE_HIT;
        schedule(hit, 1, (lvl, t) -> {
            Vec3 head = CineKit.headAnchor(p).at(1f);
            Vfx.add(new Hd.Pressure(head, UP, 7.0, Math.PI, 0xFF5030, 14, 0.8f, true));
            CineKit.shock(lvl, feet(p), UP, 6.0, 0xFF5030, 0xFFD0A0, 16, 0.8f, true);
            Vfx.add(new Fx.Aura(p, 0xFF4A28, ShazamAnim.TITAN_RAGE_TICKS + 20, () -> {
                ThanosClientState.Other o = ThanosClientState.thanos(p.getId());
                return o != null && o.rage() ? 1f : 0f;
            }));
            CineKit.camera(p, head, 0.7f, 22);
            if (self) {
                ScreenFx.vignette(0.35f, 0xC02010, 30);
                FovKick.punch(-0.06f);
            }
        });
    }

    private static void spin(AbstractClientPlayer p) {
        schedule(ShazamAnim.TITAN_SPIN_HIT, 1, (lvl, t) -> {
            Vec3 c = p.position().add(0, 1.0, 0);
            Vfx.add(new Fx.Wave(c, UP, 4.6, 0.5, 0xD8E0F0, 10, 0.9f, 0.05f, null));
            Vfx.add(new Fx.Wave(c, UP, 4.2, 0.18, 0xFFFFFF, 8, 0.9f, 0f, null));
            for (int i = 0, n = Vfx.count(24); i < n; i++) {
                double a = i * Math.PI * 2.0 / n;
                Vfx.spark(c.x + Math.cos(a) * 3.6, c.y, c.z + Math.sin(a) * 3.6, -Math.sin(a) * 0.5, 0.05, Math.cos(a) * 0.5,
                        0xFFFFFF, 0.06f, 8, Double.NaN);
            }
        });
    }

    private static void slam(ClientLevel level, AbstractClientPlayer p, Vec3 at, boolean self) {
        CineFx.impact(level, at.add(0, 0.2, 0), 2.0f, COSMIC, COSMIC_HOT, self, true);
        CineKit.crater(level, at, 3.6, 0xC8A0FF, 0x6A5A4A, 30);
        Vfx.add(new Hd.DustBurst(at.add(0, 0.3, 0), 3.0, 0x8A7A6A, 30, 0.7f, true));
    }

    private static void parry(Vec3 at) {
        CineKit.sparks(at, 18, 0xFFE8B0, 0.35, 0.06f, 8, at.y - 1.5);
        Vfx.add(new Fx.Flash(at, 0.6f, 0xFFFFFF, 5, 0.9f));
        Vfx.glint(at.x, at.y, at.z, 0xFFFFFF, 0.5f, 6);
    }

    private static void stoneFound(ClientLevel level, AbstractClientPlayer p, Vec3 pos, boolean self) {
        int k = Mth.clamp((int) Math.round(pos.x), 0, 5);
        int c = STONE[k];
        Vec3 f = feet(p);
        Vfx.add(new Fx.Pillar(f, 16.0, 1.2f, c, 30));
        CineKit.burst(chest(p), 1.6f, c, 0xFFFFFF, 16, 1f);
        CineKit.shock(level, f, UP, 6.0, c, hot(c), 20, 0.8f, true);
        CineFx.godRays(feetAnchor(p), c, 14.0, 1.8, 8, 0.7f, 40);
        schedule(0, 30, (lvl, t) -> {
            Vec3 ch = chest(p);
            double a = t * 0.5;
            Vfx.mote(ch.x + Math.cos(a) * 1.2, ch.y - 0.8 + t * 0.06, ch.z + Math.sin(a) * 1.2, 0, 0.03, 0, c, 0.08f, 16);
        });
        if (self) {
            ScreenFx.titleKey("title.shazammod.thanos.stone." + StoneType.byIndex(k).id, c, 50, 4);
            ScreenFx.vignette(0.3f, c, 20);
        }
    }

    // ------------------------------------------------------------------ alat bantu

    private static void schedule(int delay, int duration, ShazamFx.Step step) {
        ShazamFx.schedule(delay, duration, step);
    }

    private static Lightning.Anchor hand(AbstractClientPlayer p) {
        return pt -> ShazamPoses.handPos(p, true, pt);
    }

    private static Vec3 handNow(AbstractClientPlayer p) {
        return ShazamPoses.handPos(p, true, 1f);
    }

    private static Vec3 chest(Entity e) {
        return e.position().add(0, e.getBbHeight() * 0.62, 0);
    }

    private static Vec3 feet(Entity e) {
        return e.position().add(0, 0.05, 0);
    }

    private static Lightning.Anchor feetAnchor(Entity e) {
        return Lightning.Anchor.on(e, 0, 0.05, 0);
    }

    private static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 1) : f.normalize();
    }

    static int hot(int rgb) {
        return Draw.mix(rgb, 0xFFFFFF, 0.65);
    }

    private static int stones(AbstractClientPlayer p) {
        if (p == Minecraft.getInstance().player) {
            return ThanosClientState.stones;
        }
        ThanosClientState.Other o = ThanosClientState.thanos(p.getId());
        return o == null ? 0 : o.stones();
    }

    private static int colorOf(int mask, RandomSource r) {
        if (mask == 0) {
            return COSMIC;
        }
        for (int tries = 0; tries < 8; tries++) {
            int k = r.nextInt(6);
            if ((mask & (1 << k)) != 0) {
                return STONE[k];
            }
        }
        return COSMIC;
    }

    private static LivingEntity near(ClientLevel level, Vec3 pos, double r) {
        LivingEntity best = null;
        double bd = r * r;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new net.minecraft.world.phys.AABB(pos, pos).inflate(r))) {
            double d = e.position().add(0, e.getBbHeight() * 0.62, 0).distanceToSqr(pos);
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        return best;
    }

    private static float fade(float time, float life, float in, float out) {
        return Mth.clamp(time / in, 0f, 1f) * Mth.clamp((life - time) / out, 0f, 1f);
    }

    // ================================================================== efek khusus Thanos

    /** Robekan ruang: dua tepi bergerigi yang membuka lalu menutup, isinya kehampaan gelap, tepinya menyala. */
    static final class Rift extends Effect {
        private final Vec3 c, side;
        private final int rgb;
        private final double size;
        private final float[] jag = new float[9];

        Rift(Vec3 c, Vec3 look, int rgb, int life, double size) {
            super(life);
            this.c = c;
            Vec3 f = new Vec3(look.x, 0, look.z);
            this.side = f.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : new Vec3(-f.z, 0, f.x).normalize();
            this.rgb = rgb;
            this.size = size;
            RandomSource r = Vfx.random();
            for (int i = 0; i < jag.length; i++) {
                jag[i] = (float) (r.nextDouble() - 0.5);
            }
        }

        private float open(float pt) {
            float t = progress(pt);
            return t < 0.25f ? t / 0.25f : t > 0.7f ? (1f - t) / 0.3f : 1f;
        }

        @Override
        public void renderGlow(Draw d) {
            float open = open(d.partialTick);
            double h = size * (0.6 + 0.4 * open);
            int n = jag.length;
            float[] left = new float[n * 3], right = new float[n * 3];
            for (int i = 0; i < n; i++) {
                double f = i / (double) (n - 1);
                double y = c.y + (f - 0.5) * 2.0 * h;
                double w = Math.sin(Math.PI * f) * 0.35 * size * open;
                double j = jag[i] * 0.14 * size;
                left[i * 3] = (float) (c.x + side.x * (-w + j));
                left[i * 3 + 1] = (float) y;
                left[i * 3 + 2] = (float) (c.z + side.z * (-w + j));
                right[i * 3] = (float) (c.x + side.x * (w + j));
                right[i * 3 + 1] = (float) y;
                right[i * 3 + 2] = (float) (c.z + side.z * (w + j));
            }
            d.polyline(left, n, 0.09f, 0.09f, rgb, 0xFFFFFF, open, open);
            d.polyline(right, n, 0.09f, 0.09f, rgb, 0xFFFFFF, open, open);
            d.glow(c.x, c.y, c.z, (float) (size * 0.9), rgb, 0.45f * open);
        }

        @Override
        public void renderSoft(Draw d) {
            float open = open(d.partialTick);
            d.puff(c.x, c.y, c.z, (float) (size * 0.38 * open), VOID, VOID, 0.85f * open);
        }
    }

    /** Pusaran gelap di langit: kehampaan bertepi cahaya biru, lengan spiral berputar, kilat kecil di tepinya. */
    static final class SkyRift extends Effect {
        private final Vec3 c;
        private final double r;

        SkyRift(Vec3 c, double r, int life) {
            super(life);
            this.c = c;
            this.r = r;
        }

        private float alpha(float pt) {
            return fade(time(pt), life, 8f, 14f);
        }

        private double radius(float pt) {
            return r * (0.4 + 0.6 * Math.min(1.0, time(pt) / 10.0));
        }

        @Override
        public void renderGlow(Draw d) {
            float a = alpha(d.partialTick);
            double rr = radius(d.partialTick);
            float time = time(d.partialTick);
            d.ring(c.x, c.y, c.z, 0, 1, 0, rr, rr * 0.18, STONE[1], a, 0.1f, null);
            d.ring(c.x, c.y, c.z, 0, 1, 0, rr * 0.82, rr * 0.06, 0xFFFFFF, a * 0.7f, 0f, null);
            int n = 12;
            for (int k = 0; k < 5; k++) {
                float[] pts = new float[n * 3];
                for (int i = 0; i < n; i++) {
                    double f = i / (double) (n - 1);
                    double ang = k * Math.PI * 2.0 / 5.0 + f * 2.4 + time * 0.08;
                    double rad = rr * (1.0 - 0.85 * f);
                    pts[i * 3] = (float) (c.x + Math.cos(ang) * rad);
                    pts[i * 3 + 1] = (float) (c.y - f * 0.6);
                    pts[i * 3 + 2] = (float) (c.z + Math.sin(ang) * rad);
                }
                d.polyline(pts, n, 0.5f, 0.08f, COSMIC, COSMIC_HOT, a * 0.7f, a * 0.2f);
            }
            float old = d.body(0.4f);
            d.glow(c.x, c.y - 0.5, c.z, (float) (rr * 1.2), STONE[1], 0.3f * a);
            d.body(old);
        }

        @Override
        public void renderSoft(Draw d) {
            float a = alpha(d.partialTick);
            d.disc(c.x, c.y + 0.05, c.z, 0, 1, 0, radius(d.partialTick) * 0.85, VOID, 0.92f * a, 0.0f, null);
        }
    }

    /** Batu bulan yang jatuh: bongkah gelap yang menyala, ekor api & asap, makin cepat menjelang tanah. */
    static final class Meteor extends Effect {
        private final Vec3 a, b;

        Meteor(Vec3 a, Vec3 b, int life) {
            super(life);
            this.a = a;
            this.b = b;
        }

        private Vec3 at(float time) {
            float t = Mth.clamp(time / life, 0f, 1f);
            return a.lerp(b, t * t);
        }

        @Override
        public boolean tick(ClientLevel level) {
            Vec3 p = at(age + 1f);
            RandomSource r = level.random;
            Vfx.flame(p.x, p.y, p.z, (r.nextDouble() - 0.5) * 0.05, 0.05, (r.nextDouble() - 0.5) * 0.05, 0xFF7A30, 0.6f, 10);
            Vfx.smoke(p.x, p.y + 0.3, p.z, 0, 0.02, 0, 0x403038, 0.8f, 30);
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            Vec3 p = at(time);
            Vec3 tail = at(Math.max(0f, time - life * 0.35f));
            d.beam(tail.x, tail.y, tail.z, p.x, p.y, p.z, 0.9f, 0xFF7A30, 0xFFE8B0, 0.1f, 1f);
            d.flare(p.x, p.y, p.z, 1.6f, 0xFF9A50, 1f);
            d.glow(p.x, p.y, p.z, 0.7f, 0xFFFFFF, 0.8f);
        }

        @Override
        public void renderSoft(Draw d) {
            Vec3 p = at(time(d.partialTick));
            d.puff(p.x, p.y, p.z, 0.8f, 0x5A4A4A, 0x2A2026, 0.95f);
        }
    }

    /** Lingkaran mahkota pikiran di atas kepala (budak Belenggu Pikiran / korban Badai Pikiran). */
    static final class Halo extends Effect {
        private final Entity e;
        private final int rgb;

        Halo(Entity e, int rgb, int life) {
            super(life);
            this.e = e;
            this.rgb = rgb;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return e.isAlive() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 6f, 10f);
            Vec3 p = e.getPosition(d.partialTick).add(0, e.getBbHeight() + 0.35, 0);
            double rr = 0.42 + 0.03 * Math.sin(time * 0.3);
            d.ring(p.x, p.y, p.z, 0, 1, 0, rr, 0.07, rgb, a, 0.15f, null);
            for (int k = 0; k < 3; k++) {
                double ang = time * 0.15 + k * Math.PI * 2.0 / 3.0;
                d.glint(p.x + Math.cos(ang) * rr, p.y, p.z + Math.sin(ang) * rr, 0.13f, time * 0.2f, rgb, a);
            }
            d.glow(p.x, p.y, p.z, 0.5f, rgb, 0.25f * a);
        }
    }

    /** Pita kenyataan yang membelit badan sasaran, berputar & makin rapat sampai meledak. */
    static final class Ribbons extends Effect {
        private final Entity e;
        private final int rgb;

        Ribbons(Entity e, int rgb, int life) {
            super(life);
            this.e = e;
            this.rgb = rgb;
        }

        @Override
        public boolean tick(ClientLevel level) {
            return e.isAlive() && super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 4f, 4f);
            Vec3 base = e.getPosition(d.partialTick);
            double h = e.getBbHeight();
            double w = e.getBbWidth() * 0.75 + 0.25;
            double tight = 1.05 - 0.25 * progress(d.partialTick);
            int n = 14;
            for (int k = 0; k < 4; k++) {
                float[] pts = new float[n * 3];
                for (int i = 0; i < n; i++) {
                    double f = i / (double) (n - 1);
                    double ang = f * Math.PI * 3.0 + k * Math.PI / 2.0 + time * 0.25;
                    double rr = w * tight * (0.9 + 0.1 * Math.sin(time * 0.5 + i));
                    pts[i * 3] = (float) (base.x + Math.cos(ang) * rr);
                    pts[i * 3 + 1] = (float) (base.y + f * h);
                    pts[i * 3 + 2] = (float) (base.z + Math.sin(ang) * rr);
                }
                d.polyline(pts, n, 0.08f, 0.08f, rgb, hot(rgb), a * 0.9f, a * 0.9f);
            }
        }
    }

    /** Kubah realitas: kulit merah yang berdenyut, busur pita berputar di dalamnya, dan kotak glitch yang berkedip. */
    static final class RealityStorm extends Effect {
        private final Vec3 c;
        private final double r;

        RealityStorm(Vec3 c, double r, int life) {
            super(life);
            this.c = c;
            this.r = r;
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource rnd = level.random;
            if (age % 2 == 0) {
                double a = rnd.nextDouble() * Math.PI * 2.0, rr = rnd.nextDouble() * r;
                Vfx.mote(c.x + Math.cos(a) * rr, c.y + rnd.nextDouble() * 2.0, c.z + Math.sin(a) * rr, 0, 0.05, 0,
                        rnd.nextBoolean() ? STONE[3] : 0x200008, 0.08f, 20);
            }
            LocalPlayer me = Minecraft.getInstance().player;
            if (me != null && me.position().distanceTo(c) < r) {
                Vfx.worldTint(0x501018, 0.18f);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 6f, 12f);
            d.shell(c.x, c.y, c.z, r, STONE[3], 0.35f * a * (0.85f + 0.15f * (float) Math.sin(time * 0.5)), 3.0, 0.5);
            d.ring(c.x, c.y + 0.05, c.z, 0, 1, 0, r, 0.25, STONE[3], 0.8f * a, 0.06f, null);
            int n = 10;
            for (int k = 0; k < 6; k++) {
                float[] pts = new float[n * 3];
                double tilt = k * 0.5 + time * 0.03;
                for (int i = 0; i < n; i++) {
                    double f = i / (double) (n - 1);
                    double ang = f * Math.PI * 1.2 + k * Math.PI / 3.0 + time * 0.06 * (k % 2 == 0 ? 1 : -1);
                    double y = 0.6 + (r * 0.45) * Math.sin(Math.PI * f) * (0.6 + 0.4 * Math.sin(tilt));
                    double rr = r * (0.55 + 0.25 * Math.sin(f * Math.PI));
                    pts[i * 3] = (float) (c.x + Math.cos(ang) * rr);
                    pts[i * 3 + 1] = (float) (c.y + y);
                    pts[i * 3 + 2] = (float) (c.z + Math.sin(ang) * rr);
                }
                d.polyline(pts, n, 0.12f, 0.12f, STONE[3], 0xFFD0D0, a * 0.6f, a * 0.6f);
            }
            long seed = (long) (time / 2f);
            RandomSource g = RandomSource.create(seed * 7919L + 13L);
            for (int i = 0; i < 10; i++) {   // kotak glitch: berganti tiap 2 tick
                double ang = g.nextDouble() * Math.PI * 2.0, el = g.nextDouble() * Math.PI * 0.45;
                double x = c.x + Math.cos(ang) * Math.cos(el) * r, y = c.y + Math.sin(el) * r, z = c.z + Math.sin(ang) * Math.cos(el) * r;
                double s = 0.25 + g.nextDouble() * 0.5;
                d.quad(x - s, y - s, z, x + s, y - s, z, x + s, y + s, z, x - s, y + s, z,
                        g.nextBoolean() ? STONE[3] : 0xFFFFFF, a * 0.5f, a * 0.5f, a * 0.5f, a * 0.5f);
            }
        }
    }

    /** Cincin jam di sekeliling badan: dua belas tanda & jarum yang berputar mundur (Putar Balik). */
    static final class ClockRing extends Effect {
        private final Entity e;
        private final int rgb;

        ClockRing(Entity e, int rgb, int life) {
            super(life);
            this.e = e;
            this.rgb = rgb;
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 3f, 6f);
            Vec3 c = e.getPosition(d.partialTick).add(0, e.getBbHeight() * 0.55, 0);
            double rr = 1.3;
            d.ring(c.x, c.y, c.z, 0, 1, 0, rr, 0.08, rgb, a, 0.08f, null);
            d.ring(c.x, c.y, c.z, 0, 1, 0, rr * 0.7, 0.04, hot(rgb), a * 0.8f, 0f, null);
            for (int k = 0; k < 12; k++) {
                double ang = k * Math.PI / 6.0;
                double cs = Math.cos(ang), sn = Math.sin(ang);
                d.line(c.x + cs * rr * 0.86, c.y, c.z + sn * rr * 0.86, c.x + cs * rr * 1.08, c.y, c.z + sn * rr * 1.08,
                        0.05f, 0.05f, hot(rgb), a, a);
            }
            double hand = -time * 0.6;   // mundur
            d.line(c.x, c.y, c.z, c.x + Math.cos(hand) * rr * 0.9, c.y, c.z + Math.sin(hand) * rr * 0.9, 0.08f, 0.04f,
                    0xFFFFFF, a, a);
        }
    }

    /** Kubah waktu: kulit hijau, jam raksasa yang berhenti di tanah, butiran yang membeku di udara. */
    static final class TimeDome extends Effect {
        private final Vec3 c;
        private final double r;

        TimeDome(Vec3 c, double r, int life) {
            super(life);
            this.c = c;
            this.r = r;
            RandomSource rnd = Vfx.random();
            for (int i = 0, n = Vfx.count(40); i < n; i++) {   // butiran yang membeku di udara
                double a = rnd.nextDouble() * Math.PI * 2.0, rr = Math.sqrt(rnd.nextDouble()) * r * 0.9;
                Vfx.mote(c.x + Math.cos(a) * rr, c.y + 0.3 + rnd.nextDouble() * r * 0.5, c.z + Math.sin(a) * rr, 0, 0, 0,
                        rnd.nextBoolean() ? STONE[4] : 0xD8FFE0, 0.06f, life);
            }
        }

        @Override
        public boolean tick(ClientLevel level) {
            LocalPlayer me = Minecraft.getInstance().player;
            if (me != null && me.position().distanceTo(c) < r) {
                Vfx.worldTint(0x10301A, 0.22f);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 5f, 10f);
            d.shell(c.x, c.y, c.z, r, STONE[4], 0.4f * a, 3.0, 0.5);
            Vec3 g = c.add(0, 0.06, 0);
            d.ring(g.x, g.y, g.z, 0, 1, 0, r * 0.95, 0.22, STONE[4], 0.8f * a, 0.05f, null);
            d.ring(g.x, g.y, g.z, 0, 1, 0, r * 0.7, 0.08, hot(STONE[4]), 0.6f * a, 0f, null);
            for (int k = 0; k < 12; k++) {
                double ang = k * Math.PI / 6.0, cs = Math.cos(ang), sn = Math.sin(ang);
                d.line(g.x + cs * r * 0.78, g.y, g.z + sn * r * 0.78, g.x + cs * r * 0.92, g.y, g.z + sn * r * 0.92,
                        0.16f, 0.16f, hot(STONE[4]), a, a);
            }
            d.line(g.x, g.y, g.z, g.x + r * 0.6, g.y, g.z, 0.22f, 0.12f, 0xFFFFFF, a, a);          // jarum yang berhenti
            d.line(g.x, g.y, g.z, g.x, g.y, g.z - r * 0.4, 0.26f, 0.14f, 0xFFFFFF, a, a);
        }
    }

    /** Tali jiwa: pita bergelombang dari dada makhluk ke tangan Gauntlet, butiran jiwa mengalir di sepanjangnya. */
    static final class SoulStream extends Effect {
        private final Entity from;
        private final Lightning.Anchor to;
        private final int rgb, delay, len;
        private final float seed = Vfx.random().nextFloat() * 10f;

        SoulStream(Entity from, Lightning.Anchor to, int rgb, int delay, int len) {
            super(delay + len + 6);
            this.from = from;
            this.to = to;
            this.rgb = rgb;
            this.delay = delay;
            this.len = len;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (age >= delay && age < delay + len && age % 2 == 0 && from.isAlive()) {
                double f = level.random.nextDouble();
                Vec3 s = chest(from), e = to.at(1f);
                Vec3 p = s.lerp(e, f);
                Vec3 dir = e.subtract(s).normalize().scale(0.25);
                Vfx.mote(p.x, p.y, p.z, dir.x, dir.y, dir.z, hot(rgb), 0.07f, 8);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick) - delay;
            if (time < 0f || !from.isAlive()) {
                return;
            }
            float a = fade(time, len + 6, 4f, 6f);
            Vec3 s = from.getPosition(d.partialTick).add(0, from.getBbHeight() * 0.62, 0);
            Vec3 e = to.at(d.partialTick);
            Vec3 dir = e.subtract(s);
            Vec3 side = dir.cross(UP);
            side = side.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : side.normalize();
            int n = 16;
            float[] pts = new float[n * 3];
            for (int i = 0; i < n; i++) {
                double f = i / (double) (n - 1);
                double wave = Math.sin(Math.PI * f) * 0.28 * Math.sin(time * 0.6 + f * 8.0 + seed);
                double lift = Math.sin(Math.PI * f) * 0.4;
                pts[i * 3] = (float) (s.x + dir.x * f + side.x * wave);
                pts[i * 3 + 1] = (float) (s.y + dir.y * f + lift);
                pts[i * 3 + 2] = (float) (s.z + dir.z * f + side.z * wave);
            }
            d.polyline(pts, n, 0.14f, 0.05f, rgb, hot(rgb), a * 0.8f, a);
        }
    }

    /** Gelombang Jentikan: cincin emas-putih yang menyapu sejauh 48 blok, dinding debu tipis di belakangnya. */
    static final class SnapWave extends Effect {
        private final Vec3 c;
        private final double r;

        SnapWave(Vec3 c, double r, int life) {
            super(life);
            this.c = c;
            this.r = r;
        }

        private double front(float pt) {
            float t = progress(pt);
            return r * (1.0 - Math.pow(1.0 - t, 2.2));
        }

        @Override
        public boolean tick(ClientLevel level) {
            RandomSource rnd = level.random;
            double f = front(1f);
            for (int i = 0, n = Vfx.count(10); i < n; i++) {
                double a = rnd.nextDouble() * Math.PI * 2.0;
                Vfx.mote(c.x + Math.cos(a) * f, c.y + rnd.nextDouble() * 1.6, c.z + Math.sin(a) * f, Math.cos(a) * 0.05, 0.03,
                        Math.sin(a) * 0.05, GOLD, 0.09f, 18);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            float t = progress(d.partialTick);
            float a = (float) Math.pow(1f - t, 1.3);
            double f = front(d.partialTick);
            d.ring(c.x, c.y, c.z, 0, 1, 0, f, 0.6 + f * 0.03, GOLD, a, 0.05f, null);
            d.ring(c.x, c.y + 0.4, c.z, 0, 1, 0, f * 0.985, 0.25, 0xFFFFFF, a * 0.8f, 0f, null);
        }

        @Override
        public void renderSoft(Draw d) {
            float t = progress(d.partialTick);
            d.ring(c.x, c.y + 0.3, c.z, 0, 1, 0, front(d.partialTick) * 0.96, 1.6, 0xB09070, 0.35f * (1f - t), 0f, null);
        }
    }

    /** Sinyal Batu: panah cahaya warna batu dari dada ke arah kuilnya, dengan denyut yang meluncur. */
    static final class SignalArrow extends Effect {
        private final Vec3 c, dir;
        private final int rgb;

        SignalArrow(Vec3 c, Vec3 dir, int rgb, int life) {
            super(life);
            this.c = c;
            this.dir = dir;
            this.rgb = rgb;
        }

        @Override
        public void renderGlow(Draw d) {
            float time = time(d.partialTick);
            float a = fade(time, life, 4f, 12f);
            Vec3 s = c.add(dir.scale(0.8)), e = c.add(dir.scale(8.0));
            d.beam(s.x, s.y, s.z, e.x, e.y, e.z, 0.12f, rgb, 0xFFFFFF, a * 0.3f, a);
            Vec3 side = new Vec3(-dir.z, 0, dir.x);
            for (int k = 0; k < 3; k++) {
                double along = ((time * 0.3 + k * 2.4) % 7.2) + 0.8;
                Vec3 tip = c.add(dir.scale(along));
                Vec3 l = tip.subtract(dir.scale(0.5)).add(side.scale(0.35)), rr = tip.subtract(dir.scale(0.5)).subtract(side.scale(0.35));
                d.line(l.x, l.y, l.z, tip.x, tip.y, tip.z, 0.08f, 0.08f, rgb, a, a);
                d.line(rr.x, rr.y, rr.z, tip.x, tip.y, tip.z, 0.08f, 0.08f, rgb, a, a);
            }
            d.flare(e.x, e.y, e.z, 0.6f, rgb, a);
        }
    }
}
