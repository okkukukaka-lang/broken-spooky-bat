package com.shazammod.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.AksaraSkills;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMod;
import com.shazammod.client.fx.AksaraFx;
import com.shazammod.client.fx.ShazamRage;
import com.shazammod.client.vfx.Draw;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/**
 * 0.51 PRALAYA (orisinal, robot/AI): seluruh tubuh pemain jadi android berangka logam (tekstur 256 px di tata letak UV
 * kulit, dibuat tools/textures/aksara_textures.py):
 *
 *   1) rangka gunmetal & pelat bersudut (bagian dasar model);
 *   2) panel luar, sabuk & sambungan (lapisan luar; lapisan luar kulit asli disembunyikan);
 *   3) sirkuit yang menyala & berdenyut mengikuti denyut drone: merah, putih-panas saat Singularitas, dan sejak 0.52
 *      ikut warna INTI DAYA yang sedang dipakai skill (Plasma merah, Graviton ungu, Siber sian, ...);
 *   4) bentuk 3D dari AksaraGeo: antena, visor, reaktor pusat di dada, pelat bahu, enam kristal INTI DAYA di bahu,
 *      lengan bawah & lutut (0.53), dan rombongan drone. Titik inti, reaktor & drone yang digambar dikirim ke AksaraFx
 *      (aliran daya inti -> reaktor & pendar yang pas di pose apa pun).
 *
 * 0.55 ARMOR YANG DIPANGGIL: selama dipanggil (sebelum server menyatakan berubah) & dilepas, cuma bagian armor yang
 * sudah menempel / belum terlepas yang digambar di atas badan manusianya (AksaraFx.assembled), tanpa bentuk 3D. Fase
 * armor & inti yang terpasang (status pemain) menentukan tampilannya (lihat AksaraGeo).
 */
public class AksaraLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ResourceLocation SKIN = ShazamMod.id("textures/entity/aksara/skin.png");
    public static final ResourceLocation GLOW = ShazamMod.id("textures/entity/aksara/glow.png");
    private static final int FULLBRIGHT = 15728880;
    private static final float ARM_INFLATE = 1.04f;

    public AksaraLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    public static boolean active(AbstractClientPlayer player) {
        return !player.isInvisible() && ShazamClientState.isTransformed(player.getId())
                && ShazamClientState.isAksara(player.getId());
    }

    /** 0.55 Bagian armor yang digambar (bit AksaraFx.PART_*): semua saat berarmor, sebagian saat dipanggil / dilepas. */
    private static int parts(AbstractClientPlayer player, float pt) {
        if (player.isInvisible()) {
            return 0;
        }
        if (active(player)) {
            return AksaraFx.ALL_PARTS;
        }
        return ShazamClientState.isAksara(player.getId()) && !ShazamClientState.isTransformed(player.getId())
                ? AksaraFx.assembled(player, pt) : 0;
    }

    /** RenderPlayerEvent.Pre: lapisan luar kulit asli disembunyikan (diganti lapisan luar Aksara di render()). */
    public static void pre(AbstractClientPlayer player, PlayerModel<AbstractClientPlayer> m, float pt) {
        try {
            int parts = parts(player, pt);
            if (parts == 0) {
                return;
            }
            if (has(parts, AksaraFx.PART_HEAD)) {
                m.hat.visible = false;
            }
            if (has(parts, AksaraFx.PART_BODY)) {
                m.jacket.visible = false;
            }
            if (has(parts, AksaraFx.PART_ARM_R)) {
                m.rightSleeve.visible = false;
            }
            if (has(parts, AksaraFx.PART_ARM_L)) {
                m.leftSleeve.visible = false;
            }
            if (has(parts, AksaraFx.PART_LEG_R)) {
                m.rightPants.visible = false;
            }
            if (has(parts, AksaraFx.PART_LEG_L)) {
                m.leftPants.visible = false;
            }
        } catch (Throwable ignored) {
            // lapisan kostum nggak boleh bikin game crash
        }
    }

    private static boolean has(int parts, int part) {
        return (parts & (1 << part)) != 0;
    }

    private static AksaraGeo.Look look(AbstractClientPlayer p, float pt) {
        AksaraGeo.Look look = new AksaraGeo.Look();
        look.age = p.tickCount + pt + p.getId() * 13f;
        look.spin = AksaraFx.spin(p, pt);
        look.purna = Mth.clamp(ShazamRage.glow(p, pt), 0f, 1f);
        look.flare = AksaraFx.flare(p, pt);
        look.discsOut = AksaraFx.discsOut(p, pt);
        for (int i = 0; i < 6; i++) {
            look.disc[i] = AksaraFx.discGlow(p, i, pt);
        }
        look.active = AksaraFx.activeCore(p);
        look.activeK = look.active >= 0 ? AksaraFx.activeWeight(p, pt) : 0f;
        look.phase = AksaraFx.phaseOf(p);   // 0.55
        look.cores = AksaraFx.coresOf(p);
        look.thrust = ShazamClientState.isFlying(p.getId()) ? 1f : 0f;
        return look;
    }

    /** 0.52 Warna sirkuit: merah (putih-panas saat Singularitas), condong ke warna inti daya yang sedang dipakai skill. */
    private static int tone(AksaraGeo.Look look) {
        int base = look.purna > 0.3f ? 0xFFF0EC : 0xFF2A32;
        if (look.active < 0 || look.active >= 6 || look.activeK <= 0f) {
            return base;
        }
        return Draw.mix(base, AksaraSkills.RGB[look.active], 0.8 * look.activeK);
    }

    /** Terang sirkuit di kulit: denyut drone + Singularitas + kilatan skill + inti yang dipakai; penuh sesaat sesudah berubah. */
    private static float glow(AbstractClientPlayer p, AksaraGeo.Look look, float pt) {
        float pulse = AksaraFx.pulse(p, pt);
        float k = (0.42f + 0.25f * pulse + 0.45f * look.purna + 0.5f * look.flare + 0.25f * look.activeK)
                * (look.phase <= 1 ? 0.62f : look.phase >= 3 ? 1.12f : 1f);   // 0.55 sirkuit ikut fase armor
        float reveal = ShazamCape.revealTime(p, pt);
        if (reveal >= 0f && reveal < 16f) {
            k = Math.max(k, 1.3f * (1f - reveal / 16f));
        }
        return k;
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, float limbSwing,
                       float limbAmount, float pt, float ageInTicks, float netHeadYaw, float headPitch) {
        try {
            int parts = parts(p, pt);
            if (parts == 0) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = getParentModel();
            int overlay = LivingEntityRenderer.getOverlayCoords(p, 0f);
            AksaraGeo.Look look = look(p, pt);
            if (parts != AksaraFx.ALL_PARTS) {   // 0.55 armor sedang dipanggil / dilepas
                renderPartial(m, ps, buffers, light, overlay, look, parts, AksaraFx.lockFlash(p, pt));
                return;
            }
            // 1) tubuh grafit & topeng, lalu 2) kain, sabuk, kalung di lapisan luar
            VertexConsumer skin = buffers.getBuffer(RenderType.entityCutoutNoCull(SKIN));
            base(m.head, ps, skin, light, overlay);
            for (ModelPart[] pair : body(m)) {
                base(pair[1], ps, skin, light, overlay);
            }
            shell(m.hat, m.head, ps, skin, light, overlay);
            for (ModelPart[] pair : body(m)) {
                shell(pair[0], pair[1], ps, skin, light, overlay);
            }
            // 3) sirkuit yang menyala (merah / putih-panas / warna inti yang dipakai)
            float glow = glow(p, look, pt);
            if (glow > 0.02f) {
                VertexConsumer lines = buffers.getBuffer(RenderType.eyes(GLOW));
                int c = color(tone(look), glow);
                glowPart(m.head, ps, lines, c);
                for (ModelPart[] pair : body(m)) {
                    glowPart(pair[1], ps, lines, c);
                }
            }
            // 4) antena, visor, reaktor, pelat, dan rombongan drone berkristal inti
            AksaraGeo.render(m.head, m.body, m.rightArm, m.leftArm, m.rightLeg, m.leftLeg, ps, buffers, light, overlay, look);
            if (look.pointsValid) {
                AksaraFx.recordPoints(p, look.points, pt);
            }
        } catch (Throwable ignored) {
            // lapisan kostum nggak boleh bikin game crash
        }
    }

    /**
     * 0.55 Sebagian armor (dipanggil / dilepas): bagian yang menempel digambar penuh (kulit, lapisan luar, sirkuit),
     * sirkuitnya menyala terang sesaat setelah bagian itu mengunci.
     */
    private static void renderPartial(PlayerModel<AbstractClientPlayer> m, PoseStack ps, MultiBufferSource buffers,
                                      int light, int overlay, AksaraGeo.Look look, int parts, float flash) {
        ModelPart[][] all = {{m.hat, m.head}, {m.jacket, m.body}, {m.rightSleeve, m.rightArm}, {m.leftSleeve, m.leftArm},
                {m.rightPants, m.rightLeg}, {m.leftPants, m.leftLeg}};
        VertexConsumer skin = buffers.getBuffer(RenderType.entityCutoutNoCull(SKIN));
        for (int i = 0; i < all.length; i++) {
            if (has(parts, i)) {
                base(all[i][1], ps, skin, light, overlay);
                shell(all[i][0], all[i][1], ps, skin, light, overlay);
            }
        }
        VertexConsumer lines = buffers.getBuffer(RenderType.eyes(GLOW));
        int c = color(tone(look), Math.max(0.3f, flash) * (look.phase <= 1 ? 0.7f : 1f));
        for (int i = 0; i < all.length; i++) {
            if (has(parts, i)) {
                glowPart(all[i][1], ps, lines, c);
            }
        }
    }

    /** Tangan orang pertama: lengan grafit bergurat prada, kelat bahu, gelang, pelat bahu. */
    public static void firstPersonArm(PoseStack ps, MultiBufferSource buffers, int light, AbstractClientPlayer p, HumanoidArm arm) {
        try {
            if (!active(p)) {
                return;
            }
            Minecraft mc = Minecraft.getInstance();
            if (!(mc.getEntityRenderDispatcher().getRenderer(p) instanceof PlayerRenderer renderer)) {
                return;
            }
            PlayerModel<AbstractClientPlayer> m = renderer.getModel();
            boolean right = arm == HumanoidArm.RIGHT;
            ModelPart base = right ? m.rightArm : m.leftArm;
            ModelPart sleeve = right ? m.rightSleeve : m.leftSleeve;
            m.attackTime = 0f;
            m.crouching = false;
            m.swimAmount = 0f;
            m.setupAnim(p, 0f, 0f, 0f, 0f, 0f);
            base.xRot = 0f;
            sleeve.xRot = 0f;
            float pt = mc.getTimer().getGameTimeDeltaPartialTick(true);
            AksaraGeo.Look look = look(p, pt);
            VertexConsumer skin = buffers.getBuffer(RenderType.entityCutoutNoCull(SKIN));
            scaled(base, ps, skin, light, 0xFFFFFFFF, ARM_INFLATE);
            scaled(sleeve, ps, skin, light, 0xFFFFFFFF, ARM_INFLATE * 1.02f);
            scaled(base, ps, buffers.getBuffer(RenderType.eyes(GLOW)), FULLBRIGHT, color(tone(look), glow(p, look, pt)),
                    ARM_INFLATE);
            base.xScale = ARM_INFLATE;
            base.yScale = ARM_INFLATE;
            base.zScale = ARM_INFLATE;
            AksaraGeo.renderArm(base, !right, ps, buffers, light, look);
            base.xScale = 1f;
            base.yScale = 1f;
            base.zScale = 1f;
        } catch (Throwable ignored) {
            // tangan orang pertama nggak boleh bikin game crash
        }
    }

    /** Badan, lengan, kaki: {lapisan luar, bagian dasar}. */
    private static ModelPart[][] body(PlayerModel<AbstractClientPlayer> m) {
        return new ModelPart[][] {{m.jacket, m.body}, {m.rightSleeve, m.rightArm}, {m.leftSleeve, m.leftArm},
                {m.rightPants, m.rightLeg}, {m.leftPants, m.leftLeg}};
    }

    private static void base(ModelPart part, PoseStack ps, VertexConsumer vc, int light, int overlay) {
        if (part != null && part.visible) {
            part.render(ps, vc, light, overlay, 0xFFFFFFFF);
        }
    }

    private static void glowPart(ModelPart part, PoseStack ps, VertexConsumer vc, int color) {
        if (part != null && part.visible) {
            part.render(ps, vc, FULLBRIGHT, OverlayTexture.NO_OVERLAY, color);
        }
    }

    /** Lapisan luar dipaksa terlihat (di pre() disembunyikan supaya kulit asli pemain nggak ikut digambar). */
    private static void shell(ModelPart outer, ModelPart base, PoseStack ps, VertexConsumer vc, int light, int overlay) {
        if (outer == null || base == null || !base.visible) {
            return;
        }
        boolean visible = outer.visible;
        outer.visible = true;
        outer.render(ps, vc, light, overlay, 0xFFFFFFFF);
        outer.visible = visible;
    }

    private static void scaled(ModelPart part, PoseStack ps, VertexConsumer vc, int light, int color, float scale) {
        if (part == null) {
            return;
        }
        boolean visible = part.visible;
        part.visible = true;
        part.xScale = scale;
        part.yScale = scale;
        part.zScale = scale;
        part.render(ps, vc, light, OverlayTexture.NO_OVERLAY, color);
        part.xScale = 1f;
        part.yScale = 1f;
        part.zScale = 1f;
        part.visible = visible;
    }

    /** Warna cahaya aditif: kekuatan dikalikan ke RGB (jenis render "eyes" mengabaikan alpha). */
    private static int color(int rgb, float k) {
        k = Mth.clamp(k, 0f, 1f);
        int r = (int) (((rgb >> 16) & 255) * k);
        int g = (int) (((rgb >> 8) & 255) * k);
        int b = (int) ((rgb & 255) * k);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
