package com.shazammod.client.render;

import java.util.ArrayList;
import java.util.List;

import com.shazammod.kaldera.KalderaBody;

/**
 * 0.73 Bentuk 3D KALDERA, Titan Radiasi (rancangan orisinal; 0.73.1 tema radiasi), dibangun sekali dari rumus (tanpa file
 * model):
 *
 *   badan   : bongkah batu bijih uranium raksasa berlapis-lapis dengan punuk batu di atas bahu & pinggul, lempeng strata di
 *             sisinya, dan tiang-tiang batu kecil yang menggantung di bawah perutnya
 *   kristal : gugus kristal uranium segi enam yang menyala hijau, tumbuh dari bahu, pinggul, sisi badan, lereng depan &
 *             belakang gunungnya, dan dari pelipis kepalanya (bukan di garis punggung)
 *   gunung  : lereng bergigi di punggungnya sampai bibir kawah, mahkota duri batu gelap di sekeliling kawah, kolam inti
 *             radioaktif di dasarnya, tiga lubang uap, dan lima aliran cairan radioaktif yang menuruni lerengnya
 *   kepala  : haluan batu bertingkat tiga (seperti lapisan tebing), alis batu, jambul tiang batu, tiga pasang mata hijau,
 *             dan celah menyala di antara langit-langit & rahang bawah yang membuka saat meraung
 *   kaki    : berkas tiang batu segi enam (paha & betis), sendi lutut dari inti yang berpijar, telapak lebar dari tiang batu
 *             pendek (dibangun ulang tiap gambar mengikuti pinggul, lutut, & telapaknya)
 *
 * Lima lapisan: batu (padat, bertekstur), kristal (padat), urat (cahaya, tekstur retakan di atas batu yang sama), inti
 * (cahaya terang: kolam, aliran, mata, mulut, sendi), dan kilau kristal (cahaya di atas kristal). Kelas ini cuma hitungan
 * (tanpa kelas Minecraft), jadi bisa dipakai alat pratinjau juga; KalderaRenderer yang meneruskan titiknya ke Minecraft.
 */
public final class KalderaModel {
    private KalderaModel() {}

    public static final int ROCK = 0, VEIN = 1, CORE = 2, CRYSTAL = 3, SHINE = 4, LAYERS = 5;
    public static final int Z_BODY = 0, Z_CALDERA = 1, Z_STREAM = 2, Z_FACE = 3, Z_LEG = 4, Z_JOINT = 5, Z_CRYSTAL = 6, ZONES = 7;
    static final float TILE = 8f;        // tekstur batu & urat berulang tiap 8 blok
    static final float CORE_TILE = 5f;
    static final float SHINE_FLOW = -0.35f; // kilau kristal merambat pelan dari pangkal ke ujungnya
    private static final float BY = KalderaBody.BODY_Y, BZ = KalderaBody.BODY_Z;
    private static final float RX = KalderaBody.BODY_RX, RY = KalderaBody.BODY_RY, RZ = KalderaBody.BODY_RZ, RY_TOP = 9f;
    private static final int STRIDE = 11; // x y z u v nx ny nz tint zone flow

    /** Penerima titik: posisi & normal di ruang lokal entity (belum diputar menurut arah hadapnya). */
    public interface Sink {
        void vertex(int layer, float x, float y, float z, float u, float v, float nx, float ny, float nz, float tint, int zone);
    }

    /** Tinggi tanah (ruang lokal) di bawah telapak leg yang sedang menapak di (lx, lz). */
    public interface Ground {
        float at(int leg, float lx, float lz);
    }

    // ------------------------------------------------------------------ jaring statis

    static final class Mesh {
        float[] d = new float[STRIDE * 4 * 256];
        int n;

        void put(float x, float y, float z, float u, float v, float nx, float ny, float nz, float tint, int zone, float flow) {
            if (n + STRIDE > d.length) {
                float[] g = new float[d.length * 2];
                System.arraycopy(d, 0, g, 0, n);
                d = g;
            }
            d[n++] = x; d[n++] = y; d[n++] = z; d[n++] = u; d[n++] = v;
            d[n++] = nx; d[n++] = ny; d[n++] = nz; d[n++] = tint; d[n++] = zone; d[n++] = flow;
        }

        int vertices() {
            return n / STRIDE;
        }
    }

    /** Satu bagian bergerak (badan / kepala / rahang): lima lapisan jaring di ruang bagiannya sendiri. */
    static final class Group {
        final Mesh[] layer = {new Mesh(), new Mesh(), new Mesh(), new Mesh(), new Mesh()};
    }

    private static Group body, head, jaw;
    private static LegKit[] kits;

    private static synchronized void build() {
        if (body != null) {
            return;
        }
        Group b = new Group(), h = new Group(), j = new Group();
        buildBody(new B(b, 0x51A7));
        buildHead(new B(h, 0x7E11));
        buildJaw(new B(j, 0x33C9));
        scale(h, KalderaBody.HEAD_SCALE);
        scale(j, KalderaBody.HEAD_SCALE);
        LegKit[] k = new LegKit[4];
        for (int i = 0; i < 4; i++) {
            k[i] = new LegKit(0x1000 + i * 977);
        }
        kits = k;
        head = h;
        jaw = j;
        body = b;
    }

    private static void scale(Group g, float k) {
        for (Mesh m : g.layer) {
            for (int i = 0; i < m.n; i += STRIDE) {
                m.d[i] *= k;
                m.d[i + 1] *= k;
                m.d[i + 2] *= k;
            }
        }
    }

    /** Jumlah titik semua jaring statis (buat uji). */
    public static int staticVertices() {
        build();
        int n = 0;
        for (Group g : new Group[]{body, head, jaw}) {
            for (Mesh m : g.layer) {
                n += m.vertices();
            }
        }
        return n;
    }

    // ------------------------------------------------------------------ derau

    static float hash(int x, int y, int z, int seed) {
        int h = x * 374761393 + y * 668265263 + z * 1274126177 + seed * 144665;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFFFF) / (float) 0x1000000;
    }

    static float noise(float x, float y, float z, int seed) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y), iz = (int) Math.floor(z);
        float fx = x - ix, fy = y - iy, fz = z - iz;
        fx = fx * fx * (3f - 2f * fx);
        fy = fy * fy * (3f - 2f * fy);
        fz = fz * fz * (3f - 2f * fz);
        float a = lerp(fx, hash(ix, iy, iz, seed), hash(ix + 1, iy, iz, seed));
        float b = lerp(fx, hash(ix, iy + 1, iz, seed), hash(ix + 1, iy + 1, iz, seed));
        float c = lerp(fx, hash(ix, iy, iz + 1, seed), hash(ix + 1, iy, iz + 1, seed));
        float e = lerp(fx, hash(ix, iy + 1, iz + 1, seed), hash(ix + 1, iy + 1, iz + 1, seed));
        return lerp(fz, lerp(fy, a, b), lerp(fy, c, e));
    }

    /** Derau berlapis, -1..1. */
    static float fbm(float x, float y, float z, int seed) {
        return (noise(x, y, z, seed) * 0.6f + noise(x * 2.1f, y * 2.1f, z * 2.1f, seed + 7) * 0.28f
                + noise(x * 4.3f, y * 4.3f, z * 4.3f, seed + 13) * 0.12f) * 2f - 1f;
    }

    /** Titik permukaan bongkah lonjong bergerigi di sudut lintang th & bujur ph, ditambah lift ke luar. */
    static float[] blobPoint(float cx, float cy, float cz, float rx, float ry, float rz, float amp, float freq, float strata, int nseed,
                             float th, float ph, float lift) {
        return blobPoint(cx, cy, cz, rx, ry, ry, rz, amp, freq, strata, nseed, th, ph, lift);
    }

    /** Sama, dengan jari-jari atas (ryTop) & bawah (ry) yang berbeda. */
    static float[] blobPoint(float cx, float cy, float cz, float rx, float ry, float ryTop, float rz, float amp, float freq, float strata,
                             int nseed, float th, float ph, float lift) {
        float st = (float) Math.sin(th), ct = (float) Math.cos(th);
        float dx = st * (float) Math.cos(ph), dy = ct, dz = st * (float) Math.sin(ph);
        float r = 1f + amp * fbm(dx * freq + 11f, dy * freq + 3f, dz * freq + 5f, nseed) + strata * (float) Math.sin(dy * 9.0 + dx * 1.3);
        float lx = dx * rx * r, ly = dy * (dy > 0f ? ryTop : ry) * r, lz = dz * rz * r;
        float ll = (float) Math.sqrt(lx * lx + ly * ly + lz * lz) + 1.0E-4f;
        return new float[]{cx + lx + lx / ll * lift, cy + ly + ly / ll * lift, cz + lz + lz / ll * lift};
    }

    static float lerp(float t, float a, float b) {
        return a + (b - a) * t;
    }

    static float smooth(float a, float b, float t) {
        float k = Math.max(0f, Math.min(1f, (t - a) / (b - a)));
        return k * k * (3f - 2f * k);
    }

    // ------------------------------------------------------------------ pembangun

    /** Pembangun jaring statis: quad dengan normal yang dipaksa keluar, UV dari proyeksi tiga arah. */
    static final class B {
        final Group g;
        int seed;
        int count;

        B(Group g, int seed) {
            this.g = g;
            this.seed = seed;
        }

        float rnd() {
            return hash(count++, seed, 91, 3);
        }

        float rnd(float a, float b) {
            return a + (b - a) * rnd();
        }

        /**
         * Quad a-b-c-d. ref = titik di dalam bentuknya (normal dibuat menjauhinya). vein = ikut lapisan urat yang menyala.
         * shade = terang batu (0..1).
         */
        void quad(int layer, float[] a, float[] b, float[] c, float[] e, float rx, float ry, float rz, float shade, int zone,
                  boolean vein) {
            float acx = c[0] - a[0], acy = c[1] - a[1], acz = c[2] - a[2];
            float bdx = e[0] - b[0], bdy = e[1] - b[1], bdz = e[2] - b[2];
            float nx = acy * bdz - acz * bdy, ny = acz * bdx - acx * bdz, nz = acx * bdy - acy * bdx;
            float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (nl < 1.0E-6f) {
                return;
            }
            nx /= nl;
            ny /= nl;
            nz /= nl;
            float mx = (a[0] + b[0] + c[0] + e[0]) * 0.25f - rx, my = (a[1] + b[1] + c[1] + e[1]) * 0.25f - ry,
                    mz = (a[2] + b[2] + c[2] + e[2]) * 0.25f - rz;
            float[][] p = {a, b, c, e};
            if (nx * mx + ny * my + nz * mz < 0f) {
                nx = -nx;
                ny = -ny;
                nz = -nz;
                p = new float[][]{a, e, c, b};
            }
            emit(layer, p, nx, ny, nz, shade, zone, layer == CORE ? CORE_TILE : TILE);
            if (vein && layer == ROCK) {
                emit(VEIN, p, nx, ny, nz, 1f, zone, TILE);
            }
        }

        private void emit(int layer, float[][] p, float nx, float ny, float nz, float shade, int zone, float tile) {
            float ax = Math.abs(nx), ay = Math.abs(ny), az = Math.abs(nz);
            Mesh m = g.layer[layer];
            for (float[] q : p) {
                float u, v;
                if (ay >= ax && ay >= az) {
                    u = q[0] / tile;
                    v = q[2] / tile;
                } else if (ax >= az) {
                    u = q[2] / tile;
                    v = -q[1] / tile;
                } else {
                    u = q[0] / tile;
                    v = -q[1] / tile;
                }
                m.put(q[0], q[1], q[2], u, v, nx, ny, nz, shade, zone, layer == CORE ? 1f : 0f);
            }
        }

        /** Quad inti dengan UV sendiri (aliran: v sepanjang alirannya, digeser tiap gambar). */
        void coreQuad(float[] a, float[] b, float[] c, float[] e, float ua, float va, float ub, float vb, float rx, float ry,
                      float rz, float tint, int zone) {
            uvQuad(CORE, a, b, c, e, ua, va, ub, vb, rx, ry, rz, tint, zone, 1f);
        }

        /** Quad dengan UV sendiri di lapisan mana pun: a (ua, va), b (ub, va), c (ub, vb), e (ua, vb). flow = ikut digeser. */
        void uvQuad(int layer, float[] a, float[] b, float[] c, float[] e, float ua, float va, float ub, float vb, float rx, float ry,
                    float rz, float tint, int zone, float flow) {
            float acx = c[0] - a[0], acy = c[1] - a[1], acz = c[2] - a[2];
            float bdx = e[0] - b[0], bdy = e[1] - b[1], bdz = e[2] - b[2];
            float nx = acy * bdz - acz * bdy, ny = acz * bdx - acx * bdz, nz = acx * bdy - acy * bdx;
            float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (nl < 1.0E-6f) {
                return;
            }
            nx /= nl;
            ny /= nl;
            nz /= nl;
            float mx = (a[0] + b[0] + c[0] + e[0]) * 0.25f - rx, my = (a[1] + b[1] + c[1] + e[1]) * 0.25f - ry,
                    mz = (a[2] + b[2] + c[2] + e[2]) * 0.25f - rz;
            Mesh m = g.layer[layer];
            if (nx * mx + ny * my + nz * mz < 0f) {
                m.put(a[0], a[1], a[2], ua, va, -nx, -ny, -nz, tint, zone, flow);
                m.put(e[0], e[1], e[2], ua, vb, -nx, -ny, -nz, tint, zone, flow);
                m.put(c[0], c[1], c[2], ub, vb, -nx, -ny, -nz, tint, zone, flow);
                m.put(b[0], b[1], b[2], ub, va, -nx, -ny, -nz, tint, zone, flow);
            } else {
                m.put(a[0], a[1], a[2], ua, va, nx, ny, nz, tint, zone, flow);
                m.put(b[0], b[1], b[2], ub, va, nx, ny, nz, tint, zone, flow);
                m.put(c[0], c[1], c[2], ub, vb, nx, ny, nz, tint, zone, flow);
                m.put(e[0], e[1], e[2], ua, vb, nx, ny, nz, tint, zone, flow);
            }
        }

        /**
         * Kristal uranium segi enam: pangkalnya terbenam di batu (base dikurangi seperempat panjangnya), badan prisma yang
         * sedikit mengecil, lalu ujung runcing. Digambar dua kali: kristal padat (lapisan CRYSTAL, terang batu shade) dan
         * kilaunya (lapisan SHINE, ikut terang zona kristal). UV: u melintang tiap sisi, v dari pangkal (0) ke ujung (1).
         */
        void crystal(float bx, float by, float bz, float dx, float dy, float dz, float len, float r, float twist, float shade) {
            float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dl < 1.0E-4f || len < 0.05f) {
                return;
            }
            dx /= dl;
            dy /= dl;
            dz /= dl;
            float hx = Math.abs(dy) < 0.9f ? 0f : 1f, hy = Math.abs(dy) < 0.9f ? 1f : 0f;
            float ux = hy * dz, uy = -hx * dz, uz = hx * dy - hy * dx;
            float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
            ux /= ul;
            uy /= ul;
            uz /= ul;
            float wx = dy * uz - dz * uy, wy = dz * ux - dx * uz, wz = dx * uy - dy * ux;
            float sink = len * 0.25f, shoulder = len * 0.74f;
            float[] apex = {bx + dx * len, by + dy * len, bz + dz * len};
            float[][] lo = new float[6][], hi = new float[6][];
            for (int k = 0; k < 6; k++) {
                float a = twist * 6.28f + (float) (Math.PI / 3.0 * k);
                float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                float ox = ux * ca + wx * sa, oy = uy * ca + wy * sa, oz = uz * ca + wz * sa;
                lo[k] = new float[]{bx - dx * sink + ox * r, by - dy * sink + oy * r, bz - dz * sink + oz * r};
                hi[k] = new float[]{bx + dx * shoulder + ox * r * 0.9f, by + dy * shoulder + oy * r * 0.9f, bz + dz * shoulder + oz * r * 0.9f};
            }
            float mx = bx + dx * len * 0.4f, my = by + dy * len * 0.4f, mz = bz + dz * len * 0.4f;
            float vs = 0.78f;
            for (int k = 0; k < 6; k++) {
                int k1 = (k + 1) % 6;
                float facet = shade * (0.78f + 0.22f * (float) Math.abs(Math.cos(k * 1.9 + twist * 7.0)));
                uvQuad(CRYSTAL, lo[k], lo[k1], hi[k1], hi[k], 0f, 0f, 1f, vs, mx, my, mz, facet, Z_CRYSTAL, 0f);
                uvQuad(CRYSTAL, hi[k], hi[k1], apex, apex, 0f, vs, 1f, 1f, mx, my, mz, Math.min(1f, facet * 1.1f), Z_CRYSTAL, 0f);
                uvQuad(SHINE, lo[k], lo[k1], hi[k1], hi[k], 0f, 0f, 1f, vs, mx, my, mz, 1f, Z_CRYSTAL, SHINE_FLOW);
                uvQuad(SHINE, hi[k], hi[k1], apex, apex, 0f, vs, 1f, 1f, mx, my, mz, 1f, Z_CRYSTAL, SHINE_FLOW);
            }
        }

        /**
         * Gugus kristal yang tumbuh dari titik (x, y, z) ke arah (nx, ny, nz): n kristal, yang pertama paling besar, condong
         * acak di sekitar arahnya, pangkalnya sedikit menyebar.
         */
        void cluster(float x, float y, float z, float nx, float ny, float nz, float size, int n) {
            float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz) + 1.0E-4f;
            nx /= nl;
            ny /= nl;
            nz /= nl;
            for (int i = 0; i < n; i++) {
                float spread = i == 0 ? 0.18f : 0.62f;
                float dx = nx + rnd(-spread, spread), dy = ny + rnd(-spread, spread), dz = nz + rnd(-spread, spread);
                float len = size * (i == 0 ? 1.25f : rnd(0.45f, 0.95f));
                float r = len * rnd(0.15f, 0.21f);
                float off = i == 0 ? 0f : size * 0.42f;
                float ox = rnd(-off, off), oy = rnd(-off, off) * 0.5f, oz = rnd(-off, off);
                crystal(x + ox, y + oy, z + oz, dx, dy, dz, len, r, rnd(), 0.85f + 0.15f * rnd());
            }
        }

        /** Terang batu menurut tinggi (perut gelap, puncak berdebu abu) & sedikit acak tiap bidang. */
        float rockShade(float y) {
            float s = 0.62f + 0.3f * smooth(8f, 52f, y) + rnd(-0.07f, 0.07f);
            return Math.max(0.35f, Math.min(1f, s));
        }

        /**
         * Bongkah lonjong bergerigi (lintang-bujur), dari sudut kutub atas th0 sampai th1 (0 = atas, pi = bawah).
         * amp = tinggi gerigi (bagian dari jari-jari), strata = lapisan batu mendatar.
         */
        void blob(float cx, float cy, float cz, float rx, float ry, float rz, int segU, int segV, float amp, float freq,
                  float strata, float th0, float th1, int zone, int nseed) {
            blob(cx, cy, cz, rx, ry, ry, rz, segU, segV, amp, freq, strata, th0, th1, zone, nseed);
        }

        void blob(float cx, float cy, float cz, float rx, float ry, float ryTop, float rz, int segU, int segV, float amp, float freq,
                  float strata, float th0, float th1, int zone, int nseed) {
            float[][] ring = new float[(segV + 1) * (segU + 1)][];
            for (int i = 0; i <= segV; i++) {
                float th = th0 + (th1 - th0) * i / segV;
                for (int k = 0; k <= segU; k++) {
                    float ph = (float) (Math.PI * 2.0 * (k % segU) / segU);
                    ring[i * (segU + 1) + k] = blobPoint(cx, cy, cz, rx, ry, ryTop, rz, amp, freq, strata, nseed, th, ph, 0f);
                }
            }
            for (int i = 0; i < segV; i++) {
                for (int k = 0; k < segU; k++) {
                    float[] a = ring[i * (segU + 1) + k], b2 = ring[i * (segU + 1) + k + 1];
                    float[] c = ring[(i + 1) * (segU + 1) + k + 1], e = ring[(i + 1) * (segU + 1) + k];
                    quad(ROCK, a, b2, c, e, cx, cy, cz, rockShade((a[1] + c[1]) * 0.5f), zone, true);
                }
            }
        }

        /** Tiang batu segi enam dari a ke b (r0 di pangkal, r1 di ujung), tutup di kedua ujungnya. */
        void hexPrism(float ax, float ay, float az, float bx, float by, float bz, float r0, float r1, float twist, int zone,
                      boolean vein, float shade) {
            float dx = bx - ax, dy = by - ay, dz = bz - az;
            float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dl < 1.0E-4f) {
                return;
            }
            dx /= dl;
            dy /= dl;
            dz /= dl;
            float hx = Math.abs(dy) < 0.9f ? 0f : 1f, hy = Math.abs(dy) < 0.9f ? 1f : 0f;
            float ux = hy * dz, uy = -hx * dz, uz = hx * dy - hy * dx;
            float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
            ux /= ul;
            uy /= ul;
            uz /= ul;
            float wx = dy * uz - dz * uy, wy = dz * ux - dx * uz, wz = dx * uy - dy * ux;
            float[][] lo = new float[6][], hi = new float[6][];
            for (int k = 0; k < 6; k++) {
                float a = twist + (float) (Math.PI / 3.0 * k);
                float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                lo[k] = new float[]{ax + (ux * ca + wx * sa) * r0, ay + (uy * ca + wy * sa) * r0, az + (uz * ca + wz * sa) * r0};
                hi[k] = new float[]{bx + (ux * ca + wx * sa) * r1, by + (uy * ca + wy * sa) * r1, bz + (uz * ca + wz * sa) * r1};
            }
            float mx = (ax + bx) * 0.5f, my = (ay + by) * 0.5f, mz = (az + bz) * 0.5f;
            for (int k = 0; k < 6; k++) {
                int k1 = (k + 1) % 6;
                quad(ROCK, lo[k], lo[k1], hi[k1], hi[k], mx, my, mz, shade * (0.9f + 0.2f * rnd()), zone, vein);
            }
            if (r1 > 0.05f) {
                quad(ROCK, hi[0], hi[1], hi[2], hi[3], mx, my, mz, shade * 1.08f, zone, false);
                quad(ROCK, hi[3], hi[4], hi[5], hi[0], mx, my, mz, shade * 1.08f, zone, false);
            }
            quad(ROCK, lo[0], lo[1], lo[2], lo[3], mx, my, mz, shade * 0.8f, zone, false);
            quad(ROCK, lo[3], lo[4], lo[5], lo[0], mx, my, mz, shade * 0.8f, zone, false);
        }

        /**
         * Bongkah bersudut delapan (sudutnya diberi sendiri): 0-3 = belakang (kiri-bawah, kanan-bawah, kanan-atas,
         * kiri-atas), 4-7 = depan (urutan sama). coreMask: sisi mana yang menyala (1 bawah, 2 atas, 4 depan, 8 belakang).
         */
        void hexa(float[][] c, int zone, float shade, boolean vein, int coreMask, float coreTint) {
            float mx = 0, my = 0, mz = 0;
            for (float[] p : c) {
                mx += p[0] / 8f;
                my += p[1] / 8f;
                mz += p[2] / 8f;
            }
            int[][] faces = {{0, 1, 5, 4}, {3, 2, 6, 7}, {4, 5, 6, 7}, {0, 1, 2, 3}, {0, 3, 7, 4}, {1, 2, 6, 5}};
            float[] tone = {0.72f, 1.06f, 0.95f, 0.85f, 0.92f, 0.92f};
            for (int f = 0; f < 6; f++) {
                int[] q = faces[f];
                quad(ROCK, c[q[0]], c[q[1]], c[q[2]], c[q[3]], mx, my, mz, Math.min(1f, shade * tone[f] * (0.92f + 0.16f * rnd())),
                        zone, vein);
                if (f < 4 && (coreMask & (1 << f)) != 0) {   // lapisan inti tipis sedikit di luar sisi batunya
                    float[][] o = new float[4][];
                    for (int k = 0; k < 4; k++) {
                        float[] p = c[q[k]];
                        o[k] = new float[]{p[0] + (p[0] - mx) * 0.004f, p[1] + (p[1] - my) * 0.02f, p[2] + (p[2] - mz) * 0.004f};
                    }
                    quad(CORE, o[0], o[1], o[2], o[3], mx, my, mz, coreTint, Z_FACE, false);
                }
            }
        }

        /** Kotak miring sederhana: pusat, setengah ukuran belakang (w0, h0) & depan (w1, h1), sepanjang z0..z1, bergeser acak. */
        float[][] slab(float x, float yb0, float yt0, float yb1, float yt1, float w0, float w1, float z0, float z1, float jitter) {
            float[][] c = {
                    {x + w0, yb0, z0}, {x - w0, yb0, z0}, {x - w0, yt0, z0}, {x + w0, yt0, z0},
                    {x + w1, yb1, z1}, {x - w1, yb1, z1}, {x - w1, yt1, z1}, {x + w1, yt1, z1}};
            for (float[] p : c) {
                p[0] += rnd(-jitter, jitter);
                p[1] += rnd(-jitter, jitter);
                p[2] += rnd(-jitter, jitter);
            }
            return c;
        }

        /** Batu bersudut kecil di sekitar pusat (cx, cy, cz) berukuran (sx, sy, sz). */
        float[][] boulder(float cx, float cy, float cz, float sx, float sy, float sz) {
            float[][] c = new float[8][];
            int[][] sign = {{1, -1, -1}, {-1, -1, -1}, {-1, 1, -1}, {1, 1, -1}, {1, -1, 1}, {-1, -1, 1}, {-1, 1, 1}, {1, 1, 1}};
            for (int i = 0; i < 8; i++) {
                c[i] = new float[]{cx + sign[i][0] * sx * rnd(0.6f, 1.15f), cy + sign[i][1] * sy * rnd(0.6f, 1.15f),
                        cz + sign[i][2] * sz * rnd(0.6f, 1.15f)};
            }
            return c;
        }
    }

    // ------------------------------------------------------------------ badan & gunung

    private static void buildBody(B b) {
        // bongkah badan utama, leher, punuk bahu & pinggul
        b.blob(0f, BY, BZ, RX, RY, RY_TOP, RZ, 26, 14, 0.09f, 1.7f, 0.01f, 0.05f, (float) Math.PI, Z_BODY, 101);
        b.blob(0f, 29.5f, 22f, 10.5f, 9.5f, 9.5f, 12, 8, 0.12f, 1.9f, 0.02f, 0f, (float) Math.PI, Z_BODY, 102);
        b.blob(12.5f, 35.5f, 15f, 8f, 6.5f, 8.5f, 9, 6, 0.24f, 2.4f, 0.03f, 0.2f, (float) (Math.PI * 0.75), Z_BODY, 103);
        b.blob(-12.5f, 35.5f, 15f, 8f, 6.5f, 8.5f, 9, 6, 0.24f, 2.4f, 0.03f, 0.2f, (float) (Math.PI * 0.75), Z_BODY, 104);
        b.blob(13.5f, 34.5f, -17.5f, 8.5f, 7f, 9f, 9, 6, 0.24f, 2.4f, 0.03f, 0.2f, (float) (Math.PI * 0.75), Z_BODY, 105);
        b.blob(-13.5f, 34.5f, -17.5f, 8.5f, 7f, 9f, 9, 6, 0.24f, 2.4f, 0.03f, 0.2f, (float) (Math.PI * 0.75), Z_BODY, 106);

        // lereng gunung: dari pundak badan sampai bibir kawah, bergigi; kakinya membentuk birai batu yang menjorok di atas badan
        final int segs = 24, rings = 5;
        float cz = KalderaBody.CALDERA_Z, y0 = BY + 1f, y1 = KalderaBody.CALDERA_Y, rRim = 9.2f;
        float ex = RX * 0.97f, ez = RZ * 0.95f;   // kaki lereng = lingkar badan
        float[][] cone = new float[(rings + 1) * (segs + 1)][];
        float[] ridge = new float[segs];
        for (int k = 0; k < segs; k++) {
            float ph = (float) (Math.PI * 2.0 * k / segs);
            ridge[k] = 0.14f * (float) Math.pow(Math.abs(Math.sin(ph * 2.5 + 0.7)), 0.6) + 0.1f * fbm((float) Math.cos(ph) * 2f,
                    0f, (float) Math.sin(ph) * 2f, 201) - 0.06f;
        }
        for (int i = 0; i <= rings; i++) {
            float u = i / (float) rings;
            float y = y0 + (y1 - y0) * (float) Math.pow(u, 1.15);
            float t = (float) Math.pow(u, 0.62);
            float zc = BZ + (cz - BZ) * u;
            for (int k = 0; k <= segs; k++) {
                float ph = (float) (Math.PI * 2.0 * (k % segs) / segs);
                float cs = (float) Math.cos(ph), sn = (float) Math.sin(ph);
                float er = 1f / (float) Math.sqrt((cs / ex) * (cs / ex) + (sn / ez) * (sn / ez));   // jari-jari elips kaki lereng
                float r = er + (rRim - er) * t;
                float rr = r * (1f + ridge[k % segs] * smooth(0f, 0.4f, u) * (1f - 0.5f * u)
                        + 0.05f * u * fbm((k % segs) * 0.7f, u * 3f, 0f, 202));
                float yy = y + (i == rings || i == 0 ? 0f : 1.0f * fbm((k % segs) * 0.5f, u * 2f, 4f, 203));
                cone[i * (segs + 1) + k] = new float[]{cs * rr, yy, zc + sn * rr};
            }
        }
        for (int i = 0; i < rings; i++) {
            for (int k = 0; k < segs; k++) {
                float[] a = cone[i * (segs + 1) + k], c2 = cone[(i + 1) * (segs + 1) + k + 1];
                b.quad(ROCK, a, cone[i * (segs + 1) + k + 1], c2, cone[(i + 1) * (segs + 1) + k], 0f, (a[1] + c2[1]) * 0.5f - 6f, cz,
                        b.rockShade((a[1] + c2[1]) * 0.5f), i >= rings - 2 ? Z_CALDERA : Z_BODY, true);
            }
        }
        for (int k = 0; k < segs; k++) {   // birai di kaki lereng: melipat ke dalam badan (nggak ada celah tembus pandang)
            float[] a = cone[k], c2 = cone[k + 1];
            float[] ia = {a[0] * 0.8f, a[1] - 5f, BZ + (a[2] - BZ) * 0.8f};
            float[] ic = {c2[0] * 0.8f, c2[1] - 5f, BZ + (c2[2] - BZ) * 0.8f};
            b.quad(ROCK, a, c2, ic, ia, 0f, y0 + 6f, BZ, 0.42f, Z_BODY, false);
        }
        // bibir & mangkuk kawah, kolam inti radioaktif di dasarnya
        float[][] lip = new float[segs + 1][], wall = new float[segs + 1][], deep = new float[segs + 1][];
        for (int k = 0; k <= segs; k++) {
            float ph = (float) (Math.PI * 2.0 * (k % segs) / segs), cs = (float) Math.cos(ph), sn = (float) Math.sin(ph);
            float j = 1f + 0.08f * fbm((k % segs) * 0.9f, 7f, 1f, 204);
            lip[k] = new float[]{cs * 7.9f * j, y1 + 0.9f, cz + sn * 7.9f * j};
            wall[k] = new float[]{cs * 6.6f * j, y1 - 2.2f, cz + sn * 6.6f * j};
            deep[k] = new float[]{cs * 4.8f, y1 - 3.4f, cz + sn * 4.8f};
        }
        for (int k = 0; k < segs; k++) {
            float[] r0 = cone[rings * (segs + 1) + k], r1 = cone[rings * (segs + 1) + k + 1];
            b.quad(ROCK, r0, r1, lip[k + 1], lip[k], 0f, y1 - 8f, cz, b.rockShade(y1) * 1.05f, Z_CALDERA, true);
            b.quad(ROCK, lip[k], lip[k + 1], wall[k + 1], wall[k], 0f, y1 + 9f, cz, 0.55f, Z_CALDERA, true);   // dinding dalam
            b.quad(ROCK, wall[k], wall[k + 1], deep[k + 1], deep[k], 0f, y1 + 9f, cz, 0.42f, Z_CALDERA, true);
        }
        float lake = y1 - 2.6f;
        float[] mid = {0f, lake, cz};
        for (int k = 0; k < segs; k++) {   // kolam inti (kipas segitiga: dua titik pusat yang sama)
            float ph0 = (float) (Math.PI * 2.0 * k / segs), ph1 = (float) (Math.PI * 2.0 * (k + 1) / segs);
            float[] a = {(float) Math.cos(ph0) * 6.9f, lake, cz + (float) Math.sin(ph0) * 6.9f};
            float[] c = {(float) Math.cos(ph1) * 6.9f, lake, cz + (float) Math.sin(ph1) * 6.9f};
            b.quad(CORE, mid, a, c, mid, 0f, lake - 4f, cz, 1f, Z_CALDERA, false);
        }
        // mahkota duri batu gelap di sekeliling kawah
        for (int i = 0; i < 11; i++) {
            float ph = (float) (Math.PI * 2.0 * (i + b.rnd(-0.25f, 0.25f)) / 11.0);
            float cs = (float) Math.cos(ph), sn = (float) Math.sin(ph);
            float r = b.rnd(8.2f, 9.4f), len = b.rnd(3.5f, 9f), lean = b.rnd(0.25f, 0.5f);
            float bx = cs * r, bz = cz + sn * r, by = y1 + b.rnd(-0.8f, 0.4f);
            float dx = cs * lean, dy = 1f, dz = sn * lean;
            float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            b.hexPrism(bx, by - 1f, bz, bx + dx / dl * len, by + dy / dl * len, bz + dz / dl * len, b.rnd(1.3f, 2.1f), b.rnd(0.15f, 0.45f),
                    b.rnd(0f, 1f), Z_CALDERA, true, 0.82f);
        }
        // lubang asap di lereng
        for (int i = 0; i < VENTS.length; i += 2) {
            float vx = VENTS[i], vz = VENTS[i + 1];
            float vy = ventY(cone, rings, segs, vx, vz) - 0.6f;
            b.hexPrism(vx, vy, vz, vx * 1.04f, vy + 2.4f, vz, 2.3f, 1.2f, b.rnd(0f, 1f), Z_BODY, false, 0.6f);
            float[] m0 = {vx, vy + 2.45f, vz};
            for (int k = 0; k < 6; k++) {
                float a0 = (float) (Math.PI / 3.0 * k), a1 = (float) (Math.PI / 3.0 * (k + 1));
                float[] p0 = {vx + (float) Math.cos(a0) * 0.9f, vy + 2.45f, vz + (float) Math.sin(a0) * 0.9f};
                float[] p1 = {vx + (float) Math.cos(a1) * 0.9f, vy + 2.45f, vz + (float) Math.sin(a1) * 0.9f};
                b.quad(CORE, m0, p0, p1, m0, vx, vy, vz, 0.7f, Z_CALDERA, false);
            }
        }
        // lempeng strata di kedua sisi badan
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 9; i++) {
                float z = -24f + i * 5.8f + b.rnd(-1.5f, 1.5f);
                float y = b.rnd(26f, 36f);
                float r = bodyRadiusAt(y, z) * 0.97f;
                if (r <= 1f) {
                    continue;
                }
                float w = b.rnd(1.2f, 2.2f), hgt = b.rnd(1.2f, 2.4f), len = b.rnd(2.5f, 4.5f);
                b.hexa(b.boulder(side * r, y, z, w, hgt, len), Z_BODY, b.rockShade(y), true, 0, 0f);
            }
        }
        // batu-batu yang mencuat dari punggung (di luar lereng gunung)
        for (int i = 0; i < 18; i++) {
            float z = b.rnd(-27f, 24f);
            float x = b.rnd(-15f, 15f);
            float dzc = z - (cz - 2f);
            if (x * x + dzc * dzc < 21f * 21f) {
                continue;
            }
            float y = surfaceY(x, z);
            if (y < 33f) {
                continue;
            }
            b.hexa(b.boulder(x, y + 0.4f, z, b.rnd(1.2f, 2.6f), b.rnd(1.0f, 2.2f), b.rnd(1.2f, 2.8f)), Z_BODY, b.rockShade(y), true, 0, 0f);
        }
        // tiang batu yang menggantung di bawah perut
        for (int i = 0; i < 8; i++) {
            float x = b.rnd(-11f, 11f), z = b.rnd(-20f, 14f);
            float k = Math.max(0f, 1f - (x / RX) * (x / RX) - ((z - BZ) / RZ) * ((z - BZ) / RZ));
            float y = BY - RY * (float) Math.sqrt(k) + 1f;
            b.hexPrism(x, y + 1.5f, z, x + b.rnd(-0.4f, 0.4f), y - b.rnd(2.5f, 6f), z + b.rnd(-0.4f, 0.4f), b.rnd(1.1f, 1.8f), b.rnd(0.2f, 0.6f),
                    b.rnd(0f, 1f), Z_BODY, false, 0.5f);
        }
        // lima aliran cairan radioaktif: dari bibir kawah menuruni lembah-lembah lereng, jatuh dari birai, lalu mengalir di sisi badan
        float[] streamDeg = {35f, 145f, 212f, 270f, 328f};   // serong depan, serong belakang, & belakang (kepala di +z)
        for (int s = 0; s < 5; s++) {
            int best = 0;
            float bestR = 9f;
            for (int k = 0; k < 4; k++) {   // cari lembah (gerigi terendah) di sekitar arahnya
                int kk = Math.floorMod(Math.round(segs * streamDeg[s] / 360f) + k - 2, segs);
                if (ridge[kk] < bestR) {
                    bestR = ridge[kk];
                    best = kk;
                }
            }
            float phs = (float) (Math.PI * 2.0 * best / segs);
            List<float[]> pts = new ArrayList<>();
            List<Float> wid = new ArrayList<>();
            for (int i = 0; i <= 10; i++) {   // di lereng (bidang segi jaringnya sendiri, sedikit di atasnya)
                float u = 1f - i / 10f;
                float ph = phs + 0.06f * (float) Math.sin(i * 1.3 + s);
                pts.add(conePoint(cone, rings, segs, u, ph, 0.35f));
                wid.add(1.6f + 1.8f * (i / 10f));
            }
            float[] edge = pts.get(pts.size() - 1);
            float phb = (float) Math.atan2(edge[2] - BZ, edge[0]);
            for (int i = 1; i <= 3; i++) {   // lalu menetes sedikit di bawah lingkar badan
                float th = 1.62f + i * 0.08f;
                pts.add(blobPoint(0f, BY, BZ, RX, RY, RY_TOP, RZ, 0.09f, 1.7f, 0.01f, 101, th, phb + 0.05f * (float) Math.sin(i + s), 0.5f));
                wid.add(3.2f - 0.7f * i);
            }
            float[][] arr = pts.toArray(new float[0][]);
            float[] w = new float[wid.size()];
            for (int i = 0; i < w.length; i++) {
                w[i] = wid.get(i);
            }
            ribbon(b, arr, w, 0f, 38f, cz, Z_STREAM);
        }
        crystals(b, cone, rings, segs);
    }

    /** Gugus kristal uranium di bahu, pinggul, sisi badan, dan lereng depan & belakang gunung (nggak di garis punggung). */
    private static void crystals(B b, float[][] cone, int rings, int segs) {
        for (int side = -1; side <= 1; side += 2) {
            float ph = side > 0 ? 0f : (float) Math.PI;
            // bahu: gugus terbesar, condong ke depan & keluar
            float[] s = blobPoint(side * 12.5f, 35.5f, 15f, 8f, 6.5f, 6.5f, 8.5f, 0.24f, 2.4f, 0.03f, 103 + (side > 0 ? 0 : 1),
                    0.85f, ph + side * 0.35f, -0.6f);
            b.cluster(s[0], s[1], s[2], side * 0.9f, 0.85f, 0.35f, 7.4f, 7);
            // pinggul: lebih kecil, condong ke belakang
            float[] h = blobPoint(side * 13.5f, 34.5f, -17.5f, 8.5f, 7f, 7f, 9f, 0.24f, 2.4f, 0.03f, 105 + (side > 0 ? 0 : 1),
                    0.9f, ph - side * 0.4f, -0.6f);
            b.cluster(h[0], h[1], h[2], side * 0.9f, 0.8f, -0.4f, 5.8f, 6);
            // sisi badan: dua gugus kecil di bawah lingkar badan
            float[][] flank = {{30.5f, 3f, 3.8f, 3}, {28.5f, -9f, 3.4f, 3}, {32f, -20f, 2.8f, 2}};
            for (float[] f : flank) {
                float r = bodyRadiusAt(f[0], f[1]);
                if (r <= 2f) {
                    continue;
                }
                b.cluster(side * (r - 0.6f), f[0], f[1], side, -0.25f, b.rnd(-0.2f, 0.2f), f[2], (int) f[3]);
            }
        }
        // lereng gunung: serong depan kiri & kanan, dan serong belakang (menjauhi garis punggung)
        float[][] slope = {{0.42f, (float) (Math.PI * 0.5 - 0.62), 5.4f, 4}, {0.42f, (float) (Math.PI * 0.5 + 0.62), 5.4f, 4},
                {0.36f, (float) (Math.PI * 1.5 + 0.7), 4.4f, 3}, {0.5f, (float) (Math.PI * 1.5 - 0.95), 3.8f, 3}};
        for (float[] q : slope) {
            float[] p = conePoint(cone, rings, segs, q[0], q[1], -0.3f);
            b.cluster(p[0], p[1], p[2], (float) Math.cos(q[1]), 0.95f, (float) Math.sin(q[1]), q[2], (int) q[3]);
        }
    }

    /** Lubang asap (x, z) di lereng gunung. */
    public static final float[] VENTS = {11.5f, -9f, -12f, -6f, 4f, -16.5f};

    /** Titik di permukaan lereng (jaring segi) pada u (0 = kaki, 1 = bibir) & sudut ph, terangkat lift ke luar. */
    private static float[] conePoint(float[][] cone, int rings, int segs, float u, float ph, float lift) {
        float fi = Math.max(0f, Math.min(rings - 1.0E-3f, u * rings));
        float fk = (float) (Math.floorMod((int) Math.floor(ph / (Math.PI * 2.0) * segs * 1000.0), segs * 1000) / 1000.0);
        int i = (int) fi, k = (int) fk;
        float ti = fi - i, tk = fk - k;
        float[] a = cone[i * (segs + 1) + k], b = cone[i * (segs + 1) + k + 1];
        float[] c = cone[(i + 1) * (segs + 1) + k], d = cone[(i + 1) * (segs + 1) + k + 1];
        float[] p = new float[3];
        for (int j = 0; j < 3; j++) {
            p[j] = lerp(ti, lerp(tk, a[j], b[j]), lerp(tk, c[j], d[j]));
        }
        float ox = p[0], oz = p[2] - KalderaBody.CALDERA_Z;
        float ol = (float) Math.sqrt(ox * ox + oz * oz) + 1.0E-4f;
        p[0] += ox / ol * lift;
        p[1] += lift * 0.6f;
        p[2] += oz / ol * lift;
        return p;
    }

    /** Tinggi lereng di (x, z) (dicari dari jaring lerengnya). */
    private static float ventY(float[][] cone, int rings, int segs, float x, float z) {
        float ph = (float) Math.atan2(z - KalderaBody.CALDERA_Z, x);
        float d = (float) Math.sqrt(x * x + (z - KalderaBody.CALDERA_Z) * (z - KalderaBody.CALDERA_Z));
        float best = 1e9f, y = 40f;
        for (int i = 0; i <= 20; i++) {
            float[] p = conePoint(cone, rings, segs, i / 20f, ph, 0f);
            float pd = (float) Math.sqrt(p[0] * p[0] + (p[2] - KalderaBody.CALDERA_Z) * (p[2] - KalderaBody.CALDERA_Z));
            if (Math.abs(pd - d) < best) {
                best = Math.abs(pd - d);
                y = p[1];
            }
        }
        return y;
    }

    /** Tinggi permukaan atas bongkah badan utama di (x, z) (tanpa gerigi). */
    private static float surfaceY(float x, float z) {
        float k = 1f - (x / RX) * (x / RX) - ((z - BZ) / RZ) * ((z - BZ) / RZ);
        return k <= 0f ? BY - 6f : BY + RY_TOP * (float) Math.sqrt(k);
    }

    /** Jari-jari datar bongkah badan di ketinggian y pada potongan z. */
    private static float bodyRadiusAt(float y, float z) {
        float k = 1f - ((y - BY) / RY) * ((y - BY) / RY) - ((z - BZ) / RZ) * ((z - BZ) / RZ);
        return k <= 0f ? 0f : RX * (float) Math.sqrt(k);
    }

    /** Pita cairan menyala sepanjang titik-titik pts (lebar wid), menghadap menjauhi sumbu (0, ry, rz). */
    private static void ribbon(B b, float[][] pts, float[] wid, float rx, float ry, float rz, int zone) {
        float vacc = 0f;
        for (int i = 0; i < pts.length - 1; i++) {
            float[] p = pts[i], q = pts[i + 1];
            float tx = q[0] - p[0], ty = q[1] - p[1], tz = q[2] - p[2];
            float ox = p[0] - rx, oz = p[2] - rz;
            float ol = (float) Math.sqrt(ox * ox + oz * oz) + 1.0E-4f;
            float nx = ox / ol, ny = 0.35f, nz = oz / ol;
            float sx = ty * nz - tz * ny, sy = tz * nx - tx * nz, sz = tx * ny - ty * nx;
            float sl = (float) Math.sqrt(sx * sx + sy * sy + sz * sz) + 1.0E-4f;
            sx /= sl;
            sy /= sl;
            sz /= sl;
            float w0 = wid[i] * 0.5f, w1 = wid[i + 1] * 0.5f;
            float[] a = {p[0] + sx * w0, p[1] + sy * w0, p[2] + sz * w0};
            float[] c = {p[0] - sx * w0, p[1] - sy * w0, p[2] - sz * w0};
            float[] d = {q[0] - sx * w1, q[1] - sy * w1, q[2] - sz * w1};
            float[] e = {q[0] + sx * w1, q[1] + sy * w1, q[2] + sz * w1};
            float seg = (float) Math.sqrt(tx * tx + ty * ty + tz * tz);
            float tint = 0.75f + 0.25f * (1f - i / (float) pts.length);
            b.coreQuad(a, c, d, e, 0f, vacc / CORE_TILE, 1f, (vacc + seg) / CORE_TILE, rx, ry, rz, tint, zone);
            vacc += seg;
        }
    }

    // ------------------------------------------------------------------ kepala & rahang

    private static void buildHead(B b) {
        // tengkorak batu membulat di belakang, haluan berlapis yang miring ke depan (ruang kepala: dari sendinya, +z depan)
        b.blob(0f, 3.4f, 6.5f, 7.6f, 6.2f, 7.4f, 9, 6, 0.2f, 2.3f, 0.02f, 0.15f, (float) (Math.PI * 0.62), Z_BODY, 301);
        b.hexa(b.slab(0f, -1.0f, 5.4f, -2.0f, 1.4f, 7.0f, 4.0f, 5.5f, 17.0f, 0.3f), Z_BODY, 0.76f, true, 0, 0f);
        b.hexa(b.slab(0f, -3.0f, 0.4f, -3.2f, -1.2f, 7.9f, 4.6f, 3.8f, 17.6f, 0.25f), Z_BODY, 0.68f, true, 0, 0f);
        float[][] roof = b.slab(0f, -3.8f, -2.8f, -3.95f, -3.0f, 7.4f, 4.4f, 4.6f, 18.0f, 0.12f);
        b.hexa(roof, Z_BODY, 0.6f, false, 1, 0.9f);   // langit-langit mulut: bawahnya menyala
        // tenggorokan menyala di pangkal mulut
        float[] t0 = {6.4f, -3.9f, 5.2f}, t1 = {-6.4f, -3.9f, 5.2f}, t2 = {-6.0f, -8.4f, 5.0f}, t3 = {6.0f, -8.4f, 5.0f};
        b.coreQuad(t0, t1, t2, t3, 0f, 0f, 1.2f, 1f, 0f, -6f, 0f, 1f, Z_FACE);
        for (int side = -1; side <= 1; side += 2) {
            // alis batu yang menaungi deretan mata, & pipi bersudut
            b.hexa(b.slab(side * 6.6f, 0.3f, 2.8f, 0.0f, 1.6f, 1.7f, 1.0f, 5.5f, 15.0f, 0.3f), Z_BODY, 0.72f, true, 0, 0f);
            b.hexa(b.boulder(side * 7.6f, -2.2f, 6.5f, 1.4f, 1.6f, 2.4f), Z_BODY, 0.66f, true, 0, 0f);
            // tiga mata hijau di sisi kepala, mengecil ke depan
            for (int e = 0; e < 3; e++) {
                float z = 8f + e * 3.1f;
                float half = lerp((z - 3.8f) / (17.6f - 3.8f), 7.9f, 4.6f) + 0.14f;
                float x = side * half, y = -0.9f - e * 0.15f, sz = 0.95f - e * 0.12f;
                float[] a = {x, y + sz, z}, c = {x, y, z + sz * 1.25f}, d = {x, y - sz * 0.8f, z}, f = {x, y, z - sz * 1.25f};
                b.coreQuad(a, c, d, f, 0f, 0f, 0.6f, 0.6f, 0f, y, z, 1f, Z_FACE);
            }
        }
        // jambul tiang batu di ubun-ubun, condong ke belakang
        for (int i = 0; i < 4; i++) {
            float z = 2.5f + i * 2.6f, y = 8.6f - i * 0.9f;
            float len = b.rnd(3.2f, 5.2f) * (1f - i * 0.12f);
            b.hexPrism(b.rnd(-0.5f, 0.5f), y - 1.4f, z, b.rnd(-0.4f, 0.4f), y + len * 0.75f, z - len * 0.65f, b.rnd(1.0f, 1.4f), 0.25f,
                    b.rnd(0f, 1f), Z_BODY, true, 0.72f);
        }
        b.hexa(b.boulder(0f, -0.4f, 17.4f, 3.2f, 2.0f, 1.4f), Z_BODY, 0.7f, true, 0, 0f);   // tonjolan moncong
        for (int side = -1; side <= 1; side += 2) {   // kristal kecil yang tumbuh dari pelipis, condong ke belakang
            b.cluster(side * 5.6f, 6.4f, 4.4f, side * 0.75f, 0.9f, -0.55f, 2.8f, 3);
        }
    }

    private static void buildJaw(B b) {
        // rahang bawah (ruang rahang: dari engselnya); atasnya lantai mulut yang menyala
        float[][] j = b.slab(0f, -4.6f, -0.25f, -3.4f, -0.45f, 7.0f, 4.2f, 0.5f, 15.6f, 0.15f);
        b.hexa(j, Z_BODY, 0.6f, true, 2, 0.85f);
        b.hexa(b.boulder(0f, -4.2f, 13.2f, 3.0f, 1.7f, 2.2f), Z_BODY, 0.56f, true, 0, 0f);   // dagu
        for (int i = 0; i < 3; i++) {   // janggut batu yang menggantung di bawah rahang
            float z = 4f + i * 3.5f;
            b.hexPrism(b.rnd(-1.5f, 1.5f), -4.0f, z, b.rnd(-1.8f, 1.8f), -6.8f - b.rnd(0f, 1.5f), z + b.rnd(-0.6f, 0.6f), b.rnd(1.0f, 1.4f),
                    0.3f, b.rnd(0f, 1f), Z_BODY, false, 0.52f);
        }
        for (int side = -1; side <= 1; side += 2) {   // gigi batu tumpul di tepi rahang
            for (int i = 0; i < 4; i++) {
                float z = 4.5f + i * 2.9f;
                float half = lerp((z - 0.5f) / 15.1f, 7.0f, 4.2f) - 0.7f;
                b.hexa(b.boulder(side * half, 0.35f, z, 0.6f, 0.75f, 0.7f), Z_BODY, 0.66f, false, 0, 0f);
            }
        }
    }

    // ------------------------------------------------------------------ kaki (dibangun tiap gambar)

    /** Bentuk acak kaki yang tetap (tiang-tiang di berkasnya, telapak). */
    static final class LegKit {
        final float[] ox = new float[7], oz = new float[7], r = new float[7], e0 = new float[7], e1 = new float[7], tw = new float[7];
        final float[] lox = new float[7], loz = new float[7], lr = new float[7], le0 = new float[7], le1 = new float[7];
        final float[] px = new float[7], pz = new float[7], ph = new float[7], pr = new float[7];

        LegKit(int seed) {
            B rnd = new B(null, seed);
            for (int i = 0; i < 7; i++) {
                float a = (float) (Math.PI / 3.0 * i) + rnd.rnd(-0.2f, 0.2f);
                float d = i == 6 ? 0f : rnd.rnd(3.7f, 4.3f);
                ox[i] = (float) Math.cos(a) * d;
                oz[i] = (float) Math.sin(a) * d;
                r[i] = i == 6 ? 2.9f : rnd.rnd(2.05f, 2.5f);
                e0[i] = rnd.rnd(-0.8f, 1.6f);
                e1[i] = rnd.rnd(-0.6f, 1.2f);
                tw[i] = rnd.rnd(0f, 1f);
                lox[i] = ox[i] * 0.88f;
                loz[i] = oz[i] * 0.88f;
                lr[i] = r[i] * 0.92f;
                le0[i] = rnd.rnd(-0.6f, 1.4f);
                le1[i] = rnd.rnd(-0.4f, 0.8f);
                float pa = (float) (Math.PI / 3.0 * i) + rnd.rnd(-0.25f, 0.25f);
                float pd = i == 6 ? 0f : rnd.rnd(4.3f, 5.1f);
                px[i] = (float) Math.cos(pa) * pd;
                pz[i] = (float) Math.sin(pa) * pd;
                ph[i] = rnd.rnd(2.8f, 4.0f);
                pr[i] = rnd.rnd(2.4f, 3.0f);
            }
        }
    }

    // ------------------------------------------------------------------ gambar

    /** Matriks afin 3x4 (baris): [m0 m1 m2 m3; m4 m5 m6 m7; m8 m9 m10 m11]. */
    static float[] ident() {
        return new float[]{1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0};
    }

    static float[] mul(float[] a, float[] b) {
        float[] r = new float[12];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 4; j++) {
                float s = a[i * 4] * b[j] + a[i * 4 + 1] * b[4 + j] + a[i * 4 + 2] * b[8 + j];
                if (j == 3) {
                    s += a[i * 4 + 3];
                }
                r[i * 4 + j] = s;
            }
        }
        return r;
    }

    static float[] translate(float x, float y, float z) {
        return new float[]{1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z};
    }

    /** Putaran baku sumbu X (y' = y cos - z sin). */
    static float[] rotX(float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        return new float[]{1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0};
    }

    static float[] rotY(float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        return new float[]{c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0};
    }

    static float[] rotZ(float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        return new float[]{c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0};
    }

    /** Matriks badan, sama persis dengan KalderaBody.body. */
    static float[] bodyMatrix(KalderaBody.Pose p) {
        float[] m = translate(0f, p.bodyY, 0f);
        m = mul(m, translate(0f, KalderaBody.PIVOT_Y, 0f));
        m = mul(m, rotZ(p.roll));
        m = mul(m, translate(0f, -KalderaBody.PIVOT_Y, 0f));
        m = mul(m, translate(0f, KalderaBody.PIVOT_Y, KalderaBody.PIVOT_Z));
        m = mul(m, rotX(-p.pitch));
        return mul(m, translate(0f, -KalderaBody.PIVOT_Y, -KalderaBody.PIVOT_Z));
    }

    static float[] headMatrix(float[] bodyM, KalderaBody.Pose p) {
        float[] m = mul(bodyM, translate(0f, KalderaBody.NECK_Y, KalderaBody.NECK_Z));
        m = mul(m, rotY(p.headYaw));
        return mul(m, rotX(-p.headUp));
    }

    static float[] jawMatrix(float[] headM, KalderaBody.Pose p) {
        return mul(mul(headM, translate(0f, KalderaBody.JAW_Y, KalderaBody.JAW_Z)), rotX(p.jaw));
    }

    private static void emit(Group g, float[] m, float[] gain, float flow, float rock, int only, Sink sink) {
        for (int layer = 0; layer < LAYERS; layer++) {
            if (only >= 0 && layer != only) {
                continue;
            }
            Mesh mesh = g.layer[layer];
            float[] d = mesh.d;
            for (int i = 0; i < mesh.n; i += STRIDE) {
                float x = d[i], y = d[i + 1], z = d[i + 2], nx = d[i + 5], ny = d[i + 6], nz = d[i + 7];
                int zone = (int) d[i + 9];
                float tint = layer == ROCK || layer == CRYSTAL ? d[i + 8] * rock : d[i + 8] * gain[zone];
                sink.vertex(layer, m[0] * x + m[1] * y + m[2] * z + m[3], m[4] * x + m[5] * y + m[6] * z + m[7],
                        m[8] * x + m[9] * y + m[10] * z + m[11], d[i + 3], d[i + 4] + d[i + 10] * flow,
                        m[0] * nx + m[1] * ny + m[2] * nz, m[4] * nx + m[5] * ny + m[6] * nz, m[8] * nx + m[9] * ny + m[10] * nz,
                        tint, zone);
            }
        }
    }

    /**
     * Gambar seluruh tubuh dalam pose p. gain = terang lapisan cahaya tiap zona, rock = terang batu & kristal (memucat
     * saat membatu), flow = geser tekstur inti (mengalir) & kilau kristal, ground = tinggi tanah di bawah telapak yang
     * menapak, only = cuma lapisan ini (ROCK / VEIN / CORE / CRYSTAL / SHINE), atau -1 = semua.
     */
    public static void render(KalderaBody.Pose p, float[] gain, float rock, float flow, Ground ground, int only, Sink sink) {
        build();
        float[] bm = bodyMatrix(p);
        float[] hm = headMatrix(bm, p);
        float[] jm = jawMatrix(hm, p);
        emit(body, bm, gain, flow, rock, only, sink);
        emit(head, hm, gain, flow, rock, only, sink);
        emit(jaw, jm, gain, flow, rock, only, sink);
        float[] hint = new float[3], k = new float[4];
        for (int i = 0; i < 4; i++) {
            float hx = KalderaBody.HIP[i * 3], hy = KalderaBody.HIP[i * 3 + 1], hz = KalderaBody.HIP[i * 3 + 2];
            float[] hip = {bm[0] * hx + bm[1] * hy + bm[2] * hz + bm[3], bm[4] * hx + bm[5] * hy + bm[6] * hz + bm[7],
                    bm[8] * hx + bm[9] * hy + bm[10] * hz + bm[11]};
            float fx, fy, fz;
            if (p.planted[i]) {
                fx = p.foot[i * 3];
                fz = p.foot[i * 3 + 2];
                fy = ground.at(i, fx, fz) + p.foot[i * 3 + 1];
            } else {
                float x = p.foot[i * 3], y = p.foot[i * 3 + 1], z = p.foot[i * 3 + 2];
                fx = bm[0] * x + bm[1] * y + bm[2] * z + bm[3];
                fy = bm[4] * x + bm[5] * y + bm[6] * z + bm[7];
                fz = bm[8] * x + bm[9] * y + bm[10] * z + bm[11];
            }
            float ay = fy + 3.2f;   // pergelangan: di atas telapak
            KalderaBody.kneeHint(i, hint);
            KalderaBody.knee(hip[0], hip[1], hip[2], fx, ay, fz, hint[0], hint[1], hint[2], k);
            leg(kits[i], hip, new float[]{k[0], k[1], k[2]}, new float[]{fx, ay, fz}, fy, gain, rock, only, sink);
        }
    }

    /** Satu kaki: berkas tiang paha (pinggul -> lutut), sendi inti, berkas tiang betis (lutut -> pergelangan), telapak. */
    private static void leg(LegKit kit, float[] hip, float[] knee, float[] ankle, float footY, float[] gain, float rock, int only,
                            Sink sink) {
        LegOut out = new LegOut(sink, gain, rock, only);
        bundle(out, kit.ox, kit.oz, kit.r, kit.e0, kit.e1, kit.tw, hip, knee, 0.95f);
        bundle(out, kit.lox, kit.loz, kit.lr, kit.le0, kit.le1, kit.tw, knee, ankle, 0.85f);
        out.coreBall(knee[0], knee[1], knee[2], 4.2f);
        for (int i = 0; i < 7; i++) {   // telapak: tiang-tiang batu pendek yang melebar
            float x = ankle[0] + kit.px[i], z = ankle[2] + kit.pz[i];
            out.column(x, footY + kit.ph[i], z, x * 1f + kit.px[i] * 0.12f, footY - 0.3f, z + kit.pz[i] * 0.12f, kit.pr[i] * 0.85f,
                    kit.pr[i], kit.tw[i], 0.55f, false);
        }
    }

    private static void bundle(LegOut out, float[] ox, float[] oz, float[] r, float[] e0, float[] e1, float[] tw, float[] a, float[] b,
                               float shade) {
        float dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
        float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dl < 1.0E-3f) {
            return;
        }
        dx /= dl;
        dy /= dl;
        dz /= dl;
        // sumbu potongan: u = d x Z, w = d x u
        float ux = dy, uy = -dx, uz = 0f;
        float ul = (float) Math.sqrt(ux * ux + uy * uy);
        if (ul < 1.0E-3f) {
            ux = 1f;
            uy = 0f;
            ul = 1f;
        }
        ux /= ul;
        uy /= ul;
        float wx = dy * uz - dz * uy, wy = dz * ux - dx * uz, wz = dx * uy - dy * ux;
        for (int i = 0; i < 7; i++) {
            float sx = ux * ox[i] + wx * oz[i], sy = uy * ox[i] + wy * oz[i], sz = uz * ox[i] + wz * oz[i];
            out.column(a[0] + sx - dx * e0[i], a[1] + sy - dy * e0[i], a[2] + sz - dz * e0[i], b[0] + sx + dx * e1[i],
                    b[1] + sy + dy * e1[i], b[2] + sz + dz * e1[i], r[i], r[i] * 0.92f, tw[i], shade, true);
        }
    }

    /** Keluaran kaki langsung ke sink (sudah di ruang lokal). */
    private static final class LegOut {
        final Sink sink;
        final float[] gain;
        final float rock;
        final int only;

        LegOut(Sink sink, float[] gain, float rock, int only) {
            this.sink = sink;
            this.gain = gain;
            this.rock = rock;
            this.only = only;
        }

        void quad(int layer, float[] a, float[] b, float[] c, float[] d, float rx, float ry, float rz, float tint, int zone) {
            if (only >= 0 && layer != only) {
                return;
            }
            float acx = c[0] - a[0], acy = c[1] - a[1], acz = c[2] - a[2];
            float bdx = d[0] - b[0], bdy = d[1] - b[1], bdz = d[2] - b[2];
            float nx = acy * bdz - acz * bdy, ny = acz * bdx - acx * bdz, nz = acx * bdy - acy * bdx;
            float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (nl < 1.0E-6f) {
                return;
            }
            nx /= nl;
            ny /= nl;
            nz /= nl;
            float mx = (a[0] + b[0] + c[0] + d[0]) * 0.25f - rx, my = (a[1] + b[1] + c[1] + d[1]) * 0.25f - ry,
                    mz = (a[2] + b[2] + c[2] + d[2]) * 0.25f - rz;
            float[][] p = {a, b, c, d};
            if (nx * mx + ny * my + nz * mz < 0f) {
                nx = -nx;
                ny = -ny;
                nz = -nz;
                p = new float[][]{a, d, c, b};
            }
            float ax = Math.abs(nx), ay = Math.abs(ny), az = Math.abs(nz);
            float tile = layer == CORE ? CORE_TILE : TILE;
            for (float[] q : p) {
                float u, v;
                if (ay >= ax && ay >= az) {
                    u = q[0] / tile;
                    v = q[2] / tile;
                } else if (ax >= az) {
                    u = q[2] / tile;
                    v = -q[1] / tile;
                } else {
                    u = q[0] / tile;
                    v = -q[1] / tile;
                }
                sink.vertex(layer, q[0], q[1], q[2], u, v, nx, ny, nz, tint, zone);
            }
        }

        void column(float ax, float ay, float az, float bx, float by, float bz, float r0, float r1, float twist, float shade,
                    boolean vein) {
            float dx = bx - ax, dy = by - ay, dz = bz - az;
            float dl = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dl < 1.0E-3f) {
                return;
            }
            dx /= dl;
            dy /= dl;
            dz /= dl;
            float hx = Math.abs(dy) < 0.9f ? 0f : 1f, hy = Math.abs(dy) < 0.9f ? 1f : 0f;
            float ux = hy * dz, uy = -hx * dz, uz = hx * dy - hy * dx;
            float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
            ux /= ul;
            uy /= ul;
            uz /= ul;
            float wx = dy * uz - dz * uy, wy = dz * ux - dx * uz, wz = dx * uy - dy * ux;
            float[][] lo = new float[6][], hi = new float[6][];
            for (int k = 0; k < 6; k++) {
                float a = twist * 6.28f + (float) (Math.PI / 3.0 * k);
                float ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                lo[k] = new float[]{ax + (ux * ca + wx * sa) * r0, ay + (uy * ca + wy * sa) * r0, az + (uz * ca + wz * sa) * r0};
                hi[k] = new float[]{bx + (ux * ca + wx * sa) * r1, by + (uy * ca + wy * sa) * r1, bz + (uz * ca + wz * sa) * r1};
            }
            float mx = (ax + bx) * 0.5f, my = (ay + by) * 0.5f, mz = (az + bz) * 0.5f;
            float rs = rock * shade;
            for (int k = 0; k < 6; k++) {
                int k1 = (k + 1) % 6;
                float t = rs * (0.86f + 0.14f * (float) Math.cos(k * 1.7 + twist * 9.0));
                quad(ROCK, lo[k], lo[k1], hi[k1], hi[k], mx, my, mz, t, Z_LEG);
                if (vein) {
                    quad(VEIN, lo[k], lo[k1], hi[k1], hi[k], mx, my, mz, gain[Z_LEG], Z_LEG);
                }
            }
            quad(ROCK, lo[0], lo[1], lo[2], lo[3], mx, my, mz, rs * 0.75f, Z_LEG);
            quad(ROCK, lo[3], lo[4], lo[5], lo[0], mx, my, mz, rs * 0.75f, Z_LEG);
            quad(ROCK, hi[0], hi[1], hi[2], hi[3], mx, my, mz, rs * 0.95f, Z_LEG);
            quad(ROCK, hi[3], hi[4], hi[5], hi[0], mx, my, mz, rs * 0.95f, Z_LEG);
        }

        /** Sendi inti: bola bersegi kecil yang berpijar (lapisan inti). */
        void coreBall(float cx, float cy, float cz, float r) {
            final int lat = 4, lon = 6;
            for (int i = 0; i < lat; i++) {
                double t0 = Math.PI * i / lat, t1 = Math.PI * (i + 1) / lat;
                for (int j = 0; j < lon; j++) {
                    double p0 = Math.PI * 2.0 * j / lon, p1 = Math.PI * 2.0 * (j + 1) / lon;
                    float[] a = sph(cx, cy, cz, r, t0, p0), b = sph(cx, cy, cz, r, t0, p1);
                    float[] c = sph(cx, cy, cz, r, t1, p1), d = sph(cx, cy, cz, r, t1, p0);
                    quad(CORE, a, b, c, d, cx, cy, cz, gain[Z_JOINT], Z_JOINT);
                }
            }
        }

        private static float[] sph(float cx, float cy, float cz, float r, double t, double p) {
            return new float[]{cx + r * (float) (Math.sin(t) * Math.cos(p)), cy + r * (float) Math.cos(t),
                    cz + r * (float) (Math.sin(t) * Math.sin(p))};
        }
    }
}
