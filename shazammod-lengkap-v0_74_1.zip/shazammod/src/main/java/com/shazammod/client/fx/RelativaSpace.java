package com.shazammod.client.fx;

import com.shazammod.client.anim.Ease;
import com.shazammod.client.vfx.Draw;
import com.shazammod.client.vfx.Effect;
import com.shazammod.client.vfx.Fx;
import com.shazammod.client.vfx.Hd;
import com.shazammod.client.vfx.Lightning;
import com.shazammod.client.vfx.Vfx;
import com.shazammod.relativa.RelativaClientState;
import com.shazammod.relativa.RelativaNetwork;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.Vec3;

/**
 * 0.70 Efek empat kuasa ruang-waktu RELATIVA (semua dari mesin efek mod ini):
 *
 *   Jembatan Einstein-Rosen   mulut bola lubang cacing: tenggorokan gelap berwarna dimensi seberang (Nether merah bara,
 *                             End ungu berbintang, Overworld biru langit), pinggiran Fresnel, cincin Einstein + citra
 *                             kedua, pemandangan "terowongan" yang mengalir keluar dari pusatnya, lengan spiral, materi
 *                             yang berputar jatuh, dan lensa gravitasi (shader) di sekelilingnya
 *   Foton Tanpa Massa         badan bercahaya, jejak paket gelombang foton (pita sinus kuning-putih), bayangan cahaya
 *                             saat mendekati c
 *   Kucing Schrödinger        kotak Schrödinger yang terbuka, salinan yang muncul dari cahaya, runtuh jadi partikel
 *   Cincin Einstein           cuma lengkungan cahaya (lensa di shader) + kilau Fresnel sangat tipis di tepi badan
 */
final class RelativaSpace {
    private RelativaSpace() {}

    private static final Vec3 UP = new Vec3(0, 1, 0);

    /** Warna mulut menurut dimensi seberangnya: {pinggir, pendar, tenggorokan, langit, bintang1, bintang2, bintang3}. */
    static int[] palette(String dim) {
        return switch (dim) {
            case "minecraft:the_nether" -> new int[] {0xFF8A3A, 0xFF4A14, 0x2A0602, 0xFF6A1E, 0xFFC060, 0xFF5020, 0xFFE8B0};
            case "minecraft:the_end" -> new int[] {0xD0A0FF, 0x8A4DFF, 0x07030F, 0x5A2A9A, 0xFFFFFF, 0xE0C8FF, 0xFFF2B0};
            case "minecraft:overworld" -> new int[] {0x9CE6FF, 0x3FA8FF, 0x0A1A2E, 0x6FC8FF, 0xFFFFFF, 0xA8FF9C, 0x9CD8FF};
            default -> {
                float h = (dim.hashCode() & 0xFFFF) / 65535f;
                int rim = hsv(h, 0.55f, 1f), glow = hsv(h, 0.8f, 0.95f), sky = hsv(h, 0.7f, 0.8f);
                yield new int[] {rim, glow, 0x08080C, sky, 0xFFFFFF, rim, hsv(h + 0.15f, 0.4f, 1f)};
            }
        };
    }

    private static int hsv(float h, float s, float v) {
        return Mth.hsvToRgb(((h % 1f) + 1f) % 1f, s, v) & 0xFFFFFF;
    }

    /** Dua sumbu bidang yang menghadap kamera (tegak lurus arah ke kamera). */
    private static Vec3[] facing(Vec3 tc) {
        Vec3 a = Math.abs(tc.y) > 0.95 ? new Vec3(1, 0, 0) : UP;
        Vec3 e1 = a.cross(tc).normalize();
        return new Vec3[] {e1, tc.cross(e1).normalize()};
    }

    // ================================================================== Jembatan Einstein-Rosen

    /** Satu mulut lubang cacing (bola). Hidup sampai server mengabarkan menutup (atau umurnya lewat). */
    static final class Mouth extends Effect implements RelativaEffects.Lensing {
        static final int GROW = 14, CLOSE = 12, STARS = 44, ARMS = 3;
        final int key;
        final Vec3 c;
        final double radius;
        final int[] pal;
        private final ClientLevel level;
        private final int openAge, limit;
        private final float[] sa = new float[STARS], sv = new float[STARS], sp = new float[STARS];
        private final int[] sc = new int[STARS];
        private final float seed;
        private int closeAt = -1;
        private boolean dead;

        Mouth(ClientLevel level, int key, Vec3 c, double radius, String partner, int serverAge, int life) {
            super(Integer.MAX_VALUE / 4);
            this.level = level;
            this.key = key;
            this.c = c;
            this.radius = radius;
            this.pal = palette(partner);
            this.openAge = Math.max(0, serverAge);
            this.limit = Math.max(40, life - serverAge + 60);
            RandomSource r = Vfx.random();
            for (int i = 0; i < STARS; i++) {
                sa[i] = r.nextFloat() * Mth.TWO_PI;
                sv[i] = 0.012f + r.nextFloat() * 0.03f;
                sp[i] = r.nextFloat();
                sc[i] = pal[4 + r.nextInt(3)];
            }
            this.seed = r.nextFloat() * 100f;
        }

        boolean dead() {
            return dead;
        }

        boolean closing() {
            return closeAt >= 0;
        }

        void shut() {
            if (closeAt < 0) {
                closeAt = age;
            }
        }

        /** 0..1 besar mulut: mengembang (OUT_BACK) saat terbuka, menciut saat menutup. */
        private float grow(float t) {
            float open = openAge + t;
            float g = open >= GROW ? 1f : Ease.OUT_BACK.apply(Mth.clamp(open / GROW, 0f, 1f));
            if (closeAt >= 0) {
                g *= 1f - Ease.IN_QUAD.apply(Mth.clamp((t - closeAt) / CLOSE, 0f, 1f));
            }
            return Math.max(0f, g);
        }

        @Override
        public boolean tick(ClientLevel lvl) {
            if (dead || lvl != level) {
                dead = true;
                return false;
            }
            if (closeAt >= 0 && age - closeAt >= CLOSE) {   // runtuh: kilat & materi tersedot habis
                Vfx.add(new Fx.Flash(c, (float) radius * 1.6f, RelativaFx.hot(pal[0]), 8, 0.9f));
                CineKit.motesOut(c, 26, pal[0], 0.16, 0.06f, 14);
                Vfx.add(new Hd.Pressure(c, UP, radius * 3.0, Math.PI, pal[0], 10, 0.6f, true));
                dead = true;
                return false;
            }
            if (age > limit) {
                dead = true;
                return false;
            }
            float g = grow(age);
            RandomSource r = lvl.random;
            for (int k = 0, n = Vfx.count(3); k < n && g > 0.2f; k++) {   // materi & cahaya yang berputar jatuh ke mulut
                Vec3 o = ShazamFx.randomDir(r).scale(radius * (2.2 + r.nextDouble() * 1.4));
                Vec3 in = o.scale(-1).normalize();
                Vec3 swirl = UP.cross(in);
                swirl = swirl.lengthSqr() < 1.0E-4 ? Vec3.ZERO : swirl.normalize().scale(0.08);
                Vec3 v = in.scale(0.12).add(swirl);
                Vfx.mote(c.x + o.x, c.y + o.y, c.z + o.z, v.x, v.y, v.z, r.nextBoolean() ? pal[0] : pal[4], 0.05f, 16);
            }
            return super.tick(lvl);
        }

        @Override
        public boolean alive() {
            return !dead;
        }

        @Override
        public float[] lens(float pt) {
            float g = grow(time(pt));
            if (g <= 0.02f) {
                return null;
            }
            double r = radius * g;
            return new float[] {(float) c.x, (float) c.y, (float) c.z, (float) (r * 1.15), 0f, 0f, 0.85f * Math.min(1f, g)};
        }

        @Override
        public void renderSoft(Draw d) {
            float g = grow(time(d.partialTick));
            if (g <= 0.01f) {
                return;
            }
            Vec3 tc = RelativaEffects.toCam(d, c);
            d.disc(c.x, c.y, c.z, tc.x, tc.y, tc.z, radius * g * 0.97, pal[2], 0.9f * Math.min(1f, g), 0.45f * Math.min(1f, g),
                    null);
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float g = grow(t);
            if (g <= 0.01f) {
                return;
            }
            float a = Math.min(1f, g);
            double r = radius * g * (1.0 + 0.025 * Math.sin((t + seed) * 0.21));
            Vec3 tc = RelativaEffects.toCam(d, c);
            Vec3[] e = facing(tc);
            // langit seberang terlihat di tenggorokannya, pendar luar, kulit bola Fresnel
            d.glow(c.x, c.y, c.z, (float) (r * 0.62), pal[3], 0.55f * a);
            d.glow(c.x, c.y, c.z, (float) (r * 2.3), pal[1], 0.22f * a);
            d.shell(c.x, c.y, c.z, r, pal[0], 0.8f * a, 2.4, 1.0);
            // cincin Einstein (cahaya dari belakang yang dibelokkan) + citra keduanya yang lebih redup di luar
            d.ring(c.x, c.y, c.z, tc.x, tc.y, tc.z, r * 1.03, r * 0.1, RelativaFx.hot(pal[0]), 0.95f * a, 0f, null);
            d.ring(c.x, c.y, c.z, tc.x, tc.y, tc.z, r * 1.42, r * 0.045, pal[0], 0.35f * a, 0f, null);
            // pemandangan terowongan: bintang / bara / cahaya dari seberang mengalir keluar dari pusatnya, makin cepat
            for (int i = 0; i < STARS; i++) {
                float f = (sp[i] + (t + seed) * sv[i]) % 1f;
                double rr = Math.pow(f, 1.7) * r * 0.95;
                double rr0 = Math.max(0.0, rr - r * (0.04 + 0.16 * f));
                double ca = Math.cos(sa[i]), sn = Math.sin(sa[i]);
                double dx = e[0].x * ca + e[1].x * sn, dy = e[0].y * ca + e[1].y * sn, dz = e[0].z * ca + e[1].z * sn;
                float al = a * f * (1f - f * 0.35f);
                d.line(c.x + dx * rr0, c.y + dy * rr0, c.z + dz * rr0, c.x + dx * rr, c.y + dy * rr, c.z + dz * rr,
                        0.02f, (float) (0.03 + 0.05 * f), sc[i], al * 0.4f, al);
            }
            // lengan spiral yang berputar (ruang-waktu terpilin ke dalam tenggorokan)
            int n = 18;
            for (int k = 0; k < ARMS; k++) {
                float[] pts = new float[n * 3];
                double base = k * Mth.TWO_PI / ARMS + t * 0.06;
                for (int j = 0; j < n; j++) {
                    double q = j / (double) (n - 1);
                    double rad = r * (0.12 + 0.86 * q);
                    double ang = base + q * 2.4;
                    double ca = Math.cos(ang), sn = Math.sin(ang);
                    pts[j * 3] = (float) (c.x + (e[0].x * ca + e[1].x * sn) * rad);
                    pts[j * 3 + 1] = (float) (c.y + (e[0].y * ca + e[1].y * sn) * rad);
                    pts[j * 3 + 2] = (float) (c.z + (e[0].z * ca + e[1].z * sn) * rad);
                }
                d.polyline(pts, n, 0.03f, (float) (r * 0.09), pal[1], pal[0], 0.1f * a, 0.4f * a);
            }
        }
    }

    // ================================================================== Foton Tanpa Massa

    /** Badan bercahaya + jejak paket gelombang foton tiap pemain yang memakai Foton Tanpa Massa. */
    static final class PhotonTrail extends Effect {
        private static final int N = 24;
        private final AbstractClientPlayer p;
        private final double[] hx = new double[N], hy = new double[N], hz = new double[N];
        private int count;
        private Vec3 last, vel = Vec3.ZERO;
        private double speed;

        PhotonTrail(AbstractClientPlayer p) {
            super(Integer.MAX_VALUE / 4);
            this.p = p;
        }

        boolean dead() {
            return p.isRemoved() || (RelativaClientState.flags(p.getId()) & RelativaNetwork.FLAG_PHOTON) == 0;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (dead()) {
                return false;
            }
            Vec3 c = p.position().add(0, p.getBbHeight() * 0.55, 0);
            if (last != null) {
                Vec3 v = c.subtract(last);
                if (v.lengthSqr() > 64.0) {   // pindah (lubang cacing): jejaknya mulai lagi
                    v = Vec3.ZERO;
                    count = 0;
                }
                vel = v;
                speed = speed * 0.6 + v.length() * 0.4;
            }
            last = c;
            System.arraycopy(hx, 0, hx, 1, N - 1);
            System.arraycopy(hy, 0, hy, 1, N - 1);
            System.arraycopy(hz, 0, hz, 1, N - 1);
            hx[0] = c.x;
            hy[0] = c.y;
            hz[0] = c.z;
            count = Math.min(N, count + 1);
            boolean shown = !p.isInvisible();
            if (shown && speed > 1.8 && age % 2 == 0) {   // mendekati c: bayangan cahaya berderet
                Vfx.add(new Hd.Ghost(p.position(), p.yBodyRot, p.getBbHeight() / 1.8, 1, RelativaFx.PHOTON, 0xFFFFFF, 8,
                        Math.min(0.7f, (float) (speed * 0.18))));
            }
            if (shown && speed > 0.4 && age % 2 == 1) {
                RandomSource r = level.random;
                Vec3 back = vel.lengthSqr() > 1.0E-6 ? vel.normalize().scale(-0.4) : Vec3.ZERO;
                Vfx.streak(c.x + (r.nextDouble() - 0.5) * 0.6, c.y + (r.nextDouble() - 0.5) * 1.0, c.z + (r.nextDouble() - 0.5) * 0.6,
                        back.x, back.y, back.z, r.nextBoolean() ? RelativaFx.PHOTON : 0xFFFFFF, 0.05f, 8);
            }
            return super.tick(level);
        }

        @Override
        public void renderGlow(Draw d) {
            if (p.isInvisible()) {
                return;
            }
            float pt = d.partialTick;
            float a = Mth.clamp(time(pt) / 8f, 0f, 1f);
            Vec3 c = p.getPosition(pt).add(0, p.getBbHeight() * 0.55, 0);
            boolean fp = HdKit.firstPerson(p);
            if (!fp) {   // badan dari cahaya: inti terang & kulit tipis
                d.flare(c.x, c.y, c.z, 0.42f, RelativaFx.PHOTON, 0.45f * a);
                d.shell(c.x, c.y, c.z, p.getBbHeight() * 0.55, RelativaFx.PHOTON, 0.16f * a, 3.0, 1.0);
            }
            if (count < 3 || speed < 0.15) {
                return;
            }
            int n = count;
            float[] pts = new float[n * 3];
            float[] wav = new float[n * 3];
            float[] w = new float[n], al = new float[n];
            Vec3 dir = vel.lengthSqr() > 1.0E-6 ? vel.normalize() : new Vec3(0, 0, 1);
            Vec3 side = dir.cross(UP);
            side = side.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : side.normalize();
            float time = time(pt);
            for (int i = 0; i < n; i++) {
                double x = i == 0 ? c.x : hx[i], y = i == 0 ? c.y : hy[i], z = i == 0 ? c.z : hz[i];
                pts[i * 3] = (float) x;
                pts[i * 3 + 1] = (float) y;
                pts[i * 3 + 2] = (float) z;
                float f = i / (float) (n - 1);
                // paket gelombang: amplitudo naik lalu turun di sepanjang jejak (selubung Gauss), osilasi E tegak lurus
                double env = Math.exp(-Math.pow((f - 0.35) / 0.22, 2.0)) * 0.55;
                double osc = Math.sin(i * 1.6 - time * 0.9) * env;
                wav[i * 3] = (float) (x + side.x * osc);
                wav[i * 3 + 1] = (float) (y + osc * 0.6);
                wav[i * 3 + 2] = (float) (z + side.z * osc);
                w[i] = 0.38f * (1f - f) + 0.02f;
                al[i] = a * Math.min(1f, (float) speed * 1.5f) * (1f - f);
            }
            d.polyline(pts, n, w, al, RelativaFx.PHOTON, 0xFFFFFF);
            float[] w2 = new float[n];
            for (int i = 0; i < n; i++) {
                w2[i] = 0.07f;
            }
            d.polyline(wav, n, w2, al, RelativaFx.LIGHT, 0xFFFFFF);
        }
    }

    // ================================================================== Kucing Schrödinger

    /** Kotak Schrödinger dari garis cahaya di sekeliling badan; tutupnya terbuka sampai split, lalu kotaknya pecah. */
    static final class QuantumBox extends Effect {
        private final AbstractClientPlayer p;
        private final int split;

        QuantumBox(AbstractClientPlayer p, int split) {
            super(split + 10);
            this.p = p;
            this.split = split;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float a = RelativaFx.fade(t, life, 3f, 9f);
            Vec3 f = p.getPosition(d.partialTick);
            double h = p.getBbHeight() * 1.15, w = p.getBbWidth() * 1.6;
            double grow = t > split ? 1.0 + (t - split) * 0.25 : 1.0;   // pecah: rusuknya terlempar keluar
            double hw = w * grow, x0 = f.x - hw, x1 = f.x + hw, z0 = f.z - hw, z1 = f.z + hw, y0 = f.y, y1 = f.y + h * grow;
            int col = RelativaFx.QUANTUM;
            float lw = 0.05f;
            // rusuk bawah & tegak
            edge(d, x0, y0, z0, x1, y0, z0, lw, col, a);
            edge(d, x1, y0, z0, x1, y0, z1, lw, col, a);
            edge(d, x1, y0, z1, x0, y0, z1, lw, col, a);
            edge(d, x0, y0, z1, x0, y0, z0, lw, col, a);
            edge(d, x0, y0, z0, x0, y1, z0, lw, col, a);
            edge(d, x1, y0, z0, x1, y1, z0, lw, col, a);
            edge(d, x1, y0, z1, x1, y1, z1, lw, col, a);
            edge(d, x0, y0, z1, x0, y1, z1, lw, col, a);
            // tutup: berengsel di rusuk belakang, terbuka sampai 110° saat split
            double open = Math.toRadians(110.0) * Ease.IN_OUT_SINE.apply(Mth.clamp(t / split, 0f, 1f));
            double depth = z1 - z0;
            double ly = y1 + Math.sin(open) * depth, lz = z0 + Math.cos(open) * depth;
            edge(d, x0, y1, z0, x1, y1, z0, lw, col, a);
            edge(d, x0, y1, z0, x0, ly, lz, lw, col, a);
            edge(d, x1, y1, z0, x1, ly, lz, lw, col, a);
            edge(d, x0, ly, lz, x1, ly, lz, lw, col, a);
            if (t < split) {   // cahaya superposisi bocor dari celah tutupnya
                d.glow(f.x, y1, f.z, (float) (0.6 + 0.8 * t / split), RelativaFx.QUANTUM, 0.4f * a * t / split);
            }
        }

        private static void edge(Draw d, double ax, double ay, double az, double bx, double by, double bz, float w, int rgb,
                                 float a) {
            d.line(ax, ay, az, bx, by, bz, w, w, rgb, a, a);
        }
    }

    // ================================================================== Cincin Einstein

    /**
     * Lensa di sekeliling badan yang tak terlihat (dibaca shader lensa): makin cepat bergerak makin jelas lengkungannya.
     * Di dunia cuma kilau Fresnel yang sangat tipis (kalau shader nggak bisa dipakai, sedikit lebih jelas).
     */
    static final class CloakLens extends Effect implements RelativaEffects.Lensing {
        private final AbstractClientPlayer p;
        private Vec3 last;
        private double speed;
        private boolean dead;

        CloakLens(AbstractClientPlayer p) {
            super(Integer.MAX_VALUE / 4);
            this.p = p;
        }

        boolean dead() {
            return dead || p.isRemoved() || (RelativaClientState.flags(p.getId()) & RelativaNetwork.FLAG_CLOAK) == 0;
        }

        @Override
        public boolean tick(ClientLevel level) {
            if (dead()) {
                dead = true;
                return false;
            }
            Vec3 now = p.position();
            if (last != null) {
                double v = now.distanceTo(last);
                speed = speed * 0.7 + (v > 8.0 ? 0.0 : v) * 0.3;
            }
            last = now;
            return super.tick(level);
        }

        @Override
        public boolean alive() {
            return !dead();
        }

        @Override
        public float[] lens(float pt) {
            float a = Mth.clamp(time(pt) / 10f, 0f, 1f);
            Vec3 c = RelativaEffects.chestOf(p, pt);
            double k = Math.min(1.0, speed * 2.5);
            return new float[] {(float) c.x, (float) c.y, (float) c.z, (float) (0.85 + 0.35 * k), 0f, 0f,
                    a * (float) (0.45 + 0.4 * k)};
        }

        @Override
        public void renderGlow(Draw d) {
            if (HdKit.firstPerson(p)) {
                return;
            }
            float t = time(d.partialTick);
            float a = Mth.clamp(t / 10f, 0f, 1f);
            Vec3 c = RelativaEffects.chestOf(p, d.partialTick);
            float flicker = 0.5f + 0.5f * Mth.sin(t * 0.37f) * Mth.sin(t * 0.13f + 1.3f);
            float k = RelativaLensShader.usable() ? 0.05f : 0.12f;
            boolean self = p == Minecraft.getInstance().player;
            d.shell(c.x, c.y - p.getBbHeight() * 0.1, c.z, p.getBbHeight() * 0.62, 0xD8E8FF, (self ? 0.12f : k) * a
                    * (0.6f + 0.4f * flicker) * (float) (1.0 + speed * 3.0), 4.0, 1.0);
            if (speed > 0.12) {   // bergerak cepat: cincin tipis berkilau sesaat
                Vec3 tc = RelativaEffects.toCam(d, c);
                d.ring(c.x, c.y, c.z, tc.x, tc.y, tc.z, p.getBbHeight() * 0.58, 0.04, 0xFFFFFF,
                        (float) Math.min(0.3, speed * 0.6) * a * flicker, 0f, null);
            }
        }
    }

    /** Cincin Einstein terbentuk: cincin cahaya menyempit ke badan (on) atau mengembang lepas dari badan (off). */
    static final class LensRing extends Effect {
        private final AbstractClientPlayer p;
        private final boolean on;

        LensRing(AbstractClientPlayer p, boolean on, int life) {
            super(life);
            this.p = p;
            this.on = on;
        }

        @Override
        public void renderGlow(Draw d) {
            float t = time(d.partialTick);
            float f = Mth.clamp(t / life, 0f, 1f);
            float k = on ? Ease.IN_QUAD.apply(f) : Ease.OUT_CUBIC.apply(f);
            Vec3 c = RelativaEffects.chestOf(p, d.partialTick);
            Vec3 tc = RelativaEffects.toCam(d, c);
            double h = p.getBbHeight();
            double r = on ? Mth.lerp(k, h * 2.2, h * 0.5) : Mth.lerp(k, h * 0.5, h * 2.6);
            float a = on ? 0.3f + 0.7f * k : 1f - k;
            d.ring(c.x, c.y, c.z, tc.x, tc.y, tc.z, r, 0.09 + 0.05 * (1 - k), 0xEAF2FF, 0.85f * a, 0.05f, null);
            d.ring(c.x, c.y, c.z, tc.x, tc.y, tc.z, r * 1.35, 0.035, RelativaFx.RELATIV, 0.4f * a, 0f, null);
            // berkas cahaya dari belakang yang dibelokkan mengitari badan: busur-busur tipis
            Vec3[] e = facing(tc);
            int arcs = 6, n = 10;
            for (int i = 0; i < arcs; i++) {
                double base = i * Mth.TWO_PI / arcs + t * 0.05 * (on ? 1 : -1);
                float[] pts = new float[n * 3];
                for (int j = 0; j < n; j++) {
                    double ang = base + (j / (double) (n - 1)) * 0.9;
                    double rad = r * (1.08 + 0.12 * Math.sin(j * 0.7));
                    double ca = Math.cos(ang), sn = Math.sin(ang);
                    pts[j * 3] = (float) (c.x + (e[0].x * ca + e[1].x * sn) * rad);
                    pts[j * 3 + 1] = (float) (c.y + (e[0].y * ca + e[1].y * sn) * rad);
                    pts[j * 3 + 2] = (float) (c.z + (e[0].z * ca + e[1].z * sn) * rad);
                }
                d.polyline(pts, n, 0.03f, 0.03f, RelativaFx.LIGHT, 0xFFFFFF, 0.1f * a, 0.6f * a);
            }
        }
    }

    // ================================================================== bantuan

    static Lightning.Anchor above(AbstractClientPlayer p, double dy) {
        return Lightning.Anchor.on(p, 0, p.getBbHeight() + dy, 0);
    }
}
