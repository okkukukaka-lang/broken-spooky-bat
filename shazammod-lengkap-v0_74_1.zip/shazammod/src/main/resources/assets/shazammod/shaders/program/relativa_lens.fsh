#version 150

// RELATIVA - shader layar.
//  1) 0.67 optik relativistik (Kecepatan Cahaya & Lesat Cahaya), dari rumus relativitas khusus:
//     aberasi    cos θs = (cos θo − β) / (1 − β cos θo): pandangan memampat ke arah gerak. Rentang sudut layar dinormalisasi
//                supaya seluruh layar tetap terlihat (kalau persis 1:1, di β tinggi dunia menciut jadi satu titik).
//     Doppler    D = 1 / (γ (1 − β cos θo)): tiap kanal warna mengambil panjang gelombang sumber λs = λo · D^0,55
//                (biru di depan, merah di belakang / samping yang menjauh)
//     beaming    terang dikali D^1,1 (cahaya terkumpul ke arah gerak)
//     ditambah garis kecepatan yang memancar dari titik tujuan gerak.
//  2) lensa gravitasi lubang hitam (pendekatan lensa tipis, β = θ − θE² / θ), bayangan, dan cincin foton.
//  3) 0.67 waktu dunia berhenti (warna memudar dingin + vinyet) dan gelombang "waktu berhenti / berjalan lagi".
//  4) 0.67 kilau Terowongan Kuantum di pinggir layar (warna terbelah + pinggiran interferensi).

uniform sampler2D DiffuseSampler;

uniform vec2 InSize;
uniform float Clock;        // detik (jam asli, tetap jalan walau dunia membeku)
uniform float CenterX;      // lensa gravitasi
uniform float CenterY;
uniform float Lens;
uniform float Shadow;
uniform float Ring;
uniform float Beta;         // 0..~0,5 kecepatan (visual), 0 = mati
uniform float MotionX;      // arah gerak di ruang pandang (kamera menghadap −Z), vektor satuan
uniform float MotionY;
uniform float MotionZ;
uniform float TanX;         // tan(setengah FOV)
uniform float TanY;
uniform float ThetaLo;      // rentang sudut layar terhadap arah gerak (radian)
uniform float ThetaHi;
uniform float SrcLo;        // rentang sudut sumber hasil aberasi
uniform float SrcHi;
uniform float StreakX;      // titik layar asal garis kecepatan
uniform float StreakY;
uniform float Frozen;       // 0..1 waktu dunia berhenti
uniform float Pulse;        // 0..1 gelombang waktu (0 = nggak ada)
uniform float Phase;        // 0..1 kilau Terowongan Kuantum

in vec2 texCoord;

out vec4 fragColor;

vec3 fetch(vec2 uv) {
    return texture(DiffuseSampler, clamp(uv, vec2(0.0005), vec2(0.9995))).rgb;
}

// spektrum kira-kira dari RGB: biru 465 nm, hijau 550 nm, merah 610 nm, ekor UV / inframerah memudar
float spectrum(vec3 c, float lam) {
    if (lam <= 465.0) {
        return c.b * clamp((lam - 380.0) / 85.0, 0.0, 1.0);
    }
    if (lam <= 550.0) {
        return mix(c.b, c.g, (lam - 465.0) / 85.0);
    }
    if (lam <= 610.0) {
        return mix(c.g, c.r, (lam - 550.0) / 60.0);
    }
    return c.r * exp(-(lam - 610.0) / 260.0);
}

void main() {
    float aspect = InSize.x / max(InSize.y, 1.0);
    vec2 scale = vec2(aspect, 1.0);
    vec2 uv = texCoord;
    float ringGlow = 0.0;

    // gelombang waktu: cincin yang menyebar dari tengah layar dan membelokkan gambar
    if (Pulse > 0.0005) {
        vec2 d = (uv - 0.5) * scale;
        float r = length(d);
        float x = (r - Pulse * 1.35) / (0.07 + 0.05 * Pulse);
        float k = exp(-x * x) * (1.0 - Pulse);
        if (r > 0.0001) {
            uv += d / r * k * 0.045 / scale;
        }
        ringGlow = k;
    }

    // aberasi relativistik
    float doppler = 1.0;
    if (Beta > 0.0005) {
        vec3 m = vec3(MotionX, MotionY, MotionZ);
        vec2 ndc = uv * 2.0 - 1.0;
        vec3 dir = normalize(vec3(ndc.x * TanX, ndc.y * TanY, -1.0));
        float cosO = clamp(dot(dir, m), -1.0, 1.0);
        float cs = clamp((cosO - Beta) / (1.0 - Beta * cosO), -1.0, 1.0);
        float ths = acos(cs);
        float thp = ThetaLo + (ths - SrcLo) * (ThetaHi - ThetaLo) / max(SrcHi - SrcLo, 0.0001);
        vec3 perp = dir - m * cosO;
        float sl = length(perp);
        if (sl > 0.00001) {
            perp /= sl;
            vec3 dp = m * cos(thp) + perp * sin(thp);
            float z = min(dp.z, -0.05);
            uv = vec2(dp.x / (-z * TanX), dp.y / (-z * TanY)) * 0.5 + 0.5;
        }
        float gamma = inversesqrt(max(1.0 - Beta * Beta, 0.0001));
        doppler = 1.0 / (gamma * (1.0 - Beta * cosO));
    }

    // lensa gravitasi
    float shadow = 0.0;
    float ring = 0.0;
    if (Lens > 0.0005) {
        vec2 c = vec2(CenterX, CenterY);
        vec2 d = (uv - c) * scale;
        float th = max(length(d), 0.00001);
        vec2 dir2 = d / th;
        float fall = 1.0 / (1.0 + pow(th / (Lens * 7.0), 2.0));
        float beta = th - (Lens * Lens / th) * fall;
        uv = c + dir2 * beta / scale;
        if (Shadow > 0.0005) {
            shadow = 1.0 - smoothstep(Shadow * 0.94, Shadow * 1.02, th);
            float e = (th - Shadow * 1.06) / max(Shadow * 0.07, 0.0001);
            ring = exp(-e * e) * Ring * (0.9 + 0.1 * sin(Clock * 6.0 + atan(d.y, d.x) * 3.0));
        }
    }

    // ambil warna (dengan garis kecepatan saat bergerak)
    vec3 col;
    if (Beta > 0.0005) {
        vec2 c = vec2(StreakX, StreakY);
        vec2 dd = uv - c;
        float ln = length(dd) + 0.00001;
        vec2 stp = dd / ln * min(ln, 0.6) * Beta * 0.1 / 7.0;
        vec3 acc = vec3(0.0);
        for (int i = 0; i < 8; i++) {
            acc += fetch(uv - stp * float(i));
        }
        col = acc / 8.0;
    } else {
        col = fetch(uv);
    }

    // kilau Terowongan Kuantum: warna terbelah di pinggir layar
    if (Phase > 0.0005) {
        vec2 d = (texCoord - 0.5) * scale;
        float r = length(d);
        float w = smoothstep(0.32, 0.85, r) * Phase;
        vec2 off = (r > 0.0001 ? d / r : vec2(0.0)) * 0.0045 * w / scale;
        col.r = mix(col.r, fetch(uv + off).r, w);
        col.b = mix(col.b, fetch(uv - off).b, w);
    }

    // Doppler & beaming
    if (Beta > 0.0005) {
        float dc = pow(max(doppler, 0.0001), 0.55);
        vec3 shifted = vec3(spectrum(col, 610.0 * dc), spectrum(col, 550.0 * dc), spectrum(col, 465.0 * dc));
        float lum = dot(col, vec3(0.3333));
        shifted = shifted * 0.8 + lum * 0.2 * vec3(clamp(1.6 - dc, 0.0, 1.0), 0.55, clamp(dc - 0.4, 0.0, 1.0));
        shifted *= pow(clamp(doppler, 0.7, 2.0), 1.1);
        shifted = shifted / (1.0 + max(shifted - 1.0, vec3(0.0)) * 0.7);
        col = mix(col, shifted, smoothstep(0.0, 0.08, Beta));
    }

    col = mix(col, vec3(0.0), shadow);
    col += vec3(1.0, 0.82, 0.55) * ring;

    // waktu dunia berhenti
    if (Frozen > 0.0005) {
        float l = dot(col, vec3(0.299, 0.587, 0.114));
        col = mix(col, vec3(l), 0.45 * Frozen);
        col = mix(col, vec3(0.55, 0.78, 1.0) * l * 1.1, 0.18 * Frozen);
        float v = smoothstep(0.45, 1.05, length((texCoord - 0.5) * scale));
        col *= 1.0 - 0.35 * v * Frozen;
    }
    col += vec3(0.75, 0.9, 1.0) * ringGlow * 0.25;

    // pinggiran interferensi ungu (Terowongan Kuantum)
    if (Phase > 0.0005) {
        vec2 d = (texCoord - 0.5) * scale;
        float r = length(d);
        float w = smoothstep(0.32, 0.85, r) * Phase;
        float fr = 0.5 + 0.5 * sin(r * 70.0 - Clock * 2.6 + sin(atan(d.y, d.x) * 5.0 + Clock) * 1.5);
        col += vec3(0.42, 0.26, 0.85) * fr * fr * w * 0.07;
    }

    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
