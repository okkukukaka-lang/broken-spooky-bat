#version 150

// 0.72 Shader Shazam - bloom, jalur naik: tingkat yang lebih kecil diperbesar 2x (filter tenda 8 ketukan) lalu dicampur
// dengan tingkat yang sama dari jalur turun. Hasil akhirnya = rata-rata berbobot pendar sempit sampai pendar sangat lebar.

uniform sampler2D DiffuseSampler;   // tingkat lebih kecil (hasil naik sebelumnya)
uniform sampler2D LevelSampler;     // tingkat ini dari jalur turun

uniform vec2 InSize;
uniform float Spread;
uniform float Wide;   // bobot pendar yang lebih lebar

in vec2 texCoord;

out vec4 fragColor;

vec3 tap(vec2 uv) {
    return texture(DiffuseSampler, uv).rgb;
}

void main() {
    vec2 o = Spread / InSize;
    vec3 c = tap(texCoord + vec2(-2.0 * o.x, 0.0));
    c += tap(texCoord + vec2(-o.x, o.y)) * 2.0;
    c += tap(texCoord + vec2(0.0, 2.0 * o.y));
    c += tap(texCoord + vec2(o.x, o.y)) * 2.0;
    c += tap(texCoord + vec2(2.0 * o.x, 0.0));
    c += tap(texCoord + vec2(o.x, -o.y)) * 2.0;
    c += tap(texCoord + vec2(0.0, -2.0 * o.y));
    c += tap(texCoord + vec2(-o.x, -o.y)) * 2.0;
    c /= 12.0;
    vec3 level = texture(LevelSampler, texCoord).rgb;
    fragColor = vec4((level + c * Wide) / (1.0 + Wide), 1.0);
}
