#version 150

// 0.72 Shader Shazam - sinar dewa: pendar efek diburamkan memancar dari (maksimal) dua sumber cahaya terkuat di layar
// (kilatan ledakan, bola api, sambaran petir). Yang menghalangi cahayanya (tanah, bangunan) sudah gelap di pendar efek,
// jadi berkasnya terlihat menembus celah-celah seperti cahaya sungguhan.

uniform sampler2D DiffuseSampler;   // pendar efek (seperempat layar)

uniform vec2 InSize;
uniform vec4 LightA;   // x, y (0..1 layar, boleh sedikit di luar), kuat, panjang berkas (0..1)
uniform vec4 LightB;
uniform float Aspect;

in vec2 texCoord;

out vec4 fragColor;

const int N = 28;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

vec3 rays(vec4 l, float jitter) {
    if (l.z <= 0.001) {
        return vec3(0.0);
    }
    vec2 delta = (texCoord - l.xy) * (l.w / float(N));
    vec2 p = texCoord - delta * jitter;
    float w = 1.0;
    float norm = 0.0;
    vec3 acc = vec3(0.0);
    for (int i = 0; i < N; i++) {
        p -= delta;
        acc += texture(DiffuseSampler, clamp(p, vec2(0.001), vec2(0.999))).rgb * w;
        norm += w;
        w *= 0.94;
    }
    vec2 d = (texCoord - l.xy) * vec2(Aspect, 1.0);
    float fall = 1.0 / (1.0 + dot(d, d) * 5.0);   // makin jauh dari sumbernya makin redup
    return acc / norm * l.z * fall;
}

void main() {
    float jitter = hash(texCoord * InSize);   // geser awal tiap piksel: berkasnya nggak bertangga
    fragColor = vec4(rays(LightA, jitter) + rays(LightB, jitter), 1.0);
}
