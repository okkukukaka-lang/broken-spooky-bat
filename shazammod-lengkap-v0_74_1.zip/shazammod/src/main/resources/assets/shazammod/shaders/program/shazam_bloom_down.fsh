#version 150

// 0.72 Shader Shazam - bloom, jalur turun: gambar diperkecil 2x dengan filter Kawase ganda (5 ketukan bilinear, kira-kira
// rata-rata 4x4 piksel). Tahap pertama juga memangkas pendar yang sangat redup (Floor) & menguatkannya (Gain).

uniform sampler2D DiffuseSampler;

uniform vec2 InSize;
uniform float Spread;   // jarak ketukan (texel masukan)
uniform float Floor;    // di bawah terang ini pendar diabaikan (0 = semua ikut)
uniform float Gain;

in vec2 texCoord;

out vec4 fragColor;

vec3 tap(vec2 uv) {
    return texture(DiffuseSampler, uv).rgb;
}

void main() {
    vec2 o = Spread / InSize;
    vec3 c = tap(texCoord) * 4.0;
    c += tap(texCoord + vec2(-o.x, -o.y));
    c += tap(texCoord + vec2(o.x, -o.y));
    c += tap(texCoord + vec2(-o.x, o.y));
    c += tap(texCoord + vec2(o.x, o.y));
    c *= 0.125;
    float peak = max(c.r, max(c.g, c.b));
    c *= Gain * smoothstep(Floor, Floor * 2.0 + 0.0001, peak);
    fragColor = vec4(c, 1.0);
}
