#version 150

// 0.72 Shader Shazam - gabungan akhir (layar penuh), urutannya:
//  1. pembiasan: tepi gelombang tekanan (cincin di tanah & gelembung udara) membengkokkan gambar di belakangnya dan memecah
//     warnanya sedikit (aberasi kromatik); udara di atas bola api & plasma beriak. Yang lebih dekat ke kamera daripada
//     gelombangnya nggak ikut bengkok (dicek dari kedalaman dunia);
//  2. hantaman besar (dari guncangan kamera): zoom kabur ke tengah, aberasi kromatik, vinyet;
//  3. bloom pendar efek + sinar dewa, dicampur "screen" (menambah cahaya tanpa pernah bikin layar putih semua);
//  4. dither halus supaya gradasi pendarnya nggak bertangga.

uniform sampler2D DiffuseSampler;   // gambar dunia
uniform sampler2D BloomSampler;     // pendar efek yang sudah diburamkan (seperempat layar)
uniform sampler2D RaysSampler;      // sinar dewa (seperempat layar)
uniform sampler2D DepthSampler;     // kedalaman dunia

uniform vec2 InSize;
uniform float Clock;    // detik (jam asli, berulang tiap jam)
uniform float Bloom;    // kuat bloom
uniform float Rays;     // kuat sinar dewa
uniform float Impact;   // 0..1 hantaman besar
uniform float Chroma;   // pengali aberasi kromatik pembiasan
uniform vec2 Proj;      // (m22, m32) matriks proyeksi: kedalaman layar -> jarak (blok)

// tiap sumber pembiasan (maksimal 6):
//   A = (pusat x, pusat y, baris 1 matriks elips -> lingkaran satuan)
//   B = (baris 2 matriks, tebal pita relatif, kuat geser dalam satuan tinggi layar)
//   C = (jarak sisi depan gelombang ke kamera dalam blok (0 = nggak dicek), jenis: 0 gelombang / 1 udara panas, -, -)
uniform vec4 S0A;
uniform vec4 S0B;
uniform vec4 S0C;
uniform vec4 S1A;
uniform vec4 S1B;
uniform vec4 S1C;
uniform vec4 S2A;
uniform vec4 S2B;
uniform vec4 S2C;
uniform vec4 S3A;
uniform vec4 S3B;
uniform vec4 S3C;
uniform vec4 S4A;
uniform vec4 S4B;
uniform vec4 S4C;
uniform vec4 S5A;
uniform vec4 S5B;
uniform vec4 S5C;

in vec2 texCoord;

out vec4 fragColor;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

vec3 fetch(vec2 uv) {
    return texture(DiffuseSampler, clamp(uv, vec2(0.0005), vec2(0.9995))).rgb;
}

void source(vec4 a, vec4 b, vec4 c, float sceneDist, vec2 aspect, inout vec2 offs, inout float chroma) {
    if (b.w <= 0.0) {
        return;
    }
    float occ = c.x > 0.0 ? smoothstep(c.x - 2.5, c.x + 0.5, sceneDist) : 1.0;
    if (occ <= 0.0) {
        return;
    }
    vec2 d = (texCoord - a.xy) * aspect;
    vec2 q = vec2(dot(a.zw, d), dot(b.xy, d));
    float r = length(q);
    float len = length(d);
    vec2 dir = len > 0.00001 ? d / len : vec2(0.0);
    if (c.y < 0.5) {   // gelombang tekanan: pita lensa di sekitar r = 1 (luar didorong keluar, dalam ditarik masuk)
        float x = (r - 1.0) / max(b.z, 0.01);
        if (abs(x) > 3.5) {
            return;
        }
        float k = x * exp(-x * x) * 2.33 * b.w * occ;
        offs += dir * k;
        chroma += abs(k);
    } else if (r < 1.0) {   // udara panas: riak yang naik, paling kuat di tengah
        float h = (1.0 - r * r) * b.w * occ;
        vec2 p = texCoord * aspect * 70.0;
        float t = Clock;
        vec2 n = vec2(sin(p.y * 1.7 + t * 9.0 + sin(p.x * 0.9 + t * 3.0)),
                      cos(p.x * 1.3 - t * 7.0 + sin(p.y * 1.1 - t * 2.0)) - 0.35);
        offs += n * h * 0.5;
        chroma += h * 0.15;
    }
}

void main() {
    vec2 aspect = vec2(InSize.x / max(InSize.y, 1.0), 1.0);
    float depth = texture(DepthSampler, texCoord).r;
    float sceneDist = depth >= 0.99999 ? 1.0e6 : Proj.y / (depth * 2.0 - 1.0 + Proj.x);
    vec2 offs = vec2(0.0);
    float chroma = 0.0;
    source(S0A, S0B, S0C, sceneDist, aspect, offs, chroma);
    source(S1A, S1B, S1C, sceneDist, aspect, offs, chroma);
    source(S2A, S2B, S2C, sceneDist, aspect, offs, chroma);
    source(S3A, S3B, S3C, sceneDist, aspect, offs, chroma);
    source(S4A, S4B, S4C, sceneDist, aspect, offs, chroma);
    source(S5A, S5B, S5C, sceneDist, aspect, offs, chroma);

    vec2 off = offs / aspect;   // satuan tinggi layar -> uv
    float lo = length(off);
    if (lo > 0.04) {   // pengaman: geseran sebesar apa pun tetap masuk akal
        off *= 0.04 / lo;
        lo = 0.04;
    }
    vec2 uv = texCoord + off;
    vec2 split = (lo > 0.000001 ? off / lo : vec2(0.0)) * min(chroma * Chroma, 0.005);
    vec2 fromC = uv - 0.5;
    split += fromC * (Impact * 0.014);

    vec3 col;
    if (Impact > 0.02) {   // hantaman: zoom kabur ke tengah layar
        col = vec3(0.0);
        for (int i = 0; i < 6; i++) {
            vec2 u = 0.5 + fromC * (1.0 - Impact * 0.03 * float(i) / 5.0);
            col += vec3(fetch(u + split).r, fetch(u).g, fetch(u - split).b);
        }
        col /= 6.0;
    } else {
        col = vec3(fetch(uv + split).r, fetch(uv).g, fetch(uv - split).b);
    }

    vec3 glow = clamp(texture(BloomSampler, uv).rgb * Bloom, 0.0, 1.0);
    vec3 shaft = clamp(texture(RaysSampler, uv).rgb * Rays, 0.0, 1.0);
    col = 1.0 - (1.0 - col) * (1.0 - glow);
    col = 1.0 - (1.0 - col) * (1.0 - shaft);

    col *= 1.0 - Impact * 0.32 * smoothstep(0.12, 0.62, length(fromC * vec2(aspect.x * 0.75, 1.0)));
    col += (hash(texCoord * InSize + fract(Clock * 7.13)) - 0.5) / 255.0;
    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
