"""SFX Kuasa Infinity (0.64: Thanos Alt+Z/X/V/N, PRALAYA Alt+Shift+Z/X/V/N). Dibuat dari nol dengan synth.py.

    python3 tools/sfx/infinity_sfx.py src/main/resources/assets/shazammod/sounds [nama ...]

Puncaknya dikunci ke ShazamAnim.INF_* (20 tick = 1 dtk), putar di pitch 1:
    infinity_surge 0,6 dtk (INF_SURGE_HIT) | infinity_crater_charge 0,7 (INF_CRATER_THROW) | infinity_portal_open 0,5
    (INF_PORTAL_OPEN) | infinity_rewrite 0,8 (INF_REWRITE_HIT) | infinity_raise 0,7 (INF_RAISE_HIT)
infinity_crater (ledakan kawah), infinity_portal_close, infinity_rewrite_end, infinity_crumble diputar tepat saat kejadian.
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_argv = sys.argv
sys.argv = [sys.argv[0]]
import synth as s                 # noqa: E402
import aksara_sfx as a            # noqa: E402
sys.argv = _argv

SR = s.SR
place = a.place


def env(dur, tau):
    return s.env_exp(int(dur * SR), tau)


def n_of(dur):
    return int(dur * SR)


def infinity_surge(rng, v):        # Daya Tak Terbatas: tenaga ditahan 0,6 dtk, lalu meledak & berdengung
    T, total = 0.6, 3.4
    n = n_of(T)
    strain = s.sweep_filter(s.supersaw(np.geomspace(70, 140, n), T, 7, 0.02, rng), np.geomspace(200, 3000, 64), "low", 1.2)
    strain = strain * np.linspace(0.05, 1, n) ** 2.5 * 0.25
    crackle = s.crackle(T, 500, rng, 1500, 9000, 0.002, np.linspace(0, 1, 30) ** 2) * 0.25
    d = 2.6
    m = n_of(d)
    tm = np.arange(m) / SR
    hum = s.supersaw(55 * (1 + 0.01 * np.sin(2 * np.pi * 5 * tm)), d, 7, 0.02, rng)
    hum = s.lp(hum, 1800) * s.env_adsr(d, 0.01, 0.6, 0.5, 1.6) * 0.5
    blast = s.mix(s.sub_drop(150, 30, 1.8, 0.5, 7) * 1.8, s.hp(s.white(n_of(0.02), rng), 2000) * env(0.02, 0.004) * 3.0,
                  s.crackle(1.6, 1200, rng, 1200, 10000, 0.002, np.linspace(1, 0, 40) ** 1.5) * 0.9,
                  s.sweep_filter(s.pink(n_of(1.4), rng), np.geomspace(6000, 300, 64), "band", 1.0) * env(1.4, 0.4) * 0.9)
    y = place(total, (0, strain), (0, crackle), (0, s.reverse_swell(T, rng, 400, 9000) * 0.3), (T, hum), (T, s.sat(blast, 1.8)))
    return s.limiter(s.reverb(y, 2.2, 0.25, rng=rng, size=1.6), 0.95)


def infinity_crater_charge(rng, v):   # bola daya dikumpulkan 0,7 dtk, lalu dilontarkan (desing)
    T, total = 0.7, 1.6
    ch = a.charge(T, 120, 1400, 0.3)
    throw = s.sweep_filter(s.pink(n_of(0.8), rng), np.geomspace(5000, 600, 64), "band", 1.4) * env(0.8, 0.2) * 0.8
    y = place(total, (0, ch), (0, s.reverse_swell(T, rng, 500, 10000) * 0.35), (T, throw),
              (T, s.sub_drop(180, 60, 0.4, 0.1, 7) * 0.7))
    return s.reverb(y, 1.4, 0.25, rng=rng)


def infinity_crater(rng, v):       # Ledakan Kawah: ledakan raksasa, tanah tercungkil, gemuruh panjang & hujan puing
    total = 7.0
    big = s.mix(s.impact(rng, 2) * 1.0, s.sub_drop(110, 18, 4.0, 1.4, 4) * 2.0,
                s.hp(s.white(n_of(0.03), rng), 1500) * env(0.03, 0.006) * 3.5,
                s.bp(s.white(n_of(0.6), rng), 150, 2500) * env(0.6, 0.12) * 1.5)
    rumble = s.lp(s.brown(n_of(6.0), rng), 140) * s.env_adsr(6.0, 0.05, 1.5, 0.5, 4.0) * 1.2
    debris = s.crackle(5.0, 90, rng, 250, 4000, 0.008, np.linspace(1, 0, 60) ** 1.4) * 1.0
    tail = s.sweep_filter(s.pink(n_of(5.0), rng), np.geomspace(3000, 150, 64), "low", 0.8) * s.env_adsr(5.0, 0.1, 1.0, 0.5, 3.5) * 0.7
    y = place(total, (0, s.sat(big, 2.2)), (0.05, rumble), (0.3, debris), (0.1, tail))
    return s.limiter(s.reverb(y, 4.0, 0.3, rng=rng, size=2.6), 0.95)


def infinity_portal_open(rng, v):  # Gerbang Kosmik: tarikan 0,5 dtk, gerbang menyala & berputar
    T, total = 0.5, 2.6
    d = 2.0
    m = n_of(d)
    tm = np.arange(m) / SR
    swirl = s.sweep_filter(s.pink(m, rng), 900 + 600 * np.sin(np.linspace(0, 18, 64)), "band", 2.5) * s.env_adsr(d, 0.05, 0.6, 0.6, 1.0) * 0.6
    tone = (np.sin(2 * np.pi * 220 * tm + 2 * np.sin(2 * np.pi * 6 * tm)) * 0.3 + np.sin(2 * np.pi * 330 * tm) * 0.15) * s.env_adsr(d, 0.02, 0.5, 0.6, 1.0)
    ignite = s.mix(s.sub_drop(200, 60, 0.6, 0.15, 7) * 0.9, s.crackle(0.5, 800, rng, 2000, 10000, 0.0015, np.linspace(1, 0, 20)) * 0.5)
    y = place(total, (0, s.reverse_swell(T, rng, 600, 12000) * 0.7), (T, ignite), (T, swirl), (T, tone))
    return a.flange(s.reverb(y, 2.0, 0.35, rng=rng), 3.0, 0.7, 0.5)


def infinity_portal_close(rng, v):  # gerbang menutup: implosi "vwomp"
    vw = s.osc(np.geomspace(500, 40, n_of(0.7)), 0.7) * env(0.7, 0.18) * 0.9
    air = s.sweep_filter(s.white(n_of(0.5), rng), np.geomspace(8000, 300, 64), "band", 2.0) * env(0.5, 0.12) * 0.6
    return s.reverb(s.mix(vw, air), 1.2, 0.3, rng=rng)


def infinity_rewrite(rng, v):      # Tulis Ulang Dunia: tarikan 0,8 dtk, lalu kenyataan melengkung & menyebar
    T, total = 0.8, 4.4
    d = 3.4
    m = n_of(d)
    tm = np.arange(m) / SR
    warp = s.supersaw(82 * (1 + 0.05 * np.sin(2 * np.pi * 2.5 * tm)), d, 7, 0.03, rng)
    warp = a.flange(s.lp(warp, 2000), 6.0, 1.2, 0.8) * s.env_adsr(d, 0.03, 0.8, 0.6, 2.0) * 0.5
    choir = s.lp(s.choir([196.0, 246.94, 293.66], d, rng, "a", 3.5), 3000) * s.env_adsr(d, 0.3, 1.0, 0.5, 1.6) * 0.1
    y = place(total, (0, s.reverse_swell(T, rng, 300, 10000) * 0.6), (T, warp), (T, choir), (T, a.glitch(d * 0.7, rng, 0.25)),
              (T, s.sub_drop(120, 30, 2.0, 0.6, 5) * 1.2))
    return s.limiter(s.reverb(y, 3.0, 0.35, rng=rng, size=2.2), 0.95)


def infinity_rewrite_end(rng, v):  # dunia kembali: tarikan terbalik, lalu "pop"
    T, total = 0.6, 2.0
    pop = s.mix(s.sub_drop(260, 70, 0.5, 0.1, 8) * 0.9, s.crackle(0.6, 900, rng, 2500, 12000, 0.0015, np.linspace(1, 0, 20)) * 0.5)
    y = place(total, (0, s.reverse_swell(T, rng, 400, 12000) * 0.8), (T, pop), (T, s.bell(523.25, 1.2, rng, ((1, 1), (2.0, 0.4)), 0.5) * 0.2))
    return s.reverb(y, 1.8, 0.35, rng=rng)


def infinity_raise(rng, v):        # Bangkitkan Undead: tanah bergemuruh, erangan, tulang berderak di 0,7 dtk
    T, total = 0.7, 3.4
    n = n_of(T)
    rumble = s.lp(s.brown(n_of(3.0), rng), 160) * s.env_adsr(3.0, 0.3, 0.8, 0.5, 1.6) * 1.0
    m = n_of(2.4)
    t = np.arange(m) / SR
    groan = s.formant(s.osc(np.geomspace(95, 70, m), 2.4, "saw") * (0.7 + 0.3 * np.sin(2 * np.pi * 3 * t)) + s.pink(m, rng) * 0.3, "o")
    groan = s.lp(groan, 1400) * s.env_adsr(2.4, 0.2, 0.8, 0.5, 1.2) * 0.35
    rattle = s.crackle(1.6, 220, rng, 800, 5000, 0.004, np.linspace(1, 0.2, 30)) * 0.8
    burst = s.mix(s.sub_drop(140, 40, 0.8, 0.2, 7) * 1.1, s.bp(s.white(n_of(0.3), rng), 300, 3000) * env(0.3, 0.06) * 0.9)
    y = place(total, (0, rumble), (0, s.reverse_swell(T, rng, 200, 6000) * 0.4), (T, burst), (T, groan), (T, rattle))
    return s.reverb(y, 2.6, 0.35, rng=rng, size=1.8)


def infinity_crumble(rng, v):      # undead hancur: tulang berjatuhan & debu jiwa
    rattle = s.crackle(0.9, 600, rng, 900, 6000, 0.003, np.linspace(1, 0, 20) ** 1.5) * 0.8
    whisper = s.sweep_filter(s.white(n_of(1.0), rng), np.geomspace(6000, 1200, 64), "band", 1.5) * env(1.0, 0.3) * 0.4
    thud = s.sub_drop(120 + v * 15, 50, 0.4, 0.1, 6) * 0.5
    return s.reverb(s.mix(rattle, whisper, thud), 1.2, 0.3, rng=rng)


RECIPES = {
    "infinity_surge": (infinity_surge, 1, 1.0),
    "infinity_crater_charge": (infinity_crater_charge, 1, 0.9),
    "infinity_crater": (infinity_crater, 2, 1.0),
    "infinity_portal_open": (infinity_portal_open, 1, 0.9),
    "infinity_portal_close": (infinity_portal_close, 1, 0.85),
    "infinity_rewrite": (infinity_rewrite, 1, 1.0),
    "infinity_rewrite_end": (infinity_rewrite_end, 1, 0.85),
    "infinity_raise": (infinity_raise, 1, 0.95),
    "infinity_crumble": (infinity_crumble, 2, 0.8),
}
s.RECIPES.update(RECIPES)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "out"
    only = sys.argv[2:] if len(sys.argv) > 2 else None
    os.makedirs(out, exist_ok=True)
    for name, (fn, count, gain) in RECIPES.items():
        if only and name not in only:
            continue
        for v in range(count):
            y = s.render(name, fn, v, gain)
            fname = f"{name}_{v + 1}.ogg"
            s.encode(y, os.path.join(out, fname))
            rms = 20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)
            print(fname, round(len(y) / SR, 2), "dtk", round(float(rms), 1), "dB", flush=True)
