"""SFX THANOS (0.63, fan-made). Dibuat dari nol dengan synth.py (+ alat bantu aksara_sfx.py), bukan rekaman film.

    python3 tools/sfx/thanos_sfx.py src/main/resources/assets/shazammod/sounds [nama ...]

Ciri suaranya: KOSMIK & BERAT: sub-bass dalam, drone supersaw gelap, dentang logam Gauntlet, dan satu nada kristal
per batu (tangga pentatonik minor A: Power A4, Space C5, Mind D5, Reality E5, Time G5, Soul A5; keenamnya = akor).
Tekstur tiap batu: Power = ledakan & percikan, Space = hisapan hampa & "vwomp", Mind = dengung psikis FM, Reality =
cairan yang melengkung (flanger/glitch), Time = detak jam & pita yang melambat, Soul = paduan suara hantu & angin.
Puncaknya dikunci ke tick ShazamAnim.TITAN_* (20 tick = 1 dtk), jadi putar di pitch 1:

    thanos_bind 4,5 dtk | thanos_transform 1,3 | thanos_power_punch 0,35 | thanos_power_nova 0,8 | thanos_space_step 0,3
    thanos_moon_rift 0,6 | thanos_meteor 0,5 (= TITAN_METEOR_FALL) | thanos_mind 0,4 | thanos_mindstorm 0,7
    thanos_reality_wrap 0,4 | thanos_reality_storm 0,6 | thanos_rewind 0,5 | thanos_timestop 0,6 | thanos_soul_harvest 0,4
    thanos_soul_shield 0,5 | thanos_snap_charge tepat 3,0 dtk (6 nada tiap 0,4 dtk = TITAN_SNAP_STAGGER) | thanos_rage 0,7
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_argv = sys.argv
sys.argv = [sys.argv[0]]
import synth as s                 # noqa: E402
import aksara_sfx as a            # noqa: E402  (alat bantu: clank, gong, charge, glitch, flange, bend_down, place)
sys.argv = _argv

SR = s.SR
STONE_F = [440.0, 523.25, 587.33, 659.25, 783.99, 880.0]   # Power, Space, Mind, Reality, Time, Soul


def env(dur, tau):
    return s.env_exp(int(dur * SR), tau)


def n_of(dur):
    return int(dur * SR)


def chime(rng, f, dur=1.6, tau=0.9):
    """Nada kristal batu: bell harmonik yang jernih."""
    return s.bell(f, dur, rng, ((1, 1), (2.0, 0.42), (3.01, 0.22), (4.2, 0.1)), tau, 0.001)


place = a.place


# ------------------------------------------------------------------ resep

def thanos_bind(rng, v):           # Sumpah Titan: drone kosmik naik 4,5 dtk, enam nada batu, lalu menyatu (braam)
    T, total = 4.5, 6.4
    n = n_of(T)
    drone = s.supersaw(np.geomspace(40, 82, n), T, 7, 0.01, rng)
    drone = s.lp(drone, 900) * np.linspace(0.1, 1.0, n) ** 1.8 * 0.28
    sub = s.osc(np.geomspace(30, 55, n), T) * np.linspace(0.2, 1.0, n) ** 2 * 0.6
    swirl = s.sweep_filter(s.pink(n, rng), np.geomspace(200, 6000, 64), "band", 1.6) * np.linspace(0, 1, n) ** 3 * 0.4
    items = [(0, drone), (0, sub), (0, swirl), (T - 0.6, s.reverse_swell(0.6, rng, 400, 12000) * 0.9)]
    for k in range(6):
        items.append((1.0 + k * 0.5, chime(rng, STONE_F[k] * 0.5, 2.4) * 0.35))
    burst = s.mix(s.braam(rng, 2) * 1.1, s.sub_drop(140, 28, 2.4, 0.7, 7) * 2.0, s.hp(s.white(n_of(0.02), rng), 2000) * env(0.02, 0.004) * 3.0,
                  a.clank(rng, 160, 1.8, 0.8, 0.7) * 0.4,
                  s.crackle(1.2, 700, rng, 1200, 9000, 0.002, np.linspace(1, 0, 30) ** 2) * 0.6)
    items.append((T, burst))
    return s.limiter(s.reverb(place(total, *items), 3.0, 0.3, rng=rng, size=2.0), 0.95)


def thanos_transform(rng, v):      # berubah: tenaga naik 1,3 dtk, lalu ledakan kosmik
    T, total = 1.3, 4.0
    n = n_of(T)
    rise = s.supersaw(np.geomspace(55, 112, n), T, 7, 0.015, rng)
    rise = s.sweep_filter(rise, np.geomspace(200, 4000, 64), "low", 1.2) * np.linspace(0.05, 1, n) ** 2.4 * 0.28
    gather = s.crackle(T, 300, rng, 1500, 9000, 0.002, np.linspace(0, 1, 40) ** 2) * 0.25
    hit = s.mix(s.braam(rng, 1) * 1.0, s.sub_drop(160, 28, 2.5, 0.7, 7) * 2.0, a.clank(rng, 180, 1.6, 0.8, 0.6) * 0.7,
                s.hp(s.white(n_of(0.02), rng), 2000) * env(0.02, 0.004) * 3.0)
    y = place(total, (0, rise), (0, s.reverse_swell(T, rng, 400, 9000) * 0.4), (0, gather), (T, hit))
    return s.limiter(s.sat(y, 1.4), 0.95)


def thanos_revert(rng, v):         # kembali: tenaga padam
    dur = 1.2
    n = n_of(dur)
    sweep = s.supersaw(np.geomspace(220, 55, n), dur, 5, 0.01, rng)
    sweep = s.sweep_filter(sweep, np.geomspace(4000, 200, 64), "low", 1.0) * env(dur, 0.35) * 0.5
    air = s.sweep_filter(s.white(n, rng), np.geomspace(6000, 300, 64), "band", 1.4) * env(dur, 0.3) * 0.4
    return s.reverb(s.mix(sweep, air, s.sub_drop(90, 35, 0.8, 0.2, 6) * 0.8), 1.4, 0.25, rng=rng)


def thanos_stone_found(rng, v):    # batu ditemukan: akor kristal, kilau, dengung
    total = 3.0
    items = [(0.0, chime(rng, STONE_F[0] * 0.5, 2.8) * 0.3), (0.06, chime(rng, STONE_F[2] * 0.5, 2.8) * 0.3),
             (0.12, chime(rng, STONE_F[4] * 0.5, 2.8) * 0.3), (0.2, chime(rng, STONE_F[5], 2.6) * 0.2)]
    hum = s.mix(s.osc(110, 2.6) * 0.3, s.osc(165, 2.6) * 0.15) * s.env_adsr(2.6, 0.3, 0.6, 0.6, 1.5)
    glitter = s.crackle(2.0, 140, rng, 5000, 14000, 0.001, np.linspace(1, 0, 30)) * 0.3
    items += [(0, hum), (0.1, glitter), (0, s.sub_drop(120, 50, 0.8, 0.2, 6) * 0.5)]
    return s.reverb(place(total, *items), 2.6, 0.4, rng=rng, size=1.8)


def thanos_power_punch(rng, v):    # Z Tinju Daya: tarikan 0,35 dtk, hantaman energi
    T, total = 0.35, 1.8
    n = n_of(T)
    hum = s.lp(s.osc(np.geomspace(80, 160, n), T, "saw"), 600) * np.linspace(0, 1, n) ** 2 * 0.4
    hit = s.mix(s.sub_drop(140, 36, 1.2, 0.25, 8) * 1.4,
                s.bp(s.white(n_of(0.3), rng), 300, 3000) * env(0.3, 0.05) * 1.2,
                s.crackle(0.8, 900, rng, 1200, 9000, 0.002, np.linspace(1, 0, 30) ** 2) * 0.8,
                s.sweep_filter(s.pink(n_of(1.2), rng), np.geomspace(3000, 200, 64), "band", 1.2) * env(1.2, 0.3) * 0.7)
    y = place(total, (0, s.reverse_swell(T, rng, 300, 6000) * 0.6), (0, hum), (T, s.sat(hit, 2.0)))
    return s.reverb(y, 1.6, 0.25, rng=rng, size=1.3)


def thanos_power_nova(rng, v):     # Shift+Z Ledakan Daya: tenaga dipadatkan 0,8 dtk, lalu meledak
    T, total = 0.8, 3.4
    ex = s.mix(s.impact(rng, 0) * 0.9, s.sub_drop(120, 25, 2.4, 0.8, 6) * 1.3,
               s.crackle(1.5, 600, rng, 800, 8000, 0.004, np.linspace(1, 0, 40) ** 2) * 0.8)
    y = place(total, (0, a.charge(T, 90, 700, 0.22)), (0, s.reverse_swell(T, rng, 400, 10000) * 0.3), (T, ex))
    return s.limiter(s.sat(y, 1.3), 0.95)


def thanos_space_step(rng, v):     # X Langkah Kosmik: hisapan 0,3 dtk, ruang robek ("vwomp")
    T, total = 0.3, 1.4
    vwomp = s.osc(np.geomspace(420, 50, n_of(0.6)), 0.6) * env(0.6, 0.15) * 0.9
    tear = s.sweep_filter(s.white(n_of(0.5), rng), np.geomspace(9000, 300, 64), "band", 2.0) * env(0.5, 0.12) * 0.7
    glint = s.bell(1600, 1.0, rng, ((1, 1), (1.5, 0.5), (2.5, 0.3)), 0.4) * 0.15
    y = place(total, (0, s.reverse_swell(T, rng, 800, 12000) * 0.8), (T, vwomp), (T, tear), (T, glint))
    return a.flange(s.reverb(y, 1.4, 0.3, rng=rng), 2.0, 1.2, 0.5)


def thanos_moon_rift(rng, v):      # Shift+X Hujan Bulan: langit robek 0,6 dtk, gemuruh panjang
    T, total = 0.6, 3.6
    d = 2.8
    n = n_of(d)
    fc = np.concatenate([np.geomspace(150, 2500, 8), np.geomspace(2500, 120, 56)])
    tear = s.sweep_filter(s.brown(n, rng) + 0.3 * s.pink(n, rng), fc, "low", 1.0) * s.env_adsr(d, 0.02, 0.6, 0.5, 2.0) * 1.2
    rumble = s.lp(s.brown(n, rng), 120) * s.env_adsr(d, 0.1, 0.5, 0.7, 2.0) * 0.9
    crack = s.crackle(1.2, 400, rng, 400, 5000, 0.006, np.linspace(1, 0, 30)) * 0.6
    y = place(total, (0, s.reverse_swell(T, rng, 200, 8000) * 0.7), (T, tear), (T, rumble), (T, crack),
              (T, s.sub_drop(100, 30, 2.0, 0.6, 5) * 0.8))
    return s.reverb(y, 3.0, 0.35, rng=rng, size=2.2)


def thanos_meteor(rng, v):         # satu batu bulan: siulan jatuh 0,5 dtk (= TITAN_METEOR_FALL), lalu menghantam
    T, total = 0.5, 2.4
    n = n_of(T)
    whistle = s.osc(np.geomspace(1800 + v * 220, 480, n), T) * np.linspace(0.1, 1, n) ** 2 * 0.25
    roar = s.sweep_filter(s.pink(n, rng), np.geomspace(800, 3000, 64), "band", 1.4) * np.linspace(0.1, 1, n) ** 2 * 0.8
    hit = s.mix(s.sub_drop(130 - v * 10, 30, 1.6, 0.4, 7) * 1.5, s.bp(s.white(n_of(0.4), rng), 200, 2500) * env(0.4, 0.08) * 1.2,
                s.crackle(1.4, 160, rng, 300, 3500, 0.006, np.linspace(1, 0, 40) ** 2) * 0.9)
    y = place(total, (0, whistle), (0, roar), (T, s.sat(hit, 2.0)))
    return s.reverb(y, 2.0, 0.25, rng=rng, size=1.6)


def thanos_mind(rng, v):           # C Belenggu Pikiran: dengung psikis naik 0,4 dtk, sinar FM
    T, total = 0.4, 1.7
    n = n_of(T)
    t = np.arange(n) / SR
    whine = np.sin(2 * np.pi * np.cumsum(np.geomspace(600, 1800, n)) / SR) * (0.6 + 0.4 * np.sin(2 * np.pi * 14 * t))
    whine = whine * np.linspace(0, 1, n) ** 2 * 0.25
    m = n_of(1.0)
    tm = np.arange(m) / SR
    fm = np.sin(2 * np.pi * 1200 * tm + 3 * np.sin(2 * np.pi * 7 * tm)) * env(1.0, 0.25) * 0.3
    beam = s.bp(s.white(m, rng), 2000, 3000, 2) * env(1.0, 0.3) * 0.5
    y = place(total, (0, whine), (T, fm), (T, beam), (T, chime(rng, STONE_F[2] * 2, 1.2) * 0.3))
    return s.reverb(y, 1.8, 0.35, rng=rng)


def thanos_mindstorm(rng, v):      # Shift+C Badai Pikiran: dengung bergetar 0,7 dtk, gelombang pikiran
    T, total = 0.7, 2.8
    n = n_of(T)
    t = np.arange(n) / SR
    build = (np.sin(2 * np.pi * 440 * t) + np.sin(2 * np.pi * 446 * t) + np.sin(2 * np.pi * 659 * t)) * np.linspace(0, 1, n) ** 2 * 0.15
    m = n_of(1.9)
    tm = np.arange(m) / SR
    waves = np.sin(2 * np.pi * 880 * tm + 4 * np.sin(2 * np.pi * 3 * tm)) * env(1.9, 0.5) * 0.25
    whoosh = s.sweep_filter(s.pink(m, rng), np.geomspace(4000, 400, 64), "band", 1.5) * env(1.9, 0.5) * 0.6
    y = place(total, (0, build), (T, waves), (T, whoosh), (T, s.sub_drop(110, 40, 1.0, 0.2, 6) * 0.9))
    return a.flange(s.reverb(y, 2.2, 0.4, rng=rng), 4.0, 0.8, 0.5)


def thanos_reality_wrap(rng, v):   # V Kenyataan Palsu: pelintiran 0,4 dtk, lalu kenyataan terkunci
    T, total = 0.4, 1.7
    n = n_of(T)
    twist = a.flange(s.sweep_filter(s.pink(n, rng), np.geomspace(300, 3000, 64), "band", 2.0), 6.0, 3.0, 0.7)
    twist = twist * np.linspace(0.2, 1, n) * 0.8
    liquid = s.osc(np.geomspace(300, 90, n_of(1.2)), 1.2, "tri") * env(1.2, 0.3) * 0.4
    snap = s.bp(s.white(n_of(0.05), rng), 1000, 6000) * env(0.05, 0.01) * 1.2
    y = place(total, (0, twist), (T, snap), (T, liquid), (T, s.crackle(0.8, 60, rng, 300, 2000, 0.01) * 0.6))
    return s.reverb(y, 1.4, 0.3, rng=rng)


def thanos_reality_burst(rng, v):  # pita kenyataan meledak: letupan + pecahan kaca
    total = 1.5
    shatter = s.crackle(0.9, 900, rng, 2500, 12000, 0.0015, np.linspace(1, 0, 30) ** 2) * 0.8
    ring = s.bell(880, 1.2, rng, ((1, 1), (2.4, 0.5), (3.9, 0.3)), 0.3) * 0.25
    y = place(total, (0, s.sub_drop(220, 60, 0.5, 0.1, 8) * 0.9), (0, shatter), (0, ring))
    return s.reverb(y, 1.2, 0.3, rng=rng)


def thanos_reality_storm(rng, v):  # Shift+V Badai Realitas: tarikan 0,6 dtk, dunia melengkung & glitch
    T, total = 0.6, 3.6
    d = 2.8
    m = n_of(d)
    tm = np.arange(m) / SR
    warble = s.supersaw(110 * (1 + 0.04 * np.sin(2 * np.pi * 3 * tm)), d, 5, 0.02, rng)
    warble = a.flange(s.lp(warble, 1500), 5.0, 1.5, 0.7) * s.env_adsr(d, 0.05, 0.5, 0.6, 1.6) * 0.5
    y = place(total, (0, s.reverse_swell(T, rng, 300, 9000) * 0.6), (T, warble), (T, a.glitch(d, rng, 0.25)),
              (T, s.sub_drop(100, 35, 1.2, 0.3, 6) * 0.8))
    return s.reverb(y, 2.4, 0.35, rng=rng, size=1.8)


def thanos_rewind(rng, v):         # B Putar Balik: detak jam makin cepat & nada terbalik 0,5 dtk, lalu waktu berbalik
    T, total = 0.5, 2.0
    clicks = [(max(0.0, T - 0.06 * k - 0.004 * k * k), s.bp(s.white(n_of(0.012), rng), 2000, 7000) * env(0.012, 0.002) * 0.5)
              for k in range(8)]
    rev = chime(rng, STONE_F[4], T)[::-1] * 0.5
    after = s.osc(np.geomspace(200, 900, n_of(0.6)), 0.6) * env(0.6, 0.15) * 0.3
    y = place(total, *clicks, (0, s.reverse_swell(T, rng, 500, 10000) * 0.7), (0, rev), (T, after),
              (T, s.sub_drop(110, 50, 0.6, 0.15, 6) * 0.7))
    return s.reverb(y, 1.8, 0.35, rng=rng)


def thanos_timestop(rng, v):       # Shift+B Henti Waktu: tarikan 0,6 dtk, "vwomp" melambat, gong, nada tinggi menggantung
    T, total = 0.6, 2.8
    vw = a.bend_down(s.mix(s.osc(220, 1.4, "saw") * 0.3, s.osc(330, 1.4) * 0.3) * env(1.4, 0.5), 1.0, 0.25)
    high = s.osc(2637, 2.0) * s.env_adsr(2.0, 0.05, 0.3, 0.5, 1.4) * 0.08
    y = place(total, (0, s.reverse_swell(T, rng, 400, 10000) * 0.7), (T, vw), (T, a.gong(rng, 196, 2.0, 1.2) * 0.4),
              (T, high), (T, s.sub_drop(90, 30, 1.0, 0.3, 6) * 0.8))
    return s.reverb(y, 2.6, 0.4, rng=rng, size=2.0)


def thanos_soul_harvest(rng, v):   # N Panen Jiwa: tarikan 0,4 dtk, jiwa-jiwa meratap 2 dtk, lalu tercabut
    T, D, total = 0.4, 2.0, 3.2
    m = n_of(D)
    voices = s.lp(s.choir([196.0, 233.08, 293.66], D, rng, "o", 4.5), 2500) * s.env_adsr(D, 0.2, 0.5, 0.7, 0.6) * 0.18
    wind = s.sweep_filter(s.pink(m, rng), 1100 + 500 * np.sin(np.linspace(0, 12, 64)), "band", 2.0)
    wind = wind * s.env_adsr(D, 0.1, 0.3, 0.8, 0.5) * 0.7
    drain = s.osc(np.geomspace(500, 120, m), D, "tri") * np.linspace(0.2, 1, m) * 0.2
    rip = s.mix(s.sub_drop(150, 40, 0.8, 0.2, 7) * 0.9, s.bp(s.white(n_of(0.3), rng), 400, 4000) * env(0.3, 0.06))
    y = place(total, (0, s.reverse_swell(T, rng, 300, 7000) * 0.5), (T, voices), (T, wind), (T, drain), (T + D, rip))
    return s.reverb(y, 2.6, 0.4, rng=rng, size=1.8)


def thanos_soul_shield(rng, v):    # Shift+N Perisai Jiwa: tarikan 0,5 dtk, dengung hangat perisai
    T, total = 0.5, 2.0
    hum = s.mix(s.osc(146.83, 1.4) * 0.4, s.osc(220.0, 1.4) * 0.25, s.osc(293.66, 1.4) * 0.15) * s.env_adsr(1.4, 0.02, 0.4, 0.5, 0.9)
    y = place(total, (0, s.reverse_swell(T, rng, 300, 8000) * 0.6), (T, hum), (T, chime(rng, STONE_F[5] * 1.335, 1.3) * 0.25),
              (T, s.sub_drop(120, 50, 0.6, 0.15, 6) * 0.7))
    return s.reverb(y, 2.0, 0.35, rng=rng)


def thanos_snap_charge(rng, v):    # R mengisi Jentikan: tepat 3,0 dtk, enam nada batu tiap 0,4 dtk, drone naik
    total = 3.0
    n = n_of(total)
    drone = s.supersaw(np.geomspace(55, 110, n), total, 7, 0.012, rng)
    drone = s.sweep_filter(drone, np.geomspace(200, 3000, 64), "low", 1.1) * np.linspace(0.15, 1, n) ** 1.6 * 0.4
    sub = s.osc(np.geomspace(35, 55, n), total) * np.linspace(0.2, 1, n) * 0.4
    items = [(0, drone), (0, sub), (0, s.reverse_swell(total, rng, 500, 12000) * 0.6)]
    for k in range(6):
        items.append((k * 0.4, chime(rng, STONE_F[k], 1.8) * 0.35))
    return place(total, *items)


def thanos_snap(rng, v):           # JENTIKAN: jentikan jari yang jernih, hening sekejap, lalu gelombang yang menyapu
    total = 4.4
    click = s.mix(s.hp(s.white(n_of(0.012), rng), 2500) * env(0.012, 0.0018) * 7.0,
                  s.bp(s.white(n_of(0.05), rng), 900, 3500) * env(0.05, 0.008) * 2.4,
                  s.osc(2200, 0.03) * env(0.03, 0.004) * 1.2)
    wave = s.sweep_filter(s.pink(n_of(3.5), rng), np.geomspace(9000, 250, 64), "band", 0.9) * s.env_adsr(3.5, 0.08, 0.8, 0.5, 2.4) * 0.9
    choir = s.lp(s.choir([220.0, 261.63, 329.63], 3.0, rng, "a", 4.0), 3000) * s.env_adsr(3.0, 0.5, 1.0, 0.4, 1.5) * 0.08
    y = place(total, (0, click), (0.2, wave), (0.2, s.sub_drop(80, 22, 3.0, 1.0, 4) * 1.2),
              (0.2, a.gong(rng, 110, 3.5, 2.0) * 0.5), (0.45, choir))
    return s.reverb(y, 3.2, 0.35, rng=rng, size=2.4)


def thanos_dust(rng, v):           # satu makhluk lenyap jadi debu: bisikan butiran yang berjatuhan
    dur = 1.6
    n = n_of(dur)
    grains = s.crackle(dur, 1800, rng, 3000, 12000, 0.0008, np.linspace(1, 0, 40) ** 1.5) * 0.5
    hiss = s.sweep_filter(s.white(n, rng), np.geomspace(8000, 1500, 64), "band", 1.5) * s.env_adsr(dur, 0.05, 0.5, 0.4, 1.0) * 0.4
    sigh = s.lp(s.choir([311.13 + v * 20], dur, rng, "u", 3.0), 1200) * s.env_adsr(dur, 0.1, 0.4, 0.3, 1.0) * 0.06
    return s.reverb(s.mix(grains, hiss, sigh), 1.8, 0.4, rng=rng)


def thanos_rage(rng, v):           # Shift+R Murka Titan: geraman 0,7 dtk, lalu raungan
    T, total = 0.7, 3.0
    n = n_of(T)
    t = np.arange(n) / SR
    growl = s.formant(s.pink(n, rng) * (0.7 + 0.3 * np.sin(2 * np.pi * 9 * t)), "o") * np.linspace(0.2, 1, n) ** 2 * 0.6
    m = n_of(2.0)
    roar = s.formant(s.osc(np.geomspace(120, 75, m), 2.0, "saw") * 0.6 + s.pink(m, rng) * 0.5, "a")
    roar = s.sat(roar, 2.5) * s.env_adsr(2.0, 0.05, 0.6, 0.6, 1.2) * 0.8
    y = place(total, (0, growl), (0, s.reverse_swell(T, rng, 300, 9000) * 0.6), (T, roar),
              (T, s.sub_drop(100, 30, 1.6, 0.5, 6) * 1.1))
    return s.reverb(y, 2.2, 0.3, rng=rng, size=1.8)


def thanos_spin(rng, v):           # M Putaran Pedang: kibasan lebar + dering bilah
    return place(1.3, (0.05, s.whoosh(rng, v) * 0.7), (0.3, a.clank(rng, 1240, 0.6, 0.6, 0.15) * 0.25))


def thanos_throw(rng, v):          # pedang dilempar berputar: desing berulang
    dur = 1.0
    n = n_of(dur)
    t = np.arange(n) / SR
    whir = s.bp(s.white(n, rng), 600, 4000) * (0.5 + 0.5 * np.sin(2 * np.pi * 18 * t)) * s.env_adsr(dur, 0.05, 0.3, 0.6, 0.5) * 0.7
    return s.mix(whir, s.whoosh(rng, 1) * 0.5)


def thanos_slam(rng, v):           # Hantaman Titan mendarat: dentum, tanah terbelah
    return s.limiter(s.mix(s.impact(rng, 1) * 0.9, s.earth_crack(rng, 0) * 0.6, s.sub_drop(110, 26, 2.0, 0.6, 6) * 0.9), 0.95)


def thanos_leap(rng, v):           # J melompat: hentakan kaki + kibasan berat
    return place(1.2, (0.3, s.sub_drop(100, 45, 0.4, 0.1, 6) * 0.6), (0.3, s.whoosh(rng, 2, True) * 0.6))


def thanos_parry(rng, v):          # tangkisan Pedang Dua Mata: dentang logam
    y = s.mix(a.clank(rng, 680 + v * 40, 0.8, 1.0, 0.25) * 0.9, s.hp(s.white(n_of(0.03), rng), 3000) * env(0.03, 0.004) * 0.8)
    return s.reverb(y, 1.0, 0.25, rng=rng)


def thanos_signal(rng, v):         # Sinyal Batu: denging sonar
    ping = s.bell(1046.5, 1.2, rng, ((1, 1), (2.0, 0.2)), 0.5) * 0.4
    echo = s.bell(1046.5, 1.2, rng, ((1, 1),), 0.4) * 0.15
    y = place(1.6, (0, ping), (0.3, echo), (0, s.osc(130.81, 1.0) * env(1.0, 0.3) * 0.2))
    return s.reverb(y, 1.6, 0.4, rng=rng)


RECIPES = {
    "thanos_bind": (thanos_bind, 1, 1.0),
    "thanos_transform": (thanos_transform, 1, 1.0),
    "thanos_revert": (thanos_revert, 1, 0.8),
    "thanos_stone_found": (thanos_stone_found, 1, 0.9),
    "thanos_power_punch": (thanos_power_punch, 2, 1.0),
    "thanos_power_nova": (thanos_power_nova, 1, 1.0),
    "thanos_space_step": (thanos_space_step, 2, 0.9),
    "thanos_moon_rift": (thanos_moon_rift, 1, 1.0),
    "thanos_meteor": (thanos_meteor, 3, 1.0),
    "thanos_mind": (thanos_mind, 1, 0.85),
    "thanos_mindstorm": (thanos_mindstorm, 1, 0.9),
    "thanos_reality_wrap": (thanos_reality_wrap, 1, 0.9),
    "thanos_reality_burst": (thanos_reality_burst, 2, 0.9),
    "thanos_reality_storm": (thanos_reality_storm, 1, 0.9),
    "thanos_rewind": (thanos_rewind, 1, 0.9),
    "thanos_timestop": (thanos_timestop, 1, 0.95),
    "thanos_soul_harvest": (thanos_soul_harvest, 1, 0.9),
    "thanos_soul_shield": (thanos_soul_shield, 1, 0.85),
    "thanos_snap_charge": (thanos_snap_charge, 1, 0.9),
    "thanos_snap": (thanos_snap, 1, 1.0),
    "thanos_dust": (thanos_dust, 3, 0.75),
    "thanos_rage": (thanos_rage, 1, 1.0),
    "thanos_spin": (thanos_spin, 2, 0.85),
    "thanos_throw": (thanos_throw, 1, 0.8),
    "thanos_slam": (thanos_slam, 2, 1.0),
    "thanos_leap": (thanos_leap, 1, 0.8),
    "thanos_parry": (thanos_parry, 2, 0.9),
    "thanos_signal": (thanos_signal, 1, 0.8),
}
WINDUPS = {"thanos_snap_charge"}
LOOPS = set()

s.RECIPES.update(RECIPES)
s.WINDUPS.update(WINDUPS)
s.LOOPS.update(LOOPS)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "out"
    only = sys.argv[2:] if len(sys.argv) > 2 else None
    os.makedirs(out, exist_ok=True)
    for name, (fn, count, gain) in RECIPES.items():
        if only and name not in only:
            continue
        for v in range(count):
            y = s.render(name, fn, v, gain)
            fname = f"{name}_{v + 1}.ogg"
            s.encode(y, os.path.join(out, fname))
            rms = 20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)
            print(fname, round(len(y) / SR, 2), "dtk", round(float(rms), 1), "dB", flush=True)
