"""Tekstur Infinity Gauntlet 3D (0.65): atlas 64x64 berisi swatch bahan, desain ORISINAL (bukan aset film/komik).

Tiap sisi kotak di GauntletGeo memakai satu swatch utuh (bevel di tepinya bikin tiap pelat terlihat timbul). Letak swatch
harus sama dengan tabel SW di GauntletGeo.java:

    STEEL 0,0  STEEL_DK 16,0  VIOLET 32,0  GOLD 48,0          (16x16)
    DORSAL 0,16  HALO 48,16  FLARE 16,32                      (16x16)
    RIDGE 0,32 (16x8)
    FINGER 16,16  NAIL 24,16  KNUCKLE 16,24  SOCKET 24,24  GEM 32,16  CORE 32,24  PALM 40,24   (8x8)
    WHITE 40,16  GROOVE 44,16                                 (4x4)

    python3 gauntlet_3d.py ASSETS_DIR [PREVIEW.png]
"""
import math
import os
import random
import sys

from PIL import Image

N = 64
rng = random.Random(1965)
img = Image.new("RGBA", (N, N), (0, 0, 0, 255))
px = img.load()


def clamp(v):
    return max(0, min(255, int(round(v))))


def put(x, y, c):
    px[x, y] = (clamp(c[0]), clamp(c[1]), clamp(c[2]), 255)


def mul(c, k):
    return tuple(v * k for v in c[:3])


def lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def plate(x0, y0, w, h, base, hi, lo, panel=True, noise=6, rivets=False, scratches=0):
    """Pelat logam berbevel: tepi atas/kiri terang, bawah/kanan gelap, garis panel di dalam."""
    for y in range(h):
        for x in range(w):
            c = lerp(base, mul(base, 1.12), 1 - (x + y) / (w + h))   # gradasi halus
            e = min(x, y, w - 1 - x, h - 1 - y)
            if e == 0:
                c = hi if (x == 0 or y == 0) and not (x == w - 1 or y == h - 1) else lo
                if (x == 0 and y == h - 1) or (x == w - 1 and y == 0):
                    c = lerp(hi, lo, 0.5)
            elif e == 1 and w >= 12:
                c = lerp(c, hi if (x == 1 or y == 1) else lo, 0.45)
            elif panel and w >= 12 and e == 3:
                c = mul(c, 0.72)                                       # alur panel
            elif panel and w >= 12 and e == 4 and (x == 4 or y == 4):
                c = mul(c, 1.12)                                       # tepi atas alur kena cahaya
            n = rng.uniform(-noise, noise)
            put(x0 + x, y0 + y, (c[0] + n, c[1] + n, c[2] + n * 1.1))
    if rivets and w >= 12:
        for (rx, ry) in ((2, 2), (w - 3, 2), (2, h - 3), (w - 3, h - 3)):
            put(x0 + rx, y0 + ry, mul(hi, 1.1))
            put(x0 + rx + 1, y0 + ry + 1, mul(lo, 0.9))
    for _ in range(scratches):
        sx, sy = rng.randrange(4, w - 4), rng.randrange(4, h - 4)
        ln = rng.randrange(2, 5)
        for k in range(ln):
            xx, yy = sx + k, sy + (k // 2)
            if xx < w - 3 and yy < h - 3:
                c = px[x0 + xx, y0 + yy]
                put(x0 + xx, y0 + yy, mul(c, 1.18))


STEEL = (70, 74, 86)
STEEL_HI = (150, 158, 174)
STEEL_LO = (30, 31, 38)
GOLD = (196, 150, 58)
GOLD_HI = (255, 226, 140)
GOLD_LO = (112, 76, 26)

# --- pelat baja utama & sisi gelap
plate(0, 0, 16, 16, STEEL, STEEL_HI, STEEL_LO, rivets=True, scratches=5)
plate(16, 0, 16, 16, mul(STEEL, 0.78), mul(STEEL_HI, 0.8), STEEL_LO, rivets=False, scratches=3)

# --- manset ungu tua: ukiran chevron, list emas atas & bawah
for y in range(16):
    for x in range(16):
        base = (60, 24, 96)
        c = lerp(base, (86, 40, 132), 1 - y / 15)
        if (x + abs(y - 8)) % 6 == 0 and 3 <= y <= 12:
            c = mul(c, 0.62)                                          # ukiran
        if (x + abs(y - 8)) % 6 == 1 and 3 <= y <= 12:
            c = mul(c, 1.25)
        if y in (0, 15):
            c = GOLD_HI if y == 0 else GOLD_LO
        elif y in (1, 14):
            c = GOLD
        elif y in (2, 13):
            c = mul(c, 0.7)
        n = rng.uniform(-4, 4)
        put(32 + x, y, (c[0] + n, c[1] + n * 0.6, c[2] + n))

# --- emas: pita kilau horizontal
for y in range(16):
    for x in range(16):
        t = y / 15
        c = lerp(GOLD_HI, GOLD, min(1, t * 2.2)) if t < 0.45 else lerp(GOLD, GOLD_LO, (t - 0.45) / 0.55)
        if 5 <= y <= 6:
            c = lerp(c, (255, 244, 200), 0.5)
        if x in (0, 15):
            c = mul(c, 0.8)
        n = rng.uniform(-5, 5)
        put(48 + x, y, (c[0] + n, c[1] + n, c[2] + n * 0.5))

# --- punggung tangan: bingkai timbul, tengah sedikit cekung, garis ukir melingkar
for y in range(16):
    for x in range(16):
        dx, dy = x - 7.5, y - 7.5
        r = math.hypot(dx, dy)
        c = lerp(mul(STEEL, 0.86), mul(STEEL, 1.05), 1 - (x + y) / 30)
        e = min(x, y, 15 - x, 15 - y)
        if e == 0:
            c = STEEL_HI if (x == 0 or y == 0) else STEEL_LO
        elif e == 1:
            c = lerp(c, GOLD, 0.55)
        elif e == 2:
            c = mul(c, 0.7)
        elif abs(r - 6.0) < 0.5:
            c = mul(c, 0.66)
        elif abs(r - 5.4) < 0.4:
            c = mul(c, 1.15)
        n = rng.uniform(-4, 4)
        put(x, 16 + y, (c[0] + n, c[1] + n, c[2] + n))

# --- rusuk punggung lengan: tepi emas, alur tenaga gelap di tengah (memanjang ke arah v)
for y in range(8):
    for x in range(16):
        if x in (0, 15):
            c = GOLD_LO
        elif x in (1, 14):
            c = GOLD
        elif 6 <= x <= 9:
            c = (22, 16, 30) if 7 <= x <= 8 else (40, 34, 52)
        else:
            c = lerp(STEEL, STEEL_HI, 0.25 if x < 7 else 0.0)
        n = rng.uniform(-4, 4)
        put(x, 32 + y, (c[0] + n, c[1] + n, c[2] + n))
for y in range(8, 16):
    for x in range(16):
        put(x, 32 + y, (0, 0, 0))


def small(x0, y0, fn):
    for y in range(8):
        for x in range(8):
            put(x0 + x, y0 + y, fn(x, y))


def finger(x, y):
    c = lerp(STEEL, STEEL_HI, 0.15)
    if y == 0 or y == 7:
        c = mul(STEEL, 0.55)                       # celah antar-ruas
    elif y == 1:
        c = lerp(STEEL_HI, c, 0.4)
    elif x == 0:
        c = mul(STEEL_HI, 0.9)
    elif x == 7:
        c = STEEL_LO
    n = rng.uniform(-5, 5)
    return (c[0] + n, c[1] + n, c[2] + n)


def nail(x, y):
    c = mul(STEEL, 0.85)
    if y >= 6:
        c = lerp(STEEL_HI, (220, 226, 240), 0.5)   # ujung tajam berkilat
    elif y == 0:
        c = mul(STEEL, 0.55)
    elif x == 0:
        c = STEEL_HI
    elif x == 7:
        c = STEEL_LO
    n = rng.uniform(-4, 4)
    return (c[0] + n, c[1] + n, c[2] + n)


def knuckle(x, y):
    c = lerp(GOLD, STEEL, 0.45)
    e = min(x, y, 7 - x, 7 - y)
    if e == 0:
        c = lerp(GOLD_HI, STEEL_HI, 0.3) if (x == 0 or y == 0) else GOLD_LO
    elif e == 1:
        c = mul(c, 1.1)
    n = rng.uniform(-4, 4)
    return (c[0] + n, c[1] + n, c[2] + n)


def socket(x, y):
    e = min(x, y, 7 - x, 7 - y)
    if e == 0:
        return GOLD_HI if (x == 0 or y == 0) else GOLD_LO
    if e == 1:
        return GOLD
    r = math.hypot(x - 3.5, y - 3.5)
    return lerp((44, 22, 64), (14, 10, 20), min(1, r / 2.5))


def gem(x, y):
    # faset: segitiga terang-gelap bergantian (putih, nanti diwarnai warna batu)
    dx, dy = x - 3.5, y - 3.5
    a = math.atan2(dy, dx)
    k = 0.78 + 0.22 * math.cos(a * 4 + 0.6)
    if max(abs(dx), abs(dy)) < 1.6:
        k = 1.0
    if x == 1 and y == 1 or x == 2 and y == 1:
        k = 1.15                                     # kilau
    v = 255 * min(1.0, k)
    return (v, v, v)


def core(x, y):
    r = math.hypot(x - 3.5, y - 3.5)
    a = math.atan2(y - 3.5, x - 3.5)
    k = 1.0 - 0.25 * min(1, r / 3.5) + 0.12 * math.sin(a * 3 + r * 1.4)
    v = 255 * max(0.5, min(1.0, k))
    return (v, v, v)


def palm(x, y):
    c = (40, 37, 46)
    if x in (0, 7) or y in (0, 7):
        c = (28, 26, 32)
    if y == 3 and x % 2 == 0:
        c = (64, 58, 70)                             # jahitan
    n = rng.uniform(-3, 3)
    return (c[0] + n, c[1] + n, c[2] + n)


small(16, 16, finger)
small(24, 16, nail)
small(16, 24, knuckle)
small(24, 24, socket)
small(32, 16, gem)
small(32, 24, core)
small(40, 24, palm)

for y in range(4):
    for x in range(4):
        put(40 + x, 16 + y, (255, 255, 255))         # putih (garis cahaya)
        put(44 + x, 16 + y, (18, 14, 22))            # alur gelap
for y in range(20, 24):
    for x in range(40, 48):
        put(x, y, (0, 0, 0))

# --- pendar bulat (aditif: tepi & sudut HARUS hitam supaya nggak terlihat kotak)
for y in range(16):
    for x in range(16):
        r = math.hypot(x - 7.5, y - 7.5) / 7.5
        v = max(0.0, 1 - r) ** 2.2
        put(48 + x, 16 + y, (255 * v, 255 * v, 255 * v))

# --- bintang kilatan (Jentikan): inti bulat + empat sinar
for y in range(16):
    for x in range(16):
        dx, dy = (x - 7.5) / 7.5, (y - 7.5) / 7.5
        r = math.hypot(dx, dy)
        core_v = max(0.0, 1 - r * 1.6) ** 2
        ray = max(0.0, 1 - abs(dx) * 7) * max(0.0, 1 - abs(dy)) + max(0.0, 1 - abs(dy) * 7) * max(0.0, 1 - abs(dx))
        v = min(1.0, core_v + 0.8 * ray * max(0.0, 1 - r))
        if min(x, y, 15 - x, 15 - y) == 0:
            v = 0.0
        put(16 + x, 32 + y, (255 * v, 255 * v, 255 * v))


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    out = os.path.join(sys.argv[1], "textures", "entity", "thanos")
    os.makedirs(out, exist_ok=True)
    img.save(os.path.join(out, "infinity_gauntlet.png"))
    if len(sys.argv) > 2:
        img.resize((N * 8, N * 8), Image.NEAREST).save(sys.argv[2])
    print("ok", os.path.join(out, "infinity_gauntlet.png"))


if __name__ == "__main__":
    main()
