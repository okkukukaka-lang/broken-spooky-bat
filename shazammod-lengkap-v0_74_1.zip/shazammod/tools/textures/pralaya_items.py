"""Ikon barang PRALAYA 0.55 (orisinal): Inti Armor, dua modul upgrade, enam inti. 16x16, digambar 8x lalu diperkecil.

    python3 -I pralaya_items.py ASSETS_DIR [PREVIEW.png]

Menulis ke ASSETS_DIR/textures/item/:
  lontar_sabda.png          Inti Armor PRALAYA: badan baja heksagonal, reaktor merah di tengah, enam dudukan inti KOSONG
  modul_tempa_nether.png    Modul Tempa Nether: pelat paduan gelap berbaut dengan retakan tempa membara & soket tengah
  modul_kalibrasi_end.png   Modul Kalibrasi End: giroskop dua cincin pucat di atas dudukan baja, kristal ungu di poros
  inti_daya.png ... inti_atma.png   enam inti: kristal heksagonal runcing dua ujung, dijepit pita baja di pinggangnya
"""
import os
import sys

import numpy as np
from PIL import Image, ImageDraw

SS = 8                      # supersampling
N = 16
CORES = ["inti_daya", "inti_ruang", "inti_benak", "inti_maya", "inti_kala", "inti_atma"]
RGB = [0xFF3048, 0x8A6CFF, 0x40E6FF, 0xFF4FC8, 0xFFB840, 0x5CFFA0]   # sama dengan AksaraSkills.RGB
STEEL = (88, 96, 110)
STEEL_HI = (168, 176, 192)
STEEL_DK = (34, 37, 46)
DARK = (24, 26, 33)


def rgb(c):
    return ((c >> 16) & 255, (c >> 8) & 255, c & 255)


def mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


class Canvas:
    """Kanvas besar (16*SS) dengan lapisan warna + alpha; diperkecil jadi piksel tegas."""

    def __init__(self):
        self.im = Image.new("RGBA", (N * SS, N * SS), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im)

    def poly(self, pts, col, a=255):
        self.d.polygon([(x * SS, y * SS) for x, y in pts], fill=col + (a,))

    def rect(self, x0, y0, x1, y1, col, a=255):
        self.d.rectangle([x0 * SS, y0 * SS, x1 * SS - 1, y1 * SS - 1], fill=col + (a,))

    def ellipse(self, cx, cy, rx, ry, col, a=255, width=0):
        box = [(cx - rx) * SS, (cy - ry) * SS, (cx + rx) * SS, (cy + ry) * SS]
        if width:
            self.d.ellipse(box, outline=col + (a,), width=int(width * SS))
        else:
            self.d.ellipse(box, fill=col + (a,))

    def line(self, x0, y0, x1, y1, col, w=1.0, a=255):
        self.d.line([(x0 * SS, y0 * SS), (x1 * SS, y1 * SS)], fill=col + (a,), width=max(1, int(w * SS)))

    def finish(self, outline=True):
        arr = np.asarray(self.im, dtype=float)
        h = arr.reshape(N, SS, N, SS, 4)
        a = h[..., 3].mean(axis=(1, 3)) / 255.0
        w = h[..., 3:4] / 255.0
        col = (h[..., :3] * w).sum(axis=(1, 3)) / np.maximum(w.sum(axis=(1, 3)), 1e-6)
        out = np.zeros((N, N, 4), np.uint8)
        solid = a > 0.45
        out[..., :3] = np.clip(col, 0, 255).astype(np.uint8)
        out[..., 3] = np.where(solid, 255, 0)
        if outline:   # garis luar gelap 1 px di tepi bawah-kanan (ciri ikon vanilla), biar terbaca di latar terang
            edge = np.zeros_like(solid)
            edge[1:, :] |= solid[:-1, :] & ~solid[1:, :]
            edge[:, 1:] |= solid[:, :-1] & ~solid[:, 1:]
            out[edge] = (14, 15, 20, 255)
        return Image.fromarray(out, "RGBA")


def crystal(c, col, cx=8.0, top=0.6, bottom=15.4, half=3.9, shoulder=4.2, band=True):
    """Kristal heksagonal runcing dua ujung, tiga sisi tampak (kiri terang, tengah, kanan gelap), pita baja."""
    light, mid, dark = mix(col, (255, 255, 255), 0.42), col, mix(col, (0, 0, 0), 0.5)
    deep = mix(col, (0, 0, 0), 0.7)
    yt, yb = top + shoulder - 0.6, bottom - shoulder + 0.6
    xl, xr = cx - half, cx + half
    xa, xb = cx - half * 0.38, cx + half * 0.38
    c.poly([(cx, top), (xl, yt), (xl, yb), (cx, bottom), (xr, yb), (xr, yt)], deep)          # siluet
    c.poly([(cx, top), (xl, yt), (xa, yt)], light)                                            # ujung atas
    c.poly([(cx, top), (xa, yt), (xb, yt)], mix(light, mid, 0.5))
    c.poly([(cx, top), (xb, yt), (xr, yt)], mid)
    c.poly([(xl, yt), (xa, yt), (xa, yb), (xl, yb)], light)                                   # sisi kiri
    c.poly([(xa, yt), (xb, yt), (xb, yb), (xa, yb)], mid)                                     # sisi tengah
    c.poly([(xb, yt), (xr, yt), (xr, yb), (xb, yb)], dark)                                    # sisi kanan
    c.poly([(xl, yb), (xa, yb), (cx, bottom)], mid)                                           # ujung bawah
    c.poly([(xa, yb), (xb, yb), (cx, bottom)], dark)
    c.poly([(xb, yb), (xr, yb), (cx, bottom)], deep)
    c.ellipse(cx - 0.3, (top + bottom) / 2 - 1.6, 1.3, 2.2, mix(col, (255, 255, 255), 0.65), 150)   # cahaya dalam
    c.line(xl + 0.9, yt + 0.6, xl + 0.9, yt + 3.2, (255, 255, 255), 0.9)                      # kilau
    c.rect(xl + 0.6, top + shoulder - 0.2, xl + 1.4, top + shoulder + 0.6, (255, 255, 255))
    if band:
        my = (top + bottom) / 2
        c.rect(xl - 0.5, my - 0.9, xr + 0.5, my + 0.9, STEEL)
        c.rect(xl - 0.5, my - 0.9, xr + 0.5, my - 0.35, STEEL_HI)
        c.rect(xl - 0.5, my + 0.4, xr + 0.5, my + 0.9, STEEL_DK)
        for bx in (xl - 0.1, xr - 0.9):                                                        # baut pita
            c.rect(bx, my - 0.4, bx + 1.0, my + 0.4, STEEL_DK)


def armor_core():
    c = Canvas()
    hexa = [(8 + 7.2 * np.cos(np.pi / 6 + k * np.pi / 3), 8 + 7.2 * np.sin(np.pi / 6 + k * np.pi / 3)) for k in range(6)]
    c.poly(hexa, STEEL_DK)
    inner = [(8 + 6.1 * np.cos(np.pi / 6 + k * np.pi / 3), 8 + 6.1 * np.sin(np.pi / 6 + k * np.pi / 3)) for k in range(6)]
    c.poly(inner, DARK)
    c.poly([inner[3], inner[4], inner[5], (8, 8)], mix(DARK, STEEL, 0.5))                 # sisi atas lebih terang
    c.line(inner[3][0], inner[3][1], inner[4][0], inner[4][1], STEEL_HI, 0.7)
    c.line(inner[4][0], inner[4][1], inner[5][0], inner[5][1], STEEL_HI, 0.7)
    for k in range(6):                                                                     # enam dudukan kosong
        a = -np.pi / 2 + k * np.pi / 3
        px, py = 8 + np.cos(a) * 4.4, 8 + np.sin(a) * 4.4
        c.ellipse(px, py, 1.25, 1.25, STEEL)
        c.ellipse(px, py, 0.7, 0.7, (10, 11, 15))
    c.ellipse(8, 8, 2.2, 2.2, (120, 16, 22))                                               # reaktor merah
    c.ellipse(8, 8, 1.5, 1.5, (255, 46, 52))
    c.ellipse(7.6, 7.6, 0.7, 0.7, (255, 224, 214))
    return c.finish()


def nether_module():
    c = Canvas()
    base, hi, lo = (58, 48, 54), (104, 90, 96), (30, 24, 28)
    c.poly([(2.5, 1.5), (13.5, 1.5), (14.5, 2.5), (14.5, 13.5), (13.5, 14.5), (2.5, 14.5), (1.5, 13.5), (1.5, 2.5)], lo)
    c.poly([(2.8, 2.2), (13.2, 2.2), (13.8, 2.8), (13.8, 13.0), (13.0, 13.8), (2.8, 13.8), (2.2, 13.2), (2.2, 2.8)], base)
    c.line(2.6, 2.4, 13.2, 2.4, hi, 0.8)
    c.line(2.4, 2.6, 2.4, 13.2, hi, 0.8)
    for x, y in ((3.6, 3.6), (12.4, 3.6), (3.6, 12.4), (12.4, 12.4)):                     # baut
        c.ellipse(x, y, 0.75, 0.75, hi)
        c.ellipse(x + 0.2, y + 0.2, 0.4, 0.4, lo)
    ember, hot = (255, 110, 30), (255, 214, 140)
    for pts in (((5.0, 5.2), (6.6, 6.4), (6.2, 8.0)), ((11.2, 5.0), (9.8, 6.6), (10.4, 7.6)),
                ((5.2, 11.0), (6.8, 9.6), (7.6, 10.4)), ((10.8, 11.2), (9.4, 9.8))):     # retakan tempa membara
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            c.line(x0, y0, x1, y1, ember, 0.9)
    hexa = [(8 + 2.4 * np.cos(k * np.pi / 3), 8 + 2.4 * np.sin(k * np.pi / 3)) for k in range(6)]
    c.poly(hexa, lo)
    hexb = [(8 + 1.6 * np.cos(k * np.pi / 3), 8 + 1.6 * np.sin(k * np.pi / 3)) for k in range(6)]
    c.poly(hexb, ember)
    c.ellipse(7.8, 7.8, 0.7, 0.7, hot)
    return c.finish()


def end_module():
    c = Canvas()
    c.poly([(4.0, 13.0), (12.0, 13.0), (13.0, 15.0), (3.0, 15.0)], STEEL)                   # dudukan baja
    c.rect(3.0, 14.2, 13.0, 15.0, STEEL_DK)
    c.rect(7.4, 10.5, 8.6, 13.2, STEEL_HI)                                                  # tiang poros
    pale, lav, deep = (236, 224, 255), (184, 146, 255), (96, 60, 170)
    c.ellipse(8, 7.2, 6.4, 2.6, lav, 255, 1.0)                                              # cincin datar
    c.ellipse(8, 7.2, 2.4, 6.0, pale, 255, 1.0)                                             # cincin tegak
    c.poly([(8, 3.9), (9.6, 7.2), (8, 10.5), (6.4, 7.2)], deep)                             # kristal di poros
    c.poly([(8, 3.9), (8, 10.5), (6.4, 7.2)], lav)
    c.line(7.3, 5.6, 7.3, 7.0, (255, 255, 255), 0.7)
    c.ellipse(8, 7.2, 0.6, 0.6, pale)
    return c.finish()


def core_icon(i):
    c = Canvas()
    crystal(c, rgb(RGB[i]))
    return c.finish()


def main():
    out = sys.argv[1]
    d = os.path.join(out, "textures/item")
    os.makedirs(d, exist_ok=True)
    icons = {"lontar_sabda": armor_core(), "modul_tempa_nether": nether_module(), "modul_kalibrasi_end": end_module()}
    for i, name in enumerate(CORES):
        icons[name] = core_icon(i)
    for name, im in icons.items():
        im.save(os.path.join(d, name + ".png"))
    if len(sys.argv) > 2:
        sheet = Image.new("RGBA", (len(icons) * 18 + 2, 20), (60, 62, 70, 255))
        for k, im in enumerate(icons.values()):
            sheet.paste(im, (2 + k * 18, 2), im)
        sheet.resize((sheet.width * 8, sheet.height * 8), Image.NEAREST).save(sys.argv[2])
    print("ok", len(icons))


if __name__ == "__main__":
    main()
