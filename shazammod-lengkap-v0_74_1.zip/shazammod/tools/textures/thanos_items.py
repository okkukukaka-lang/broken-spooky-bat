"""Ikon barang Thanos (0.62): ikon placeholder ORISINAL 16x16, bukan aset film/komik.

  - enam batu: permata oval berfaset generik, satu warna per batu
  - Pedang Dua Mata: pedang berbilah dua ujung generik (baja polos, pegangan kulit gelap di tengah)
  - Infinity Gauntlet: sarung tangan besi gelap generik, tanpa permata (kilau enchant muncul saat keenam batu terpasang)

Mau ganti dengan gambar sendiri? Timpa saja PNG-nya (16x16) di textures/item/.

    python3 thanos_items.py ASSETS_DIR [PREVIEW.png]
"""
import os
import sys

from PIL import Image

N = 16
OUTLINE = (24, 18, 28, 255)

STONES = {
    "power": (155, 69, 224),
    "space": (63, 123, 255),
    "reality": (229, 38, 46),
    "soul": (255, 138, 28),
    "time": (53, 214, 84),
    "mind": (255, 224, 58),
}


def mix(c, k):
    """k < 1 menggelap, k > 1 menerang (ke putih)."""
    if k <= 1:
        return tuple(int(v * k) for v in c[:3]) + (255,)
    t = min(1.0, k - 1)
    return tuple(int(v + (255 - v) * t) for v in c[:3]) + (255,)


def outline(img):
    px = img.load()
    solid = {(x, y) for y in range(N) for x in range(N) if px[x, y][3] > 0}
    for x, y in list(solid):
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < N and 0 <= ny < N and (nx, ny) not in solid:
                px[nx, ny] = OUTLINE
    return img


def gem(color):
    img = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    px = img.load()
    cx, cy, rx, ry = 7.5, 8.0, 4.6, 5.6
    for y in range(N):
        for x in range(N):
            dx, dy = (x - cx) / rx, (y - cy) / ry
            d = dx * dx + dy * dy
            if d > 1.0:
                continue
            k = 1.0 - 0.32 * (dx + dy)            # cahaya dari kiri atas
            if dx * dx + dy * dy < 0.28:           # meja permata di tengah
                k += 0.18
            if abs(dx - dy) < 0.12 or abs(dx + dy) < 0.12:   # garis faset
                k *= 0.82
            px[x, y] = mix(color, max(0.35, min(1.55, k)))
    for x, y in ((5, 4), (6, 4), (5, 5)):         # kilau
        px[x, y] = (255, 255, 255, 255)
    px[10, 11] = mix(color, 1.5)
    return outline(img)


def blade():
    img = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    px = img.load()
    steel, edge, dark = (186, 192, 204, 255), (236, 240, 248, 255), (108, 114, 128, 255)
    grip, wrap, guard = (58, 40, 34, 255), (92, 66, 52, 255), (140, 146, 158, 255)
    # diagonal dari kiri bawah ke kanan atas, sama seperti pedang vanilla
    for i in range(1, 15):
        x, y = i, 15 - i
        if 6 <= i <= 9:                            # pegangan di tengah
            px[x, y] = grip if i % 2 else wrap
            continue
        if i in (5, 10):                           # pelindung tangan
            px[x, y] = guard
            for ox, oy in ((-1, -1), (1, 1)):
                if 0 <= x + ox < N and 0 <= y + oy < N:
                    px[x + ox, y + oy] = guard
            continue
        px[x, y] = steel
        if 0 <= x + 1 < N:
            px[x + 1, y] = edge                    # sisi tajam yang terkena cahaya
        if 0 <= y + 1 < N:
            px[x, y + 1] = dark
        if i in (3, 4, 11, 12) and x + 1 < N and y + 1 < N:
            px[x + 1, y + 1] = dark                # bilah melebar dekat pelindung, meruncing ke ujung
    px[1, 14], px[14, 1] = edge, edge              # kedua ujung
    return outline(img)


def gauntlet():
    img = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    px = img.load()
    iron, light, shade = (92, 98, 112, 255), (140, 148, 164, 255), (58, 62, 74, 255)
    band = (70, 54, 88, 255)
    for x in range(4, 12):                          # manset
        for y in range(11, 15):
            px[x, y] = shade if y == 14 else iron
    for x in range(4, 12):
        px[x, 11] = band
    for x in range(3, 13):                          # punggung tangan
        for y in range(5, 11):
            px[x, y] = light if (x < 6 and y < 8) else iron
    for fx in (4, 6, 8, 10):                        # empat jari dengan ruas
        for y in range(2, 5):
            px[fx, y] = iron
            px[fx + 1, y] = shade
        px[fx, 3] = light
    for y in range(6, 10):                          # ibu jari
        px[2, y] = iron
    px[2, 6] = light
    for x in range(3, 13):                          # garis pelat di buku jari
        px[x, 5] = shade
    return outline(img)


def main():
    assets = sys.argv[1] if len(sys.argv) > 1 else "../../src/main/resources/assets/shazammod"
    out = os.path.join(assets, "textures", "item")
    os.makedirs(out, exist_ok=True)
    icons = {f"{name}_stone": gem(color) for name, color in STONES.items()}
    icons["thanos_double_blade"] = blade()
    icons["infinity_gauntlet"] = gauntlet()
    for name, img in icons.items():
        img.save(os.path.join(out, name + ".png"))
    if len(sys.argv) > 2:
        scale = 8
        sheet = Image.new("RGBA", (len(icons) * (N * scale + 8), N * scale), (40, 40, 48, 255))
        for i, img in enumerate(icons.values()):
            big = img.resize((N * scale, N * scale), Image.NEAREST)
            sheet.paste(big, (i * (N * scale + 8), 0), big)
        sheet.save(sys.argv[2])
    print("ditulis:", ", ".join(icons))


if __name__ == "__main__":
    main()
