"""Tekstur KALDERA, Titan Radiasi (0.73.1). Semuanya bisa diulang (tileable).
  rock.png          batu bijih uranium (pitchblende): sel-sel bersudut gelap kehijauan, retakan gelap, bintik mineral kuning-hijau
  veins.png         cahaya hijau di sebagian retakan yang sama + bintik-bintik mineral yang berpendar
  core.png          cairan inti radioaktif: hijau menyala dengan kerak gelap yang hanyut & gelembung terang
  crystal.png       kristal uranium (padat): hijau tua di pangkal, pucat terang di ujung, garis sisi kristal
  crystal_glow.png  kilau kristal (cahaya): urat-urat cahaya memanjang & denyut yang merambat (berulang di sumbu v)
usage: python3 -I textures_rad.py <out dir>"""
import os, sys
import numpy as np
from PIL import Image

out = sys.argv[1]
os.makedirs(out, exist_ok=True)
rng = np.random.default_rng(7331)

def torus_voronoi(N, pts, M=None):
    M = M or N
    ys, xs = np.mgrid[0:M, 0:N]
    px = (xs + 0.5) / N; py = (ys + 0.5) / M
    d1 = np.full((M, N), 9.0); d2 = np.full((M, N), 9.0); idx = np.zeros((M, N), int); second = np.zeros((M, N), int)
    for k, (x, y) in enumerate(pts):
        dx = np.abs(px - x); dx = np.minimum(dx, 1 - dx)
        dy = np.abs(py - y); dy = np.minimum(dy, 1 - dy)
        d = np.sqrt(dx * dx + dy * dy)
        closer = d < d1
        second = np.where(closer, idx, np.where(d < d2, k, second))
        d2 = np.where(closer, d1, np.minimum(d2, d))
        idx = np.where(closer, k, idx)
        d1 = np.where(closer, d, d1)
    return d1, d2, idx, second

def tile_noise(N, cells, seed, octaves=3, M=None, cells_y=None):
    M = M or N; cy = cells_y or cells
    r = np.random.default_rng(seed)
    acc = np.zeros((M, N)); amp = 1.0; tot = 0
    for o in range(octaves):
        c = cells * (2 ** o); cyy = cy * (2 ** o)
        g = r.random((cyy, c))
        ys, xs = np.mgrid[0:M, 0:N]
        fx = xs / N * c; fy = ys / M * cyy
        x0 = np.floor(fx).astype(int); y0 = np.floor(fy).astype(int)
        tx = fx - x0; ty = fy - y0
        tx = tx * tx * (3 - 2 * tx); ty = ty * ty * (3 - 2 * ty)
        x1 = (x0 + 1) % c; y1 = (y0 + 1) % cyy; x0 %= c; y0 %= cyy
        v = (g[y0, x0] * (1 - tx) + g[y0, x1] * tx) * (1 - ty) + (g[y1, x0] * (1 - tx) + g[y1, x1] * tx) * ty
        acc += v * amp; tot += amp; amp *= 0.5
    return acc / tot

def save(arr, name):
    Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), 'RGB').save(os.path.join(out, name))

# ---------------------------------------------------------------- batu bijih: sel acak bersudut (bukan kolom teratur)
N = 128
pts = [(rng.random(), rng.random()) for _ in range(46)]
d1, d2, idx, second = torus_voronoi(N, pts)
edge = (d2 - d1) * N
grain = tile_noise(N, 8, 11, 4)
fine = tile_noise(N, 32, 12, 2)
cellTone = rng.uniform(-1, 1, len(pts))
cellTint = rng.uniform(-1, 1, len(pts))

base = np.array([60, 65, 57], float)
col = np.zeros((N, N, 3)); col[:] = base
t = cellTone[idx][..., None]; w = cellTint[idx][..., None]
col += t * 10.0
col += w * np.array([-3, 3, -2])
col *= (0.8 + 0.4 * grain)[..., None]
col += ((fine - 0.5) * 20)[..., None]
# kilap berminyak (pitch): sisi sel sedikit lebih terang di dekat retakan, lalu retakan gelap
rim = np.clip(1 - edge / 5.0, 0, 1)
col += (rim * 9)[..., None]
crack = np.clip(1 - edge / 2.0, 0, 1)
col = col * (1 - crack[..., None] * 0.75) + np.array([16, 20, 15]) * crack[..., None] * 0.75
r2 = np.random.default_rng(13)
# bintik mineral kuning-hijau (berkelompok), & sedikit karat jingga
patch = tile_noise(N, 6, 14, 2)
speck = (r2.random((N, N)) < 0.03) & (patch > 0.6) & (crack < 0.3)
col[speck] = col[speck] * 0.35 + np.array([176, 206, 64]) * 0.65
tiny = (r2.random((N, N)) < 0.004) & (crack < 0.2)
col[tiny] = col[tiny] * 0.5 + np.array([150, 190, 70]) * 0.5
rust = (tile_noise(N, 5, 15, 2) > 0.72) & (r2.random((N, N)) < 0.12)
col[rust] = col[rust] * 0.65 + np.array([150, 92, 40]) * 0.35
col = np.round(col / 6.0) * 6.0
save(col, 'rock.png')

# ---------------------------------------------------------------- urat: cahaya hijau di sebagian retakan + bintik berpendar
pair = (np.minimum(idx, second) * 131 + np.maximum(idx, second) * 17) % 100
glowEdge = pair < 44
flick = 0.55 + 0.45 * tile_noise(N, 10, 21, 3)
vein = np.clip(1.25 - edge / 2.0, 0, 1) * glowEdge * flick
halo = np.clip(1 - edge / 4.5, 0, 1) * glowEdge * 0.28 * flick
v = np.clip(np.maximum(vein, halo), 0, 1)
dots = speck.astype(float) * 0.75 + tiny.astype(float) * 0.5
v = np.maximum(v, dots)
c_core = np.array([232, 255, 186]); c_mid = np.array([104, 255, 52]); c_edge = np.array([18, 92, 12])
vc = np.where((v > 0.7)[..., None], c_mid + (c_core - c_mid) * ((v - 0.7) / 0.3)[..., None],
              c_edge + (c_mid - c_edge) * (v / 0.7)[..., None])
vc = vc * np.clip(v * 1.6, 0, 1)[..., None]
vc = np.round(vc / 4.0) * 4.0
save(vc, 'veins.png')

# ---------------------------------------------------------------- inti: cairan radioaktif
M = 64
rl = np.random.default_rng(99)
lp = [(rl.random(), rl.random()) for _ in range(14)]
e1, e2, li, _ = torus_voronoi(M, lp)
le = (e2 - e1) * M
n1 = tile_noise(M, 4, 41, 4); n2 = tile_noise(M, 9, 42, 3)
heat = np.clip(0.55 + 0.55 * (n1 - 0.5) * 2 + 0.25 * (n2 - 0.5) * 2, 0, 1)
crust = np.clip((le - 2.0) / 3.0, 0, 1) * np.clip((0.6 - n2) * 3.0, 0, 1)
hotc = np.array([236, 255, 190]); midc = np.array([112, 255, 50]); deep = np.array([30, 150, 22]); dark = np.array([10, 38, 10])
lc = np.where((heat > 0.6)[..., None], midc + (hotc - midc) * ((heat - 0.6) / 0.4)[..., None], deep + (midc - deep) * (heat / 0.6)[..., None])
lc = lc * (1 - crust[..., None]) + dark * crust[..., None]
rb = np.random.default_rng(7)
for _ in range(9):   # gelembung terang
    bx, by, br = rb.integers(0, M), rb.integers(0, M), rb.uniform(1.2, 2.4)
    ys, xs = np.mgrid[0:M, 0:M]
    dx = np.minimum(np.abs(xs - bx), M - np.abs(xs - bx)); dy = np.minimum(np.abs(ys - by), M - np.abs(ys - by))
    ring = np.clip(1 - np.abs(np.sqrt(dx * dx + dy * dy) - br) / 0.9, 0, 1)
    lc = lc * (1 - ring[..., None] * 0.7) + hotc * ring[..., None] * 0.7
lc = np.round(lc / 4.0) * 4.0
save(lc, 'core.png')

# ---------------------------------------------------------------- kristal (padat, kena cahaya dunia): 32 x 64, v ke bawah
CW, CH = 32, 64
ys, xs = np.mgrid[0:CH, 0:CW]
vv = (ys + 0.5) / CH; uu = (xs + 0.5) / CW
grad = np.clip(vv / 0.95, 0, 1) ** 1.3
basec = np.array([28, 74, 30]); tipc = np.array([150, 232, 112])
cc = basec + (tipc - basec) * grad[..., None]
# sisi kristal: tepi terang di kiri, bayangan di kanan, garis tengah halus
cc *= (1.0 + 0.25 * np.exp(-((uu - 0.08) / 0.07) ** 2) - 0.22 * np.exp(-((uu - 0.9) / 0.1) ** 2))[..., None]
cc *= (0.94 + 0.08 * np.cos(uu * np.pi * 2.0 * 3.0))[..., None]
inc = tile_noise(CW, 3, 61, 3, M=CH, cells_y=6)
cc *= (0.85 + 0.3 * inc)[..., None]
rc = np.random.default_rng(5)
cloudy = (rc.random((CH, CW)) < 0.03) & (vv < 0.7)
cc[cloudy] = cc[cloudy] * 0.6 + np.array([200, 250, 170]) * 0.4
cc = np.round(cc / 4.0) * 4.0
save(cc, 'crystal.png')

# ---------------------------------------------------------------- kilau kristal (cahaya): berulang di v (digeser tiap gambar)
streak = np.zeros((CH, CW))
for (u0, wdt, a) in ((0.2, 0.05, 0.9), (0.47, 0.035, 0.6), (0.71, 0.06, 0.8)):
    du = np.abs(uu - u0); du = np.minimum(du, 1 - du)
    wob = 0.025 * np.sin(vv * np.pi * 2.0 * 2.0 + u0 * 9.0)
    streak = np.maximum(streak, a * np.exp(-((du + wob) / wdt) ** 2))
pulse = np.zeros((CH, CW))
for (v0, wd, a) in ((0.18, 0.07, 1.0), (0.62, 0.05, 0.7)):
    dv = np.abs(vv - v0); dv = np.minimum(dv, 1 - dv)
    pulse = np.maximum(pulse, a * np.exp(-(dv / wd) ** 2))
body = 0.32 + 0.12 * tile_noise(CW, 4, 71, 2, M=CH, cells_y=8)
g = np.clip(body + 0.55 * streak + 0.45 * pulse + 0.25 * streak * pulse, 0, 1.2)
dim = np.array([22, 80, 18]); mid = np.array([96, 240, 60]); hot = np.array([214, 255, 168])
gc = np.where((g > 0.7)[..., None], mid + (hot - mid) * np.clip((g - 0.7) / 0.4, 0, 1)[..., None],
              dim + (mid - dim) * (g / 0.7)[..., None])
gc = np.round(gc / 4.0) * 4.0
save(gc, 'crystal_glow.png')
print('ok', sorted(os.listdir(out)))
