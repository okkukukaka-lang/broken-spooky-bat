package com.shazammod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.joml.Vector3f;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.level.BlockEvent;

/**
 * 0.56 PRALAYA FASE DEWA (berarmor + keenam inti terpasang): juara paling OP. Semua skill berdampak ke SELURUH WORLD (semua
 * makhluk yang termuat di semua dimensi), tanpa cooldown, tanpa biaya daya, dan yang berdurasi jadi tanpa batas (tekan lagi
 * untuk mematikan). Henti Waktu jadi HENTI WAKTU DUNIA:
 *
 *   - seluruh server membeku memakai tick freeze bawaan Minecraft (sama dengan /tick freeze): makhluk, proyektil, item,
 *     redstone, tungku, tanaman, siang-malam, dan cuaca berhenti; client ikut membeku (nggak patah-patah)
 *   - pemain lain ikut beku: posisinya dikunci, nggak bisa menyerang, memakai barang, memecah / memasang blok, atau memakai
 *     kekuatan; cuma PRALAYA yang bergerak
 *   - damage PRALAYA ke makhluk yang membeku DITABUNG lalu ditagih x1,5 saat waktu berjalan lagi; damage lain diabaikan.
 *     0.58: yang ditabung damage FINAL (sesudah pengali tinju & skill), tagihannya nggak bisa dihindari / ditangkis rival,
 *     dan semua pukulan yang ditabung melempar korbannya sekaligus saat waktu berjalan lagi
 *   - berhenti kalau ditekan lagi, armor dilepas, PRALAYA keluar / mati, atau dicairkan dari luar (/tick unfreeze)
 *
 * Jam skill PRALAYA memakai tick server (AksaraSkills.now), bukan game time, karena game time ikut berhenti saat beku.
 */
@EventBusSubscriber(modid = ShazamMod.MODID)
public final class PralayaGod {
    private PralayaGod() {}

    /** Durasi "tanpa batas" (dimatikan dengan menekan lagi): ~14 jam. HUD menampilkan tak hingga. */
    public static final int FOREVER = 1_000_000;
    public static final double REACH = 160.0;          // jangkauan bidik Fase Dewa (dibatasi area yang termuat)
    public static final float STORED_INTEREST = 1.5f;  // damage yang ditabung saat waktu dunia berhenti
    private static final int MAX_TARGETS = 1500;       // pengaman: paling banyak segini makhluk per skill
    private static final int PULSE_GAP = 10;           // denyut layar seluruh world paling sering tiap segini tick

    /** Fase Dewa sedang berarmor. */
    public static boolean god(ServerPlayer p) {
        return ShazamPowers.isAksara(p) && PralayaProgress.phase(p) >= 3;
    }

    // ---------------------------------------------------------------- makhluk di seluruh world

    private static boolean enemy(LivingEntity m) {
        return m.isAlive() && m instanceof Enemy && !DemonSoldier.isFriendly(m);
    }

    /** Semua musuh yang termuat di semua dimensi (terdekat dulu kalau sedimensi), paling banyak MAX_TARGETS. */
    public static List<LivingEntity> enemies(ServerPlayer p) {
        List<LivingEntity> out = new ArrayList<>();
        for (ServerLevel level : p.server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                if (e instanceof LivingEntity m && m != p && !(m instanceof Player) && enemy(m)) {
                    out.add(m);
                }
            }
        }
        sortNear(p, out);
        return out.size() > MAX_TARGETS ? new ArrayList<>(out.subList(0, MAX_TARGETS)) : out;
    }

    /** Semua mob (musuh maupun bukan) yang termuat di semua dimensi. */
    public static List<Mob> mobs(ServerPlayer p) {
        List<Mob> out = new ArrayList<>();
        for (ServerLevel level : p.server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                if (e instanceof Mob m && m.isAlive()) {
                    out.add(m);
                }
            }
        }
        return out;
    }

    /** Proyektil milik siapa pun selain PRALAYA di semua dimensi. */
    public static List<Projectile> projectiles(ServerPlayer p) {
        List<Projectile> out = new ArrayList<>();
        for (ServerLevel level : p.server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                if (e instanceof Projectile pr && pr.isAlive() && pr.getOwner() != p) {
                    out.add(pr);
                }
            }
        }
        return out;
    }

    /** Pemain lain & peliharaan PRALAYA di semua dimensi. */
    public static List<LivingEntity> allies(ServerPlayer p) {
        List<LivingEntity> out = new ArrayList<>();
        for (ServerLevel level : p.server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                if (e instanceof LivingEntity l && l != p && l.isAlive()
                        && (l instanceof Player || (l instanceof TamableAnimal pet && pet.isOwnedBy(p)))) {
                    out.add(l);
                }
            }
        }
        return out;
    }

    private static <T extends LivingEntity> void sortNear(ServerPlayer p, List<T> list) {
        list.sort(Comparator.comparingDouble((T m) -> m.level() == p.level() ? m.distanceToSqr(p) : Double.MAX_VALUE));
    }

    public static Vec3 chest(Entity e) {
        return e.position().add(0, e.getBbHeight() * 0.55, 0);
    }

    // ---------------------------------------------------------------- tanda efek

    /**
     * Penanda efek seluruh world: animasi untuk paling banyak max target terdekat (yang sedimensi), dan debu warna inti
     * di SEMUA target (pemain yang ada di dekat target mana pun melihatnya). core 0-5 inti, 6 = keenamnya (putih).
     */
    public static void mark(ServerPlayer p, List<? extends LivingEntity> targets, ShazamAnim anim, int core, int max) {
        int sent = 0;
        for (LivingEntity m : targets) {
            if (sent >= max || m.level() != p.level()) {
                break;
            }
            if (anim != null) {
                ShazamNetwork.playAnim(p, anim, chest(m));
            }
            sent++;
        }
        int rgb = AksaraSkills.RGB[Math.max(0, Math.min(6, core))];
        DustParticleOptions dust = new DustParticleOptions(new Vector3f(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f,
                (rgb & 255) / 255f), 2.0f);
        for (LivingEntity m : targets) {
            if (m.level() instanceof ServerLevel level) {
                level.sendParticles(dust, m.getX(), m.getY() + m.getBbHeight() * 0.6, m.getZ(), 10, 0.3, 0.5, 0.3, 0.02);
            }
        }
    }

    private static final Map<UUID, Integer> PULSE_AT = new HashMap<>();

    /** Denyut warna inti di layar SEMUA pemain di server (skill Fase Dewa terasa di seluruh world). */
    public static void pulse(ServerPlayer p, int core) {
        int now = p.server.getTickCount();
        Integer last = PULSE_AT.get(p.getUUID());
        if (last != null && now - last < PULSE_GAP) {
            return;
        }
        PULSE_AT.put(p.getUUID(), now);
        ShazamNetwork.playAnimToAll(p.getId(), ShazamAnim.SABDA_WORLD, new Vec3(core, 0, 0));
    }

    // ---------------------------------------------------------------- Henti Waktu Dunia

    /** 0.57 jeda sebelum waktu berjalan lagi (= gong terbalik membengkak di AKSARA_WORLDRESUME, terputus tepat di ujungnya). */
    public static final int RESUME_WINDUP = 30;

    private static final double DEBT_PUSH = 0.55;   // 0.58 dorongan per pukulan yang ditabung (dilepas saat waktu berjalan)
    private static final double DEBT_PUSH_MAX = 3.2;

    private static UUID owner;
    private static boolean wasFrozen;
    private static int resumeAt = -1;   // tick server saat waktu berjalan lagi (-1 = belum diminta)
    private static int collecting;      // 0.58 > 0 selama tagihan waktu sedang ditagih
    private static final Map<UUID, Float> STORED = new HashMap<>();
    private static final Map<UUID, Vec3> PUSHED = new HashMap<>();   // 0.58 dorongan pukulan yang ditabung
    private static final Map<UUID, Vec3> LOCKED = new HashMap<>();

    /** 0.58 Entitas ini PRALAYA yang sedang memegang waktu dunia. */
    public static boolean isOwner(Entity e) {
        return owner != null && e != null && owner.equals(e.getUUID());
    }

    /** 0.58 Sedang menagih damage yang ditabung selama waktu berhenti (dunia maupun Henti Kala biasa). */
    public static boolean collectingDebt() {
        return collecting > 0;
    }

    /**
     * 0.58 Tagihan waktu: damage yang ditabung masuk sekaligus. Nggak bisa dihindari / ditangkis (rival), pengalinya sudah
     * dihitung saat ditabung (AksaraSkills & rival nggak mengalikannya lagi).
     */
    public static boolean chargeDebt(LivingEntity victim, DamageSource source, float amount) {
        collecting++;
        try {
            victim.invulnerableTime = 0;
            return victim.hurt(source, amount);
        } finally {
            collecting--;
        }
    }

    public static boolean stopped() {
        return owner != null;
    }

    public static boolean ownsStop(ServerPlayer p) {
        return owner != null && owner.equals(p.getUUID());
    }

    /** Pemain ini sedang dibekukan Henti Waktu Dunia (server). */
    public static boolean frozen(Player p) {
        return owner != null && !p.level().isClientSide() && !owner.equals(p.getUUID()) && !p.isCreative() && !p.isSpectator();
    }

    /**
     * B di Fase Dewa: hentikan / jalankan lagi waktu seluruh world. 0.57: menjalankan lagi butuh jeda RESUME_WINDUP tick
     * (semua client mendengar gong terbalik yang membengkak, lalu waktu berjalan tepat saat suaranya terputus).
     */
    public static boolean toggleStop(ServerPlayer p) {
        if (ownsStop(p)) {
            if (resumeAt >= 0) {   // sudah menunggu waktu berjalan lagi
                return false;
            }
            resumeAt = p.server.getTickCount() + RESUME_WINDUP;
            ShazamNetwork.playAnimToAll(p.getId(), ShazamAnim.SABDA_WORLD_TIME, new Vec3(2, 0, 0));
            return true;
        }
        if (owner != null) {   // PRALAYA lain sedang memegang waktu
            p.displayClientMessage(Component.translatable("message.shazammod.pralaya.world_busy").withStyle(ChatFormatting.GRAY),
                    true);
            return false;
        }
        MinecraftServer server = p.server;
        wasFrozen = server.tickRateManager().isFrozen();
        owner = p.getUUID();
        resumeAt = -1;
        STORED.clear();
        PUSHED.clear();
        LOCKED.clear();
        server.tickRateManager().setFrozen(true);
        // 0.57 suara & shader layar diputar di tiap client (AksaraFx.worldAnim), bukan suara dunia dari server
        ShazamNetwork.playAnimToAll(p.getId(), ShazamAnim.SABDA_WORLD_TIME, new Vec3(1, 0, 0));
        for (ServerPlayer other : server.getPlayerList().getPlayers()) {
            other.displayClientMessage(Component.translatable(other == p ? "message.shazammod.pralaya.world_stop_self"
                    : "message.shazammod.pralaya.world_stop", p.getDisplayName()).withStyle(ChatFormatting.GOLD,
                    ChatFormatting.BOLD), false);
        }
        return true;
    }

    /** Waktu berjalan lagi: semua damage yang ditabung ditagih sekaligus (x1,5). unfreeze false = sudah dicairkan dari luar. */
    public static void end(MinecraftServer server, boolean unfreeze) {
        if (owner == null) {
            return;
        }
        ServerPlayer p = server.getPlayerList().getPlayer(owner);
        boolean planned = resumeAt >= 0 && server.getTickCount() >= resumeAt;   // sesudah jeda (suaranya sudah diputar)
        owner = null;
        resumeAt = -1;
        if (unfreeze) {
            server.tickRateManager().setFrozen(wasFrozen);
        }
        float total = 0f;
        int count = 0;
        for (Map.Entry<UUID, Float> e : STORED.entrySet()) {
            for (ServerLevel level : server.getAllLevels()) {
                if (level.getEntity(e.getKey()) instanceof LivingEntity m && m.isAlive()) {
                    float amount = e.getValue() * STORED_INTEREST;
                    chargeDebt(m, p != null ? ShazamPowers.forceSource(p) : level.damageSources().magic(), amount);
                    Vec3 push = PUSHED.get(e.getKey());
                    if (push != null) {   // semua pukulan yang ditabung melempar korbannya sekaligus
                        m.push(push.x, push.y, push.z);
                        m.hurtMarked = true;
                    }
                    if (p != null && count < 24 && m.level() == p.level()) {
                        ShazamNetwork.playAnim(p, ShazamAnim.SABDA_HIT, chest(m));
                    }
                    total += amount;
                    count++;
                    break;
                }
            }
        }
        STORED.clear();
        PUSHED.clear();
        LOCKED.clear();
        ShazamNetwork.playAnimToAll(p != null ? p.getId() : -1, ShazamAnim.SABDA_WORLD_TIME,
                new Vec3(0, count, planned ? 1 : 0));
        if (p != null) {
            p.displayClientMessage(Component.translatable("message.shazammod.pralaya.world_resume", count, Math.round(total))
                    .withStyle(ChatFormatting.GOLD), false);
        }
    }

    /** Tiap tick server: pemiliknya masih ada & masih Fase Dewa, dunia masih beku, pemain lain tetap terkunci. */
    public static void serverTick(MinecraftServer server) {
        if (owner == null) {
            return;
        }
        ServerPlayer p = server.getPlayerList().getPlayer(owner);
        if (p == null || !god(p)) {
            end(server, true);
            return;
        }
        if (!server.tickRateManager().isFrozen()) {   // dicairkan dari luar (/tick unfreeze): ikut selesai
            end(server, false);
            return;
        }
        if (resumeAt >= 0 && server.getTickCount() >= resumeAt) {   // 0.57 jeda selesai: waktu berjalan lagi
            end(server, true);
            return;
        }
        for (ServerPlayer other : server.getPlayerList().getPlayers()) {
            if (!frozen(other) || !other.isAlive()) {
                LOCKED.remove(other.getUUID());
                continue;
            }
            Vec3 at = LOCKED.get(other.getUUID());
            if (at == null) {
                other.stopRiding();
                LOCKED.put(other.getUUID(), other.position());
                continue;
            }
            if (other.position().distanceToSqr(at) > 0.0025) {
                other.connection.teleport(at.x, at.y, at.z, other.getYRot(), other.getXRot());
            }
            other.setDeltaMovement(Vec3.ZERO);
            other.fallDistance = 0f;
        }
    }

    /** Pemain masuk di tengah Henti Waktu Dunia: client-nya dikabari (ikut membeku, layar memucat). */
    public static void onLogin(ServerPlayer player) {
        if (owner == null) {
            return;
        }
        ServerPlayer p = player.server.getPlayerList().getPlayer(owner);
        // y = 1: masuk di tengah jalan, layar langsung kelabu tanpa suara & bola pembuka
        net.neoforged.neoforge.network.PacketDistributor.sendToPlayer(player, new ShazamAnimPayload(p != null ? p.getId() : -1,
                ShazamAnim.SABDA_WORLD_TIME.ordinal(), 1f, 1f, 0f));
    }

    /** Server berhenti: dunia dicairkan dulu (kondisi beku nggak tersimpan, tapi biar rapi). */
    public static void clear(MinecraftServer server) {
        end(server, true);
        PULSE_AT.clear();
    }

    /**
     * Paling awal di ShazamPowers.onIncomingDamage. Selama waktu dunia berhenti: damage PRALAYA ke makhluk yang beku
     * ditabung (ditagih saat waktu berjalan lagi), damage lain diabaikan. true = sudah diurus (dibatalkan).
     */
    public static boolean interceptDamage(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        if (owner == null || victim.level().isClientSide() || owner.equals(victim.getUUID())
                || event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return false;
        }
        if (debt(event)) {
            return false;   // 0.58 dibiarkan lewat dulu (pengali tinju & skill dihitung), ditabung di onIncomingLast
        }
        event.setCanceled(true);
        return true;
    }

    /** Damage PRALAYA pemegang waktu ke makhluk (bukan pemain) selama waktu dunia berhenti: ditabung, bukan diabaikan. */
    private static boolean debt(LivingIncomingDamageEvent event) {
        return !(event.getEntity() instanceof Player) && isOwner(event.getSource().getEntity());
    }

    /**
     * 0.58 Paling akhir (sesudah ShazamPowers & mod lain): damage PRALAYA yang sudah final ditabung lalu dibatalkan. Dulu
     * ditabung di awal (sebelum pengali tinju), jadi tinju dewa cuma tercatat 1-2 damage dan rival seperti kebal.
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onIncomingLast(LivingIncomingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        if (owner == null || victim.level().isClientSide() || collecting > 0 || owner.equals(victim.getUUID())
                || event.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY) || !debt(event)) {
            return;
        }
        float amount = event.getAmount();
        event.setCanceled(true);
        if (amount <= 0f) {
            return;
        }
        float total = STORED.merge(victim.getUUID(), amount, Float::sum);
        Entity attacker = event.getSource().getEntity();
        boolean melee = event.getSource().getDirectEntity() == attacker;
        Vec3 dir = melee ? attacker.getLookAngle() : victim.position().subtract(attacker.position());
        dir = new Vec3(dir.x, 0, dir.z);
        dir = dir.lengthSqr() < 1.0E-4 ? Vec3.ZERO : dir.normalize().scale(melee ? DEBT_PUSH : DEBT_PUSH * 0.4);
        Vec3 push = PUSHED.getOrDefault(victim.getUUID(), Vec3.ZERO).add(dir.x, melee ? 0.12 : 0.05, dir.z);
        double flat = Math.sqrt(push.x * push.x + push.z * push.z);
        if (flat > DEBT_PUSH_MAX) {
            push = new Vec3(push.x * DEBT_PUSH_MAX / flat, push.y, push.z * DEBT_PUSH_MAX / flat);
        }
        PUSHED.put(victim.getUUID(), new Vec3(push.x, Math.min(push.y, 1.1), push.z));
        if (melee && attacker instanceof ServerPlayer p) {   // pukulan terasa: berapa yang sudah ditabung di korban ini
            p.displayClientMessage(Component.translatable("message.shazammod.pralaya.world_debt", victim.getDisplayName(),
                    Math.round(total * STORED_INTEREST)).withStyle(ChatFormatting.GOLD), true);
        }
    }

    // ---------------------------------------------------------------- pemain yang membeku nggak bisa berbuat apa-apa

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent event) {
        if (frozen(event.getEntity())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (frozen(event.getEntity())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (frozen(event.getEntity())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        if (frozen(event.getEntity())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (frozen(event.getEntity())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent event) {
        if (frozen(event.getPlayer())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onPlace(BlockEvent.EntityPlaceEvent event) {
        if (event.getEntity() instanceof Player player && frozen(player)) {
            event.setCanceled(true);
        }
    }
}
