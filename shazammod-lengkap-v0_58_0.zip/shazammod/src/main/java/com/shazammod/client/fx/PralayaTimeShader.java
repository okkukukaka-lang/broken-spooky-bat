package com.shazammod.client.fx;

import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector4f;
import org.slf4j.Logger;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.logging.LogUtils;
import com.shazammod.ShazamMod;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * 0.57 Henti Waktu Dunia ala anime: shader layar (post-processing) di atas gambar dunia. Bola berwarna terbalik
 * mengembang dari pemegang waktu dengan tepi yang mendistorsi layar, menciut lagi sambil meninggalkan dunia kelabu, dunia
 * berdenyut halus tiap detak jam, lalu saat waktu berjalan lagi bola berwarna normal mengembang. Urutannya diatur
 * AksaraFx.timeStopLook. Kalau shader-nya gagal dimuat (driver / mod shader lain), AksaraFx memakai lapisan kelabu biasa.
 */
public final class PralayaTimeShader {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final ResourceLocation CHAIN = ResourceLocation.fromNamespaceAndPath(ShazamMod.MODID,
            "shaders/post/pralaya_timestop.json");

    private static PostChain chain;
    private static boolean failed;
    private static boolean checked, pack;   // shader pack Iris aktif? (dicek sekali tiap efeknya mulai)
    private static int width = -1, height = -1;

    private PralayaTimeShader() {}

    /** Shader-nya nggak bisa dipakai saat ini: AksaraFx menggantinya dengan lapisan kelabu. */
    public static boolean failed() {
        return failed || pack;
    }

    /** Shader pack Iris sedang dipakai: gambar dunianya diatur Iris, post-processing sendiri bisa tertimpa. */
    private static boolean shaderPackInUse() {
        try {
            Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Object instance = api.getMethod("getInstance").invoke(null);
            return Boolean.TRUE.equals(api.getMethod("isShaderPackInUse").invoke(instance));
        } catch (Throwable notInstalled) {
            return false;
        }
    }

    /** Dipanggil paling akhir di RenderLevelStageEvent (prioritas LOWEST), cuma di tahap AFTER_LEVEL. */
    public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_LEVEL) {
            return;
        }
        // Detik shader ikut tick client, bukan waktu game (waktu game ikut berhenti selama Henti Waktu Dunia)
        float pt = event.getPartialTick().getGameTimeDeltaPartialTick(true);
        float[] look = AksaraFx.timeStopLook(pt);
        if (look == null) {
            close();
            return;
        }
        if (!checked) {
            checked = true;
            pack = shaderPackInUse();
        }
        if (failed || pack) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        RenderTarget main = mc.getMainRenderTarget();
        try {
            if (chain == null) {
                chain = new PostChain(mc.getTextureManager(), mc.getResourceManager(), main, CHAIN);
                width = -1;
                height = -1;
            }
            if (main.width != width || main.height != height) {
                width = main.width;
                height = main.height;
                chain.resize(width, height);
            }
            float[] center = center(event, mc, pt);
            chain.setUniform("Clock", AksaraFx.timeClock(pt));
            chain.setUniform("Radius", look[0]);
            chain.setUniform("CenterX", center[0]);
            chain.setUniform("CenterY", center[1]);
            chain.setUniform("InsideInvert", look[1]);
            chain.setUniform("InsideGray", look[2]);
            chain.setUniform("OutsideGray", look[3]);
            chain.setUniform("Ripple", look[4]);
            chain.setUniform("Pulse", look[5]);
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.resetTextureMatrix();
            chain.process(pt);
        } catch (Exception e) {
            failed = true;
            LOGGER.warn("PRALAYA: shader Henti Waktu Dunia gagal dipakai, diganti lapisan kelabu biasa", e);
            close();
        } finally {
            main.bindWrite(true);
            RenderSystem.enableDepthTest();
        }
    }

    /**
     * Pusat bola di layar (0..1, boleh di luar layar): dada pemegang waktu. Tengah layar kalau dia sendiri yang memegang
     * (orang pertama), ada di belakang kamera, atau nggak termuat (jauh / beda dimensi).
     */
    private static float[] center(RenderLevelStageEvent event, Minecraft mc, float pt) {
        float[] middle = {0.5f, 0.5f};
        Entity owner = mc.level != null ? mc.level.getEntity(AksaraFx.timeLookOwner()) : null;
        if (owner == null || owner == mc.player && mc.options.getCameraType().isFirstPerson()) {
            return middle;
        }
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        Vec3 at = owner.getPosition(pt).add(0.0, owner.getBbHeight() * 0.62, 0.0);
        Vector4f v = new Vector4f((float) (at.x - cam.x), (float) (at.y - cam.y), (float) (at.z - cam.z), 1.0f);
        v.mul(new Matrix4f().rotation(camera.rotation().conjugate(new Quaternionf())));
        v.mul(event.getProjectionMatrix());
        if (v.w < 0.05f) {
            return middle;
        }
        return new float[] {Mth.clamp(v.x / v.w * 0.5f + 0.5f, -1.0f, 2.0f), Mth.clamp(v.y / v.w * 0.5f + 0.5f, -1.0f, 2.0f)};
    }

    /** Efeknya selesai / keluar world: shader dilepas (dibuat lagi waktu dipakai lagi). */
    public static void close() {
        if (chain != null) {
            try {
                chain.close();
            } catch (RuntimeException ignored) {
                // melepas shader nggak boleh bikin game crash
            }
            chain = null;
        }
        width = -1;
        height = -1;
        checked = false;
        pack = false;
    }
}
