#version 150

// 0.57 PRALAYA - Henti Waktu Dunia: bola berwarna terbalik mengembang dari pemegang waktu, tepinya mendistorsi layar,
// lalu menciut dan meninggalkan dunia kelabu. Saat waktu berjalan lagi, bola berwarna normal mengembang lagi.

uniform sampler2D DiffuseSampler;

uniform vec2 InSize;
uniform float Clock;        // detik (berulang tiap 100 detik), dipakai untuk gelombang
uniform float Radius;       // jari-jari bola, dalam satuan tinggi layar (0 = nggak ada bola)
uniform float CenterX;      // pusat bola di layar (0..1, boleh di luar layar)
uniform float CenterY;
uniform float InsideInvert; // 1 = warna di dalam bola dibalik
uniform float InsideGray;   // kelabu di dalam bola
uniform float OutsideGray;  // kelabu di luar bola
uniform float Ripple;       // kuat distorsi tepi bola + getaran halus seluruh layar
uniform float Pulse;        // denyut menyempit ke pusat (tiap detak jam)

in vec2 texCoord;

out vec4 fragColor;

const float TAU = 6.2831853;

float luma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

vec3 gray(vec3 c, float amount) {
    float l = clamp((luma(c) - 0.5) * 1.1 + 0.5, 0.0, 1.0);   // kelabu sedikit lebih kontras
    return mix(c, vec3(l), amount);
}

vec3 fetch(vec2 uv) {
    return texture(DiffuseSampler, clamp(uv, vec2(0.0005), vec2(0.9995))).rgb;
}

void main() {
    float aspect = InSize.x / max(InSize.y, 1.0);
    vec2 scale = vec2(aspect, 1.0);
    vec2 center = vec2(CenterX, CenterY);
    vec2 d = (texCoord - center) * scale;
    float dist = length(d);
    vec2 dir = dist > 0.00001 ? d / dist : vec2(0.0, 1.0);
    float on = step(0.0005, Radius);

    // tepi bola: pita distorsi yang bergelombang
    float edge = dist - Radius;
    float band = exp(-edge * edge * 180.0) * on;
    float wave = sin(edge * 60.0 - Clock * TAU * 6.0);
    vec2 push = dir * band * (0.03 + 0.012 * wave) * Ripple;

    // seluruh layar: getaran halus + denyut menyempit ke pusat
    float wob = sin(texCoord.y * 46.0 + Clock * TAU * 3.0) * 0.0018 * Ripple;
    vec2 uv = texCoord - push / scale;
    uv.x += wob;
    uv = center + (uv - center) * (1.0 - 0.012 * Pulse);

    // warna terpisah di tepi bola & saat denyut
    vec2 sd = dir / scale * (band * 0.007 * Ripple + 0.002 * Pulse);
    vec3 col = vec3(fetch(uv + sd).r, fetch(uv).g, fetch(uv - sd).b);

    float inside = (1.0 - smoothstep(-0.006, 0.006, edge)) * on;
    vec3 inCol = gray(mix(col, vec3(1.0) - col, InsideInvert), InsideGray);
    vec3 outCol = gray(col, OutsideGray);
    vec3 result = mix(outCol, inCol, inside) + vec3(band * 0.12 * Ripple);
    fragColor = vec4(clamp(result, 0.0, 1.0), 1.0);
}
