"""SFX PRALAYA, Sang Mesin Kiamat (0.51, robot/AI — bukan magis). Dibuat dari nol dengan synth.py.

    python3 tools/sfx/aksara_sfx.py src/main/resources/assets/shazammod/sounds [nama ...]

Ciri suaranya: MEKANIS & DIGITAL — servo/aktuator, dentang logam, dengung reaktor, bass sub, zap/glitch digital, dan
suara sintetis dingin yang terdistorsi (tanpa kata) untuk momen besar. Nama recipe & jumlahnya SAMA dengan versi lama
supaya names.txt/gen.py nggak berubah; cuma DSP-nya yang diganti. Puncaknya tetap dikunci ke tick ShazamAnim.AKSARA_*:

    aksara_transform 2,2 dtk | aksara_nova 1,1 | aksara_purna 1,7 | aksara_erase 3,2 | aksara_rite 7,5 | aksara_soul 2,4
    aksara_timestop 0,6 | aksara_lance 0,45 | aksara_beam mulai 0,4 | aksara_dominion 0,9 | aksara_rewrite 0,8
    aksara_fold 0,25 | aksara_gate 0,5 | aksara_ward 0,6 | aksara_rewind 0,5
Putar di pitch 1 supaya puncaknya nggak bergeser. Kecuali aksara_core (0.52, inti daya menyala): sengaja diputar dengan
pitch per inti (0,84 / 0,945 / 1,05 / 1,26 / 1,4 / 1,575), jadi keenam inti berurutan jadi akor.
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
_argv = sys.argv
sys.argv = [sys.argv[0]]
import synth as s                 # noqa: E402
sys.argv = _argv

SR = s.SR


# ------------------------------------------------------------------ alat bantu mekanis

def env(dur, tau):
    return s.env_exp(int(dur * SR), tau)


def crush(x, bits=6, rate=6000):
    """Bitcrush + penurunan sample-rate: bikin suara jadi digital/kasar."""
    step = 2.0 ** (bits - 1)
    y = np.round(np.clip(x, -1, 1) * step) / step
    hold = max(1, int(SR / rate))
    n = len(y)
    idx = (np.arange(n) // hold) * hold
    return y[np.clip(idx, 0, n - 1)]


def servo(dur, f0, f1, rng, amp=0.4, grit=0.3):
    """Aktuator: nada saw yang menyapu pitch + flutter amplitudo + sedikit noise gerigi."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    f = np.geomspace(max(1.0, f0), max(1.0, f1), n)
    y = s.osc(f, dur, "saw") * (0.6 + 0.4 * np.sin(2 * np.pi * 42 * t))
    y = s.lp(y, 2600)
    g = s.bp(s.white(n, rng), 1500, 5000, 2) * grit
    e = np.minimum(1, t / 0.02) * np.minimum(1, (dur - t) / 0.05)
    return (y + g) * e * amp


def whine(dur, f0, f1, amp=0.3):
    """Spin-up/spin-down murni (sine naik/turun)."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    f = np.geomspace(max(1.0, f0), max(1.0, f1), n)
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.4 * np.sin(2 * np.pi * np.cumsum(f * 1.5) / SR)
    e = np.minimum(1, t / 0.02) * np.minimum(1, (dur - t) / 0.06)
    return y * e * amp


def clank(rng, f=520, dur=0.4, bright=1.0, tau=0.12):
    """Dentang logam: bell inharmonik + klik noise transient."""
    partials = ((1.0, 1.0), (1.42, 0.5 * bright), (2.31, 0.3 * bright), (3.17, 0.16 * bright), (4.9, 0.08 * bright))
    bell = s.bell(f, dur, rng, partials, tau, 0.001)
    click = s.bp(s.white(int(0.02 * SR), rng), 1800, 8000, 2) * env(0.02, 0.004) * 0.9
    return s.mix(bell * 0.7, click)


def boom(rng, f0=90, f1=34, dur=1.0, body=0.5, sub=0.6):
    """Hentakan sub-bass mekanis."""
    return s.thump(rng, f0, f1, dur, 0.1, body, sub)


def zap(dur, rng, lo=400, hi=6000, drop=True):
    """Zap digital: noise terfilter + nada turun, lalu di-bitcrush."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    tone = s.osc(np.geomspace(1400, 300, n) if drop else np.geomspace(300, 1400, n), dur, "square") * 0.3
    nz = s.bp(s.white(n, rng), lo, hi, 2) * 0.5
    y = crush((tone + nz) * env(dur, dur / 3), 5, 7000)
    return y


def charge(dur, f0=120, f1=1200, amp=0.4):
    """Pengisian daya: saw naik + filter membuka + flutter, makin keras."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    y = s.osc(np.geomspace(f0, f1, n), dur, "saw")
    y = s.sweep_filter(y, np.geomspace(400, 5000, n), "low", 1.4)
    y = y * (t / dur) ** 2 * (0.7 + 0.3 * np.sin(2 * np.pi * 30 * t))
    return y * amp


def reactorhum(dur, f=70, amp=0.22):
    """Dengung reaktor kontinu (dua saw berselisih tipis + filter)."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    y = s.osc(f, dur, "saw") + s.osc(f * 1.004, dur, "saw") + s.osc(f * 2, dur, "saw") * 0.4
    y = s.lp(y, 900) * (1 + 0.15 * np.sin(2 * np.pi * 7 * t))
    e = np.minimum(1, t / 0.1) * np.minimum(1, (dur - t) / 0.2)
    return y * e * amp


def glitch(dur, rng, amp=0.4):
    """Semburan glitch digital yang ter-gate acak."""
    n = int(dur * SR)
    y = s.bp(s.white(n, rng), 300, 9000, 2)
    gate = np.zeros(n)
    i = 0
    while i < n:
        seg = rng.integers(int(0.005 * SR), int(0.04 * SR))
        if rng.random() < 0.55:
            gate[i:i + seg] = rng.uniform(0.3, 1.0)
        i += seg
    return crush(y * gate, 4, 5000) * amp


def voice(dur, rng, base=120, menace=1.0, amp=0.26):
    """Suara sintetis dingin tanpa kata (saw detune + formant bandpass + soft clip): aura AI yang mengancam."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    vib = 1 + 0.01 * np.sin(2 * np.pi * 5.5 * t)
    y = sum(s.osc(base * r * vib, dur, "saw") for r in (0.5, 1.0, 1.5 * menace)) / 3
    f1 = s.bp(y, 350, 700, 2)
    f2 = s.bp(y, 1100, 2100, 2) * 0.7
    y = np.tanh((f1 + f2) * 2.2)
    e = s.env_adsr(dur, 0.2, 0.2, 0.8, 0.5)
    return y * e * amp


def static_bed(dur, rng, lo=80, hi=12000, amp=0.5):
    return s.bp(s.white(int(dur * SR), rng), lo, hi, 2) * env(dur, dur / 3) * amp


def place(total, *items):
    out = np.zeros(int(total * SR))
    for sec, x in items:
        i = int(sec * SR)
        if i >= len(out):
            continue
        e = min(len(out), i + len(x))
        out[i:e] += x[:e - i]
    return out


def tape(x, f0=1.0, f1=0.25):
    """Pita melambat (untuk Stasis): nada & tempo turun bersamaan."""
    n = len(x)
    speed = np.geomspace(f0, f1, n)
    pos = np.cumsum(speed)
    pos = pos[pos < n - 1]
    return np.interp(pos, np.arange(n), x)


# ------------------------------------------------------------------ resep

# 0.55 armor yang dipanggil: tick tiap bagian armor mengunci / terlepas (SAMA dengan AksaraFx.ARRIVE / DETACH)
ARMOR_ARRIVE = [20, 23, 27, 31, 33, 38]
ARMOR_DETACH = [6, 7, 8, 9, 10, 11]


def beep(dur, f, amp=0.25):
    """Bip digital pendek (sinyal panggilan armor)."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    return np.sin(2 * np.pi * f * t) * np.minimum(1, t / 0.004) * np.minimum(1, (dur - t) / 0.02) * amp


def aksara_transform(rng, v):
    """0.55 Armor dipanggil dari jauh: sinyal panggilan (tiga bip naik), keenam bagian armor datang mendesing dari langit
    dan MENGUNCI tepat di tick ARMOR_ARRIVE (dentang + desis hidrolik), lalu armornya menyegel & menyala di 2,2 dtk
    (= ShazamAnim.AKSARA_MORPH_BURST)."""
    total, hit = 3.6, 2.2
    parts = [(0.0, crush(beep(0.07, 880), 7, 9000)), (0.12, crush(beep(0.07, 1175), 7, 9000)),
             (0.24, crush(beep(0.11, 1568), 7, 9000)), (0.3, charge(hit - 0.3, 70, 300, 0.22))]
    for k, tick in enumerate(ARMOR_ARRIVE):
        sec = tick / 20.0
        parts.append((max(0.0, sec - 0.5), s.whoosh(rng, k % 3) * 0.55))              # desing datang (puncak ~0,5 dtk)
        parts.append((sec, clank(rng, 300 + k * 55, 0.5, 1.2, 0.14) * 0.9))           # mengunci
        parts.append((sec + 0.03, servo(0.16, 900, 380, rng, 0.12, 0.35)))            # desis hidrolik
    parts.append((hit - 0.4, whine(0.4, 300, 1600, 0.3)))
    parts.append((hit, boom(rng, 90, 30, 2.0, 0.6, 0.8) * 1.4))
    parts.append((hit, clank(rng, 240, 1.2, 1.3, 0.3) * 1.2))
    parts.append((hit, static_bed(0.8, rng, 200, 9000, 0.5)))
    parts.append((hit, voice(1.4, rng, 90, 1.0, 0.26)))
    parts.append((hit - 0.15, reactorhum(total - hit + 0.15, 70, 0.2)))              # reaktor armor menyala
    return s.reverb(place(total, *parts), 1.6, 0.22, rng=rng)


def aksara_revert(rng, v):
    """0.55 Armor dilepas: daya turun, lalu bagian demi bagian terlepas (desis + dentang ringan) dan mendesing pergi.
    Server memutarnya saat status berubah dilepas, REVERT_WINDUP (6 tick) sesudah animasi REVERT: waktunya digeser."""
    parts = [(0.0, whine(0.6, 900, 160, 0.3)), (0.0, reactorhum(0.8, 60, 0.12) * np.linspace(1, 0, int(0.8 * SR)))]
    for k, tick in enumerate(ARMOR_DETACH):
        sec = (tick - 6) / 20.0 + 0.02
        parts.append((sec, servo(0.12, 400, 900, rng, 0.12, 0.4)))
        parts.append((sec, clank(rng, 560 - k * 35, 0.25, 0.7, 0.08) * 0.7))
        parts.append((sec + 0.02, s.whoosh(rng, k % 3) * 0.35))
    return s.reverb(place(1.8, *parts), 1.4, 0.2, rng=rng)


def aksara_pulse(rng, v):
    base = 480 + v * 120
    parts = [(i * 0.05, clank(rng, base + i * 50, 0.2, 0.6, 0.06) * 0.4) for i in range(4)]
    parts.append((0.0, servo(0.5, 300, 360, rng, 0.12, 0.1)))
    return s.reverb(place(0.9, *parts), 0.9, 0.16, rng=rng)


def aksara_punch(rng, v):
    hit = s.mix(boom(rng, 130, 60, 0.4, 0.3, 0.5) * 0.9, clank(rng, 300, 0.3, 1.0, 0.07))
    return s.reverb(place(0.6, (0.0, hit), (0.0, zap(0.2, rng, 600, 7000) * 0.4)), 0.7, 0.16, rng=rng)


def aksara_sixfold(rng, v):
    total = 1.6
    hiss = whine(0.3, 200, 900, 0.25)              # piston hidrolik
    slam = s.mix(boom(rng, 80, 30, 1.0, 0.4, 0.9) * 1.3, clank(rng, 180, 0.8, 1.4, 0.2) * 1.2)
    metal = static_bed(0.4, rng, 300, 8000, 0.6)
    return s.reverb(place(total, (0.0, hiss), (0.3, slam), (0.3, metal), (0.3, glitch(0.4, rng, 0.3))), 1.4, 0.24, rng=rng)


def aksara_beam(rng, v):
    total, start, end = 2.6, 0.4, 2.0
    pre = charge(start, 200, 1000, 0.4)
    dur = end - start
    m = int(dur * SR)
    t = np.arange(m) / SR
    body = (s.osc(110 * (1 + 0.008 * np.sin(2 * np.pi * 8 * t)), dur, "saw") + s.osc(165, dur, "saw") * 0.6)
    body = s.sweep_filter(body, 1400 + 300 * np.sin(2 * np.pi * 6 * t), "low", 1.6) * 0.34
    hiss = s.bp(s.white(m, rng), 2500, 11000, 2) * (0.22 + 0.08 * np.sin(2 * np.pi * 12 * t))
    beam = (body + hiss) * np.minimum(1, t / 0.03) * np.minimum(1, (dur - t) / 0.08)
    blast = boom(rng, 110, 44, 0.6, 0.2, 0.5)
    return s.reverb(place(total, (0.0, pre), (start, beam), (end - 0.05, blast)), 1.3, 0.2, rng=rng)


def aksara_nova(rng, v):
    total, hit = 3.0, 1.1
    gather = charge(hit, 100, 1400, 0.5)
    blast = s.mix(boom(rng, 80, 26, 2.0, 0.5, 1.0) * 1.4, static_bed(1.0, rng, 150, 9000, 0.8))
    zp = zap(0.6, rng, 300, 9000) * 0.6
    return s.reverb(place(total, (0.0, gather), (0.0, whine(hit, 120, 900, 0.2)), (hit, blast), (hit, zp)), 2.0, 0.26,
                    rng=rng)


def aksara_fold(rng, v):
    snap = 0.25
    pre = whine(snap, 1400, 300, 0.25)
    pop = s.mix(zap(0.08, rng, 1500, 10000), clank(rng, 700, 0.2, 0.9, 0.05) * 0.6)
    sub = s.sub_drop(220, 60, 0.3, 0.07) * 0.6
    return s.reverb(place(0.8, (0.0, pre), (snap, pop), (snap, sub)), 0.9, 0.2, rng=rng)


def aksara_gate(rng, v):
    total, open_ = 2.6, 0.5
    n = int(total * SR)
    t = np.arange(n) / SR
    drone = (s.osc(55, total, "saw") + s.osc(55 * 1.006, total, "saw")) * 0.5
    drone = s.sweep_filter(drone, np.concatenate([np.geomspace(120, 900, int(0.5 * SR)),
                                                  np.full(n - int(0.5 * SR), 900.0)]), "low", 1.6)
    drone = drone * np.minimum(1, t / 0.3) * np.minimum(1, (total - t) / 0.4) * 0.5
    pull = s.air_whoosh(1.4, rng, 1200, 300, 120, 1.1, 0.4) * 0.5   # graviton menyedot
    y = place(total, (0.0, drone), (0.1, pull), (open_, boom(rng, 55, 28, 1.2, 0.3, 0.6) * 0.9),
              (open_, whine(0.3, 300, 80, 0.2)))
    return s.reverb(y, 2.2, 0.26, rng=rng)


def aksara_lance(rng, v):
    total, hit = 1.2, 0.45
    pre = whine(hit, 500, 2600, 0.22)
    stab = s.mix(zap(0.25, rng, 1000, 11000), clank(rng, 1400, 0.3, 0.8, 0.06) * 0.5)
    return s.reverb(place(total, (0.0, pre), (hit, stab), (hit, boom(rng, 160, 80, 0.3, 0.1, 0.4) * 0.5)), 1.2, 0.24,
                    rng=rng)


def aksara_dominion(rng, v):
    total, hit = 2.4, 0.9
    scan = servo(hit, 300, 600, rng, 0.2, 0.2)
    wave = s.air_whoosh(1.0, rng, 300, 1400, 400, 1.0, 0.3) * 0.5
    wash = glitch(1.0, rng, 0.35)                  # sinyal retas
    return s.reverb(place(total, (0.0, scan), (hit, wave), (hit, wash), (hit, boom(rng, 70, 34, 0.8, 0.2, 0.4) * 0.6)),
                    1.8, 0.24, rng=rng)


def aksara_rewrite(rng, v):
    total, hit = 1.6, 0.8
    buzz = s.bp(s.white(int(hit * SR), rng), 1500, 7000, 2) * 0.3   # kerumunan nanite
    buzz = crush(buzz, 5, 8000)
    brk = s.mix(zap(0.25, rng, 300, 9000), clank(rng, 360, 0.4, 0.9, 0.08) * 0.5)
    return s.reverb(place(total, (0.0, buzz), (hit, brk), (hit, boom(rng, 130, 50, 0.5, 0.1, 0.5) * 0.6)), 1.3, 0.22,
                    rng=rng)


def aksara_veil(rng, v):
    total = 1.2
    sweep = s.air_whoosh(0.8, rng, 400, 3000, 600, 1.0, 0.4) * 0.45
    dig = glitch(0.5, rng, 0.3)                     # kamuflase optik mengaktif
    return s.reverb(place(total, (0.05, sweep), (0.0, dig), (0.0, whine(0.6, 1800, 600, 0.15))), 1.4, 0.26, rng=rng)


def aksara_timestop(rng, v):
    total, hit = 2.4, 0.6
    build = whine(hit, 200, 700, 0.2)
    hum = reactorhum(1.6, 70, 0.2)
    freeze = tape(hum, 1.0, 0.12)                   # semua melambat & membeku
    clk = clank(rng, 300, 0.6, 1.0, 0.2)
    return s.reverb(place(total, (0.0, build), (hit, freeze), (hit, clk), (hit, boom(rng, 60, 30, 1.0, 0.3, 0.6) * 0.8)),
                    2.4, 0.3, rng=rng)


def aksara_timeresume(rng, v):
    total = 1.8
    hum = reactorhum(0.8, 70, 0.2)
    start = tape(hum, 0.12, 1.0)                    # waktu berjalan lagi
    bill = s.mix(boom(rng, 90, 30, 1.2, 0.35, 0.9) * 1.1, static_bed(0.6, rng, 200, 8000, 0.6))
    ticks = [(0.5 + i * 0.05, clank(rng, 900, 0.1, 0.5, 0.03) * 0.5) for i in range(8)]
    return s.reverb(place(total, (0.0, start), (0.45, bill), *ticks), 1.8, 0.26, rng=rng)


def aksara_rewind(rng, v):
    total, hit = 1.4, 0.5
    g = clank(rng, 500, 0.5, 1.0, 0.15)
    rev = g[::-1] * 0.8
    back = s.air_whoosh(0.5, rng, 2000, 600, 200, 1.0, 0.7) * 0.5
    return s.reverb(place(total, (0.0, rev), (0.0, back), (hit, zap(0.3, rng, 600, 9000) * 0.5),
                          (hit, boom(rng, 120, 60, 0.4, 0.1, 0.4) * 0.5)), 1.5, 0.24, rng=rng)


def aksara_soul(rng, v):
    total, rip = 3.2, 2.4
    drain = whine(rip, 180, 90, 0.18) + s.bp(s.pink(int(rip * SR), rng), 200, 2000, 2) * 0.12
    tt = s.t_axis(rip)
    drain = drain * np.minimum(1, tt / 0.4)
    tear = s.mix(zap(0.5, rng, 200, 7000), boom(rng, 90, 40, 0.8, 0.2, 0.6) * 0.8)
    return s.reverb(place(total, (0.0, drain), (rip, tear), (rip, static_bed(0.5, rng, 150, 6000, 0.5))), 2.2, 0.28,
                    rng=rng)


def aksara_ward(rng, v):
    total, hit = 2.0, 0.6
    spin = whine(hit, 300, 900, 0.22)
    bloom = s.mix(clank(rng, 420, 0.8, 1.0, 0.3), reactorhum(1.2, 110, 0.16))
    return s.reverb(place(total, (0.0, spin), (hit, bloom), (hit, static_bed(0.4, rng, 400, 7000, 0.3))), 2.0, 0.28,
                    rng=rng)


def aksara_purna(rng, v):
    total, hit = 4.0, 1.7
    parts = [(0.1 + i * 0.22, clank(rng, 360 + i * 60, 0.5, 1.0, 0.2) * 0.6) for i in range(6)]
    parts.append((0.0, charge(hit, 90, 500, 0.4)))
    parts.append((0.0, reactorhum(total, 70, 0.2)))
    parts.append((hit, boom(rng, 75, 24, 2.2, 0.6, 1.0) * 1.4))
    parts.append((hit, voice(2.2, rng, 85, 1.2, 0.34)))
    parts.append((hit, static_bed(1.2, rng, 150, 10000, 0.7)))
    parts.append((hit - 0.4, whine(0.4, 400, 1600, 0.3)))
    return s.reverb(place(total, *parts), 2.6, 0.3, rng=rng)


def aksara_erase(rng, v):
    total, hit = 6.2, 3.2
    n = int(hit * SR)
    tt = np.arange(n) / SR
    build = charge(hit, 60, 2000, 0.6)
    drone = voice(hit, rng, 70, 1.4, 0.28) * (tt / hit)[..., ] ** 1.2
    whiteout = s.mix(boom(rng, 70, 20, 3.0, 0.7, 1.0) * 1.5, static_bed(2.5, rng, 60, 14000, 1.0))
    glitchy = glitch(1.2, rng, 0.5)
    return s.reverb(place(total, (0.0, build), (0.0, drone), (hit, whiteout), (hit, glitchy),
                          (hit, voice(2.6, rng, 80, 1.3, 0.3))), 3.0, 0.32, rng=rng)


def aksara_disc(rng, v):
    total = 1.0
    parts = []
    for i in range(6):                              # enam drone diluncurkan
        parts.append((i * 0.03, s.mix(whine(0.4, 400 + i * 120, 1200, 0.2),
                                      s.bp(s.white(int(0.3 * SR), rng), 800 + i * 150, 4000, 2) * env(0.3, 0.1) * 0.3)))
    return s.reverb(place(total, *parts), 1.0, 0.2, rng=rng)


def aksara_shield(rng, v):
    deploy = s.mix(clank(rng, 380, 0.7, 1.0, 0.25), whine(0.3, 200, 700, 0.2))
    hum = reactorhum(0.8, 120, 0.18)
    return s.reverb(place(0.9, (0.0, deploy), (0.0, hum)), 1.0, 0.2, rng=rng)


def aksara_step(rng, v):
    pre = whine(0.12, 1600, 400, 0.25)
    pop = s.mix(zap(0.06, rng, 1500, 10000), clank(rng, 900, 0.25, 0.6, 0.04) * 0.4)
    return s.reverb(place(0.45, (0.0, pre), (0.12, pop)), 0.7, 0.18, rng=rng)


def aksara_parry(rng, v):
    fwip = s.air_whoosh(0.18, rng, 1200, 4500, 1500, 1.0, 0.4) * 0.6
    tk = s.mix(clank(rng, 1200, 0.3, 0.7, 0.05) * 0.5, zap(0.12, rng, 800, 9000) * 0.4)
    return s.reverb(place(0.5, (0.0, fwip), (0.1, tk)), 0.8, 0.2, rng=rng)


def aksara_core(rng, v):
    """0.52 Inti daya menyala: desing naik, kilat listrik pendek, denting kristal bening, dengung daya. Kode memutarnya
    dengan pitch per inti (enam nada naik), jadi keenam inti berurutan terdengar sebagai akor."""
    f = 880 + v * 110
    ping = s.bell(f, 0.9, rng, ((1, 1), (2.0, 0.42), (3.01, 0.22), (4.2, 0.1), (5.43, 0.06)), 0.32, 0.0012) * 0.55
    sweep = whine(0.16, 420, 1900, 0.16)
    snap = zap(0.07, rng, 2000, 12000, drop=False) * 0.35
    hum = reactorhum(0.7, 110, 0.12)
    sub = boom(rng, 120, 60, 0.35, 0.2, 0.35) * 0.45
    return s.reverb(place(1.1, (0.0, sweep), (0.1, snap), (0.11, ping), (0.1, sub), (0.12, hum)), 1.0, 0.2, rng=rng)


def aksara_rite(rng, v):
    total, read, etch, burst = 9.0, 2.5, 5.5, 7.5
    parts = [(0.0, reactorhum(burst, 60, 0.16)), (0.0, servo(read, 150, 400, rng, 0.2, 0.2))]
    for i in range(6):                              # subsistem demi subsistem online
        parts.append((read + i * 0.5, clank(rng, 360 + i * 70, 0.6, 1.0, 0.2) * 0.6))
        parts.append((read + i * 0.5, whine(0.3, 300 + i * 80, 900, 0.1)))
    parts.append((etch, charge(burst - etch, 90, 500, 0.4)))
    parts.append((etch, voice(burst - etch + 1, rng, 85, 1.0, 0.24)))
    parts.append((burst, boom(rng, 70, 24, 2.0, 0.55, 1.0) * 1.3))
    parts.append((burst, static_bed(1.2, rng, 150, 10000, 0.7)))
    return s.reverb(place(total, *parts), 2.6, 0.28, rng=rng)


# ------------------------------------------------------------------ 0.57 Henti Waktu Dunia (Fase Dewa)
# Dibuat dari nol (bukan sampel): sentakan, tarikan pita yang melambat & melengkung (efek distorsinya), gong logam yang
# nadanya ikut turun, lalu detak jam yang membeku; berjalan lagi = gong terbalik yang membengkak lalu terputus.

def bend_down(x, f0=1.0, f1=0.35, curve=2.2):
    """Pita yang melambat: nada & tempo turun makin dalam (dipakai untuk 'waktu' yang mengental)."""
    n = len(x)
    k = np.linspace(0, 1, n) ** curve
    speed = f0 + (f1 - f0) * k
    pos = np.cumsum(speed)
    pos = pos[pos < n - 1]
    return np.interp(pos, np.arange(n), x)


def flange(x, depth_ms=3.0, rate=0.6, mix=0.6):
    """Flanger: salinan tertunda yang jaraknya bergoyang (dunia 'melengkung')."""
    n = len(x)
    t = np.arange(n) / SR
    d = (0.5 + 0.5 * np.sin(2 * np.pi * rate * t)) * depth_ms / 1000.0 * SR + 1.0
    idx = np.clip(np.arange(n) - d, 0, n - 1)
    return x * (1 - mix * 0.5) + np.interp(idx, np.arange(n), x) * mix


def gong(rng, f, dur, tau, partials=((1.0, 1.0), (1.47, 0.7), (2.09, 0.5), (2.56, 0.35), (3.4, 0.25), (4.73, 0.15))):
    return s.bell(f, dur, rng, partials, tau, 0.002)


def aksara_worldstop(rng, v):
    """Waktu dunia berhenti (2,6 dtk): sentakan + dentum (0,15 dtk, saat bola shader mulai mengembang), tarikan pita yang
    melambat & melengkung, gong yang nadanya ikut turun, gemeretak halus, lalu detak jam pertama di 2,15 dtk (= 43 tick,
    AksaraFx.STOP_FIRST_TICK; detak berikutnya diputar client tiap 20 tick)."""
    total = 2.6
    snap = s.mix(boom(rng, 110, 28, 1.6, 0.7, 1.0) * 1.3, clank(rng, 900, 0.25, 1.4, 0.05) * 0.8,
                 s.bp(s.white(int(0.03 * SR), rng), 2000, 9000, 2) * env(0.03, 0.006) * 1.2)
    n = int(1.9 * SR)
    t = np.arange(n) / SR
    chord = sum(s.osc(f, 1.9, "saw") for f in (55.0, 82.5, 110.0, 164.8)) / 4.0
    hiss = s.bp(s.white(n, rng), 300, 6000, 2) * 0.6
    body = s.sweep_filter(chord + hiss, np.geomspace(5200, 180, n), "low", 1.6) * np.exp(-t / 0.9)
    warp = flange(bend_down(body, 1.0, 0.3), 4.0, 0.8, 0.7) * 0.9
    ring = flange(bend_down(gong(rng, 196.0, 2.6, 1.1), 1.0, 0.55, 1.6), 2.5, 0.35, 0.5) * 0.7
    crackle = s.crackle(1.8, 22, rng, 2500, 9000) * np.linspace(1, 0, int(1.8 * SR)) * 0.25
    pre = s.reverse_swell(0.15, rng, 800, 9000) * 0.5
    tick = aksara_tick_body(rng, 1.0) * 0.55
    out = place(total, (0.0, pre), (0.15, snap), (0.15, warp), (0.15, ring), (0.22, crackle), (2.15, tick))
    return s.reverb(out, 2.4, 0.3, rng=rng)


def aksara_tick_body(rng, pitch=1.0):
    """Satu detak jam: klik lebar yang tajam + badan 'tik' pendek + dentang kecil inharmonik yang cepat padam."""
    click = s.bp(s.white(int(0.006 * SR), rng), 800 * pitch, 11000, 2) * env(0.006, 0.0015) * 1.6
    body = s.bp(s.white(int(0.12 * SR), rng), 1000 * pitch, 6500 * pitch, 2) * env(0.12, 0.022) * 0.9
    partials = ((1.0, 1.0), (1.93, 0.6), (2.88, 0.4), (4.02, 0.25))
    ting = s.bell(1150.0 * pitch, 0.4, rng, partials, 0.06, 0.0005) * 0.35
    knock = s.lp(s.white(int(0.03 * SR), rng), 700 * pitch) * env(0.03, 0.007) * 0.6
    return s.mix(click, body, ting, knock)


def aksara_clocktick(rng, v):
    """Detak jam di dunia yang membeku (diputar tiap 1 detik selama Henti Waktu Dunia): ruang luas, gemanya panjang."""
    body = aksara_tick_body(rng, 1.0 if v == 0 else 0.84)
    return s.reverb(place(0.5, (0.0, body)), 1.1, 0.3, rng=rng)


def aksara_worldresume(rng, v):
    """Waktu dunia berjalan lagi (2,3 dtk): gong & desis terbalik yang membengkak 1,5 dtk (= PralayaGod.RESUME_WINDUP 30
    tick), terputus dengan sentakan tepat saat waktu berjalan, lalu udara mengalir kembali."""
    total = 2.3
    rise = 1.5
    g = s.mix(gong(rng, 233.0, rise, 0.6), gong(rng, 610.0, rise, 0.45) * 0.45)[::-1]
    n = int(rise * SR)
    t = np.arange(n) / SR
    swell = s.sweep_filter(s.white(n, rng), np.geomspace(300, 9000, n), "low", 1.2) * (t / rise) ** 3 * 0.7
    tone = s.osc(np.geomspace(60, 420, n), rise, "saw") * (t / rise) ** 2.5 * 0.25
    build = flange(s.mix(g * 0.8, swell, s.lp(tone, 2500)), 3.0, 1.2, 0.6)
    cut = s.mix(clank(rng, 700, 0.3, 1.3, 0.06) * 0.7, boom(rng, 140, 45, 0.5, 0.4, 0.5) * 0.8,
                s.bp(s.white(int(0.05 * SR), rng), 1500, 9000, 2) * env(0.05, 0.01))
    air = s.whoosh(rng, 1) * 0.35
    out = place(total, (0.0, build), (rise, cut), (rise - 0.45, air))
    return s.reverb(out, 1.4, 0.22, rng=rng)


# ------------------------------------------------------------------ 0.58 Inti Daya / Benak / Atma yang lebih merusak

def aksara_ruin(rng, v):
    """Ledakan Inti Daya yang menghancurkan medan (3,4 dtk): retakan tajam, dentum sub yang dalam, gemuruh tanah yang
    bergulung, lalu bongkahan batu berjatuhan & berderak. v=1 lebih berat & lebih banyak reruntuhan."""
    total = 3.4
    heavy = v == 1
    crack = s.bp(s.white(int(0.06 * SR), rng), 1200, 12000, 2) * env(0.06, 0.01) * 1.6
    body = boom(rng, 62 if heavy else 72, 20, 2.6, 1.0, 1.3) * 1.5
    n = int(3.0 * SR)
    t = np.arange(n) / SR
    wobble = 0.6 + 0.4 * np.abs(np.sin(2 * np.pi * (3.1 + rng.uniform(-0.4, 0.4)) * t + rng.uniform(0, 6)))
    rumble = s.lp(s.white(n, rng), 160) * np.exp(-t / (1.3 if heavy else 1.0)) * wobble * 2.2
    grit = s.bp(s.white(n, rng), 200, 1800, 2) * np.exp(-t / 0.5) * 0.5
    debris = s.crackle(2.8, 34 if heavy else 24, rng, 500, 6500, 0.006,
                       curve=np.concatenate([np.linspace(0.2, 1.0, 10), np.linspace(1.0, 0.0, 40)])) * 0.9
    rocks = [(0.25 + rng.uniform(0, 2.2), s.bp(s.white(int(0.07 * SR), rng), 260, 2400, 2) * env(0.07, 0.015)
              * rng.uniform(0.3, 0.8)) for _ in range(12 if heavy else 8)]
    out = place(total, (0.0, crack), (0.0, body), (0.02, rumble), (0.02, grit), (0.15, debris), *rocks)
    return s.reverb(out, 2.8, 0.32, rng=rng)


def aksara_psyburst(rng, v):
    """Benak meledak (1,4 dtk): tarikan terbalik pendek, letupan tekanan, kilau psionik yang bergetar & turun nadanya."""
    total = 1.4
    pre = s.reverse_swell(0.16, rng, 900, 10000) * 0.6
    pop = s.mix(boom(rng, 170, 55, 0.45, 0.6, 0.4) * 1.1,
                s.bp(s.white(int(0.03 * SR), rng), 1500, 9000, 2) * env(0.03, 0.006) * 0.9)
    n = int(0.9 * SR)
    t = np.arange(n) / SR
    base = 990.0 if v == 0 else 830.0
    shimmer = sum(s.osc(base * r * (1 + 0.012 * np.sin(2 * np.pi * 23 * t)), 0.9, "sine") * a
                  for r, a in ((1.0, 1.0), (1.5, 0.6), (2.0, 0.45), (2.98, 0.25)))
    shimmer = flange(bend_down(shimmer * np.exp(-t / 0.28), 1.0, 0.55, 1.4), 2.0, 2.4, 0.6) * 0.5
    zing = s.osc(np.geomspace(4200, 520, int(0.35 * SR)), 0.35, "sine") * env(0.35, 0.09) * 0.35
    out = place(total, (0.0, pre), (0.16, pop), (0.16, shimmer), (0.17, zing))
    return s.reverb(out, 1.6, 0.3, rng=rng)


def aksara_soulburst(rng, v):
    """Jiwa yang tercabut meledak (1,9 dtk): jeritan arwah (formant) yang melengking lalu jatuh, hempasan udara, desis
    yang memudar."""
    total = 1.9
    n = int(1.3 * SR)
    t = np.arange(n) / SR
    f0 = 300.0 if v == 0 else 250.0
    glide = f0 * np.interp(t, [0, 0.35, 1.3], [1.0, 1.75, 0.8]) * (1 + 0.02 * np.sin(2 * np.pi * 6.3 * t))
    wail = s.formant(s.osc(glide, 1.3, "saw") + 0.3 * s.osc(glide * 1.01, 1.3, "saw"), "o" if v == 0 else "u")
    wail = wail * np.minimum(1, t / 0.08) * np.exp(-t / 0.55) * 1.4
    airy = s.sweep_filter(s.white(n, rng), np.geomspace(6000, 900, n), "low", 1.0) * np.exp(-t / 0.4) * 0.45
    hit = s.mix(boom(rng, 120, 45, 0.5, 0.5, 0.5) * 0.9, s.bp(s.white(int(0.04 * SR), rng), 800, 7000, 2) * env(0.04, 0.01))
    out = place(total, (0.0, hit), (0.02, flange(wail, 3.0, 0.9, 0.5)), (0.0, airy))
    return s.reverb(out, 2.2, 0.36, rng=rng)


RECIPES = {
    "aksara_transform": (aksara_transform, 1, 1.0),
    "aksara_revert": (aksara_revert, 1, 0.8),
    "aksara_pulse": (aksara_pulse, 3, 0.6),
    "aksara_punch": (aksara_punch, 2, 0.9),
    "aksara_sixfold": (aksara_sixfold, 1, 1.0),
    "aksara_beam": (aksara_beam, 1, 0.95),
    "aksara_nova": (aksara_nova, 1, 1.0),
    "aksara_fold": (aksara_fold, 1, 0.85),
    "aksara_gate": (aksara_gate, 1, 0.95),
    "aksara_lance": (aksara_lance, 1, 0.9),
    "aksara_dominion": (aksara_dominion, 1, 0.9),
    "aksara_rewrite": (aksara_rewrite, 1, 0.9),
    "aksara_veil": (aksara_veil, 1, 0.8),
    "aksara_timestop": (aksara_timestop, 1, 1.0),
    "aksara_timeresume": (aksara_timeresume, 1, 1.0),
    "aksara_rewind": (aksara_rewind, 1, 0.85),
    "aksara_soul": (aksara_soul, 1, 0.9),
    "aksara_ward": (aksara_ward, 1, 0.8),
    "aksara_purna": (aksara_purna, 1, 1.0),
    "aksara_erase": (aksara_erase, 1, 1.0),
    "aksara_disc": (aksara_disc, 1, 0.85),
    "aksara_shield": (aksara_shield, 1, 0.85),
    "aksara_step": (aksara_step, 1, 0.75),
    "aksara_rite": (aksara_rite, 1, 1.0),
    "aksara_parry": (aksara_parry, 1, 0.8),
    "aksara_core": (aksara_core, 2, 0.75),
    "aksara_worldstop": (aksara_worldstop, 1, 1.0),
    "aksara_worldresume": (aksara_worldresume, 1, 1.0),
    "aksara_clocktick": (aksara_clocktick, 2, 0.8),
    "aksara_ruin": (aksara_ruin, 2, 1.0),
    "aksara_psyburst": (aksara_psyburst, 2, 0.85),
    "aksara_soulburst": (aksara_soulburst, 2, 0.85),
}
WINDUPS = set()
LOOPS = set()

s.RECIPES.update(RECIPES)
s.WINDUPS.update(WINDUPS)
s.LOOPS.update(LOOPS)

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "out"
    only = sys.argv[2:] if len(sys.argv) > 2 else None
    os.makedirs(out, exist_ok=True)
    for name, (fn, count, gain) in RECIPES.items():
        if only and name not in only:
            continue
        for v in range(count):
            y = s.render(name, fn, v, gain)
            fname = f"{name}_{v + 1}.ogg"
            s.encode(y, os.path.join(out, fname))
            rms = 20 * np.log10(np.sqrt(np.mean(y ** 2)) + 1e-9)
            print(fname, round(len(y) / SR, 2), "dtk", round(float(rms), 1), "dB", flush=True)
